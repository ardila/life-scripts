# NVDA — NVIDIA Corporation

## Where this sits in the AI stack
NVDA sells the integrated rack-scale training and inference substrate for frontier AI: a Blackwell/Blackwell Ultra GPU die (~208B transistors on TSMC 4NP) plus HBM3e stack on a CoWoS-L interposer, packaged 72 to a rack via copper-backplane NVLink (NVL72), connected rack-to-rack via Quantum-X800 InfiniBand or Spectrum-X Ethernet, and exposed through CUDA + cuDNN + cuBLAS + CUTLASS + NCCL + TensorRT to PyTorch/JAX. The unit of competition is no longer the chip; it is the rack-scale "AI factory" with deterministic ~14 TB/s bisection inside the NVLink domain. NVDA is dominant for both training (where it has no real competition) and high-throughput frontier inference (where it competes with Google TPU and AMD on specific workloads), and largely absent from edge inference.

## Moat — what it is physically made of
The moat decomposes into five layers, each with different durability.

**1. CUDA + numerical libraries (10–15 year moat, eroding at the inference edge).** cuDNN, cuBLAS, CUTLASS, and the post-training kernels (TensorRT, TensorRT-LLM) embed a decade of architecture-specific tuning — Tensor Core scheduling, register-pressure-aware tiling, Hopper TMA usage, Blackwell NVFP4 quantization paths. The replacement work is not "write a compiler"; it is rewriting tens of thousands of fused kernels per generation. ROCm 7 closed roughly 3.5× of the inference gap vs ROCm 6 [17] and AMD's MI355X is now within striking distance of B200 on Llama-2-70B inference [22][23]. The training-side moat — Megatron-LM's specific NCCL all-reduce/all-gather schedules tuned to NVLink topology, FP8/FP4 mixed-precision recipes, TransformerEngine — is materially harder to replicate and has not yet been replicated. Stack Overflow CUDA:ROCm question ratio is ~50:1 [17], a proxy for the long-tail debugging knowledge that determines whether a 10,000-GPU job actually finishes.

**2. NCCL collective comms + NVLink fabric (5–8 year moat, hardware-anchored).** NCCL implements ring- and tree-based all-reduce/all-gather over NVLink with topology-aware path selection. NVLink 5 in NVL72 delivers ~1.8 TB/s per GPU and ~14 TB/s bisection inside the rack — roughly an order of magnitude over commodity 800 GbE NICs. RCCL (AMD's clone) and the UALink open-standard alternative are functionally behind on heterogeneous topologies and copper-backplane density. This is not pure software: it requires the SerDes IP, the connector density, and the NVSwitch ASIC. NVLink 6 in Vera Rubin keeps NVDA on the lead lap [18].

**3. CoWoS-L packaging allocation (3–5 year moat, supply-chain-anchored).** NVDA has booked ~60% of TSMC's total CoWoS capacity for 2026–2027 — ~510k wafers, primarily CoWoS-L — required for Blackwell's reticle-stitched die and Rubin's larger interposers [5][6]. CoWoS-S (the smaller-interposer variant AMD's MI300/MI355X uses) is less constrained; CoWoS-L is the actual chokepoint for chips above the reticle limit. TSMC is ramping CoWoS from ~35k wafers/month (late 2024) to ~130k (end-2026) [5], but NVDA's pre-purchased share locks competitors into the tail of the queue. Google reportedly cut its 2026 TPU production target from 4M to 3M units citing CoWoS access [5].

**4. HBM specification leadership (2–4 year moat).** NVDA is demanding 10–11 Gb/s HBM4 vs the JEDEC 8 Gb/s baseline, forcing SK Hynix and Samsung to produce custom binned parts [12]. SK Hynix (~70% of NVDA's HBM4) and Samsung (~30%) are co-designing with NVDA; Micron is only qualified for the lower-tier Rubin CPX inference SKU [12]. This is moat-as-buyer-power, not moat-as-IP.

**5. Customer relationships and reference architectures (2–3 year moat).** Microsoft, Meta, Google, Amazon, Oracle, CoreWeave have hyperscale-grade deployment recipes — power, cooling, validation, NCCL tuning — built around NVDA's reference designs (DGX SuperPOD, GB200/300 NVL72). Switching costs are real but not insurmountable; this is the layer that ASIC programs are actively eroding.

What it is **not** made of: brand, patent fortress, or first-mover in any abstract sense. Patents in this space don't bite — the moat is execution and ecosystem.

## AI buildout bottleneck map
Gating constraints, ranked by tightness, with NVDA's exposure:

- **Power generation & grid interconnect (tightest).** US data center demand: ~50 GW (2024) → ~76 GW (2026) [14]. GE Vernova, Siemens, and Mitsubishi Power all show gas turbine backlogs into 2028–2030 [14][15]. Hyperscaler capex ~$600B in 2026, ~75% AI-tied [14]. NVDA is **indirectly exposed** — every delayed gigawatt is a delayed Rubin order, but NVDA isn't the bottleneck owner. Per-rack power has gone from ~30 kW (H100) to ~120 kW (GB300 NVL72), pushing facilities into liquid cooling and behind-the-meter generation; this favors NVDA's rack-scale value capture but constrains absolute deployment volume.
- **CoWoS-L advanced packaging.** NVDA is the **constraint owner** by contractual lock-in — it benefits from the scarcity it created. Competitors (AMD, hyperscaler ASICs except Google) are exposed customers.
- **HBM4 yield.** Samsung 1c DRAM yields ~60% [12]; volume bring-up is the gate on Rubin. NVDA is **a beneficiary** insofar as its 10–11 Gb/s spec demand keeps suppliers concentrated, but **exposed** if Samsung's qualification slips, since SK Hynix alone cannot supply Rubin volumes.
- **TSMC N3/N2 capacity.** 3nm utilization at 100% in H1 2026, demand ~3× supply; Rubin moves to N3P, Rubin Ultra to N2 [11]. NVDA gets priority allocation; competitors fight for tail.
- **Optical interconnect.** Co-packaged optics for Quantum-X / Spectrum-X arrive in 2026 [18]. NVDA is ahead of merchant Ethernet vendors on CPO integration; Coherent, Lumentum, Marvell are arms suppliers.
- **Liquid cooling at >100 kW/rack.** CDU and direct-to-chip cooling supply (Vertiv, CoolIT, Boyd) is tight but expanding. NVDA is **a beneficiary**, not the bottleneck owner.
- **Kernel & compiler talent.** A few thousand engineers globally can write production CUDA kernels at the level Triton/CUTLASS demand. NVDA owns the largest pool by an order of magnitude.

The single most important asymmetry: **the binding constraints are physical (power, packaging, memory yield) rather than design**. That structurally favors whoever has pre-purchased physical capacity — i.e., NVDA — for the next 24 months.

## Competitive teardown
Each competitor on the technical axis where they actually compete:

**AMD (MI355X today, MI400 H2'26).** The genuine merchant alternative. ISSCC 2026 disclosure: MI355X doubled per-CU throughput vs MI325X [7]. MLPerf Inference v6.0 on Llama-2-70B: tied B200 in Offline, 97% in Server, **119% in Interactive** [8][22]. MLPerf Training v5.1 LoRA: 10.18 min vs B200's 9.85 min — within ~3% [22]. MI400 (CDNA 5, TSMC N2, 432 GB HBM4, ~2× compute) targets H2 2026 [22]. **The honest read: AMD is at parity on single-node inference for memory-bound workloads.** Where AMD still loses materially: multi-node training at 1k+ GPU scale (NCCL > RCCL on heterogeneous fabric), FP4 frontier training (NVFP4 hardware path), and compiler maturity for novel architectures (MoE routing, long-context attention variants). AMD will take share in inference-only deployments; the training fortress is still NVDA's.

**Google TPU v7 Ironwood.** The most credible vertical-stack threat. Anthropic deal: up to 1M TPU access, ~1 GW online in 2026, ~$10B Broadcom-direct racks + ~$42B GCP RPO [9][10]. TPUv7 is co-designed with XLA/JAX; for workloads written natively in JAX, the abstraction tax is negligible. The constraint: TPU is captive — only available via GCP or Anthropic's specific deal — and Google itself is CoWoS-supply-constrained (3M unit cut from 4M plan) [5]. Threat to NVDA: real but bounded by Google's willingness to be a merchant and by CoWoS allocation.

**AWS Trainium2/3.** Trainium3 launched Dec 2025, 3 nm, 2.52 PFLOPS FP8, 144 GB HBM3e [10]. Project Rainier scaled to ~500k Trainium2 → 1M+ by end-2025 [10]. Anthropic uses it heavily for training. Trainium's NeuronX SDK is meaningfully behind CUDA; the wins are TCO-driven for Anthropic-style customers willing to invest in compiler porting. Threat axis: large-batch inference and select training workloads; not frontier multi-modal.

**Meta MTIA + Broadcom.** April 2026: 1 GW initial commitment, multi-GW phase, TSMC N2 [11][29]. MTIA has been mainly recommendation/ranking-focused; the 2 nm jump signals a real LLM-inference push. Threat to NVDA's Meta wallet share is direct — Meta is one of the top-4 customers at ~15% of revenue [27]. The displacement is incremental, not wholesale: Meta still buys Blackwell for Llama training.

**OpenAI–Broadcom ASIC.** $10B program, Richard Ho leading, 10 GW target by 2029 [11]. First silicon late 2026/2027. This is the most strategically alarming for NVDA because OpenAI is its largest forward customer commitment (Stargate). The deal scaled down from $100B to $20–30B notably suggests OpenAI itself is hedging [26].

**Custom silicon shipment growth ~44.6% CAGR vs GPU shipment growth 16.1%** [28]. NVDA AI accelerator share peaked ~87% (2024), projected ~75% by 2026 [28]. This is the bear case as a number.

The honest summary: NVDA has **lost no axis where training scaling matters at >1k GPUs**. It is being **competed at parity on single-node inference for steady-state memory-bound workloads** by AMD and at the captive-vertical-stack level by Google. Custom ASICs are eating 5–10 points of share per year off the top.

## Bull case — technical
The technical conditions:

1. **Inference compute outgrows training compute by >5×, and the marginal token requires architectural complexity (long context, agentic, multi-modal, reasoning) that custom ASICs cannot retarget quickly.** Blackwell Ultra's 50× tokens-per-MW vs Hopper [1] and Rubin CPX's disaggregation specifically address long-context inference, where ASIC inflexibility hurts.
2. **NVFP4 + Tensor Core path remains the best precision-vs-quality frontier.** MLPerf Training v5.1: Llama 3.1 405B trained in 10 minutes on 5,120 Blackwell GPUs using NVFP4 [24], 2.7× the prior round's per-job throughput, 45% per-GPU at fixed scale [24]. AMD has no FP4 training story shipping at scale yet.
3. **CoWoS-L and HBM4 high-binned supply remain physical bottlenecks through 2027.** This locks NVDA's allocation lead until at least Rubin Ultra ships [5][12].
4. **NVLink Fusion converts the would-be threat (custom ASICs) into incremental NVDA revenue.** By licensing NVLink to integrate Marvell/MediaTek/hyperscaler accelerators into NVDA racks [18], NVDA captures the rack-scale system value even when the compute die isn't NVDA's.
5. **Power constraints favor whoever delivers the most tokens per kilowatt.** GB300 NVL72 (50× vs Hopper) is currently the answer; Rubin VR200 is claimed at 3.3× GB300 [1]. Per-MW productivity is what hyperscalers are now optimizing under turbine-backlog reality.

**Base rate.** Software-anchored hardware moats with foundry pre-purchase advantages historically erode over 5–10 years (Intel x86 took ~7 years from AMD Zen 1 to lose 25 points of server share; Cisco took 10 to lose meaningful enterprise share). NVDA's moat is younger but deeper than either. Reasonable baseline: market share drift from ~80% to ~65% over 2026–2029, with revenue still growing because the pie expands faster than share is lost. Financial outcome: revenue compounds in the 25–35% range through FY28, gross margin recovers to mid-70s [13], EPS grows ~30%/year. At 26× forward [16] this is fairly priced if growth holds, undervalued if 90-day capex signals stay positive.

## Bear case — technical
The technical conditions under which the thesis breaks:

1. **Inference workload mix shifts decisively toward steady-state, memory-bound, low-batch transformer decoding** — exactly the regime where MI355X already matches B200 server performance and where any Broadcom-designed ASIC at 2 nm will beat both on $/token. The MI355X being 119% of B200 on Llama-2-70B Interactive [22] is a leading indicator. If 2027 inference is 80% of compute (today ~67%), the moat-thinnest workload becomes the dominant workload.
2. **Triton + MLIR + PyTorch 2 compile reach hardware-agnostic parity.** OpenAI's Triton is now usable on AMD ROCm and on TPU via XLA bridging; PyTorch's Inductor backend uses Triton as its IR. If model authors write Triton instead of CUDA, NCCL-level differentiation matters less for inference, and the CUDA layer of the moat thins from "decade of kernels" to "best-tuned but not unique." This is not a 12-month risk but a 36-month one.
3. **Hyperscaler concentration becomes hyperscaler defection.** Top-4 direct customers = 61% of revenue (Q3 FY26: 22%, 15%, 13%, 11%) [27]; top-5 hyperscalers >50% [27]. Every one of them has an ASIC program. If the implied weighted-average customer's ASIC share rises from ~10% to ~30% of their AI capex over 24 months — Meta's 1 GW Broadcom commitment is the existence proof — NVDA's $216B base sees 10–15 points of headwind just from internal substitution.
4. **CoWoS-L expansion outpaces NVDA demand growth, eliminating allocation scarcity by 2027.** TSMC is ~3.7×-ing CoWoS capacity [5]; if Rubin demand normalizes faster than TSMC adds CoWoS-L lines, AMD and the ASIC players catch up on physical supply.
5. **Power/turbine reality limits hyperscaler capex below the implied $600B+/year run-rate** [14]. The bull case assumes hyperscaler capex compounds; if grid interconnect timelines actually stretch into 2028+, FY28–FY29 NVDA revenue is supply-rationed downward, and a backlog that was thought to be tight becomes structurally thinner.
6. **OpenAI/Stargate slips materially.** The $100B pledge already trimmed to $20–30B with the "no assurance any investment will be completed" 10-K language [26] is a yellow flag. If OpenAI's first Broadcom silicon (late 2026) is competitive, OpenAI shifts marginal capex away from Rubin.

The short-seller's summary would read: NVDA is a 25× forward-PE business whose top-4 customers are simultaneously its top-4 competitors, whose moat's weakest layer (inference) is the fastest-growing workload, and whose physical-supply lock-in expires inside the discount window of any reasonable DCF.

## Market view check
Stock $215.20 (May 8, 2026); forward P/E ~25–26× on consensus FY27 EPS ~$8.34 [16]; consensus PT ~$271 (+~26%), Strong Buy [16]. Trailing P/E 43.9× — well below 10-year average ~62× [16]. Q1 FY27 guide $78B excludes China data center compute [13]. The market is pricing **a deceleration** — at consensus growth and stable margins, 25× forward is not aggressive — but is **also pricing in continued moat durability** through the Rubin generation. The price is not consistent with a 2027–2028 displacement of >20 points of share by ASICs; it is consistent with mild share loss inside an expanding pie. The consensus appears to underweight (a) the parity AMD has reached on single-node inference and (b) the customer-concentration-vs-customer-ASIC tension. The market is overweighting the H20/B30A China optionality (mostly noise) and underweighting NVLink Fusion as a strategic hedge. Net: roughly fairly priced; mispricings are second-order and direction-ambiguous.

## 90-day falsifiers
Specific events to watch through August 2026:

- **NVDA Q1 FY27 print (late May 2026):** Data Center revenue ≥ $66B and **non-GAAP gross margin ≥ 72%** keeps thesis intact; <70% would suggest Rubin transition is more dilutive than guided.
- **Hyperscaler Q2 2026 capex updates (Microsoft/Meta/Google/Amazon, late July):** Sequential change in disclosed AI capex run-rate. >+10% sequential → supply-tightness thesis intact; cuts of >5% sequentially → demand-pull weakening.
- **Vera Rubin R100 sampling timeline:** confirmation of Q4 2026 sampling at GTC summer keynote / Computex. Slip beyond Q1 2027 → Rubin Ultra/Feynman cadence breaks.
- **Samsung HBM4 11 Gb/s qualification at NVDA:** Currently passed at 10–11 Gb/s [12]. A re-qualification slip would compress Rubin volume in H2 2026.
- **MI400 first benchmarks (expected H2 2026):** If MI400 reaches within 10% of B300/Rubin on multi-node MLPerf Training submissions on GPT-class architectures, the training-side moat narrative weakens materially.
- **Meta MTIA-2 / Broadcom ASIC silicon disclosure:** Performance-per-watt vs B300 at the next hyperscaler conference (Hot Chips August). Within 30% → real Meta wallet erosion timeline accelerates from 2028 to 2027.
- **OpenAI–NVDA definitive agreement:** Whether the trimmed $20–30B Stargate commitment is actually signed [26]. Any further descope is a material negative.
- **CoWoS-L allocation reshuffle:** TrendForce/DigiTimes channel-checks for any 2027 CoWoS-L share moving from NVDA to AMD/Broadcom.
- **Anthropic compute-mix disclosures:** Any datapoint suggesting Trainium/TPU now exceeds GPU in Anthropic's training mix is a leading signal of frontier-lab defection.

## What I could not verify
- Exact NVFP4 numerical-quality vs FP8 on production frontier models (NVDA marketing claims vs independent perplexity measurements).
- The actual 22%/15%/13%/11% customer identities — strongly inferred to be Microsoft, Meta, Google, Amazon (or Oracle/CoreWeave-via-Microsoft) but NVDA does not disclose names.
- Whether Rubin CPX's disaggregated prefill/decode architecture preserves NVLink-level integration or implies a more open fabric — engineering details not yet public.
- Independent measurement of NVL72's NVLink5 bisection bandwidth at sustained AllReduce loads (datasheet ~14 TB/s; field-realized number not published in MLPerf).
- The economics of NVLink Fusion licensing — whether NVDA captures system-level margin on third-party-die racks or only switch/cable revenue [18].
- Whether Samsung's HBM4 11 Gb/s pass holds across full production binning, or only on engineering samples.
- The true depth of the OpenAI–Broadcom design progress — whether first silicon achieves taping-out targets or slips into 2027.
- Anthropic's NVDA-specific spend trajectory under the Google TPU expansion; the Google deal may be incremental or substitutive.

## Sources
[1] https://blogs.nvidia.com/blog/data-blackwell-ultra-performance-lower-cost-agentic-ai/ — retrieved 2026-05-10 — Blackwell Ultra throughput-per-MW and tokens-per-cost claims vs Hopper, hyperscaler deployment list.
[2] https://newsletter.semianalysis.com/p/inferencex-v2-nvidia-blackwell-vs — retrieved 2026-05-10 — SemiAnalysis InferenceX v2 cross-vendor inference benchmarks on Blackwell, Hopper, AMD.
[3] https://newsletter.semianalysis.com/p/vera-rubin-extreme-co-design-an-evolution — retrieved 2026-05-10 — Vera Rubin co-design details, NVLink 6, rack architecture evolution from GB200.
[4] https://www.servethehome.com/nvidia-reports-q4-fy2026-earnings-data-center-and-proviz-drive-revenue-records/ — retrieved 2026-05-10 — Q4 FY26 segment revenue breakdown, $62.3B Data Center +75% YoY.
[5] https://www.astutegroup.com/news/industrial/advanced-packaging-demand-soars-nvidia-secures-60-of-cowos-capacity/ — retrieved 2026-05-10 — Morgan Stanley CoWoS allocation analysis, 60% NVDA share, Google's TPU production cut.
[6] https://www.digitimes.com/news/a20251210PD218/tsmc-cowos-capacity-nvidia-equipment.html — retrieved 2026-05-10 — TSMC CoWoS expansion 35k → 130k wafers/month, NVDA booking through 2027.
[7] https://www.tomshardware.com/tech-industry/semiconductors/inside-the-instinct-mi355x — retrieved 2026-05-10 — ISSCC 2026 MI355X disclosure, per-CU doubling, AMD claim of GB200-matching performance.
[8] https://www.amd.com/en/blogs/2026/amd-delivers-breakthrough-mlperf-inference-6-0-results.html — retrieved 2026-05-10 — AMD MLPerf Inference v6.0 results, MI355X 100k tok/s on Llama-2-70B Server.
[9] https://newsletter.semianalysis.com/p/tpuv7-google-takes-a-swing-at-the — retrieved 2026-05-10 — TPUv7 Ironwood architecture, Anthropic 1M TPU deal structure, Broadcom direct sale.
[10] https://www.datacenterfrontier.com/machine-learning/article/55335703/inside-anthropics-multi-cloud-ai-factory-how-aws-trainium-and-google-tpus-shape-its-next-phase — retrieved 2026-05-10 — Anthropic multi-cloud strategy, Project Rainier Trainium2 scale, Trainium3 specs.
[11] https://about.fb.com/news/2026/04/meta-partners-with-broadcom-to-co-develop-custom-ai-silicon/ — retrieved 2026-05-10 — Meta-Broadcom MTIA 1 GW commitment, 2 nm node, multi-GW roadmap.
[12] https://www.trendforce.com/news/2026/03/09/news-samsung-sk%E2%80%AFhynix-reportedly-tapped-as-nvidia-rubin-hbm4-suppliers-shipments-could-start-in-march/ — retrieved 2026-05-10 — Rubin HBM4 supplier split, 10–11 Gb/s spec, Samsung yield data.
[13] https://analysis.org/nvidias-q4-fy2026-was-a-scale-event-68-1b-quarter-215-9b-year-and-guidance-that-shrugged-off-china/ — retrieved 2026-05-10 — Q4 FY26 GM 75.2%, Q1 FY27 $78B guide excluding China DC, full-year financials.
[14] https://ibinterviewquestions.com/guides/energy-investment-banking/data-center-power-boom-ai-demand-hyperscaler — retrieved 2026-05-10 — US data center power 50→76 GW, $600B hyperscaler capex 2026, turbine backlogs.
[15] https://power.mhi.com/regions/amer/insights/us-power-outlook-and-long-term-trends — retrieved 2026-05-10 — Mitsubishi Power gas turbine OEM backlog through 2030.
[16] https://www.gurufocus.com/term/forward-pe-ratio/NVDA — retrieved 2026-05-10 — NVDA forward PE 26.0, FY27 EPS consensus, price target.
[17] https://www.thundercompute.com/blog/rocm-vs-cuda-gpu-computing — retrieved 2026-05-10 — ROCm 7 vs CUDA gap analysis, Stack Overflow ratio, Triton portability.
[18] https://www.sdxcentral.com/news/nvidia-opens-nvlink-fabric-to-hyperscaler-custom-silicon/ — retrieved 2026-05-10 — NVLink Fusion architecture, three-tier networking, Marvell partnership.
[19] https://nvidianews.nvidia.com/news/nvidia-announces-financial-results-for-fourth-quarter-and-fiscal-2026 — retrieved 2026-05-10 — Official Q4/FY26 results press release.
[20] https://wolfstreet.com/2025/04/15/nvidia-makes-mess-afterhours-discloses-5-5-billion-in-charges-due-to-us-export-restrictions-on-its-h20-chip-for-china/ — retrieved 2026-05-10 — H20 export restriction $5.5B charge disclosure.
[21] https://www.calcalistech.com/ctechnews/article/bkyz5ttozg — retrieved 2026-05-10 — Mellanox/networking $11B quarterly run rate, Spectrum-X $10B annualized.
[22] https://rocm.blogs.amd.com/artificial-intelligence/mlperf-inference-v6.0/README.html — retrieved 2026-05-10 — AMD MLPerf v6.0 detailed comparison vs B200/B300.
[23] https://www.spheron.network/blog/mlperf-inference-v6-benchmark-results-2026/ — retrieved 2026-05-10 — Independent MLPerf v6.0 GPU rankings cross-vendor.
[24] https://developer.nvidia.com/blog/nvidia-blackwell-architecture-sweeps-mlperf-training-v5-1-benchmarks/ — retrieved 2026-05-10 — MLPerf Training v5.1 5,120-GPU Llama 3.1 405B 10-min record, NVFP4 use.
[25] https://www.sundeepteki.org/blog/nvidias-ai-moat-in-2025-a-deep-dive — retrieved 2026-05-10 — CUDA developer count and ecosystem metrics.
[26] https://www.datacenterfrontier.com/machine-learning/article/55354528/nvidias-100-billion-openai-bet-shrinks-and-signals-a-new-phase-in-the-ai-infrastructure-cycle — retrieved 2026-05-10 — OpenAI commitment trimmed from $100B to $20–30B, Stargate phasing.
[27] https://daloopa.com/blog/analyst-pov/nvidia-customer-concentration-a-big-4-earnings-preview — retrieved 2026-05-10 — Top-4 customer concentration 61% (22/15/13/11) Q3 FY26, hyperscaler share >50%.
[28] https://introl.com/blog/custom-silicon-inflection-2026-hyperscaler-asics-nvidia-gpu — retrieved 2026-05-10 — Custom ASIC 44.6% CAGR vs GPU 16.1%, NVDA share 87%→75% trajectory.
[29] https://www.cnbc.com/2026/04/14/meta-commits-to-one-gigawatt-of-custom-chips-with-broadcom-as-hock-tan-agrees-to-leave-board.html — retrieved 2026-05-10 — Meta 1 GW MTIA commitment scope and Broadcom board change.
[30] https://lambda.ai/blog/lambda-mlperf-training-benchmarks-v5.1 — retrieved 2026-05-10 — GB300 NVL72 27% performance lift over GB200 NVL72 in MLPerf Training v5.1.