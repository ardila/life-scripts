# PH — Parker-Hannifin Corporation

## Where this sits in the AI stack
PH is a motion-and-control industrial conglomerate; its AI-stack exposure is at the **rack-level fluid handling layer** — universal quick-disconnect (UQD/UQDB) couplings, manifolds, hoses, fittings, filtration, and thermal control components that sit between the cold plate and the coolant distribution unit (CDU) on liquid-cooled GPU racks (NVIDIA GB200/GB300 NVL72-class) [1][2][3]. It does not make GPUs, cold plates, CDUs, optics, or power gear. By management's own acknowledgement, data center is **~1% of consolidated sales** [4]; the remaining ~99% is aerospace systems (F-35, commercial OEM/aftermarket, Meggitt) and diversified industrial flow/motion control. Treat PH as an aerospace/industrial compounder with a small, real, growing AI sidecar — not as an AI infrastructure pure-play.

## Snapshot
- **Price:** $878.83 (2026-05-08 close) [5]
- **Market cap:** ~$124.2B [5]
- **52-week range:** ~$538 – $1,034.96 (sources conflict on the low; see "What I could not verify") [5][6]
- **Forward P/E:** ~25.8× (on Street FY27 EPS ~$32.50) [7][8]
- **EV / NTM revenue:** ~6.0×–6.5× (FY26 revenue guide $20.9–$21.3B; net debt ~$6–7B pre-Filtration Group; pro forma higher) [9][10] — approximate
- **Consensus 12-month price target:** $996.81 (+13.4% implied) [11]
- **YTD total return:** n/a — could not source a verified 2025-12-31 close; the stock is down ~11% in the week post-Q3 FY26 earnings (Apr 30) from a recent high near $1,035 [6][12]
- **Short interest (% of float):** ~1.07% [6]
- **Dividend yield:** ~0.74% (annual $7.20/share) [13]

## Moat — what it is physically made of
The PH moat has **two genuinely durable components and one over-marketed one**. Decomposed honestly:

**1. Aerospace systems integration (durable, ~35% of sales).** PH does not sell loose pumps and valves on the F-35; it designs, qualifies, and integrates entire fuel inerting, hydraulic, flight-control, fluid-conveyance, and thermal-management subsystems, with FAA/EASA airworthiness data packages accumulated over decades [14]. The Meggitt acquisition (closed 2022) layered in pneumatics, fire protection, wheels/brakes, and sensor systems already locked into A320neo, 787, F-35, and 100+ rotorcraft type certificates. Aftermarket runs at structurally higher margin (now driving 29.5% adjusted segment OM) because the OEM bid sets a 30-year annuity that no second-source can credibly re-qualify in under ~5–7 years per LRU. This is the real moat: certification cost + part-number lock-in + multi-decade install base. Backlog is a record $8.4B in Aerospace alone, up 14% in orders [4].

**2. Quick-coupling manufacturing scale & qualification (modest, exposed to standardization).** PH is one of the top-5 vendors of UQDs alongside **Stäubli (CH), Danfoss (DK), Colder Products/CPC (US, owned by Dover), and Gates (US)** — collectively ~63–73% global share of UQDs [15]. PH's UQD/UQDB product line is engineered to OCP's Universal Quick Disconnect Specification Rev 1.0 and the UQDB blind-mate spec, which are **open standards licensed under the permissive OCPHL** — meaning anyone can build interchangeable parts; there is no IP rent [16][17]. The moat is therefore (a) precision machining at scale on stainless/PPS bodies, (b) drip-free / blind-mate qualification with each hyperscaler and ODM (Foxconn, Wistron, Quanta, Inventec), and (c) being on NVIDIA's reference BOM for GB200/GB300 racks — PH was listed alongside CPC, Danfoss, and Stäubli as having "gained an early advantage with proven certifications" on GB200 [3]. GB300 introduced a new internal connector standard (NVUQD03) at a lower unit price ($40–50 vs. $70–80 on GB200), already compressing $/unit by ~40% in one generation [3]. That ASP trajectory bounds the moat economics.

**3. "Broad portfolio" / cross-sell synergy (mostly narrative).** Management routinely cites the breadth of motion/control technologies as a moat. In practice this looks more like a conglomerate scale advantage in distribution and procurement than a defensible technical moat. The $9.25B Filtration Group deal at ~13.4× EBITDA (incl. synergies) extends the same playbook — buying #1 niche industrial brands with aftermarket recurrence [10][18]. This is good capital allocation, not a technical moat.

**Net read:** the moat is aerospace certification (deep, decades to displace) plus quick-coupling manufacturing scale on an **open** standard (real but bounded). The "AI moat" framing some sellside notes use is wrong; nothing in PH's data-center exposure is proprietary — it's an oligopolist on a commodity-standardized fluid connector.

## AI buildout bottleneck map
- **Power generation & grid interconnect** — *the* binding constraint. Gas turbine lead times are ~5 years; GE Vernova has remaining slots only in '29–'30; major interconnect queues run 5–7 years (Columbus 84 months, Silicon Valley 72) [19][20]. **PH position:** indirect beneficiary (motion/control content into onsite generation skids, BESS, and switchgear), but not a primary supplier of turbines or transformers. Not the play.
- **Advanced packaging (TSMC CoWoS-L)** — gating Blackwell/Rubin volumes. **PH position:** indifferent / no exposure.
- **HBM3e/HBM4 yield** — gates training cluster throughput. **PH position:** indifferent.
- **Optical interconnect / co-packaged optics** — gates scale-out fabric. **PH position:** indifferent.
- **Liquid cooling at >100 kW/rack** — liquid-cooled AI server share is forecast 15% (2024) → 54% (2025) → 76% (2026) per Goldman [1]. GB200 NVL72 and GB300 NVL72 ship liquid-cooled by default. **PH position:** direct beneficiary in the QD/manifold/hose layer, but **not** in the higher-value CDU layer (where Vertiv has ~70% volume share on first-batch GB200 [21], Schneider/Motivair second after the $4.75B Ecolab-CoolIT deal) and not in cold plates (Cooler Master ~50%, AVC 30–40% on GB200 [21]). The UQD market itself is small in absolute terms — ~$0.39B in 2025 growing to ~$0.75B by 2030 at 14.3% CAGR [15]; data-center QDs specifically $506M (2024) → $1.4B (2031) [15]. Even a 25% share would be ~$300M/yr by 2030 — material but not transformative against a ~$21B base.
- **Electrical contractor / skilled labor** — binding. **PH position:** indifferent.
- **Kernel & compiler talent (CUDA, Triton, NCCL, TensorRT)** — binding for training/inference efficiency. **PH position:** indifferent.

**Summary:** PH benefits from the *liquid-cooling* bottleneck only, at the lowest-IP layer of the cooling stack. The fluid connector market is real but small relative to PH's $21B revenue base, and ASPs are trending **down** generation-over-generation (GB300 NVUQD03 unit pricing is ~40% below GB200 [3]) as the BOM commoditizes.

## Competitive teardown
- **Stäubli (private, Switzerland)** — closest peer in liquid cooling QDs. 30 years of liquid cooling, 10 in electronics cooling [22]. Co-defined OCP UQD/UQDB specs. Likely the largest QD vendor in absolute terms; competes on the same hyperscaler-qualified reference lists. **Parity axis:** technical specification, leak rate, MTBF; PH does not have a discernible technical lead. Differentiator: PH's broader portfolio (hoses, manifolds, filtration) lets it sell more BOM lines per rack.
- **Danfoss (private, Denmark) / Hansen Technologies subsidiary** — explicitly named alongside PH on GB200 [3]; co-developed Meta's LQC standard with CEJN [23]. Strong in Europe and on hyperscaler reference BOMs. **Parity axis:** at parity on specification. Differentiator: deeper hyperscaler relationships at Meta.
- **Colder Products Company / CPC (Dover Corp., DOV)** — Everis brand explicitly on NVIDIA's GB200 reference list [3]; arguably ahead of PH in mindshare among ODMs. Publicly tradable proxy for the *same* exposure inside a comparable conglomerate.
- **Gates Corporation (GTES)** — fluid power / hose specialist, smaller QD presence but cited in top-5 share group [15].
- **CEJN (private, Sweden)** — co-defined OCP LQC/UQDB/BMQC suite with Meta; strong in OCP-compliant blind-mate variants [23][24].
- **Vertiv (VRT), Schneider (with Motivair), Ecolab (post-CoolIT)** — *not* direct competitors of PH; they sit one layer up (CDU + rack-level thermal management). They are **customers** to whom PH may sell connectors and hoses. Their thermal-systems ASP per rack ($50–150k+ CDU vs. $40–50 per QD) is where the AI rent actually accrues; PH does not contest that layer.

**What would have to be true for a competitor to take PH share at the connector layer:** (a) hyperscaler/ODM consolidates BOM on a single approved vendor — Stäubli or CPC are the most likely incumbents to win that, (b) NVIDIA reference BOM tightens further on internal connectors (NVUQD03→04) and exclusivity-style supply, or (c) Chinese domestic suppliers (e.g., HansHow, Foxconn-owned shops) qualify into hyperscaler builds at materially lower price. None of these would tank PH's stock — connector revenue is small — but they would compress the optionality the market is pricing in.

## Bull case — technical
For the stock to outperform from $879, the following technical conditions need to hold simultaneously:

1. **Aerospace cycle holds for 3+ more years.** A320neo/737MAX build rates continue to recover (engine deliveries are the bottleneck, not airframes); 787 ramps to 10/month; commercial aftermarket remains in mid-teens organic growth as the post-COVID flight-hour catch-up extends. F-35 production stays at ≥150/yr; defense aftermarket benefits from sustained NATO and Indo-Pacific posture. Base rate on aerospace upcycles: typically 6–8 years from trough; we are roughly 4 years in. Believable but not guaranteed.
2. **Liquid cooling penetration tracks Goldman's 76% by 2026** and continues toward >90% for AI servers by 2028 [1]. PH's data-center exposure scales from ~1% to ~3–5% of sales by FY28, contributing roughly half a turn of incremental growth.
3. **Filtration Group closes in CY26 H2, synergies tracking.** Adds ~$2B revenue, ~$220M cost synergies, recurring-aftermarket-heavy mix; defends the consolidated margin profile against any industrial cyclical softening [10].
4. **Margin expansion continues** — adjusted segment OM moved from ~21% pre-Meggitt to 27.2% guide for FY26 [4]. The Win Strategy + decentralized P&L culture is the actual machine; if it sustains, FY28 EPS lands in $35–38 range, supporting a $1,100+ stock at 28–30× multiple.

**Connect to stock:** if all four hold, the math gets you to mid-teens annualized total return — fine but not spectacular. The aerospace pillar (1) does the heavy lifting; the AI/liquid-cooling pillar (2) is a marginal addition.

**Base rate caution:** in past industrial platform shifts (mainframe→x86, x86→cloud, ICE→EV), incumbent industrial component suppliers generally retained share but saw multiple compression as the *narrative* shifted on/off them. A 26× forward P/E on a 5–7% organic-grower with ~1% AI exposure embeds optionality that has historically not paid in this category.

## Bear case — technical
What a short-seller who understands the stack would say:

1. **The "AI exposure" is being multiplied through PH's multiple, but the underlying dollar exposure is small and on a commoditizing BOM line.** GB300 already shrunk QD unit prices by ~40% vs. GB200 [3]; further consolidation (NVIDIA-spec internal connectors, single-source ODM contracts, Chinese suppliers) compresses unit economics faster than rack-count growth offsets. The total *addressable* data-center QD pool is <$1.5B by 2031 [15]; PH could be 15–25% of that — i.e., ~$200–350M revenue, ~1–2% of total. The market is pricing >25× forward as if this is a 10%+ contributor.
2. **Aerospace cycle has a finite top.** Commercial OEM at 22% organic in Q3 [4] is unsustainable; pent-up engine-shop-visit demand normalizes by FY27/28. When that happens, the aerospace tailwind that drove the 38% rally in CY2025 reverses sentiment, and the multiple resets toward the 18–20× historical norm — a ~25% derate independent of AI.
3. **Industrial segment is already soft.** Industrial growth is guided at only 2.5% in FY26 [4]; if global PMIs roll over, Diversified Industrial (65% of sales) drops into low single digits or contracts. Conglomerate discount returns.
4. **Filtration Group is a $9.25B deal at 19.6× pre-synergy EBITDA** [18]. The premium is justified only if the synergies arrive on schedule; large industrial M&A integration risk is non-trivial (Meggitt took 3+ years to fully extract).
5. **Liquid cooling vendor consolidation is happening above PH.** Schneider bought Motivair; Ecolab bought CoolIT for $4.75B; Vertiv bought Strategic Thermal Labs [25][26]. As the thermal stack consolidates and CDU vendors begin to push toward integrated cooling-loop ownership (vertical extension downward into connectors and manifolds), PH's component sales become more procurement-driven and less spec-driven — pricing leverage moves to the CDU integrator.

**Stock outcome in bear:** $700–$750 (~20× on a normalized FY28 EPS of ~$36, derated for cycle).

## Market view check
At $879, ~26× forward EPS and ~6× EV/NTM revenue, PH trades at a meaningful premium to its 10-year average (~17–19×) and to industrial peers (EMR, ETN, ROK in the 22–25× range). Consensus PT of $997 implies the Street wants another ~13% — modest. The 11% post-earnings drop despite a *raise* on guidance [4][12] suggests the market is starting to question how much AI/data-center optionality is fairly embedded. The market appears to believe PH should be valued partly as an AI infrastructure name with industrial-conglomerate downside protection. The technical reality is closer to: ~99% industrial/aerospace compounder with ~1% AI sidecar growing fast off a tiny base. That gap is the mispricing — modestly to the downside, not catastrophically. This is not a short; it is a "fairly priced quality compounder where the AI optionality the multiple embeds is real but smaller than the framing suggests."

## 90-day falsifiers
- **FY26 Q4 print (mid-Aug 2026):** does Aerospace organic growth stay >12% with sequential backlog growth, or roll over? A deceleration to <8% would invalidate the bull case pillar #1.
- **Hyperscaler capex commentary** (META, MSFT, GOOGL, AMZN Q2 calls in late Jul / early Aug): aggregate FY26 capex guide change. If aggregate guidance is *cut* by >5% sequentially, liquid-cooling penetration timing slips and PH's growth optionality compresses.
- **Filtration Group regulatory clearance:** any antitrust second request from FTC/EC that extends close beyond CY26 Q4 forces a re-rate on near-term EPS accretion math.
- **NVIDIA GTC October 2026 (Rubin platform details):** if Rubin further consolidates the internal cooling-connector spec to a single-vendor reference (or PH is explicitly named/de-named), it directionally re-prices the data-center sidecar.
- **OCP Summit (Oct 2026):** new UQDB / blind-mate specifications and any move toward Chinese-vendor qualification by Meta or Microsoft would tighten the competitive-pressure scenario in the bear case.
- **Industrial PMI / Diversified Industrial orders cadence** in Q4 FY26 results: a deceleration in North America industrial orders below +3% YoY would surface conglomerate-cyclical risk before the aerospace cycle even tops.

## What I could not verify
- **Parker-specific dollar revenue inside data-center cooling.** Management says "~1% of sales" but no SKU-level disclosure; "$210M" is inference (1% × $21B guide).
- **Parker's share of the data-center UQD market specifically** vs. Stäubli, CPC, Danfoss. Only the collective top-5 share (63–73%) is sourced.
- **Whether PH is on the formally published NVIDIA HGX/GB300 Recommended Vendor List** as opposed to merely "early-advantage" sourcing on GB200 [3]. Boyd was explicitly listed as RVL-validated for GB200 NVL72 [27]; PH was not confirmed in equivalent language.
- **Exact 2025-12-31 close** for a clean YTD calculation; the stock is up massively over 12 months (~72% per one source [6]) but I could not nail the precise YTD figure.
- **52-week low discrepancy** ($538 vs. $637) between sources — likely an adjusted-vs-unadjusted or different timestamp issue, but unresolved.
- **PH's pro-forma net debt** post-Filtration Group close (will likely exceed $14B); the EV/NTM revenue figure is approximate.
- **Per-rack PH dollar content** on GB200 NVL72 — frequently estimated at "low thousands of dollars in QDs/hoses/manifolds" by sellside, but no primary disclosure exists.

## Sources
[1] https://www.lombardodier.com/insights/2026/january/ai-supercharges-the-race.html — 2026-05-10 — Goldman-cited liquid-cooling penetration trajectory (15% / 54% / 76%) for 2024–2026.
[2] https://www.parker.com/us/en/divisions/quick-coupling-division/industries/liquid-cooling-for-data-servers.html — 2026-05-10 — PH self-description of liquid-cooling product scope.
[3] https://pioneerthermal.com/nvidia-gb300-gpu-liquid-cooling-revolution/ — 2026-05-10 — GB200 vs. GB300 connector ASP ($70–80 → $40–50) and PH/CPC/Danfoss/Stäubli early-advantage status.
[4] https://www.fool.com/earnings/call-transcripts/2026/04/30/parker-hannifin-ph-q3-2026-earnings-transcript/ — 2026-05-10 — PH Q3 FY26 transcript: ~1% data-center sales, $8.4B aerospace backlog, FY26 guide raises, Filtration Group timing.
[5] https://www.investing.com/equities/parkerhannifin — 2026-05-10 — Price $878.83 (2026-05-08); market cap $124.23B.
[6] https://www.chartmill.com/stock/quote/PH/profile — 2026-05-10 — 52-week range, short interest ~1.07%, 1-yr return.
[7] https://www.gurufocus.com/term/forward-pe-ratio/PH — 2026-05-10 — Forward P/E 25.82.
[8] https://simplywall.st/stocks/us/capital-goods/nyse-ph/parker-hannifin/news/assessing-parker-hannifin-ph-valuation-after-upgraded-2026-e — 2026-05-10 — FY27 EPS consensus ~$32.50, fair value framework.
[9] https://investors.parker.com/news-events/press-releases/detail/506/parker-reports-fiscal-2026-third-quarter-results — 2026-05-10 — Q3 FY26 release; FY26 revenue guide $20.9–$21.3B.
[10] https://investors.parker.com/news-events/press-releases/detail/496/parker-to-acquire-filtration-group-corporation — 2026-05-10 — Filtration Group $9.25B / 13.4× synergized EBITDA, $2B revenue addition, $220M synergies.
[11] https://meyka.com/blog/ph-parker-hannifin-earnings-beat-q3-2026-results-exceed-expectations-0105/ — 2026-05-10 — Consensus 12-month PT $996.81.
[12] https://www.investing.com/news/transcripts/earnings-call-transcript-parkerhannifin-q3-2026-beats-expectations-stock-dips-93CH-4650757 — 2026-05-10 — Post-Q3 stock weakness despite beat.
[13] https://stockanalysis.com/stocks/ph/dividend/ — 2026-05-10 — Dividend $7.20 annual, yield ~0.74%.
[14] https://www.parker.com/us/en/markets/aerospace-and-defense.html — 2026-05-10 — Aerospace systems integration scope (F-35, fuel/inerting, flight-control).
[15] https://www.marketsandmarkets.com/ResearchInsight/uqd-coupling-companies.asp — 2026-05-10 — Top-5 UQD share (Stäubli/Danfoss/PH/CPC/Gates) 63–73%; market $0.39B→$0.75B 2025–2030.
[16] https://www.opencompute.org/documents/ocp-universal-quick-disconnect-uqd-specification-rev-1-0-2-pdf — 2026-05-10 — OCP UQD Specification Rev 1.0 governed by permissive OCPHL license.
[17] https://www.opencompute.org/documents/uqdb-spec-1-0-pdf — 2026-05-10 — OCP UQDB blind-mate specification, open-standard nature.
[18] https://madison.net/madison-industries-agrees-to-sell-filtration-group-to-parker-hannifin-for-9-25-billion-valuing-the-innovator-at-more-than-10-billion/ — 2026-05-10 — Filtration Group purchase multiple 19.6× pre-synergy EBITDA.
[19] https://newsletter.semianalysis.com/p/how-ai-labs-are-solving-the-power — 2026-05-10 — Gas-turbine lead times ~5 yrs; onsite-gas trend for AI labs.
[20] https://avanzaenergy.substack.com/p/data-centers-are-killing-the-grid — 2026-05-10 — Grid interconnect queues 36–84 months across major US markets.
[21] https://www.trendforce.com/presscenter/news/20250821-12682.html — 2026-05-10 — Vertiv ~70% CDU share on first GB200 batch; Cooler Master 50%+ cold-plate share.
[22] https://www.staubli.com/global/en/fluid-connectors/products/quick-and-dry-disconnect-couplings/thermal-management/uqd-universal-quick-disconnect.html — 2026-05-10 — Stäubli 30-yr liquid-cooling history, UQD/UQDB portfolio.
[23] https://www.cejn.com/en-us/products/thermal-control/uqd-couplings/ — 2026-05-10 — CEJN/Meta LQC co-development; OCP UQDB/BMQC variants.
[24] https://www.cpcworldwide.com/Liquid-Cooling/Computing/Data-Centers — 2026-05-10 — CPC Everis QDs for data-center DLC; Dover-owned competitor positioning.
[25] https://www.vertiv.com/en-us/about/news-and-events/corporate-news/2026/vertiv-strengthens-liquid-cooling-system-capability-with-acquisition-of-strategic-thermal-labs/ — 2026-05-10 — Vertiv acquires Strategic Thermal Labs (Apr 2026), thermal-chain consolidation.
[26] https://enkiai.com/ai-market-intelligence/data-center-liquid-cooling-companies/ — 2026-05-10 — Ecolab–CoolIT $4.75B; CDU vendor map.
[27] https://www.boydcorp.com/liquid-cooling/boyd-validated-for-nvidia-gb200-nvl72-recommended-vendor-list.html — 2026-05-10 — Boyd NVIDIA RVL validation language (used as comparator for PH's unverified RVL status).