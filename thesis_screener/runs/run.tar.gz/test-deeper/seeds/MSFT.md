# MSFT — Microsoft Corporation

## Where this sits in the AI stack
Microsoft is the only Western hyperscaler that touches every layer of the AI stack from the kilowatt to the SaaS seat: it operates ~1.2 GW+ of newly-online AI datacenter capacity (Fairwater Wisconsin and counterparts) cooled by closed-loop direct-to-chip systems [16]; it runs the largest deployed clusters of NVIDIA GB200/GB300 NVL72 (the first 4,608-GPU GB300 cluster was lit for OpenAI on Quantum-X800 InfiniBand) [13][20]; it has shipped first-party silicon (Cobalt 100/200 ARM CPUs, Maia 100, and the Maia 200 inference accelerator on TSMC N3 with 216 GB HBM3e) [4][14][17]; it sells the model layer (Azure OpenAI, Anthropic Claude, plus open-weights via Foundry) [10]; and it owns the dominant productivity-software distribution channel for AI inference (M365 Copilot at 20M paid seats, GitHub Copilot at ~4.7M paid devs) [11][15]. The training-vs-inference mix matters: MSFT is now optimizing for inference economics — Maia 200 is explicitly an inference part, not a training part [4].

## Snapshot
- **Price:** $415.10 (2026-05-09 close) [1]
- **Market cap:** ~$3.08T (≈7.42B shares × $415) [1][21]
- **52-week range:** $356.28 – $555.45 [21]
- **Forward P/E:** ~21.4× (FY consensus) [2]
- **EV / NTM revenue:** ~10× (rough; EV/EBITDA ~17×, EV/FCF ~43×) [2]
- **Consensus 12-month price target:** $569.46 (+37.2% from spot) [2]
- **YTD total return:** approximately −24% (worst Magnificent-7 performer in 2026) [22]
- **Short interest (% of float):** n/a — not disclosed in retrieved sources; historically <1% for MSFT and immaterial to the thesis

## Moat — what it is physically made of

The moat is a **stack of partially-correlated assets**, each of which would have to be replicated separately. Decomposed:

**1. Distribution moat (most durable, software).** M365 Copilot rides on top of 450M paid commercial M365 seats — a pre-existing identity, file-graph, and policy substrate (Entra ID, Purview, Defender, SharePoint Graph) that competitors cannot ship without rebuilding 25 years of enterprise integration [11]. 20M paid Copilot seats at ~$30/seat/mo implies a $7.2B run-rate that grew by 5M seats in a single quarter [11]. Accenture alone bought 740K seats; Bayer/J&J/Mercedes/Roche each have >90K [11]. Replacement cost: not measurable in dollars — measured in "incumbent enterprise IT vendor with a 25-year head start." This is the most durable component.

**2. GitHub developer-graph moat.** 4.7M paid GitHub Copilot subscribers, agentic mode generating ~1.2M PRs/month [15]. Important and under-discussed: GitHub Copilot's RL signal — accept/reject events on real production code from millions of devs — is a proprietary post-training dataset that nobody else has at scale. Cursor and Anysphere are building the IDE; only MSFT owns the code-host. Durable for as long as GitHub remains the default git remote (~5+ years of inertia).

**3. OpenAI capital-claim and IP license.** Post-October 2025 restructuring, MSFT owns 26.79% of OpenAI Group PBC (worth ~$228B at the March 2026 $852B mark — a 17.6× ROIC on the original $13B) [5]. Crucially, the IP license to OpenAI models is non-exclusive but valid through 2032; OpenAI still pays MSFT a 20% revenue share through 2030 (capped) [5]. The April 2026 amendment removed Microsoft's revenue-share payment **to** OpenAI for Azure-served customers and let OpenAI sell on AWS/GCP/Oracle — this *eroded* the moat from "exclusive cloud" to "preferred + economic-interest holder." Important to be honest: this is materially weaker than 12 months ago.

**4. Capacity-as-moat.** $190B of CY26 capex (vs. $154.6B consensus going in), ~1 GW added in Q3 FY26 alone, datacenter footprint set to double over two years [3][8]. Constellation's 837 MW Three Mile Island restart PPA (20-year) is a quasi-moat — there are perhaps a half-dozen restartable nuclear sites in the U.S. and MSFT got to one of the best ones first [9]. SMR/microreactor program manager hire signals the next leg [9]. Power is the binding constraint of the cycle (see next section); locked-in baseload at fixed price is a structural cost advantage.

**5. Custom silicon (early but real).** Maia 200 on TSMC N3 with 216 GB HBM3e at 7 TB/s, 272 MB on-chip SRAM, ~140B transistors, claims 10 PFLOPS FP4 / 5 PFLOPS FP8 — ~3× FP4 of AWS Trainium 3 and FP8 above Google TPU v7 Ironwood per Microsoft's own benchmarks [4][12]. The "30% cheaper than any other AI silicon" claim from EVP Scott Guthrie is not yet third-party verified, and MLPerf submissions are absent — treat as **inference, not fact**, until validated. The Maia SDK ships with Triton-based compiler, PyTorch integration, and a low-level Maia language [4]. **Honest assessment:** this is meaningful but two generations behind Google's TPU maturity (TPU v1 was 2015; Maia 100 was 2024). The moat depth here is ~3-5 years, not 10.

**6. NCCL/CUDA dependency is a moat MSFT *rents from NVIDIA*.** The 4,608-GPU GB300 NVL72 cluster uses NVLink (130 TB/s intra-rack) and Quantum-X800 InfiniBand inter-rack [20]. None of the collective-comm primitives, NCCL all-reduce paths, or NVSwitch topology design are MSFT's. This is the part of the stack where MSFT is **a customer, not a moat-holder** — and it's the part most exposed to NVIDIA capturing more of the value chain.

## AI buildout bottleneck map

The 24-month gating constraints, with MSFT's position on each:

| Constraint | 2026 status | MSFT position |
|---|---|---|
| **CoWoS-L advanced packaging** | NVIDIA booked ~60% (~595K wafers); AMD 11%; rest fought over by hyperscalers [6]. TSMC scaling 35K → 130K wpm by EoY 2026 [6] | **Exposed customer.** Maia 200 needs CoWoS slot. MSFT is not in NVIDIA's 60% — it competes with AMZN/GOOG for Broadcom-fab'd ASIC slots |
| **HBM3e/HBM4** | Sold out through 2026; Samsung/SK Hynix raised prices ~20%; SK Hynix 50–55% share [7] | **Exposed.** Direct cause of the $25B capex add to $190B [3]. Negotiating leverage limited because demand inelastic |
| **Power generation + grid interconnect** | Gas turbine lead times multi-year; new transmission queues 4–7 yrs [9] | **Beneficiary.** 837 MW Constellation PPA, SMR program, multi-year nuclear posture is best-in-class. Weakness: still gas-bridged in Texas/Iowa |
| **Liquid cooling at >100 kW/rack** | GB300 NVL72 racks ~120 kW; Maia "Sidekick" was first direct-to-chip retrofit | **Self-supplied.** Fairwater is "world's most powerful AI datacenter" by claim; 90%+ closed-loop liquid [16] |
| **Optical interconnect** | Co-packaged optics ramping 2026–27 | Indifferent / customer of NVIDIA Quantum-X800 [20] |
| **Compiler / kernel talent** | <2,000 globally fluent in CUDA + Triton + collective comms | **Constraint owner / employer.** MSFT pays top of market; recently consolidated under "Superintelligence team" [4] |
| **Frontier training data** | Effectively exhausted high-quality public web corpus | Indirect — flows through OpenAI/Anthropic, which MSFT funds and hosts |

The single most important fact: **Microsoft itself said it remains supply-constrained through at least the end of CY26** [3]. Demand is not the bottleneck.

## Competitive teardown

**Versus AWS (the strongest direct competitor).** AWS Q1 CY26: revenue $37.6B (+28% — fastest in 15 quarters), backlog $364B ex-Anthropic / $464B inc. [18]. Trainium2 ~30% better $/perf vs comparable GPUs; Trainium3 +30–40% over Tn2; Trainium revenue commitments >$225B [18]. Anthropic anchor on Trainium is structurally important — it gives AWS a compiler-co-design partner the way OpenAI gives MSFT one. **On the technical axis that matters:** AWS leads on custom-silicon-for-training maturity (Tn3 is in production; Maia 200 is inference-only); MSFT leads on inference economics claim and on enterprise software distribution. Azure grew 40% vs AWS 28% — but Azure includes the OpenAI revenue commitment that has just been restructured downward; ex-OpenAI, MSFT RPO grew ~26%, **roughly in line with AWS** [8]. The growth-rate gap is narrower than it looks.

**Versus Google Cloud.** GCP Q1 CY26: revenue $20B (+63%), backlog $462B (~doubled QoQ) [19]. Google ships TPU v7 Ironwood (4.6 PFLOPS FP8/chip, 192 GB HBM3e) and is selling TPU pods to a "select group of customers" — first time TPUs have left Google's walls [19]. **Technical reality:** TPU is the most mature non-NVIDIA training silicon on the planet (10+ years of compiler work — XLA, MLIR, Pathways). If Anthropic or Apple continues to pull workloads onto TPU, MSFT loses the ability to claim "AI revenue share = cloud share." GCP's $185B 2026 capex is approaching MSFT's $190B — they are not capital-constrained relative to MSFT.

**Versus Oracle.** OCI is the **specific technical threat to the OpenAI-on-Azure thesis.** Oracle FY26 capex ~$50B; RPO surged to $523B (+438% YoY); $300B contracted with OpenAI for 4.5 GW; first Stargate buildings live in Abilene with NVIDIA GB200 racks already training [3 (Stargate sources)]. Oracle is structurally cheaper on power (West Texas wind, gas) and on land. The April 2026 OpenAI restructuring is exactly what unlocked this — OpenAI is shifting *training* to Stargate while keeping inference distributed across Azure/AWS/GCP/Oracle. **MSFT's loss is not "OpenAI leaves" — it's "OpenAI's incremental compute spend goes elsewhere."**

**Versus NVIDIA itself.** NVIDIA increasingly captures the "rack as a product" layer (GB300 NVL72 ships as a complete liquid-cooled system). MSFT's role in the OpenAI training cluster is reduced to landlord + integrator + power-procurer. As a fraction of the AI dollar, the GPU vendor's share is rising, not falling.

## Bull case — technical

For MSFT to outperform from $415, the following technical conditions need to hold:

1. **Inference (not training) becomes the dominant compute workload by 2027**, and Maia 200's 30% TCO advantage becomes verifiable in production. Inference scales with users; training scales with frontier-model count. MSFT's bet is that user-bound inference workloads dwarf the dozen-or-so frontier training runs that go to Stargate.
2. **M365 Copilot penetration crosses ~10% of the 450M base** (currently 4.4%). This is the single highest-leverage variable in the bull case — every 1% of the base = ~4.5M seats × ~$360/yr = $1.6B incremental high-margin software ARR.
3. **The OpenAI 26.79% stake compounds.** At a March 2026 mark of $228B, this is already worth ~7.4% of MSFT's market cap, off the balance sheet. If OpenAI IPOs at >$1.5T (consensus path), MSFT's stake is worth ~$400B+ — and it's pure equity, not capex-hungry.
4. **Capex per dollar of incremental Azure revenue stops rising.** This is the one the market is most worried about (the YTD drawdown is essentially this anxiety priced in).

**Base rate on technology displacement at this stage of a platform shift:** In the last three platform shifts (mainframe→client/server, on-prem→cloud, mobile→cloud-mobile), the dominant incumbent of the *prior* cycle either failed to lead the next (IBM, HPE) or repositioned with massive capex and ~5 years of margin compression but kept share (Microsoft itself, in the Azure pivot). MSFT's current profile — heavy capex, margin compression, dominant distribution preserved — historically corresponds to a **~70% probability of keeping share** in the new cycle. Modal outcome: stock re-rates higher once capex/revenue ratio peaks and reverses (typically 2–3 years into the build).

If those conditions hold, the multiple compresses less than feared, FY28 EPS comes in around $18–20, and ~25× of that is $450–500. The consensus $569 PT requires either multiple expansion or further EPS upside beyond that — possible if Copilot inflects, but not the base case.

## Bear case — technical

Written by someone who actually understands the stack:

1. **Capex efficiency is deteriorating in a way the moat doesn't fix.** $190B of CY26 capex against ~$37B AI run-rate revenue is a >5× capex-to-AI-revenue ratio. Even amortizing GPUs over 5 years, the depreciation alone (~$38B/yr at run-rate) eats most of the AI revenue. The bear thesis isn't "AI demand falls"; it's "AI demand is real but the unit economics for the *cloud landlord* are bad because the GPU vendor captures the margin."
2. **The OpenAI restructuring is the leak in the dam.** OpenAI on AWS + GCP + Oracle was unthinkable in early 2025; it's contractual fact in April 2026 [5]. Once a frontier lab is multi-cloud, the lock-in to any single cloud is asymptotically zero. The IP license through 2032 protects *Azure offering OpenAI models*, not *OpenAI training spend going to Azure*.
3. **Maia is two generations behind TPU and one behind Trainium on training.** A genuinely competitive Maia training part is at least 2 chip generations away (~2028+). In the meantime, MSFT pays NVIDIA's gross margin on every training GPU. AWS has Trn3 in customers' hands today; Google has TPU v7 in third-party hands today [12][19]. This is a **structural margin disadvantage for the next 24 months**.
4. **Copilot at 4.4% penetration after >2 years is a concerning curve, not a victory lap.** The Directions on Microsoft data shows the headline number masks slow conversion of "trial → standardized rollout" [11]. If the slope flattens — and there is some sell-side data suggesting it may — then the $7.2B becomes $12-15B not $30B+, which doesn't justify $190B of capex.
5. **Anthropic's $30B Azure commit is a multi-year contract priced before the AWS/Anthropic vertical integration deepened.** Anthropic's primary training partner is AWS; the Azure deal looks more like a hedge/reseller agreement than a strategic anchor. If Anthropic compresses Azure spend toward the floor of the contract, MSFT's "frontier model count" advantage shrinks.

A short-seller who could check these would be looking for: (a) Q1 FY27 capex guide flat-to-down; (b) Azure ex-OpenAI growth re-decelerating below 22%; (c) Maia 200 production volume disclosure that comes in below 50K units; (d) any Copilot net-seat-add deceleration.

## Market view check

At $415 / 21.4× forward, MSFT is trading at the cheapest forward multiple in three years and ~24% below YTD start [22][2]. Consensus PT of $569 implies the Street believes the capex digestion is temporary and the AI revenue-to-capex ratio inflects in late FY27. That's a defensible view but it's **the same view sell-side held in January 2026 when the stock was $545** — the multiple compression has been real and reflects genuine technical concerns (OpenAI restructuring, capex efficiency, Maia-behind-TPU), not just "AI fatigue." The market is pricing a probability somewhere between the bull and bear cases above; my read is that the market is roughly fairly valuing the *cloud landlord* business but **probably under-valuing the OpenAI equity stake** ($228B mark, off-balance-sheet, with optional liquidity at IPO) and **roughly fairly valuing Copilot** (because penetration is genuinely ambiguous). Net: directionally undervalued, but not screaming-cheap; the asymmetric leg is the OpenAI stake, which is uncorrelated with the Azure capex anxiety.

## 90-day falsifiers

Specific, datable events in the next 90 days that would update the thesis:

1. **Microsoft FY26 Q4 print (late July 2026, ~Aug 1):** Azure constant-currency growth — bull confirmation requires ≥38%; bear confirmation if <34%. Watch ex-OpenAI RPO growth specifically — bull >28%, bear <22%.
2. **FY27 capex commentary on that same call:** any signal of YoY deceleration of capex growth from the FY26 +61% rate. Capex growth re-accelerating = market rejects the bull thesis on margin recovery.
3. **OpenAI Q2 model release and where it trains:** if the next frontier model trains substantially on Stargate-Abilene rather than Azure, that's empirical confirmation of the bear migration thesis.
4. **Maia 200 second-region deployment (Phoenix US-West-3):** confirmed timeline slippage past Q3 CY26 = bearish for Maia ramp.
5. **AWS Q2 print (late July):** if AWS prints another acceleration to 30%+ while Azure ex-OpenAI decelerates, the "Azure is winning AI" narrative breaks.
6. **HBM4 ramp at SK Hynix:** any miss vs. Q3 ramp targets propagates to Maia 200/GB300 supply through Q1 CY27.
7. **GitHub Copilot usage-based billing transition (June 1, 2026):** observable revenue ramp signal in Q1 FY27 print — if accept/reject economics force MSFT to absorb more inference cost than expected, GitHub gross margin compresses.
8. **OpenAI IPO filing or further valuation marks:** a $1T+ secondary print would lift MSFT's stake mark by ~$40B.

## What I could not verify

- **Maia 200's "30% cheaper" claim has no third-party benchmark.** All performance numbers are Microsoft-disclosed. No MLPerf submission visible. Treat as marketing until validated.
- **Maia 200 production volume.** Microsoft has not disclosed unit volumes; reasonable estimates from the CoWoS-L allocation suggest <50K units in 2026 — small relative to the >500K Blackwell GPUs MSFT is deploying.
- **Exact OpenAI revenue contribution to Azure.** The 26% ex-OpenAI RPO growth implies OpenAI is a meaningful fraction of the headline 99% RPO growth, but the precise dollar number is unstated.
- **Short interest as % of float.** Multiple sources have it but none returned a specific 2026 number; historically immaterial (<1%).
- **Net of inter-company commitments, how much of Anthropic's $30B Azure spend is incremental versus a re-routing of existing Azure AI workloads.**
- **Microsoft's CoWoS-L wafer allocation.** Industry estimates exist but Microsoft does not disclose; I infer it sits in the AMD+ASIC bucket competing for the ~40% of supply NVIDIA does not consume.
- **Whether Microsoft has a roadmap Maia training part.** Strongly hinted but not announced; the Maia 200 positioning as "for inference" is conspicuous.

## Sources
[1] https://watcher.guru/news/microsoft-stock-msft-in-may-2026-profit-loss-or-stagnation — retrieved 2026-05-10 — May 9, 2026 MSFT close ~$415.10
[2] https://www.gurufocus.com/term/forward-pe-ratio/MSFT — retrieved 2026-05-10 — Forward P/E 21.4×; consensus PT $569.46
[3] https://www.cnbc.com/2026/04/29/microsoft-msft-q3-earnings-report-2026.html — retrieved 2026-05-10 — $190B CY26 capex including $25B from memory pricing
[4] https://blogs.microsoft.com/blog/2026/01/26/maia-200-the-ai-accelerator-built-for-inference/ — retrieved 2026-05-10 — Maia 200 TSMC N3, 216GB HBM3e, "30% cheaper" claim
[5] https://www.cnbc.com/2026/04/27/openai-microsoft-partnership-revenue-cap.html — retrieved 2026-05-10 — Apr 2026 restructuring, 26.79% stake, $228B mark, IP license to 2032
[6] https://www.digitimes.com/news/a20251210PD218/tsmc-cowos-capacity-nvidia-equipment.html — retrieved 2026-05-10 — NVIDIA ~60% of CoWoS-L; AMD 11%; TSMC scaling 35K→130K wpm
[7] https://www.trendforce.com/news/2025/12/24/news-samsung-sk-hynix-reportedly-plan-20-hbm3e-price-hike-for-2026-as-nvidia-h200-asic-demand-rises/ — retrieved 2026-05-10 — HBM3e +20% pricing for 2026; supply sold out
[8] https://news.alphastreet.com/microsoft-msft-q3-fy2026-azure-hits-40-growth-as-ai-business-reaches-37-billion-run-rate/ — retrieved 2026-05-10 — Azure +40% cc; AI run-rate $37B; RPO $627B; ex-OpenAI RPO +26%
[9] https://enkiai.com/nuclear/microsoft-constellation-ai-data-centers/ — retrieved 2026-05-10 — Constellation 837 MW PPA; SMR program-manager hire
[10] https://blogs.microsoft.com/blog/2025/11/18/microsoft-nvidia-and-anthropic-announce-strategic-partnerships/ — retrieved 2026-05-10 — Anthropic $30B Azure commit; MSFT invests up to $5B in Anthropic
[11] https://windowsnews.ai/article/microsoft-365-copilot-hits-20m-paid-seats-enterprise-ai-adoption-governance-roi.415952 — retrieved 2026-05-10 — 20M paid M365 Copilot seats; Accenture 740K; 60% of F500 with ≥10K seats
[12] https://winbuzzer.com/2026/01/27/microsoft-maia-200-ai-chip-amazon-google-performance-xcxwbn/ — retrieved 2026-05-10 — Maia 200 vs Trainium 3 / TPU v7 performance comparison
[13] https://azure.microsoft.com/en-us/blog/microsoft-azure-delivers-the-first-large-scale-cluster-with-nvidia-gb300-nvl72-for-openai-workloads/ — retrieved 2026-05-10 — 4,608 GB300 NVL72 cluster for OpenAI on Azure
[14] https://learn.microsoft.com/en-us/azure/virtual-machines/sizes/cobalt-overview — retrieved 2026-05-10 — Cobalt 100 GA in 32 regions; Cobalt 200 announced
[15] https://www.getpanto.ai/blog/github-copilot-statistics — retrieved 2026-05-10 — 4.7M GitHub Copilot paid devs; agentic mode 1.2M PRs/mo
[16] https://blogs.microsoft.com/blog/2025/09/18/inside-the-worlds-most-powerful-ai-datacenter/ — retrieved 2026-05-10 — Fairwater Wisconsin, 315 acres, closed-loop liquid cooling
[17] https://www.datacenterfrontier.com/machine-learning/article/33015123/microsoft-unveils-custom-designed-data-center-ai-chips-racks-and-liquid-cooling — retrieved 2026-05-10 — Maia "Sidekick" first DC liquid-cooling retrofit
[18] https://www.fool.com/earnings/call-transcripts/2026/04/29/amazon-amzn-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — AWS Q1 CY26 $37.6B / +28%; backlog $364B ex-Anthropic; Trainium commitments >$225B
[19] https://finance.biggo.com/news/US_GOOGL_2026-04-29 — retrieved 2026-05-10 — GCP Q1 CY26 $20B +63%; backlog $462B; capex $180–190B
[20] https://blogs.nvidia.com/blog/microsoft-azure-worlds-first-gb300-nvl72-supercomputing-cluster-openai/ — retrieved 2026-05-10 — NVLink 130 TB/s intra-rack; Quantum-X800 InfiniBand inter-rack
[21] https://stockanalysis.com/stocks/msft/statistics/ — retrieved 2026-05-10 — Market cap and 52-week range
[22] https://247wallst.com/investing/2026/05/07/tens-of-thousands-of-tech-workers-are-being-laid-off-in-2026/ — retrieved 2026-05-10 — MSFT −23.4% YTD, −31.7% from ATH; worst Magnificent-7