# MA — Mastercard Incorporated

## Where this sits in the AI stack
Mastercard is not an AI infrastructure company — it is an application-layer AI integrator sitting on top of a private global authorization/clearing/settlement network (Banknet). It physically operates ~60 data centers (mostly colocated) connected by 100G MPLS backbones running ISO 8583 messaging, plus ~3,700 edge nodes that processed >10B transactions in December 2020 alone [1]. The actual "AI" workload it runs is real-time fraud inference (Decision Intelligence Pro), a transformer/RNN ensemble scoring ~160B annual transactions in <50ms and sustaining 70,000 TPS at peak — running on hybrid AWS/Azure compute, not their own silicon [2][1]. So when comparing this name to NVDA/AMD/AVGO, the right framing is: MA is a real-time inference application company whose competitive position depends almost entirely on network economics and regulatory positioning, with AI as a margin and retention defense rather than the moat.

## Snapshot

- **Price:** $497.99 (2026-05-10 intraday; $495.48 2026-05-09 close) [3]
- **Market cap:** ~$441–470B (range across sources, midpoint ~$455B) [3]
- **52-week range:** $480.50 – $601.77 [3]
- **Forward P/E:** ~26× on FY26 consensus EPS ~$20.25 (range $19.05–$20.93) [4]
- **EV / NTM revenue:** ~13.0× (EV $457.7B [5] / FY26 implied revenue ~$35.2B from low-teens growth on FY25 base [6])
- **Consensus 12-month price target:** ~$648–665 (53-analyst median $665; implied +31–34% vs. spot) [4]
- **YTD total return:** –11.6% [7]
- **Short interest (% of float):** 0.73% (~6.49M shares) [8]

## Moat — what it is physically made of
Decompose into five components and assess each separately.

**1. Two-sided network (the actual moat).** ~3.5B+ cards issued through thousands of issuer banks, accepted at >150M merchant locations. Adding either side raises the value of the other; switching costs are paid by both. This is structural, not technical. The base rate for displacement of a globally-scaled two-sided payment network is extremely slow — Diners Club to Visa took 30+ years, and even Pix in Brazil (a sovereign-mandated, central-bank-operated rail that runs on the same domestic banks) needed 4 years to overtake cards in e-commerce share by transaction count [9]. Durability: high, but eroding at the geographic edges.

**2. Banknet (authorization plumbing).** 60 data centers, MPLS backbone, ISO 8583, sub-100ms authorization end-to-end including issuer hop [1]. This is replicable engineering — stablecoin rails on L2s can in principle finalize in seconds at <1bp — but the regulatory, settlement-finality, and chargeback/dispute layer wrapped around it is not easily replicated. Durability: medium. Banknet is a commodity in isolation; the surrounding rulebook is not.

**3. Decision Intelligence Pro (the AI piece).** In-house RNN/transformer ensemble + graph ML scoring 160B/yr tx in <50ms, 70k TPS peak, reportedly delivering up to 300% improvement in fraud detection and 2× faster compromised-card identification vs. prior models [2][10]. The defensible asset is *the training data*, not the architecture — Mastercard owns one of the largest labeled fraud datasets in the world, and the RNN graph approach is well-aligned to relational transaction structure. A competitor could replicate the architecture in a few quarters; reproducing the labeled data substrate would take 5+ years of run-rate volume, which is why Visa, Stripe, and Adyen each train on their own walled gardens. Durability: high for as long as MA retains transaction volume; collapses if A2A/stablecoin substitution pulls volume off the network.

**4. Token vault and tokenization standards.** MA's token vault (Mastercard Digital Enablement Service) and the new Agentic Tokens (Agent Pay, launched April 2025; first live agentic transaction September 29, 2025) bind a tokenized credential to a specific AI agent with scoped permissions, valid for a specific merchant/window [11][12]. This is genuinely a new primitive — the question is whether MA's standard or Visa Intelligent Commerce or a neutral standard (think a "payments OIDC") wins. Durability: contested.

**5. Regulatory and settlement licensing.** PCI-DSS compliance posture, settlement bank relationships, BIN ownership, AML/KYC infrastructure across ~210 jurisdictions. This is a real moat against Stripe-Bridge or BVNK-style entrants — but explicitly *not* against Visa, and the GENIUS Act (July 2025) created a "Permitted Payment Stablecoin Issuer" framework that lets non-bank entities issue dollar-pegged stablecoins, eroding the licensing perimeter [13]. Durability: medium and declining.

Honest summary: the moat is ~70% network economics and regulatory inertia, ~20% data (for AI fraud), ~10% software/standards (tokenization). The CUDA-equivalent here is the issuer relationship rulebook, not a piece of code.

## AI buildout bottleneck map
This section largely doesn't apply — MA is not in the AI infrastructure supply chain. It is *indifferent* to CoWoS-L allocation, HBM3e supply, GB300 lead times, or 800G optics. Its AI compute footprint is small enough to run on hybrid AWS/Azure [1] and its inference workload (Decision Intelligence) is bursty but bounded by transaction volume, not by frontier-scale training. The relevant bottlenecks for MA are different:

- **Cross-border travel volume** (gating Q2–Q3 revenue acceleration): geopolitical/Iran exposure dragged April cross-border to +9% from Q1's +13%, with travel specifically dropping from +8% to +2% [14]. **Exposed customer** of the macro environment.
- **Stablecoin payment infrastructure** (CoWoS-equivalent for the post-card era): MA is acquiring rather than building, paying $1.8B for BVNK to secure licensed multi-jurisdiction stablecoin rails with $30B annualized volume [15]. **Beneficiary if integration succeeds; constraint owner of fiat ↔ on-chain bridges if BVNK becomes the standard.**
- **AI fraud model arms race**: every issuer, processor, and merchant is independently spending on AI fraud; MA's edge depends on data network effects holding. **Supplier of fraud-as-a-service through Decision Intelligence Pro and the Risk Decisioning Platform.**
- **Real-time payments infrastructure (FedNow, RTP, Pix interlinkages)**: FedNow has ~1,500 institutions/40% of DDAs as of late 2025 [16]; RTP volume hit ~1M tx/day, ~$500B/month. **Exposed.**

## Competitive teardown
Specifically by technical axis:

- **Visa (V):** parity competitor on virtually every axis. Slightly larger global GDV, slightly more cross-border exposure (which has been a Q1 headwind), comparable AI fraud stack (Visa Protect / Risk Manager Pro), parallel agentic strategy (Visa Intelligent Commerce vs. Agent Pay) [11]. No meaningful share takes are visible in either direction. They will both win or both lose against external substitutes.
- **Stablecoin rails (USDC/PYUSD/Tether, increasingly delivered via Stripe-Bridge):** the substantive bear. Visa now settles in USDC at a $4.6B annualized run rate across 130+ programs in 50+ countries [17]; Chainalysis put 2025 adjusted stablecoin volume at $28T [17]. On a *transaction cost* axis, an L2 USDC transfer is sub-cent vs. ~150–250bps of interchange. What stablecoins *don't* yet have: dispute resolution, chargeback, universal merchant acceptance, fraud guarantees. MA is responding via BVNK acquisition (close late 2026) — explicitly buying the bridge rather than building it [15]. **Take-share timeline: 2028–2032 for material P&L impact at current S-curve.**
- **Account-to-account (A2A): UPI, Pix, FedNow, RTP, SEPA Instant.** Pix overtook cards in Brazil e-commerce in 2025 (42% vs. 41%) and is projected to reach 50% by 2028 [18]. India credit card e-commerce share fell from 43% (2018) to 21% (2024) [9]. These rails bypass MA entirely. The mitigant: cross-border is the *highest-margin* business (cross-border assessments grew 18% on 13% volume in Q1 2026 — explicit pricing power [19]), and domestic A2A doesn't address cross-border friction yet. Pix–EU and UPI–Singapore interlinkages are the events to watch.
- **Stripe / Adyen / PayPal:** processor layer, not network layer; technically customers, but Stripe's Bridge stack and Adyen's direct schemes could disintermediate parts of MA's stack for large merchants. PayPal integrated Mastercard Agent Pay simultaneously with ChatGPT and Perplexity [12] — they're hedging rather than competing.
- **CBDCs:** structurally threatening in 10+ year horizon, not 24-month relevant in jurisdictions that matter to MA's P&L.

The most honest read: MA has parity-to-slight-advantage on the AI fraud axis, parity on Banknet, *behind* on stablecoin infrastructure until BVNK closes, and structurally exposed on A2A in fast-growing EM. Visa is in the same boat by a few percentage points.

## Bull case — technical
For the stock to outperform from here, the technical conditions are:
1. Cross-border travel rebases by Q3 2026 — i.e., the April softness was geopolitical (Iran/tariff) and not a structural step-down. April +9% vs. Q1 +13% is consistent with a one-off, but Q2 print will tell [14].
2. BVNK closes on schedule (late 2026) and stablecoin settlement becomes a *layer beneath the card brand* rather than a substitute — i.e., the "Mastercard-branded stablecoin transaction" wins economically over a raw USDC checkout button. Visa's $4.6B USDC settlement run-rate is encouraging proof-of-concept [17].
3. Agent Pay tokens become a de facto standard for agentic commerce authentication, capturing economics on the 20%+ of e-commerce projected to be AI-agent-mediated [12].
4. The $200B interchange settlement is approved as proposed (10bps cut for 5 years, 1.25% cap on standard consumer for 8 years) — bearish-sounding, but it *resolves* a >20-year overhang and forecloses worse outcomes [20].
5. AI fraud detection economics (DI Pro) generate enough VAS revenue growth (+22% in Q1 [21]) that MA's revenue mix tilts away from pure interchange-linked toward stickier B2B SaaS-like services.

Base rate caveat: payment-network displacement at frontier scale has historically taken 20+ years end-to-end. Pix in Brazil shows it can be 4–6 years in a single market with sovereign backing, but global multi-jurisdictional displacement has no precedent at <10 years. Bull case is plausible.

Financial outcome: at 26× $22+ FY27 EPS = $570-ish in 12 months, ~+15% plus ~0.5% dividend. To hit consensus $650+ requires multiple re-rate to 30×, which needs AI/agentic narrative to take hold *and* cross-border to reaccelerate.

## Bear case — technical
The version a stack-literate short would write:
1. **The settlement layer detaches from the brand.** Stripe/Bridge, Shopify, and large merchants embed USDC checkout that settles in seconds at single-digit-bps. MA's 150–250bps interchange becomes uncompetitive for non-credit transactions. The BVNK acquisition turns out to be a 2017-NVDA-buying-Mellanox moment of insight *or* a 2008-MSFT-buying-aQuantive write-down — the optionality is real, but at $1.8B for $30B in annualized volume (=6% multiple of volume), MA is paying a 2× premium because it could not build in time [15]. 
2. **A2A interlinkages eat cross-border.** Pix→Europe, UPI→Singapore/UAE, FedNow→SEPA Instant. If even 10% of the $9T cross-border flow shifts to bank-to-bank rails over 5 years, MA loses ~$1-2B of high-margin revenue. The 18% cross-border assessment growth on 13% volume in Q1 [19] is exactly what you'd expect from pricing into shrinking volume share — defensible in 2026, broken by 2029.
3. **Decision Intelligence loses data-network-effect as volume routes around the network.** If the actual fraud-relevant transaction signal moves to stablecoin rails (where MA sees nothing) or A2A (where MA sees nothing), DI Pro's training data becomes stale relative to chain-native fraud detection (Chainalysis, TRM, Elliptic) on the on-chain side and bank-consortium models on the A2A side.
4. **Interchange settlement triggers further regulatory action.** The proposed -10bps + 1.25% cap is the floor, not the ceiling. The DOJ Visa case sets precedent for follow-on MA action [20]. EU and UK have parallel investigations.
5. **Agentic commerce defaults to ACH or stablecoin, not card tokenization.** AI agents are *price-sensitive* in a way humans aren't — if an agent can choose to pay with USDC for 0bps or a card token for 200bps, it will choose the former by default unless explicitly constrained. Agent Pay tokens may end up niche.

Financial outcome under this case: revenue growth decelerates to mid-single digits by 2028, op margins compress 300–400bps as VAS investment fails to offset interchange/volume compression, multiple compresses to 18–20× on lower EPS = $360–$420 range.

## Market view check
Forward P/E ~26× on ~$20.25 EPS, EV/EBITDA 22.7× (~19% below 10-year median of 27.9×) [22], down 11.6% YTD against a roughly flat S&P [7]. Sell-side is uniformly bullish (35 Buy, 3 Hold, 0 Sell, median PT +33%) [4] — which by itself tells you nothing because analyst targets lag, but the spread between consensus and price suggests the market is pricing some structural risk the sell-side has not internalized. The most plausible read: the market is underwriting some combination of (a) cross-border deceleration as structural rather than geopolitical, (b) early-stage stablecoin/A2A disruption, and (c) interchange settlement overhang. At 26×, the stock is *cheap-ish* if the moat is durable for 10+ years and *correctly priced or expensive* if substitution accelerates inside 5. Given the network-displacement base rate, my read is the market has overshot mildly to the downside on cyclical (cross-border) factors and is approximately correctly pricing the structural ones. Reward-to-risk skewed positive at these levels, but the upside is no longer "compounder at any price" — it's "show me Q2 cross-border."

## 90-day falsifiers
- **Q2 2026 earnings (late July 2026):** May/June cross-border volume trajectory. If May cross-border travel stays at April's +2% YoY or worse, the geopolitical-blip thesis is broken and a structural deceleration is in play. Watch the cross-border assessment vs. volume spread — if pricing power compresses below 4pp, that's a tell.
- **Interchange settlement court ruling:** federal judge expected to rule on the $200B proposed settlement in 2026 [20]. Rejection would be a multi-quarter overhang; acceptance is a clearing event.
- **BVNK regulatory approvals progress** (close targeted late 2026) [15]: any delay signals integration risk and erodes the stablecoin-defense thesis.
- **Visa Q2/Q3 results (read-through):** if Visa shows substantially better cross-border, that's idiosyncratic MA weakness; if matching, it's macro.
- **GENIUS Act PPSI license issuances:** count and identity of approved stablecoin issuers in the next 90 days; large bank PPSIs (e.g., JPM, BofA stablecoins) would be the most credible structural threat to interchange.
- **Pix or UPI cross-border interlinkage announcements** (BIS Project Nexus, Pix–SEPA, UPI–GCC corridors): each one knocks 1–2% off the long-term cross-border TAM.
- **MLPerf-equivalent disclosure** at Mastercard's developer events of DI Pro performance vs. third-party benchmarks — none currently exist, which is itself a soft tell. Watch September Mastercard Sessions.
- **Any large merchant (Shopify-scale or Walmart-scale) embedding stablecoin checkout** as default and disclosing routing share by tender type.

## What I could not verify
- Person-years required to replicate Decision Intelligence Pro at parity; I inferred 5+ years based on the data-substrate argument, not from disclosed engineering details.
- Exact split of cross-border revenue between travel and e-commerce — directionally travel is the more volatile component, but I could not source a precise split.
- Direct latency/throughput comparison between MA's Decision Intelligence Pro and Visa's Risk Manager Pro / Visa Protect — no MLPerf-equivalent independent benchmark exists for payment fraud models.
- Detailed token vault statistics (number of active tokens, share of e-commerce flow tokenized) — MA discloses growth qualitatively but not the absolute base.
- Share of BVNK's $30B annualized volume on which MA will capture economics post-close, and the contractual terms with stablecoin issuers (USDC, PYUSD).
- Q1 2026 cross-border revenue split by region and the specific Iran/Middle East exposure quantum.
- The realized cross-elasticity between interchange pricing reductions (from the settlement) and merchant acceptance volume — i.e., whether the -10bps cut is offset by acceptance gains.
- Whether the 5,000 vs. 20,000 TPS figures for Mastercard reflect sustained vs. peak vs. theoretical capacity — sources conflict and MA does not disclose a SLA-grade number publicly.

## Sources
[1] https://www.fierce-network.com/cloud/mastercard-cto-dishes-network-gets-your-money-where-it-needs-go — retrieved 2026-05-10 — Banknet architecture, 60 data centers, MPLS, 3,700 edges, hybrid AWS/Azure
[2] https://venturebeat.com/orchestration/what-ai-builders-can-learn-from-fraud-models-that-run-in-300-milliseconds — retrieved 2026-05-10 — DI Pro latency/throughput specs (160B yearly tx, <50ms, 70k TPS peak)
[3] https://finance.yahoo.com/quote/MA/ — retrieved 2026-05-10 — current price $497.99, 52-week range $480.50–$601.77, market cap range
[4] https://www.tikr.com/blog/mastercard-stock-heres-why-analysts-target-655-in-2026 — retrieved 2026-05-10 — consensus FY26 EPS ~$20.25, PT median $665, 53 analysts
[5] https://www.gurufocus.com/term/enterprise-value-to-ebitda/MA — retrieved 2026-05-10 — EV $457.66B, EV/EBITDA 22.73× (19% below 10-yr median 27.94×)
[6] https://www.fool.com/earnings/call-transcripts/2026/04/30/mastercard-ma-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1 2026 net revenue $8.4B, FY26 guidance low-teens currency-neutral
[7] https://www.ytdreturn.com/mastercard/ — retrieved 2026-05-10 — YTD 2026 total return –11.62%
[8] https://www.marketbeat.com/stocks/NYSE/MA/short-interest/ — retrieved 2026-05-10 — short interest ~6.49M shares, 0.73% of shares outstanding
[9] https://techcrunch.com/2025/01/09/india-rupay-upi-payment-push-is-cutting-out-visa-and-mastercard/ — retrieved 2026-05-10 — India credit card e-commerce share decline 43%→21%, RuPay/UPI displacement
[10] https://www.cdomagazine.tech/aiml/mastercard-launches-decision-intelligence-pro-new-generative-ai-model-for-fraud-detection — retrieved 2026-05-10 — DI Pro genAI/transformer/graph-ML architecture
[11] https://www.mastercard.com/us/en/business/artificial-intelligence/mastercard-agent-pay.html — retrieved 2026-05-10 — Agent Pay tokenization specs and scoped permissions
[12] https://www.paz.ai/blog/the-payment-networks-are-all-in-what-visa-mastercard-and-paypals-q4-moves-signal — retrieved 2026-05-10 — agentic commerce 20% e-commerce projection, first live transaction Sept 29 2025, PayPal multi-platform integration
[13] https://www.brookings.edu/articles/next-steps-for-genius-payment-stablecoins/ — retrieved 2026-05-10 — GENIUS Act July 2025, PPSI framework, non-bank issuance
[14] https://news.alphastreet.com/mastercard-ma-q1-2026-revenue-jumps-16-but-april-cross-border-softness-tests-the-bull-case/amp/ — retrieved 2026-05-10 — April cross-border +9% vs Q1 +13%, travel +2% vs +8%
[15] https://www.cnbc.com/2026/03/17/mastercard-acquiring-stablecoin-startup-bvnk-in-crypto-bet.html — retrieved 2026-05-10 — BVNK $1.8B acquisition, $30B annualized volume, late-2026 close
[16] https://www.paymentsdive.com/news/fednow-rtp-bank-participation-instant-payments/721484/ — retrieved 2026-05-10 — FedNow ~1,500 institutions / 40% of DDAs
[17] https://www.kucoin.com/news/flash/visa-mastercard-and-stripe-aggressively-expand-stablecoin-settlement-infrastructure — retrieved 2026-05-10 — Visa USDC $4.6B annualized run rate, 130+ programs / 50+ countries; Chainalysis $28T 2025 stablecoin volume
[18] https://financialit.net/news/e-commerce/e-commerce-upi-sparks-credit-card-boom-india-while-pix-overtakes-card-dominance — retrieved 2026-05-10 — Pix 42% Brazil e-commerce vs cards 41%, 18% CAGR to 50% by 2028
[19] https://www.tikr.com/blog/mastercard-q1-2026-earnings-revenue-hits-8-4b-eps-up-23 — retrieved 2026-05-10 — Q1 cross-border assessments +18% on +13% volume; domestic assessments +6% on +7% GDV
[20] https://www.pymnts.com/credit-cards/2026/retailers-object-to-200-billion-visa-mastercard-swipe-fee-settlement/ — retrieved 2026-05-10 — $200B settlement terms (-10bps 5yr, 1.25% cap 8yr), merchant objections, 2026 ruling expected
[21] https://finance.yahoo.com/markets/stocks/articles/mastercard-beats-q1-earnings-strong-143700049.html — retrieved 2026-05-10 — Q1 2026 VAS revenue $3.5B +22% YoY, EPS $4.60 +23%
[22] https://www.gurufocus.com/term/enterprise-value-to-ebitda/MA — retrieved 2026-05-10 — Mastercard EV/EBITDA 22.73× vs 10-yr median 27.94×