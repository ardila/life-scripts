I have enough material. Drafting the dossier now.

# FLR — Fluor Corporation

## Where this sits in the AI stack
Fluor sits at the **physical buildout layer** of AI infrastructure — not silicon, not software, not power generation equipment, but the engineering, procurement and construction (EPC) of the buildings that house GPUs, the gas-fired and nuclear plants that power them, and the federal nuclear sites that produce the materials some of those plants will run on. The company sells engineering hours, project management, and the underwriting capacity to wrap a multi-billion-dollar fixed-asset project under one schedule. Within AI specifically, Fluor's exposure is to hyperscale and colocation data center campuses (Urban Solutions / Mission & Tech Solutions), to gas-fueled and nuclear power plants that supply them (Energy Solutions), and — more idiosyncratically — to U.S. Department of Energy nuclear cleanup and HALEU fuel work that underpins the long-dated SMR thesis [1][3][8].

## Snapshot
- **Price:** $43.31 (2026-05-10 close) [1]
- **Market cap:** $6.20B [1]
- **52-week range:** $37.04 – $57.50 [1]
- **Forward P/E:** ~18–20× — inferred from FY26 EBITDA midpoint $542M, ~$50M D&A, modest net interest income on $3.2B cash, ~25% tax, ~165M shares → ~$2.10–2.40 EPS. No clean sell-side consensus EPS surfaced post-guide-down; treat as estimate, not consensus. [2][6]
- **EV / NTM revenue:** ~0.27× — ($6.2B mcap − ~$3.2B cash & securities + ~$1B debt) / ~$15B NTM revenue, an inference from full-year 2025 revenue of $15.5B and Q1 –8% YoY [4][6][7]
- **Consensus 12-month price target:** ~$53.50–$54.22 (implied +24% to +25% from $43.31), Buy consensus from 6–9 analysts [2]
- **YTD total return:** −15.2% through May 8, 2026 [9]
- **Short interest (% of float):** 5.8% [9]

## Moat — what it is physically made of
Fluor's moat is **not** a software or IP moat. Decomposed honestly:

**1. Nuclear-EPC license to operate (durable, narrow).** Fluor is one of three Western firms — alongside Bechtel and Westinghouse/Brookfield — that can prime a Western nuclear new-build or DOE legacy-cleanup contract at scale. The H2C JV (BWXT/Amentum/Fluor) holds a Hanford tank-waste contract worth up to $45B; Fluor leads the Savannah River M&O contract ($12B / 5 years; Fluor's portion ~$4.5B / 4 years) [8]. These are not won on price; they are won on cleared personnel, NQA-1 quality programs, decades of audit trails, and DOE relationship continuity. Replication time is 10–20 years, not 2–3. This is the most genuinely durable component of the moat.

**2. Reimbursable contract framework (durable, but is a discipline not a moat).** 82% of Q1 2026 backlog and 87% of FY25 awards are reimbursable; legacy fixed-price loss exposure has been worked down from $1.8B to $558M, and new "smart lump sum" structures only convert from cost-plus after front-end engineering defines scope [4][7]. This protects margin but is a contract-discipline choice that Bechtel, KBR, and Jacobs can match — and that hyperscalers may resist as they push for guaranteed-price, guaranteed-schedule mega-builds.

**3. Hyperscale data-center delivery track record (real but commoditizing).** ~148 MW delivered across Sweden/UK over 5 years, hyperscale builds in Finland/Netherlands, two colocation campuses in India for a Fortune 500 customer with 14.5M safe work-hours, and "Top Data Center Constructor 2025" recognition from Data Centre Magazine [10]. This is genuine but is *one of many* general contractors with the credentials — Bechtel, DPR, Turner, Holder, Mortenson, Clayco all play here, and Quanta has spent ~$3.5B on Cupertino Electric and Dynamic Systems explicitly to take the electrical/mechanical specialty layer [11].

**4. Front-end engineering pipeline as a soft lock-in.** Fluor reports $60B of revenue under active front-end engineering (FEED) and $40B of tracked prospects, up 50% YoY [3][12]. Once Fluor does the FEED, the customer faces switching cost in handing the EPC phase to a different prime. This is real but soft; if execution slips (as on legacy infrastructure projects and the Q1 mining/legal charges), the FEED relationship doesn't lock in the construction phase.

**5. NuScale equity is no longer part of the moat.** Fluor fully exited its ~40M-share NuScale position in April 2026, generating ~$2.43B in gross proceeds since September 2025 [13][6]. The SMR optionality on Fluor's balance sheet is gone; what remains is the *engineering* relationship with NuScale (Fluor would still be the EPC for NuScale module deployments). That is real but the equity windfall is now in the rear-view mirror.

Net: there is a real, durable nuclear-EPC moat that is small (federal-only, capped TAM) and a much larger commercial-EPC franchise that is **a participant in a competitive market, not the holder of a structural moat**. Be honest: this is a low-margin services business whose advantage is reputation + contract discipline, not technology.

## AI buildout bottleneck map
The actual gating constraints on the next 24 months of AI buildout, with FLR's position on each:

- **Power generation (gas turbines):** Severely constrained. GE Vernova ended 2025 with an 80 GW gas-turbine backlog stretching into 2029; the CEO expects to be sold out through 2030 by end-2026; OEM quotes run 5–7 years for new orders [14]. **FLR is a downstream beneficiary, not the constraint owner.** Fluor builds the *plant* around the turbine; GE Vernova / Siemens Energy / MHI own the actual gating SKU. Margin and pricing power on a turbine is far better than on the EPC wrap.
- **Grid interconnect:** Severely constrained. U.S. interconnection queue ~2,300 GW with median 5-year wait, up to 12 years for some data-center projects; ~80% project attrition due to delays/upgrade costs [15]. **FLR is an exposed customer's contractor**, indifferent at best — no special privilege in queue.
- **Liquid cooling at >100 kW/rack:** Capacity-constrained at the OEM (Vertiv, CoolIT, Boyd) and CDU level. **FLR integrates these as a buyer, neutral.**
- **CoWoS-L advanced packaging:** TSMC scaling from ~35K wafers/month (late 2024) to ~130–150K/month by end-2026; NVIDIA holds >60% of allocation [16]. **FLR is wholly indifferent** — this is a packaging/foundry constraint with zero overlap into FLR's business.
- **HBM3e/HBM4 supply:** Indifferent.
- **Optical interconnect supply:** Indifferent.
- **Electrical contractor capacity (medium voltage, switchgear install, CDU loops):** Constrained. **This is where Quanta Services has positioned via Cupertino Electric and Dynamic Systems** [11]. FLR plays at the EPC layer above this; Quanta owns the actual labor/install bottleneck better.
- **SMR / new nuclear:** Multi-year constraint (NRC licensing, fuel HALEU). **FLR is a credentialed beneficiary** through its NuScale EPC relationship and DOE work, but the first NuScale TVA reactors don't come online until 2032 [13] — too far out to drive 2026–2028 numbers.
- **Semiconductor fab construction:** TSMC AZ Fab 2 and Fab 3, Samsung TX, Intel OH all ongoing. FLR has historic semi-fab EPC capability but the *named* primes on the headline U.S. fabs have generally been Bechtel and JV consortia; I could not confirm a current FLR scope on TSMC AZ specifically [17].

The honest summary: Fluor is **adjacent to most AI-buildout bottlenecks but owns none of them**. The pure-play bottleneck owners (GE Vernova on turbines, Eaton/Hubbell on switchgear, Vertiv on cooling, Quanta on electrical labor) trade at much higher multiples for that reason.

## Competitive teardown
- **Bechtel (private).** Bechtel is bigger, private, and is publicly partnered with NVIDIA on "AI factory" delivery, with explicit framing around "first revenue token" time-to-online [18]. On hyperscale flagship campuses Bechtel is the default prime; on nuclear new-build (Vogtle, future AP1000s) Bechtel competes head-to-head with Fluor. Because Bechtel is private, it can warehouse risk on lump-sum that public Fluor will not. **Net: Bechtel takes the largest-marquee dollar; Fluor takes the multi-campus reimbursable framework deals.**
- **Quanta Services (PWR).** Different layer — Quanta is the electrical / utility-T&D / specialty mechanical labor stack underneath the EPC wrap. The Cupertino Electric ($2B) and Dynamic Systems (~$1.5B) acquisitions are explicit data-center-electrical bets [11]. **Quanta owns labor, FLR owns coordination.** Quanta's multiple is roughly 2–3× FLR's on EBITDA precisely because the market believes labor is scarcer than coordination. This is plausibly correct.
- **Jacobs Solutions (J), AECOM (ACM), KBR.** Front-end engineering and federal-services overlap. None of them have FLR's nuclear M&O footprint; Jacobs is comparable on data-center mechanical/electrical engineering. These compete for the FEED dollar more than for the EPC dollar.
- **Kiewit (private), Mortenson (private), Holder, DPR, Turner, Clayco.** General-contractor competition for hyperscale data-center shells. Several are perfectly capable on a single-site basis. FLR's edge is multi-site framework + global passport, not site-level execution.
- **In-house hyperscaler teams (Meta, Microsoft, Google).** The most under-discussed competitive vector: Meta and Microsoft have large internal datacenter design groups and act as their own GC on many sites, hiring trades directly. This *caps* the EPC opportunity even as capex grows. Fluor benefits where (a) the hyperscaler wants speed-to-online over cost optimization, or (b) the project is power-plant scale rather than just shell.

What would have to be true for a competitor to take share: **Quanta already has parity-or-better on the data-center electrical labor axis**; Bechtel already has parity-or-better on flagship-campus delivery. Fluor needs to convert its FEED pipeline at margin, not lose share — share-loss is not the issue, rather **share-of-pipeline that converts to firm backlog at fee** is the issue.

## Bull case — technical
For FLR to outperform from $43, the following technical conditions need to hold:

1. **Hyperscaler 2026 capex lands at the high end (~$700–725B)** [19][20] *and* a meaningful share of the new sites are too power-intensive (>500 MW campus, on-site generation, behind-the-meter nuclear/gas) for hyperscalers to self-perform — pushing them onto an EPC-wrap model rather than direct-to-trades.
2. **The $60B FEED book converts to firm backlog at >50% rate over 8–12 quarters.** Q1 2026 awards of $2.69B (down 54% YoY) [4] is what spooked the market; the bull case is that this is timing, not loss.
3. **The reimbursable mix holds at 80%+** as projects convert from FEED to construction, so EBITDA margin compounds rather than compresses on conversion.
4. **U.S. nuclear renaissance accelerates faster than the 2032 NuScale-TVA timeline implies** — Vogtle Unit 5/6 restart, additional AP1000s, or HALEU enrichment plant builds. FLR's DOE-cleared workforce is the asymmetric enabler here. None of this needs to be at parity with NVIDIA-cycle TAM to drive a 30% multiple re-rate on a $6B-cap stock.
5. **Capital return on the $3.2B post-NuScale war chest is disciplined** — $516M Q1 buyback at $40s removes float; another ~$1B buyback would shrink share count materially [6][7].

**Base rate context:** Past EPC platform shifts (gas-fired buildout 2000–2008, LNG cycle 2014–2019, mining super-cycle) have produced multi-bagger moves in EPC primes during conversion phase, followed by deep cyclical drawdowns when the build cycle peaks. Today's hyperscaler capex is in conversion phase. EPC primes that survived the previous cycles intact (Fluor did, JEC did, McDermott did not) tend to compound book-value through the *next* cycle if they hold contract discipline. So a 20–30% return over 18–24 months is consistent with base rate; a multi-bagger is not, because the reimbursable model caps upside.

Financial outcome: 18–20× ~$2.20 EPS plus ~$3 NuScale cash distributable per share + $54 PT center-of-mass = roughly fair-value at $50–55 today, with optionality on FEED conversion taking it to $60–65. That is what the consensus PT already prices in [2].

## Bear case — technical
A short-seller who actually understands the stack would write:

1. **EPC is structurally a low-margin services business.** Even at 80% reimbursable, segment margins run 3–5%. The tape's enthusiasm in 2024–2025 conflated "exposed to AI capex" with "captures AI capex." The $60B FEED book is *gross*, not *net of fee*; even at 5–7% all-in fee, lifetime gross profit on the entire pipeline is $3–4B — not transformative against a $6B market cap once you discount conversion probability and execution risk.
2. **Fluor specifically has serial execution problems.** The Q1 2026 print included a $96M legal charge and $37M mining cost overrun [9]; legacy fixed-price losses have been worked down but not eliminated; Urban Solutions still has three legacy projects to hand over through 2026 and one in early 2027 [4]. The company has cut guidance repeatedly. Reimbursable contracts protect the *go-forward* mix but do not eliminate the embedded tail.
3. **The actual AI bottlenecks are upstream of Fluor.** Gas turbines (5–7yr wait), grid interconnect (5–12yr), CoWoS-L allocation, HBM4 — the value capture lives at the OEM and constraint-owner level (GEV, Eaton, Vertiv, Quanta), not the GC level. FLR is a beneficiary, not a beneficiary at the price the market wants to ascribe.
4. **Hyperscaler self-performance caps the TAM.** Meta, Microsoft, and Google design and procure their own data centers; they hire EPC primes selectively for power-plant-scale or international jurisdictions. The very largest and most lucrative campus deals are *less* available to outside primes than naive TAM math suggests.
5. **Bechtel as private competitor is a structural problem.** Bechtel can underwrite lump-sum risk Fluor cannot, can move on multi-decade workforce decisions without earnings-quarter pressure, and is publicly partnered with NVIDIA on AI factory delivery [18]. On flagship marquee work, FLR likely loses share over time.
6. **NuScale's exit removes an option, not a value.** $2.43B realized at sale prices the market may now consider a high-water mark. The company's own decision to fully exit at this point in the SMR cycle is itself a credible negative signal about NuScale-specific monetization, even as it improves Fluor's balance sheet.

**Base rate context for displacement:** Past services moats (engineering, consulting, construction) erode slowly — over decades, not quarters — but never re-rate up to product-company multiples. The historical base rate for an EPC prime to compound at >12% over a 10-year window is poor: cyclicality wins. The bear is not that FLR goes to zero; it's that FLR is a 0.27× revenue, 18–20× earnings *services* business that the market has flirted with rerating to a 1× revenue *AI infrastructure* business. The Q1 print started the unwind of that flirtation.

## Market view check
At $43.31 and a $54 consensus PT, the Street is calling for ~24% upside on a Buy rating with a -15% YTD print and a guidance cut already absorbed [2][9]. The market is treating FLR as an EPC cyclical with AI optionality — about 18–20× earnings, ~0.27× revenue, ~7–8× EBITDA on guided midpoint. **That is approximately fair given the technical reality:** Fluor benefits from the buildout but does not own the bottleneck. The market is *not* priced for "Fluor is the AI picks-and-shovels play" — that thesis was priced when the stock was at $57 last summer; the Q1 miss reset it. The mispricing risk is *symmetric*: another guide-down or a major fixed-price legacy charge takes the stock to ~$35; conversion of $5–10B of FEED to firm reimbursable backlog over the next two prints takes it to $55–60. Net, this is closer to fair than mispriced today.

## 90-day falsifiers
- **Q2 2026 print (early August):** Awards print needs to recover above $4–5B from Q1's $2.69B; if awards stay <$3.5B, the FEED-to-firm conversion thesis is broken and the stock breaks $40 [4].
- **Major data-center master-agreement award announcement** at >$1B converted out of FEED. The disclosed unnamed US data-center master agreement at $500M–$1B-per-project [3] needs visible call-down activity.
- **TeraWulf 480 MW Kentucky LNTP → full notice to proceed** at the disclosed $3–4B estimate [3]. Full conversion is a thesis-confirming print; failure to convert by Q3 is bearish.
- **Hyperscaler Q2 capex guidance:** if Microsoft, Meta, Amazon, or Google cut FY26 capex sequentially by >10%, the EPC primes derate together. Watch GEV's order book as a leading indicator [14][19].
- **Any restated legacy-project charge in Q2:** would invalidate the "loss exposure walked from $1.8B to $558M" narrative and reset multiples [4].
- **Bechtel + NVIDIA "AI factory" reference customer announced** with named hyperscaler. Would tighten the competitive vise on FLR's master-agreement positioning [18].
- **DOE Hanford / Savannah River contract action.** Continuation, expansion, or competitor displacement on either is a binary read on the most durable part of the moat [8].

## What I could not verify
- Fluor's specific scope, dollar value, or current status on TSMC Arizona Fab 1/2/3 — sources confirm Fluor has historic semi-fab EPC capability but did not confirm an active prime contract on the named TSMC AZ phases.
- The identity of the unnamed US data-center provider behind the $500M–$1B / project master agreement [3]. Identification would materially tighten the bull thesis.
- A clean, sell-side-consensus FY26 EPS — I inferred ~$2.10–2.40 from EBITDA guidance, share count, and tax rate; published consensus was not surfaced cleanly. The forward P/E I cited is therefore an inference, not a Bloomberg-confirmed number.
- Quantitative share of $60B FEED that historically converts to firm backlog at Fluor specifically. Industry rule-of-thumb is 30–60%; the actual realized rate over the last cycle was not in the public sources I reviewed.
- Margin profile and overhead structure of Fluor's data-center work specifically vs. corporate average — Fluor does not segment-disclose at that granularity.
- Whether Fluor's nuclear-cleared workforce is currently capacity-constrained relative to the DOE/SMR pipeline. If it is, the marginal nuclear EPC dollar is much higher-margin than headline rate.
- The actual cost basis on Fluor's NuScale stake and therefore the realized gain — I have gross proceeds ($2.43B) but not net economics.

## Sources
[1] https://finance.yahoo.com/quote/FLR/ — retrieved 2026-05-10 — FLR price ($43.31), market cap ($6.20B), 52-wk range ($37.04–$57.50)
[2] https://stockanalysis.com/stocks/flr/forecast/ — retrieved 2026-05-10 — Analyst average PT ~$54, 6–9 analyst Buy consensus
[3] https://newsroom.fluor.com/news-releases/news-details/2026/Fluor-Reports-First-Quarter-2026-Results/default.aspx — retrieved 2026-05-10 — Q1 2026 backlog $25.7B at 82% reimbursable, $60B FEED book + $40B prospects, data-center master-agreement disclosed, TeraWulf 480 MW LNTP
[4] https://www.investing.com/news/transcripts/earnings-call-transcript-fluors-q1-2026-earnings-miss-stock-drops-10-93CH-4672952 — retrieved 2026-05-10 — Q1 2026 EPS $0.14 vs $0.61 consensus, revenue $3.66B, awards $2.69B (-54% YoY), guidance cut, legal/mining charges
[5] https://www.constructiondive.com/news/fluor-posts-drop-q1-awards-revenue/819751/ — retrieved 2026-05-10 — Q1 awards drop, contracting strategy
[6] https://grafa.com/en/news/united-states/fluor-flr-q1-2026-earnings-nuscale-sale-share-repurchase — retrieved 2026-05-10 — $3.2B liquidity, NuScale completed, $516M Q1 buyback
[7] https://news.alphastreet.com/fluor-flr-enters-2026-with-a-backlog-mix-built-for-cash-flow/ — retrieved 2026-05-10 — Reimbursable mix history (45% → 80%), legacy loss exposure $1.8B → $558M, 2025 results
[8] https://www.fluor.com/projects/savannah-river-nuclear-management-operations and https://www.energy.gov/em/major-contracts-summary-0 — retrieved 2026-05-10 — DOE M&O contracts: Savannah River $12B / 5yr (Fluor portion ~$4.5B / 4yr), Hanford H2C JV up to $45B
[9] https://ts2.tech/en/why-fluor-stock-is-dropping-after-q1-earnings-miss-and-2026-guidance-cut/ — retrieved 2026-05-10 — YTD -15.21%, short interest 5.82%, $96M legal + $37M mining charges
[10] https://newsroom.fluor.com/featured-stories/blog-details/2025/Fluor-Named-Top-Data-Center-Constructor-by-DataCentre-Magazine/default.aspx and https://www.fluor.com/market-reach/industries/technology/data-centers — retrieved 2026-05-10 — Hyperscale track record: ~148 MW UK/Sweden, Finland/Netherlands, India colocation, Top Constructor 2025
[11] https://finance.yahoo.com/sectors/technology/articles/data-centers-becoming-core-growth-152300822.html — retrieved 2026-05-10 — Quanta acquisitions: Cupertino Electric ($2B), Dynamic Systems ($1.5B)
[12] https://www.fool.com/earnings/call-transcripts/2026/02/17/fluor-flr-q4-2025-earnings-call-transcript/ — retrieved 2026-05-10 — Pipeline up 50% YoY, segment commentary, "smart lump sum" framework
[13] https://www.fool.com/investing/2026/05/07/fluor-is-done-selling-stake-in-nuscale-is-it-time/ and https://balkangreenenergynews.com/us-based-fluor-sells-remaining-stake-in-nuscale-technology-supplier-for-romanias-smr-project/ — retrieved 2026-05-10 — NuScale exit completed April 2026, ~$2.43B gross since Sept 2025, TVA 6 GW agreement first online 2032
[14] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ and https://www.spglobal.com/commodity-insights/en/news-research/latest-news/electric-power/052025-us-gas-fired-turbine-wait-times-as-much-as-seven-years-costs-up-sharply — retrieved 2026-05-10 — GEV 80 GW backlog into 2029, OEM lead times 5–7 yr
[15] https://rmi.org/interconnection-reform-ai-data-centers-generator-queues/ and https://enkiai.com/data-center/data-center-power-crisis-2026-the-grid-bottleneck/ — retrieved 2026-05-10 — Interconnection queue ~2,300 GW, median 5-yr wait, ~80% project attrition
[16] https://markets.financialcontent.com/stocks/article/tokenring-2026-2-5-tsmc-to-quadruple-advanced-packaging-capacity-reaching-130000-cowos-wafers-monthly-by-late-2026 and https://www.astutegroup.com/news/industrial/advanced-packaging-demand-soars-nvidia-secures-60-of-cowos-capacity/ — retrieved 2026-05-10 — TSMC CoWoS to 130–150K wpm by end-2026, NVIDIA >60% allocation, CoWoS-L for Blackwell/Rubin
[17] https://en.wikipedia.org/wiki/TSMC_Arizona and https://www.trendforce.com/news/2025/12/18/news-tsmc-reportedly-accelerates-arizona-2nd-fab-eyes-3q26-tool-install-2027-3nm-production/ — retrieved 2026-05-10 — TSMC AZ fab status, no confirmed FLR scope
[18] https://datacentremagazine.com/news/bechtel-data-centre-procurement-strategy-innovation — retrieved 2026-05-10 — Bechtel/NVIDIA AI factory partnership, "first revenue token" framing
[19] https://www.tomshardware.com/tech-industry/big-tech/big-techs-ai-spending-plans-reach-725-billion — retrieved 2026-05-10 — Hyperscaler 2026 capex projection ~$725B, +77% YoY
[20] https://datacenterrichness.substack.com/p/hyperscalers-plan-630-billion-in — retrieved 2026-05-10 — Alternative hyperscaler 2026 capex estimate ~$630B