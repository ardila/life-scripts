I have what I need. Writing the dossier now.

# ANSS — ANSYS, Inc. (delisted; legacy ticker absorbed into Synopsys/SNPS on 2025-07-17)

## Where this sits in the AI stack
ANSS does not exist as a tradeable security. Ansys was acquired by Synopsys on 17 July 2025; each ANSS share converted into $199.91 cash + 0.3399 SNPS shares [1][2][5]. The Ansys business now sits inside Synopsys as the "system analysis" half of a "silicon-to-systems" stack: it sells **physics solvers**, not silicon or runtime. The relevant layer for the AI buildout is **chip and system signoff** — RedHawk-SC for IR-drop/power-integrity signoff down to 3nm, RedHawk-SC Electrothermal for 3D-IC stack thermal, HFSS for full-wave EM extraction on advanced packages, Icepak for board/system cooling, Lumerical/Zemax for the photonic pieces of co-packaged optics, plus general-purpose Fluent (CFD) and Mechanical (FEA) used for datacenter aero/thermal and mechanical reliability [14][15][31]. Workload is **design-time, offline, batch** — not training, not real-time inference. This dossier therefore covers (a) what a legacy ANSS holder owns today (SNPS shares + cash), and (b) the underlying Ansys business as a moat inside SNPS.

## Snapshot
ANSS itself: **delisted 2025-07-18** [3][4]. Listing the legacy proxy via the parent.

- **ANSS legacy conversion value per share:** ~$375.46 ($199.91 cash + 0.3399 × $516.48 SNPS close = $175.55 stock) [1][5][25]
- **SNPS price:** $516.48 (2026-05-08 close) [25]
- **SNPS market cap:** ~$98.9B [25]
- **SNPS 52-week range:** n/a — could not source a clean range in the available data; consensus commentary suggests material volatility through the integration window
- **SNPS forward P/E:** ~33.6× on FY26 non-GAAP EPS guide $14.38–$14.46 [25][18]
- **SNPS EV / NTM revenue:** ~8.5× on FY26 guide $9.56–9.66B [18][25]
- **SNPS consensus 12-month target:** ~$558 (avg of 14–18 analysts), ~+8% from spot; recent revisions trimmed by ~$70 citing integration risk [25][26][27]
- **SNPS YTD total return:** n/a — not in the available source set
- **Short interest:** n/a — not in the available source set

If a value above is "n/a", I could not source it cleanly in the searches done for this dossier rather than it being unavailable in principle.

## Moat — what it is physically made of
The Ansys moat is not "simulation software" — it's several stacked, separately durable layers. Decomposing them:

**(1) Validated solver IP with decades of physical correlation.** Fluent (CFD) dates to the 1980s; LS-DYNA explicit dynamics to 1976; Mechanical/APDL to the early 1970s. The durable asset is not the code but the **calibrated turbulence closures, material models, contact algorithms, and constitutive laws** that have been correlated against measured experiments over decades and accepted by certification bodies (FAA, FDA 510(k) submissions referencing Ansys models, automotive crash homologation pipelines). Replicating this from scratch requires not engineering effort but **physical test data** a competitor does not have. This is the longest-lived layer and the hardest to copy.

**(2) Foundry-certified semiconductor signoff flows.** RedHawk-SC is certified for IR-drop / dynamic voltage drop / electromigration signoff down to 3nm and is built on the SeaScape cloud-native analytics platform [14]. Ansys 3D-IC power integrity + thermal is certified for the TSMC 3Dblox reference flow and integrated with Synopsys 3DIC Compiler for CoWoS interposers up to 5.5× reticle [15][29]. The certification path with a foundry is multi-year and gated by silicon correlation studies — Ansys publishes <10% RedHawk-vs-silicon correlation on validation chips [14]. A new entrant must either be foundry-certified or convince customers to accept uncertified signoff on $50M+ tape-outs. Practically, that doesn't happen.

**(3) Multiphysics co-simulation glue.** The genuinely defensible piece for the AI era is the **coupling**: HFSS-IC (EM extraction) → RedHawk-SC (power) → RedHawk-SC Electrothermal (heat) → Mechanical (stress/warpage) → Icepak (board-level cooling) on a single geometry/mesh representation. Competitors have one or two of these; only Ansys has the full chain glued, and the glue (data formats, mesh translators, parameter sweep automation) is the actual work. This matters specifically for **2.5D/3D-IC and CoWoS-L** where thermal–mechanical–EM coupling is no longer optional [15][29].

**(4) GPU-accelerated solver rewrites.** Fluent's GPU solver hits ~110× speedup on 320 GH200s vs 2,000 CPU cores [9]; CUDA 12.8 support across Blackwell shipped in 2025 R2 / 2026 R1 [8]. This is a moat versus open-source solvers (OpenFOAM, SU2) which lack production-grade GPU kernels for multiphase/combustion. It is **not** a moat versus Siemens Simcenter STAR-CCM+ or Cadence Fidelity CFD, both of which also have GPU paths.

**(5) Customer ACV stickiness.** FY24 ACV was $2.56B growing 15% YoY in Q4 [22][23] with non-GAAP operating margin of 45.7% — these are subscription metrics, not perpetual-license. Multi-year enterprise agreements with Boeing, Volvo, the major auto OEMs, and every leading semi (NVIDIA, AMD, Intel, TSMC, Broadcom) make displacement an N-year procurement and validation cycle.

**What is *not* a moat:** brand alone; SimAI as a standalone product (it sits on top of customer-owned simulation data, and the underlying neural-operator architectures are NVIDIA-open via PhysicsNeMo [11][32]).

## AI buildout bottleneck map
For each of the next-24-month gating constraints on AI infrastructure, where does the Ansys business actually sit:

- **Advanced packaging (CoWoS-L / SoIC):** **Beneficiary, indirect.** Every CoWoS-L design is a multiphysics problem (thermal gradients across stacked dies, warpage from CTE mismatch, EM crosstalk between stacked HBM and logic). RedHawk-SC Electrothermal + HFSS-IC + Mechanical are the de facto signoff chain [15][29]. Revenue scales with **number of unique advanced-packaging tape-outs**, not wafer volume.
- **HBM yield / supply:** Indirect beneficiary — HBM stack design uses HFSS for SI/PI extraction and Mechanical for through-silicon-via stress. Not a primary driver.
- **Power generation and grid:** **Beneficiary, modest.** Icepak + Fluent are used in datacenter cooling design (CRAC layout, immersion, rear-door heat exchangers). Demand from hyperscaler facility design is real but small relative to silicon signoff.
- **Liquid cooling at >100 kW/rack:** Direct beneficiary. CFD-led cold-plate and manifold optimization is a Fluent workload, and ASE/Foxconn/Vertiv-style ODMs use Ansys broadly. Quantification beyond "directionally positive" is not publicly disclosed.
- **Optical interconnect / co-packaged optics:** **Direct beneficiary, structurally important.** TSMC-COUPE (compact universal photonic engine) is the explicit example where the toolchain spans Zemax (optical path) + Lumerical (photonic device) + HFSS-IC (EM) + RedHawk-SC Electrothermal (heat) [31]. CPO is where Ansys is currently most uniquely positioned because nobody else has the photonic-to-electrical-to-thermal chain integrated.
- **Kernel/compiler talent:** Indifferent — Ansys is the consumer of CUDA-skilled engineering, not the supplier.
- **Training data quality / frontier model scaling:** Indifferent — Ansys does not sit in the training-data or RLHF stack.

Net: Ansys benefits primarily from **design complexity per chip** (advanced packaging, 3D-IC, CPO), not from raw GPU unit volume. This is a different exposure shape than NVIDIA or TSMC.

## Competitive teardown
Three meaningful competitors. Honest read on each:

**Cadence Design Systems** — the most credible threat. Acquired Beta CAE Systems for $1.24B (2024) and Hexagon's design/engineering unit for $3.16B (2025) [17]. Now offers Allegro X + Clarity 3D Solver (EM) + Celsius EC (thermal) + Fidelity CFD + MSC Actran. **Parity already** on EM signoff for IC packaging at advanced nodes. **Behind** on the full multiphysics chain (especially nonlinear structural and CFD breadth) but closing fast. The risk to the legacy ANSS moat is not "Cadence dominates" but "Cadence reaches good-enough multiphysics, customers split EDA + multiphysics across two vendors, Synopsys-Ansys premium pricing compresses." Timeline: 2026–2028.

**Siemens Digital Industries (Siemens Xcelerator: Simcenter STAR-CCM+ / Femap / HEEDS + Altair).** Closed $10.6B Altair acquisition in 2025 [16][17]. Now has CFD, FEA, electromagnetics, optimization, and AI-augmented simulation (Altair's PhysicsAI). Strong outside semis (auto, aerospace, industrial). **Weaker** on chip signoff — does not have a credible RedHawk-SC competitor. Competes head-on with Ansys on industrial CFD/FEA, **not** on the chip side that's tied to the AI buildout.

**Dassault Systèmes (SIMULIA / Abaqus / CST Studio Suite).** Long-standing #1 in nonlinear FEA via Abaqus; CST is real competition in EM. Bundled with 3DEXPERIENCE PLM. Distribution moat in regulated industries (aerospace, life sciences). Not a meaningful threat to the AI-chip-driven part of the Ansys business.

**Open-source + NVIDIA PhysicsNeMo.** PhysicsNeMo is a Python framework for physics-ML (PINNs, neural operators, GNN) — open-source [32]. It is *not* a solver replacement; it builds surrogates that need a ground-truth solver to train on. Ansys is integrating it (SeaScape + PhysicsNeMo FNO surrogates for chip thermal [11]) rather than competing. The case where PhysicsNeMo becomes a threat is if hyperscalers fund publicly-available, foundry-validated surrogate models for chip signoff — currently no evidence this is happening at the certification level.

**What would have to be true for a competitor to take share:** (a) Cadence completes Hexagon integration and ships a unified multiphysics + EDA flow by 2027 that is TSMC-certified for 3D-IC signoff; (b) a hyperscaler (likely Google or Meta) sponsors an open foundry-certified IR-drop signoff path. Neither has occurred yet; both are plausible by 2028.

## Bull case — technical
For SNPS (the security legacy ANSS holders now own) to outperform on the *Ansys-driven* part of the story, the technical conditions are:
(1) **CoWoS-L volume and design diversity both expand** — meaning more unique advanced-package tape-outs, not just more wafers of existing designs. Each new package design is a multiphysics signoff sale. Confirmation will show up as CoWoS allocation diversification beyond NVIDIA/Broadcom to AMD MI400, Marvell custom silicon, and hyperscaler ASICs (Trainium 3, TPU v7, MTIA v2).
(2) **CPO transitions from announcement to volume** — TSMC-COUPE and equivalents move from samples to production in 2026–2027. Ansys is uniquely positioned for the photonic/electrical/thermal coupling [31].
(3) **3D-IC certification moat holds** — competitors (Cadence) do not achieve TSMC 3Dblox-equivalent certification on the **full** stack (power + thermal + EM + mechanical) before 2027.
(4) **SimAI cross-sell works** — Synopsys uses its EDA installed base (essentially every fabless co.) to attach SimAI / multiphysics seats; the disclosed $400M synergy run-rate target by year 4 is real, not optimistic [20].

Base rate: established multiphysics platforms have not been displaced once in 40+ years (Nastran '65, Abaqus '78, Fluent '83 still dominant in their niches). The base rate for sudden moat erosion is essentially zero on 3-year horizons.

If those hold: Ansys segment compounds low double-digits, SNPS aggregate revenue compounds high teens through FY28, and the ~33× forward multiple is sustained or expands on operating leverage.

## Bear case — technical
The honest short-of-the-stack version:
(1) **Ansys is a design-time, not run-time, business.** It scales with the *number of distinct chip and package designs being signed off*, not with token throughput. If hyperscalers consolidate around a smaller number of designs (NVIDIA dominates, ASIC proliferation slows), Ansys' addressable design count shrinks even as compute spend grows. The current narrative ("Ansys is an AI play") could decouple from the actual financial result if AI silicon converges rather than diversifies.
(2) **Surrogate-model commoditization.** PhysicsNeMo is open-source; if a frontier lab releases a foundation model for chip-level thermal/EM/power that is "close enough" for early-stage design exploration, customers may pull back on solver licenses for exploratory work, keeping Ansys only for the final signoff (smaller seat count).
(3) **Cadence catch-up.** Cadence's Hexagon + Beta CAE acquisitions plus its existing EDA distribution create a credible second-source. Procurement organizations *want* to dual-source critical signoff. Pricing power compresses even if share is stable.
(4) **Integration friction inside SNPS.** Synopsys' Q1 FY26 already showed Design IP down 6.5% YoY [19][20]; sell-side has trimmed targets by ~$70 citing integration risk and China headwinds [25]. The cultural collision between EDA (project-based, deal-driven) and CAE (subscription/ACV) sales motions is non-trivial. Synergies could disappoint.
(5) **China.** Both EDA and CAE face escalating export controls. The advanced-node signoff flows are explicitly in scope of US restrictions on Chinese fabless customers. Material revenue at risk that I could not size precisely.

Base rate on integration: large software roll-ups (Oracle/PeopleSoft, IBM/Red Hat, Broadcom/VMware) historically show 12–24 months of revenue dis-synergy before alleged synergies appear. SNPS is currently 10 months in.

## Market view check
SNPS at $516, ~33× forward earnings, ~8.5× EV/NTM revenue, FY26 guide $9.56–9.66B with Ansys contributing $2.9B [18][25]. Consensus PT ~$558 implies ~8% upside; analysts trimmed by ~$70 recently citing slower EDA + IP and integration uncertainty [25][26]. The market is pricing SNPS as **a transitional year** with confidence in the long-term Silicon-to-Systems thesis — i.e., the forward multiple is being held up by the strategic story while near-term numbers absorb dis-synergy. The price is approximately consistent with the technical reality: the moat is intact, integration is real, China is real, Cadence catch-up is a 2027+ risk not a 2026 risk. The mispricing case (if any) is asymmetric on the *downside*: at 33× forward, there is no margin of safety if either (a) the $400M synergy target slips a year or (b) Cadence ships a unified flow in 2026. The mispricing case on the upside requires CPO/CoWoS-L to ramp faster than current consensus models.

## 90-day falsifiers
Observable by ~early August 2026:
- **SNPS Q2 FY26 earnings on 2026-05-27** [28]. Watch: (a) Ansys segment growth — does management still guide double-digits for the segment? (b) Design IP — does the YoY decline narrow or widen? (c) any Ansys-specific operating-margin disclosure; (d) China commentary. A miss + lowered guide would invalidate the bull case substantially.
- **Cadence Q1 CY26 earnings (late April / May 2026)** — competitive read. Specifically: any disclosure of multiphysics ACV from the Hexagon/Beta CAE assets, and any TSMC 3Dblox certification claims.
- **NVIDIA Computex / GTC Asia 2026 announcements** — watch for PhysicsNeMo expansion into chip thermal/EM signoff at foundry-certified level. If NVIDIA announces a *foundry-certified* open surrogate model, that is a real moat-erosion data point.
- **TSMC quarterly update on CoWoS capacity** and allocation diversity. More distinct customers using CoWoS-L = more Ansys signoff seats. Concentration in NVIDIA + Broadcom only = bear data point.
- **Any hyperscaler-disclosed ASIC tape-out using a non-Ansys signoff flow** — would be the single cleanest falsifier of the multiphysics moat at the chip layer.

## What I could not verify
- **RedHawk-SC's exact role in NVIDIA Blackwell / Rubin signoff.** Highly likely given foundry certification and historical usage, but neither NVIDIA nor Ansys publicly attributes specific tape-outs.
- **Ansys-segment standalone operating margin post-acquisition.** Synopsys reports Design Automation (47.3% adj. op margin Q1 FY26) and Design IP (16.2%) but does not split Ansys cleanly [19][20]; pre-deal Ansys ran 45.7% non-GAAP op margin [22].
- **Quantitative China exposure of the Ansys business.** Synopsys flagged China as a headwind broadly; the Ansys-specific number is not separately disclosed in my sources.
- **Whether Synopsys' $400M synergy target is run-rate by year 4 or cumulative.** I saw "run-rate by year 4" in one source [20]; this should be cross-checked against the deal proxy.
- **52-week range, YTD return, and short interest** for SNPS at a precise current value — my searches surfaced point prices but not a clean range.
- **The competitive position of Altair PhysicsAI inside the Siemens portfolio post-close** — likely weaker than Cadence's Hexagon integration but I could not confirm.
- **Whether Stockopedia's "$374.30 ANSS price" is a stale quote or a synthetic implied-deal value.** $199.91 + 0.3399 × $516.48 = $375.46, which matches almost exactly; I infer it is the implied deal value, not a tradeable price.

## Sources
[1] https://news.synopsys.com/2025-07-17-Synopsys-Completes-Acquisition-of-Ansys — retrieved 2026-05-10 — Synopsys's own announcement of deal close on 17 July 2025.
[2] https://www.prnewswire.com/news-releases/synopsys-completes-acquisition-of-ansys-302507582.html — retrieved 2026-05-10 — PRNewswire confirmation of close.
[3] https://www.investing.com/news/sec-filings/synopsys-completes-acquisition-of-ansys-and-delisting-from-nasdaq-93CH-4140021 — retrieved 2026-05-10 — confirms ANSS delisting on 18 July 2025.
[4] https://www.bitget.com/wiki/ansys-stock — retrieved 2026-05-10 — secondary confirmation of delisting status.
[5] https://investors.ansys.com/static-files/cf98bdc1-c68b-45d7-ab03-f5a841852563 — retrieved 2026-05-10 — Form 425 with merger consideration: $199.91 cash + 0.3399 SNPS shares per ANSS share.
[6] https://www.ansys.com/products/ai/simai — retrieved 2026-05-10 — Ansys SimAI product page (physics-agnostic surrogate-model SaaS).
[7] https://www.ansys.com/blog/explaining-simai — retrieved 2026-05-10 — how SimAI applies neural surrogates to solver outputs.
[8] https://vagon.io/gpu-guide/how-to-use-gpu-on-ansys-fluent — retrieved 2026-05-10 — CUDA 12.8 / Blackwell support in Fluent 2025 R2 and 2026 R1.
[9] https://www.ansys.com/blog/new-era-ansys-fluent-computations — retrieved 2026-05-10 — Fluent on 320 GH200s producing 110× speedup vs 2,000 CPU cores.
[10] https://www.ansys.com/content/dam/it-solutions/platform-support/2024-r1/ansys-2024-r1-gpu-accelerator-capabilities.pdf — retrieved 2026-05-10 — Ansys GPU accelerator capability matrix.
[11] https://blogs.nvidia.com/blog/ansys-omniverse-nvidia-physicsnemo-accelerate-simulation/ — retrieved 2026-05-10 — Ansys integrating PhysicsNeMo FNO surrogates into SeaScape for chip thermal.
[12] https://nvidianews.nvidia.com/news/nvidia-blackwell-accelerates-computer-aided-engineering-software-by-orders-of-magnitude-for-real-time-digital-twins — retrieved 2026-05-10 — NVIDIA GTC 2025 announcement of up-to-50× CAE acceleration with Ansys/Cadence/Siemens/Altair/Synopsys.
[13] https://www.engineering.com/nvidia-boasts-50x-faster-simulation-at-gtc-2025/ — retrieved 2026-05-10 — Ansys + 8 Blackwell GPUs cut Volvo external-aero CFD from 24h to 6.5h.
[14] https://www.ansys.com/products/semiconductors/ansys-redhawk-sc — retrieved 2026-05-10 — RedHawk-SC IR-drop signoff to 3nm; cloud-native SeaScape platform; <10% silicon correlation.
[15] https://www.prnewswire.com/news-releases/ansys-3d-ic-power-integrity-and-thermal-solutions-certified-for-tsmc-3dblox-reference-flow-301660295.html — retrieved 2026-05-10 — TSMC 3Dblox certification for Ansys 3D-IC flow.
[16] https://www.cognitivemarketresearch.com/simulation-software-market-report — retrieved 2026-05-10 — simulation software market shares; Ansys ~25%+; top-5 ~55-60%.
[17] https://www.eetimes.com/cadence-bolsters-multiphysics-simulation-with-3-16bn-acquisition/ — retrieved 2026-05-10 — Cadence acquires Hexagon design unit ($3.16B); prior Beta CAE deal ($1.24B); Siemens-Altair ($10.6B).
[18] https://investor.synopsys.com/news/news-details/2026/Synopsys-Posts-Financial-Results-for-First-Quarter-Fiscal-Year-2026/default.aspx — retrieved 2026-05-10 — Q1 FY26 revenue $2.41B; FY26 guide $9.56–9.66B; Ansys contribution $2.9B; EPS guide $14.38–14.46.
[19] https://www.stocktitan.net/news/SNPS/synopsys-posts-financial-results-for-first-quarter-fiscal-year-ika7xvp784c5.html — retrieved 2026-05-10 — Design Automation +96% YoY (47.3% adj. op margin); Design IP -6.5% (16.2% adj. op margin).
[20] https://futurumgroup.com/insights/synopsys-q1-fy-2026-earnings-highlight-eda-and-ansys-momentum/ — retrieved 2026-05-10 — Ansys $886M Q1; $400M run-rate synergy target by year 4.
[21] https://s201.q4cdn.com/778493406/files/doc_earnings/2026/q1/supplemental-info/Synopsys-Q1-FY2026-Financial-Supplement.pdf — retrieved 2026-05-10 — Synopsys financial supplement (segment detail).
[22] https://investors.ansys.com/news-releases/news-release-details/ansys-announces-q4-and-fy-2024-financial-results — retrieved 2026-05-10 — Ansys standalone FY24 revenue $2.545B; ACV $2.563B; non-GAAP op margin 45.7%.
[23] https://www.engineering.com/ansys-q4-revenue-up-47-to-882m-with-283m-profit/ — retrieved 2026-05-10 — Q4 2024 ACV growth +15% reported.
[24] https://www.stockopedia.com/share-prices/ansys-NSQ:ANSS/ — retrieved 2026-05-10 — shows $374.30 "ANSS price" that is the deal-implied conversion value, not a tradeable quote.
[25] https://stockanalysis.com/stocks/snps/statistics/ — retrieved 2026-05-10 — SNPS forward P/E ~33.6×; EV/EBITDA ~65; current price $516.48; market cap $98.94B.
[26] https://www.marketbeat.com/stocks/NASDAQ/SNPS/forecast/ — retrieved 2026-05-10 — SNPS 14-analyst consensus $557.86 average price target; "Buy".
[27] https://public.com/stocks/snps/forecast-price-target — retrieved 2026-05-10 — SNPS consensus targets and recent revisions; some firms cut by ~$70.
[28] https://news.synopsys.com/2026-04-27-Synopsys-Announces-Earnings-Release-Date-for-Second-Quarter-Fiscal-Year-2026 — retrieved 2026-05-10 — Q2 FY26 print date confirmed 27 May 2026.
[29] https://news.synopsys.com/2025-09-24-Synopsys-Collaborates-with-TSMC-to-Drive-the-Next-Wave-of-AI-and-Multi-Die-Innovation — retrieved 2026-05-10 — 3DIC Compiler supports TSMC SoIC-X and CoWoS at 5.5× reticle interposers; HFSS-IC/RedHawk integration.
[30] https://www.hpcwire.com/off-the-wire/synopsys-partners-with-tsmc-to-power-next-gen-ai-systems-with-silicon-proven-ip-and-certified-eda-flows/ — retrieved 2026-05-10 — Synopsys/TSMC certified AI flows; foundry partnership context.
[31] https://convergedigest.com/synopsys-expands-tsmc-collaboration-for-ai-chip-design-3dic-and-cpo/ — retrieved 2026-05-10 — COUPE photonic flow uses Zemax + Lumerical + HFSS-IC + RedHawk-SC Electrothermal.
[32] https://github.com/NVIDIA/physicsnemo — retrieved 2026-05-10 — PhysicsNeMo is open-source physics-ML framework (PINNs, neural operators, GNN).