I have sufficient research material. Writing the dossier now.

# QCOM — Qualcomm Incorporated

## Where this sits in the AI stack

Qualcomm is primarily a **fabless mobile SoC and wireless-IP licensor** — its physical product is the Snapdragon family of integrated SoCs (CPU + GPU + Hexagon NPU + Adreno + modem) for handsets, PCs (Snapdragon X), automotive (Snapdragon Ride), and XR, plus its 3G/4G/5G standard-essential patent (SEP) portfolio licensed via QTL [4][9]. Its newly disclosed AI exposure is the **AI200/AI250 rack-scale inference accelerators** — LPDDR-memory-based, Hexagon-NPU-derived ASICs targeting inference-only data-center workloads, with first commercial deployment with Saudi Arabia's HUMAIN in 2026 [2][3][12]. QCOM does *not* meaningfully participate in frontier training, scale-up NVLink-class fabrics, HBM-bound throughput inference, or merchant CPU servers today; it is an edge-inference / mobile-NPU company attempting a back-door entry into data-center inference via memory-capacity arbitrage rather than peak FLOP/s.

## Snapshot

- **Price:** $219.09 (2026-05-08 close — May 10 is a Sunday) [1][15]
- **Market cap:** $230.9B [1][15]
- **52-week range:** ~$135 – $233 (inferred from +51.8% trailing-12-month return and recent highs reported by data providers) [15] — *exact published range not retrievable in single feed*
- **Forward P/E:** 22.4× on consensus FY EPS (≈$9.75) [15]
- **EV / NTM revenue:** 5.5× [15]
- **Consensus 12-month price target:** ~$174–$180 (implied **−18% to −20%** vs. spot) [13][14]
- **YTD total return:** approximately **+30–40%** (inference from year-end 2025 ~$155 prints; not directly retrievable) [1]
- **Short interest (% of float):** 4.6% [15]

Note: the negative implied return to consensus PT is a real signal — sell-side has not caught up to the post-AI200-announcement and Snap/AR rally [21]; the run-up is largely retail and momentum, not analyst-led.

## Moat — what it is physically made of

The "Qualcomm moat" is not one moat; it is four assets of very different durability.

**1. Wireless SEPs (QTL).** The hardest asset. QCOM holds the top "Patent Asset Index" position in cellular standards; QTL generated **$5.6B in FY24 revenue at ~72% EBT margin**, roughly **30% of company profit** [9][8]. Licenses run to >150 licensees including Huawei (Huawei pays ~$1.8B/yr) [9]. Durability: 10+ years on existing 5G stack; 6G is positioned as evolutionary (not a clean reset). Falsifier: Huawei filed **6.5× more 5G-era patents** than QCOM between 2015–2026 [9] — the per-unit royalty rate, not just the licensee count, will be re-tested in 6G negotiations.

**2. Hexagon NPU IP.** Hexagon is a hybrid VLIW + HVX vector + HMX tensor architecture with 6–8 hardware threads, scalar/vector/tensor ISAs, evolved over 15 years for mobile power envelopes [10]. The AI200/AI250 are the *first* attempt to scale this architecture to ~250W rack cards [3][7]. Real strength: **perf/watt** at int8/int4. Real weakness: the kernel/compiler stack (QNN Execution Provider, AI Hub, ONNX path) [22] has nowhere near CUDA's footprint — there is no equivalent of cuDNN/CUTLASS/NCCL with ten years of fused-kernel hardening and ~4M developers. vLLM and PyTorch integration is announced but production scale unproven outside Hexagon-on-handset.

**3. Oryon CPU (from Nuvia, $1.4B, 2021).** Custom ARMv8 microarchitecture — Qualcomm states <1% of Arm reference IP remains in the cores [20]. Powers Snapdragon X Elite (now ~10% of US >$800 Windows laptop retail by Circana) [6] and X2 Elite (CES 2026, up to 80 TOPS NPU). Qualcomm won the ARM lawsuit, confirming use of Nuvia-derived cores [20]. Durability: real and growing in PC; data-center Oryon is the *intended* differentiator vs. ARM Neoverse reference designs (a Centriq lesson, see below). Person-years to replicate at parity: Apple+Nuvia took roughly 5–7 years from a clean sheet.

**4. Automotive Snapdragon Ride / Cockpit.** $1.33B Q2 FY26 (+38% YoY); **$45B disclosed design-win pipeline**; BMW Neue Klasse (iX3) launched on Snapdragon Ride Pilot with **jointly-developed software stack** [11][16]. Bosch partnership extended to ADAS [11]. Durability: 7–10 year design-cycle lock-in once a model platform ships; switching cost is genuinely high for OEMs once safety validation is complete.

**What is *not* moat:** the AI200/AI250 software ecosystem, hyperscaler customer breadth, multi-node fabric IP (Ethernet/PCIe scale-out is not differentiated; the Alphawave SerDes acquisition closed Dec 2025 [17] is *acquiring* the missing piece, not defending an existing one), and HBM/CoWoS supply (QCOM bypasses this — see below).

## AI buildout bottleneck map

The 24-month gating constraints and Qualcomm's position on each:

| Bottleneck | Status | QCOM position |
|---|---|---|
| **HBM3e/HBM4 supply** | Single tightest input; ~$10–15/GB and oversubscribed through mid-2026 [5][7] | **Beneficiary by avoidance** — AI200 uses LPDDR5X (~$2–4/GB) [7]; no HBM allocation needed |
| **CoWoS-L packaging** | TSMC capacity doubling but oversubscribed through 2026 [5] | **Beneficiary by avoidance** — LPDDR-on-package does not require CoWoS-L; AI200 ships independently of NVDA/AMD allocation queue |
| **Power & grid** | 160 kW direct-liquid-cooled racks for AI200 [2][3]; similar density to GB300/Helios | Indifferent — same constraint as all rack-scale players |
| **Optical interconnect / 224G SerDes** | Required for 1.6T scale-out switching [17] | Was a gap; Alphawave acquisition (Dec 2025, $2.4B) [17] is the explicit fix |
| **Kernel/compiler talent** | CUDA has ~4M devs; ROCm ~100k; QNN/AI Hub far smaller | **Constraint owner** — this is QCOM's largest moat *deficit*; vLLM/ONNX/PyTorch support announced [22] but enterprise-grade serving for 100B+ param models on Hexagon is unproven outside HUMAIN |
| **HBM3e price flowing into handset BOMs** | Memory price spike pressuring handset OEM build plans, esp. China [19] | **Exposed customer** — already cited by management as a Q2 FY26 handset weakness driver [19] |
| **Frontier training data / RL compute** | Constraint at the frontier labs | Indifferent — QCOM does not sell into training |

The key non-obvious read: **HBM scarcity is structurally good for AI200 economics.** A 400B-parameter FP16 model fits in *one* 768GB AI200 card vs. 3× B200s or 5× H100s [7]. The trade-off is throughput-per-card — LPDDR5X aggregate bandwidth is a fraction of HBM3e's ~3.35 TB/s [7]. This is a real architectural bet that **memory-capacity-bound inference (long-context KV cache, large MoE experts on chip, batch-1 latency-sensitive workloads)** is a defensible niche even if frontier batched-throughput workloads stay on NVDA.

## Competitive teardown

The relevant axes are inference-specific. Qualcomm does not compete in training and should not be evaluated as if it does.

**vs. NVIDIA (Blackwell Ultra GB300 / Vera Rubin NVL72).** GB300 NVL72 delivers **1.1 EFLOPS FP4** at ~145 kW [4]; Vera Rubin NVL72 (H2 2026) targets **3.6 EFLOPS FP4**, 20.7 TB HBM4, 50 PFLOPS FP4/chip [4]. AI200 per-card FLOPS not publicly disclosed; NextPlatform's modeling implies ~983 PFLOPS over the 1,250-rack HUMAIN deployment vs. roughly equivalent FP4 throughput from ~14× GB300 racks at much higher capital cost [3]. On **throughput per dollar for memory-capacity-bound inference**, AI200 may genuinely win. On **token/s for batched generation of frontier models**, Rubin wins by a wide margin and is the safe choice for hyperscalers. Software gap is structural — no CUDA-parity option exists.

**vs. AMD (MI400 / Helios, Q3 2026).** Helios delivers **2.9 EFLOPS FP4 inference / 1.4 EFLOPS FP8 training** with 31 TB HBM4 per rack on TSMC N2 [18]. AMD is the more direct merchant competitor on the *same axis as NVDA* (HBM-bound, training + inference, ROCm). AMD has reached parity on raw FLOPS but lags on software; QCOM does not compete with AMD directly — different memory architecture and different workload target.

**vs. Broadcom (custom ASIC / Google TPU).** This is the genuinely important competitor. Broadcom captures ~60% of the AI ASIC market and is projected at **~$40B AI revenue in FY26** [23], including $21B from the Google TPU program through 2031 [23]. Hyperscalers building custom silicon with Broadcom and Marvell *is* the bear case for any merchant inference accelerator — including QCOM AI200. Qualcomm's own response is dual-track: announced custom-silicon engagement with one large hyperscaler in addition to merchant AI200/AI250 [12]. "All of the above" per Amon — credible but unproven; one disclosed customer.

**vs. in-house hyperscaler (AWS Trainium/Inferentia, Google TPU, Microsoft Maia).** Same point. Hyperscalers prefer to insource; merchant share at the long-context inference end of the market will be contested by Trainium2/3 and TPU v7.

**Base rate on platform displacement.** ARM-on-server has been "two years out" for a decade; Centriq (Qualcomm's 2017 attempt) reached Microsoft Azure pilot then was killed in 2018 — ecosystem and software depth, not silicon, were the failure modes [24]. AMD took ~5 years from EPYC Naples (2017) to credible Xeon displacement (~25% server CPU share by 2024). NVIDIA's CUDA moat took ~15 years to build and shows no real signs of yielding to OpenAI Triton or Mojo. Base rate for a new merchant inference entrant reaching 5% data-center share within 24 months is low.

## Bull case — technical

The thesis that makes QCOM work over the next 24 months requires four technical conditions:

1. **Inference workloads continue to shift toward memory-capacity-bound regimes** — long context (1M+ tokens), large MoE expert tables on-chip, batch-1 reasoning models. If KV-cache and weight footprint dominate, LPDDR-per-dollar is a winning architecture and AI200's 768 GB/card is a *feature*, not a compromise [7].
2. **HBM/CoWoS supply stays tight through 2027.** TSMC CoWoS-L capacity doubles, but demand outruns supply through at least mid-2026 [5]. Every quarter that NVDA and AMD are allocation-rationed, QCOM's LPDDR architecture is the *only* incremental capacity sovereigns and second-tier clouds can buy at scale. HUMAIN's 200 MW is the proof point [3].
3. **Software stack reaches "good enough" for non-frontier inference.** ONNX/vLLM/PyTorch path needs to deliver within 1.5× of vLLM-on-NVDA for common open-weight models (Llama-class, Qwen-class) [22]. Not parity — just enough that sovereign and second-tier customers don't have to staff a CUDA team.
4. **Auto + PC + sovereign-inference combined growth offsets handset/Apple cliff.** Auto $5B annualized run rate, $45B pipeline [11][16]; Snapdragon X at 10% share of >$800 Windows laptops with X2 Elite ramping [6]. If these grow at ~25% blended through FY28, they re-replace the Apple modem revenue (~$3–4B) and China handset softness.

**Financial outcome under bull:** AI200 reaches $2–3B run rate by FY28; auto grows to $7B; PC scales; QTL holds at $5–6B. FY28 revenue ~$48–52B, EPS ~$12. At 22× that is ~$265 — modest upside from $219, with optionality if the hyperscaler custom-silicon engagement materializes.

## Bear case — technical

Symmetric, and probably the better-supported case.

1. **AI200 ships, but no second flagship customer emerges in 2026.** HUMAIN is sovereign-political, not a technical win — it is a vehicle for Saudi capital deployment and US-Saudi alignment, not a vote of confidence by an inference-economics-driven buyer. Adobe is the announced first *workload* customer; one workload at one site is not commercial traction [25][12].
2. **The LPDDR memory-bandwidth gap shows up at production scale.** A 400B model fits on one card, but actual tokens/s/$ may be uncompetitive vs. Rubin once test-time-compute / long-context-prefill workloads stress bandwidth. AI250's "near-memory compute" claim of 10× effective bandwidth [3] is unverified; chip is 2027.
3. **Software ecosystem never reaches escape velocity.** This is the Centriq replay risk [24]. Mobile Hexagon developers do not transfer cleanly to data-center inference workloads. Without a vLLM-on-Hexagon production reference with public throughput numbers from a Tier-1 hyperscaler, enterprise adoption stalls.
4. **Apple modem step-down is sharper than guided.** Apple to take ~20% of iPhones on Qualcomm in 2026 and **zero by 2027** [25][26]. At ~$23/modem + $8 royalty across ~230M iPhones, that is ~$7B of revenue at >70% gross margin walking out the door [26]. Auto + PC + AI200 ramp must replace this on a roughly two-year clock.
5. **Handset memory cost squeeze persists.** HBM-driven memory price inflation is pressuring Android OEM build plans in China today, per QCOM's own Q2 FY26 commentary [19]. This is a *direct negative* from the same AI infrastructure boom QCOM is trying to participate in as a supplier. Same trend, opposite signs in different segments.
6. **Hyperscaler in-house silicon takes the AI200 TAM.** Broadcom's $40B FY26 AI revenue [23] tells you where the merchant share is going. The Qualcomm custom-silicon engagement [12] could be additive, but disclosed as "one hyperscaler" — single point of failure.

**Financial outcome under bear:** Handset declines $4–5B over 18 months; AI200 reaches sub-$1B run rate by FY28; QTL flat. FY28 revenue ~$40–42B, EPS ~$9. At a derating to 15× on a "stranded mobile" narrative, ~$135 — roughly **40% downside**.

## Market view check

At $219 / 22.4× forward / 5.5× EV-NTM-revenue, QCOM trades at a slight discount to the merchant semi composite (~25× forward) and *above* its pre-AI-narrative range (15–18× in 2022–2024). Consensus PT of ~$174 [13][14] is below spot, meaning sell-side has not endorsed the run-up — the marginal buyer is paying for AI200 optionality and Snap/AR partnership headlines [21]. The market is implicitly betting that **(a) the Apple modem cliff is offset by auto + PC growth, and (b) AI200 wins a non-trivial slice of memory-capacity-bound inference**. It is **not** pricing in successful displacement of NVDA in any large workload. That seems roughly right on a probability-weighted basis — but it leaves little margin for the bear case (Centriq-replay software failure, slower hyperscaler diversification away from NVDA) which the technical history says is the modal outcome.

## 90-day falsifiers

- **Q3 FY26 earnings (late July 2026).** Watch for: handset bottoming in China (management called the bottom); auto growth rate (must hold >30% YoY to defend the pipeline narrative); any disclosed AI200 unit shipments or revenue contribution; commentary on second hyperscaler custom-silicon engagement.
- **Hyperscaler capex prints (late July).** Microsoft, Google, Meta, Amazon Q2 reports; combined 2026 capex run-rate to $700B+ [27]. A sequential cut >10% in any of the four would crater the AI hardware complex including QCOM's optionality. An *increase* in announced 2027 plans is bullish for AI200 sovereign customers.
- **HUMAIN AI200 deployment progress.** 200 MW target for 2026 [3]; any public confirmation of AI200 (not just AI100) racks in production at HUMAIN, Adobe inference workload throughput numbers, or independent benchmark publication.
- **iPhone 18 launch (Sept 2026).** Confirms C2 modem in Pro models — if Apple takes >80% Apple modems on its own silicon, the FY27 Apple revenue is essentially zero [26].
- **Any second AI200 customer disclosure** (Oracle, CoreWeave, sovereign cloud, Meta side-deployment). Single-customer-concentration risk falls fast on second name.
- **Snapdragon X2 Elite shipping designs and PC market share data** (Q3 retail prints) — sustaining or breaching 10% of >$800 Windows segment [6].
- **MLPerf Inference v5.x submission with AI200.** Absent or weak submission would be a strong negative signal on software stack readiness.

## What I could not verify

- **AI200 peak FP8/FP4 FLOPS, exact NPU core count, process node, per-card power, aggregate LPDDR5X bandwidth.** Public spec sheet does not disclose; analyst estimates (32 cores, 5nm, 250W) are speculation [3].
- **AI250 near-memory-compute "10× effective bandwidth" claim.** No independent benchmark exists; chip is 2027.
- **Per-token economics of AI200 vs. GB300 on production inference** for any specific workload. No public head-to-head.
- **The named "large hyperscaler" in Amon's custom-silicon engagement.** Speculation has named Meta and a sovereign; not confirmed [12].
- **Exact Apple revenue contribution to QCOM today** — the $7B figure is analyst-pieced from modem + royalty + handset units, not disclosed by QCOM [25][26].
- **Q1 FY26 stand-alone data-center segment revenue.** QCOM does not break out AI200/AI100/Cloud AI as a segment; it sits inside QCT.
- **Exact 52-week range and YTD return** — recent close confirmed at $219.09 [1][15], but a clean published 52w high/low and YTD figure was not retrievable in a single feed and is inferred.

## Sources

[1] https://finance.yahoo.com/quote/QCOM/ — retrieved 2026-05-10 — confirms QCOM at ~$219 price level May 2026
[2] https://www.datacenterdynamics.com/en/news/qualcomm-launches-ai200-and-ai250-chip-offering-targeting-inferencing-workloads-at-rack-scale/ — retrieved 2026-05-10 — AI200/AI250 announcement, 160kW rack, PCIe scale-up, Ethernet scale-out, direct liquid cooling
[3] https://www.nextplatform.com/2025/10/28/how-qualcomm-can-compete-with-nvidia-for-datacenter-ai-inference/ — retrieved 2026-05-10 — technical breakdown of AI200 economics, HUMAIN 200MW comparison vs. GB300, AI250 near-memory compute claim
[4] https://www.nvidia.com/en-us/data-center/vera-rubin-nvl72/ and https://www.nvidia.com/en-us/data-center/gb300-nvl72/ — retrieved 2026-05-10 — GB300 NVL72 1.1 EFLOPS FP4 / 145 kW, Vera Rubin NVL72 3.6 EFLOPS FP4 H2 2026
[5] https://newsletter.semianalysis.com/p/ai-capacity-constraints-cowos-and — retrieved 2026-05-10 — CoWoS and HBM as binding constraints through mid-2026
[6] https://www.tomshardware.com/tech-industry/qualcomm-claims-it-owns-10-percent-of-u-s-windows-pc-retail-market-for-devices-priced-usd800-and-up — retrieved 2026-05-10 — Snapdragon X 10% share of US >$800 Windows laptops (Circana)
[7] https://wccftech.com/qualcomm-new-ai-rack-scale-solution-actually-uses-lpddr-mobile-memory-onboard/ and https://www.hpcwire.com/2025/10/28/qualcomm-takes-on-nvidia-amd-with-new-ai-accelerator-cards/ — retrieved 2026-05-10 — LPDDR5X vs. HBM3e per-GB cost, 768GB capacity, bandwidth trade-off
[8] https://blog.withedge.com/p/the-secret-behind-qualcomms-margins — retrieved 2026-05-10 — QTL revenue and EBT margin economics
[9] https://www.lightreading.com/5g/huawei-and-qualcomm-tussle-for-5g-patents-lead-as-6g-draws-closer and https://www.patsnap.com/resources/blog/articles/huawei-vs-qualcomm-5g-patent-strategy-6-51-ratio/ — retrieved 2026-05-10 — QCOM Patent Asset Index #1; Huawei 6.5× more 5G filings; Huawei licensing $630M vs QTL $5.6B
[10] https://thechipletter.substack.com/p/qualcomms-hexagon-ai-accelerators and https://www.hc2023.hotchips.org/assets/program/conference/day2/ML%20Inference/HC2023%20Qualcomm%20Hexagon%20NPU.pdf — retrieved 2026-05-10 — Hexagon NPU VLIW + HVX/HMX architecture, Hot Chips 2023 disclosure
[11] https://www.qualcomm.com/news/releases/2025/09/qualcomm-and-bmw-group-unveil-groundbreaking-automated-driving-s and https://www.wardsauto.com/news/qualcomm-to-collaborate-with-bosch-vehicle-adas-systems-snapdragon/817348/ — retrieved 2026-05-10 — BMW Neue Klasse co-developed software stack, Bosch ADAS partnership
[12] https://www.theregister.com/2026/05/01/qualcomm_q2_fy_26/ and https://cloudnews.tech/qualcomm-prepares-its-return-to-data-centers-with-custom-silicon-for-hyperscale/ — retrieved 2026-05-10 — Amon Q2 FY26 commentary on hyperscaler custom-silicon engagement, "all of the above" strategy
[13] https://www.marketbeat.com/stocks/NASDAQ/QCOM/forecast/ — retrieved 2026-05-10 — consensus PT ~$180
[14] https://stockanalysis.com/stocks/qcom/forecast/ — retrieved 2026-05-10 — consensus PT ~$174
[15] https://stockanalysis.com/stocks/qcom/statistics/ — retrieved 2026-05-10 — forward P/E 22.4×, EV/NTM rev 5.5×, market cap $230.9B, short interest 4.6%, +51.8% trailing-12-month return
[16] https://futurumgroup.com/insights/qualcomm-q2-fy-2026-earnings-show-data-center-entry-and-auto-strength/ and https://s204.q4cdn.com/645488518/files/doc_financials/2026/q2/FY2026-2nd-Quarter-Earnings-Release.pdf — retrieved 2026-05-10 — Q2 FY26 segment revenues: handsets $6B (−13%), auto $1.33B (+38%), IoT $1.73B (+9%), QTL $1.4B at 72% EBT
[17] https://www.networkworld.com/article/4003852/qualcomms-2-4b-alphawave-deal-signals-bold-data-center-ambitions.html and https://convergedigest.com/qualcomm-completes-alphawave-semi-acquisition-accelerates-data-center-push/ — retrieved 2026-05-10 — Alphawave $2.4B closed Dec 2025, SerDes/UCIe rationale, 224G for 1.6T switching
[18] https://www.tomshardware.com/tech-industry/artificial-intelligence/amd-touts-instinct-mi430x-mi440x-and-mi455x-ai-accelerators-and-helios-rack-scale-ai-architecture-at-ces and https://newsletter.semianalysis.com/p/amd-advancing-ai-mi350x-and-mi400-ualoe72-mi500-ual256 — retrieved 2026-05-10 — Helios MI455X 2.9 EFLOPS FP4 / 1.4 EFLOPS FP8 / 31 TB HBM4, UALink scale-up, Q3 2026
[19] https://www.fool.com/earnings/call-transcripts/2026/04/29/qualcomm-qcom-q2-2026-earnings-transcript/ — retrieved 2026-05-10 — Q2 FY26 transcript: China handset OEM build plan cuts driven by memory cost spike, Apple step-down in Sept quarter
[20] https://www.tomshardware.com/pc-components/cpus/qualcomm-says-its-oryon-cpu-cores-have-1-percent-or-less-of-arms-original-technology-cores-in-snapdragon-x-pc-chips-are-almost-entirely-custom and https://www.tomshardware.com/pc-components/cpus/qualcomm-scores-big-win-over-arm-in-contentious-lawsuit-u-s-court-rejects-arms-lawsuit-confirms-qualcomms-can-use-oryon-cores-acquired-via-nuvia — retrieved 2026-05-10 — Oryon custom microarchitecture, ARM lawsuit outcome
[21] https://247wallst.com/investing/2026/05/07/qualcomm-climbs-8-as-buyback-snap-ar-partnership-power-pivot-beyond-smartphones/ — retrieved 2026-05-10 — Snap AR multi-year deal, buyback announcement driving recent rally
[22] https://www.tomshardware.com/tech-industry/artificial-intelligence/qualcomm-unveils-ai200-and-ai250-ai-inference-accelerators-hexagon-takes-on-amd-and-nvidia-in-the-booming-data-center-realm and https://onnxruntime.ai/docs/execution-providers/QNN-ExecutionProvider.html — retrieved 2026-05-10 — vLLM/ONNX/PyTorch/LangChain/CrewAI support for AI200; QNN Execution Provider state
[23] https://oplexa.com/broadcom-google-tpu-deal-2026/ and https://tech-insider.org/broadcom-ai-revenue-custom-chips-2026/ — retrieved 2026-05-10 — Broadcom ~60% AI ASIC share, ~$40B FY26 AI revenue, $21B from Google through 2031
[24] https://chipsandcheese.com/p/qualcomms-centriq-2400-and-the-falkor and https://www.fool.com/investing/2018/12/21/4-reasons-qualcomms-data-center-business-failed.aspx — retrieved 2026-05-10 — Centriq launch, Microsoft pilot, 2018 shutdown, team reduced from ~1000 to ~50
[25] https://www.middleeastainews.com/p/humain-deploys-1024-qualcomm-ai-100 and https://www.qualcomm.com/news/releases/2025/10/humain-and-qualcomm-to-deploy-ai-infrastructure-in-saudi-arabia- — retrieved 2026-05-10 — HUMAIN 1,024 AI100 systems delivered, 200MW target 2026, Adobe first workload customer, AI200 integration planned
[26] https://www.telecomstechnews.com/news/iphone-c1-modem-chip-to-cut-apples-qualcomm-reliance-by-80/ and https://www.webpronews.com/apple-to-debut-in-house-c2-modems-in-iphone-18-pro-by-2026/ and https://www.ainvest.com/news/apple-c1-modem-catalyst-qualcomm-decline-semiconductor-shifts-2505/ — retrieved 2026-05-10 — Apple modem transition: ~20% Apple share in 2026, zero in 2027; ~$23 modem + $8 royalty per device pre-transition
[27] https://www.cnbc.com/2026/02/06/google-microsoft-meta-amazon-ai-cash.html and https://www.tomshardware.com/tech-industry/big-tech/big-techs-ai-spending-plans-reach-725-billion — retrieved 2026-05-10 — 2026 hyperscaler capex: Amazon $200B, Alphabet $185B, Meta $125–145B, Microsoft $190B; combined ~$700B, ~75% AI