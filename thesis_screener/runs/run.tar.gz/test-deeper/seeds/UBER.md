All research in. Writing the dossier now.

# UBER — Uber Technologies, Inc.

## Where this sits in the AI stack
UBER sits at the **application/marketplace layer** — it does not design silicon, build models at the frontier, or operate AI training infrastructure. Its AI-relevant exposure is two-fold: (1) it runs a large in-house ML platform (Michelangelo, ~5,000+ production models, ~15M predictions/sec) for matching, ETA, surge pricing, and fraud, atop OCI and GCP[27][30]; (2) it is the **demand-aggregation layer** sitting in front of every credible Level-4 robotaxi operator outside Tesla — Waymo, Wayve, WeRide, Pony, Avride, Nuro/Lucid, Volkswagen MOIA, May Mobility, Momenta — and the customer-facing brand for Aurora-driven autonomous trucking via Uber Freight[14][13][17][18][19]. The investment question is not "is Uber an AI company" — it isn't. It is: does the marketplace layer survive the AV transition, or does the vehicle owner go direct.

## Snapshot
- **Price:** $75.45 (2026-05-08 close; May 9 was a non-trading day)[4]
- **Market cap:** ~$153.6B[4]
- **52-week range:** $68.46 – $101.99[4]
- **Forward P/E:** ~20.5× (FY26 consensus EPS ~$3.32 non-GAAP)[4][6]
- **EV / NTM revenue:** ~2.55× (derived: LTM EV/Rev 2.8× per Multiples.vc on $53.7B LTM revenue, applied ~14% growth — not directly disclosed)[7]
- **Consensus 12-mo PT:** $107.79 (~+43% from price)[5]
- **YTD total return:** ~-9%[8]
- **Short interest:** ~2.75% of shares outstanding (low; not contested)[4][5]
- **Q1 2026 print (May 6, 2026):** Revenue $13.2B (+14%), Gross Bookings $53.7B (+25%), MAPCs 199M (+17%), Trips 3.64B (+20%), Adj. EBITDA $2.48B (+33%), FCF $2.29B[1][2]
- **Mobility take rate:** ~29.9% (last disclosed Q4'25; Q1'26 not published in supplemental)[1]

## Moat — what it is physically made of
Decompose into the components that actually exist:

**1. Demand aggregation (highest durability).** 199M monthly active platform consumers, ~50M Uber One members, and dominant verbed-brand consumer recall in rideshare across North America, Western Europe, India, and Latin America[1]. Replication cost is roughly **$15–25B of cumulative net subsidy over a decade** (the historical Uber/DiDi/Grab/Lyft burn) plus regulatory clearance in each jurisdiction. This is what AV operators are buying when they sign with Uber.

**2. Marketplace algorithms (high durability, narrow scope).** Open-sourced **H3 hexagonal indexing** is the geospatial substrate; batch matching solves bipartite minimum-cost assignment over short windows at ~30M match-pair predictions/min; **DeepETA** (transformer-style network combining router output with live state) is the disclosed ETA stack[27][28]. These are not unique algorithms — H3 is open-source and Lyft/DoorDash/Bolt run conceptually similar systems — but the **calibration data** (years of trip outcomes per H3 cell per hour-of-week) is proprietary and only meaningful at scale. A competitor with the algorithm but without the data underperforms on first-mile pickup ETA in exactly the way that drives churn.

**3. Network density per geography (medium durability, **local** only).** The classic Uber flywheel — more drivers in a hex → shorter pickup → higher utilization → lower price → more demand — is real, **but it saturates near zero wait time**, so the marginal advantage of Uber over Lyft in mature US metros is much smaller than the share gap suggests[31][32]. Density advantages are also **per-city**, not global; Uber must rebuild liquidity in each new market individually.

**4. Multi-product platform leverage (medium durability).** Shared identity, payments, maps, H3 substrate, and the Marketplace/Fulfillment Platform across Rides, Eats, Freight. Driver/courier pool is partially fungible (the existence of an unauthorized account-rental market at $300–500/month proves the asset is interchangeable)[27]. ~40% of bookings tied to Uber One bundling.

**5. Insurance and risk underwriting (medium durability).** Uber carries one of the largest US commercial auto insurance books, giving actuarial scale that smaller competitors and most AV operators do not have. Management is guiding to "**hundreds of millions of dollars**" of US Mobility insurance savings in 2026, flowing into price reductions — this is real and structural[2].

**6. Patents (low durability, defensive only).** ~3,060 patents globally, 1,832 active, recent grants in pickup-point assistance and merchant order routing[33]. None of these are the moat; they are insurance against IP claims.

**Honest read:** the moat is **demand aggregation + the local-density flywheel + the brand habit**. It is not a technical moat in the silicon sense. CUDA replicates with $30B and a decade. Uber's consumer base would replicate with cash *and* time *and* regulatory access — the time component is the binding constraint.

## AI buildout bottleneck map
Uber is a **negligible participant** in the physical AI buildout — it is not a top-100 GPU buyer, has no HBM/CoWoS exposure, no power-grid exposure, no liquid-cooling exposure. Its relevant bottlenecks are different:

- **AV vehicle production capacity:** Hyundai Metaplant Georgia is targeting ~50K Ioniq 5 for Waymo (ramps end-2026); Zeekr RT (Geely, Sweden-finished) is the 6th-gen Waymo platform; VW ID. Buzz from Hannover. Tesla's Cybercab at Giga Texas reportedly hit ~2K/week with a 10K/week 2026 target[22][34][36][37]. **Uber position: indifferent buyer** — benefits from any operator scaling, agnostic on which.
- **AV regulatory throughput:** State-by-state. Texas SB 2807 in force May 2026, California finalizing safety-case framework July 2026, federal SELF DRIVE Act 2026 (HR 7390) introduced but not enacted[26]. **Uber position: beneficiary** — fragmented patchwork favors a marketplace overlay; federal preemption would slightly reduce that advantage by lowering AV operator deployment cost.
- **Fleet operations capacity (charging, depot, cleaning):** Hertz/Oro, Moove, Avis, Flexdrive are the actual operators behind the AV deployments. Uber announced **$100M+ for AV-specific DC fast-charging hubs**[24]. **Uber position: partial owner of constraint** — capital-intensive but commoditizing.
- **Driver supply:** 10M+ drivers/couriers globally, hybrid AV+human handoff is part of the product story. **Uber position: beneficiary** of Prop 22-style 1099 classification (upheld CA Supreme Court Jul 2024)[39]; falsified by reclassification rulings.
- **AI compute for Uber's own ML:** Run on OCI/GCP via co-design with Ampere (~30% power reduction vs prior CPU)[30]. Not capacity-constrained at current scale.

## Competitive teardown

**Waymo (the most important comp).** Waymo runs ~450–500K paid trips/week (Apr 2026) toward a 1M/week YE26 target[9]. **Critical fact: every Waymo city launched since Atlanta has been Lyft or direct Waymo app — not Uber.** Nashville is Lyft+Waymo[11]; Miami uses Moove for fleet ops; Dallas uses Avis; DC/Denver/Seattle/Boston/NYC plans are direct[10][12]. London will be the first market where Waymo's own app and Uber's Wayve robotaxis compete head-to-head[13]. The cooling is unambiguous in revealed preference even if both parties stay diplomatic. Waymo's 6th-gen "Ojai" hardware reportedly costs **<$20K atop the vehicle** (vs ~$100K on Jaguar I-Pace), with the Zeekr base around $75K — a >50% unit cost reduction[15][35]. As Waymo unit economics improve, the rationale for sharing margin with Uber weakens.

**Tesla (the most important asymmetric threat).** Cybercab in production at Giga Texas Q2'26, ~2K/wk ramping toward 10K/wk YE26, exempt from NHTSA's 2,500/yr AV cap because it is FMVSS-compliant[36][37]. Robotaxi service in Austin (June 2025), Bay Area (supervised, July 2025), Dallas/Houston (April 2026). Independent counts (Electrek, Feb 2026) put the **unsupervised** fleet at ~25 cars across three Texas cities — far below Musk's claims[20]. Tesla undercuts Uber by ~60% in Austin (Jefferies dual-rider study)[21]. Stated cost target: **$0.20–0.40/mile** vs ~$0.70–1.50 for human ride-hail[38]. The threat is not today's volume; it is the combined vertical integration (vehicle + chip + autonomy + 5M+ existing customer fleet that can flip into Tesla Network) and willingness to subsidize. Khosrowshahi's Q1'26 line — "we don't see any effect of the Waymo launches on our overall business" — is plausibly true for now and approximately useless as a forward indicator[2].

**Lyft.** 24% US share, ~11× scale gap on bookings ($53.7B vs $4.9B Q1'26)[40][41]. Risher's customer-obsession + partnership strategy (Chase, DoorDash, United, Waymo Nashville, Holon, Mobileye Drive) is genuinely working for share retention but not closing the profitability gap (Uber Mobility EBITDA margin >8%, ~37% ROE; Lyft Q1'26 adj EBITDA $120–140M guide on $4.9B GB)[44]. Lyft's existence as a credible #2 actually **helps** Uber by giving AV operators a multi-homing alternative that prevents Uber from extracting too much.

**DoorDash.** ~56–67% US food delivery vs Uber Eats ~23%[42][43]. Q1'26 ad business >$1B annualized; new verticals (grocery) on track to gross-profit positive H2'26[42]. EV/Rev ~5.1× vs Uber ~2.8× LTM — DASH is priced as the growth/grocery/ads story, UBER as the AV-overhang story.

**International equity stakes (passive value).** Uber owns ~18% of DiDi and ~27.5% of Grab from operating-market exits — these are mark-to-market financial positions, not strategic levers.

## Bull case — technical
**Base rate on platform displacement.** Marketplaces with multi-sided liquidity at this scale (eBay, Booking, Airbnb, Amazon 3P) have **never been displaced by a vertically integrated supplier** — even when the supplier had compelling product (e.g., Toys R Us trying to leave Amazon, or hotels trying to bypass Booking via direct apps). The reason: the demand aggregator captures the **marginal user** who searches across options, and once a price comparison habit is established, even superior single-product apps lose share back to the aggregator over time. The case where the supplier wins is when the supplier's product is **strictly better and uniquely available** (Apple Stores vs CompUSA). Tesla's robotaxi could plausibly meet the "strictly better" bar; Waymo cannot, because it ships the same Ioniq/Zeekr that anyone can dispatch.

**Conditions for outperformance:**
1. AV operators (Waymo, Wayve, Nuro/Lucid, VW MOIA, WeRide, Pony) continue to multi-home rather than going single-app — supported by their own behavior in 2025–26 outside Waymo[3].
2. Uber's $10B AV commitment buys real fleet ops/charging/insurance scale that becomes a moat at the **operations** layer, not just demand[24].
3. Insurance savings ("hundreds of millions" 2026) flow to price → trips growth +20% sustains another 6–8 quarters[2].
4. Tesla Robotaxi remains supply-constrained (~25 unsupervised cars April 2026) for long enough that Uber consolidates AV multi-operator share[20].
5. Waymo's NYC/DC/Seattle launches go via Uber rather than direct (would falsify cooling thesis).

If all hold: 18%+ bookings growth, 35%+ EBITDA growth, FCF compounding past $10B by 2027 → multiple re-rates from ~20× to ~25× → ~$110 = consensus PT.

## Bear case — technical
**Base rate on technology cost-curve disruption.** When a new technology reduces unit cost by >50% with vertical integration (EV vs ICE, smartphone vs feature phone, streaming vs cable), incumbents that depend on the prior unit economics structurally lose. Robotaxi at $0.20–0.40/mile vs $0.70–1.50/mile is **exactly that** kind of curve, and the operator who owns the silicon + the autonomy + the vehicle + the fleet captures most of the surplus.

**Conditions for underperformance:**
1. Waymo NYC, DC, Seattle, Boston launches go **direct** (no Uber, no Lyft). Trips/week passes 1M YE26 with Waymo holding most of the per-trip economics. The Atlanta/Austin Uber partnerships look in retrospect like an early-scaling concession, not a durable model[3][10].
2. Tesla Cybercab production hits stated 10K/wk ramp by YE26, unsupervised fleet exceeds 5K, and Tesla Network sees first $1B annualized run-rate. The 5M+ existing Tesla customer fleet becomes available for the network without new capex[36].
3. Uber's "Swiss Army knife" Autonomous Solutions pitch (demand + fleet ops + financing for non-vertically-integrated operators) gets squeezed: vertically integrated players (Tesla, Waymo) don't need it; commodity operators (WeRide, Pony, Avride) get pushed off Uber by Lyft or by direct apps.
4. Insurance savings comp out by 2027 — they are largely a one-time benefit from claim-frequency improvement plus tort reform tailwinds, not a structural take-rate expansion.
5. Mobility take rate (29.9%) compresses as AV operators with credible direct-app alternatives extract better terms — even 200bps would be a ~$1.5B annual EBITDA hit at current GB.
6. Gig worker reclassification in any major US state (CA's Apr 2026 *Rideshare Drivers United* lawsuit is live)[39] adds 20–25% to driver cost in the affected geography.

If even **two** of (1), (2), (5) hit, fair value is closer to $55–65 (~16× a flatter EPS line).

## Market view check
At $75 / ~20× forward EPS / 2.55× EV/NTM revenue with bookings +25% and FCF +2% YoY, the market is pricing in **a real but not catastrophic AV disintermediation discount**. Pre-Waymo-Atlanta UBER traded above $85 at ~24×. The ~9% YTD drawdown plus the ~26% drawdown from $102 high reflects: (a) Waymo's evident shift toward direct-app and Lyft-partnership for new cities, (b) Tesla Cybercab production confirmation, (c) FCF growth deceleration to +2% YoY signaling capex absorption from the $10B AV plan. The +43% consensus PT reflects sell-side modeling the bull case (multi-operator partnership thesis works, 20%+ bookings growth durable). **The market disagrees with the sell-side, and on the technical substrate, the market is closer to right** — the revealed preference of every Waymo city launched since Atlanta is the dominant data point. Uber is not obviously cheap at $75; it is fair if you assume Tesla under-executes *and* Waymo's cost curve flattens. Both are possible; neither is guaranteed.

## 90-day falsifiers
- **Aug 2026 — Uber Q2'26 earnings:** Did Mobility GB growth in Austin/Atlanta MSA decelerate vs national? (Currently no effect per Q1, per management.) Did insurance savings show up in Mobility EBITDA margin? Q2 guide is GB $56.25B–$57.75B / EBITDA $2.70–$2.80B[1] — a beat-and-raise on EBITDA would partially refute the bear thesis.
- **Waymo NYC / Seattle / DC announcement:** Direct app, Lyft partnership, or Uber? Direct = bear thesis confirmed; Uber inclusion = bull thesis intact.
- **Tesla Robotaxi unsupervised fleet count:** Independent trackers (Electrek, Sawyer Merritt) reach >200 unsupervised vehicles across TX/CA/NV by August → bear-acceleration signal. Stays sub-100 → execution-risk thesis on Tesla holds.
- **Wayve London commercial launch:** Pilot date slipped or paying riders by Q3'26? Pilot = bull case ("Uber's the rails for the rest of the AV world"); slip = generic AV-execution skepticism.
- **California *Rideshare Drivers United v. Uber* preliminary rulings on Prop 22 minimums.** Adverse ruling = direct cost hit.
- **Hyperscaler AV capex commentary** (Alphabet Q2 call): Waymo capex up >30% sequential = direct-app strategy fully funded.

## What I could not verify
- **Exact Uber/Waymo per-trip economic split.** Both parties are silent. Industry inference is that Waymo retains the majority — but "majority" between 55% and 90% is a huge range for thesis purposes.
- **Per-city Waymo trips on Uber app vs Waymo app.** Total Waymo paid trips disclosed; allocation by channel not.
- **Mobility take rate for Q1'26.** Last reliable disclosure is Q4'25 at 29.9%; Q1'26 supplemental PDF not parseable.
- **Uber's $10B AV commitment status — contractually obligated vs intent to spend.** Disclosed framing leaves both interpretations open.
- **Tesla Robotaxi daily trip volume.** Tesla discloses cumulative; independent estimates vary by 10×.
- **Whether the NVIDIA "100,000 vehicle Uber AV ecosystem" announcement is signed orders or roadmap.** Reads as roadmap.
- **DeepETA latency SLO / accuracy delta.** Only directional improvements published.
- **Uber's actual AI/ML headcount and senior departure/hire trajectory 2024–2026.**
- **Uber Freight market share** vs C.H. Robinson/Echo. No clean recent disclosure.

## Sources
[1] https://investor.uber.com/news-events/news/press-release-details/2026/Uber-Announces-Results-for-First-Quarter-2026/default.aspx — retrieved 2026-05-10 — Q1 2026 press release: revenue, GB, MAPCs, trips, segment splits, Q2 guide.
[2] https://www.fool.com/earnings/call-transcripts/2026/05/06/uber-uber-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q1'26 earnings call transcript, including Khosrowshahi commentary on Waymo non-impact, insurance savings, AV partner count.
[3] https://www.thedriverlessdigest.com/p/waymo-and-ubers-partnership-may-be — retrieved 2026-05-10 — Waymo-Uber partnership cooling: every new Waymo city since Atlanta has been Lyft or direct.
[4] https://stockanalysis.com/stocks/uber/statistics/ — retrieved 2026-05-10 — UBER price ($75.45 May 8 close), market cap, 52-week range, short interest.
[5] https://www.marketbeat.com/stocks/NYSE/UBER/forecast/ — retrieved 2026-05-10 — Average analyst PT $107.79 (Strong Buy, ~33 analysts).
[6] https://www.gurufocus.com/term/forward-pe-ratio/UBER — retrieved 2026-05-10 — Forward P/E ~20.5×.
[7] https://multiples.vc/public-comps/uber-valuation-multiples — retrieved 2026-05-10 — EV/Revenue 2.8× LTM (NTM ~2.55× derived).
[8] https://www.tikr.com/blog/uber-stock-is-down-9-in-2026-heres-why-analysts-still-see-upside-to-103 — retrieved 2026-05-10 — YTD return ~-9%.
[9] https://insideevs.com/news/791245/waymo-rides-per-week-2026-doubled/ — retrieved 2026-05-10 — Waymo ~450–500K paid trips/week, 1M/wk YE26 target.
[10] https://9to5google.com/2026/04/22/waymo-new-cities-features/ — retrieved 2026-05-10 — Waymo direct-app footprint: Phoenix, SF, LA, Miami, Dallas, Houston, San Antonio, Orlando, Nashville plus 2026 city plans.
[11] https://www.lyft.com/blog/posts/lyft-and-waymo-launch-partnership-to-expand-autonomous-mobility-to-nashville — retrieved 2026-05-10 — Lyft+Waymo Nashville partnership.
[12] https://electrek.co/2025/11/18/waymo-expansion-autonomous-rides-miami-dallas-houston/ — retrieved 2026-05-10 — Waymo Miami (Moove), Dallas (Avis), Houston expansion.
[13] https://www.roadtoautonomy.com/london-waymo-uber-compete/ — retrieved 2026-05-10 — London first city of head-to-head Waymo direct vs Uber/Wayve.
[14] https://wayve.ai/press/wayve-uber-l4-autonomy-trials/ — retrieved 2026-05-10 — Wayve-Uber London Spring 2026 robotaxi launch.
[15] https://www.cnbc.com/2026/02/12/waymo-begins-deploying-next-gen-ojai-robotaxis-to-extend-its-us-lead.html — retrieved 2026-05-10 — Waymo 6th-gen Ojai hardware deployment.
[17] https://investor.uber.com/news-events/news/press-release-details/2026/WeRide-and-Uber-Launch-Fully-Driverless-Robotaxi-Fare-Charging-Operations-in-Dubai-Accelerating-Autonomous-Mobility-in-the-Middle-East-2026-NSiF0EFKhd/default.aspx — retrieved 2026-05-10 — WeRide Dubai driverless commercial; 1,200-vehicle Middle East commitment.
[18] https://investor.uber.com/news-events/news/press-release-details/2025/Lucid-Nuro-and-Uber-Partner-on-Next-Generation-Autonomous-Robotaxi-Program/default.aspx — retrieved 2026-05-10 — Lucid+Nuro+Uber 35K-vehicle robotaxi program; Uber-exclusive in SF.
[19] https://ir.aurora.tech/news-events/press-releases/detail/128/aurora-expands-driverless-trucking-service-from-fort-worth-to-el-paso — retrieved 2026-05-10 — Aurora driverless trucking expansion; Uber Freight as launch customer.
[20] https://electrek.co/2026/02/16/tesla-robotaxi-status-check-8-months-in/ — retrieved 2026-05-10 — Independent Tesla Robotaxi unsupervised count ~25 vehicles across 3 TX cities.
[21] https://www.notebookcheck.net/Uber-vs-Lyft-vs-Waymo-vs-Model-Y-robotaxi-ride-share-price-and-wait-times-comparison-shows-Tesla-is-buying-adoption.1214171.0.html — retrieved 2026-05-10 — Tesla undercutting Uber ~60% in Austin (Jefferies study).
[22] https://electrek.co/2026/02/11/hyundai-supply-waymo-50000-ioniq-5-robotaxis/ — retrieved 2026-05-10 — Hyundai 50K Ioniq 5 supply target for Waymo.
[24] https://www.benzinga.com/markets/tech/26/05/52437488/ubers-10-billion-robotaxi-push-could-challenge-tesla-and-waymo-dominance — retrieved 2026-05-10 — Uber's $10B AV commitment composition.
[26] https://www.nhtsa.gov/press-releases/av-framework-plan-modernize-safety-standards — retrieved 2026-05-10 — NHTSA AV Framework, AV STEP, AVEP exemption to 2,500/yr/mfr.
[27] https://www.uber.com/us/en/blog/scaling-ai-ml-infrastructure-at-uber/ — retrieved 2026-05-10 — Michelangelo: 5,000+ models, ~15M predictions/sec, 30M match-pair predictions/min.
[28] https://www.uber.com/us/en/blog/deepeta-how-uber-predicts-arrival-times/ — retrieved 2026-05-10 — DeepETA architecture.
[30] https://www.cio.com/article/3513933/uber-embraces-the-cloud-with-customized-cpus.html — retrieved 2026-05-10 — Uber cloud migration to Oracle/Ampere; ~30% power reduction.
[31] https://www.nfx.com/post/the-network-effects-map-nfx-case-study-uber — retrieved 2026-05-10 — Uber network effects saturation analysis.
[32] http://www.shapiromh.com/uploads/8/6/4/0/8640674/mshapiro_jmp.pdf — retrieved 2026-05-10 — Shapiro JMP on density of demand and Uber benefits.
[33] https://patents.justia.com/assignee/uber-technologies-inc — retrieved 2026-05-10 — Uber patent portfolio (~3,060 globally, 1,832 active).
[34] https://www.electrive.com/2025/05/07/uber-joins-robotaxi-forces-with-both-pony-ai-and-weride/ — retrieved 2026-05-10 — Uber AV partner roster.
[35] https://www.selfdrivingcars360.com/waymo-sixth-generation-hardware-costs-less-for-driverless-expansion/ — retrieved 2026-05-10 — Waymo 6th-gen <$20K hardware cost atop vehicle.
[36] https://electrek.co/2026/04/23/tesla-cybercab-production-starts-no-nhtsa-2500-vehicle-cap/ — retrieved 2026-05-10 — Cybercab production confirmed; FMVSS-compliant exemption from cap.
[37] https://www.bloomberg.com/news/articles/2026-04-24/musk-says-tesla-has-begun-production-of-its-cybercab-robotaxi — retrieved 2026-05-10 — Cybercab production start ~2K/wk, target 10K/wk YE26.
[38] https://zevaglobal.com/blog/teslas-autonomous-driving-and-robotaxi-vision-what-fleet-managers-need-to-know/ — retrieved 2026-05-10 — Tesla cost target $0.20–0.40/mile vs $0.70–1.50 ride-hail.
[39] https://calmatters.org/economy/2024/07/prop-22-california-gig-work-law-upheld/ — retrieved 2026-05-10 — California Supreme Court upheld Prop 22.
[40] https://thenextweb.com/news/uber-q1-2026-earnings-autonomous-demand-acceleration — retrieved 2026-05-10 — Uber/Lyft Q1'26 GB scale comparison.
[41] https://www.lyft.com/blog/posts/press-release-lyft-reports-strong-q1-financial-results — retrieved 2026-05-10 — Lyft Q1'26 results: revenue, EBITDA guide.
[42] https://www.fool.com/earnings/call-transcripts/2026/05/06/doordash-dash-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — DoorDash Q1'26 ad business >$1B annualized, grocery profitability target.
[43] https://www.statista.com/statistics/1235724/market-share-us-food-delivery-companies/ — retrieved 2026-05-10 — US food delivery share split.
[44] https://tickeron.com/blogs/uber-vs-lyft-earnings-preview-as-q4-results-put-ride-demand-and-margins-in-focus-11692/ — retrieved 2026-05-10 — Uber vs Lyft profitability and ROE comparison.