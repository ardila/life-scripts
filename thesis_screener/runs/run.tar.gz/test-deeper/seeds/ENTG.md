# ENTG — Entegris, Inc.

## Where this sits in the AI stack
Entegris sells the **consumable chemistry, filtration media, and wafer-handling hardware** that sit one layer below the wafer-fab equipment makers (AMAT, Lam, KLA, ASML). It does not make tools, transistors, or packages. It makes the UPE (ultra-high-molecular-weight polyethylene) membrane filters that sit at the point-of-use on EUV photoresist tracks; the CMP (chemical-mechanical planarization) slurries and pads that polish each metal layer; the high-purity ALD/CVD precursors (e.g., WCl₅ for fluorine-free tungsten, molybdenum precursors) used in deposition; the gas/liquid purifiers; and the polycarbonate FOUPs that move wafers between tools [1][2][3][4][5]. Workload exposure: ~40% advanced logic, ~30% memory (split DRAM/NAND), and a $100M+ run-rate in advanced packaging — i.e., they sell consumables into every wafer that touches a frontier-node line, both training silicon (Blackwell/Rubin, MI300/400, TPU, Trainium) and HBM stacks [6][7].

## Snapshot
- **Price:** $149.11 (2026-05-08 close) [8]
- **Market cap:** $22.71B [9]
- **52-week range:** $66.32 – $159.15 [10]
- **Forward P/E:** 42.9× (on FY consensus EPS) [9]
- **EV / NTM revenue:** ~6.1× ($21.2B EV / ~$3.49B forward revenue) [11]
- **Consensus 12-month price target:** $141.90 (10-analyst average; implied **−4.8%**); range $95–$155; 6 Buy / 4 Hold / 1 Sell [12]
- **YTD total return:** +23.6% [10]
- **Short interest (% of float):** 6.47% (~9.83M shares) [13]
- **Dividend yield:** 0.42% (annual $0.40) [13]
- **Net debt / leverage:** $3.3B / 3.6× net leverage; targeted ~3× by YE2026 [14]

## Moat — what it is physically made of

The "Entegris moat" is not one thing. It is roughly four technical assets bundled with one structural asset (qualification lock-in). Decomposed:

**1. UPE membrane filtration for EUV photoresist (the strongest piece).**
At leading-edge logic, photoresist is now an EUV chemically-amplified resist (CAR) or metal-oxide resist (MOR, Inpria). The dominant on-wafer yield killer is the **bridge defect** — a single ~2-nm rigid molecular aggregate or particle in the resist film causes adjacent features to short after etch [15]. Entegris' SPIE Advanced Lithography papers with imec show **R² ≈ 0.97 linear correlation between UPE membrane pore size and bridge defect density**, and that the effect persists through full pattern transfer through etch [4][16]. The Impact 8G filter with the Oktolex membrane is currently the volume product against this defect class [3]. Replicating UPE chemistry at this pore-size control with low-extractable behavior is a multi-year polymer-membrane R&D program — Pall (Danaher) and 3M can build credible alternatives, but **the membrane is qualified per resist chemistry per fab per node**, and the qual cycle is the moat, not the membrane itself (more below).

**2. CMP slurries and pads (CMC Materials, acquired July 2022 for ~$5.7B).**
CMC was the former Cabot Microelectronics, the world's #1 slurry maker at ~$1.2B/yr [17][18]. Top three slurry players (CMC/ENTG, Showa Denko, Fujimi) hold ~51% global share [19]. The technical content is in the colloidal silica/ceria abrasive engineering and the additive chemistry that selectively polishes one material vs. another (e.g., copper over barrier metal, tungsten over dielectric). Critically, **CMP slurry content per wafer roughly doubles from N3 to N2** because gate-all-around (GAA) and backside-power-delivery introduce more metal levels and more selective-polish steps [20].

**3. Specialty deposition precursors and the Lam dual-source partnership.**
Entegris (with Gelest, a Mitsubishi Chemical subsidiary) is the dual qualified source for the WCl₅ tungsten precursor used in Lam's dry-resist tooling and fluorine-free ALD-W flows for 2nm logic and advanced DRAM [21]. Solid-source molybdenum precursors for replacing tungsten word-lines in advanced 3D NAND are the next leg [22]. This is small-volume, very high-purity chemistry — pure inorganic synthesis at semiconductor-grade.

**4. FOUPs and 300mm wafer-handling.**
Polycarbonate FOUPs with N₂-purge compatibility and outgassing-controlled materials. Entegris shares the leading position with Miraial and Shin-Etsu Polymer; this is mature commodity-adjacent business but provides the customer-touchpoint depth [23].

**5. The structural moat: per-resist, per-fab, per-node qualification.**
A specialty material change at a frontier-node fab requires re-qualification through pilot lots, defectivity matching, particle baseline, marathon runs — typically 12–18 months even when the chemistry is identical [24, inference based on industry norms]. Once qualified, a $10–50/wafer consumable is not a place a fab takes risk to save 5%. The CMC acquisition lifted Entegris' "unit-driven" (consumable) revenue from ~70% to ~80% [17] — meaning revenue follows wafer starts, not fab capex cycles, making the model less cyclical than equipment vendors' but also dependent on utilization.

**Honest assessment of moat durability**:
- UPE filtration / advanced precursors: durable for the current node, vulnerable on a 5-year horizon if a competitor (Pall, Merck KGaA, JSR) gets co-designed into a node from inception. The moat is per-node, not perpetual.
- CMP slurries: oligopoly economics, not monopoly. Three players each have qualified positions; share shifts at the wafer level happen at every node transition.
- FOUPs: low durability, commoditized.
- Qualification lock-in: highly durable for the install base, neutral on greenfield fabs (Arizona, Ohio, Dresden) where every supplier re-qualifies.

## AI buildout bottleneck map
The actual gating constraints on the 24-month AI buildout, and where ENTG sits relative to each:

| Bottleneck | Status | ENTG position |
|---|---|---|
| **CoWoS / CoWoS-L packaging** at TSMC | Oversubscribed through 2026; capacity scaling 75–80k → 120–130k wpm by YE2026; NVIDIA holds ~60% allocation [25][26] | **Indirect beneficiary.** Sells filtration/wet chemistry/CMP into the interposer flow but is *not* the gatekeeper. $100M+ run-rate is real but small (~3% of revenue) [7] |
| **HBM3e/HBM4 capacity** at SK hynix, Samsung, Micron | Tight; HBM4 sticks with microbumps (no hybrid bonding yet) [27] | **Beneficiary.** DRAM consumables scale with HBM die counts. Memory ~30% of revenue; mgmt called out "DRAM accelerating, driven by AI" [6] |
| **Advanced logic capacity at N3/N2/18A** | TSMC and Intel adding; utilization at advanced nodes "near effective capacity" per ENTG [6] | **Direct beneficiary** via content-per-wafer step-up at each node transition |
| **EUV / High-NA EUV scanner output** (ASML) | Constrained by ASML throughput, not materials | **Beneficiary** (resist-track filtration scales with EUV layer counts) |
| **Power/grid for hyperscaler datacenters** | Severe constraint (gas turbine backlog, transmission interconnect queues) | **Indifferent** |
| **Optical interconnect / co-packaged optics** | Tight optics supply | **Indifferent** |
| **Liquid cooling / >100kW racks** | Tight | **Indifferent** |

The honest summary: **ENTG benefits from AI buildout but is not on the critical path of any AI-specific bottleneck.** Their growth comes from wafer starts × content-per-wafer, both of which are AI-correlated but neither of which is the constraint.

## Competitive teardown

**Merck KGaA Electronics (with Versum Materials)** — closest direct competitor on every axis. Merck won the 2019 Versum bid against Entegris [28]. Direct head-to-head in CMP slurries, deposition precursors, specialty gases. Merck has comparable scale and R&D, deeper European customer relationships, particularly with Infineon and STMicro. **Where Merck has parity or advantage**: specialty gases for ion implantation, certain photoresist ancillaries. **Where ENTG leads**: UPE filtration, breadth of CMP portfolio post-CMC.

**Pall Corporation (Danaher)** — direct competitor in microelectronic filtration. Danaher's life-sciences membrane R&D is a credible long-term threat. The five-player oligopoly (Pall, Entegris, 3M, Cobetter, Parker) holds 45–60% of the electronic-filtration market [29]. **ENTG's edge**: tighter integration with EUV resist suppliers (JSR, TOK, Inpria) and earlier-stage co-development.

**Fujimi, Showa Denko (Resonac), Anji Microelectronics** — CMP slurry competitors. Asia-Pacific holds ~82% of CMP slurry consumption; the regional players have logistics and customer-proximity advantages [19]. **Anji** is the China-domestic threat — credible at trailing nodes, not yet at sub-5nm. The China-localization push (85% in-region for ENTG, target 90% by YE2026) [6] partially neutralizes this but also signals the threat is real.

**JSR, Tokyo Ohka Kogyo, Shin-Etsu** — adjacent in photoresist; not direct in filtration. Compete in the broader specialty-materials wallet share at fabs.

**DuPont, Cabot Corp** — slurry/CMP-adjacent. DuPont is the long-tail diversified competitor.

**Honest read**: there is no single "NVIDIA-vs-AMD" displacement story here. Specialty materials is structurally an oligopoly with regional clusters. ENTG's share gains are **per-node, per-product, per-fab** — measured in basis points, not market shifts. The bear thesis is not that one competitor takes over; it's that ENTG fails to expand share at N2/A14 transitions and content-per-wafer growth disappoints.

## Bull case — technical
For ENTG to outperform, the following technical conditions must hold over 24 months:

1. **N2 / A14 / 18A production ramps proceed roughly on schedule at TSMC, Samsung, Intel.** Each node transition is worth ~2× CMP slurry content per wafer [20] and step-ups in filter consumption, gas-purifier load, and precursor demand. Schedule slips here directly translate to ENTG revenue slips.
2. **HBM4 / HBM4E volume ramps in 2026–2027 at all three memory vendors.** ENTG's DRAM consumable basket scales with die count per stack; 12-Hi → 16-Hi roadmap is favorable.
3. **UPE membrane qualification remains node-locked.** No competitor (Pall, 3M) wins a frontier-node design-in for the next two years.
4. **ENTG's stated outperformance vs. wafer-starts (4–5pp above MSI growth) holds** [30]. With WFE growing 9% in 2026 to $135B [31] and silicon wafer shipments +13.1% Y/Y in Q1 2026 [32], ENTG should be capable of low-double-digit organic growth — but Q1 only delivered +5%, leaving a credibility gap to close.
5. **Net leverage glides to ~3× by YE2026** [14], unlocking either a buyback or a follow-on tuck-in M&A (e.g., another precursor or pad-conditioning niche player).

If all five hold, $5B revenue by 2027 (a target previously cited but not reaffirmed in the Q1'26 transcript) becomes plausible, ~16% gross-margin operating leverage takes EPS materially above consensus, and the multiple sustains.

**Base rate caveat**: oligopolistic specialty-materials suppliers in semis (Linde, Air Products, Shin-Etsu Chemical, Sumco) historically compound at single-digit to low-double-digit revenue CAGR with very long moats but rarely *expand* multiples — they get derated when growth slips and rerated when the cycle inflects. ENTG is currently in a re-rating phase that has already played out (+24% YTD). Historical base rate suggests further re-rating is rare without genuine acceleration.

## Bear case — technical
The version a short-seller who reads SPIE proceedings would write:

1. **The valuation already prices the AI thesis.** 6.1× EV/NTM revenue and 42.9× forward P/E for a 5%-growth quarter (Q1 +5% Y/Y, Q2 guide ~5%) is rich. Consensus 12-month PT of $141.90 sits **below** current $149.11 [12] — the sell-side already thinks the stock is ahead of itself.

2. **The "content-per-wafer doubles N3→N2" story is real but slow-realized.** N2 HVM at TSMC is just starting in 2026; meaningful volume contribution to ENTG's P&L is a 2027–2028 event. The market may have pulled forward two years of revenue.

3. **Memory cycle risk.** 30% of revenue is memory. DRAM bit-growth has been mostly HBM-driven; if HBM pricing rolls (Micron and Samsung catch up to SK hynix on HBM4 yield), commodity DRAM spending could disappoint. NAND remains structurally weak; only the moly word-line transition saves it.

4. **China dual-track risk.** 85% in-region production for China sales [6] is impressive de-risking, but it also means ENTG is building Chinese manufacturing capacity that domestic competitors (Anji, NAURA-adjacent suppliers) can eventually displace. The qualification moat is weaker in China where SMIC, YMTC, CXMT face equivalent pressure to localize.

5. **The CoWoS exposure is overstated.** $100M+ run-rate on $3.2B revenue is ~3%. The "advanced packaging" narrative is mostly a story; the actual P&L driver is wafer starts at advanced logic.

6. **Hybrid bonding is a long-term bear.** When SK hynix moves HBM5 to hybrid bonding (post-2027), microbump-era CMP and filter content per stack drops materially. The dielectric chemistry (SiCN PECVD) is owned by AMAT/Lam, not ENTG [33].

7. **Margin recovery is reflexive, not structural.** Gross margin recovered from ~42% trough to 46.9% in Q1'26 — most of this is volume leverage on fixed cost absorption. If Q3/Q4 doesn't accelerate, the multiple breaks first.

8. **Net leverage at 3.6×** [14] is still meaningful and constrains capital return. CMC was bought at the top; goodwill impairment risk is non-zero in a downturn.

## Market view check
At $149 and 6.1× EV/NTM revenue, the stock is priced for a clean ramp to ~$5B revenue by 2027 with margin recovery to ~48% gross. The street's $141.90 consensus PT implies the median analyst thinks the move has played out. The short interest at 6.5% of float is **above** the typical 2–3% for a defensive specialty-materials name [13] — i.e., the market is split, with non-trivial dollars positioned that the AI-tailwind story is overpriced. My read: the **technical thesis is correct** (durable per-node moats, real content-per-wafer step-up, structural memory tailwind from HBM), but the **timing is uncertain** (Q1 +5% does not look like a stock running to a $5B 2027). Mispricing is small; this is a hold-quality story that has already had its move. Asymmetric upside requires the Q2/Q3 print to clearly accelerate above 7–8% Y/Y.

## 90-day falsifiers
- **Q2 2026 earnings (late July 2026):** revenue print vs. $830M guide, Q3 sequential guide. **A Q3 guide at <+5% sequential would falsify the acceleration thesis.**
- **TSMC and SK hynix capex commentary on July 2026 calls.** A cut to TSMC 2026 capex below $44B or SK hynix HBM capex deferral would directly hit ENTG's content-growth math.
- **MLPerf and customer disclosures on Blackwell-Ultra/Rubin volume.** If NVIDIA Q2 disclosures show CoWoS allocation shifted to <50% NVIDIA share (i.e., AMD MI400 / Trainium / TPU taking allocation), ENTG is neutral but the AI-narrative trade weakens.
- **Pall (Danaher) or Merck KGaA EUV resist-track filter design-in announcements** at SPIE Advanced Lithography 2026 abstracts (program typically posted September). A Merck design-in at a TSMC fab on N2 photoresist would be a direct moat hit.
- **China export-control re-tightening past the November 2026 standstill** [34]. A renewed ECCN restriction on specialty chemistries to SMIC/YMTC/CXMT would force ENTG to slow Chinese capacity build and cut localized revenue.
- **WFE memory data points (SK hynix monthly HBM bit-growth, Samsung HBM4 yield disclosures).** Memory acceleration is the single biggest 2026 swing factor.

## What I could not verify
- **Whether ENTG plays in the SiCN dielectric chemistry that enables hybrid bonding.** Public disclosures are silent on this. AMAT and Lam own the dielectric deposition tooling; ENTG's exposure is via CMP slurry into the post-bond planarization step at most.
- **The exact reaffirmation of the "$5B revenue by 2027" target** in the Q1 2026 transcript — earlier corporate communications cited it, but the Q1'26 transcript I retrieved did not restate the figure explicitly [35].
- **Specific qualification-cycle duration** for advanced-node specialty materials. Industry-standard is "12–18 months"; I could not source a published per-product number for UPE filters or CMP slurries.
- **Entegris' precise share within the $100M+ advanced-packaging run-rate vs. competitors** (e.g., share at OSATs like ASE and Amkor for CoWoS-adjacent process steps).
- **Whether the CHIPS Act $75M Colorado Springs grant has been fully obligated and disbursed under the 2025 administration's revised CHIPS approach** [36].
- **The exact gross-margin contribution by segment** (APS vs. MS) is reported on adjusted-segment-profit basis, not standalone GM, in public filings.

## Sources
[1] https://blog.entegris.com/solving-bridge-defects-in-euv-car-resists-with-advanced-upe-filtration — retrieved 2026-05-10 — Entegris technical blog establishing UPE filter role in EUV CAR bridge defect reduction
[2] https://www.entegris.com/en/home/brands/cmc-materials-july-2022.html — retrieved 2026-05-10 — CMC Materials brand page, CMP slurry/pad portfolio
[3] https://www.entegris.com/shop/en/USD/products/liquid-filtration-and-purification/liquid-filters/Impact-8G-Filter/p/Impact8GFilter — retrieved 2026-05-10 — Impact 8G filter product page with Oktolex membrane
[4] https://blog.entegris.com/effect-of-pou-filter-pore-size-on-euv-bridge-defect-density — retrieved 2026-05-10 — POU filter pore-size to EUV bridge defectivity correlation
[5] https://blog.entegris.com/solid-precursors-for-3d-architectures-materials — retrieved 2026-05-10 — Mo, W, Al solid precursors for 3D NAND/logic ALD
[6] https://www.fool.com/earnings/call-transcripts/2026/04/30/entegris-entg-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1 2026 earnings call: 40% advanced logic, 30% memory; segment splits; 85% China in-region; AI commentary
[7] Q1 2026 transcript (same as [6]) — $100M+ advanced packaging run-rate
[8] https://finance.yahoo.com/quote/ENTG/ — retrieved 2026-05-10 — Closing price $149.11 (May 8, 2026)
[9] https://www.gurufocus.com/term/forward-pe-ratio/ENTG — retrieved 2026-05-10 — Forward P/E 42.92×, market cap $22.71B
[10] https://stockanalysis.com/stocks/entg/statistics/ — retrieved 2026-05-10 — 52-week range $66.32–$159.15, YTD +23.55%
[11] https://www.alphaspread.com/security/nasdaq/entg/relative-valuation/ratio/enterprise-value-to-revenue — retrieved 2026-05-10 — EV/Sales TTM 6.6×, forward 6.1×; EV $21.2B
[12] https://www.tipranks.com/stocks/entg/forecast — retrieved 2026-05-10 — Consensus PT $141.90, range $95–$155, 6 Buy / 4 Hold / 1 Sell
[13] https://www.benzinga.com/insights/short-sellers/24/04/38022701/entg-analyzing-entegriss-short-interest — retrieved 2026-05-10 — Short interest 9.83M / 6.47% of outstanding; dividend $0.40/0.42% yield
[14] Q1 2026 transcript — net debt $3.3B, leverage 3.6× → 3× by YE2026; $50M term-loan paydown Q1
[15] https://www.entegris.com/content/dam/web/resources/poster/poster-bridging-the-defect-gap-in-euv-photoresist-10336.pdf — retrieved 2026-05-10 — Bridge defect mechanism in EUV photoresist
[16] https://spie.org/advanced-lithography/presentation/Point-of-use-UPE-membrane-filter-optimization-for-EUV-chemically/13983-107 — retrieved 2026-05-10 — SPIE 2024/25: pore size vs. defectivity, R²≈0.97 correlation; imec collaboration
[17] https://cen.acs.org/business/mergers-&-acquisitions/Entegris-acquire-electronic-materials-maker/99/i45 — retrieved 2026-05-10 — CMC acquisition $6.5B announced (closed at ~$5.7B); 70% → 80% unit-driven revenue
[18] https://investor.entegris.com/news-releases/news-release-details/entegris-completes-acquisition-cmc-materials-solidifying — retrieved 2026-05-10 — CMC Materials closing details
[19] https://www.zionmarketresearch.com/report/cmp-slurry-market — retrieved 2026-05-10 — CMP slurry market $1.96B (2024) → $4.28B (2034); top 3 ~51% share; APAC 82%
[20] https://markets.financialcontent.com/stocks/article/stockstory-2026-5-1-entg-q1-deep-dive-advanced-logic-and-memory-demand-drive-results-amid-margin-expansion — retrieved 2026-05-10 — CMP content N3→N2 doubles
[21] https://blog.entegris.com/solid-precursors-for-3d-architectures-materials — retrieved 2026-05-10 — WCl5 fluorine-free tungsten precursor; Lam–Entegris–Gelest dual-source for 2nm dry resist
[22] Same as [21] — Mo precursors for 3D NAND word-lines
[23] https://reports.valuates.com/market-reports/QYRE-Auto-28X16651/global-wafer-carrier-front-opening-unified-pod-foup — retrieved 2026-05-10 — FOUP top players: Entegris, Miraial, Shin-Etsu Polymer
[24] Industry-standard inference based on aggregate of [1][3][20]; specific qual cycles not verified
[25] https://markets.financialcontent.com/stocks/article/tokenring-2026-1-1-the-great-packaging-pivot-how-tsmc-is-doubling-cowos-capacity-to-break-the-ai-supply-bottleneck-through-2026 — retrieved 2026-05-10 — CoWoS capacity 75–80k → 120–130k wpm by YE2026
[26] https://www.astutegroup.com/news/industrial/advanced-packaging-demand-soars-nvidia-secures-60-of-cowos-capacity/ — retrieved 2026-05-10 — NVIDIA ~60% of CoWoS allocation
[27] https://semiengineering.com/hbm4-sticks-with-microbumps-postponing-hybrid-bonding/ — retrieved 2026-05-10 — HBM4 stays on microbumps, no hybrid bonding
[28] https://www.gasworld.com/story/merck-wins-versum-materials-takeover-battle-scuppers-entegris-deal/ — retrieved 2026-05-10 — Merck KGaA wins Versum, blocks Entegris deal
[29] https://www.marketsandmarkets.com/Market-Reports/electronic-filtration-market-239108694.html — retrieved 2026-05-10 — Top 5 filtration players hold 45–60% share
[30] https://beyondspx.com/quote/ENTG/margin-inflection-meets-content-growth-entegris-path-through-the-semiconductor-reset-nasdaq-entg — retrieved 2026-05-10 — ENTG outperformance vs. MSI by 4–5pp
[31] https://www.semi.org/en/semi-press-release/global-semiconductor-equipment-sales-projected-to-reach-a-record-of-156-billion-dollars-in-2027-semi-reports — retrieved 2026-05-10 — WFE $135.2B 2026 (+9%), $156B by 2027
[32] https://ninescrolls.com/news/semi-q1-2026-silicon-wafer-shipments-hit-3-275-msi-up-13-1-year-on-year-on-ai — retrieved 2026-05-10 — Q1 2026 silicon wafer shipments 3,275 MSI, +13.1% Y/Y
[33] https://semianalysis.com/2024/02/09/hybrid-bonding-process-flow-advanced/ — retrieved 2026-05-10 — Hybrid bonding process flow; SiCN/SiO2 PECVD dielectric owned by tool vendors
[34] https://www.morganlewis.com/pubs/2026/01/us-international-trade-and-investment-key-shifts-in-2025-and-what-businesses-should-know-for-2026 — retrieved 2026-05-10 — US-China standstill through November 2026
[35] Q1 2026 transcript — $5B 2027 target not explicitly restated in the Q1 2026 call retrieved
[36] https://www.manufacturingdive.com/news/entegris-75-million-chips-colorado-springs-semiconductor-supply-plant/719950/ — retrieved 2026-05-10 — $75M CHIPS Act funding for Colorado Springs facility