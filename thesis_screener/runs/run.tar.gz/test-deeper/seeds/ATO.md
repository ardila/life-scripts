# ATO — Atmos Energy Corporation

## Where this sits in the AI stack
ATO is **not in the AI compute stack**. It is a pure-play regulated natural gas utility whose AI exposure is one layer removed from the load: it owns the last-mile distribution and intrastate transmission pipes that **feed gas-fired generators** powering data centers, primarily in Texas. Of two segments, Distribution (LDCs across 8 states, ~3.3M customers, ~64% of revenue) sells therms to homes, commerce, and increasingly to behind-the-meter (BTM) data center gensets; Pipeline & Storage — almost entirely the **Atmos Pipeline-Texas (APT)** intrastate system (5,700 miles, five underground storage caverns including Bethel Salt Dome) — moves Permian/Carthage/East Texas supply to the Waha, Carthage and Katy market hubs and into the DFW Metroplex.[1][2][3] Workload: combined-cycle and reciprocating engine power generation, both grid-connected and BTM, supporting both AI training and inference clusters in ERCOT.

## Snapshot
- **Price:** $185.62 (2026-04-27 close)[4]
- **Market cap:** $30.7B[4]
- **52-week range:** $149.98 – $192.51[5]
- **Forward P/E:** ~22.0× on FY2026 EPS guidance midpoint of $8.45[4][6]
- **EV / NTM revenue:** ~8× (rough — ~$30.7B equity + ~$10B net debt vs. ~$5B FY26E revenue). **Caveat: not a meaningful metric for a rate-regulated utility; rate base premium (P/RB ~1.6–1.8×) and P/B ~2.6× are more diagnostic.**
- **Consensus 12-month price target:** $181.11 (implied −2.4%), rating "Hold"[7]
- **YTD total return:** +6.3% (price), trailing XLU's +6.8%[8]
- **Short interest (% of float):** 2.3% of 164.5M float[5]

## Moat — what it is physically made of
This is a regulatory-franchise + right-of-way moat, **not** a technology moat. Decomposed:

1. **Certificated franchise monopolies in LDC service territories.** Mid-Tex (DFW + much of Texas outside Houston), Louisiana, Mississippi, Kentucky/Mid-States, Colorado/Kansas. These are exclusive grants from state PUCs/RRCs. Durability: high; the last meaningful US gas LDC franchise revocation was decades ago.
2. **APT physical right-of-way and storage caverns.** 5,700 miles of intrastate pipe routed during decades when easements were cheap and political; the Bethel Salt Dome project doubled peak-day deliverability into APT after a 55-mile, 36-inch loop to Groesbeck Compressor came online.[2][9] **Salt-dome storage is the moat's most replication-resistant physical asset**: it requires the right geology (bedded salt with structural integrity), water sourcing for solution mining over years, and Railroad Commission permits. Texas has ~10 commercially active salt-cavern storage sites; greenfield is a 5–8 year exercise.
3. **Texas regulatory mechanism stack.** GRIP, the Rate Review Mechanism (RRM), and **Rule 7.7102** (codified by the Texas RRC in 2026 from 2025 legislation) collectively let ATO recover ~95% of capex within 6 months and ~99% within 12 months by deferring post-in-service carrying costs, depreciation and ad valorem taxes on growth capex.[10][11] This is *not* unique to ATO — it applies to all Texas gas LDCs — but ATO is by far the largest beneficiary on an absolute-dollar basis given its rate base concentration.
4. **Cost of capital advantage.** 60.9% equity cap, A-/A3 senior unsecured ratings, $4.1B liquidity, debt/equity 0.67.[6] This matters because a regulated utility competes for capex authorization on the basis of authorized ROE (~9.5–10% in Texas) against WACC; lower WACC = more rate base it can profitably absorb.
5. **What is NOT a moat:** there is no software, no proprietary protocol, no patent portfolio, no developer ecosystem. Gas molecules are fungible and tariffed.

Replication cost: a hypothetical entrant would need decades to assemble equivalent ROW + storage + regulatory relationships. But that's the wrong question — the real competitive question is **at the margin**, who wins the next greenfield data-center gas supply contract, and there the moat is much thinner (see Competitive Teardown).

## AI buildout bottleneck map
Gating constraints on US AI buildout over the next 24 months, and ATO's position:

- **Grid interconnection in ERCOT.** ~360 GW of speculative data-center load sits in the ERCOT queue against ~94 GW system peak.[12][13] ERCOT estimates 7.4 GW of *non-crypto* data-center load in 2026 ramping toward 228 GW of submissions by 2032.[12] **ATO is a direct beneficiary of grid scarcity**: every gigawatt that can't get a grid POI accelerates BTM gas, which moves through APT and Mid-Tex.
- **Gas turbine backlog.** GE Vernova ended Q1 2026 with ~100 GW of contracted/reserved gas-turbine slots stretching into 2029–30; ~20% explicitly tied to data centers.[14] **ATO is indifferent at the turbine layer** but benefits in aggregate: turbine delivery 2028+ → gas demand 2028+ → APT throughput growth.
- **Permian takeaway capacity.** >4.5 Bcf/d of new Waha-egress projects targeted for 2H26 (Blackcomb 2.5 Bcf/d, Apex 2.0 Bcf/d, Saguaro 2.8 Bcf/d, GCX expansion 0.57 Bcf/d).[15] **APT is partially exposed but largely insulated**: APT's job is moving gas *within* Texas to load. More takeaway → narrower Waha–HH basis → better economics for Texas-located generation → more APT volumes. But APT does not earn on the basis spread.
- **Texas SB 6 (effective for >75 MW loads interconnecting after 12/31/2025).** Requires 50% backup generation capability and remote curtailment.[16] **Net positive for ATO** because backup generation is overwhelmingly natural gas — every new 100 MW load implies ~50 MW of gas-fired backup needing fuel and pipe service.
- **Electrical contractor / substation transformer capacity.** Indirect tailwind via the same mechanism (longer grid wait → more BTM gas).
- **CoWoS-L allocation, HBM3e yield, optical interconnect, liquid cooling, kernel/compiler talent.** ATO **indifferent**. These constrain how fast Nvidia/AMD/hyperscalers can deploy compute, which in turn caps gas demand growth — a soft ceiling on ATO's tailwind, not a direct exposure.

Net read: ATO sits **two layers downstream from the compute bottleneck**, on the favorable side of essentially every immediate bottleneck. The risk is not that ATO loses to a faster competitor on a technical axis — it's that the upstream bottleneck (compute) eventually slows the gas-demand pull-through.

## Competitive teardown
The relevant axis is **who gets the gas-supply contract for the next data center campus in Texas**. ATO competes on different axes than the headlines suggest:

- **Energy Transfer (ET).** Direct and serious threat at the *new greenfield* margin. ET's **Hugh Brinson Pipeline** (1.5 Bcf/d Phase 1, 400 miles, Waha→Maypearl, in service Q4 2026) is explicitly positioned for "power plant and data center growth in Texas," and ET has already signed a ~900 MMcf/d Oracle deal across three campuses (two in Texas).[17][18] ET's pitch: 42-inch, single-operator path from Permian wellhead to load. **ATO's APT pitch**: existing intrastate network with deep DFW connectivity and salt-dome storage for peak-day deliverability. For Permian-adjacent West Texas campuses (e.g., the Chevron/Microsoft 2.5 GW hub due late 2027[19]), ET is the favored counterparty. For DFW Metroplex campuses, APT is the incumbent. **APT does not lose the existing book; it loses share of new Permian-adjacent flow.**
- **Kinder Morgan (KMI).** Interstate (FERC-regulated) competitor. GCX expansion (mid-2026, +0.57 Bcf/d) and proposed Trident pipeline. Different regulatory regime, longer-haul economics; less of a direct overlap with APT's DFW-centric network.
- **Whitewater / MPLX / Enbridge JV.** Matterhorn, Blackcomb. Permian egress players, complementary rather than directly competing with APT.
- **Targa (TRGP) / Forza Pipeline.** Delaware Basin gathering scaling to 750k Dth/d. Upstream of APT, not parallel.
- **Behind-the-meter integrated developers** (e.g., LandBridge/PowerBridge West Texas 2 GW, Chevron–Microsoft). These are the real wildcard: they bypass both LDC and intrastate pipe by sourcing gas directly via gathering and dedicating a single pipeline lateral. **If integrated wellhead-to-genset becomes the dominant model for West Texas hyperscale, APT's growth narrative is materially narrower** — though Mid-Tex's DFW book is unaffected since DFW is far from the wellhead and needs intrastate transport regardless.

Net read: ATO is a strong incumbent in DFW and a marginal player in the Permian-adjacent greenfield. The market narrative tends to conflate these.

## Bull case — technical
For ATO to outperform, the following technical conditions must hold:

1. **ERCOT interconnection backlog persists through 2027+.** This forces hyperscalers into BTM gas as a bridge of *years*, not quarters. Current evidence: 360 GW queue, transformer/breaker shortages, SB 6 curtailment regime.[12][16]
2. **DFW Metroplex data-center cluster (Plano, Irving, Garland, north Dallas) absorbs >2 GW of new IT load by 2028.** Dallas is already 1 GW colo with 600 MW preleased.[20] Mid-Tex serves this footprint directly; APT moves the gas in via Line WA Phase 2 (44 miles of 36-inch, completed) and existing Bethel storage capacity.[3][9]
3. **Rule 7.7102 deferral mechanism survives RRC implementation cycle.** ~$155–165M FY26 pretax benefit alone, and durable through FY27–28 as capex scales.[11]
4. **Mid-Tex residential/commercial growth continues at ~39k Texas adds/year**, supporting the underlying 6–8% rate-base CAGR independent of AI.[21]
5. **Capital recovery stays at 95%/6mo, 99%/12mo,** so a $13.77B 2026–28 capex program (mostly ROE-earning rate base) compounds into ~7–9% annual EPS growth.[6][11]

If 1–5 hold, ATO compounds EPS at 8–9% with 2.2% dividend = ~10–11% total return, with a regulated-utility risk profile. The bull case for *multiple expansion* beyond ~22× requires the market to treat ATO as a structural AI beneficiary rather than a defensive utility — historically rare; the closest analog is the late-1990s telco buildout boost to Williams Companies, which expanded multiples ~30% before retracing.

**Base rate caution:** Utility re-rating during capex super-cycles is real but partial. Of the four prior US power-utility capex super-cycles (1970s coal, 1990s gas combined-cycle, 2010s renewables, 2020s grid hardening), only the 1990s cycle delivered sustained multiple expansion; the others compressed back within 4–6 years as rate-case fatigue set in.

## Bear case — technical
A short-seller who actually reads the gas-flow diagrams writes:

1. **22× forward P/E is ~3 turns above ATO's 10-year average (~18×) and ~2 turns above the peer group.** The premium implies AI-tailwind durability that may not be there. ATO's *own* disclosed data-center gas opportunity — ~30 Bcf/year by 2030 — is **~82 MMcf/d incremental**, against APT's existing throughput on the order of several Bcf/d.[1] A single ET–Oracle deal is 900 MMcf/d. ATO is not the marginal beneficiary the multiple implies.
2. **ATO does not earn on gas price.** APT is a tariffed transporter; LDCs pass through gas cost. The Permian takeaway buildout *narrows* basis, which is good for producers and for gas-fired generation economics, but does not directly accrue to ATO unless throughput volumes rise — and those volumes are concentrated in the existing DFW book, not the West Texas greenfield where new compute is going.
3. **Competition for new greenfield is structural, not cyclical.** ET's Hugh Brinson is purpose-built for the Waha→Texas-load corridor that competes head-on with APT's value proposition. Hyperscaler procurement increasingly favors single-counterparty wellhead-to-burner-tip deals (Chevron–Microsoft, Crusoe–Permian arrangements), which APT cannot offer.
4. **Rate-case political ceiling.** The Mid-Tex 2025 case approved a 14.1% residential rate increase ex-gas-cost.[22] This was politically expensive. Future rate cases face heightened ERCOT cost backlash + utility-bill inflation fatigue. The regulatory-lag advantage is real but the *headline rate level* still needs PUCT/city approval.
5. **Bond-proxy unwind risk.** ATO's 2.2% yield + 1.6× P/RB only works if 10Y stays anchored. A 75–100 bp move higher in long rates historically re-rates regulated utilities by 10–15%.
6. **AI capex compression upstream.** If hyperscaler capex flattens (TrendForce $830B 2026 number is at the high end of consensus), the back-end of the ERCOT queue (the speculative 200+ GW tail) never materializes, and the BTM-gas thesis caps at the 2027 deployment cycle rather than running through 2030.

## Market view check
At $185.62 and 22× forward EPS, the market is pricing ATO as a **utility with AI optionality** — not as a pure defensive name (peer group ~17–19×) and not as an AI infrastructure name (peer group 30×+). Consensus PT $181 implies analysts see fair value within 3% of spot — broadly a "fully priced, hold for the dividend" view. Our technical reading agrees that **AI optionality is real but small relative to the rate-base growth story**: the ~30 Bcf/yr 2030 data-center number is meaningful but not transformative, while the actual EPS driver is rate-base growth × authorized ROE × cost-of-capital advantage, levered by Rule 7.7102 capital recovery. The mispricing, if any, is mild: the stock is appropriately rich on its core utility merits and modestly rich on the AI overlay. We see no large dislocation to exploit either way.

## 90-day falsifiers
- **APT Q3 FY26 (calendar Q3 2026) throughput growth disclosure.** Look for management to call out specific named data-center interconnects on APT. <5% YoY APT volume growth would weaken the AI tailwind narrative; >10% would strengthen it materially.
- **Energy Transfer Hugh Brinson Phase 1 in-service date confirmation (targeted Q4 2026).** Slippage to 2027 supports APT share retention in the interim; on-time confirms competitive intensity in 2027.
- **Texas PUCT rulemaking proceedings on SB 6 implementation (final rules expected 2H26).** Specifically, the 50% backup-generation rule and the four-coincident-peak alternative review. Stricter curtailment rules → more BTM gas → ATO positive.
- **ERCOT 2026 long-term load forecast update (typically published Q3).** Material upward revision to data-center load supports BTM gas thesis; downward revision damages it.
- **Mid-Tex 2026 RRM filing.** Watch the requested capital additions and any city-coalition opposition signal — political ceiling on rate cases.
- **Q3 FY26 earnings (early August 2026).** Specifically, capex spend pacing against the $4.2B FY26 guide and any disclosed named data-center customer wins.
- **Any announcement of an APT-served BTM gas-fired generation campus >500 MW.** This would be a meaningful re-rating catalyst; absence of such announcements through end-2026 would suggest APT is losing the greenfield-supply contest to ET.

## What I could not verify
- Exact APT-only EBITDA contribution for FY25 (only Pipeline & Storage segment-level figures were disclosed: ~36% of FY24 revenue, ~$1.1B FY25 P&S revenue).[1][23]
- Specific named data-center customer contracts on APT (management referred to "high volume" of on-site gas activity but did not disclose counterparties).[6]
- Quantified share of the $13.77B 2026–28 capex plan specifically allocated to data-center-driven projects vs. legacy system modernization.
- Whether ATO has secured firm transportation contracts with West Texas hyperscale campuses (e.g., Chevron–Microsoft 2.5 GW hub) or is conceding that corridor to ET/Whitewater.
- Net debt and exact enterprise value as of 2026-04-27 (used estimated ~$10B net debt; actual figure pending the next 10-Q).
- Authorized ROE blended across jurisdictions for FY26 (estimated 9.5–10% range).
- Whether Bethel Salt Dome retains spare expansion capacity beyond the recent doubling, or if additional storage capex will be required for the 2028–30 demand bulge.

## Sources
[1] https://www.atmosenergy.com/apt/about-atmos-pipeline-texas/ — retrieved 2026-05-10 — APT system size (5,700 miles), market centers (Waha/Carthage/Katy), five storage facilities.
[2] https://www.atmosenergy.com/pipeline-projects/texas-service-territory/ — retrieved 2026-05-10 — Texas service territory description, $10.7B 2019–24 Texas investment.
[3] https://everyticker.com/quote/ATO/analysis/texas-tailwinds-and-regulatory-revolution-atmos-energy-s-compounding-advantage-nyse-ato — retrieved 2026-05-10 — Texas regulatory framework analysis; ~30 Bcf/yr 2030 data-center demand reference; 1.1M Texas population growth by 2030.
[4] https://www.wallstreetzen.com/stocks/us/nyse/ato — retrieved 2026-05-10 — Price $185.62 (04/27/2026 close), market cap $30.71B, forward P/E 22.07.
[5] https://finviz.com/quote.ashx?t=ATO — retrieved 2026-05-10 — 52-week range $149.98–$192.51, float 164.51M, short interest 2.3%.
[6] https://www.investing.com/news/transcripts/earnings-call-transcript-atmos-energys-q2-2026-earnings-exceed-expectations-93CH-4669511 — retrieved 2026-05-10 — Q2 FY26 earnings call: $4.2B FY26 capex, $13.77B FY26–28 plan, data-center commentary, $4.1B liquidity, 60.9% equity cap.
[7] https://www.dailypolitical.com/2026/04/09/atmos-energy-corporation-nyseato-receives-consensus-recommendation-of-hold-from-analysts.html — retrieved 2026-05-10 — Consensus "Hold," PT $181.11.
[8] https://www.barchart.com/story/news/ato-2026-2-19 — retrieved 2026-05-10 — YTD return +6.3% vs. XLU +6.8%.
[9] https://www.investing.com/news/transcripts/earnings-call-transcript-atmos-energy-q1-2026-earnings-beat-eps-forecasts-93CH-4485230 — retrieved 2026-05-10 — Q1 FY26 call: Line WA Loop Phase 2 status, Bethel Storage 55-mile 36-inch loop.
[10] https://www.atmosenergy.com/apt/apt-rates-and-tariffs/atmos-pipeline-texas/ — retrieved 2026-05-10 — APT rate mechanisms (GRIP/RRM).
[11] https://seekingalpha.com/news/4588789-atmos-energy-lifts-fiscal-2026-eps-guidance-to-8_40-8_50-as-texas-rule-7_7102-impact-targets — retrieved 2026-05-10 — Rule 7.7102 quantified at $155–165M pretax FY26; 95%/6mo and 99%/12mo capital recovery.
[12] https://energynewsbeat.co/data-center/over-367gw-grid-requirements-in-texas-ercot-by-2032-navigating-the-ai-data-center-boom-for-investors-and-consumers/ — retrieved 2026-05-10 — ERCOT 360 GW queue, 7.4 GW 2026 → 228 GW 2032 data-center submissions.
[13] https://naturalgasintel.com/news/ercot-sees-power-load-breaking-records-as-data-centers-call-on-natural-gas/ — retrieved 2026-05-10 — ERCOT peak load records, BTM gas trend.
[14] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — GE Vernova 100 GW backlog into 2029–30, 20% explicitly data-center tied.
[15] https://rbnenergy.com/daily-posts/blog/pipeline-buildout-set-unlock-permian-natural-gas-production-growth-later-2026 — retrieved 2026-05-10 — Permian takeaway buildout >4.5 Bcf/d in 2H26.
[16] https://www.bakerbotts.com/thought-leadership/publications/2025/july/texas-senate-bill-6-understanding-the-impacts-to-large-loads-and-co-located-generation — retrieved 2026-05-10 — SB 6 details: 50% backup, curtailment, 12/31/2025 threshold.
[17] https://hughbrinsonpipeline.com/the-project/ — retrieved 2026-05-10 — Hugh Brinson 400 mi / 42 inch / 1.5 Bcf/d Phase 1 Q4 2026.
[18] https://naturalgasintel.com/news/energy-transfer-expands-permian-gas-network-as-data-center-demand-surges/ — retrieved 2026-05-10 — Energy Transfer–Oracle 900 MMcf/d, three campuses.
[19] https://fortune.com/2026/04/01/microsoft-chevron-exclusivity-powering-west-texas-data-center-complex/ — retrieved 2026-05-10 — Chevron–Microsoft 2.5 GW West Texas hub, late 2027.
[20] https://www.dmagazine.com/commercial-real-estate/2025/12/dallas-and-data-centers-are-booming-whats-in-the-venn-diagram/ — retrieved 2026-05-10 — Dallas 1 GW colo online (98% leased) + 600 MW under construction (95% preleased).
[21] https://www.thestockobserver.com/2026/05/07/atmos-energy-nyseato-updates-fy-2026-earnings-guidance.html — retrieved 2026-05-10 — 51k new customers TTM, 39k+ Texas adds, FY26 EPS guidance raise.
[22] https://services.austintexas.gov/edims/document.cfm?id=453315 — retrieved 2026-05-10 — 2025 Atmos Mid-Tex rate case settlement, 14.1% residential ex-gas-cost increase.
[23] https://s201.q4cdn.com/158157484/files/doc_financials/2025/ar/2025-Annual-Report.pdf — retrieved 2026-05-10 — FY25 annual report segment data; Pipeline & Storage segment financials.