Now I have enough to write. Drafting the dossier now.

# FFIV — F5, Inc.

## Where this sits in the AI stack
F5 sells L4–L7 application delivery and security: physical and virtual ADCs (BIG-IP appliances, BIG-IP Next, BIG-IP Virtual Edition), the NGINX reverse proxy/ingress family, and a layered AI-traffic management stack (F5 AI Gateway, AI Guardrails, AI Red Team) [1][8]. In an AI context, F5 sits **downstream of the GPU compute layer**: where inference traffic terminates inside an enterprise data center, on a neocloud edge, or at a Kubernetes cluster boundary, F5 boxes (or BlueField-3 DPUs running F5 software) handle TLS termination, request routing across multiple model endpoints, prompt/response inspection, rate-limiting on a per-token basis, and policy enforcement. They do **not** participate in training, are **not** in the NVLink/InfiniBand scale-up fabric, and are largely irrelevant to frontier model training. Their AI exposure is to **enterprise inference** — particularly self-hosted, multi-model inference inside large regulated enterprises and at telco/sovereign edges [2][6].

## Snapshot
- **Price:** $354.03 (2026-05-08 close) [9]
- **Market cap:** $19.97B [9]
- **52-week range:** $223.76 – $354.50 [3][9]
- **Forward P/E:** 21.5× (on FY26 consensus EPS ~$16.27) [4][9]
- **EV / NTM revenue:** 5.87× (EV $18.79B; ~$1.2B net cash) [9]
- **Consensus 12-month price target:** $320 (implied **−9.6%** vs. spot) [4]
- **YTD total return:** ~+23% (estimate; stock ~$287 in early Jan 2026) [10] — could not source a precise YTD figure from primary data
- **Short interest (% of float):** 3.11% [9]
- **Dividend yield:** n/a — F5 does not pay a dividend; capital return is via buyback ($502M in FY25) [9][11]

## Moat — what it is physically made of
The "F5 moat" is three structurally different things stacked on top of each other; their durability is very different.

**1. Operational lock-in on the BIG-IP installed base (highest durability).** BIG-IP is not "a load balancer" — it is a programmable traffic manager with iRules (TCL-based), iApps templates, an entire TMOS network microkernel that handles flow state at line rate, and decades of accreted policy logic that lives only inside customer config repos. A Fortune 500 with 500+ BIG-IP devices typically has tens of thousands of iRules written by network teams over 10–15 years; rip-and-replace requires equivalent rule-by-rule reverse engineering on a different control plane (NetScaler, AVI, Envoy). This is a true switching cost, not "we like this vendor." The 81% gross margin on services (FY25) is the financial fingerprint of that lock-in [11]. **Person-years to replicate at parity in a single large enterprise: roughly 15–40 engineer-years per ~1,000-device estate, a number I am inferring from documented Citrix→F5 and F5→AVI migration timelines.**

**2. Hardware refresh on rSeries / VELOS chassis (medium durability).** The 26% systems-revenue growth in Q2 FY26 is largely a refresh of a base that was last upgraded around the 2018–2020 i-Series cycle [5][7]. This is a real cash-flow tailwind but it is a **cycle**, not a moat. After two strong refresh years it normalizes.

**3. AI-traffic differentiation via NVIDIA BlueField-3 offload (low–medium durability, highest optionality).** F5's BIG-IP Next for Kubernetes runs as DPU-resident software on BlueField-3 SuperNICs inside the NVIDIA Enterprise AI Factory validated design [12][13]. The Tolly Group benchmark — vendor-commissioned but methodology disclosed — reports +40% token throughput, −34% latency, and −61% TTFT versus the host-CPU control [12][14]. The technical mechanism is real: BlueField-3 offloads the TLS, the TCP/QUIC termination, and the AI-aware load-balance decision out of the x86 host, freeing host CPU and avoiding PCIe round-trips that would otherwise contend with GPU traffic. **This is the only F5 component that touches the actual AI silicon stack.** Durability is uncertain because the same DPU runtime is open to competitors — NVIDIA explicitly wants a multi-vendor DPU ecosystem [14], and Cisco, Palo Alto, and the Envoy AI Gateway project are all working on equivalent BlueField/Intel IPU offloads.

**4. CalypsoAI for AI security (acquired Sep 2025 for ~$180M) [15].** A real database (~10,000 new attack patterns/month claimed) and a credible runtime guardrail product. Whether it is a moat or just a feature depends on whether enterprise procurement decides "AI security" is a separate SKU or a checkbox bundled into the existing CDN/WAF (Cloudflare, Akamai, Imperva).

**5. NGINX ecosystem (asymmetric).** NGINX powers a meaningful fraction of public-facing web servers; F5 monetizes only the Plus/enterprise sliver. NGINX Gateway Fabric replacing the EOL'd Ingress-NGINX in Kubernetes [8] is a credible distribution channel into AI workloads — but it is also fully open and competes with Envoy Gateway / kgateway in the same slot [16][17].

**Brand and "we are the network team's default" is real and shows up in 81% gross margin, but it is not a substitute for any of the above.**

## AI buildout bottleneck map
The actual gating constraints over the next 24 months and where FFIV sits on each:

- **Power generation & grid interconnect (gas turbine backlogs running 3–5 years; substation buildouts):** **Indifferent.** F5 ships ~25–50W per device class and is invisible at site-level power planning.
- **CoWoS-L advanced packaging (TSMC capacity rationed across NVIDIA/AMD/Broadcom):** **Indifferent.** F5 silicon (mostly merchant Intel Xeon plus a small custom FPGA/ASIC mix in rSeries) does not need CoWoS.
- **HBM3e / HBM4 supply (gated by SK Hynix / Micron / Samsung):** **Indifferent.**
- **400G / 800G optics & co-packaged optics:** **Beneficiary at margin.** F5 chassis terminate that traffic on the enterprise side, but optics shortage limits hyperscaler builds, not F5 throughput.
- **Liquid cooling at >100kW/rack:** **Indifferent.** BIG-IP is air-cooled.
- **DPU / SmartNIC supply (BlueField-3 allocation):** **Exposed customer.** F5's accelerated-inference story rides on BlueField-3 availability. NVIDIA prioritizes its own DGX Cloud and hyperscaler reference designs first [14]. If BlueField-4 (slated for the Vera Rubin generation in 2026 [18]) compresses the BlueField-3 lifecycle, F5's certified-design story has to be re-validated.
- **Enterprise inference repatriation:** **Direct beneficiary.** F5's own 2026 State of Application Strategy survey (self-serving but corroborated by other industry data) reports 78% of enterprises now run inference in-house and average 7 production models [2][6]. Multi-model routing — picking GPT-class vs. Claude-class vs. open-weight Llama-class per request — is a genuine new control plane requirement that F5 is selling into [2].
- **Kernel/compiler talent, training data quality:** **Indifferent.**

**Net read:** F5 is not on the critical path for the AI buildout. It is a **second-derivative beneficiary** of inference workloads landing inside enterprise networks. This is a real but bounded tailwind.

## Competitive teardown
The competitive picture is genuinely fragmented across three battlefields, and F5 is ahead on one and exposed on the other two.

**1. Legacy enterprise ADC (north-south perimeter).** Citrix NetScaler is the only structural peer; A10 plays at the price-sensitive edge. Citrix has been distracted by ownership changes and product decisions that pushed customers toward F5 — F5's recent share gains here are real [19][20]. **F5 wins this fight today and probably for another 3–5 years.** Falsifier: a major Citrix-to-F5 migration reverses, or NetScaler ships credible AI-traffic features.

**2. Cloud-native L7 / API gateway / service mesh (east-west and increasingly north-south in K8s).** Envoy is the runaway data-plane standard, used by Istio, kgateway (Solo.io's CNCF donation), Envoy Gateway, and the Envoy AI Gateway (Bloomberg + Tetrate, CNCF) [16][17]. Kong AI Gateway extends the same model with multi-LLM routing [16][21]. **F5 has no structural advantage here**; it has a tactical advantage from BIG-IP Next being containerized and the BlueField-3 offload, but the open-source data plane is a permanent overhang. The honest read: in a cloud-native greenfield deployment, the default is Envoy-based, not F5-based. F5's defense is that the perimeter and the policy plane are still the network team's domain, and network teams buy F5 [22].

**3. AI gateway specifically.** Six credible vendors (F5, Envoy AI Gateway, Kong, Solo.io, Apache APISIX, Cloudflare AI Gateway) launched products in the 2024–2026 window [16][21][23]. Cloudflare's AI Gateway is a different product category entirely — a SaaS routing layer fronting OpenAI/Anthropic/Google APIs, not a proxy you run inside your data center [23][24]. The enterprise self-hosted AI gateway is **not yet a settled category**. F5's bet is that the network team owns this purchase; the cloud-native bet is that the platform-engineering team owns it via Envoy. **This is the single most important competitive question for the FFIV thesis and it is not resolved.**

**Base rate on platform shifts in network infrastructure:** Cisco took ~10–15 years to lose meaningful share in branch routing to SD-WAN; F5's prior generation of competitors (Foundry, Radware, Brocade ADX) took similar periods to be displaced. Cloud-native L7 displacement of enterprise ADC has already been "happening" for ~7 years and F5's revenue has still grown. The base rate says these transitions are **slower than tech press implies**, which is a positive for the bull case on a 3–5 year view and neutral on a 10-year view.

## Bull case — technical
For FFIV to outperform the next 24 months, the following technical conditions need to hold:

1. **Enterprise inference repatriation continues at the rate F5's own survey claims (78% running inference in-house, 7+ models in production [2][6]).** This is what justifies the AI gateway / multi-model routing as a separate line item in 2027–2028 enterprise budgets.
2. **BlueField-3 (and eventually -4) DPU offload is sticky as a co-marketed reference design.** NVIDIA Enterprise AI Factory becomes the default packaged enterprise AI box, and F5 stays in the validated stack [13]. The 40% throughput / 34% latency claims survive third-party MLPerf-style replication.
3. **The hardware refresh cycle (rSeries / VELOS) sustains for at least 4–6 more quarters.** Q2 FY26 systems +26% YoY [5] is unsustainable forever, but a 2-year double-digit run is plausible given the 2018–2020 install-base age.
4. **AI-attributed revenue compounds from $50M H1 FY26 (~$100M annualized) toward 8–10% of revenue by FY28.** That is the inflection that justifies multiple expansion above the current ~5.9× EV/sales [5][9].
5. **The cloud-native gateway war stays unresolved long enough for F5 to buy a seat at the table** (CNCF Gold membership, NGINX Gateway Fabric, MCP-aware proxy in BIG-IP v21 are all evidence of intent [8][25]).

If this holds, you get high-single-digit revenue growth, modest operating leverage, ~$1B annual buyback against a $20B cap shrinking the share count ~5% per year, and the multiple holds at 21–23×. Stock probably gets to $400–425 on a 12-month view.

## Bear case — technical
Symmetric and arguably more interesting.

1. **The AI gateway is not a separate product — it is a feature of Envoy Gateway and is open source.** Kong AI Gateway, Envoy AI Gateway (Bloomberg/Tetrate/CNCF), and kgateway already implement multi-model routing, token rate-limiting, and prompt/response inspection [16][17][21]. Once enterprise platform teams standardize on Envoy data plane (which has already happened for east-west service mesh), F5's AI Gateway becomes a parallel product the platform team has to be sold against open source. The 100-customer AI count [5] is small enough to disappear in a single procurement-cycle change.
2. **The DPU offload moat is rented from NVIDIA.** F5's BlueField-3 differentiation requires (a) NVIDIA continuing to push DPU-resident networking, (b) F5 retaining preferred validated-design status, and (c) competing offload software (Aviatrix, Cisco Hypershield, Palo Alto, native NVIDIA DOCA primitives) not commoditizing the same offload. None of these is guaranteed beyond 24 months. NVIDIA's incentive is multi-vendor DPU adoption, not F5 exclusivity.
3. **Hardware refresh is a cycle and decelerates.** The 26% systems growth in Q2 FY26 [5] re-bases higher and the tough comp arrives in FY27–28. If software growth stays mid-single-digit and systems normalizes to flat, total revenue growth reverts to 4–5%, which does not support a 21× forward multiple.
4. **Hyperscaler-native gateways take the AI inference market that matters.** AWS Bedrock, Azure AI Foundry, and GCP Vertex all embed gateway-equivalent functions natively. The portion of enterprise inference that lands inside hyperscaler-managed services never sees an F5 box.
5. **Customer concentration is non-trivial.** Two distributors >10% of revenue each [26] — typical of channel-led enterprise infra businesses, but it means quarterly results can wobble on distributor inventory decisions independent of underlying demand.

If two of these five hit, FY27 revenue growth decelerates to mid-single-digits, multiple compresses to ~16×, and the stock trades back to the $260–280 zone.

## Market view check
At $354, FFIV trades at 21.5× forward EPS and 5.9× EV/NTM revenue — a meaningful re-rating from the 12–14× forward multiple it carried in 2023–2024 when the consensus story was "ex-growth network appliance vendor with declining hardware." Consensus 12-month PT of $320 is **below** spot, meaning the sell-side already thinks the AI re-rating has overshot near-term [4][9]. The 58% trailing-12-month return [3] has compressed forward expected returns into the +/-10% band.

The market is implicitly believing: (a) the AI inference repatriation thesis is structural, not a 2026 fad; (b) the BlueField-3 partnership becomes a durable differentiator; (c) hardware refresh runs through FY27. **If even two of those hold, the current price is roughly fair.** What the market is **not** pricing is a serious cloud-native displacement scenario inside the AI workload — which is precisely the scenario a technical short would write.

The cleanest read: this is a **fairly-priced re-rated cyclical with optionality on a real but unproven AI inference category**. Not obviously cheap; not obviously expensive. The asymmetry is mediocre in either direction at $354 — better risk-reward exists in either the "AI silicon is overbuilt" trade (short NVDA/AVGO derivatives) or the "Envoy/CNCF wins the gateway category" trade (long PANW or selective cloud-native security plays).

## 90-day falsifiers
Specific, observable events between now and ~August 2026 that would update the thesis materially:

1. **Q3 FY26 earnings (~late July 2026):** AI-attributed revenue. H1 was ~$50M [5]; if Q3 alone prints >$40M, the AI flywheel is real. If Q3 prints <$25M, growth is decelerating sharply and the bear case strengthens.
2. **Q3 FY26 systems revenue YoY growth:** Above +20% sustains the refresh thesis. Below +10% says the cycle is rolling over.
3. **Independent (non-Tolly) benchmark of BIG-IP Next on BlueField-3 vs. Envoy AI Gateway on the same hardware**, ideally from a hyperscaler engineering blog or MLPerf-Inference. If the gap is <10%, the F5 differentiation story weakens.
4. **NVIDIA Enterprise AI Factory roster updates at GTC Fall 2026 (Oct):** does F5 stay the named L4–L7 partner, or does NVIDIA add Cisco/Palo Alto/Envoy AI Gateway to the validated design alongside?
5. **Any large neocloud (CoreWeave, Nebius, Crusoe, Lambda) announcing an F5 deployment for inference traffic** — currently absent from the customer list and would be a meaningful signal that the bull case is broadening past traditional enterprise.
6. **Citrix/NetScaler ownership news or product release** that re-energizes the ADC competitor — currently a dormant threat that could re-awaken.
7. **CalypsoAI integration milestones** — first GA bundle of AI Red Team + Guardrails + Remediate sold as one SKU at >$500K ACV [15][27].

## What I could not verify
- Precise FY26 YTD return — used an estimate based on a Jan 2026 reference price [10]; primary historical pricing was not directly retrievable.
- Tolly Group benchmark methodology details — the +40%/−34%/−61% numbers are vendor-commissioned and I could not find an independent replication [12][14].
- F5's actual share of the BlueField-3 attached-software market vs. competing DPU-resident network functions — NVIDIA does not break this out.
- Whether the "100 AI customers" figure [5] includes pilot/POC vs. paid production deployments.
- The split inside AI-attributed revenue between net-new logos and existing customers expanding — the call disclosed the aggregate but not the mix.
- Whether the two >10% distributors [26] are concentrated by end-market (e.g., federal vs. commercial), which would matter for the AI thesis.
- Citrix/NetScaler private financials post-Cloud Software Group ownership — direct competitive trajectory is hard to triangulate.
- Detailed gross-margin breakdown of systems vs. software vs. services beyond the blended 81% [11].

## Sources
[1] https://www.f5.com/ — retrieved 2026-05-10 — F5 corporate product taxonomy: BIG-IP, NGINX, Distributed Cloud, AI Gateway/Guardrails/Red Team
[2] https://www.businesswire.com/news/home/20260505145450/en/AI-Has-Left-the-Lab-F5-Report-Reveals-78-of-Enterprises-Now-Run-AI-Inference-as-a-Core-Operation — retrieved 2026-05-10 — F5 2026 State of Application Strategy report: 78% in-house inference, 7 models avg
[3] https://finance.yahoo.com/quote/FFIV/ — retrieved 2026-05-10 — Trailing 52-week return ~+32%; price history reference
[4] https://public.com/stocks/ffiv/forecast-price-target — retrieved 2026-05-10 — Consensus PT $320 median (range $250–$355) from 26 analysts; rating distribution
[5] https://www.f5.com/company/news/press-releases/earnings-q2-fy26 — retrieved 2026-05-10 — Q2 FY26 results: $812M revenue, +11% YoY, products +22%, systems +26%; AI ~$50M H1
[6] https://www.helpnetsecurity.com/2026/05/07/f5-ai-inference-operations-report/ — retrieved 2026-05-10 — Multi-model routing as enterprise problem; corroborates F5 survey framing
[7] https://www.investing.com/news/transcripts/earnings-call-transcript-f5-networks-beats-q2-2026-forecasts-shares-dip-93CH-4643237 — retrieved 2026-05-10 — Q2 FY26 transcript: revenue mix 51/49 product/services; AI customer count ~100
[8] https://www.networkworld.com/article/4143922/f5-brings-new-visibility-and-ai-controls-to-big-ip-nginx.html — retrieved 2026-05-10 — F5 March 2026 product launch: F5 Insight, AI Remediate, NGINX Gateway Fabric replaces Ingress-NGINX, BIG-IP v21.1 PQC
[9] https://stockanalysis.com/stocks/ffiv/statistics/ — retrieved 2026-05-10 — Price $354.03 (May 8 close), market cap $19.97B, EV $18.79B, fwd P/E 21.48, EV/Rev 5.87, short int 3.11%, no dividend
[10] https://intellectia.ai/stock/FFIV/forecast — retrieved 2026-05-10 — January 2026 reference price ~$287 used for YTD estimate (low confidence)
[11] https://www.f5.com/company/news/press-releases/earnings-fy25-q4 — retrieved 2026-05-10 — FY25 revenue $3.088B (+10%), gross margin 81.4%, $502M FY25 buyback
[12] https://www.f5.com/company/news/press-releases/f5-nvidia-ai-factory-economics-accelerated-inference — retrieved 2026-05-10 — F5 + NVIDIA March 2026: Tolly Group +40% throughput / 61% TTFT / 34% latency on BlueField-3
[13] https://www.f5.com/company/blog/f5-big-ip-next-for-kubernetes-joins-the-nvidia-enterprise-ai-factory-validated-design — retrieved 2026-05-10 — BIG-IP Next for Kubernetes in NVIDIA Enterprise AI Factory validated design
[14] https://developer.nvidia.com/blog/turbocharging-ai-factories-with-dpu-accelerated-service-proxy-for-kubernetes/ — retrieved 2026-05-10 — NVIDIA technical blog: DPU-accelerated service proxy mechanism, multi-vendor DPU framing
[15] https://www.f5.com/company/blog/what-are-ai-guardrails — retrieved 2026-05-10 — CalypsoAI acquisition closed; AI Guardrails + AI Red Team product details, 10K+ attack patterns/month
[16] https://jimmysong.io/blog/ai-gateway-in-depth/ — retrieved 2026-05-10 — Independent 2026 AI gateway market survey: F5, Envoy AI Gateway, Kong, Solo.io, APISIX
[17] https://tetrate.io/press/tetrate-and-bloomberg-release-open-source-envoy-ai-gateway-built-on-cncfs-envoy-gateway-project — retrieved 2026-05-10 — Envoy AI Gateway as CNCF/Bloomberg/Tetrate joint project
[18] https://en.wikipedia.org/wiki/Nvidia_BlueField — retrieved 2026-05-10 — BlueField-4 expected with Vera Rubin platform; BlueField-3 generational position
[19] https://hawatel.com/en/blog/netscaler-vs-f5-big-ip-analysis-of-features-security-and-costs/ — retrieved 2026-05-10 — Independent feature/cost comparison F5 vs. NetScaler
[20] https://www.parallels.com/blogs/ras/netscaler-vs-f5/ — retrieved 2026-05-10 — Citrix NetScaler positioning, Cloud Software Group context
[21] https://developer.konghq.com/ai-gateway/ — retrieved 2026-05-10 — Kong AI Gateway product capabilities
[22] https://hoop.dev/blog/what-envoy-f5-big-ip-actually-does-and-when-to-use-it/ — retrieved 2026-05-10 — North-south vs. east-west deployment model for F5 BIG-IP vs. Envoy
[23] https://blog.cloudflare.com/ai-platform/ — retrieved 2026-05-10 — Cloudflare AI Gateway architecture; SaaS routing layer for hosted models
[24] https://www.cloudflare.com/developer-platform/products/ai-gateway/ — retrieved 2026-05-10 — Cloudflare AI Gateway feature scope; not a self-hosted enterprise proxy
[25] https://community.f5.com/kb/technicalarticles/agentic-ai-with-f5-big-ip-v21-using-model-context-protocol-and-openshift/344501 — retrieved 2026-05-10 — BIG-IP v21 MCP protocol support, JSON-RPC visibility, K8s automation via CIS
[26] https://www.tradingview.com/news/tradingview:b5d126bbb0892:0-f5-inc-sec-10-k-report/ — retrieved 2026-05-10 — FY25 10-K: two distributors >10% of revenue; R&D $539.8M (+8.2% YoY)
[27] https://www.f5.com/company/news/press-releases/f5-to-acquire-calypsoai-to-bring-advanced-ai-guardrails-to-large-enterprises — retrieved 2026-05-10 — CalypsoAI acquisition deal terms (~$180M, Sep 2025)