# GEV — GE Vernova Inc.

## Where this sits in the AI stack
GEV sits **two layers below** the AI hardware stack that most investors fixate on: it manufactures and services the physical apparatus that converts hydrocarbons or fissile material into electrons and then steps those electrons up, down, and across distance to a data hall's switchgear. Specifically: H-class (7HA/9HA) and aeroderivative (LM2500/LM6000) gas turbines, the BWRX-300 small modular reactor (via the GE-Hitachi nuclear JV), HVDC converter stations, large power transformers (now scaled via Prolec GE), grid software, and onshore/offshore wind. The relevant workload it touches is not GPU FLOPs — it is the **24×7 ~100kW/rack thermal-and-power problem** sitting under every Blackwell/Rubin training cluster and inference fleet. GEV's exposure to AI is therefore through the bottleneck (firm baseload + grid plumbing), not through silicon.[1][2][3]

## Snapshot
- **Price:** $1,040.15 (2026-05-09 close)[4]
- **Market cap:** ~$280B (266–309B across sources depending on float treatment and intraday timing)[4][5]
- **52-week range:** $387.03 – $1,181.95[4]
- **Forward P/E:** ~64× (NTM consensus)[6]
- **EV / NTM revenue:** ~6.1× (EV ~$274B / $45B FY26 guidance midpoint)[5][7]
- **Consensus 12-month price target:** ~$1,039 average / $1,050 median across 24–34 analysts — implied ~0% from spot (sell-side has chased the move rather than anchored a thesis)[6]
- **YTD total return:** +71% to +76% depending on source[8]
- **Short interest:** 2.71% of float (~7.3M shares; up 22.8% from mid-March)[8]

## Moat — what it is physically made of
Stripped to components, the moat is not "industrial brand." It is four specific, separately durable physical and contractual assets:

**1. Hot-section metallurgy and the casting/forging supply chain.** An H-class turbine inlet runs above the melting point of its blades; survival depends on single-crystal nickel superalloy castings, directionally solidified vanes, and thermal-barrier coatings whose recipes are protected by both patent and process know-how. The forged rotors and the cast hot-section parts are bottlenecked at a handful of suppliers globally — **Howmet, Precision Castparts, Doncasters, Japan Steel Works** — most of whom already serve all three Western OEMs.[9][10] A new entrant cannot simply order these; the qualified-supplier list is the moat. GEV's allocation in this network is the asset, not the turbine drawings.

**2. The ~7,000-unit installed gas turbine base and its service annuity.** A heavy-duty turbine operates 25–30 years; the OEM owns hot-gas-path inspection, blade replacement, and digital twin optimization for that life. Services are >55% of GEV's $163B total backlog (~$81B services backlog).[11] This is **structurally analogous to commercial aero-engine aftermarket economics** (GE Aerospace, Rolls-Royce, P&W) — a high-margin annuity insulated from new-build cycles. The 100 GW backlog being booked at +10–20 pts $/kW vs. Q4 2025 prices creates a *compounding* annuity because every new HA shipped today is a 30-year service contract starting in 2027–2030.[12][13]

**3. Prolec GE + the large-power-transformer GOES supply chain.** With standard LPT lead times at 128–144 weeks (and specialty units reaching 4–5 years), domestic transformer capacity has become its own moat.[14][15] GEV consolidating Prolec gives it scale on grain-oriented electrical steel (GOES) procurement — a market with effectively 4 mills globally (Nippon Steel, JFE, POSCO, Stelco) — and 25%-growth-since-acquisition backlog visibility.[16][17]

**4. BWRX-300 first-mover position.** The Ontario Power Generation Darlington unit is under construction (CNSC license issued April 2025; construction began May 2025; commercial operation targeted late 2029).[18] Among Western SMRs (NuScale, TerraPower, X-energy, Holtec SMR-300, Westinghouse AP300, Rolls-Royce SMR), BWRX-300 is the first to break ground. The moat here is regulatory pathway and Gen-III BWR pedigree, not nuclear physics — natural-circulation cooling and ~10% the complexity of a traditional BWR.[18][19]

**Where the "moat" is thinner than narrative:** GEV's offshore wind business has demonstrated negative durability — Haliade-X blade-bonding defects forced Vineyard Wind blade removals and the segment is guided to ~$400M EBITDA loss in 2026.[20][21] Onshore wind has scale but commoditizes against Vestas and Goldwind. Grid software is sub-scale relative to Hitachi Energy and Schneider. Treat the moat as a **gas+grid+nuclear** moat, with wind as a stranded cost.

**Base rate on displacement.** Heavy-duty industrial gas turbines have an 80-year incumbency curve. The 2-firm-plus-one structure (GE Vernova, Siemens Energy, Mitsubishi Power) hasn't seen a successful Western new entrant in 50+ years. Comparable: commercial widebody jet engines (GE/RR duopoly), narrow-body (CFM/P&W/RR). New entrants take 20–30 years to qualify on the supplier-list side alone. This is closer to aerospace propulsion than to semiconductors — moats erode in *decades*, not quarters.

## AI buildout bottleneck map
The actual gating constraints on AI infrastructure scaling, 2026–2028, and where GEV sits:

| Bottleneck | GEV position | Evidence |
|---|---|---|
| **Generation capacity (24×7 firm)** | **Primary supplier-side beneficiary** | 100 GW backlog + slot reservations, targeting 110+ GW EoY 2026; orders booked into 2030[12][13] |
| **Gas turbine lead time (~5 yrs for large units)** | **Constraint owner** — slot allocator | Wood Mac: gas turbine prices +195% by 2027[22] |
| **Castings/forgings (Howmet, PCC, JSW)** | Exposed customer (shares queue with Siemens, Mitsubishi, aero) | Limited supplier set; rotor and hot-section bottleneck[9] |
| **Large power transformers (GSU + substation)** | **Supplier-side beneficiary via Prolec** | LPT lead times 128–144 weeks; ~50% of planned 2026 US DC projects at risk of delay due to grid equipment[14][15] |
| **HVDC converter stations + cable** | **Supplier-side beneficiary** ($10B HVDC backlog) | Q1 2026 large new HVDC order in Asia; Europe primary[7] |
| **Grid interconnect queue (PJM, ERCOT, MISO)** | Indifferent — GEV ships equipment regardless | Behind-the-meter co-location trend bypasses queue (Chevron/EN1/GEV 4 GW)[23] |
| **Liquid cooling >100kW/rack** | Indifferent (Vertiv/Schneider/CoolIT) | Not GEV's layer |
| **Advanced packaging (CoWoS-L), HBM, optics** | Indifferent — TSMC/SK Hynix/Coherent layer | n/a |
| **SMR commercial operation pre-2030** | **First-mover** (BWRX-300) | Darlington Unit 1 in construction; 3 follow-ons ordered[18][24] |
| **Electrical contractor / skilled labor for buildout** | Exposed — affects customer project schedule | Diffuse industry shortage |

The thesis-relevant observation: **GEV is the most concentrated public-market exposure to the binding constraint of AI infrastructure today**, which is firm power and grid plumbing, *not* compute. NVIDIA sells the bottleneck of last year. GEV sells the bottleneck of this year and next.

## Competitive teardown

**Siemens Energy (closest analog).** SGT-9000HL at 880 MW combined-cycle, >64% efficiency — at parity with GE 9HA on raw thermodynamics.[25] Siemens reported a €136B backlog in Q1 FY26 and doubled gas turbine units sold YoY (100→194).[26][27] Where Siemens wins: 50 Hz European utility relationships, hydrogen-readiness narrative. Where GEV wins: 60 Hz North American installed base (the AI demand center), HA-class operating-hour pedigree (Bouchain 62.22% net CC record stands), aeroderivative coverage for fast-deploy bridge power (LM2500/LM6000), and SMR optionality. **For the AI-power thesis specifically, GEV's advantage is geographic — North American hyperscaler buildout — not technical superiority.**

**Mitsubishi Power.** M501JAC is a credible 60 Hz competitor; first-mover on 30% hydrogen blending (relevant for IRA §45V projects).[28] Asia-dominant; growing in North America via the IPP channel. Real, not a strawman — they will share the cycle. They are unlikely to take material US data-center share given GEV/Siemens incumbency on US balance-of-plant and service networks.

**Caterpillar / Solar Turbines / Wärtsilä / Cummins (reciprocating engines and small aeroderivatives).** This is the *non-obvious* competitive vector. Meta's Socrates project (New Albany, OH; ~200 MW each, 2026 in-service) selected **Solar Turbines Titan 250s, Siemens SGT400s, and Caterpillar 3520 reciprocating engines** — *not* GEV HA platforms.[29] The reason: HA-class lead time is 4–5 years; reciprocating engines and 30-MW-class turbines ship in 12–24 months and can be deployed in modular trains. **For "bridge" or "first phase" power on a 24–36 month construction window, GEV's HA is the wrong product.** This matters because every MW that goes to reciprocating engines is a MW that's harder for GEV to convert to its HA service annuity later. GEV is responding by pushing aeroderivatives — but the share of fast-deploy power going to Caterpillar/Solar/Wärtsilä is a real headwind to watch.

**Chinese OEMs (Dongfang, Harbin, Shanghai Electric).** F-class 50 MW G50 export to Kazakhstan; H-class development targeted for 2030.[30][31] **Not a competitive threat in the next 24 months** for the US hyperscaler market — Western OEM service network, project-finance acceptance, and component sourcing all argue against. Becomes relevant for emerging market data center buildout post-2028.

**Transformer side: Hitachi Energy, Hyundai Electric, Hyosung, ABB, Eaton.** All scaling. Prolec gives GEV legitimate North American share, but the LPT market doesn't have a clear "winner" — supply growth is across all 5–6 majors. Treat the transformer business as **beneficiary of a rising tide**, not as a defended moat.

**SMR competitors.** NuScale (NRC-certified design but lost UAMPS customer in 2023), TerraPower (Wyoming Natrium, 2030+), X-energy (HTGR, gas-cooled), Holtec SMR-300 (Palisades site), Westinghouse AP300, Rolls-Royce SMR (UK). GEV-Hitachi BWRX-300 is the **only one in actual Western construction**. The window where this matters commercially is 2029–2032; in that window, FOAK economics will determine whether the platform earns its keep.

## Bull case — technical
For GEV to outperform from $1,040, the following must broadly hold:

1. **Hyperscaler firm-power demand stays inelastic.** Microsoft + Meta + Amazon + Google + Oracle have collectively signaled $690B 2026 capex.[32] If even 30% of incremental data-center load lands as behind-the-meter natural gas (vs. utility grid or renewables), the 100-GW backlog converts to firm orders at GEV's quoted price premium.[12]
2. **The service annuity compounds.** Every HA shipped 2025–2028 becomes a 25–30 year service contract. At >55% services in backlog already, the trajectory mechanically pushes consolidated EBITDA margin toward the 20% 2028 target.[13][33]
3. **Castings/forgings constraint persists 2027–2028**, sustaining the +10–20 pt $/kW pricing premium. This is the variable most under GEV's control — slot reservation discipline is the lever.
4. **Transformer shortage doesn't resolve before 2028.** GOES capacity additions take 3–4 years; demand is up 274% on GSU and 116% on substation since 2019.[14] Prolec runs at supply-constrained margins.
5. **BWRX-300 Darlington hits late-2029 COD within ±20% of budget.** Establishes the Western SMR reference plant; turns 8–12 GW of currently-soft SMR LOIs into firm orders.[18][24]
6. **Wind doesn't get worse.** $400M 2026 EBITDA loss is *priced in*; further blade defects or contract terminations are the tail risk.

Financial outcome under bull: 2028 revenue ~$55B (vs $44.5–45.5B 2026 guide, ~10% CAGR), 20% EBITDA margin → ~$11B EBITDA, FCF conversion ~70% → ~$7–8B FCF. At a 25× FCF multiple on industrial annuity-quality cash flow (services-tail justified premium), market cap $175–200B — i.e. **below today's price**. The bull case is therefore really about *time horizon and option value* on the 2030+ service tail beyond the 2028 window. The market is pricing GEV as if the H-class shipment vintage 2026–2030 is the most valuable cohort in the company's 80-year history. That can be true *and* still mean the multiple compresses.

## Bear case — technical
The short-seller who has done the work writes this version:

1. **AI capex is the marginal demand and AI capex is reflexive.** Hyperscaler capex grew because models scaled because Nvidia shipped because hyperscaler capex grew. If GPT-5/Claude-5/Gemini-3 generation models deliver sub-linear capability returns on compute (a real possibility given pretraining-compute scaling diminishing returns documented in arXiv literature), 2027–2028 capex revisions could be sharp. Slot reservation agreements are **not firm orders**; conversion rates under demand stress are uncertain. The 100 GW headline is partly a *forward indicator with cancellation optionality*.
2. **The substitution path is reciprocating engines and aeroderivatives, not HA-class.** Meta Socrates already chose Solar/Siemens-aero/Caterpillar.[29] Behind-the-meter, fast-deploy power favors 12–24 month products. GEV captures less of the 2026–2027 wave than the headline backlog suggests; the 100 GW skews to traditional utility customers (80% of contracted volume) whose load growth is more cyclical than AI.[13]
3. **Pricing is partly steel/copper inflation, not margin.** A +10–20 pt $/kW order book is welcome, but when GOES, nickel, and copper revert, ASPs follow. The Power segment 17–19% margin guide is contingent on holding the pricing premium *and* on commodity stability — both at peak.
4. **64× forward P/E on an industrial.** Even granting durable services moat, the multiple embeds a 5-year hyper-growth path. Industrial peers (Siemens Energy, Caterpillar, Eaton) trade at 20–30× forward. The variance from 64× to 30× is a -50% multiple compression risk even if EPS grows in line.
5. **SMR optionality is a 2030+ story with FOAK execution risk.** Vogtle 3/4 final cost was 2.5× initial estimate. BWRX-300 Darlington is FOAK; "$5B/unit" claims should be discounted heavily.
6. **Chinese OEM commoditization** is a 2028–2032 risk, but Dongfang's H-class development trajectory toward 2030 is real, and the global ex-OECD market is sizable.[30][31]
7. **Wind is a strategic question, not just a cost.** Spinning out or shutting down offshore wind would be value-additive but cause one-time charges. Management has resisted; this is a governance overhang.

Financial outcome under bear: AI-driven slot reservations cancel 20–30% during 2027 capex normalization, revenue plateaus near $48–50B vs $55B+ embedded in the multiple, services backlog grows but at half the headline rate, EBITDA margin stalls at 16–17%. Multiple compresses to 30–35× forward earnings; stock at $500–650.

## Market view check
At $1,040, 64× forward P/E, ~6.1× EV/NTM revenue, and an essentially flat consensus price target, the market is pricing GEV as **a high-quality industrial that has just been re-rated to a quasi-software multiple** on the basis of: (a) a 100 GW gas-turbine backlog that effectively pre-sells the next 4–5 years of output, (b) +10–20 pt pricing power on incremental orders, and (c) a credible 2028 path to 20% EBITDA margins.[12][13] What the market is *implicitly* believing: that AI-driven firm-power demand sustains through 2030 without a meaningful pause, that hyperscaler slot reservations convert to firm orders at near-100%, and that GEV holds pricing while commodity inputs stabilize. The technical reality I've described supports parts 1–2 (the bottleneck is real, GEV's incumbency in castings/forgings/service is real), but **stock-level upside requires the 2030+ service-tail to be valued more aggressively than it already is**. Symmetry of risk-reward at $1,040 looks closer to balanced than the +70% YTD might suggest. The opportunity is not "buy GEV here" — the opportunity was 2024–2025. The thesis from here is more about whether the *service annuity quality* of the 2026–2030 shipment cohort is being properly valued, which is a question I can argue either way.

## 90-day falsifiers
Specific things checkable by August 2026 that would update the thesis materially:

1. **Q2 2026 gas turbine backlog progression.** Bull falsified if backlog growth slows to <5 GW QoQ (vs 17 GW Q1 jump). Bear falsified if backlog crosses 115 GW (above year-end target).
2. **Slot reservation → firm order conversion ratio disclosure.** Management may quantify in Q2 call. Conversion <80% historical = bear validated.
3. **Hyperscaler Q2 capex guidance.** A >10% sequential cut in any of MSFT/META/GOOG/AMZN/ORCL FY26 capex guidance is a leading indicator. Particularly watch Meta and Microsoft direct power commentary.
4. **Pricing on Q2 orders vs Q1 +10–20 pt premium.** Plateau or reversal = bear.
5. **Any HA-class blade or hot-section defect disclosure.** Operational quality issue on the install base would be material; watch CNBC/utility-press for outages.
6. **BWRX-300 Darlington construction milestones.** Schedule slippage or cost re-estimate before COD would price in FOAK risk early.
7. **Wind segment Q2 EBITDA.** If losses exceed $150M (vs ~$100M run-rate to hit ~$400M FY guide), the goodwill question reactivates.
8. **MI400 / FP4 multi-node MLPerf submissions.** Adjacent but relevant: any AMD competitive surprise that compresses near-term hyperscaler GPU capex would flow through to GEV slot reservations within 1–2 quarters.

## What I could not verify
- **Exact 60 Hz vs 50 Hz split** of GEV's HA-class installed base. I asserted 60 Hz North American dominance based on the data-center customer geography but did not source a unit-count split.
- **GEV's specific allocation share at Howmet / Precision Castparts / Japan Steel Works** vs Siemens and Mitsubishi. The bottleneck structure is sourced; the *relative* GEV share at each supplier is opaque (commercial-confidential supplier relationships).
- **Slot reservation → firm order historical conversion rate.** Management discusses backlog discipline but I could not find a publicly disclosed historical conversion ratio. This is the single most important number for the bear case.
- **The fraction of the 100 GW backlog priced under inflation pass-through clauses** vs fixed price. Margin durability depends on this; I did not locate the contract structure breakdown.
- **2026 NTM EPS consensus.** I inferred ~$16.25 from the 64× P/E at $1,040, but did not find a directly sourced consensus EPS estimate. The press release's $4.7B Q1 net income appears to include a discrete item (likely tax) and is not a clean run-rate.
- **Specific Prolec backlog book-to-bill** and the GOES contract terms — disclosed at segment level only.
- **Whether the Chevron / Engine No. 1 / GEV 4 GW deal is fully under firm contract or remains LOI/MOU stage** at the time of writing.[23]
- **Microsoft 1.4 GW West Virginia deal turbine OEM selection** — letter of intent only, not confirmed GEV.

## Sources
[1] https://www.gevernova.com/gas-power/products/gas-turbines/h-class-gas-turbines — retrieved 2026-05-10 — established the HA-class product line (7HA/9HA) at >64% combined-cycle efficiency.
[2] https://www.gevernova.com/gas-power/industries/data-centers — retrieved 2026-05-10 — established GEV's product positioning for data center bridge and primary power.
[3] https://www.gevernova.com/nuclear/carbon-free-power/bwrx-300-small-modular-reactor — retrieved 2026-05-10 — established BWRX-300 product positioning and natural-circulation design.
[4] https://finance.yahoo.com/quote/GEV/ — retrieved 2026-05-10 — established spot price $1,040.15, 52-week range, market cap.
[5] https://www.macrotrends.net/stocks/charts/GEV/ge-vernova/market-cap — retrieved 2026-05-10 — market cap and EV cross-check.
[6] https://www.gurufocus.com/term/forward-pe-ratio/GEV — retrieved 2026-05-10 — forward P/E ~64×.
[7] https://www.fool.com/earnings/call-transcripts/2026/04/22/ge-vernova-gev-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1 2026 transcript: HVDC $10B backlog, Asian HVDC win.
[8] https://www.marketbeat.com/stocks/NYSE/GEV/forecast/ and https://fintel.io/ss/us/gev — retrieved 2026-05-10 — consensus PT, YTD return, short interest.
[9] https://www.powermag.com/gas-turbine-supply-chain-bottlenecks-could-reshape-the-generation-mix-in-2030-and-beyond/ — retrieved 2026-05-10 — Howmet/PCC/JSW castings and forgings bottleneck.
[10] https://www.primary.vc/articles/the-gas-turbine-bottleneck-reshaping-energy-infrastructure-ex8qe — retrieved 2026-05-10 — supplier-set bottleneck structure.
[11] https://www.gevernova.com/sites/default/files/gevernova_2025_annual_report.pdf — retrieved 2026-05-10 — installed base ~7K gas turbines, ~59K wind, services backlog $81B+, services >55% of backlog.
[12] https://www.utilitydive.com/news/ge-vernova-gas-turbine-backlog-hits-100-gw-as-prices-rise/818332/ — retrieved 2026-05-10 — Q1 2026 100 GW backlog, +10–20 pt $/kW pricing.
[13] https://www.gevernova.com/news/press-releases/ge-vernova-reports-first-quarter-2026-financial — retrieved 2026-05-10 — Q1 2026 results: $9.3B revenue, $163B backlog, 110 GW year-end target, segment margin guides, 80/20 utility/data-center mix.
[14] https://www.powermag.com/transformers-in-2026-shortage-scramble-or-self-inflicted-crisis/ — retrieved 2026-05-10 — LPT lead times 128–144 weeks; 274% GSU demand growth since 2019.
[15] https://www.bloomberg.com/news/newsletters/2026-04-01/us-data-center-boom-relies-on-hard-to-find-electrical-equipment — retrieved 2026-05-10 — half of planned 2026 US DC builds at risk from electrical equipment shortage.
[16] https://www.gevernova.com/news/press-releases/ge-vernova-completes-prolec-ge-acquisition — retrieved 2026-05-10 — Prolec acquisition close in Feb 2026.
[17] https://www.gevernova.com/sites/default/files/gev_webcast_transcript_10222025.pdf — retrieved 2026-05-10 — Q3 2025 transcript: Prolec backlog growth, transformer category positioning.
[18] https://www.gevernova.com/news/press-releases/ge-vernova-hitachi-bwrx-300-small-modular-reactor-approved-construction-province-ontario-opg — retrieved 2026-05-10 — Ontario/OPG construction approval, May 2025 start.
[19] https://en.wikipedia.org/wiki/BWRX-300 — retrieved 2026-05-10 — design lineage to ESBWR, natural circulation cooling.
[20] https://www.windtech-international.com/company-news/ge-vernova-reports-mixed-performance-in-wind-business — retrieved 2026-05-10 — 2025 wind segment $0.6B EBITDA loss, -6.6% margin.
[21] https://www.offshorewind.biz/2025/01/21/canada-made-ge-vernova-blades-to-be-removed-from-vineyard-wind-1-site/ — retrieved 2026-05-10 — Haliade-X blade defect, Vineyard Wind blade removals.
[22] https://www.utilitydive.com/news/gas-turbine-supply-crunch-set-to-raise-prices-195-by-2027-woodmac/816904/ — retrieved 2026-05-10 — Wood Mackenzie +195% gas turbine pricing forecast by 2027.
[23] https://www.chevron.com/newsroom/2025/q1/power-solutions-for-us-data-centers — retrieved 2026-05-10 — Chevron / Engine No. 1 / GEV 4 GW JV using 7HA turbines.
[24] https://www.gevernova.com/news/press-releases/province-of-ontario-to-deploy-additional-ge-hitachi-bwrx-300-small-modular-reactors — retrieved 2026-05-10 — Ontario ordering three additional BWRX-300 units at Darlington.
[25] https://www.siemens-energy.com/global/en/home/products-services/product/sgt5-9000hl.html — retrieved 2026-05-10 — Siemens SGT5-9000HL 880 MW CC, >64% efficiency.
[26] https://www.enlit.world/library/siemens-energy-boasts-record-gas-turbine-orders-in-response-to-demand-boom — retrieved 2026-05-10 — Siemens Energy €136B backlog, 100→194 gas turbine units YoY.
[27] https://www.asminternational.org/massive-gas-turbine-demand-powers-up-siemens-other-providers/ — retrieved 2026-05-10 — Siemens 2024→2025 turbine unit doubling.
[28] https://power.mhi.com/regions/amer/products/gas-turbines/m501j — retrieved 2026-05-10 — Mitsubishi M501JAC specifications and 30% hydrogen capability.
[29] https://www.power-eng.com/onsite-power/onsite-gas-turbines-reciprocating-engines-to-power-meta-data-center/ — retrieved 2026-05-10 — Meta Socrates project: Solar Titan 250, Siemens SGT400, Caterpillar 3520 — confirming non-GEV selection for fast-deploy.
[30] https://www.newenergyera.com/news/chinas-self-developed-f-class-50-mw-heavy-duty-gas-turbine-enters-overseas-market-for-the-first-time.html — retrieved 2026-05-10 — Dongfang G50 F-class first overseas export to Kazakhstan.
[31] https://www.turbomachinerymag.com/view/china-claims-breakthrough-in-independent-manufacture-of-advanced-gas-turbines — retrieved 2026-05-10 — Chinese H-class development timeline targeting 2030.
[32] https://introl.com/blog/hyperscaler-capex-690-billion-microsoft-azure-power-bottleneck-2026 — retrieved 2026-05-10 — 2026 hyperscaler capex $690B aggregate figure.
[33] https://www.gevernova.com/news/press-releases/ge-vernova-raises-multi-year-financial-outlook-doubles-dividend-increases-buyback-authorization — retrieved 2026-05-10 — 20% adjusted EBITDA margin target by 2028.