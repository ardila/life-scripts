# MDB — MongoDB, Inc.

## Where this sits in the AI stack
MDB sits at the **application data layer**, not in the AI infrastructure substrate. It sells (1) a managed multi-cloud document database (Atlas, ~72% of revenue) [4][6]; (2) a self-managed binary (Enterprise Advanced) [10]; and (3) a vector retrieval stack — Atlas Vector Search backed by HNSW indexes on dedicated Search Nodes [11], plus the Voyage AI embedding/reranker family acquired Feb 2025 for ~$220M [5]. The relevant AI workload is **not training or accelerator inference** — it is RAG retrieval, agent state/memory, and operational data for LLM-driven applications, where MDB competes for the role of the OLTP-plus-vector substrate underneath the model layer. Real-time, transactional, multi-tenant, mid-millisecond — not batch analytical.

## Snapshot
- **Price:** $299.50 (2026-05-10 intraday) [1]
- **Market cap:** ~$24.07B [1]
- **52-week range:** $148.88 (2025-04-22) – $444.72 (2026-01-07) [1][2]
- **Forward P/E:** 45.5× (vs. software-infra median ~18×) [3]
- **EV / NTM revenue:** ~8.2× (EV ~$23.6B against FY27 guide midpoint $2.88B; net cash $453M) [1][8][23]
- **Consensus 12-month price target:** $368.67 (33 analysts; +23% implied) [9]
- **YTD total return:** −26.6% (as of 2026-05-08) [13]
- **Short interest (% of float):** 4.5% of shares outstanding (~3.6M shares) [13]

## Moat — what it is physically made of
MDB's moat is software-layer, not physical. Decomposed by component, with durability rated separately:

1. **Driver/SDK ecosystem.** Idiomatic native drivers in 12+ languages (PyMongo, Motor async, Node, Go, Java, Rust, C#); BSON binary wire format avoids the JSON ser/deser tax that pure-JSON document stores carry. *Inference:* ~5–15 person-years per driver to reach API-and-perf parity, ~100 person-years aggregate for a clean-sheet competitor — meaningful but not unique (Postgres' driver set is at least as broad). **Durability: medium.**
2. **Aggregation pipeline + query language.** `$lookup`, `$facet`, `$vectorSearch`, `$rankFusion` operators compose hybrid (lexical+vector+filter) retrieval in a single round-trip [11]. SQL+pgvector requires CTE/subquery composition that is harder to express and tune. **Durability: medium** — Postgres extensions are catching up but the specific operator surface is mature.
3. **Search Nodes / workload isolation.** Vector index lives on a separate physical tier from OLTP nodes; HNSW with optional scalar (4× RAM reduction) or binary (24× RAM reduction) quantization [11]. Architecturally cleaner than vanilla pgvector, where the index serving and OLTP share Postgres' shared-buffer memory. *Caveat:* pgvectorscale + DiskANN closes much of the architectural gap — independent benchmarks show pgvectorscale at 471 QPS@99% recall on 50M vectors [12]. **Durability: medium and shrinking.**
4. **Voyage AI embeddings + rerankers.** voyage-3-large outperforms OpenAI text-embedding-3-large by ~9.7% and Cohere v3-English by ~20.7% averaged across 100 datasets in 8 domains; binary-quantized 512-d voyage-3-large beats 3072-d float OpenAI by 1.16% at ~200× lower storage [14]. Native auto-embedding ("write text, get vectors") removes a non-trivial integration step. **Durability: medium** — embedding leadership has historically reordered every 6–12 months; the *integration* moat outlives any specific model.
5. **Multi-cloud Atlas control plane.** Single API across AWS/Azure/GCP, including cross-cloud replica sets [15]. Hyperscaler-native NoSQL (DocumentDB, Cosmos DB, Firestore) cannot match this. **Durability: high** for customers explicitly seeking cloud neutrality; weak for those who have already made a single-hyperscaler bet.
6. **Customer install base & switching cost.** 65,200+ customers, 2,799 paying >$100K ARR [4]. Switching cost is real (re-architecting the data model, rewriting aggregation pipelines, retraining ops) but unlike Oracle is bounded by partial API-compatible alternatives (DocumentDB, FerretDB, Cosmos DB Mongo API) [16]. **Durability: high for installed base, low for greenfield.**

What this is *not*: MDB has no silicon, packaging, HBM, optical-fab, or kernel-library moat. The "moat" is software ergonomics + integration depth + install base. CUDA is not a useful analogy.

## AI buildout bottleneck map
- **Power / grid interconnect, CoWoS-L, HBM3e, optical fabric, >100 kW/rack liquid cooling, CUDA/Triton/NCCL talent:** Indifferent. MDB consumes hyperscaler IaaS; physical-layer constraints affect Atlas COGS at the margin, not market access.
- **Embedding inference capacity:** **Beneficiary + supplier.** Voyage models are served from MDB-managed infrastructure; cheap GPU inference subsidizes their offering and they sell it as a feature.
- **Application-layer state for agents (long-running memory, multi-session context):** **Beneficiary.** Every credible agent framework (Claude Agent SDK, OpenAI Agents, LangGraph, Anthropic memory primitives) ships a "bring your own database" abstraction [17][20]. MongoDB is one credible default.
- **Developer mindshare:** **Constraint owner / structurally exposed.** Stack Overflow 2024 dev survey: PostgreSQL 48.7% used vs. MongoDB 25.3% [18]. The gap has widened post-2022. This is the single biggest non-financial risk to the moat.

Net: MDB sits cleanly above the physical-buildout bottleneck stack. The bottlenecks that matter to MDB are **mindshare** and the question of whether AI-native apps default to Postgres or to document stores — both are software/social phenomena, not silicon.

## Competitive teardown
- **Postgres + pgvector (Supabase, Neon, RDS Aurora, Cloud SQL).** Dominant gravitational threat. Vendor benchmarks show pgvector 4–15× faster than MongoDB on certain query patterns at small-to-mid scale [19] (vendor benchmarks are biased; treat as directional). pgvectorscale + DiskANN closes the index-architecture gap [12]. Engineering teams report collapsing multi-database stacks back to Postgres because Postgres now does vector + JSONB + full-text + graph extensions in one engine [20]. *What would have to be true for MDB to hold:* at scale (≥100M vectors, multi-tenant, multi-region, with concurrent OLTP), Search Nodes' workload isolation and Voyage's retrieval quality outweigh Postgres' simplicity. Plausible at the high end; doubtful in greenfield.
- **Snowflake Cortex Search / Databricks Vector Search / Mosaic AI.** Targeting RAG over data already in the warehouse/lakehouse [21]. Different workload — batch/near-real-time over analytical data, not real-time OLTP retrieval. Limited direct overlap, but they own the embedding-of-existing-enterprise-data motion that MDB cannot easily contest.
- **Pinecone, Weaviate, Chroma, Qdrant.** Pinecone reportedly ~$14M revenue [22] — small relative to either MDB or the standalone-vector thesis they need to justify. As every operational DB ships native vector, the standalone proposition is structurally weakened. Pinecone has technical merit but the bundling argument has run against it.
- **AWS DocumentDB / Azure Cosmos DB Mongo API.** Wire-protocol-compatible (mostly), single-cloud, lower feature parity. DocumentDB mindshare 8.1% in early 2026, down from 9.9% [16]. Hyperscaler bundling is the lever; the feature gap (no Vector Search parity, no Voyage, partial aggregation pipeline) is meaningful.
- **Oracle 23ai AI Agent Memory.** Unified vector + relational + JSON + graph "AI memory core" [17]. Real for Oracle-installed enterprises, irrelevant for greenfield AI startups.

Honest read: on real-time operational + vector workloads at scale, MDB has parity-or-better architecture (Search Nodes, quantization) and a genuine retrieval-quality lead (Voyage). On developer mindshare and greenfield startup adoption, MDB is losing.

## Bull case — technical
For MDB to outperform, the following technical conditions need to hold:
1. **Production agentic-AI apps grow into multi-million-document, multi-tenant, real-time workloads** where pgvector's single-binary scaling cracks. Search Nodes' isolated vector tier becomes a TCO advantage above some scale threshold (very approximately: ≥10M vectors per tenant + concurrent OLTP).
2. **Retrieval quality is repriced as a first-order driver of agent accuracy/cost.** Voyage's MTEB lead [14] translates into measurable downstream agent outcomes; customers stop treating embeddings as commodity.
3. **The document model is the natural shape for LLM outputs** — JSON-shaped, varying schemas, embeddings as fields. "Store the structured object Claude just returned" has lower friction in MongoDB than schema-evolving SQL tables.
4. **Multi-cloud increasingly matters** as enterprises de-risk single-hyperscaler dependency and as cross-region sovereignty rules harden.
5. **Voyage embedding inference becomes a discrete revenue line**, not just an Atlas accelerant.

Connect to financials: 21–23% Atlas growth in FY27 [23] re-accelerates to ≥25% in FY28 as AI workloads materialize; EPS grows into the multiple, supporting consensus PT of $369. **Base rate caveat:** software-platform displacement is *slow but monotone*. Postgres has been "winning" since 2010 and only reached 48.7% mindshare in 2024 [18]; MongoDB at 25.3% has been remarkably persistent. Database moats erode over decades, not quarters — that cuts both ways.

## Bear case — technical
1. **Postgres + pgvector(scale) is "good enough" for the median greenfield AI app.** The default is already Postgres-on-Supabase/Neon. As those startups grow up, they don't migrate to Mongo; they scale Postgres. The AI-native cohort is disproportionately Postgres-shaped, and that gap compounds.
2. **The AI cohort is not yet material to MDB results.** Management has acknowledged the AI cohort is "not a material driver of growth this quarter" through FY26 [13][24]. If AI revenue does not visibly accelerate Atlas growth above the 21–23% guide, the bull thesis is empirically falsified.
3. **Atlas growth is decelerating from 29% (Q4 FY26) to 21–23% (FY27 guide)** [23]; the stock dropped 20% on the print [23]. If AI does not offset the maturation curve of the core OLTP business, growth keeps decelerating.
4. **Voyage's lead is fragile.** Embedding leaderboards reorder every 6–12 months; Gemini, Cohere, BGE, and an unending stream of open-weights models contest the top of MTEB [14]. The integration moat outlives any specific model — the "best embedding" *pitch* may not.
5. **Hyperscaler bundling.** As DocumentDB / Cosmos / Firestore add Vector + LLM-bridge features inside the cloud-credit envelope, pricing pressure grows on Atlas inside single-cloud customers. (DocumentDB mindshare is down [16], but the bundling lever is permanent and cyclical.)
6. **Sales-org disruption.** CRO Capombassis and President of Field Operations Pech departed; new CRO Mac Ban started April 27, 2026 [25]. Sales-org rebuilds are typically 2–4 quarter overhangs.
7. **Non-Atlas (EA) revenue is shrinking** mid-single-digits in FY26 as multi-year deals roll off [26]; that drag continues into FY27.

Short-seller summary: ~46× forward earnings for 16–18% guided revenue growth, with the AI catalyst now 18 months in and not visible in the numbers, against a structural mindshare trend that runs the wrong way.

## Market view check
At $299.50, MDB trades ~46× forward EPS and ~8× NTM EV/revenue [3] for a business guided to 16–18% growth in FY27 [23] at ~30% adj. operating margin. The multiple bakes in re-acceleration. Consensus PT $369 (+23%) [9] implies the sell-side largely shares the bull view that Atlas growth troughs in FY27 and re-accelerates as AI workloads materialize. The 26.6% YTD drawdown from the $445 January high [13] suggests the market is no longer fully convinced — it has paid back most of FY26-print enthusiasm. The asymmetry depends almost entirely on whether the AI cohort meaningfully accelerates Atlas in 2H FY27. If it does not, the multiple is too high. If it does, it is roughly right.

## 90-day falsifiers
- **Q1 FY27 print (May 28, 2026) [1]:** Atlas growth ≥26% (matching the guide) **with** management explicitly attributing acceleration to AI workloads — not "AI not material this quarter." A miss or repeat of the Q4 commentary further damages the thesis.
- **Voyage standalone disclosure.** If management refuses to size Voyage revenue or AI-cohort Atlas consumption discretely, the "AI is a catalyst" narrative loses falsifiability on the margin.
- **MongoDB World 2026** (June, annual). Watch Anthropic/OpenAI integration depth and whether MCP server adoption is quantified beyond "thousands of users weekly."
- **pgvector 0.9 / pgvectorscale GA on managed Postgres** (RDS, Aurora, Cloud SQL, Cosmos PG). Each closes the architectural gap MDB cites in marketing.
- **A high-profile AI-native company publicly migrating off MongoDB to Postgres, or vice versa.** Either direction is a strong signal — these migrations are usually announced because they are both expensive and reputational.
- **Hyperscaler Q2 2026 capex commentary (NVDA, MSFT, GOOGL, META, AMZN).** A >10% sequential cut to AI capex guidance compresses every AI-adjacent multiple, MDB included; an upward revision is the inverse.

## What I could not verify
- Specific net revenue retention (NRR) figure for FY26 — MongoDB no longer routinely discloses the precise number; I have customer count and Atlas net adds but not NRR.
- AI-cohort Atlas revenue contribution as a precise %; management characterizes AI as "not yet material" [13][24] but does not quantify.
- Voyage AI standalone revenue post-acquisition and current FTE engineering headcount on the Voyage stack.
- Independent (non-vendor) MLPerf-style retrieval-quality benchmarks across MongoDB Vector Search vs. pgvectorscale vs. Pinecone at >100M-vector scale; vendor benchmarks abundant but mutually contradictory.
- Whether MongoDB's incremental "AI customers" are net-new logos or cross-sells into existing Atlas accounts (the materiality of the AI thesis hinges on this).
- The actual share of Atlas Search Nodes consumption that is AI-driven vs. classical full-text search.

## Sources
[1] https://finance.yahoo.com/quote/MDB/ — retrieved 2026-05-10 — current price ($299.50 intraday), market cap ($24.07B), Q1 FY27 earnings date May 28, 2026, 52-week range
[2] https://stockanalysis.com/stocks/mdb/ — retrieved 2026-05-10 — historical price reference and 52-week high/low corroboration
[3] https://www.gurufocus.com/term/forward-pe-ratio/MDB — retrieved 2026-05-10 — Forward P/E 45.53 (May 6, 2026), 151% above software-infra median 18.13
[4] https://investors.mongodb.com/news-releases/news-release-details/mongodb-inc-announces-fourth-quarter-fiscal-2026-financial — retrieved 2026-05-10 — Q4 FY26 revenue $695.1M (+27%), Atlas +29%, 65,200+ customers, 2,799 >$100K ARR
[5] https://investors.mongodb.com/news-releases/news-release-details/mongodb-announces-acquisition-voyage-ai-enable-organizations — retrieved 2026-05-10 — Voyage AI acquisition Feb 2025, ~$220M
[6] https://www.fool.com/earnings/call-transcripts/2026/03/02/mongodb-mdb-q4-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q4 FY26 transcript: Atlas $2B+ run rate, 72% of revenue
[7] https://www.prnewswire.com/news-releases/mongodb-inc-announces-fourth-quarter-fiscal-2026-financial-results-302701531.html — retrieved 2026-05-10 — official Q4 FY26 press release corroborating customer and revenue metrics
[8] https://www.gurufocus.com/term/enterprise-value-to-revenue/MDB — retrieved 2026-05-10 — EV ~$19.2B (May 5), TTM revenue $2.46B, EV/Rev 7.79; cash $490M, debt $36.5M
[9] https://www.wallstreetzen.com/stocks/us/nasdaq/mdb/stock-forecast — retrieved 2026-05-10 — 33-analyst consensus PT $368.67, Buy rating
[10] https://www.thefastmode.com/technology-solutions/44732-mongodb-brings-vector-search-ai-applications-to-self-managed-data-centers — retrieved 2026-05-10 — Vector Search now in Community Edition / Enterprise Server (was Atlas-only)
[11] https://www.mongodb.com/docs/atlas/atlas-vector-search/vector-quantization/ — retrieved 2026-05-10 — HNSW algorithm, scalar (4×) and binary (24×) quantization, Search Nodes architecture
[12] https://blog.vectorchord.ai/vector-search-over-postgresql-a-comparative-analysis-of-memory-and-disk-solutions — retrieved 2026-05-10 — pgvectorscale 471 QPS@99% recall on 50M vectors
[13] https://www.ainvest.com/news/mongodb-faces-growth-dilemma-ai-vector-search-adoption-doubles-total-revenue-deceleration-signals-maturing-cycle-2605/ — retrieved 2026-05-10 — vector search customers nearly doubled YoY but AI not yet a material growth driver; YTD return −26.58%
[14] https://blog.voyageai.com/2025/01/07/voyage-3-large/ — retrieved 2026-05-10 — voyage-3-large vs. OpenAI/Cohere on MTEB; binary-quantized 512-d outperforms 3072-d float
[15] https://www.mongodb.com/docs/atlas/architecture/current/deployment-paradigms/multi-cloud/ — retrieved 2026-05-10 — multi-cloud across AWS/Azure/GCP, cross-cloud replica sets
[16] https://www.peerspot.com/products/comparisons/amazon-documentdb_vs_mongodb-atlas — retrieved 2026-05-10 — DocumentDB mindshare 8.1% Jan 2026, down from 9.9%; feature parity gaps
[17] https://blogs.oracle.com/database/introducing-oracle-ai-agent-memory-a-unified-memory-core-for-enterprise-ai-systems — retrieved 2026-05-10 — Oracle AI Agent Memory product launch (competitive context)
[18] https://tech-insider.org/sql-vs-nosql-2026/ — retrieved 2026-05-10 — Stack Overflow 2024: PostgreSQL 48.7% used, MongoDB 25.3%
[19] https://www.myscale.com/blog/pgvector-vs-mongodb-comprehensive-performance-analysis/ — retrieved 2026-05-10 — pgvector 4–15× faster on certain query patterns vs MongoDB (vendor benchmark; directional)
[20] https://www.softwareseni.com/how-postgres-became-the-ai-agent-substrate-for-memory-branching-and-modern-hosting/ — retrieved 2026-05-10 — engineering teams collapsing multi-DB stacks back to Postgres for AI agent workloads
[21] https://www.snowflake.com/en/engineering-blog/cortex-search-unmatched-quality-simplicity/ — retrieved 2026-05-10 — Snowflake Cortex Search positioning vs. Mosaic AI Vector Search
[22] https://getlatka.com/companies/pinecone.io — retrieved 2026-05-10 — Pinecone ~$14M revenue, 4K customers (small relative to claim)
[23] https://www.investing.com/news/earnings/mongodb-stock-plunges-20-on-weak-guidance-despite-q4-earnings-revenue-beat-93CH-4536068 — retrieved 2026-05-10 — FY27 revenue guide $2.86–2.90B (16–18%), Atlas 21–23%, stock −20% post-print
[24] https://www.ainvest.com/news/mongodb-q3-2026-earnings-call-contradictions-emerge-ai-integration-atlas-growth-revenue-guidance-2512/ — retrieved 2026-05-10 — Q3 FY26 commentary: AI cohort not material driver of growth this quarter
[25] https://www.stocktitan.net/news/MDB/mongo-db-inc-announces-fourth-quarter-fiscal-2026-financial-t0n63lj6sx5y.html — retrieved 2026-05-10 — CRO Capombassis departure, Mac Ban appointment effective April 27, 2026
[26] https://www.fool.com/earnings/call-transcripts/2025/08/26/mongodb-mdb-q2-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Non-Atlas (EA) revenue declining mid-single digits FY26 due to multi-year deal roll-off