# AKAM — Akamai Technologies, Inc.

## Where this sits in the AI stack
AKAM sits at the **inference distribution + application-security layer**, not the silicon, packaging, training-cluster, or kernel-toolchain layers. Physically it operates ~4,400 edge PoPs across 700 cities in 130+ countries [4], a Linode-derived IaaS with Linode Kubernetes Engine (LKE), and is now deploying "thousands" of NVIDIA RTX PRO 6000 Blackwell Server Edition GPUs (96–192GB GDDR7, FP4-capable, 600W class — workstation/server-tier, NOT NVL72 scale-up SKUs) as the first global implementation of NVIDIA's "AI Grid" reference design [4][7][16]. Workloads target **real-time and agentic inference, regulated/sovereign serving, and DDoS/WAF/API-security**. The legacy CDN delivery business (~36% of revenue) is in secular decline; security (~55%) is the durable cash generator; the AI Inference Cloud (CIS, ~9% and growing 40% YoY [19]) is a credible but unproven call option. AKAM does **not** participate in frontier training.

## Snapshot
- **Price:** $147.71 (2026-05-08 close, post-Q1 print) [1][15]
- **Market cap:** $21.75B [15]
- **52-week range:** $69.78 – $147.71 (new high set on the post-earnings move) [15]
- **Forward P/E:** 20.5× (on NTM consensus EPS $7.19; FY26 guide $6.40–7.15 → mid-pt ~21.8×) [15][2]
- **EV / NTM revenue:** ~5.9× (EV $26.68B / FY26 guide mid-pt $4.50B) [15][19]
- **Consensus 12-month price target:** ~$120 pre-earnings median (range $72–$134, 42 analysts); refreshing post-print, with Piper Sandler raised to $156 and KeyBanc to $195 within 24 hours of the Q1 release — blended sell-side consensus is in active reset upward, ~$130–145 likely landing zone (implied roughly flat to –10% vs spot) [20]
- **YTD total return:** +69.3% [15]
- **Short interest (% of float):** 11.68% — elevated, indicates real bear conviction [15]

## Moat — what it is physically made of
The moat is **geography + security incumbency**, not silicon, CUDA, or compiler IP. Decompose:

1. **Physical PoP footprint (4,400 edge sites, 700 cities, 130+ countries) [4]**: 25-year build-out, much of it via ISP cage colocation at last-mile peering points. Hard to replicate in pure capex terms, but Cloudflare (335+ cities) and AWS CloudFront (600+ PoPs + 40+ Local Zones + Outposts) are functional substitutes for most non-sovereign traffic, and CloudFront's embedded-PoP strategy (caches inside last-mile ISPs) bypasses Akamai's main last-mile edge for cacheable content [12]. **Durability: medium for delivery, higher for sovereign/regulated workloads.**

2. **Anycast BGP routing + EdgeWorkers V8 runtime**: Mature, but Cloudflare Workers and AWS Lambda@Edge are at parity-or-better on developer experience; Cloudflare claims a >4M-developer base; Akamai discloses no comparable number. **Durability: low on developer mindshare.**

3. **Foundational consistent-hashing + real-time mapping algorithms** (Leighton/Lewin, STOC 1997 [17]): now CS-curriculum standard. **Zero defensible IP today.**

4. **Security stack — the actual moat**:
   - **Guardicore microsegmentation** (acquired 2021): agent-on-host, process-level visibility; leader in Gartner microsegmentation reviews; agent-installed = high rip-out cost.
   - **API security** via the Neosec + Noname acquisitions: behavioral baselining of API traffic — combination gives the broadest dedicated API-security suite of any vendor [18].
   - **WAF with global telemetry**: ML rules trained on tens of trillions of attack signals/year; this is a real network-effect moat that Cloudflare contests but neither dominates.
   This is ~55% of revenue and where customer lock-in is strongest. **Durability: high.**

5. **Linode IaaS + LKE**: Acquired 2022 for $900M. Simpler-than-AWS K8s + ~50% lower compute pricing for like-for-like. **Not** hyperscaler-class — no Bedrock, no SageMaker, no managed vector DB at parity. Differentiation = price + simplicity + global distribution. **Durability: moderate but undifferentiated on capability.**

6. **NVIDIA partnership (first global AI Grid rollout) [4][6]**: Co-marketing, not exclusive allocation. Cisco, HPE, T-Mobile, Verizon all have AI Grid implementations of the same NVIDIA blueprint [6]. AKAM has no preferential access to GB200/B300 NVL72 systems — its order is "thousands" of RTX PRO 6000s, modest by hyperscaler standards. **Not moat-grade.**

Bottom line: defensible moat = security + sovereign-CDN. AI inference cloud is a credible call option; the underlying silicon and runtime substrate (NVIDIA, Triton, vLLM) are commodities AKAM consumes, not produces.

## AI buildout bottleneck map
- **Power & grid interconnect** (turbines backlogged 3–5 yrs at GE Vernova/Siemens Energy): AKAM's pattern is ~10–50 kW per edge site, not GW-scale concentrated load. **Indifferent / mildly advantaged** — does not compete with hyperscalers for transmission queues.
- **CoWoS-L advanced packaging / HBM3e/HBM4**: RTX PRO 6000 Blackwell uses **GDDR7, not HBM** [7]. AKAM is unaffected by the binding HBM/CoWoS allocation queues that gate H100/B200/MI300X supply. **Indifferent — small structural advantage on supply availability of its specific SKU.**
- **Optical interconnect / NVLink scale-up fabric**: AKAM's distributed-grid design deliberately avoids NVL72-class scale-up domains. **Indifferent.**
- **Liquid cooling >100 kW/rack**: RTX PRO 6000 in 2U/4U is **air-coolable** [7]; AKAM's edge sites need no DLC retrofits. **Mild advantage** — colocation is far easier to source than DLC-ready hyperscaler greenfield.
- **Electrical-contractor capacity**: Indifferent.
- **Kernel/compiler talent**: AKAM is a **consumer** of Triton Inference Server, vLLM, TensorRT-LLM. It does not write kernels. Cloudflare wrote its own engine ("Infire" in Rust, ~7% faster than vLLM 0.10 on H100 NVL [8]). **Exposed** if customers value sub-runtime optimization.
- **Training-data quality at the frontier**: Indifferent — AKAM serves inference, not training.

Net: AKAM is largely **indifferent to the hardest 2026 bottlenecks**, which lowers execution risk but also bounds the AI tailwind. The constraint AKAM relieves for customers is **inference latency at geographic scale + sovereign data residency** — real, but a secondary bottleneck behind power/HBM/CoWoS.

## Competitive teardown
- **Cloudflare (NET)** — most direct. Q1 2026 rev $639.8M, +34% YoY; Workers AI on H100 NVL across 180+ cities; custom Infire inference engine (Rust) claimed 7% faster than vLLM 0.10 on H100 [8][10]. Cloudflare cut 1,100 jobs (~20%) on an "AI-first restructuring" [10] — telling on operating leverage. **Axes**: Cloudflare leads on developer ecosystem, runtime sophistication (Infire vs commodity Triton), and free-tier funnel; AKAM leads on enterprise relationships, regulated/sovereign workloads, and raw PoP count. **On developer-platform AI inference, Cloudflare is ahead today; on enterprise/sovereign inference, AKAM is ahead.** Different pools.
- **Hyperscalers (AWS CloudFront/Local Zones/Outposts, Azure Front Door, GCP CDN)**: bundle pricing destroys CDN economics; AWS Local Zones (40+) and Outposts collapse the latency gap in tier-1 metros. **Conceded for hyperscaler-customer workloads; advantaged for non-hyperscaler enterprises and tier-2/3 geographies.**
- **Fastly (FSLY)**: smaller, struggling; not a meaningful peer.
- **CoreWeave / Lambda / Crusoe / neoclouds**: serve frontier training and centralized inference on H100/H200/B200 clusters. Different layer. Convergence risk if they bolt on multi-region inference, but today no overlap with AKAM's distributed grid.
- **NVIDIA AI-Grid partner ecosystem (Cisco, HPE, telecom operators)** [6]: NVIDIA's reference design is non-exclusive; AKAM's "first" is timing, not architecture. **Strategic medium-term threat** as telco operators (with deeper last-mile presence than AKAM) deploy the same blueprint on their own infra.
- **NVIDIA itself**: partner, but its economic interest is volume — no incentive to favor AKAM's deployment over telcos or hyperscalers.

Honest read: AKAM's specific defensible niche is **enterprise / sovereign / regulated distributed inference**. Real, but bounded TAM.

## Bull case — technical
For AKAM to outperform from $147.71 over 24 months, the technical conditions are:
1. **Edge inference becomes the dominant pattern for real-time/agentic workloads** where p95 <100 ms matters. Plausible: industry "inference inversion" thesis, ~73% of orgs moving inference to edge per recent surveys [11][21].
2. **RTX PRO 6000 Blackwell at FP4 proves adequate** for 70B-class quantized model serving at the edge — eliminating the need for H100/B200 clusters for many production workloads. Currently plausible (FP4 70B fits comfortably on a single 192GB-class GPU).
3. **The Anthropic deal is the first of 3–5 frontier-model wins**, not a one-off. Mgmt's commentary that "GPU pipeline significantly exceeds existing inventory" [2], paired with stated $200–250M-per-incremental-customer commit sizes, would imply $1B+/yr of additional CIS revenue by 2027 if conversion holds.
4. **Security growth re-accelerates** above 11% as AI-driven attack surface (zero-day discovery + agentic exfiltration vectors) expands the WAF/API-sec/microsegmentation TAM — a thesis Tom Leighton stated explicitly on the Q1 call [2].
5. **Delivery decline moderates to –3% to –5%** (mgmt expects this) [2] rather than accelerating to –10%+.
6. **CIS gross margins normalize to 50–60%** as scale absorbs depreciation; today CIS depreciation is running ahead of revenue ramp, structurally drag.

If all hold: revenue $5.5–6B by FY28, op margin re-expanding past 26%, multiple steady at 5–6× EV/sales → ~$200+ stock.

**Base-rate caution**: distributed-edge platform shifts have historically taken 5–10 years to dominance (CDN itself: 1998→2008; mobile-edge MEC announced 2013, still <5% share of inference today). 24-month bull cases on platform-shift narratives over-index on near-term proof points. Probability-weight accordingly.

## Bear case — technical
A short-seller who actually understands the stack would argue:

1. **Inference economics favor concentration, not distribution.** Batching at concurrency 256+ cuts cost-per-token 5–20×. A distributed grid is structurally low-batch (sparse local demand) — AKAM's per-token economics will be 3–10× worse than centralized hyperscaler inference for non-latency-critical workloads. The Anthropic $1.8B / 7yr deal works out to ~$257M/yr [3][5] — vs. Anthropic's ~$10B/yr+ AWS commitment [14] and >1GW Google TPU expansion [13]. AKAM is **<3% of Anthropic's planned compute spend**, plausibly tail/burst capacity, and structurally cancellable.
2. **RTX PRO 6000 is the wrong silicon for frontier-class workloads.** It's a workstation/visualization SKU. Customers wanting H100/B200/GB200 NVL72 economics will go to CoreWeave/Lambda/AWS. AKAM's grid is for sub-frontier, FP4-quantized, latency-sensitive workloads only — a real but narrower TAM than the headline implies.
3. **Delivery is in structural decline.** A ~$1.5B revenue line shrinking 7–10%/yr; even tripled CIS to $400M+ by 2028 only partially offsets the cancellation [2][19].
4. **Capex creep.** 40–42% of revenue in 2026 vs. ~15–20% historically [2]. CFO McGowan signaled potential mid-year increases if pipeline materializes [2]. FCF is squeezed; Q2 cash gross margin guided to ~70–71% (down from low-70s) **before** most GPU depreciation lands [2].
5. **Cloudflare is winning developer mindshare for edge AI** [8][9][10] — Workers AI + Infire + free tier + 4M-dev base. Enterprise sales motion is slower-converting and lower-multiple.
6. **No silicon/compiler moat.** AKAM's IP at the inference layer is orchestration software + customer relationships. If NVIDIA Triton + vLLM + open inference engines commoditize the runtime layer (they are doing so), AKAM is structurally a colocation operator + DDoS scrubber — historically a 3–4× EV/sales business, not 6×.

Bear path: CIS growth disappoints (50% drops to ~30% by 2027), delivery decline persists at –10%, capex creep continues, multiple compresses to 4× EV/sales → stock retraces to ~$90–100.

## Market view check
At $147.71 the market is paying ~5.9× NTM EV/sales and ~21× FY26 mid-pt EPS for a business growing top-line ~6–8% consolidated, with one fast-growing segment (CIS, +40–50%) inside two slower ones (Security +11%, Delivery –7%) [19][2]. For comparison: Cloudflare ~17× EV/NTM revenue with 34% growth — much higher multiple, much higher growth. AKAM at 5.9× looks reasonable IF the CIS second-leg is real; expensive vs. its own pre-AI history (~3–4× EV/sales as a CDN-only business). The 11.68% short interest [15] suggests informed bears think the rerate is fragile.

The market is implicitly betting on three things: (a) Anthropic is the first of several large CIS contracts, (b) edge inference is structurally competitive on cost-and-latency, and (c) delivery decline stabilizes. At least two of three need to hold to justify spot. **Asymmetric risk sits on (a)** — single-deal narratives lap themselves. My read: fairly priced to slightly rich for the current proof set; the case wants 3–4 quarters of evidence.

## 90-day falsifiers
Specific, observable events by ~Aug 8, 2026:
1. **Q2 2026 CIS revenue (early Aug print)**: must be ≥$110M sequentially to track guided ≥50% YoY. <$100M is a meaningful miss given the optionality embedded in the price.
2. **Q2 capex disclosure**: must come in ≤43% of revenue. >45% signals customer commits are running ahead of revenue and FCF impairment is worse than guided.
3. **Additional named CIS customer wins** (or silence): mgmt referenced 2–3 large pipeline opportunities in addition to Anthropic; absence of follow-on announcements over 90 days is bearish for the "first-of-many" thesis.
4. **Anthropic public confirmation/denial of the $1.8B deal**: Bloomberg-attributed only; neither party officially confirmed [5]. Public framing as "burst/tail capacity" weakens the narrative; framing as "primary regional inference partner" strengthens it.
5. **Cloudflare Q2 print (early Aug) — Workers AI revenue disclosure**: >$30M/qtr with strong sequential growth would weaken AKAM's competitive narrative on the developer-platform axis.
6. **MLPerf Inference v5.x submissions (likely Sept window)**: whether RTX PRO 6000 Blackwell shows competitive throughput on Llama-3-70B/405B FP4 vs. H100/H200. Closing latency-cost gap = bull validation; meaningful gap = bear.
7. **AWS pre-re:Invent Local Zones / Outposts expansion**: aggressive geographic expansion compresses AKAM's tier-2/3-city advantage directly.
8. **Q2 Delivery revenue trend**: worse than –7% (e.g., –10%) accelerates the cancellation-vs-growth math; better than –5% is the bull-case stabilization signal.

## What I could not verify
- The specific compute / network / security split inside the $1.8B Anthropic deal — only the headline $1.8B / 7 yr / $700M of 2026 capex is public [2][3].
- Whether the "frontier model provider" is in fact Anthropic — Bloomberg attribution only; neither party officially confirmed [5].
- AKAM's actual GPU unit count (only "thousands of RTX PRO 6000 Blackwell" disclosed [4][16]) and whether any B200/GB200 is in the mix.
- CIS-segment gross margin specifically — mgmt implied it is materially below the corporate ~70% blended cash GM but no figure given [2].
- Whether the security 11% growth is unit-driven or pricing-driven; Guardicore/API/WAF revenue split is undisclosed [19].
- Akamai EdgeWorkers developer-base size — Cloudflare publishes 4M+, AKAM does not.
- Energy efficiency / PUE of AKAM edge sites vs. hyperscaler regions.
- Customer concentration outside the top-10 disclosed list.
- True replacement cost of Guardicore microsegmentation in agent-deployed environments (anecdotally high, no quantitative source).
- Whether Cloudflare's Infire engine genuinely scales to large MoE models or is optimized for sub-13B dense — claimed benchmarks are vs vLLM 0.10 on H100 NVL [8], not full-stack production benchmarks.

## Sources
[1] https://stockstotrade.com/news/akamai-technologies-inc-akam-news-2026_05_08-2/ — retrieved 2026-05-10 — post-earnings price action and intraday range, May 8 close at $147.71.
[2] https://www.fool.com/earnings/call-transcripts/2026/05/07/akamai-akam-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1 2026 transcript: capex 40–42% of revenue, GPU pipeline commentary, segment guidance, Tom Leighton edge-vs-core inference framing.
[3] https://siliconangle.com/2026/05/07/akamai-shares-surge-26-1-8b-ai-infrastructure-deal-q1-results-meet-estimates/ — retrieved 2026-05-10 — confirms $1.8B / 7-year structure and 26% post-earnings move.
[4] https://www.akamai.com/newsroom/press-release/akamai-launches-ai-grid-intelligent-orchestration-for-distributed-inference-across-4400-edge-locations — retrieved 2026-05-10 — official disclosure: 4,400 locations, NVIDIA AI Grid, RTX PRO 6000 Blackwell deployment, BlueField DPUs.
[5] https://www.benzinga.com/markets/tech/26/05/52434312/anthropic-signs-1-8-billion-akamai-cloud-deal-amid-surging-claude-ai-demand-report — retrieved 2026-05-10 — Bloomberg-attributed identification of Anthropic; not officially confirmed by either party.
[6] https://blogs.nvidia.com/blog/telecom-ai-grids-inference/ — retrieved 2026-05-10 — NVIDIA AI Grid telecom-partner ecosystem (Cisco, HPE, telco operators alongside Akamai); non-exclusive.
[7] https://docs.nvidia.com/ai-grid/whitepapers/ai-grid-reference-design/hw_ref_design.html — retrieved 2026-05-10 — AI Grid reference design hardware: RTX PRO 6000 in 2U/4U, SN5400 leaf / SN5610 spine Spectrum-X fabric, BlueField DPUs.
[8] https://blog.cloudflare.com/cloudflares-most-efficient-ai-inference-engine/ — retrieved 2026-05-10 — Cloudflare Infire (Rust) inference engine, +7% throughput vs vLLM 0.10 on H100 NVL.
[9] https://workers.cloudflare.com/product/workers-ai — retrieved 2026-05-10 — Cloudflare Workers AI: GPU footprint of 180+ cities.
[10] https://www.cnbc.com/2026/05/07/cloudflare-net-q1-2026-stock-earnings-layoffs.html — retrieved 2026-05-10 — Cloudflare Q1 2026: $639.8M revenue +34%, 1,100 layoffs (~20% of workforce).
[11] https://www.distributedthoughts.org/2026-04-06-the-inference-inversion/ — retrieved 2026-05-10 — "inference inversion" thesis on distributed inference economics.
[12] https://blog.blazingcdn.com/en-us/biggest-cdn-providers-market-share-pop-count-2025 — retrieved 2026-05-10 — CDN market share + PoP counts; CloudFront embedded-PoP commentary.
[13] https://www.anthropic.com/news/expanding-our-use-of-google-cloud-tpus-and-services — retrieved 2026-05-10 — Anthropic-Google: up to 1M TPUs, >1 GW capacity in 2026.
[14] https://www.anthropic.com/news/anthropic-amazon-compute — retrieved 2026-05-10 — Anthropic-AWS: up to 5 GW Trainium2/3, $100B+ over 10 years.
[15] https://finviz.com/quote?t=AKAM — retrieved 2026-05-10 — AKAM market cap, EV, multiples, 11.68% short float, 52-week range, YTD +69.3%.
[16] https://www.crnasia.com/india/news/2026/akamai-deploys-nvidia-blackwell-gpus-to-build-distributed-ai-inference-platform — retrieved 2026-05-10 — "thousands of RTX PRO 6000" deployment commentary.
[17] https://en.wikipedia.org/wiki/F._Thomson_Leighton — retrieved 2026-05-10 — Tom Leighton background, MIT, consistent-hashing origin (STOC 1997).
[18] https://www.akamai.com/products/akamai-guardicore-segmentation — retrieved 2026-05-10 — Guardicore agent-based microsegmentation product details.
[19] https://www.akamai.com/newsroom/press-release/akamai-reports-first-quarter-2026-financial-results — retrieved 2026-05-10 — Q1 2026 segment revenue: CIS $95M (+40%), Security $590M (+11%), Delivery $389M (–7%); FY26 guide $4.45–4.55B and EPS $6.40–7.15.
[20] https://www.gurufocus.com/news/8846433/akam-reiterated-by-piper-sandler-price-target-raised-to-156 — retrieved 2026-05-10 — Piper Sandler post-earnings PT raise to $156; KeyBanc PT to $195 (separate report) [also confirms pre-earnings median ~$120].
[21] https://www.cio.com/article/4109609/edge-vs-cloud-tco-the-strategic-tipping-point-for-ai-inference.html — retrieved 2026-05-10 — Edge vs cloud TCO inflection; ~73% of orgs moving inference to edge, cost-reduction figures.