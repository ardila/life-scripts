I have enough to write the dossier. Drafting now.

# TRGP — Targa Resources Corp.

## Where this sits in the AI stack

TRGP does not sit *in* the AI stack — it sits two layers below it, in the **fuel supply chain for the power layer**. Specifically: Targa is the largest natural-gas gatherer and processor in the Permian Basin (~25% share by inlet capacity), owner of the Grand Prix and Daytona NGL pipelines into Mont Belvieu, and operator of the Galena Park LPG export terminal on the Houston Ship Channel. [1][2][3] The connection to AI is indirect: behind-the-meter gas-fired generators feeding West Texas data-center campuses (Chevron's 2.5–5 GW plant, Pacifico's 7.65 GW "GW Ranch," New Era's 1 GW project, etc.) consume Permian gas that TRGP gathers, processes, and helps move. [4][5][6] Treating TRGP as an "AI infrastructure powerhouse" — as some retail-oriented framing does [7] — is sloppy. It is a Permian midstream consolidator whose volumes get a marginal tailwind from data-center gas burn.

## Snapshot

- **Price:** $248.12 (2026-05-08 close; intraday range $247.42–$252.24 on 2026-05-10) [8]
- **Market cap:** $53.26B [9]
- **Enterprise value:** $72.29B [9]
- **52-week range:** $144.14 – $261.95 [10]
- **Forward P/E:** 22.85× (trailing P/E 25.31×) [9]
- **EV / EBITDA (trailing):** 13.86× — note this is ~60% above the midstream peer average ~8.7× cited for ET, EPD, MPLX [9][11]
- **EV / NTM EBITDA (implied):** ~12.5× on guided 2026 adjusted EBITDA midpoint of $5.8B [12][9]
- **EV / Revenue:** 4.36× [9]
- **Consensus 12-month price target:** ~$258 (range $212–$266 across providers, 13 analysts, Buy consensus) [13]
- **YTD total return:** ~+36% (2026 YTD) [10]
- **52-week total return:** +56% [9]
- **Short interest (% of float):** 2.20% [9]
- **Dividend yield:** 2.02% ($5.00 annualized; +25% hike for 2026) [9][14]

## Moat — what it is physically made of

This is a *physical* moat, not a software one — which matters because physical moats erode on geology and permit cycles, not Moore's Law. Decomposed:

1. **Permian gas processing scale (durable, 10–15 yr).** TRGP processes ~25% of Permian inlet gas. [1] Five new cryogenic plants (Roadrunner III 265 MMcf/d, Copperhead II 275 MMcf/d, plus Pembrook II/Bull Moose/East Pembrook) are coming online with aggregate inlet of 1.4 Bcf/d. [1][15] Building a Permian processing plant takes 24–36 months from FID, requires acreage dedications from producers, and an interconnect to a cryo train. A new entrant cannot displace TRGP at parity; capacity is added at the margin, and the marginal cryo train competes with TRGP's *next* train, not its installed base.

2. **Wellhead-to-water NGL chain (highly durable).** Grand Prix + Daytona = ~1 MM bpd of NGL takeaway from the Permian to Mont Belvieu; Targa's Mont Belvieu fractionation complex is at 963 kbpd with Trains 12 & 13 under construction; LPG exports from Galena Park run at ~14 MMBbl/month, expanding to 19 MMBbl/month by Q3 2027. [2][3][16] This integrated chain — gather → process → fractionate → export — is replicated by exactly two competitors at full scale (EPD, ET), and rebuilt by zero new entrants. Mont Belvieu siting and Houston Ship Channel berth permits are themselves a moat.

3. **Acreage dedications and contract life (medium).** TRGP's gathering acreage is dedicated under long-term agreements with Permian E&Ps; >90% of cash flow is fee-based, with the non-fee portion largely hedged for ~3 years. [17] Switching cost for a producer = pulling steel out of the ground.

4. **What is *not* a moat.** Brand and software are irrelevant here. The "Wellhead-to-Water" tagline is a marketing frame, not an asset. Patents are immaterial. There is no developer ecosystem.

A competitor (EPD, ET, MPLX) cannot replicate TRGP's Permian G&P footprint in <5 years and probably not at all without acquisitions — but EPD/ET already have *their own* integrated chains, so the relevant question is share at the margin, not replacement.

## AI buildout bottleneck map

Where TRGP sits versus the actual constraints on the 24-month AI buildout:

| Bottleneck | TRGP's role |
|---|---|
| **Power generation capacity (turbines)** | Indirect supplier. GE Vernova / Siemens / MHI gas-turbine backlogs are 3–5 years; TRGP supplies *fuel* once turbines arrive, doesn't relieve turbine constraint. |
| **Grid interconnect** | Beneficiary of bypass. Behind-the-meter gas plants in Pecos / Reeves / Ward counties exist precisely *because* ERCOT interconnect queues are 4+ years. TRGP's intra-basin gas plumbing avoids the grid. |
| **Permian gas takeaway (Waha→Gulf)** | **Constrained, but not TRGP's primary line.** Waha basis went negative for a record 12+ days in early 2026. [18] Blackcomb (2.5 Bcf/d) and GCX expansion add ~4.5 Bcf/d by late 2026 / 2027. [19] Long-haul takeaway is owned by ET, KMI, WMB, MPLX/Whitewater JVs — NOT TRGP. TRGP is *downstream of producers, upstream of long-haul* — it gathers and processes, then sells residue gas into Waha or hands NGLs to its own NGL line. |
| **HBM, CoWoS-L, optical, kernel talent** | Indifferent. |
| **NGL fractionation at Mont Belvieu** | TRGP is a beneficiary / capacity owner. Adding trains 12 & 13. [2] |
| **LPG export berth capacity** | TRGP is a beneficiary; ~20% of US LPG export goes through Galena Park. [16] |
| **Liquid cooling, electrical contractors** | Indifferent. |

The honest read: TRGP is a **second-derivative beneficiary** of the AI buildout. East Daley's published list of midstream names "uniquely positioned" for data-center gas explicitly names ET, KMI, TRP, and WMB — *not* TRGP. [20] TRGP's leverage is via Permian volume growth, of which an incremental few hundred MMcf/d will eventually serve Permian data centers, on top of the bigger LNG-and-power demand story.

## Competitive teardown

Real competitors, by axis:

- **Permian G&P share (TRGP's core franchise):** ENLC (acquired by ONEOK in 2025, now OKE-owned), MPLX, Energy Transfer, and Western Midstream are the meaningful incumbents. None has more than ~10–15% of Permian inlet vs. TRGP's ~25%. [1] OKE post-ENLC is the most credible #2 in G&P, with the added advantage of its own NGL takeaway. Threat: gradual share at the margin via new plants. Timeline to parity: not credible within 5 years.

- **NGL transportation Permian → Mont Belvieu:** EPD's Mid-America/Seminole/Shin Oak system competes head-to-head with Grand Prix/Daytona. ET's Lone Star is the third entrant. Both are scaled. **This is where TRGP does not have a moat; it has parity.** EPD has more downstream petchem integration; ET has more captive volume.

- **Mont Belvieu fractionation:** EPD is #1 (>1.1 MMbpd), TRGP #2 (~960 kbpd), ET #3. [2] Capacity is added in trains; current adds are demand-driven (Permian NGL supply growth + export demand).

- **LPG export:** EPD ~30% of US, TRGP ~20%, ET ~15%, Phillips 66/P66 the remainder. Targa's 19 MMBbl/month buildout vs. EPD's Neches River expansion (announced 2024–25) is the live capacity race. [16][3]

- **Long-haul gas takeaway from Permian:** TRGP **does not meaningfully compete here.** Matterhorn (MPLX/Whitewater/EnLink/Devon JV), GCX (KMI), Permian Highway (KMI/KMI), Whistler/Blackcomb (Whitewater/MPLX/ET/Devon JV) — these are the players. [19] If the AI thesis is about long-haul gas-to-power, TRGP is the wrong ticker.

- **AI / data-center gas supply contracts:** Energy Transfer is the cleanest public reference (the VoltaGrid / Oracle deal references ET pipeline supply). [21] No public TRGP equivalent. Management did not mention data centers, AI, or hyperscaler contracts in the Q1 2026 earnings call — a notable omission given the narrative. [22]

## Bull case — technical

For TRGP to outperform from $248 over 18–24 months, the following technical conditions need to hold:

1. **Permian gas growth continues at 5–7%/yr through 2027.** 27.6 Bcf/d (2025) → 29 Bcf/d (2026E) → ~31 Bcf/d (2028E). [18][19] TRGP captures ~25% of incremental inlet, so ~350–500 MMcf/d/yr of processing growth lands on TRGP plants — already supported by Roadrunner III + Copperhead II + Pembrook II.

2. **The Permian Delaware sub-basin remains the highest-growth zone**, where TRGP just paid $1.25B for Stakeholder Midstream (closed early 2026) and concentrated its 2026 plant builds. [12][15]

3. **NGL exports grow 5–8% globally**, driven by Asian petchem (ethane cracking in China, India), European ethane imports replacing pipeline gas, and LPG-for-cooking in EM Asia/Africa. Management called out "more inbounds … than I've ever seen" on multi-year LPG export contracts in Q1 2026. [22]

4. **Permian gas-to-power data centers reach 5–10 GW operating** by 2028 (vs. ~1–2 GW now announced), driving 1–2 Bcf/d of regional gas demand and tightening Waha basis. [4][6] This raises residue gas value for TRGP's commodity-exposed margin (small but non-zero).

5. **No major NGL fractionation overbuild at Mont Belvieu.** TRGP, EPD, ET all building, but demand absorbs.

Financial outcome: 2026 EBITDA midpoint $5.8B → 2028E ~$7.0–7.5B at high-single-digit organic growth + Stakeholder + LPG export expansion. At 12× forward EV/EBITDA the equity could be $290–$320, ~+20–30% from spot.

**Base rate caution:** Midstream "secular tailwind" stories (LNG 2018, ethane export 2015, shale crude 2013) historically delivered EBITDA growth but with multiple compression as buildout completed. The fact that TRGP trades at 13.9× trailing EV/EBITDA — well above the ~8–10× midstream norm — means the bull case is already substantially priced in. Past midstream re-ratings (KMI 2014, ETP 2014) gave back the premium when capex cycles peaked.

## Bear case — technical

A short-seller who understands the stack would write:

1. **The AI premium is misattributed.** TRGP's stock is up 56% over 52 weeks and trades at ~13.9× trailing EV/EBITDA vs. an 8.7× peer average. [9][11] The 5–6 multiple-point premium implies the market is paying for AI/data-center exposure that **TRGP's own management has not described in earnings calls**, that East Daley's analysis attributes to other midstream names, and whose direct realization (a hyperscaler PPA or behind-the-meter gas supply contract) has not been announced. [22][20]

2. **Permian volume growth is downstream of WTI economics, not AI.** Permian gas is ~85% associated gas — i.e., a byproduct of oil drilling. The marginal Midland barrel breaks even around $50–60/bbl WTI. If WTI compresses to $50 (OPEC capacity return + EV demand peak debate), Permian rig count falls 15–25%, gas growth flattens, and TRGP's 2027–28 plant utilization disappoints. The AI gas demand story does not bail this out — data center gas burn through 2028 is ~2–3 Bcf/d, vs. Permian production of ~30 Bcf/d; the marginal data-center demand is a rounding error against oil cycle risk.

3. **Capex intensity is heavy and rising.** Net growth capex of $4.5B in 2026 against $5.8B EBITDA = 78% reinvestment rate. Q1 alone was $948M. [12] This is a 3+ year capex cycle. If returns on incremental capital come in at 6–7× EBITDA build multiples instead of 5×, IRRs fall below cost of capital. Historical cautionary tale: ETE/ETP's 2014–2016 capex binge led to a 60% drawdown.

4. **Long-haul gas takeaway is the actual AI-gas trade and TRGP isn't in it.** ET, KMI, WMB, MPLX, Whitewater own the Permian-to-Gulf Coast (and Permian-to-Southeast/MidCon) pipelines that physically deliver gas to data center clusters. [20][19] An investor buying "AI gas" should own those names. TRGP is intra-basin G&P plus NGL.

5. **NGL fractionation and LPG export face simultaneous capacity additions from EPD and ET** — TRGP's Trains 12/13 and Galena Park 19 MMBbl/month are coincident with EPD's announced expansions. Mont Belvieu frac margins compressed in 2018–19 the last time the industry added simultaneously.

6. **Multiple compression risk on completion of capex cycle.** Historical base rate: midstream operators trading 13–14× EV/EBITDA during capex peaks have averaged ~150 bps of multiple compression per year over the following 24 months as capex completes and free cash flow shifts to dividends. A re-rate from 12.5× forward to 10× on 2028 EBITDA of $7B = EV $70B → equity ~$50B, roughly flat to spot despite real EBITDA growth.

Falsification of bull case: Stakeholder integration disappoints, Permian gas growth comes in 5–7% rather than 7–10%, or Waha overbuilds in 2027 and weakens producer economics.

## Market view check

Forward EV/EBITDA at ~12.5× on the high end of 2026 guidance is roughly 4 turns above the midstream peer average, and consensus PT of ~$258 implies ~+4% upside. [13][9] The market is pricing TRGP as the **highest-quality Permian midstream consolidator with a structural NGL-export call option** — not as a pure AI infrastructure play, despite some third-party framing to the contrary. The premium is largely justified by 25% Permian processing share, integrated NGL chain, fee-based earnings, and a credible 8–12% multi-year EBITDA growth profile. What the market may be underpricing: the heavy reinvestment rate and the dependency of volumes on Permian oil drilling rather than AI demand. What it may be overpricing: any direct AI/data-center contract value, which is currently zero based on disclosed contracts.

Net: not obviously mispriced. A more interesting trade exists in the *relative value* between TRGP (13.9× trailing) and direct gas-to-power beneficiaries like ET (~8.5× forward), WMB, KMI — if the AI gas thesis is the trade, ET/WMB are the higher-beta expressions at lower multiples.

## 90-day falsifiers

Specific, observable events through ~August 2026:

1. **Q2 2026 earnings call (~early August 2026):** Does TRGP management explicitly discuss data center gas contracts, behind-the-meter supply, or hyperscaler relationships for the first time? Currently absent from Q4 2025 and Q1 2026 calls. [22] An explicit contract disclosure would shift the narrative materially.

2. **Permian gas production July 2026 EIA Drilling Productivity Report:** Tracks toward 29 Bcf/d 2026E? A reading <28.5 Bcf/d or rig count falling >5% sequentially is bearish for TRGP volumes 12 months out.

3. **Waha basis trajectory:** Continued negative prints through summer 2026 — when normally cooling demand pulls gas — signals takeaway constraints tightening, hurting Permian producer economics and (eventually) TRGP volumes.

4. **Blackcomb pipeline in-service:** Whitewater guides late 2026; slippage to 2027 keeps Waha tight, mixed for TRGP (better residue netbacks short-term, weaker producer economics medium-term).

5. **Stakeholder Midstream integration update:** Q2 2026 should give the first clean view of acquired EBITDA. Any guidance miss vs. acquisition modeling is a yellow flag on capital allocation.

6. **EPD or ET announces a behind-the-meter gas supply contract with a named hyperscaler** in West Texas or the Gulf Coast. Each named contract redirects the "AI gas" premium to that ticker and away from TRGP.

7. **Hyperscaler Q2 capex guidance (MSFT, GOOG, META, AMZN):** Aggregate capex was tracking $725B for 2026. [23] A material cut (>10% sequential) caps the indirect Permian data-center buildout that supports TRGP's volume thesis.

8. **Chevron Permian data-center FID:** Initially targeted early 2026 [5]; an actual FID (or its slippage) signals Permian behind-the-meter gas demand timing.

## What I could not verify

- **TRGP's specific exposure (Bcf/d) to behind-the-meter Permian data center power supply.** No company disclosures; the connection is structural rather than contractual.
- **The percentage split of TRGP's adjusted EBITDA between G&P and L&T segments for 2026E.** Earnings supplement shows segment results but a clean forward split is not in public disclosures I could access.
- **Specific contract terms / fee floor levels for TRGP's non-fee margin** — only the aggregate ">90% fee-based" disclosure was available.
- **CoWoS-L equivalent capacity constraints for behind-the-meter generators** — turbine backlog quarters cited at 3–5 years for GE Vernova / Siemens but I couldn't tie this to specific Permian data center delivery dates.
- **2026 YTD total return** — derived from price/end-of-2025 close at ~+36%, but I did not pull an official total-return calculation including dividends.
- **TRGP's Mont Belvieu fractionation market share vs. EPD precisely.** Cited ranges (EPD ~30–35%, TRGP ~20–25%, ET ~15–20% of US Mont Belvieu capacity) are industry estimates, not company-disclosed.
- **Specific commodity hedge levels and fee floor strike prices** by year — disclosed only as a sensitivity (<2% EBITDA change on ±30% commodity moves). [17]

## Sources

[1] https://www.targaresources.com/operations/logistics-transportation-segment — retrieved 2026-05-10 — Targa segment description and Permian processing footprint
[2] https://eastdaley.com/the-burner-tip/daytona-400-targa-on-fast-track-for-ngl-market-share — retrieved 2026-05-10 — Grand Prix/Daytona NGL pipeline capacity and Mont Belvieu fractionation buildout
[3] https://www.targaresources.com/operations-logistics-transportation/lpg-exports-services — retrieved 2026-05-10 — Galena Park LPG export capacity ~14 MMBbl/month with expansion to 19 MMBbl/month
[4] https://news.oilandgaswatch.org/post/massive-gas-powered-data-center-in-permian-basin-is-latest-in-string-of-texas-ai-computing-hubs — retrieved 2026-05-10 — Pacifico GW Ranch 7.65 GW Permian data center project
[5] https://www.hartenergy.com/upstream/shale-plays/he-chevron-permian-data-centers-gas/ — retrieved 2026-05-10 — Chevron 2.5–5 GW Permian data center power plant FID targeted early 2026
[6] https://www.energytech.com/data-center-power/article/55361192/new-era-energy-secures-power-for-hyperscale-ai-facility-in-permian-basin — retrieved 2026-05-10 — New Era Energy 1 GW Permian AI campus with Oasis Pipeline 450k MMBtu/d supply
[7] https://markets.financialcontent.com/stocks/article/finterra-2026-2-19-targa-resources-corp-trgp-the-midstream-powerhouse-powering-the-ai-infrastructure-boom — retrieved 2026-05-10 — Retail-oriented "AI infrastructure powerhouse" framing of TRGP
[8] https://www.marketbeat.com/instant-alerts/targa-resources-nysetrgp-issues-earnings-results-2026-05-09/ — retrieved 2026-05-10 — TRGP price and recent trading range
[9] https://stockanalysis.com/stocks/trgp/statistics/ — retrieved 2026-05-10 — TRGP valuation statistics: market cap, EV, forward/trailing P/E, EV/EBITDA, short interest
[10] https://stockanalysis.com/stocks/trgp/forecast/ — retrieved 2026-05-10 — 52-week range and YTD return
[11] https://finance.yahoo.com/news/energy-transfer-vs-enterprise-products-193600663.html — retrieved 2026-05-10 — ET ~8.5×, EPD ~9.7× 2026E EV/EBITDA peer comps
[12] https://www.globenewswire.com/news-release/2026/05/07/3289714/14074/en/Targa-Resources-Corp-Reports-Record-First-Quarter-2026-Financial-Results-and-Increases-Financial-Outlook-for-2026.html — retrieved 2026-05-10 — Q1 2026 record EBITDA $1.4B; 2026 EBITDA guide raised to $5.7–5.9B; $948M Q1 capex; Stakeholder close
[13] https://stockanalysis.com/stocks/trgp/forecast/ — retrieved 2026-05-10 — Consensus PT $258 (range $212–$266), 13 analysts, Buy consensus
[14] https://www.targaresources.com/news-releases/news-release-details/targa-resources-corp-reports-record-third-quarter-2025-results — retrieved 2026-05-10 — 25% dividend hike for 2026
[15] https://pgjonline.com/news/2026/may/targa-expands-permian-gas-processing-delaware-express-pipeline-capacity — retrieved 2026-05-10 — Roadrunner III (265 MMcf/d) and Copperhead II (275 MMcf/d) plant announcements
[16] https://www.argusmedia.com/en/news-and-insights/latest-market-news/2802638-targa-lpg-export-terminal-declares-force-majeure — retrieved 2026-05-10 — Galena Park as ~20% of US LPG exports
[17] https://www.fool.com/earnings/call-transcripts/2026/02/19/targa-resources-q4-2025-earnings-call-transcript/ — retrieved 2026-05-10 — >90% fee-based; <2% EBITDA sensitivity to ±30% commodity moves
[18] https://pgjonline.com/news/2026/april/permian-constraints-keep-waha-gas-prices-negative-for-record-stretch-as-us-markets-weaken — retrieved 2026-05-10 — Waha negative basis stretch; Permian production 27.6 Bcf/d (2025) → 29 Bcf/d (2026E)
[19] https://www.eia.gov/todayinenergy/detail.php?id=63044 — retrieved 2026-05-10 — Matterhorn / Blackcomb / GCX expansion timelines (~4.5 Bcf/d new takeaway late 2026/2027)
[20] https://eastdaley.com/the-burner-tip/data-centers-could-add-6-bcf-d-to-gas-demand-eda-forecast — retrieved 2026-05-10 — East Daley: 6 Bcf/d data center demand by 2030; ET/KMI/TRP/WMB as primary midstream beneficiaries
[21] https://www.latitudemedia.com/news/nexteras-ai-bet-google-meta-and-more-gas/ — retrieved 2026-05-10 — Hyperscaler gas-fired power deals: Microsoft/Nscale, VoltaGrid/Oracle/ET, NextEra/GE Vernova
[22] https://www.fool.com/earnings/call-transcripts/2026/05/08/targa-trgp-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q1 2026 call: no AI/data center mention; LPG export "more inbounds than I've ever seen"; CFO on Permian takeaway relief in late 2026/2027
[23] https://www.tomshardware.com/tech-industry/big-tech/big-techs-ai-spending-plans-reach-725-billion — retrieved 2026-05-10 — Aggregate 2026 hyperscaler capex tracking $725B (+77% YoY)