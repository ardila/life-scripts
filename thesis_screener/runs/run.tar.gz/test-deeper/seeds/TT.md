# TT — Trane Technologies plc

## Where this sits in the AI stack
TT sells thermal management equipment at the **facility layer** of AI infrastructure: the chillers, cooling towers, coolant distribution units (CDUs), heat-rejection systems, and modular central utility plants that sit between the rack-level cold plates and the outdoor ambient. Inside an NVIDIA GB200/GB300 NVL72 deployment, NVIDIA and its server OEMs own the cold plate and manifold; TT owns the wet side from secondary-loop CDU through primary chilled-water plant to the dry coolers or evaporative towers on the roof. After acquiring LiquidStack (March 2026), TT now also reaches up to the rack with two-phase immersion and direct-to-chip CDUs[1][9][10]. The workload is overwhelmingly **frontier training at >100 kW/rack** — air-cooled inference racks barely move the needle for TT.

## Snapshot
- **Price:** $466.17 (2026-05-08 close; May 10 is a Sunday)[2]
- **Market cap:** $103.0B[2]
- **52-week range:** $348.06 – $503.47[2]
- **Forward P/E:** 31.4× (on FY26 guided EPS midpoint $14.85)[3][14]
- **EV / NTM revenue:** ~3.8× (EV ≈ $104B on consensus 2026 revenue ~$27.2B)[15] — inference; treat as approximate
- **Consensus 12-month price target:** $505.56 (implied +8.4%)[2]
- **YTD total return:** +22.97%[16]
- **Short interest (% of float):** 1.25% of outstanding[16]
- **Dividend yield:** 0.90% ($4.20 annualized)[14]

## Moat — what it is physically made of
TT's moat is **not** software. Decomposed:

1. **Installed-base service annuity.** Roughly half of HVAC industry economics come from after-market service, parts, and controls retrofits on equipment that runs 20–25 years. A gigawatt AI factory installed with Trane chillers in 2026 generates service revenue through 2046. This is the strongest piece of the moat and the one a sell-side analyst tends to under-weight because it doesn't show up in bookings prints. Durability: **high**, but only for equipment actually sold.

2. **Engineered systems integration, not products.** The NVIDIA Omniverse DSX Blueprint for Vera Rubin AI factories now ships with Trane reference designs at 250 MW, 1 GW air-cooled, and 1 GW liquid-cooled scale. The optimized 1 GW design freed 22 MW (~10%) of cooling capacity that the operator can redirect to IT load — at $25–40/MWh of value over 20 years this is a material TCO line[8][11]. The hard part isn't the chiller; it's matching primary loop ΔT, secondary loop flow rate (>700 L/min per NVL72 rack), and CDU staging across a 1 GW campus while hitting PUE <1.15 in 54 °C ambient. That integration sits in proprietary controls, CFD models, and applied engineering — replicable but slowly. Durability: **medium-high**, eroding as NVIDIA standardizes more of the design.

3. **Manufacturing footprint and lead time.** CDU and chiller lead times are 12–18 months[6]. TT has 20 of 21 U.S. plants on-shore and is expanding Jacksonville (Stellar) and Texas (LiquidStack)[10][13]. In a market where the binding constraint is *delivery date*, allocation IS the moat. Durability: **medium** — Vertiv, Schneider (post-Motivair) and Johnson Controls are all expanding capacity on the same 12–24 month timeline.

4. **Specific product capability.** TT's Sintesis eXcellent GVAF air-cooled chiller line now reaches 2.5 MW per unit with reliable operation to 54 °C ambient[1] — that operating-map width matters in Phoenix, Abilene, and the Gulf. The Stellar modular chiller plant is *prefabricated* — it ships as a skid, not as a coordination problem on the construction site, which compresses build schedule by 6–12 months in a market where time-to-power-on is the only thing hyperscalers care about[10][13]. Durability: **medium**; Vertiv and Johnson Controls have credible substitutes.

5. **LiquidStack two-phase immersion IP.** This is the speculative piece. Two-phase has theoretically superior heat-flux capability but has not yet won meaningful frontier deployment — single-phase direct-to-chip is the industry's actual standard for GB200/GB300. Trane bought a technology option, not a sure thing[9][12].

**What TT does NOT have:** the cold plate, the manifold, the server, the OEM relationship with Supermicro/Foxconn/Quanta, or NVIDIA's primary reference-design partnership for liquid cooling (that is co-owned by Vertiv on the IT-row side)[5][6]. TT is the *facility* partner, not the *rack* partner. This matters because as more of the cooling moves to factory-integrated rack systems, the value capture migrates from facility to rack.

## AI buildout bottleneck map
The actual 24-month gating constraints and TT's exposure to each:

| Bottleneck | Status | TT position |
|---|---|---|
| Power generation & grid interconnect | Most binding; U.S. AI DC demand 4 GW (2024) → 123 GW (2035e)[6]; gas turbine backlogs 4–5 yr | **Indirect beneficiary** — drives gas-turbine on-site generation, which Stellar's modular plant integrates with; absorption chillers can run off waste heat[6][13] |
| CoWoS-L advanced packaging | TSMC-bound, 2027 visibility | **Indifferent** |
| HBM3e/HBM4 yield | Binding through 2026 | **Indifferent** |
| Optical / co-packaged optics | Tight | **Indifferent** |
| Liquid cooling at >100 kW/rack | CDU lead times 12–18 mo[6]; CDU TAM $1.05B (2025) → $7.74B (2032), 33% CAGR[6] | **Direct beneficiary / supplier** — CDU 2.5–10 MW range now offered, plus LiquidStack[1][9] |
| Modular central plant capacity | Prefab compresses 6–12 mo build schedule | **Direct beneficiary** via Stellar; ~$1B backlog inherited[7][13] |
| Electrical contractor / mechanical contractor capacity | Severe in U.S. Sunbelt | **Indirect beneficiary** — TT's prefab skids reduce field labor |
| Kernel/compiler talent | Severe | **Indifferent** |
| Frontier training data | Tightening | **Indifferent** |

TT is a clean read on the **mechanical and modular-prefab** rung of the bottleneck ladder. It is not exposed to the silicon/packaging/HBM rung at all, which is also why it is not priced like a semiconductor name.

## Competitive teardown

**Vertiv (VRT) — the actual competitor that matters.** VRT is the pure-play and is co-developing reference architectures with NVIDIA for GB200 NVL72 at the rack/row level — closer to the chip than TT[5]. VRT held ~11.3% of the liquid-cooling market in 2025 (#1 share)[6]. VRT's CoolChip CDU line spans 70 kW–1.35 MW and is closer to the rack than TT's 2.5–10 MW facility CDUs[6]. **VRT has parity-or-better at the rack/row;** TT has parity-or-better at the facility/campus. The two are not yet a zero-sum fight, but they will overlap by 2027 as VRT builds out chilled-water plant capability (Strategic Thermal Labs acquisition, April 2026)[5] and TT pushes upstream into row CDUs via LiquidStack. Multiple comp: VRT 52–55× forward P/E vs. TT 31× — the market has already decided VRT is the deeper AI-pure-play[4][14].

**Schneider Electric** — acquired Motivair (Feb 2025), the historical OEM behind several hyperscaler CDU deployments[6]. The most credible threat on the row CDU vector; combines with Schneider's UPS/switchgear position to offer power+cooling integration that TT cannot.

**Johnson Controls** — invested in Accelsius (two-phase direct-to-chip, ex-Bell Labs)[6][12]. Direct technology overlap with TT's LiquidStack. JCI is weaker in applied chillers in the U.S. than TT and stronger in EMEA.

**Carrier, nVent, Modine, Stulz, Rittal, Boyd** — fragmented long tail. None has TT's applied-systems engineering depth, but they will absorb mid-density retrofits.

**Where competitors already have parity:** Vertiv at row CDU + NVIDIA partnership; Schneider at integrated power+cooling; Accelsius/ZutaCore at two-phase chip-level evaporation. TT does not own the rack.

## Bull case — technical
1. The bottleneck stays *mechanical*. Power, prefab modular plant, and high-ambient chillers remain the long-pole items in 2026–2028 build-outs in Texas, Arizona, Georgia, and the Middle East. TT's record $10.7B backlog (+30% Q/Q, +70% Y/Y), with Americas Applied bookings +160% three quarters running, is an early reading of this[7].
2. Hyperscalers continue to standardize on **facility-level vendor consolidation** (one mechanical EPC partner per campus). TT's reach from chiller through CDU through controls + the Stellar prefab skid gives it the broadest single-vendor offering at gigawatt scale. With 22 MW freed per 1 GW design[11], a hyperscaler buying TT recovers roughly $4–8M/yr in revenue per gigawatt vs. a competitor stack — small but real.
3. Service annuity compounds quietly. Every gigawatt installed in 2026–2028 is a 20-year service stream attaching at higher density and complexity than legacy commercial HVAC.
4. **Base rate:** large industrial equipment moats (Carrier, Trane, Otis, Schneider) typically erode over **15–25 years**, not 3–5. Building codes, mechanical contractor relationships, ASHRAE certification, and 25-year warranty obligations are *slow-moving*. The CPU→GPU shift took 10+ years; the on-prem→cloud shift took 15+; ICE→EV (still incomplete) has taken 15+. Compared to those, a 2026–2030 cooling architecture transition is *fast* by software standards but TT has more time than the multiple suggests.
5. Financial read: 31× forward P/E on 13–15% EPS growth and a quietly compounding 20-year service annuity is not expensive against VRT at 52–55× growing at a similar rate.

## Bear case — technical
1. **The cooling moves into the rack.** NVIDIA's logical next step after GB300 is to integrate rack-scale primary CDU, manifolds, and dielectric loops into the certified DGX SuperPOD product — sold by Foxconn/Supermicro/Quanta, not by mechanical contractors. The facility-side scope shrinks to "deliver 25 °C water to the rack" — a commodity. TT keeps the chiller plant but loses the high-margin row CDU economics it just paid up for at LiquidStack.
2. **Two-phase doesn't win.** LiquidStack's two-phase immersion has been pitched for a decade and is still <5% of liquid-cooling deployments. If single-phase direct-to-chip continues to handle GB300 and Rubin Ultra adequately, TT paid for an option that doesn't get exercised.
3. **Vertiv consolidates NVIDIA's reference position.** If the Vera Rubin DSX reference design (now in early 2026 cycles) ends up with Vertiv as the *named* CDU/row partner and TT as a generic alternate, TT loses Sun Belt hyperscaler wins on a 12–18 month lag.
4. **Hyperscaler capex normalizes.** If 2026 H2 hyperscaler capex guidance moderates >10% Q/Q, the +160% applied bookings rate is not repeatable. TT's record backlog implies it will under-book in 2027 even if revenue is fine — the stock reacts to bookings, not revenue.
5. **Residential HVAC drag.** Roughly a quarter of TT's revenue is U.S. residential HVAC, which had revenues down mid-single-digits in Q1 2026[7]. A consumer recession masks the data-center signal.
6. **Multiple compression on cyclicals.** TT is still classified Industrials, not AI infrastructure. A factor rotation out of AI capex names hits the *cyclical* part of TT's book before it shows in the AI part.

## Market view check
At $466 and 31× forward EPS on guided 13–15% EPS growth, TT is priced as a high-quality industrial cyclical with *some* AI optionality, not as an AI pure-play. The reference comp — VRT at 52–55× forward — is priced as the pure-play[4][14]. The gap (~70% multiple premium for VRT) is roughly the right size for "VRT has the rack and the NVIDIA badge; TT has the facility and the service annuity." My read is that the market is **roughly fairly pricing** TT: the AI tailwind is recognized, but the residential drag and the rack-vs-facility distinction are correctly discounted. There is no obvious gross mispricing; the alpha case is "the service annuity from 2026–2028 installed base will compound for 20 years and is not in the 2027 EPS number." That's a 3+ year thesis, not a 12-month one.

## 90-day falsifiers
- **Q2 2026 print (late July):** Americas Applied bookings growth rate. If it decelerates from +160% to <+60% Y/Y, the AI buildout signal in TT is weakening.
- **NVIDIA GTC fall 2026 / Vera Rubin DSX named partners:** if the named row-CDU partner is exclusively Vertiv (or includes Schneider/Motivair but not Trane/LiquidStack), the bear case #3 strengthens materially.
- **Stellar revenue conversion:** the $500M of Stellar 2026 revenue guidance should show up as a clean Americas Commercial HVAC tailwind by Q3 print. A miss signals integration friction or hyperscaler push-out.
- **Hyperscaler Q2 capex calls (late July/early August):** MSFT/META/GOOG/AMZN guidance. A sequential capex cut of >10% from any two of the four would compress the entire cooling cohort.
- **CoreWeave / OpenAI gigawatt RFPs:** publicly disclosed vendor lists for new sites in Texas/Louisiana. Watch whether Trane is named as mechanical EPC or only as chiller supplier.
- **LiquidStack two-phase customer announcement:** a named GB300/Rubin deployment using LiquidStack two-phase (not just direct-to-chip CDU) would materially de-risk the acquisition.

## What I could not verify
- Specific data-center % of TT total 2026 revenue. Management discloses "Applied HVAC" growth and Stellar revenue contribution (~$500M) but does not break out data-center end-market within Americas Commercial HVAC. My inference: data-center is likely $1.5–2.5B of FY26 revenue (mid- to high-single-digit % of total) but this is not directly sourced.
- Trane's CDU qualification status with NVIDIA at the rack/row level vs. Vertiv's named-partner status — both companies appear in DSX ecosystem materials, but the *exclusive* vs. *certified-alternate* designation per platform is opaque.
- The proportion of LiquidStack's revenue that is two-phase immersion vs. single-phase direct-to-chip CDU — material to whether TT bought a real product line or an option.
- Patent strength of LiquidStack's two-phase IP vs. Accelsius (Bell Labs heritage) and ZutaCore — I could not find a clean comparative claim chart.
- Exact backlog conversion timing into revenue: the $10.7B backlog likely averages 12–24 months to revenue but the data-center portion may convert faster (modular skids) or slower (gigawatt campus phasing).
- TT's exposure to single-customer concentration risk in the data-center book (e.g., what % of Stellar's $1B backlog is one or two hyperscalers).
- Independent third-party verification of the "10% efficiency / 22 MW freed" claim from the optimized 1 GW reference design — the figure comes from Trane/NVIDIA joint press materials, not independent MLPerf-style benchmarks (and no such benchmark exists for facility thermal).

## Sources
[1] https://www.datacenterfrontier.com/cooling/article/55298248/tranes-thermal-management-overhaul-modular-cooling-platforms-for-ai-driven-data-center-demands — retrieved 2026-05-10 — Trane modular CDU 2.5–10 MW platform, GVAF chiller 2.5 MW / 54 °C ambient.
[2] https://www.marketbeat.com/stocks/NYSE/TT/forecast/ — retrieved 2026-05-10 — TT price $466.17, mkt cap $103.0B, 52w $348.06–$503.47, PT $505.56.
[3] https://www.gurufocus.com/term/forward-pe-ratio/TT — retrieved 2026-05-10 — TT forward P/E 31.58×.
[4] https://www.gurufocus.com/term/forward-pe-ratio/VRT — retrieved 2026-05-10 — VRT forward P/E 52.64× / mkt cap $130.6B for comp.
[5] https://www.vertiv.com/en-emea/about/news-and-events/news-releases/2026/vertiv-strengthens-liquid-cooling-system-capability-with-acquisition-of-strategic-thermal-labs/ — retrieved 2026-05-10 — Vertiv acquires Strategic Thermal Labs; NVIDIA GB200 NVL72 reference architecture.
[6] https://www.delloro.com/market-at-the-boiling-point-is-the-cdu-space-becoming-saturated/ — retrieved 2026-05-10 — CDU lead times 12–18 mo, market $1.05B→$7.74B 33% CAGR, Vertiv ~11.3% share.
[7] https://www.fool.com/earnings/call-transcripts/2026/04/30/trane-tt-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q1'26 backlog $10.7B (+30% YE), bookings +24%, Applied bookings +160%, FY26 EPS $14.75–14.95.
[8] https://blogs.nvidia.com/blog/omniverse-dsx-blueprint/ — retrieved 2026-05-10 — Omniverse DSX Blueprint, CFD, GB200/GB300 NVL72 configurations.
[9] https://investors.tranetechnologies.com/news-and-events/news-releases/news-release-details/2026/Trane-Technologies-Completes-Acquisition-of-LiquidStack/default.aspx — retrieved 2026-05-10 — LiquidStack acquisition closed March 2026; two-phase immersion + direct-to-chip + CDU.
[10] https://investors.tranetechnologies.com/news-and-events/news-releases/news-release-details/2026/Trane-Technologies-Completes-Acquisition-of-Stellar-Energy/default.aspx — retrieved 2026-05-10 — Stellar Energy acquisition closed Feb 2026; modular chiller plants; ~700 employees Jacksonville.
[11] https://investors.tranetechnologies.com/news-and-events/news-releases/news-release-details/2025/Trane-Technologies-Unveils-Industrys-First-Comprehensive-Thermal-Management-System-Reference-Design-for-Gigawatt-Scale-NVIDIA-AI-Factories/default.aspx — retrieved 2026-05-10 — 1 GW reference design; 10% efficiency improvement frees 22 MW.
[12] https://accelsius.com/next-generation-of-cooling_two-phase-direct-to-chip/ — retrieved 2026-05-10 — Two-phase competitor landscape (Accelsius/Bell Labs, ZutaCore, LiquidStack).
[13] https://www.datacenterdynamics.com/en/news/trane-acquires-liquid-cooling-solutions-provider-stellar-energy-digital/ — retrieved 2026-05-10 — Stellar liquid-to-chip modular plant scope; ~$1B backlog inherited.
[14] https://stockanalysis.com/stocks/tt/dividend/ — retrieved 2026-05-10 — TT dividend $4.20 annualized, yield 0.90–0.98%.
[15] https://seekingalpha.com/news/4544428-trane-technologies-outlines-6-7-percent-organic-revenue-growth-and-14_65-14_85-eps-guidance — retrieved 2026-05-10 — FY26 revenue ~$27.2B, organic growth 6–7%.
[16] https://www.marketbeat.com/stocks/NYSE/TT/short-interest/ — retrieved 2026-05-10 — Short interest 1.25% of outstanding; YTD return +22.97%.
[17] https://introl.com/blog/gb200-nvl72-deployment-72-gpu-liquid-cooled — retrieved 2026-05-10 — GB200 NVL72 120–130 kW/rack, >700 L/min coolant, 1200 W cold plate, 30–45 °C inlet.