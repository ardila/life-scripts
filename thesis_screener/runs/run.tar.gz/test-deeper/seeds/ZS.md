I have enough to write. Drafting the dossier now — being honest upfront that ZS (Zscaler) is not in the AI compute/training stack the prompt's framing assumes, then doing the deep technical work on its actual stack and exposure.

# ZS — Zscaler, Inc.

## Where this sits in the AI stack
Zscaler is **not** in the AI infrastructure stack the prompt's framing implies. It sells no silicon, no packaging, no HBM, no optics, no power equipment, no training runtime. It operates a global SaaS security cloud — the "Zero Trust Exchange" — which is a multi-tenant inline proxy that terminates TLS, inspects every byte, and re-originates traffic between users/branches/workloads and the internet/SaaS/private apps. Workload-wise it is **real-time, latency-sensitive, request-response** processing at ~500T daily signals, not batch compute [11]. The AI-relevant surfaces are three: (i) **enterprise AI/ML traffic** flowing through ZIA (989B transactions / +91% YoY in CY25) [4][11], (ii) **AI-driven attack surface** (autonomous reconnaissance, agentic lateral movement) which lifts demand for inline inspection [4], and (iii) **agentic SOC** as a new product surface (Red Canary acquisition, OpenAI TAC program access to GPT-5.4-Cyber) [4][8]. So this is a security-SaaS dossier with AI as a *workload riding on top*, not an AI-compute dossier.

## Snapshot
- **Price:** $151.97 (2026-05-09 close) [1]
- **Market cap:** ~$24.5B; EV ~$24.5B (cash ~$3.0B offsets ~$1.1B converts and op-lease) [1][13]
- **52-week range:** $128.00 – $336.99 [1][9]
- **Forward P/E:** ~37.9× on FY26 midpoint EPS guide $4.01 [3][6]
- **EV / NTM revenue:** ~6.8× (EV $24.5B / FY27 cons. ~$3.6B, FY26 guide $3.32B → 7.4×) [13][3]
- **Consensus 12-month price target:** $233.70 (mean, 46 analysts; range $165–$335 — implies +54%) [9]; Citizens cut $290→$210 (May 1); JPM cut $200→$155 (Apr 21) [10]
- **YTD total return:** Approximately −25% to −30% (inferred — stock sits ~55% below 52-week high of $337 and PT cuts cluster in late April/early May 2026; I could not source a clean YTD figure) [1][10]
- **Short interest (% of float):** 24.1% reported short-sale ratio (Apr 7, 2026) — this is days-to-cover-ish in some feeds; actual short interest as % of float is likely lower (mid-single-digits) but elevated vs. peers; **unverified at the % of float level** [9]

## Moat — what it is physically made of
Decomposing the "Zscaler moat" into actual components and rating each for durability:

**1. The proxy data plane (medium durability).** Zscaler's ZIA Service Edge is a **single-pass, single-scan multi-action** proxy: TLS is terminated once at the nearest PoP, plaintext bytes are streamed through an in-process pipeline (URL filter → IPS → AV/sandbox → DLP → CASB → browser isolation hand-off) and re-originated on the egress side without re-encrypt/re-decrypt hops between functions [11][14]. The architectural lock-in is real — chaining service VMs (the Cisco/PANW first-gen approach) adds latency per hop — but **the techniques (kernel-bypass networking, in-process service chains, eBPF/DPDK-class data planes) are well understood and replicable**. Cloudflare, Netskope and PANW Prisma Access have all converged on similar designs. Patent moat is narrow: e.g., US10284526B2 "Efficient SSL/TLS proxy" covers specific handshake-interception optimizations, not the category [16]. Person-years to replicate at parity for a serious adversary: ~300–500 engineer-years of focused effort, which Microsoft and Cloudflare are clearly putting in.

**2. PoP footprint and peering posture (medium-low durability).** 150+ DCs deployed in **transit-provider colos** (Equinix-class peering exchanges) — Zscaler's deliberate choice was to live at IX/peering rather than in compute regions, which historically gave better internet egress paths [3][14]. Cloudflare counters with 270–330+ city anycast presence anchored on their own AS [5]. Cloudflare's claim of 38–55% faster Zero Trust experience is self-reported and biased but architecturally plausible at the edge tail [5]. **This was a strong moat in 2018–2022; it is being commoditized in 2024–2026 as Cloudflare, Akamai-class operators, and hyperscalers (Microsoft Front Door / Entra GSA edge) get within a few ms.**

**3. SSL inspection at scale (low standalone durability, high integration durability).** Decrypting 100% of traffic inline at line rate is the table-stakes capability; the operational hardness is in **certificate trust chain management, HTTP/2 and QUIC handling, and TLS 1.3 ESNI/ECH workarounds**, plus per-tenant policy isolation. Competitors can do it; what's hard to replicate is the customer-side **policy ladder** (years of granular URL/app/user policies, IdP federations, GRE/IPsec tunnel deployments, ZCC agent rollouts on 100k+ endpoints).

**4. Data exhaust + Avalor + Red Canary (currently the most defensible piece).** ~500T daily signals into a custom security data fabric (Avalor, acquired 2024) [11], now combined with Red Canary's MDR runbooks ($675M close Aug 2025) to build a "unified agentic SOC" [7]. This is the closest thing Zscaler has to a true ML data moat: telemetry breadth across 9,000 customers and 989B AI/ML transactions in CY25 [4]. **But Cloudflare sees comparable or larger raw traffic volume**, and Microsoft sees richer identity telemetry via Entra/Defender. The moat is real but not unique.

**5. Customer integration depth (high durability, the actual stickiness).** This is the unsexy answer. The switching cost is not CUDA-class. It is: ZCC agents on every endpoint, GRE/IPsec tunnels from every branch, ZIA/ZPA policy ladders that took 2–3 years to tune, IdP/SCIM integrations, log streaming to Splunk/Sentinel, SOC runbooks built around Zscaler alerts. Migration to a competitor is a 12–24 month enterprise IT project with material risk of misconfigured policy gaps. **This is closer to an ERP-style moat than a CUDA-style moat** — high but erodes once a customer is already running a parallel competitor (Microsoft Entra GSA bundled in E5 [6], for instance).

Net: the moat is **integration depth + data exhaust**, not architecture. Brand and scale matter. The "single-pass proxy" pitch is mostly a 2018-era differentiator that's largely been matched.

## AI buildout bottleneck map
ZS sits **off** the physical AI buildout (no GPU/HBM/CoWoS/power exposure). Mapping the real constraints and ZS's relationship:

| Constraint | ZS exposure |
|---|---|
| CoWoS-L allocation, HBM3e/HBM4 supply | Indifferent — no silicon |
| Power generation, grid interconnect, gas turbines (multi-yr backlog) | Indifferent direct; **mildly negative** indirect (its own ~150 DCs need power; SLA-grade colos see rising costs) |
| Optical interconnect (200G/400G/800G, CPO) | Indifferent — its WAN runs over public internet + private backbones it leases |
| Liquid cooling >100kW/rack | Indifferent — proxy workloads are CPU-bound, not GPU-bound |
| Kernel/CUDA talent | Indifferent (uses Python/C++/Go server engineers, not CUDA) |
| Training-data quality at the frontier | Indifferent for products; **positive** as customer demand: enterprises need DLP on AI-bound traffic |
| Inline inference latency at enterprise scale (the SOC AI workload) | **Beneficiary** — Zscaler can route GenAI traffic, apply DLP, and now ship "Zscaler AI" inspection products [4] |
| Enterprise AI adoption broadly | **Beneficiary** — 91% YoY growth in AI/ML transactions through ZIA is a direct usage signal; gives Zscaler a SKU to attach (AI Asset Mgmt, Secure Access to AI, AI Infra/Apps protection) [4][8] |
| Agentic AI as new attack/identity surface (MCP, A2A, autonomous agents) | **Beneficiary if positioning lands** — Red Canary + OpenAI TAC partnership are bets that inline + telemetry is the right place to do agent identity/policy enforcement [4][8][7] |

The honest summary: ZS is a **second-order beneficiary** of AI capex. It gets none of the dollars going into Blackwell/Rubin/MI400, but it gets a usage tailwind every time an enterprise pipes traffic to OpenAI/Anthropic/Gemini through its cloud. Quantitatively, AI/ML traffic is ~989B of ~180T+ annual transactions (rough estimate from 500T daily signals) — call it ~0.5–1% of traffic by count, but it carries disproportionate data risk and policy complexity, which is what drives ARPU.

## Competitive teardown
Not "they compete" — *on which axis, with what evidence, on what timeline*.

**Cloudflare (NET) — most architecturally credible threat.** Cloudflare One unifies CDN/WAF/Zero Trust on a single anycast runtime (Workers). Three concrete axes: (a) **edge tail latency** — Cloudflare's 270–330+ city presence vs. Zscaler's ~55 enforcement cities (Cloudflare's count of Zscaler) [5] genuinely matters for first-byte; (b) **unified plane** — Cloudflare runs every service on every server, vs. Zscaler's ~8 sub-clouds with separate consoles [5]; (c) **cost-to-deliver** — Cloudflare's CDN-rooted infra is amortized across many products and ships at lower COGS. Where Cloudflare lags: depth of inline security features (DLP maturity, sandbox quality, SSL decryption posture, CASB SaaS coverage), enterprise sales motion, and SOC integrations. **Required-to-be-true for share take**: enterprise security depth has to catch up by 2027 and Cloudflare has to win the IR/SOC story it doesn't have today. Reasonable but not done.

**Palo Alto Networks (PANW) — Prisma Access.** Strongest in customers that already run PA firewalls and want a one-vendor SASE play. Gartner moved PANW from #2 to #3 on execution in the 2025 SSE MQ; Zscaler took #1 on execution, #2 on vision [2]. PANW is muscular in NGFW/SD-WAN bundle deals, and "platformization" pricing is real. **Required-to-be-true**: enterprises must consolidate on PANW for cost reasons faster than Zscaler can defend with platform pricing of its own.

**Microsoft Entra Global Secure Access — the structural threat.** Entra Internet Access + Private Access are bundled (or near-bundled, depending on SKU) into Microsoft 365 E5 [6]. The economics for a CISO running an all-Microsoft shop are brutal: "free-ish" SSE inside an existing seat license vs. a $5–$15/user/month Zscaler addition. Microsoft's product is technically thinner today (web filtering quality, sandbox depth, third-party SaaS coverage) [6] but the cost-bundle gravity is enormous. **Required-to-be-true for share take**: Microsoft needs to reach feature parity on inline DLP, CASB, and decryption depth — probably 18–36 months. **The base rate on Microsoft chipping at a category from inside the E5 bundle is bad for the incumbent** (Slack, Zoom, Okta, Snowflake have all felt versions of this). This is the bear case in one bullet.

**Cisco, Fortinet, Netskope, Check Point.** Cisco (#2 in Dell'Oro SASE Q3'25, <1 pt behind Zscaler [12]) plays mostly into existing Cisco-networking accounts via Umbrella + Secure Access. Fortinet runs strong in SMB/mid-market via FortiSASE. Netskope leads Gartner on vision and has had real federal wins. Check Point Harmony is a distant fourth in mindshare. None is a primary catalyst for ZS rerating in the next 12 months.

**Pure-AI-security entrants (Prompt Security, Lakera, Protect AI, etc.).** Too narrow to displace a horizontal SSE; more likely M&A targets than competitors. ZS's bet is to absorb this layer organically + via Red Canary [7].

## Bull case — technical
For ZS to outperform from $152, what has to be technically true:

1. **Single-pass inline proxy remains the right architectural locus for AI traffic governance.** Specifically: inline DLP on prompts/responses, AI app discovery via TLS-fingerprinted unsanctioned-tool detection, MCP/agent identity enforced at the proxy. If yes, ZS's installed inspection plane gets monetized by 2–3 new SKUs (AI Asset Mgmt, Secure Access to AI, Secure AI Infra/Apps) [8].
2. **Red Canary integration produces a credible agentic-SOC product within 2 quarters** — combined telemetry breadth (Zscaler) + analyst runbooks (Red Canary) + frontier model access (OpenAI TAC, GPT-5.4-Cyber) [7][4]. This is the Avalor data-fabric thesis cashing in.
3. **Microsoft's Entra GSA fails to reach feature parity on inline depth before 2027**, giving ZS another 18 months of pure-play premium pricing in security-led accounts.
4. **Enterprise AI traffic continues +50–100% YoY**, mechanically raising the per-user inspection workload and policy complexity — both ARPU drivers.

**Financial knock-on:** if ARR growth holds 22–25% through FY27 (vs. 24% FY26 guide [3]) and FCF margin steps to 28–30% from the current ~27% [13], the stock at 8× EV/sales and 30× P/E is worth $240–290 — i.e., roughly the consensus target [9].

**Base-rate caveat:** in security platform shifts, the incumbent with deep customer integration usually keeps 60–80% of installed base over a 3–5 year displacement attempt (PANW vs. Check Point, CrowdStrike vs. Symantec endpoint). But "keeping installed base" is not the same as "growing 25%." The base rate on **growth durability for a $3B+ SaaS** is unkind: median deceleration of ~300–500 bps/year past $3B ARR.

## Bear case — technical
The short-seller-who-knows-the-stack version:

1. **Microsoft GSA bundles into E5 and the marginal SSE seat goes to zero.** This is the structural threat. The technical objection — "Microsoft can't do inline TLS at the depth Zscaler does" — is real today but expires on a 12–24 month clock. Once Microsoft is "good enough" on web filtering + DLP + private access for the median enterprise, ZS retention holds but **net-new logos and seat expansion compress**. This shows up first in **NRR decline below 115%** and **net new ARR per quarter flattening**.
2. **The proxy architecture is itself the wrong locus for the agentic era.** If agents authenticate as identities (OAuth, mTLS, SPIFFE/SPIRE) and traffic gets authorized at the API/data layer rather than the network layer, Zscaler's inline plane becomes a tax, not a control point. Identity-first stacks (Microsoft Entra, Okta, Auth0) sit where the policy actually lives. **The control plane is shifting upward; Zscaler sits at L4–L7 network.**
3. **Cloudflare's unified runtime advantage compounds.** Cloudflare ships features faster because they ship them across every PoP at once on a single substrate [5]. Zscaler has accumulated ~8 sub-clouds via acquisition (Avalor, ShiftRight, Airgap, Smokescreen, Red Canary…) which the company itself frames as "platform unification" — i.e., the work is not done.
4. **Sales-led growth model is structurally expensive.** S&M as % of revenue remains elevated; FCF margin gains have come from CapEx leverage, not opex leverage. Rule-of-X today is healthy but the path to 30%+ FCF margin with 20%+ growth is not obvious if Microsoft compresses pricing.
5. **24% short interest** (or whatever the true float-adjusted figure is — see above) [9] is information: sophisticated money is positioned for the bear case.

**Financial knock-on:** if FY27 growth decelerates to 15–17% (Microsoft pricing pressure + saturation) and FCF margin stalls at 27%, fair value compresses to 5–6× EV/sales = $115–135.

**Base rate on Microsoft taking share in an enterprise SaaS category once bundled in E5:** roughly 200–400 bps of incremental share per year, sustained, until the incumbent is < 1.5× the price premium it once commanded. Slack, Zoom, Okta, and (more recently) Crowdstrike for SMB have all lived through some version of this. The incumbents survive; the multiples don't.

## Market view check
At $152 / ~38× forward EPS / ~7× EV/NTM-sales, ZS trades at a **deep historical discount to itself** (5-yr P/FCF median 118× per Gurufocus; now 24× [13]) and at parity-to-slightly-cheap vs. PANW and CRWD on growth-adjusted metrics. The market is pricing **growth-to-mid-teens by FY28 plus Microsoft margin pressure**. That is consistent with the bear case but probably too harsh given (a) ARR guide was *raised* to 24% in Q2 FY26 [3], (b) FCF generation is real (>26% margin guide [3]), (c) net new ARR ex-Red Canary still grew 21% [3]. **Plausible mispricing direction: long, with the catch that the catalyst is Microsoft Build / Q3 FY26 print, both inside the next 30 days.** If those events confirm the bear narrative (Microsoft ships GSA improvements, ZS guides Q4 growth <20%), the multiple compresses further — there is no obvious floor below 5× EV/sales (~$110).

## 90-day falsifiers
Specific, datable events:

1. **Q3 FY26 print, May 26, 2026** [10]. Watch: (a) ARR growth ex-Red Canary < 20% (bear-confirming); (b) net new ARR < $130M; (c) NRR disclosure — anything below 114% is a material negative; (d) FY26 ARR guide trajectory (if midpoint trims, the thesis breaks). Currently guided to $3.73–3.745B = 24% growth [3].
2. **Microsoft Build 2026 (mid-May 2026).** Any GSA feature announcement that closes the inline-DLP / CASB / sandbox gap is a direct bear-confirming signal. Watch the Entra/Defender sessions specifically.
3. **Cloudflare Q1 2026 earnings (typically early May 2026).** Zero Trust ARR disclosure, customer count, and any specific named ZS displacement. The Cloudflare "Zero Trust ACV >$1M customer" count crossing some threshold is a tell.
4. **PANW fiscal Q3'26 (May 2026)** Prisma Access NGS commentary. Platformization deal disclosures featuring SSE replacement.
5. **Federal-sector RFP outcomes** — any DoD or large agency SSE consolidation award in the next 90 days is a bellwether.
6. **AI-agent identity standards activity (MCP, A2A, OpenID for Agents).** If a standards body lands on identity-layer (not network-layer) enforcement, that's structurally negative for inline proxies.

## What I could not verify
- Exact YTD 2026 total return — I have the close ($152) and the 52-week range ($128–$337) but no clean YTD baseline from a primary source.
- True short interest as % of float vs. the 24.1% "short-sale ratio" figure surfaced in screening tools — the metric is ambiguously labeled.
- FY27 consensus revenue (used 20%-ish deceleration to estimate ~$3.6B for EV/NTM math) — should be checked against IBES.
- Whether Zscaler's data plane uses DPDK/eBPF/proprietary kernel-bypass — strongly implied by line-rate TLS claims and patent filings but I did not find a clean public confirmation.
- Specific FY26 net-cash position (assumed ~$3B from prior disclosures, not re-sourced).
- Whether Red Canary's "10× faster, 99.6% accuracy" runbook claims survive in a Zscaler-integrated product or were pre-acquisition marketing.
- Microsoft's actual install base for Entra Internet Access / Private Access — Microsoft has not disclosed paying customer counts at sufficient granularity to size the cannibalization risk.

## Sources
[1] https://www.cnn.com/markets/stocks/ZS — retrieved 2026-05-10 — ZS close $151.97 on 2026-05-09; intraday range $145.11–$152.20.
[2] https://www.sdxcentral.com/news/netskope-palo-alto-networks-zscaler-continue-gartners-sse-domination/ — retrieved 2026-05-10 — Gartner 2025 SSE MQ: Zscaler #1 execution, #2 vision; Netskope #1 vision; PANW slipped to #3 execution.
[3] https://ir.zscaler.com/news-releases/news-release-details/zscaler-announces-strong-second-quarter-fiscal-2026-results — retrieved 2026-05-10 — Q2 FY26: revenue $815.8M (+26% YoY), ARR $3.36B (+25%, +21% ex-Red Canary), FY26 ARR guide raised to $3.73–3.745B (+24%), revenue guide $3.309–3.322B, EPS guide $3.99–4.02, FCF margin guide ~26.5–27%.
[4] https://www.zscaler.com/press/zscaler-2026-ai-threat-report-91-year-over-year-surge-ai-activity-creates-growing-oversight — retrieved 2026-05-10 — 989.3B AI/ML transactions across ZTE in CY25 from ~9,000 orgs; +91% YoY AI/ML activity; +93% YoY data-to-AI volume; agentic-attack framing.
[5] https://blog.cloudflare.com/cloudflare-one-vs-zscaler-zero-trust-exchange/ — retrieved 2026-05-10 — Cloudflare claims 270+ cities vs. Zscaler's 55, unified runtime vs. 8 sub-clouds, 38–55% Zero Trust performance edge.
[6] https://learn.microsoft.com/en-us/entra/global-secure-access/how-to-zscaler-coexistence — retrieved 2026-05-10 — Microsoft Entra Internet Access + Private Access bundled in M365 E5; coexistence patterns documented.
[7] https://ir.zscaler.com/news-releases/news-release-details/zscaler-accelerate-innovation-ai-powered-security-operations — retrieved 2026-05-10 — Red Canary MDR acquisition, $675M, closed Aug 2025; agentic SOC strategy combining Avalor data fabric + Red Canary runbooks.
[8] https://www.zscaler.com/press/zscaler-unveils-new-innovations-secure-enterprise-ai-adoption — retrieved 2026-05-10 — AI Asset Mgmt, Secure Access to AI, Secure AI Infra/Apps product set; OpenAI TAC + GPT-5.4-Cyber.
[9] https://www.tipranks.com/stocks/zs/forecast — retrieved 2026-05-10 — 52-week range $128.00–$336.99; 46-analyst mean PT $233.70 (range $165–$335); 24.1% short-sale ratio (Apr 7, 2026).
[10] https://finance.yahoo.com/markets/stocks/articles/citizens-lowers-price-target-zscaler-121136356.html — retrieved 2026-05-10 — Citizens cut PT $290→$210 on May 1, 2026; JPM cut $200→$155 on April 21, 2026; both cite AI-driven cybersecurity re-rating + competition; Q3 FY26 print scheduled May 26, 2026.
[11] https://www.zscaler.com/resources/reference-architectures/traffic-forwarding-in-zscaler-internet-access.pdf — retrieved 2026-05-10 — 150+ DC enforcement footprint; single-pass proxy; transit-provider colo siting; ~500T daily signals figure surfaced in derivative Zscaler materials.
[12] https://www.delloro.com/news/sase-is-putting-the-nail-in-the-coffin-for-access-routers-as-market-drops-25-percent-in-3q2025/ — retrieved 2026-05-10 — Dell'Oro 3Q25: top 3 SASE = Zscaler #1, Cisco #2 (<1pt gap), PANW #3; SSE +20% YoY ≈ 1/3 of SASE revenue.
[13] https://www.gurufocus.com/term/price-to-free-cash-flow/ZS — retrieved 2026-05-10 — ZS P/FCF 24.23 (Apr 27, 2026), 80% below 10-yr median 118.48; FCF $413.3M / 52% margin in Q1 FY26.
[14] https://www.zscaler.com/products-and-solutions/ssl-inspection — retrieved 2026-05-10 — Single-scan multi-action inline architecture; line-rate TLS termination claim; AI-powered inline controls.
[15] https://www.fool.com/earnings/call-transcripts/2025/11/25/zscaler-zs-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q1 FY26 transcript: revenue $788M +26%, ARR $3.2B +26%, FCF 52% margin, "Zero Trust Everywhere"/AI Security ARR targets hit 3 quarters early, agentic ITOps customer wins (Fortune 500 financials, healthcare equipment, energy), ZDX Copilot +80% YoY bookings.
[16] https://patents.google.com/patent/US10284526B2/en — retrieved 2026-05-10 — Zscaler patent on efficient SSL/TLS proxy handshake interception — illustrative of narrow, technique-level (not category-level) IP moat.