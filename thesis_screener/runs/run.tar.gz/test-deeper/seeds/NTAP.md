I have enough material to write the dossier now.

# NTAP — NetApp, Inc.

## Where this sits in the AI stack
NetApp sells the **enterprise data-storage layer** — specifically all-flash NAS arrays (AFF, A90, AFX) running its proprietary ONTAP software, plus first-party "ONTAP-as-a-service" inside AWS (FSx for NetApp ONTAP), Azure (Azure NetApp Files), and Google Cloud (Google Cloud NetApp Volumes) [1][2]. Its AI exposure is almost entirely **enterprise AI** — data preparation, fine-tuning, RAG, and inference on regulated corporate data sitting in existing NetApp footprints — not the **frontier training tier** (xAI Colossus, OpenAI, Anthropic, Meta Llama clusters), where the storage layer is consistently won by VAST, DDN, and WEKA over parallel filesystems or DASE-style architectures rather than ONTAP-derived NAS [3][4].

## Snapshot
- **Price:** $118.00 (2026-05-08 close) [5]
- **Market cap:** $23.3B [6]
- **52-week range:** $92.91 – $126.66 (low 2025-05-09, high 2025-09-19) [5]
- **Forward P/E:** ~14.8× on FY26E non-GAAP EPS midpoint $7.97 (guide $7.92–$8.02); ~11.7× on NTM/CY27E [6][7]
- **EV / NTM revenue:** ~2.7–2.85× (EV ~$19.1B, TTM rev $6.70B; FY26 guide $6.77–$6.92B) [6][7]
- **Consensus 12-month price target:** $117–119 (~0% to +1% upside); rating Hold [8][9]
- **YTD 2026 total return:** ≈ flat (was −9.5% in mid-March, +0.7% by April 20) [10]
- **Short interest (% of float):** ~6.2% (Sep-2025 last verified) — below storage-peer average of ~9.4% [11]

## Moat — what it is physically made of
The honest decomposition:

**1. ONTAP software (durable, decaying).** Three-decade-old C/C++ codebase implementing WAFL on-disk format, snapshots, FlexVol/FlexClone (zero-copy clones), SnapMirror/SnapVault replication, SnapLock WORM compliance, multi-tenant SVMs, unified NAS+SAN+S3, inline dedupe/compression, encryption at rest [12][13]. Replicating ONTAP feature-parity is a **5–10 year engineering effort** at hundreds of FTEs — but VAST, Pure, and Dell aren't trying to replicate ONTAP feature-by-feature; they're competing by reframing what enterprise storage *is*. The moat is durable for incumbent renewals, leaky for greenfield AI workloads.

**2. First-party hyperscaler services (genuinely scarce).** NetApp is the **only** independent storage vendor with co-engineered, console-native services in all three hyperscalers — sold by AWS, Microsoft, and Google as their own SKUs [14]. This is the result of multi-year contracts that competitors cannot shortcut. Public Cloud revenue $174M in Q3 FY26 (up 27% YoY ex-Spot) at **85.1% gross margin** — an order of magnitude higher than blended product GM [15][16]. This is the most under-appreciated piece of the moat.

**3. Installed-base lock-in (real but bounded).** Exabytes of regulated enterprise data already on ONTAP, often with active SnapMirror DR pairs [13]. Migration cost is not the storage cost — it is rewriting backup, DR runbooks, security-tool integrations, and ServiceNow workflows. Switching pain compounds with regulatory archival commitments (SnapLock).

**4. AFX disaggregated architecture (new, unproven).** Launched October 2025: AFX 1K controllers (PCIe Gen5, 11 expansion slots) decoupled from NX224 NVMe enclosures over a switched fabric, scaling to 128 nodes / 1 EB effective capacity, certified for DGX SuperPOD with GB300 [17][18]. **Skeptic's note:** independent technical analysis points out the "1 EB effective" claim presumes ~13:1 reduction ratios that AI training data does not achieve (~1.2–1.5:1 realistic), and the embedded L4 GPUs in optional DX50 compute nodes couple inference and storage scaling rather than truly disaggregating them — a different architectural philosophy than VAST's stateless CNode / stateful DBox split [19].

**5. AI Data Engine (marketing, not yet moat).** Built-in metadata-driven ETL, vector embeddings, governance, lineage [17]. Competes against specialized stacks (Pinecone, Snowflake, Databricks, MongoDB Atlas) that are far ahead on ML-feature parity. AIDE GA in Q4 FY26 — too early to score [20].

**Notable absences from the moat:** NetApp did **not** submit to MLPerf Storage v1.0 (Sept 2024) or v2.0 (July 2025); WEKA, DDN, HPE, Hammerspace, Huawei, Micron all did [21]. For a company telling an AI story, refusing to put its silicon under the industry-standard storage-for-AI benchmark is a tell.

## AI buildout bottleneck map
Mapped to the actual physical/skill bottlenecks gating the next 24 months of AI infrastructure:

| Bottleneck | NetApp position |
|---|---|
| **TSMC CoWoS-L allocation** | Indifferent — NetApp doesn't ship advanced-packaged silicon |
| **HBM3e/HBM4 supply** (≈30% of hyperscaler capex 2026 per SemiAnalysis) [22] | Indifferent |
| **Power generation / grid interconnect** (US shortfall 11→40 GW by 2028 per Goldman) [23] | Indifferent |
| **Liquid cooling at >100kW/rack** | Indifferent |
| **NAND supply / pricing** | **Exposed** — NetApp pays NAND spot/contract; rising NAND lifts BOM but management's stated strategy is to absorb via Keystone STaaS subscription pricing (+65–76% YoY growth) which converts NAND volatility into customer-borne TCO [20][24] |
| **Optical interconnect** (800G ZR) | Marginal — relevant only for AFX scale-out fabric |
| **Kernel/compiler/AI-systems talent** | Indifferent (storage isn't the bottleneck); but NetApp must hire ML-systems engineers to build AIDE, where it's a price-taker against frontier labs |
| **Enterprise AI data prep / governance** | **Beneficiary** — this is the one bottleneck NetApp directly owns. ~75% of enterprise AI projects stall on data quality / governance / lineage; ONTAP+AIDE attacks this |
| **Frontier training storage feed-rate** | Mostly **bypassed** — VAST/DDN/WEKA win these deals; NetApp gets ~0% of CoreWeave/xAI/Lambda-class spend [3][4] |

Net read: NetApp is downstream of AI capex via NAND, indifferent to the bottlenecks the market mostly cares about, and only directly positioned on the "boring" enterprise data-prep bottleneck.

## Competitive teardown

**VAST Data (private, last $30B valuation, $1B raise March 2026)** [25]: DASE architecture with CUDA-accelerated stateless CNodes over NVMe-oF to dense SCM/QLC enclosures — purpose-built for linear GPU feed at hundreds of GB/s. Won the **xAI Colossus** (200K+ GPU) data platform [26] and signed a **$1.17B CoreWeave** commercial agreement Nov 2025 [27]. NetApp does not realistically compete here on the technical axis; AFX is closer architecturally than AFF was, but the engineering decade gap on disaggregation favors VAST. **What would need to happen for NetApp to take share:** VAST's NVIDIA preferred-partner status erodes (currently NVIDIA equity participant), or VAST stumbles operationally in second-tier neoclouds. Neither is in evidence.

**Pure Storage / Everpure (PSTG)** [28][29]: Won a **top-four hyperscaler licensing deal** (almost certainly Meta) for Purity OS + DirectFlash Module IP, with double-digit-EB deployments in CY26 and revenue starting FY27 [30]. Trades at **5.5× EV/Sales / 26.8× forward P/E vs NetApp 2.85× / 14.8×** — the multiple gap encodes the hyperscaler-licensing optionality NetApp lacks. Pure also leads in DirectFlash (no FTL on commodity SSDs — Pure builds the flash module to its own controller). **What NetApp would need:** an analogous hyperscaler design win, which has not surfaced in three years of trying.

**Dell PowerScale (OneFS)** [31]: PowerScale F710 was the **first Ethernet storage certified for DGX SuperPOD** — beat NetApp to that flag. Dell holds **#1 external enterprise storage share at 23.7% in Q4 CY25 vs NetApp 8.1%** [32]. PowerScale is a credible direct competitor in the same enterprise-AI customer set.

**WEKA / DDN / Hammerspace / IBM Storage Scale**: Frontier-AI focused, software-defined or HPC-heritage parallel filesystems. All submit MLPerf Storage. Dominate neocloud and national-lab deals. Not direct competitors for NetApp's enterprise NAS bread-and-butter, but they cap NetApp's frontier-AI TAM at near zero.

**Hyperscaler-native object (S3, ABS, GCS)**: For warm/cold data NetApp loses on $/GB. The first-party services (FSxN/ANF/GCNV) are NetApp's defensive answer — expensive but feature-parity for compliance-bound workloads.

## Bull case — technical
**Premise to be true:** Enterprise AI spend (RAG over corporate data, regulated-industry fine-tuning, agentic workflows over private knowledge graphs) ends up **larger than frontier training spend** within 36 months, because frontier training collapses to ~5 model labs while enterprise AI deploys to ~50,000 buyers. In that world the moat that matters is **(installed enterprise data) × (compliance/governance) × (hyperscaler-native delivery)** — exactly NetApp's stack.

**Required technical conditions:**
1. AFX qualifies into 5+ named neocloud/Tier-2 cloud customers within 12 months (vs current "early wins" framing) [20].
2. AIDE delivers measurable RAG-pipeline TCO advantage over assemble-it-yourself stacks (Snowflake + Pinecone + Airflow + custom embeddings).
3. NAND price cycle remains elevated long enough to push enterprises into Keystone subscription rather than capex purchase, locking in 80%+ GM recurring revenue [20].
4. Hyperscaler first-party services keep compounding at 25%+ — implying Microsoft/AWS/Google have no plan to displace ONTAP with a homegrown enterprise NAS (they don't, today).

**Base rate caution:** Enterprise software moats decay slowly. EMC dominated storage for two decades after the technology around it changed completely; the install-base inertia is real. But a flat-to-growing legacy moat with a credible AI growth lever has historically re-rated only **after** a quarter of clear AI-revenue acceleration (cf. ORCL Sep 2025 OCI inflection). Until then NetApp trades as 12× value.

**Financial outcome:** Re-rate from ~12× to 16–18× forward P/E + 8–10% revenue growth = $135–155 stock in 12–18 months. ~15–30% upside.

## Bear case — technical
**Premise:** Enterprise AI is a smaller, slower, less profitable adjacency than the bulls argue. Frontier capex dominates, and NetApp gets none of it. Within enterprise, Dell PowerScale (incumbent broader server bundle), Pure (Meta-validated, hyperscaler-licensing model), and VAST (downmarket from frontier) compete for the same dollar.

**Required technical conditions:**
1. **AFX adoption stays single-digit-quarterly** — Kurian himself "not predicting a ramp like C-Series" on Q3 call [33]. Translation: not confident.
2. **MLPerf gap persists.** Until NetApp posts numbers, sophisticated buyers default to VAST/WEKA/DDN/Hammerspace which do.
3. **Pure's hyperscaler deal scales to a second hyperscaler.** That validates a fundamentally different commercial model (license IP, not sell boxes) that NetApp has not pursued.
4. **NAND up-cycle compresses product GM** before Keystone mix can cushion it; FY27 GM guide disappoints.
5. **Hyperscaler first-party service growth decelerates** as AWS/Azure/GCP consider building their own enterprise NAS (Azure has been quietly hardening Azure Files Premium; AWS keeps adding to FSx for OpenZFS / Lustre).

**JPMorgan downgrade in March 2026** to Neutral, citing slowing AFA share gains and unclear AI product timing, encodes this view from the sell-side [10].

**Base rate:** NAS-incumbent platform shifts (NetApp → cloud-native object in mid-2010s) destroyed roughly half of NetApp's market value before stabilizing. The same pattern at the AI-platform shift — frontier and neocloud go elsewhere, enterprise modernizes slowly to cloud-native object + vector DBs — implies a 15–30% downside from here over 24 months.

## Market view check
At $118, $23B market cap, ~12× forward / 2.85× EV/Sales, with a consensus PT of $117 and a Hold rating, the market is pricing NetApp as **a profitable, slowly-growing storage incumbent with a credible-but-unproven AI optionality**. That's actually a fair reading of the technical reality I've described. The mispricing case requires you to disagree with the market on **one specific thing**: whether Q4 FY26 and Q1 FY27 prints will inflect the AI-customer count (200 → 300 → ?) and AFX shipments (early → ramping) sharply enough to force a re-rate. The bear thesis requires you to believe the market is **already too generous** given that the stock has been flat YTD while the AI-infra cohort (NVDA, AVGO, VRT, ANET, PSTG) has compounded — i.e., the market is already saying "we don't believe NetApp is in the AI trade."

## 90-day falsifiers
1. **Q4 FY26 earnings — May 28, 2026** [34]. Watch: revenue vs $1.85B guide midpoint; AI-customer count (>500 = bull confirmation, <400 = bear); AFX named-customer disclosures; FY27 EPS guide vs ~$8.50 consensus; Public Cloud GM holding 80%+; Keystone unbilled RPO sequential.
2. **MLPerf Storage v3.0 results (expected July/August 2026)**. NetApp submission with AFX numbers competitive vs WEKA/VAST/DDN = bull. Continued absence = bear continues.
3. **Pure Storage Q1 FY27 print (May/June 2026)**. Meta DirectFlash deployment update — if Pure raises FY27 hyperscaler revenue guide, validates licensing-IP model as the new winning shape; NetApp's lack of a similar deal becomes more glaring.
4. **Hyperscaler capex updates from MSFT/META/GOOGL/AMZN at Q2 CY26 prints (late July 2026).** A >10% sequential cut to AI infra capex compresses NetApp's hyperscaler first-party tailwind by ~12 months.
5. **Dell ISG Q1 FY27 (late May 2026)** — PowerScale acceleration would confirm Dell is taking share Dell+NetApp combined ought to be holding.
6. **NAND contract pricing trajectory (TrendForce / DRAMeXchange monthly)** — a sharp roll-over would compress Keystone unit economics before subscription mix shift completes.
7. **Any disclosed NetApp design win in a frontier neocloud (CoreWeave, Lambda, Crusoe, Nscale)**. Has not happened; would be regime-changing.

## What I could not verify
- Exact AFX revenue contribution in Q3 FY26 (NetApp does not break it out — only "ahead of expectations" qualitative).
- The precise YTD 2026 total return — search returned conflicting figures ($60 close 2025 = clearly wrong; the −9.5% YTD March / +0.7% YTD April figures suggest a CY25 close near $117, which would put YTD 2026 ~+1%).
- The FY27 consensus EPS that the cited "11.7× forward P/E" is computed against; the math implies ~$10.05 which would be 26% YoY EPS growth — high vs typical NetApp guide cadence.
- Specific revenue-share splits between NetApp and Microsoft/AWS/Google on first-party services.
- Whether Pure's hyperscaler deal is in fact Meta (heavily-implied, not confirmed by either party).
- NetApp's installed-base in EB (commonly cited as ~130 EB in past investor decks; could not pull a current figure).
- The actual AFX MLPerf-equivalent throughput per node — NetApp publishes "171 GiB/s GPUDirect" for prior-gen ONTAP A800 against DGX A100 [35], but no head-to-head AFX number against current VAST/WEKA published submissions.
- George Kurian's exact verbatim Q3 call language on AFX ramp — only second-hand summaries available; primary-source PDF could not be parsed.

## Sources
[1] https://www.netapp.com/afx/ — retrieved 2026-05-10 — NetApp's official AFX product page describing disaggregated architecture for enterprise AI.
[2] https://www.netapp.com/cloud-services/what-is-cloud-volumes-ontap/ — 2026-05-10 — Confirms NetApp first-party services across AWS/Azure/GCP.
[3] https://blocksandfiles.com/2025/11/06/vasts-1-17-billion-coreweave-deal/ — 2026-05-10 — VAST $1.17B CoreWeave deal documenting frontier neocloud share NetApp doesn't have.
[4] https://blog.farmgpu.com/storage-for-neocloud-fms2025/ — 2026-05-10 — Survey of neocloud storage stack: VAST/WEKA/DDN dominate; NetApp not listed.
[5] https://stockscan.io/stocks/NTAP/price-history — 2026-05-10 — NTAP price/range data for May 2026.
[6] https://stockanalysis.com/stocks/ntap/statistics/ — 2026-05-10 — Market cap, EV, multiples.
[7] https://www.netapp.com/newsroom/press-releases/news-rel-20260226-results-618838/ — 2026-05-10 — Q3 FY26 earnings press release with FY26 guide.
[8] https://www.tipranks.com/stocks/ntap/forecast — 2026-05-10 — Analyst PT consensus.
[9] https://www.marketbeat.com/stocks/NASDAQ/NTAP/forecast/ — 2026-05-10 — Hold rating, target distribution.
[10] https://markets.financialcontent.com/stocks/article/barchart-2026-3-13-is-netapp-stock-underperforming-the-nasdaq — 2026-05-10 — JPMorgan downgrade context, YTD performance.
[11] https://fintel.io/ss/us/ntap — 2026-05-10 — Short interest data.
[12] https://en.wikipedia.org/wiki/Write_Anywhere_File_Layout — 2026-05-10 — WAFL technical overview.
[13] https://docs.netapp.com/us-en/ontap/data-protection/snapmirror-svm-replication-concept.html — 2026-05-10 — SnapMirror replication architecture (lock-in mechanism).
[14] https://itwire.com/business-it-news/data/netapp-built-first-party-storage-inside-every-major-cloud-the-ai-payoff-is-starting-to-land.html — 2026-05-10 — Confirms NetApp uniqueness as only vendor with first-party in all three hyperscalers.
[15] https://futurumgroup.com/insights/netapp-q3-fy-2026-results-highlight-all-flash-growth-and-cloud-services/ — 2026-05-10 — Q3 FY26 numerical detail including 85.1% public cloud GM.
[16] https://www.investing.com/news/transcripts/earnings-call-transcript-netapp-beats-q3-2026-forecasts-stock-rises-postearnings-93CH-4530275 — 2026-05-10 — Q3 FY26 earnings transcript including hyperscaler revenue commentary.
[17] https://www.netapp.com/newsroom/press-releases/news-rel-20251014-129058/ — 2026-05-10 — AFX launch press release (Oct 2025).
[18] https://docs.netapp.com/us-en/ontap-afx/get-started/ontap-afx-storage.html — 2026-05-10 — AFX 1K hardware specs (PCIe Gen5, 11 slots, 128-node scale).
[19] https://storagemath.com/posts/netapp-disaggregated-ontap-ai-analysis/ — 2026-05-10 — Independent technical critique of AFX dedup-ratio claims and disaggregation completeness.
[20] https://finance.yahoo.com/news/netapp-inc-ntap-q3-2026-050723487.html — 2026-05-10 — Q3 FY26 call highlights: 300 AI customers, AFX commentary, Keystone +65% YoY.
[21] https://mlcommons.org/2024/09/mlperf-storage-v1-0-benchmark-results/ — 2026-05-10 — MLPerf Storage v1.0 results with NetApp absent from submitter list.
[22] https://www.tomshardware.com/tech-industry/memory-will-consume-30-percent-of-hyperscaler-spending-this-year — 2026-05-10 — SemiAnalysis: memory ~30% of 2026 hyperscaler capex.
[23] https://alcapitaladvisory.com/research/intelligence/ai-infrastructure.html — 2026-05-10 — Hyperscaler capex 2026 ~$725B; Goldman power-shortfall framing.
[24] https://www.themarketsdaily.com/2026/03/01/netapp-q3-earnings-call-highlights.html — 2026-05-10 — Q4 FY26 EPS/revenue guide.
[25] https://thenextweb.com/news/vast-data-1b-raise-30b-valuation-nvidia-ai-storage — 2026-05-10 — VAST $1B raise at $30B valuation, March 2026.
[26] https://www.vastdata.com/blog/building-ai-factories-a-blueprint-for-next-gen-gpu-clouds-with-vast-data — 2026-05-10 — VAST as data platform behind xAI Colossus 200K-GPU cluster.
[27] https://blocksandfiles.com/2025/11/06/vasts-1-17-billion-coreweave-deal/ — 2026-05-10 — $1.17B VAST/CoreWeave commercial agreement.
[28] https://stockanalysis.com/stocks/pstg/statistics/ — 2026-05-10 — PSTG valuation comparables.
[29] https://blog.purestorage.com/news-events/hyperscaler-chooses-pure-to-replace-storage/ — 2026-05-10 — Pure's hyperscaler-design-win announcement.
[30] https://www.blocksandfiles.com/ai-ml/2025/04/07/pure-storage-scores-flashy-meta-deal/1595548 — 2026-05-10 — Meta deal coverage with deployment scale and timing.
[31] https://www.dell.com/en-au/blog/powerscale-worlds-first-ethernet-storage-certified-on-nvidia-superpod/ — 2026-05-10 — Dell PowerScale F710 first-Ethernet DGX SuperPOD certification.
[32] https://blocksandfiles.com/2025/12/12/idc-storage-tracker-shows-pure-and-huawei-growing-fastest/ — 2026-05-10 — IDC Q4 CY25 external enterprise storage shares (Dell 23.7% / NetApp 8.1%).
[33] https://finance.yahoo.com/news/5-insightful-analyst-questions-netapp-053145091.html — 2026-05-10 — Q3 FY26 analyst Q&A: AFX "not predicting a ramp like C-Series."
[34] https://www.businesswire.com/news/home/20260506239543/en/NetApp-Hosts-Fourth-Quarter-and-Fiscal-Year-2026-Financial-Results-Webcast — 2026-05-10 — Q4 FY26 earnings date confirmed May 28, 2026.
[35] https://www.netapp.com/blog/ontap-reaches-171-gpudirect-storage/ — 2026-05-10 — ONTAP A800 + DGX A100 GPUDirect Storage 171 GiB/s benchmark.