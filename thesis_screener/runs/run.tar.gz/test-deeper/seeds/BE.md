# BE — Bloom Energy Corporation

## Where this sits in the AI stack
Bloom sits at the **on-site primary power layer** of the AI buildout — behind the customer's meter, between the natural-gas pipeline and the data-center busway. It is not silicon, packaging, fabric, or compiler. It manufactures and services modular ~325 kW solid-oxide fuel cell (SOFC) "Energy Server" units that consume pipeline natural gas (or biogas/H₂) and produce 480V AC electricity electrochemically — i.e., without combustion or rotating machinery [1][2]. The relevant workload is **24×7 baseload primary power for AI training and inference clusters that cannot wait the 5–12 years for a transmission interconnect** [3][4]. It is not a backup-genset business and it is not a renewable-PPA business.

## Snapshot
- **Price:** $264.22 (2026-05-10 close) [5]
- **Market cap:** ~$74.2B [5]
- **52-week range:** $17.01 – $302.99 [6]
- **Forward P/E:** ~129× (on FY26 non-GAAP EPS midpoint $2.05) [7][8]
- **EV / NTM revenue:** ~14× (NTM revenue ~$5.0–5.5B implied off FY26 guide $3.4–3.8B at the run rate exiting Q4) [7][9]
- **Consensus 12-month price target:** ~$210 (range $55–$335; PTs broadly lag the April spot rally) [6][10]
- **YTD total return:** +228.6% [6]
- **Short interest (% of float):** 8.15% (~23.2M shares) [10]

## Moat — what it is physically made of
The moat is real but narrower and shorter-dated than the price implies. Decompose it:

**Materials science (durable, ~5–10 yr lead).** Bloom's electrolyte is a scandia-ceria stabilized zirconia (ScSZ/SCSZ) rather than the textbook YSZ, which lifts ionic conductivity at lower operating temperature and slows the YSZ-cathode interfacial degradation pathway (La₂Zr₂O₇ secondary phase formation; Ni-coarsening at the anode) that has historically capped SOFC fleet life [11][12]. Reported field degradation is ~0.2% per 1,000 hours [2] — i.e., ~1.5–2% per year — which is what makes 5+ year service contracts at ~60% LHV electrical efficiency commercially honest. SOFC chemistry itself is public; the moat is in dopant recipe, sintering profiles, seal materials, and stack-assembly yield, all of which require multi-year fleet feedback to optimize. Doosan/Ceres only began mass SOFC production in July 2025 and booked their first commercial 9 MW order in December 2025 — this is the lead [13].

**Manufacturing (durable, ~3–5 yr lead).** A single Fremont, CA facility scales from 1 GW (today) → 2 GW (Dec 2026, ~$100M capex) and is engineered to expand to 5 GW [14]. This is not a fab; it is a stack-assembly / cell-print operation, but Bloom is vertically integrated from cell to system to install to service. A new entrant cannot copy this in <3 years even with capital, because stack yield is empirically learned (the Li-ion-cell analogue: yield curves take a fleet to mature).

**Deployment-clock moat (durable while grid is broken).** ~90-day lead time from contract to power-on [15]. This is the competitively decisive number, not efficiency or LCOE. Against grid interconnect at 5 yr median / 12 yr for data centers [3], or gas turbines sold out through 2030 with 7–8 yr backlogs [16][17], 90 days commands an extraordinary time-premium — and customers are paying it. This moat is durable only as long as grid + turbine queues don't clear.

**Customer-platform stickiness (medium).** Bloom signs 10–20 yr Operations & Maintenance contracts that capture ~30% of stack-replacement spend over the system's life. The Oracle MSA (2.8 GW potential, 1.2 GW initial = $3.5–4.0B revenue, plus a 3.53M-share warrant struck at $113.28) [18][19] and Brookfield's $5B AI-infrastructure SPV [20] build platform commitments rather than spot purchases.

**What is NOT moat.** Patents on SOFC chemistry are narrow — most filings around oxygen-ion electrolytes and metal interconnects have published prior art going back to Westinghouse work in the 1990s. There is no "CUDA"-equivalent here. The brand isn't moat. Hydrogen-readiness is forward-looking, not yet commercial. **The moat is materials/manufacturing know-how plus a 90-day clock — not a regulatory monopoly or a network effect.**

## AI buildout bottleneck map
Constraint-by-constraint placement:

| Constraint | BE position |
|---|---|
| **Grid interconnect (5–12 yr queues, 2,600 GW backlog, 14% historical completion)** [3][21] | **Direct beneficiary** — its core wedge |
| **Gas turbine supply (GEV 100 GW backlog, 7–8 yr lead, sold out through 2030)** [16][17] | **Direct beneficiary** at sub-100 MW; complementary at >200 MW |
| **Natural-gas pipeline lateral capacity** | Exposed customer — sites without pipeline access cannot host SOFCs |
| **CoWoS-L / HBM3e** | Indifferent |
| **>100 kW/rack liquid cooling** | Indifferent |
| **Power electronics (transformers, switchgear)** | Exposed (shared with all data-center power) |
| **Skilled electrical contractors** | Exposed (shared with all on-site power) |
| **Section 48E ITC (30%, fixed for fuel cells from 1/1/26)** [22] | **Direct beneficiary** — improves customer IRR at unchanged ASP |
| **SMR nuclear (NuScale, Oklo, Kairos, X-energy: first units 2028–2030+)** [23] | **Long-dated displacement risk** |

The honest framing: BE arbitrages two slow physical queues (transmission and gas-turbine OEM capacity) by selling a faster physical alternative. When either queue clears, the time-premium compresses.

## Competitive teardown
Competitors fall on different technical axes — none yet has parity on the combination of efficiency × scale × deployment time.

- **Gas turbines (GE Vernova, Siemens Energy, Mitsubishi).** Higher ASP-per-kW economics at ≥200 MW, ~60% efficiency (combined cycle), and well-understood. The competitive answer is *time*: Vernova's 100 GW backlog implies 7–8 yr deliveries [16][17]. Until that compresses (and Vernova/Siemens are jointly investing ~$1.6B in U.S. capacity [16]), Bloom owns the sub-200 MW behind-the-meter slot. **Watch:** Vernova quarterly delivery-slot guidance.
- **FuelCell Energy (FCEL).** Molten-carbonate (MCFC) chemistry, ~47% electrical efficiency, just productized 12.5 MW power blocks and signed 450 MW with SDCL [24]. MCFC operates at 650°C (vs. SOFC ~800°C) but degrades faster on cathode dissolution; FCEL is a real competitor on installed track record but not on efficiency or scale. Doesn't dent Bloom's hyperscaler funnel today.
- **Doosan / HyAxiom (licensed Ceres SOFC).** First mass-production July 2025, first commercial order 9 MW December 2025 [13]. ~3 years behind Bloom on cumulative fleet hours. Real threat in 2028–2030 if Korean manufacturing scales faster than Bloom's Fremont expansion.
- **Ceres Power (UK).** Licensing-only model, partnered with Doosan and Centrica. No own manufacturing — they sell the IP and collect royalties. Not a direct hyperscaler competitor in 2026; potentially a kingmaker if multiple licensees scale.
- **SMR nuclear (Oklo, NuScale, Kairos, X-energy).** First commercial-data-center power from 2028–2030 at the earliest [23]. The structural threat: hyperscalers want carbon-free baseload, and SOFC-on-gas isn't that. **Watch:** Oklo Aurora INL operation (late 2027/early 2028); Kairos-Google milestone slips.
- **Reciprocating engines (Caterpillar, Cummins).** Backup-class only; not duty-cycle competitive.

The honest read: on **24×7 primary power, sub-200 MW, deployable in <12 months, in jurisdictions with gas pipeline access**, Bloom has effectively a single-vendor market through 2027. Outside that envelope (large-scale baseload, carbon-free mandate, no pipeline), it does not.

## Bull case — technical
For BE to outperform, four technical things must remain roughly true through 2027:

1. **Grid + turbine queues do not clear.** Vernova 7-yr backlog holds; FERC/RTO interconnect reform doesn't materially compress queues; Texas/Virginia/Ohio hosting doesn't open up new transmission. Base rate: U.S. interconnection queue length has *increased* every year 2018–2025 [21], so the prior is queues stay long.
2. **Hyperscaler $-per-month-of-time-saved stays elevated.** A 100 MW H100/B200 cluster lost for 12 months is roughly $1.5–2B of foregone revenue at hyperscaler economics. As long as that math holds, the Bloom premium over CCGT (currently ~40% LCOE at $4/MMBtu gas [4]) is paid willingly.
3. **2 GW Fremont reaches design rate in H2 2026 with stack yields holding.** This is execution risk — it has not yet been demonstrated. Successful execution converts the $20B backlog at 34%+ gross margin and inflects FCF.
4. **Section 48E 30% ITC survives** (low risk; fuel cells have bipartisan support and the rule was intentionally fixed for fuel-cell property in the 2025 amendments) [22].

**Base rate on technology displacement:** in past platform shifts (gas-turbine peaker → reciprocating engine; steam → CCGT), the dominant incumbent retained share for 8–12 years after a credible challenger emerged, because installed-base service economics outweigh new-build efficiency for fleet operators. SOFC vs. CCGT shows similar inertia — Bloom is on the *winning* side of this curve at the sub-200 MW node.

Financial outcome if all four hold: $20B backlog + Brookfield/Oracle option-style upside delivers 2027 revenue ~$5.5–6.5B at ~36% gross margin, $1B+ non-GAAP OI. Stock is then on ~50× forward earnings — still rich but defensible if growth durates.

## Bear case — technical
The short-seller-who-actually-reads-MLSys version:

1. **Gas-turbine queues clear faster than priced in.** Vernova and Siemens have committed ~$1.6B and announced new U.S. lines [16]; if 2027 delivery slots open up, the time-premium that justifies SOFC's LCOE penalty evaporates. Hyperscalers shift to ~$700–900/kW CCGT economics from BE's effective ~$3,000–4,000/kW installed (production-cost basis, not ASP) [25].
2. **SOFC fleet degradation surprises to the downside at scale.** The 0.2%/1,000 hr figure is from a relatively young fleet at ~1 GW deployed [2]. Stress tests on cathode/electrolyte interfaces and Cr-poisoning of LSCF cathodes from metal interconnects historically accelerate non-linearly above 40,000 hours of cumulative runtime [12]. If a hyperscaler-deployed fleet shows higher real-world degradation in 2027, the LTV math on O&M contracts (the recurring-revenue thesis) breaks.
3. **Customer concentration is severe.** Oracle (1.2 GW initial), AEP (up to 1 GW), Brookfield ($5B SPV) and Equinix dominate the named backlog. A single customer pause for any reason — Oracle capex retrenchment, AEP regulatory pushback, Brookfield financing markets — is a 30%+ revenue hit with no offsetting demand.
4. **Methane scope-3 regulation.** California, EU, and prospective federal rules on methane leakage along the gas value chain raise the carbon-equivalent footprint of SOFC-on-pipeline-gas materially. If hyperscalers' carbon-neutral commitments harden into supplier mandates (and they have been), SOFC-on-gas becomes a transitional asset with a 5-yr depreciation profile rather than a 20-yr one.
5. **SMR alpha-customer ships in 2028.** Oklo at INL, Kairos at Google's site, or X-energy at Amazon's site — any of these going hot in late 2027/2028 reframes the conversation about 2030+ baseload and re-rates BE's terminal value.
6. **Ceres/Doosan or a Chinese SOFC entrant reaches 55%+ efficiency at 30% lower system cost.** SOFC chemistry is not unique IP. If Doosan's mass production achieves cost-parity at adequate efficiency by 2027, BE's pricing power compresses fast.
7. **Scaling 1→2→5 GW introduces yield issues.** Every cell-stack manufacturer (Li-ion, fuel cell, electrolyzer) has hit yield-cliff issues during 3×+ scale jumps. Bloom has not yet demonstrated this jump.

## Market view check
At ~$264, market cap ~$74B, EV/NTM revenue ~14×, forward P/E ~129×. The stock has tripled YTD on Q1 results, the Brookfield SPV, and the Oracle MSA expansion. Sell-side PTs (~$210 average) materially lag spot — this is consensus catching up to news, not consensus disagreeing. **The price implies the market believes the AI power bottleneck holds for 3–5 more years and BE owns the sub-200 MW node within it**, with backlog converting at the new ~34% GM trajectory. That is a coherent technical view, not a bubble. **What the market is *not* pricing**, in my read: (a) the ~6–8 quarter risk window between now and proven 2 GW Fremont yield, (b) SMR optionality re-rating in 2028, (c) customer-concentration single-point failure on Oracle. These are middle-of-the-thesis risks, not tail risks. Reasonable longs trim into strength; thesis remains intact unless a Q3-Q4 falsifier fires.

## 90-day falsifiers
- **Q2 2026 print (early August):** Backlog ≥ $20B (need to see *added* GW, not just sticky), gross margin tracking ≥33%, manufacturing capacity utilization, stack-replacement run rate (a leading indicator of fleet degradation surprises).
- **Hyperscaler Q2 capex commentary (MSFT/META/GOOG/AMZN):** Sequential capex guidance — a >10% cut to FY26 capex from any two of the four invalidates the demand backdrop.
- **Vernova/Siemens delivery-slot guidance update:** Any pull-in of 2027–2028 delivery slots compresses BE's time-premium.
- **New named hyperscaler contract:** Microsoft, Meta, Google, or AWS at GW-scale would re-rate; absence after 90 days post-Oracle is a soft tell.
- **Brookfield first European site announcement:** The companies guided "before end of year" [20]; pushing past Q3 is a yellow flag.
- **Section 48E final regulations / domestic content guidance:** Any narrowing of the safe harbor compresses customer IRR and pricing power.
- **Oklo / Kairos / X-energy regulatory milestone:** NRC license issuance for any SMR shifts terminal-value framing.
- **Field reliability incident at Oracle Project Jupiter or AEP initial 100 MW deployment** — any reported derate or outage is asymmetric to the downside.

## What I could not verify
- Real production cost per kW at the 2 GW run-rate (cited $2,500–4,000 range is 2017–2023 disclosure [25]; current figure not separately published).
- Field-fleet degradation distribution beyond the 0.2%/1,000 hr headline (no published bathtub curve for systems past 60,000 hours).
- Exact gas-supply readiness at Project Jupiter (Doña Ana County, NM) — pipeline lateral capacity is the unstated constraint.
- Patent strength relative to Doosan/Ceres on metal interconnect coatings and seal chemistry — the public filings don't fully separate the two.
- Whether the Oracle warrant strike at $113.28 implies the parties expected the stock to trade at this level by mid-2026, or simply reflects the deal-date spot — i.e., whether Oracle's economic incentive to scale beyond 1.2 GW remains aligned at $264.
- True customer concentration in % of backlog (the $20B figure is disclosed in aggregate, not by named counterparty).
- Whether BE's "5 GW expandable" figure is a footprint claim or a capex-funded commitment (likely the former).

## Sources
[1] https://www.bloomenergy.com/technology/ — retrieved 2026-05-10 — Bloom's official description of the SOFC stack architecture, ScSZ electrolyte, and 325 kW system block.
[2] https://www.bloomenergy.com/blog/everything-you-need-to-know-about-solid-oxide-fuel-cells/ — retrieved 2026-05-10 — Bloom-disclosed degradation rate (~0.2%/1,000 hr), 60%+ electrical efficiency, 90%+ CHP efficiency.
[3] https://emp.lbl.gov/queues — retrieved 2026-05-10 — LBNL "Queued Up" data on U.S. interconnection queue (2,600 GW backlog; 5-year median wait; 14% completion rate).
[4] https://thundersaidenergy.com/downloads/bloom-energy-solid-oxide-fuel-cell-technology/ — retrieved 2026-05-10 — Independent technical review of Bloom SOFC LCOE vs. gas turbines at varying gas prices ($4 vs. $13/MMBtu).
[5] https://finance.yahoo.com/quote/BE/ — retrieved 2026-05-10 — Bloom Energy stock price and market cap data.
[6] https://stockanalysis.com/stocks/be/ — retrieved 2026-05-10 — 52-week range ($17.01–$302.99) and YTD return (+228.6%).
[7] https://investor.bloomenergy.com/press-releases/press-release-details/2026/Bloom-Energy-Reports-Record-First-Quarter-2026-Results-and-Raises-Full-Year-2026-Guidance/default.aspx — retrieved 2026-05-10 — Q1 2026 release: $751M revenue, raised FY26 guide to $3.4–3.8B revenue, ~34% non-GAAP GM, $1.85–2.25 EPS.
[8] https://stockanalysis.com/stocks/be/statistics/ — retrieved 2026-05-10 — Forward P/E and valuation statistics.
[9] https://www.fool.com/earnings/call-transcripts/2026/04/28/bloom-energy-be-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1 2026 earnings transcript: $20B backlog, manufacturing trajectory, capacity commentary.
[10] https://www.marketbeat.com/stocks/NYSE/BE/forecast/ — retrieved 2026-05-10 — Analyst price targets, short-interest data.
[11] https://en.wikipedia.org/wiki/Solid_oxide_fuel_cell — retrieved 2026-05-10 — SOFC chemistry overview, YSZ vs ScSZ conductivity comparison.
[12] https://chemistry-europe.onlinelibrary.wiley.com/doi/10.1002/elsa.202100024 — retrieved 2026-05-10 — McPhail et al. (2022): planar SOFC degradation mechanisms (La₂Zr₂O₇ formation, Cr poisoning, Ni coarsening).
[13] https://enkiai.com/fuel-cell/fuelcell-energy-grid-support-data/ — retrieved 2026-05-10 — Doosan/HyAxiom mass production July 2025; first commercial 9 MW December 2025.
[14] https://www.utilitydive.com/news/bloom-energy-says-its-on-track-for-2-gw-annual-production-capacity/804291/ — retrieved 2026-05-10 — Fremont 1 GW → 2 GW Dec 2026 ($100M); 5 GW expandable.
[15] https://www.bloomenergy.com/industries/data-center-power/ — retrieved 2026-05-10 — 90-day deployment claim; Bloom data-center segment positioning.
[16] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — GE Vernova 80 GW backlog (year-end 2025), expected 100 GW (Q1 2026), sold out through 2030.
[17] https://rbnenergy.com/daily-posts/blog/backlog-natural-gas-turbines-expands-surging-demand-supply-constraints — retrieved 2026-05-10 — Cross-OEM (Siemens, GEV, MHI) 7–8 year delivery backlogs.
[18] https://investor.bloomenergy.com/press-releases/press-release-details/2026/Bloom-Energy-and-Oracle-Expand-Strategic-Partnership-to-Deploy-up-to-2-8-GW-to-Accelerate-AI-Infrastructure-Build-Out/default.aspx — retrieved 2026-05-10 — Oracle MSA: 2.8 GW potential, 1.2 GW initial, $3.5–4.0B initial revenue.
[19] https://www.cnbc.com/2026/04/13/oracle-expands-bloom-energy-deal-days-after-400-million-stock-warrant.html — retrieved 2026-05-10 — Oracle warrant: 3.53M shares at $113.28 strike ($400M).
[20] https://investor.bloomenergy.com/press-releases/press-release-details/2025/Brookfield-and-Bloom-Energy-Announce-5-Billion-Strategic-AI-Infrastructure-Partnership/default.aspx — retrieved 2026-05-10 — Brookfield $5B AI Infrastructure SPV, European site flagged for 2026.
[21] https://rmi.org/interconnection-reform-ai-data-centers-generator-queues/ — retrieved 2026-05-10 — RMI on interconnection queue trends; data-center–specific delays up to 12 years.
[22] https://www.whitecase.com/insight-alert/amendments-to-ira-tax-credits-congressional-budget-bill-july-6 — retrieved 2026-05-10 — Section 48E fixed 30% credit for fuel-cell property post-12/31/2025.
[23] https://www.datacenterfrontier.com/energy/article/55306971/oklo-accelerates-aurora-smr-deployment-with-nuclear-backed-infrastructure-alliances-poised-to-transform-data-center-power — retrieved 2026-05-10 — Oklo Aurora INL late 2027/early 2028; first commercial SMR-powered data centers ~2030.
[24] https://www.datacenterdynamics.com/en/news/fuelcell-energy-launches-125mw-modular-energy-solution-for-data-center-sector/ — retrieved 2026-05-10 — FuelCell Energy 12.5 MW power-block productization; SDCL 450 MW agreement.
[25] https://en.wikipedia.org/wiki/Bloom_Energy_Server — retrieved 2026-05-10 — Disclosed historical production cost range $2,500–4,000/kW (2017–2023); 100 kW unit ~$700–800K per cabinet.