# META — Meta Platforms, Inc.

## Where this sits in the AI stack
Meta is a vertically integrated **buyer and operator** of AI infrastructure, not a seller of compute. At silicon, it co-designs the MTIA ASIC family with Broadcom on TSMC 3nm (moving to 2nm in 2026‑27); at the system layer it ships open OCP server designs (Grand Teton) and runs the largest non-cloud GPU fleet — 100k+ H100 superclusters for Llama training plus 1.3M H200/Blackwell at Prometheus when it lights up [1][2][3]. At the application layer the workload that actually pays for the buildout is **real-time recommendation ranking** (Reels, Feed, Ads) using HSTU-class generative ranking models — not chatbots — and the training/inference targets are mostly internal: ranking and ads (compute-to-CPM), with Llama and Muse Spark as a secondary external research product line. [4][5][6]

## Snapshot
- **Price:** $609.63 (2026-05-08 close) [7]
- **Market cap:** ~$1.54T (consensus); some quote $1.71T using diluted basis. Use $1.54T as the working figure. [8]
- **52-week range:** $520.26 – $796.25 [9]
- **Forward P/E:** ~20.1× on FY26 consensus EPS of ~$30.1 (range 18.4×–22.6× across providers reflects whether 2026 or 2027 EPS is used) [8][10]
- **EV / NTM revenue:** 7.3× on ~$215B TTM revenue (17% below 10-yr median 8.8×) [11]
- **Consensus 12-month price target:** $839.47 (implied **+37.7%** from $609.63) [9]
- **YTD total return:** **-6.48%** (through 2026-05-07) [12]
- **Short interest:** ~1.04% of float (~26.5M shares) — low absolute level [13]

## Moat — what it is physically made of
Meta's moat is **not** the NVIDIA-style developer-lockin moat. It decomposes into four distinct stacks of very different durability:

**1. Recommendation-system depth (highest durability).** The "Actions Speak Louder than Words" (HSTU) architecture, deployed at 1.5T parameters on Reels/Feed, beat the prior DLRM baseline by 12.4% in online A/B and showed scaling-law behavior across three orders of magnitude of compute — i.e., recommendation quality now scales with compute the way LLM quality does [14]. GEM (Generative Ads Model) extended this to ads ranking, delivered +5% Reels conversions / +3% Feed conversions, and is reportedly 4× more compute-efficient per unit of ad gain than prior ranking stacks [5][6]. The moat here is the combination of (a) trillions of impressions/day of first-party engagement signal, (b) custom transducer architectures published but not trivially reproducible, and (c) M-FALCON-style inference algorithms that bend the recommendation inference cost curve — Meta claims 900× efficiency improvement vs. legacy DLRMs [14]. Person-years to replicate at parity outside a hyperscaler with comparable signal: not bounded — a competitor *without* the engagement signal cannot replicate this regardless of compute.

**2. Vertical hardware (medium-to-high, rising).** MTIA is now on a 6-month tick-tock: MTIA 300 (ranking/recommendation training, in production), 400, 450, 500 (GenAI inference), with claimed HBM bandwidth +4.5× and FLOPs +25× across 300→500 [2]. The April 14, 2026 Broadcom partnership extension committed to multi-GW of MTIA capacity, with Broadcom-supplied 1.6T Ethernet and HBM3e controllers integrated on-die — i.e., the network fabric is co-designed with the accelerator [3][15]. MTIA on 2nm would be the first AI silicon on that node alongside Broadcom-co-designed parts [15]. Durability: depends on TSMC CoWoS-L allocation, which NVIDIA dominates at ~60% share through 2026 [16]. Meta's slot is meaningful but is in queue behind NVIDIA's Rubin ramp.

**3. Open-source weaponization (medium, narrowing).** Llama + PyTorch + Triton/Inductor stack continues to commoditize the inputs to OpenAI/Anthropic/Google's product layer. But the gap is narrowing the *wrong way*: Llama 4 Scout/Maverick (released April 2025) landed below market expectations relative to Claude 4.6 and Gemini 3.1 Pro, and Chinese open-source releases (GLM-5.1, Qwen, DeepSeek-class) are now competitive or ahead of Llama on coding/SWE benchmarks [17][18]. The Alexandr Wang / MSL reorg (April 2026) and Muse Spark launch is an explicit acknowledgement that the Llama line had stalled [19][20]. Durability: open-source moat is real for advertiser/dev mindshare but is no longer technically leading.

**4. Distribution + advertiser flywheel (highest durability, oldest moat).** 8M advertisers now using Meta's AI ad-creative tools, up from 4M at end-2024 [1]. The unit economics: every dollar of MTIA/GPU inference spent on improving Andromeda/GEM ranking shows up as price-per-ad uplift (Q1 2026: +12% YoY on price-per-ad, +19% on impressions) [1]. This is a self-funding compute flywheel that is structurally absent for OpenAI/Anthropic, who must monetize via subscription/API.

## AI buildout bottleneck map
Mapping the 24-month gating constraints and Meta's position on each:

- **Advanced packaging (CoWoS-L):** TSMC scaling 35k → 130k wafers/month by end-2026; NVIDIA holds ~60% of 2026 allocation; Google cut its 2026 TPU production target from ~4M to ~3M units (~25%) explicitly due to CoWoS constraints [16][21]. **Meta position:** Constrained customer — its MTIA volume depends on Broadcom's CoWoS allocation, which sits behind NVIDIA in the queue. Inferred risk: MTIA 450/500 volume ramp could slip if Broadcom doesn't win packaging slots back from NVIDIA.
- **HBM3e / HBM4:** Fully booked through 2026; SK Hynix ~50–55% share, Samsung 35–40%, Micron 5–10%; ~20% HBM3e price hike planned for 2026 [22][23]. **Meta position:** Exposed customer — the recent capex raise ($115–135B → $125–145B) was explicitly attributed by management to "higher component pricing" including memory [24].
- **Power generation & turbines:** GE Vernova backlog 100GW under contract, slots sold out through 2030 by end of 2026 [25]. **Meta position:** Constraint *owner* via vertical integration — for Prometheus (Ohio) it sidestepped utility interconnect timelines by contracting directly with Will-Power OH for two 200MW gas turbines targeting in-service Q3 2026 [26]. This is the differentiated move. Most competitors are waiting on PJM/MISO interconnect queues measured in years.
- **Liquid cooling >100kW/rack:** Meta has publicly committed to liquid cooling for the Catalina/Open Rack v3 generation supporting Blackwell GB200 [27]. **Position:** Beneficiary of its own OCP work; not gated.
- **Optical / scale-out fabric:** Meta has validated Ethernet/RoCE at 24,576-GPU scale on Arista 7800 + OCP Wedge400/Minipack2, demonstrating parity with InfiniBand on the same workload [4]. **Position:** Indifferent to NVIDIA's NVLink/InfiniBand lock — has a working Ethernet alternative for both internal and Broadcom-supplied MTIA fabric.
- **Kernel/compiler talent:** Meta owns PyTorch, Triton, Inductor; the bench is deep. **Position:** Net supplier of talent and tooling to the industry.
- **Training data at the frontier:** Scale AI 49% stake ($14.3B) gives Meta a privileged but not exclusive data-labeling supply line for MSL [19]. **Position:** Constraint owner partially; the open-frontier-data question is unsolved across the industry.

## Competitive teardown
- **NVIDIA:** Not a competitor at the application layer; the more relevant axis is *how much of Meta's accelerator $ shifts to MTIA over time*. Inference at Meta scale (recommendation + ads + AI Studio) is the *exact* workload where custom ASICs win on TCO — power-law recommendation models are memory-bandwidth bound, not FLOPs bound, and MTIA's HBM-rich design (per-chip bandwidth claimed higher than commercial parts at MTIA 450) targets this directly [2]. Base rate on custom silicon displacing merchant GPU at hyperscalers: Google TPU now ~15-yr deep, AWS Trainium/Inferentia growing. NVIDIA share of *training* at Meta stays dominant through 2027; share of *inference* falls below 50% by 2027 is a credible inference.
- **Google (Gemini + TPU):** On the *model* axis Gemini 3.1 Pro is currently ahead of any Meta-owned model on multi-task reasoning benchmarks [17]. On the *infrastructure* axis Google has a 15-year head start on custom silicon (TPU) and on integrated training systems. The axis on which Meta wins is distribution (Family of Apps DAU) and ad self-serve.
- **OpenAI + Microsoft / Stargate:** Stargate is targeting ~10GW of capacity, $500B over multi-year [28]. Abilene flagship ~1GW by mid-2026 [28]. Meta's Prometheus (1GW Ohio, 2026) and Hyperion (1.5GW by 2027, 5GW eventual) is the comparable scale, but Meta is single-tenant; Stargate is multi-tenant via OpenAI. On the *power-per-dollar-of-revenue* metric Meta is far better positioned because it has $215B of paying revenue today vs. OpenAI's ~$13B annualized.
- **AMD (MI400):** Has not yet demonstrated multi-node FP4 scaling at parity with Blackwell on independent MLPerf submissions for GPT-4-class architectures. Meta is a publicly disclosed AMD customer at the MI300X level but at modest volume. Verdict: not yet a credible NVIDIA displacement, so doesn't materially shift Meta's compute mix near-term.
- **Anthropic, xAI:** Compete with Meta only at the *frontier-model* axis where Meta's MSL/Muse line is currently a follower. Not a threat to ads/recommendation revenue.

## Bull case — technical
The technical conditions for outperformance:
1. **HSTU/GEM scaling continues to follow a power law in production.** This is the central question. The 2024 paper showed scaling across 3 orders of magnitude up to GPT-3-class compute; the bull case is that the same curve holds for another 1–2 orders of magnitude, meaning every $1B of incremental MTIA/GPU compute applied to ranking continues to throw off ad CPM uplift at a roughly linear rate [14]. Q1 2026's +12% YoY price-per-ad is consistent with this still being intact [1].
2. **MTIA 400/450 ramps on schedule on 3nm in 2H 2026.** If Broadcom delivers, Meta cuts its NVIDIA $/inference-token cost by a multiple, freeing capex headroom and improving incremental ROIC on the next compute dollar. Base rate: Google's TPU took ~3 generations to reach parity TCO with merchant GPU for Google-internal workloads; Meta is on MTIA v3-equivalent (Iris/300) which suggests near-parity is plausible.
3. **The CoWoS / HBM bottleneck holds long enough to suppress competitor frontier-model progress** (specifically, slowing Google/OpenAI/Anthropic's training cadence) while Meta's ad-revenue compounding continues independent of frontier capability. This is the asymmetric case: Meta's revenue does not require winning AGI.
4. **Ray-Ban Display + Neural Band crosses 10M unit run-rate in 2026** [29], validating glasses as the next ambient-AI hardware platform — but this is option value, not the base case.

Base rate on technology displacement at this stage: at scale-out plateaus, incumbent ecosystems hold share for 5–10 years (CUDA, x86 in server, Windows in desktop). The bull case does not require Meta to displace anyone — it requires the application-layer flywheel (ranking → CPM) to continue running while Meta de-risks its compute supply via MTIA.

Financial outcome: forward P/E re-rates from ~20× to ~25× as the market reprices the compute-to-CPM flywheel as durable; consensus $839 PT achievable on FY27 EPS of ~$36–38.

## Bear case — technical
Symmetric. The conditions under which the thesis breaks:
1. **HSTU/GEM scaling saturates.** If the next $40B of compute applied to ranking yields <2% incremental ad price uplift (vs. ~12% YoY currently), the marginal ROIC on capex collapses [1]. The model architecture work is published; there is no a-priori reason a recommendation power law extends indefinitely. **This is the central bear risk and is genuinely difficult to disprove from outside.**
2. **MTIA ramp slips.** Custom ASIC programs that miss a node generation usually never catch up (cf. Tesla Dojo, Microsoft Maia v1). If MTIA 400/450 misses 2H 2026 on either CoWoS allocation or 3nm yield, Meta is stuck buying Blackwell/Rubin at NVIDIA's gross margin, and the $145B capex run-rate gets less efficient, not more, on each subsequent generation.
3. **Muse / Llama line falls structurally behind frontier.** If Muse 2 (presumed late 2026) lands materially behind GPT-5.4 / Gemini 3.1 Pro / Claude 4.6 on standard reasoning + coding benchmarks, the developer mindshare that justified PyTorch+Llama as a strategic moat erodes — and competitors get to run on commodity inference stacks (vLLM/TensorRT-LLM) without paying Meta-shaped costs. The Llama 4 reception in 2025 and the MSL reorg suggest this risk is *already partly realized* [19][20].
4. **Power timing slips at Prometheus.** Will-Power OH's 400MW gas-turbine in-service date Q3 2026 is on the critical path [26]. Turbine OEM backlog is so deep that any slippage means kit waits unpowered. If Prometheus is dark for 2 quarters, the depreciation hits revenue without offsetting ad uplift.
5. **Reality Labs continues to compound losses.** $4.0B Q1 operating loss = ~$16B annualized; that's 23% of Family-of-Apps operating income vaporized for an Orion product roadmap that has yet to ship a successor to Quest at meaningful scale [1].

A short-seller who understands the stack would not short on capex *per se* — they would short on the bet that recommendation-system scaling laws plateau before MTIA reaches cost parity with merchant GPU. That window is 2026–27.

## Market view check
At $609.63 / ~$1.54T market cap / 20× forward EPS / 7.3× EV/NTM revenue, Meta trades **below** its 10-yr median EV/revenue (8.8×) [11] despite running 33% YoY revenue growth, +37% above the price target, with the largest non-cloud GPU fleet in the world and a working custom-silicon program. YTD return of -6.5% on a +33% revenue print reflects investor anxiety specifically about the $125–145B capex run-rate, *not* about the underlying business [12][24]. The market is implicitly saying it doesn't believe the capex will earn its cost of capital at current ROIC. The technical view above says the burden of proof should be the opposite: the compute-to-CPM flywheel is the cleanest ROIC chain in AI, and at 20× forward Meta is priced like a mature ad-network with optional AI upside rather than an AI infrastructure operator with mandatory ad-network downside protection. The market is mispricing the flywheel-to-flywheel feedback by, I estimate, 15–25% to the downside. The disagreement is not about earnings — it's about whether $145B/yr is a return-on-capital story or a moonshot.

## 90-day falsifiers
Specific observables in next 90 days:
1. **Q2 2026 earnings (late July):** Does management raise FY26 capex *again* above $145B? Above-range would signal MTIA/HBM pricing is still inflecting and is a bear signal *for the stock* but bull signal for the underlying buildout reality.
2. **Q2 price-per-ad print:** If price-per-ad decelerates from +12% YoY to <+6%, that's evidence the GEM/HSTU power law is bending. Watch this specifically.
3. **Broadcom (AVGO) Q3 earnings (Sept):** Comments on MTIA ramp timing and CoWoS-L allocation — if Broadcom's AI revenue guide misses or Meta-attributed share is below ~$3B/qtr run-rate, MTIA ramp is at risk.
4. **Muse Spark adoption data on Meta AI app:** If Meta does not publicly cite weekly active users or query share, that's negative inference. If they do and the figure is comparable to ChatGPT mobile DAU (~150M), that's a meaningful frontier model signal.
5. **Will-Power OH turbine commissioning:** Public PJM/Ohio Power Siting Board filings will indicate if Q3 2026 in-service date for the first 200MW slips [26].
6. **Independent MLPerf v5.1 inference submissions:** If any submission discloses MTIA 400 numbers at competitive perf/W vs. B200 on Llama 3.1 405B or comparable workload, that's the cleanest external signal of MTIA viability.
7. **Q2 Reality Labs operating loss:** A widening from -$4.0B/qtr to -$5B+ without revenue inflection is a tax on the AI thesis.

## What I could not verify
- **Exact MTIA 300/400 unit shipment figures and as-deployed inference TCO vs. H200/B200.** Meta has not published per-chip economics; SemiAnalysis estimates exist but I did not access a current paid issue [15].
- **Whether the "1.3M H200/Blackwell at Prometheus" figure is from Meta or analyst inference.** It appears in secondary sources attributed to "Meta Compute" public framing but I did not find a direct Meta statement quantifying GPU count for Prometheus at that scale [30].
- **Llama 4 / Muse adoption metrics (active downloads, deployed instances).** Meta has not published numbers comparable to Hugging Face download stats since the Llama 4 disappointment.
- **MTIA's actual fabric topology and whether NVSwitch-class scale-up is feasible** — Broadcom's 1.6T Ethernet is described but the tree depth, oversubscription, and collective-communication primitives are not publicly documented.
- **Capex allocation breakdown between NVIDIA GPU, MTIA, networking, real estate, and energy** — Meta does not disclose. This matters because the bull case requires MTIA-share to rise meaningfully through 2027.
- **2nm MTIA timing.** "Latter half of 2026 / 2027" is sourced to industry commentary, not a Meta-confirmed roadmap [15].
- **Exact short interest as of most recent settlement.** Cited 1.04% / 26.47M figure is from an April update; bi-monthly cadence means the May 15 update could differ [13].

## Sources
[1] https://investor.atmeta.com/investor-news/press-release-details/2026/Meta-Reports-First-Quarter-2026-Results/ — 2026-05-10 — Q1 2026 revenue, capex guidance, advertiser AI tool adoption, Reality Labs operating loss.
[2] https://ai.meta.com/blog/meta-mtia-scale-ai-chips-for-billions/ — 2026-05-10 — MTIA roadmap, 6-month cadence, 4.5× HBM bandwidth / 25× FLOPs across 300→500.
[3] https://investors.broadcom.com/news-releases/news-release-details/broadcom-announces-extended-partnership-meta-deploy-technology — 2026-05-10 — April 14 2026 Broadcom partnership for multi-GW MTIA deployment.
[4] https://engineering.fb.com/2024/08/05/data-center-engineering/roce-network-distributed-ai-training-at-scale/ — 2026-05-10 — Meta's 24,576-GPU RoCE/Arista 7800 fabric performance parity vs. InfiniBand.
[5] https://engineering.fb.com/2025/11/10/ml-applications/metas-generative-ads-model-gem-the-central-brain-accelerating-ads-recommendation-ai-innovation/ — 2026-05-10 — GEM architecture, 4× efficiency, +5% Reels conversion uplift.
[6] https://engineering.fb.com/2026/03/31/ml-applications/meta-adaptive-ranking-model-bending-the-inference-scaling-curve-to-serve-llm-scale-models-for-ads/ — 2026-05-10 — Meta Adaptive Ranking Model, bending inference scaling curve for ads.
[7] https://stockanalysis.com/stocks/meta/history/ — 2026-05-10 — May 8 2026 close $609.63.
[8] https://finbox.com/NASDAQGS:META/explorer/pe_fwd/ — 2026-05-10 — Forward P/E 20.1× on FY consensus.
[9] https://www.marketbeat.com/stocks/NASDAQ/META/forecast/ — 2026-05-10 — 52-week range, consensus PT $839.47, 38 analyst coverage.
[10] https://stockanalysis.com/stocks/meta/statistics/ — 2026-05-10 — Trailing P/E 22.42 May 7 2026.
[11] https://www.gurufocus.com/term/enterprise-value-to-revenue/META — 2026-05-10 — EV/Revenue 7.28× (April 6 2026), vs 10-yr median 8.77×.
[12] https://www.ytdreturn.com/meta/ — 2026-05-10 — YTD total return -6.48% through May 7 2026.
[13] https://www.marketbeat.com/stocks/NASDAQ/META/short-interest/ — 2026-05-10 — Short interest ~26.47M shares / 1.04% of float (April update).
[14] https://arxiv.org/abs/2402.17152 — 2026-05-10 — Zhai et al. HSTU paper: 1.5T-param generative recommender, +12.4% online A/B, 5.3–15.2× faster than FlashAttention2, power-law scaling.
[15] https://markets.financialcontent.com/stocks/article/marketminute-2026-4-15-meta-and-broadcom-deepen-custom-silicon-ties-a-strategic-shift-toward-ai-infrastructure-independence — 2026-05-10 — Broadcom 3nm MTIA, 1.6T Ethernet integration, 2nm roadmap.
[16] https://markets.financialcontent.com/stocks/article/tokenring-2026-2-5-tsmc-to-quadruple-advanced-packaging-capacity-reaching-130000-cowos-wafers-monthly-by-late-2026 — 2026-05-10 — CoWoS capacity ramp 35k→130k wafers/month, NVIDIA ~60% allocation.
[17] https://qubittool.com/blog/llm-landscape-2026-five-camps — 2026-05-10 — 2026 LLM landscape: GPT-5.4, Gemini 3.1 Pro, Claude 4.6 vs Llama 4.
[18] https://medium.com/@sanjeevpatel3007/april-2026-ai-models-every-major-release-reviewed-6ea03d7bc0b7 — 2026-05-10 — GLM-5.1 surpassing OpenAI on coding benchmarks; open-source SOTA narrowing.
[19] https://about.fb.com/news/2026/04/introducing-muse-spark-meta-superintelligence-labs/ — 2026-05-10 — Muse Spark April 8 2026 launch, MSL reorg, Wang/Scale AI $14.3B / 49% stake.
[20] https://fortune.com/2026/04/08/meta-unveils-muse-spark-mark-zuckerberg-ai-push/ — 2026-05-10 — Muse Spark context: response to Llama 4 disappointment.
[21] https://oplexa.com/ai-chip-packaging-bottleneck-2026/ — 2026-05-10 — Google TPU 2026 production cut from ~4M to ~3M on CoWoS constraints.
[22] https://www.trendforce.com/news/2025/12/24/news-samsung-sk-hynix-reportedly-plan-20-hbm3e-price-hike-for-2026-as-nvidia-h200-asic-demand-rises/ — 2026-05-10 — 20% HBM3e price hike for 2026, supply fully booked.
[23] https://siliconanalysts.com/tools/hbm-analysis — 2026-05-10 — HBM market share SK Hynix 50–55%, Samsung 35–40%, Micron 5–10%.
[24] https://finance.yahoo.com/markets/stocks/articles/meta-just-bumped-2026-capex-232250811.html — 2026-05-10 — Capex raised to $125–145B; component pricing cited as driver; investor reaction.
[25] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — 2026-05-10 — GE Vernova 80GW backlog into 2029, sold out through 2030 by end-2026.
[26] https://www.datacenterfrontier.com/hyperscale/article/55310441/ownership-and-power-challenges-in-metas-hyperion-and-prometheus-data-centers — 2026-05-10 — Will-Power OH 2x200MW gas turbines for Prometheus, Q3 2026 in-service target; Hyperion 5GW Louisiana scale plan.
[27] https://engineering.fb.com/2024/10/15/data-infrastructure/metas-open-ai-hardware-vision/ — 2026-05-10 — Meta liquid cooling / Catalina / OCP open hardware vision.
[28] https://www.datacenterfrontier.com/machine-learning/article/55319132/scaling-stargate-openais-five-new-us-data-centers-push-toward-10-gw-ai-infrastructure — 2026-05-10 — Stargate 10GW target, Abilene ~1GW mid-2026, $500B program.
[29] https://www.meta.com/blog/meta-ray-ban-display-ai-glasses-connect-2025/ — 2026-05-10 — Ray-Ban Display $799 launch Sept 30 2025; Meta target 10M AI-glasses units by end-2026.
[30] https://markets.financialcontent.com/stocks/article/tokenring-2026-2-6-the-gigawatt-era-inside-mark-zuckerbergs-meta-compute-manifesto — 2026-05-10 — Prometheus described as housing ~1.3M H200/Blackwell GPUs (analyst inference, not Meta-confirmed).