# SNOW — Snowflake Inc.

## Where this sits in the AI stack
Snowflake is a multi-tenant SQL data-platform vendor operating at the **application/governed-data layer**, not silicon, packaging, memory, networking, power, or cooling. It does not own fabs, build accelerators, or operate datacenters; its compute and storage are *rented* from AWS, Azure, and GCP and re-sold as "credits" against a consumption meter [1][2]. The actual silicon path under a Snowflake query goes: customer SQL → Snowflake cloud-services layer → virtual warehouse (a managed EC2/VM fleet) → S3/Blob/GCS object store [3]. For AI, Snowflake's products (Cortex AI functions, Snowflake Intelligence, Cortex Code, Snowpark Container Services) are inference-and-orchestration layers that *call* hyperscaler GPU instances — most notably L40S and Blackwell RTX PRO 6000 SKUs newly GA in May 2026 — to serve enterprise-data-grounded inference (RAG, agentic, structured-data Q&A) [4][5]. Workload mix: predominantly batch and interactive analytic SQL; AI workloads are nascent (~$100M run-rate, ~2.3% of product revenue) and skew toward fine-tune / RAG / agentic inference on governed enterprise data, *not* frontier training [6].

## Snapshot
- **Price:** $139.74 (2026-05-07 close) [7]; a separate stockanalysis.com pull showed $152.45 intraday-prior — I use the lower confirmed close.
- **Market cap:** ~$48B (range $47.7B–$52.7B across sources) [7][8]
- **52-week range:** $118.30 – $280.67 [9]
- **Forward P/E:** 79.2× on FY27 non-GAAP EPS consensus [10]; n/a on GAAP — company runs deep GAAP losses ($1.33B net loss TTM) [8]
- **EV / NTM revenue:** ~8.5× (EV ~$45B net of ~$3B net cash, on FY27 guide of $5.66B product revenue) [11][8] — *inference, sourced inputs*
- **Consensus 12-month price target:** $232.74 (~+67% from $139.74); 46% Strong Buy / 46% Buy / 8% Hold / 0% Sell across 37–43 analysts [9][12]
- **YTD total return:** approximately −35.7% [13]
- **Short interest (% of float):** ~5.22% / 18.0M shares (Feb 20, 2026 settlement) [14]

## Moat — what it is physically made of
The user's framework presumes silicon/packaging components — those don't apply here. Snowflake is software-and-data. The moat decomposes into five distinct components, each with a different durability:

**1. Storage format and metadata service (medium-durable).** Snowflake data lives in proprietary **micro-partitions** — immutable, columnar, compressed files of 50–500 MB uncompressed, with header metadata (min/max per column, distinct counts, null counts) that enables aggressive partition pruning by the query optimizer [3][15]. This is the *technical* basis of fast SQL; it is not a moat against a competitor who can write their own format, but it *is* a moat against switching costs because the metadata service knows things about each customer's data that S3 does not. **Critical erosion vector**: Snowflake's own April 2024 disclosure — now the subject of the live securities class action with April 27, 2026 lead-plaintiff deadline — admitted that as customers adopt **Iceberg tables** as the storage format, Snowflake's per-storage-TB economics and stickiness deteriorate, because data physically lives in customer-controlled buckets in an open format readable by Trino, Spark, Dremio, DuckDB, etc. [16][17]. Snowflake's response — donating the **Polaris catalog** to the Apache Software Foundation in Aug 2024 — was a strategic admission that closed-format lock-in is no longer viable [17]. Polaris is now Apache Polaris; the open project and Snowflake's managed Open Catalog share the same backbone [17][18].

**2. Query optimizer + multi-cluster compute orchestration (durable).** The "secret sauce" most often cited by practitioners: cost-based optimizer tuned over ~12 years against the micro-partition statistics, plus an elastic scheduler that spins virtual warehouses of T-shirt sizes (XS–6XL) with per-second billing and result-set caching across the cloud-services layer [3][15]. Replicating this at parity in OSS engines (Trino, DuckDB) requires multi-year tuning against representative workloads. Realistic replacement cost: **person-decades**, not person-years.

**3. Snowgrid / data sharing network (durable, asymmetric).** Cross-region, cross-cloud read-only data sharing without data movement, plus the Marketplace listing economy. This is a genuine network effect: each new account on Snowflake increases the value of a data publisher's listing. Hard to replicate from zero — but Databricks Delta Sharing and Unity Catalog now offer functionally similar capability over open formats, eroding the asymmetry [19].

**4. Governance / Horizon Catalog (medium-durable).** Lineage, masking policies, row access policies, tag-based governance, and the privacy-preserving clean rooms. This is real enterprise value, but it is roughly at parity with Databricks Unity Catalog and Microsoft Fabric's OneLake governance for net-new deployments [19][20].

**5. Sales motion + enterprise contracts (the largest cash moat in the near term).** $9.77B RPO (+42% YoY), including a single Q4 contract of $400M [21]. NRR sustained at 125% [22]. ~46% of RPO recognizes within 12 months — so ~$4.5B of FY27 revenue is contractually anchored. This is the moat that the stock price actually reflects, and it is *contractual*, not technical.

What the moat is **not**: it is not CUDA-equivalent. There is no kernel library, no compiler stack, no hardware-aware runtime that competitors must replicate from scratch. The replacement engineering effort for the optimizer and scheduler is large but bounded (Databricks has demonstrated it; ClickHouse Cloud has demonstrated a different point on the curve). The moat depth is closer to "Oracle ~2005" than "NVIDIA ~2024."

## AI buildout bottleneck map
Stating explicitly where SNOW sits relative to each gating constraint over the next 24 months. SNOW is **not** a beneficiary of physical-substrate scarcity — it is largely *insulated* from it, and to the extent it is exposed, it is exposed as a **customer**, not as a supplier or constraint owner.

| Bottleneck | SNOW position | Notes |
|---|---|---|
| HBM3e / HBM4 supply (SK hynix, Samsung, Micron) | Indifferent customer | Pays through hyperscaler GPU rental; cannot benefit from tight HBM, only suffer rate pass-through |
| CoWoS-L advanced packaging (TSMC) | Indifferent | Same as above |
| Power generation & grid interconnect (>100MW) | Indifferent | Hyperscaler problem; passes through |
| Liquid cooling >100kW/rack | Indifferent | Hyperscaler problem |
| Optical interconnect / 1.6T transceivers | Indifferent | Hyperscaler problem |
| **GPU rental price (esp. L40S, B200, GB300)** | **Exposed customer** | New Snowpark Container Services SKUs GA May 5, 2026 [5]; AI workloads run on these and carry **structurally lower gross margin than SQL warehouses** — management has explicitly conceded this is the source of FY26 product-margin compression from 76% → 75% [22][6] |
| **Kernel/compiler talent** | Modestly exposed | Internal Cortex inference engine teams compete with NVIDIA, OpenAI, Anthropic, Mistral, Databricks for the same talent pool |
| **Training data quality at the frontier** | Indifferent | Doesn't train frontier models; the Arctic 480B/17B-active MoE was a one-off open-weights effort, not a flagship product [23] |
| **Enterprise data gravity** | **Beneficiary** | Genuine tailwind: customers want to run inference *where governed data already lives*, avoiding egress and a second copy. This is Snowflake's structural pitch [4] |
| **Object storage egress fees** | **Two-sided exposure** | Iceberg native tables now allow customers to keep data in their own buckets; cross-region egress charges back to customer [24] — reduces storage revenue capture but improves competitive openness |

The honest summary: **physical AI-buildout bottlenecks are not Snowflake's tailwind**. The only physical tailwind it benefits from is **enterprise data gravity**, which is real but slow-moving and contested by every other data platform vendor.

## Competitive teardown

**Databricks (private; the central competitive threat).** Closed $5B Series L at $134B in Feb 2026; IPO widely telegraphed for 2026 [25][26]. Revenue ~$5.4B ARR growing 65%; **AI revenue ~$1B run-rate vs. Snowflake's ~$100M** — a 10× gap with Snowflake's product revenue base only ~25% smaller [25][6]. In head-to-head AI/ML POCs, Databricks wins ~70% of incremental budget [25]. Technical axis: Databricks owns the *training and ML platform* layer (MLflow, Mosaic, Unity Catalog over Delta+Iceberg v3) [27], while Snowflake owns the *SQL/BI consumption* layer. The honest read: **Databricks already has parity-or-better on AI training and serving**. Snowflake's defensible territory is interactive SQL on governed data with the lowest ops burden — a real but narrower TAM. The IPO will create an immediate read-across: if Databricks prices at $134B+ on $5.4B ARR (~25×), Snowflake at ~$48B on $4.5B product revenue (~11× EV/NTM) suddenly looks reasonable in relative terms, but the *growth-and-AI-mix* gap is what the market is pricing.

**Microsoft Fabric.** ~25–40% lower TCO than Snowflake for equivalent enterprise workloads, with native OneLake + Power BI + Copilot integration [20]. Wins on Microsoft-first accounts (per third-party analyses, 9 of 14 enterprise comparison axes in Microsoft-centric deployments) [28]. The Snowflake-Microsoft Iceberg/OneLake interop partnership is partially defensive — Snowflake is conceding that data will increasingly live in OneLake and Snowflake's role is compute-on-top [20]. Threat axis: net-new Azure-native enterprise workloads.

**Google BigQuery.** Mature on multi-modal SQL+AI (Gemini in BigQuery, Vertex tie-in) with serverless pricing that is competitive on bursty workloads. Gartner places SNOW at ~40% data-warehousing share vs. BigQuery's smaller but stickier GCP-native share [20]. BigQuery + Vertex is the cleanest tightly-integrated SQL-plus-frontier-model story; threat axis is workloads where customers want the same vendor for SQL and the model.

**AWS Redshift + SageMaker + Bedrock.** The native AWS stack is increasingly viable; Redshift Serverless + Bedrock RAG addresses a meaningful share of what Cortex AI offers. AWS has a structural cost advantage on AWS-native workloads (Snowflake's COGS on AWS is AWS's revenue).

**ClickHouse Cloud / DuckDB / Trino-on-Iceberg.** The low end. ClickHouse Cloud is materially cheaper for high-concurrency analytics; DuckDB+MotherDuck and Trino-on-Iceberg with a Polaris catalog (which Snowflake itself open-sourced) can serve a real fraction of mid-sized analytic workloads at a fraction of the cost. This is the **commoditization vector** the Feb 2024 disclosure (and the live securities class action) referenced [16].

## Bull case — technical
For the stock to materially outperform, the following technical conditions must hold:

1. **Data gravity wins over compute portability for AI inference.** Enterprises do not want to copy governed PII/PHI/financial data to a third-party model provider; they want models to come to the data. Snowflake's Cortex AI + Snowpark Container Services + L40S/Blackwell GPU SKUs are the only major SQL-vendor execution of this thesis. If 5–10% of enterprise inference spend ends up running adjacent to the analytic store, that is incremental consumption directly into Snowflake's meter at ~75% product gross margin or better as Cortex efficiency improves [4][5][6].

2. **The Iceberg transition turns out to be revenue-additive, not destructive.** If customers move storage to Iceberg but still pay Snowflake for compute on top — and Snowflake captures compute on *other* engines' Iceberg data via Open Catalog — Snowflake becomes a higher-margin "compute toll" rather than a storage+compute bundle, similar to how Stripe captures payment volume on others' platforms.

3. **NRR stabilizes ≥120% and RPO duration extends.** The $400M Q4 contract and 42% RPO growth suggest enterprise commitments are extending, not shortening. If FY27 lands at the $5.66B guide and NRR holds 120%+, the consumption-deceleration narrative dies [21][22].

4. **AI workloads scale fast enough to materially shift mix.** Cortex penetration is real: 9,100 accounts on Cortex, 2,500 on Snowflake Intelligence in 3 months, Cortex Code at >50% of customers [6][29]. The question is dollar magnitude. From $100M run-rate to $500M+ over 6–8 quarters would change the narrative.

**Base rate on displacement.** Enterprise data-platform incumbents at scale rarely lose share *quickly*. Oracle/Teradata/Netezza took 10–15 years of cloud cannibalization to materially erode. Data gravity, audit cycles, and contract durations are real. The 2-yr base rate for a sub-30%-share-loss for an incumbent of Snowflake's installed base is high (>70%). Financial outcome under bull: revenue compounds to ~$8B in FY29; multiple re-rates to 12–14× EV/NTM; stock to $220–260 (~60–85% upside), consistent with consensus PT.

## Bear case — technical
The short-seller version, told honestly:

1. **The "moat" is mostly contract duration and brand, not technical depth.** Strip away the optimizer (replicable in 5–7 years, evidenced by Databricks SQL improvements) and the proprietary storage format (now obsolescing toward Iceberg by Snowflake's own admission [16]), and what remains is governance + sales motion + a price-anchored consumption meter. Governance is at parity with Unity Catalog and OneLake. **There is no CUDA-class technical moat here.**

2. **AI workloads are structurally lower margin and Snowflake doesn't own the GPUs.** Cloud-infrastructure COGS jumped from 64% → 72% of cost in Q3 FY26 — the largest single-quarter increase in years [6]. Snowflake is a **rate-taker** on GPU prices; every dollar of inference revenue passes through NVIDIA's and the hyperscaler's margin first. Product gross margin already slipped 76% → 75% YoY and may continue to compress as AI mix grows [22]. The "AI Tax" is real and structural.

3. **Databricks is winning the workload that matters going forward.** $1B AI run-rate vs. Snowflake's $100M; 65% growth vs. 27% guide; ~70% head-to-head AI POC win-rate; v3 Iceberg public preview leadership [25][27]. If the future of enterprise data spending is "model + governed data + open format," Databricks is already there. Snowflake's response (Polaris, Iceberg native tables, Cortex) is defensive and concessive.

4. **SBC + dilution erodes equity holder economics.** $1.5–1.6B SBC, 40.8% of revenue, exceeds operating cash flow by 154% [30][6]. Convertibles raised $2.3B for buybacks and still net dilution rose 8.1M shares over 9 months [30]. GAAP operating margin is −27% even as non-GAAP is +11% — a 38-point optical gap [6]. On a fully-burdened-SBC basis, the company is not profitable and the per-share growth is materially below revenue growth.

5. **The securities class action is real.** The April 2024 disclosure that Iceberg tables, tiered storage, and product-efficiency gains would *materially reduce* consumption and revenue is a management admission, on the record, that the storage moat is shrinking [16]. The plaintiffs' bar is now in for years of pressure on disclosures.

6. **Hyperscaler dependency caps upside.** Snowflake's entire substrate is AWS/Azure/GCP. AWS is its largest infrastructure cost *and* its largest competitor (Redshift+Bedrock). Microsoft Fabric is bundled into existing Azure commitments. Google has Gemini-in-BigQuery. The platforms Snowflake rents from are increasingly the platforms it competes with — and they own the GPU allocations.

**Base rate against bear:** in tech displacement, the *new workload* (AI/ML) flowing to the *new platform* (Databricks) while the incumbent retains existing workloads is a well-documented pattern (mainframe → x86, on-prem → cloud, Oracle OLTP → MongoDB/Postgres). The incumbent rarely dies, but multiples compress hard and the growth premium is gone. Financial outcome under bear: revenue compounds to ~$6.5B in FY29 with margins still pinched; multiple compresses to 6–8× EV/NTM; stock $90–110 range. Realistic 12-month downside ~30%.

## Market view check
At $139.74, the market is paying ~8.5× EV/NTM revenue and ~79× forward P/E for a 27%-guided-grower that is GAAP unprofitable, dilutes ~3% annually after buybacks, and is staring down a Databricks IPO at ~25× on faster growth and 10× more AI revenue. The −36% YTD move says the market has already discounted the bear case substantially — the multiple has compressed from ~14× to ~8.5× EV/NTM over twelve months. Consensus PT of $232 (+67%) implies analysts are anchored to the bull case (Cortex scales, NRR holds, AI is consumption-additive); the price is anchored to the bear case (Databricks IPO benchmark, AI margin pressure, lawsuit overhang). **My read: the price is roughly consistent with the technical reality that Snowflake is a durable SQL/BI incumbent that has *already lost* the new-workload (AI training/serving) battle to Databricks. What's mispriced is the optionality on Cortex actually becoming a $1B+ business inside 24 months — the market is paying ~zero for that optionality.** The asymmetry is interesting but not screaming; you are buying a high-quality enterprise SaaS franchise at a now-reasonable multiple, not a structural AI-buildout beneficiary.

## 90-day falsifiers
- **Q1 FY27 earnings (scheduled May 27, 2026 [8]):** Product revenue >$1.10B or NRR <122% are material reads. A guide-down on FY27 below $5.55B kills the thesis; a raise to $5.75B+ confirms Cortex traction.
- **Cloud-infra COGS line in 10-Q:** Sequential improvement from the 72% Q3 spike, or worsening. This is the cleanest signal on AI margin structure.
- **Databricks S-1 filing or IPO pricing:** Will set the comp multiple. If Databricks prices at <20× EV/NTM, SNOW's relative-value case strengthens; >30× and SNOW looks cheap on relatives but absolute multiple resets the sector.
- **Cortex AI explicit run-rate disclosure:** Management has been coy. If a Q1 call quantifies Cortex revenue at >$150M run-rate, optionality re-prices; silence implies the $100M figure is still the right estimate.
- **Iceberg-native customer migration disclosures:** Any customer call-out of moving substantial workload to Iceberg-on-third-party-engine is a leading indicator on the lawsuit thesis.
- **Lead-plaintiff selection in the securities class action (post-April 27 deadline):** Choice of firm signals plaintiff-side seriousness; aggressive lead counsel extends overhang.
- **Snowpark Container Services GPU adoption metrics:** Any disclosure of GPU credit consumption as % of total credits — first time a meaningful tell on AI consumption mix.
- **Microsoft Fabric net-new logo wins announced by Microsoft on Azure earnings (Apr 2026 & Jul 2026):** Direct read on the Azure-native displacement vector.

## What I could not verify
- **Exact COGS split between hyperscaler pass-through and Snowflake internal cost.** Snowflake's 10-K aggregates "cost of product revenue" without disclosing AWS/Azure/GCP commit dollars separately. The 72% Q3 cloud-infra-COGS figure comes from third-party research [6], not direct disclosure.
- **Cortex AI dollar revenue.** The ~$100M / 2.3%-of-product-revenue figure is third-party estimate [6]; Snowflake has not published an explicit Cortex revenue line.
- **Databricks AI revenue composition.** The $1B AI run-rate cited [25] is reported but not audited; what counts as "AI revenue" vs. "data engineering supporting AI" is fuzzy in both companies' disclosures.
- **Per-region GPU SKU pricing for Snowpark Container Services.** Docs confirm L40S and Blackwell RTX PRO 6000 availability [5] but credit-per-hour rates for these instance families were not in materials reviewed.
- **Cross-cloud egress dollar impact on Iceberg native table customers.** Mentioned qualitatively in docs [24], not quantified.
- **Whether the $400M Q4 contract is a single customer or a renewal/expansion bundle.** Press materials [21] and earnings transcripts do not name the customer or specify TCV duration; this matters for backlog quality assessment.
- **Independent benchmarks of Cortex inference vs. Bedrock / Vertex on equivalent enterprise RAG workloads.** No MLPerf-equivalent third-party benchmark exists for governed-data inference.

## Sources
[1] https://www.snowflake.com/en/pricing-options/ — retrieved 2026-05-10 — Snowflake pricing model and credit-based consumption.
[2] https://www.cloudzero.com/blog/snowflake-pricing/ — retrieved 2026-05-10 — Cost structure and AWS/Azure/GCP pass-through pricing.
[3] https://select.dev/posts/snowflake-architecture — retrieved 2026-05-10 — Three-layer architecture (storage, compute, services) detail.
[4] https://www.snowflake.com/en/product/features/cortex/ — retrieved 2026-05-10 — Cortex AI product surface.
[5] https://docs.snowflake.com/en/release-notes/2026/other/2026-05-05-spcs-new-instance-families-ga — retrieved 2026-05-10 — GPU_L40S and GPU_R6K (Blackwell) Snowpark Container Services GA May 5, 2026.
[6] https://www.runcheyresearch.com/blog/snow-q4-fy2026-earnings-preview — retrieved 2026-05-10 — Q3 cloud-infra COGS spike 64%→72%, $1.5B SBC, ~2.3% AI revenue / ~$100M run-rate.
[7] https://www.techi.com/quote/SNOW/ — retrieved 2026-05-10 — May 7, 2026 close of $139.74 (var. $139.38 intraday), ~$49B mkt cap.
[8] https://stockanalysis.com/stocks/snow/ — retrieved 2026-05-10 — $152.45 prior pull, $52.64B cap, 345.30M shares out, fwd P/E 84.91, TTM rev $4.68B, May 27 earnings.
[9] https://public.com/stocks/snow/forecast-price-target — retrieved 2026-05-10 — 52-wk range $118.30–$280.67, consensus PT $232.74.
[10] https://www.gurufocus.com/term/forward-pe-ratio/SNOW — retrieved 2026-05-10 — Forward P/E 79.16.
[11] https://www.snowflake.com/en/news/press-releases/snowflake-reports-financial-results-for-the-fourth-quarter-and-full-year-of-fiscal-2026/ — retrieved 2026-05-10 — FY26 product rev $4.472B, FY27 guide $5.66B.
[12] https://www.marketbeat.com/stocks/NYSE/SNOW/forecast/ — retrieved 2026-05-10 — Analyst ratings distribution and PT consensus.
[13] https://www.tikr.com/blog/snowflake-stock-is-down-35-in-2026-heres-whats-driving-the-pressure — retrieved 2026-05-10 — YTD −35.7%, drivers (slowing growth, AI cost pressure, lawsuit).
[14] https://fintel.io/ss/us/snow — retrieved 2026-05-10 — Short interest 18.0M / 5.22% (Feb 20, 2026).
[15] https://docs.snowflake.com/en/user-guide/tables-clustering-micropartitions — retrieved 2026-05-10 — Micro-partition technical spec (50–500 MB, columnar, metadata, pruning).
[16] https://zlk.com/cases/snowflake-inc-class-action-lawsuit-snow — retrieved 2026-05-10 — Securities class action alleging Iceberg/tiered-storage/efficiency headwinds undisclosed; April 27, 2026 lead-plaintiff deadline.
[17] https://www.snowflake.com/en/blog/introducing-polaris-catalog/ — retrieved 2026-05-10 — Polaris donated to Apache Software Foundation Aug 2024.
[18] https://www.snowflake.com/en/engineering-blog/apache-polaris-iceberg-rest-catalog/ — retrieved 2026-05-10 — Apache Polaris REST catalog implementation and engine interop list.
[19] https://www.databricks.com/blog/next-era-open-lakehouse-apache-icebergtm-v3-public-preview-databricks — retrieved 2026-05-10 — Iceberg v3 public preview on Databricks, Delta/Unity convergence with Iceberg.
[20] https://www.synapx.com/microsoft-fabric-vs-snowflake-2026-comparison/ — retrieved 2026-05-10 — Fabric vs SNOW 9-of-14 axes in Microsoft-centric deployments; 25–40% TCO advantage; OneLake/Iceberg interop note; Gartner 40% SNOW data-warehouse share.
[21] https://www.investing.com/news/company-news/snowflake-q4-fy2026-slides-30-revenue-growth-margin-expansion-ahead-93CH-4526231 — retrieved 2026-05-10 — Q4 product rev $1.227B (+30%), RPO $9.772B (+42%), $400M record contract, GM 75%, op margin 11%, FCF 61%.
[22] https://futurumgroup.com/insights/snowflake-q4-fy-2026-results-highlight-ai-led-consumption-and-platform-expansion/ — retrieved 2026-05-10 — NRR 125%, margin compression from 76% to 75%, AI consumption growth.
[23] https://www.snowflake.com/en/blog/arctic-open-efficient-foundation-language-models-snowflake/ — retrieved 2026-05-10 — Arctic 480B total / 17B active, 128 experts, dense-MoE hybrid, top-2 gating.
[24] https://docs.snowflake.com/en/user-guide/tables-iceberg — retrieved 2026-05-10 — Iceberg native tables, cross-region egress cost note, write restrictions.
[25] https://www.saastr.com/databricks-vs-snowflake-at-5b-arr-same-revenue-2x-valuation-gap-heres-why/ — retrieved 2026-05-10 — Databricks $5.4B ARR / 65% growth / $1B AI run-rate / ~70% AI-POC win rate; SNOW $100M AI run-rate.
[26] https://www.cnbc.com/2026/02/09/databricks-completes-5-billion-funding-round-with-2-billion-in-debt.html — retrieved 2026-05-10 — Databricks $134B Feb 2026 round, IPO signaling.
[27] https://www.databricks.com/blog/next-era-open-lakehouse-apache-icebergtm-v3-public-preview-databricks — retrieved 2026-05-10 — Iceberg v3 on Databricks; lakehouse / training stack maturity.
[28] https://www.techment.com/blogs/microsoft-fabric-vs-snowflake-comparison/ — retrieved 2026-05-10 — Fabric wins 9 of 14 categories vs SNOW for Microsoft-centric enterprises.
[29] https://snowflake.help/snowflake-ai-evolution-2026-from-data-warehouse-to-ai-powerhouse/ — retrieved 2026-05-10 — Cortex 9,100 accounts, Snowflake Intelligence 2,500 accounts in 3 months, Cortex Code >50% of customers, 200% AI workload growth.
[30] https://www.macrotrends.net/stocks/charts/SNOW/snowflake/stock-based-compensation — retrieved 2026-05-10 — FY26 SBC $1.6B, 40.8% of revenue, net dilution +8.1M shares over 9 months despite buybacks.