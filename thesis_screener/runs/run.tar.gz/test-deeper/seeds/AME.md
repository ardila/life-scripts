# AME — AMETEK, Inc.

## Where this sits in the AI stack
AMETEK is not a primary AI infrastructure name; it is an industrial conglomerate of ~30 niche instrumentation and electromechanical businesses whose AI exposure is **second-derivative** — selling tools, sensors, and subsystems into the AI supply chain rather than into the compute path itself. The most defensible AI-adjacent assets are: (a) **Zygo** heterodyne nanopositioning interferometers (ZMI) embedded in ASML photolithography reticle/wafer stages, plus Zygo advanced-packaging metrology used downstream of CoWoS [1][2]; (b) **Abaco Systems** ruggedized SBCs (NVIDIA Jetson AGX Orin-based SBC3901/3902) recently designed into a semi tool manufacturer's AI-ramp tool control [3][4]; (c) **Rotron** high-reliability AC/DC fans (15–60 kW BTU-class) used inside semi fab equipment cabinets [5]; (d) **Solidstate Controls** industrial UPS, plus **RTDS Technologies** real-time digital simulators for data-center power-electronics modeling [4][5]. None of these are training compute, networking silicon, HBM, advanced packaging, or hyperscale liquid cooling.

## Snapshot
- **Price:** $232.40 (2026-05-08 close) [6]
- **Market cap:** $53.26B [6]
- **52-week range:** $170.94 – $243.18 [7]
- **Forward P/E:** ~28.9× (on FY2026 EPS guide midpoint $8.04, range $7.94–$8.14) [8]
- **EV / NTM revenue:** ~7.0× (EV $52.94B [7] vs. NTM revenue ~$7.5–7.7B implied by high-single-digit growth on 2025 ~$7.1B base; pre-Indicor close) — inferred
- **Consensus 12-month price target:** $245.33 – $256.72 across screens; ~$256 from a 14-analyst panel, implied +10% from price; Moderate Buy / 1 SB + 8 B + 4 H [9][10]
- **YTD total return:** ~+29% (inferred — stock at/near 52-week high, 6-month return cited at +28% [10]; precise YE2025 close not verified)
- **Short interest (% of float):** 1.06% (~2.42M shares) [9]
- **Dividend:** $0.31/qtr; yield ~0.53% [11]

## Moat — what it is physically made of
AME's moat is **not** a CUDA-like software lock-in. It is a stack of small, durable, specification-locked positions in long-life industrial workflows, knitted together by an unusually disciplined operating system (the "AMETEK Growth Model"). Decompose:

1. **Specification incumbency in long-cycle qualified BOMs.** A Zygo ZMI displacement interferometer designed into an ASML scanner stage is qualified across thousands of hours of overlay/CD-SEM correlation; the wafer stage measures position to ~¼ nm at 20 kHz [12]. Replacing it requires re-qualifying tool overlay budgets — multi-year, multi-million-dollar process. Same dynamic for Gatan TEM detectors in research workflows and CAMECA SIMS/APT in process R&D fabs. ASML named Zygo in its 2025 Supplier Day Quality Category [2]. Durability: **high (5–10 yr)** because of TAT cost asymmetry, not patent breadth.
2. **Aftermarket / consumable annuities.** The Indicor portfolio AME is acquiring is explicitly ~50% aftermarket / consumables / service [13]. Across legacy AME, attach rate on service for installed instrument bases is the structural reason ~32% EIG operating margins are sustainable [14]. Durability: **high**, tracks installed-base attrition.
3. **Decentralized operating model + serial M&A flywheel.** 62 acquisitions historical, ~$292M average; cumulative ~$1.4B annualized revenue added 2020–2024; FCF/NI conversion 112–132% by quarter in 2025 [15][14]. The moat is in the *cadence and discipline* of bolt-on integration and synergy capture — Roper, Constellation Software, Danaher, AME are the four canonical examples and history shows the model durably compounds when management discipline holds [16]. Durability: **moderate** — model-dependent, not asset-based.
4. **Cleanroom-grade motion and sensing.** Haydon Kerk Pittman cleanroom-rated lead-screw actuators, Zygo Extreme Precision Optics (formed 2010 from ASML's Richmond CA assets) [2], Taylor Hobson LUPHOScan profilometers used in early-stage semi mfg [5]. Durability: **moderate-high** — narrow customer count means concentration risk, but qualification cost is the moat.
5. **No software moat, no scale moat, no brand moat with end users.** Worth saying explicitly: AME is not Roper (~75% software, ~80% recurring [16]). It is industrial precision hardware with services attached. The thesis cannot rest on platform/network effects.

A competent competitor displacing Zygo's ZMI position would need ~3–5 person-years of meterology IP work plus 5+ years of customer qualification — and would still face an OEM (ASML/KLA) that values single-source reliability over price.

## AI buildout bottleneck map
The actual constraints on AI buildout over the next 24 months and where AME sits:

| Bottleneck | AME position |
|---|---|
| **Hyperscaler power generation / grid interconnect** | Indirect / minor beneficiary. Solidstate Controls sells industrial-grade UPS (not hyperscale modules); RTDS sells power-system real-time simulators used by data-center designers — 2 new orders cited Q1 26 [4][5]. Not Vertiv/Eaton/Schneider scale. |
| **Advanced packaging (CoWoS-L)** | Beneficiary. Zygo advanced-packaging metrology and inspection products address bump/RDL height, warpage, planarity — increasingly critical as TSMC targets ~150K CoWoS wafers in 2026 for Rubin/Vera silicon [17]. Share is unverified but non-trivial; the equipment is sold to OSAT/foundry. |
| **HBM yield** | Minor beneficiary. CAMECA SIMS/APT used in HBM stack characterization but specialty research/process R&D, not in-line production. |
| **Optical interconnect / CPO supply** | Largely indifferent. Zygo Extreme Precision Optics could in principle serve CPO module optical alignment, not visibly disclosed. |
| **Liquid cooling at >100 kW/rack** | **Exposed / non-participant.** This is the most important gap. Rotron is air/fan cooling for semi *tools*, not server racks. Eaton just closed $9.5B Boyd Thermal (March 2026) [18]; Vertiv has 23% precision-cooling share [18]. AME has no direct-to-chip or immersion product. If liquid-cooling content per dollar of AI capex compounds, AME is *not* on that curve. |
| **Electrical contractor / switchgear capacity** | Indifferent. Eaton/Schneider own this. |
| **Kernel / compiler / NCCL talent** | Zero exposure. |
| **Training data / frontier model IP** | Zero exposure. |
| **EUV / High-NA litho throughput** | Beneficiary via Zygo. ASML guiding 60 EUV systems in 2026 (+20% YoY); Intel installed first High-NA EXE:5200B [19][20]. Zygo nanopositioning content per scanner is meaningful but a small fraction of scanner BOM. |

Net read: AME is a peripheral beneficiary across multiple thin slices; it has **no concentrated direct exposure** to the highest-growth AI infrastructure bottlenecks (liquid cooling, networking, HBM in-line, hyperscale UPS).

## Competitive teardown
The competitive map breaks into two halves, because AME straddles two different markets:

**Semi metrology / instruments side.**
- **KLA** — direct competitor in defect inspection / overlay metrology, dramatically larger and more concentrated in semi. KLA is the right vehicle for direct semi-equipment exposure. Zygo's ZMI displacement is complementary, not in conflict.
- **Onto Innovation, Camtek** — direct in advanced-packaging optical metrology. **Already at parity or ahead** on AP inspection throughput for HBM stacks and CoWoS bumps; Zygo is one of several suppliers. AME does not break out share.
- **Bruker, Thermo Fisher** — overlap with Gatan TEM/CAMECA in materials analysis. Stable share, slow-moving.

**Industrial test, motion, thermal side.**
- **Roper Technologies (ROP)** — peer serial acquirer, but ROP has migrated to ~75% software / ~80% recurring [16]. Different risk-return; not directly competing for hardware bolt-ons.
- **Fortive (FTV), Keysight (KEYS)** — overlap on test and measurement; Keysight has more direct AI-infra exposure (high-speed network test, optical test, 224 Gbps SerDes characterization).
- **Vertiv (VRT), nVent (NVT), Eaton (ETN)** — *not* head-to-head competitors but **occupy the AI-infrastructure thermal/power adjacency that AME does not own.** This is a competitive cost: investors with concentrated AI-buildout views pick those names, not AME.

What would have to be true for share loss: A customer-driven re-spec of an ASML scanner stage measurement to use a homegrown ZEISS or third-party interferometer would erode Zygo's most valuable position. The fact that Zygo was Quality-nominated by ASML in 2025 [2] is evidence this is not happening in the near term.

## Bull case — technical
For AME to outperform over a 2–3 year horizon, the following technical conditions must hold:

1. **Zygo retains ASML-spec position** through the High-NA EUV ramp (EXE:5200B and successors). Intel's first High-NA install is operational; ASML targets 2027–28 HVM [20]. ZMI sensor count per scanner is plausibly higher in High-NA due to faster stage motion (~m/s with nm-class precision [12]). Inferred: a meaningful per-tool revenue uplift through this cycle.
2. **Advanced-packaging metrology cycle continues.** TSMC's ~150K CoWoS-wafer ramp pulls inspection / metrology investment at OSATs and substrate vendors [17]; Zygo's AP product line participates even at modest share.
3. **Abaco semi-tool design-wins recur.** The Q1 26 Abaco-into-semi-tool win [4] is the kind of repeatable design slot that compounds across tool platforms. NVIDIA Jetson-based ruggedized compute (SBC3901: 248 TOPS, NVDLA v2) [3] is a credible OEM-tool reference architecture for next-gen process control.
4. **Indicor accretion delivers.** $5B / $1.1B revenue = ~4.5× sales paid; ~50% recurring revenue claim; 10–12% targeted synergies; year-1 cash accretion [13]. If management delivers ~150 bps margin lift over 24 months at AME's historical run-rate, it materially compounds EPS.
5. **Industrial compounder base rate.** Over 20-yr windows, AME, ROP, DHR, CSU.TO have each delivered ~13–15% annualized returns despite multiple platform shifts in their underlying markets — base rate favors the model continuing.

Financial outcome: EPS compounds at ~9–11% organic + ~2–3% from M&A, margins drift up 50–100 bps, multiple holds 28–30× → 12–15% annualized.

## Bear case — technical
A short-seller with the stack would write this version:

1. **AI exposure is dressed up.** The "AI-driven demand" mentions in the Q1 transcript [4] are real but small. Semi end-market is ~9% of AME [21]. Even doubling it adds <$700M revenue against a $7B base — meaningful but not regime-changing. The premium multiple implies the market is paying for AI optionality AME mostly doesn't have.
2. **The liquid-cooling miss is structural.** Boyd Thermal at $1.7B revenue with ~90% liquid cooling went to Eaton for $9.5B in March 2026 [18]. That price implies the market is putting a 5–6× revenue multiple on *direct* AI thermal exposure that AME has no equivalent of. If AI capex content shifts further toward liquid, AME's relative growth lags peers like VRT/NVT/ETN.
3. **Indicor at ~4.5× sales is full price.** CD&R is a sophisticated seller; "50% recurring" is a claim that has to be earned through integration. AME's historical bolt-on multiples have been lower; this is a step-up in cost-of-growth. Leverage going to ~2.3× at close [13] reduces M&A optionality for ~18 months.
4. **Organic EIG was only +2% in Q1 26** [22]. The +25% orders number is forward, not current revenue. If the order surge reflects pull-forward (tariffs, customer hedging) rather than durable demand, organic growth re-converges to mid-single-digit.
5. **Multiple compression risk.** 29× forward on a low-single-digit organic grower + M&A is at the rich end. ROP at similar quality but more software trades a turn or two higher; FTV trades lower. If the market re-prices industrials in a higher-rate environment, AME loses 10–15% from multiple alone.
6. **Base rate caution on technology displacement at this stage of the cycle.** Past platform shifts (CPU→GPU, on-prem→cloud) saw entrenched precision-instrument suppliers retain share for 5–10 years *and then* be partially displaced as the workload distribution changed (e.g., legacy semi-test losing share to AI-specific test). AME is more diversified than a single-workload bet, but the same dynamic is plausible in 7–10-year arc.

Honest bear punchline: this is a high-quality industrial trading at a high-quality industrial multiple with AI optionality embedded in the multiple but not in the cash flows. It can underperform without breaking.

## Market view check
At $232 / ~29× forward EPS / ~7× NTM revenue, the market is pricing AME as a premium-quality industrial compounder with AI optionality, in line with peers ROP (higher) and ETN/VRT (volatile but well-bid on direct AI). Consensus PT ~$256 implies only ~10% upside, suggesting the sell side already credits the Indicor accretion and the AI-adjacency narrative. The mispricing question is: does the market correctly weight the *gap* — specifically, AME's absence from direct AI thermal/power/networking — against its quality compounding? Plausibly the market is paying ~3–4 turns of multiple for AI adjacency that may not show up cleanly in segment data for 18–24 months. Direction of likely mispricing: **modestly rich at spot**, but defensible if Indicor integrates and EIG semi orders sustain >+15% YoY into 2H 2026.

## 90-day falsifiers
Specific, observable events that would update the thesis:

- **Q2 2026 earnings (~late July / early August):** EIG organic *revenue* (not just orders) growth — does the +25% Q1 order surge convert to mid-to-high-single-digit organic revenue, or does it stall? Stall = pull-forward thesis confirmed.
- **EIG operating margin in Q2 26:** Sub-32% (vs Q4 25 record 32.3% [14]) would signal mix shift away from high-margin instruments.
- **ASML Q2 26 print and 2H guide (mid-July):** EUV system shipments and High-NA backlog — Zygo's content is geared to this. A cut from 60-system 2026 guide [19] is a direct Zygo negative.
- **TSMC monthly revenue + CoWoS commentary:** any moderation of the 150K-wafer 2026 target [17] flows through Zygo AP metrology demand.
- **Indicor regulatory close progress:** Hart-Scott-Rodino timing, any antitrust signal. A delay past Q3 26 pushes 2027 EPS accretion math.
- **Hyperscaler Q2 26 capex commentary (META, GOOGL, MSFT, AMZN, ORCL):** any >10% sequential cut in 2026 capex guide is a sentiment hit for the entire AI-adjacent industrial complex including AME.
- **Abaco win cadence:** disclosure of additional semi-tool design-ins on Q2 call — silence = one-off.
- **Insider activity around current 52-week high ($243.18 [7]):** material executive sells would be a late-cycle signal.

## What I could not verify
- Exact AME YTD 2026 total return — derived from "+28% over 6 months" comment [10] and the current 52-week-high proximity; precise YE2025 closing price not located in searches.
- Zygo's revenue contribution to AME (not segmented in disclosures). Estimated as a small but high-margin slice of the Ultra Precision Technologies sub-segment.
- AME's specific dollar content per ASML EUV scanner — not publicly disclosed.
- Whether Zygo participates in High-NA EUV optics manufacturing beyond legacy EUV; ZEISS SMT is the primary projection-optics supplier [12][20].
- Indicor portfolio composition by product line — only revenue ($1.1B) and recurring-mix (~50%) disclosed in the May 6 announcement deck [13][21].
- Any AME design-win in liquid-cooling subsystems for hyperscale racks — searches show no evidence; treated as zero exposure.
- Customer concentration on Abaco's AI-edge semi-tool deal — single tool maker or multiple.
- Exact short interest as % of float vs. % of shares outstanding — sources differ marginally.

## Sources
[1] https://www.zygo.com/products/nano-position-sensors — retrieved 2026-05-10 — Zygo ZMI heterodyne interferometers used in closed-loop motion control for photolithography stages.
[2] https://www.zygo.com/company/about-us/history — retrieved 2026-05-10 — Zygo Extreme Precision Optics formed 2010 from ASML Richmond assets; nominated in ASML 2025 Supplier Day Quality Category.
[3] https://abaco.com/news/abaco-systems-introduces-sbc3901-high-performance-ai-edge-computing-rugged-3u-vpx-form-factor — retrieved 2026-05-10 — Abaco SBC3901: NVIDIA Jetson AGX Orin, 248 TOPS, NVDLA v2, for ruggedized AI edge.
[4] https://www.fool.com/earnings/call-transcripts/2026/04/30/ametek-ame-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1 2026 AME transcript: Abaco AI-tool win, RTDS data-center modules, $5B+ M&A capacity, $25M Q1 capex, +$100M 2026 growth investment.
[5] https://www.ametek.com/our-stories/stories/case-studies/2026/semiconductor-thermal-management-rotron — retrieved 2026-05-10 — Rotron fan cooling 15–60 kW BTU range, decades-long reliability in semi fabs.
[6] https://www.macrotrends.net/stocks/charts/AME/ametek/market-cap — retrieved 2026-05-10 — AME price $232.40 and market cap $53.26B on 2026-05-08 close.
[7] https://www.tickerreport.com/banking-finance/13431275/ametek-nyseame-reaches-new-52-week-high-still-a-buy.html — retrieved 2026-05-10 — 52-week range $170.94–$243.18; enterprise value $52.94B.
[8] https://www.stocktitan.net/news/AME/ametek-announces-record-first-quarter-2026-results-and-raises-full-jyourd1tyzgq.html — retrieved 2026-05-10 — Raised FY26 EPS guide to $7.94–$8.14; record $1.93B Q1 revenue; orders +23%; record backlog $3.87B.
[9] https://www.marketbeat.com/stocks/NYSE/AME/forecast/ — retrieved 2026-05-10 — Consensus PT ~$243–$256; short interest 2.42M shares / 1.06% of float; rating Moderate Buy.
[10] https://www.tikr.com/blog/ametek-is-up-28-in-the-last-6-months-heres-where-the-stock-could-go-in-2026 — retrieved 2026-05-10 — 6-month return ~+28%.
[11] https://investors.ametek.com/news-releases/news-release-details/ametek-completes-acquisition-paragon-medical — retrieved 2026-05-10 — Dividend $0.31/qtr per 2025 board action.
[12] https://www.asml.com/en/products/euv-lithography-systems/twinscan-exe-5200b — retrieved 2026-05-10 — ASML EXE:5200B wafer stage positioning ~¼ nm at 20 kHz, 60 EUV systems target 2026.
[13] https://investors.ametek.com/static-files/ac5652be-e9e5-460d-b2a6-7c0e6009c461 — retrieved 2026-05-10 — Indicor deal deck: $5B price, $1.1B revenue, ~50% aftermarket, 10–12% synergy target, ~2.3× leverage at close, end-market mix.
[14] https://www.themarketsdaily.com/2026/02/03/ametek-q4-earnings-call-highlights.html — retrieved 2026-05-10 — Q4 25 EIG margins 32.3%; 2025 adjusted op margin 26.2%; FCF/NI 132% Q4.
[15] https://www.morningstar.com/company-reports/1188918-ametek-continues-well-oiled-acquisition-strategy-with-paragon-purchase — retrieved 2026-05-10 — Serial-acquirer cadence, ~$292M average deal, ~14 deals 2020–24.
[16] https://heavymoatinvestments.substack.com/p/roper-technologies-quality-score — retrieved 2026-05-10 — Roper ~75% software / ~80% recurring; AME peer comparison.
[17] https://markets.financialcontent.com/stocks/article/tokenring-2026-1-23-the-great-packaging-surge-tsmc-targets-150000-cowos-wafers-to-fuel-nvidias-rubin-revolution — retrieved 2026-05-10 — TSMC targets ~150K CoWoS wafers 2026 for NVIDIA Rubin generation.
[18] https://markets.financialcontent.com/stocks/article/marketminute-2026-3-16-eaton-completes-95-billion-acquisition-of-boyd-thermal-as-ai-infrastructure-race-shifts-to-liquid-cooling — retrieved 2026-05-10 — Eaton closes $9.5B Boyd Thermal (Mar 2026); $1.7B revenue, ~90% liquid cooling; Vertiv 23% precision-cooling share.
[19] https://mezha.ua/en/news/asml-to-product-60-euv-systems-in-2026-310715/ — retrieved 2026-05-10 — ASML 60 EUV systems planned 2026, +20% YoY.
[20] https://www.tomshardware.com/tech-industry/semiconductors/intel-installs-industrys-first-commercial-high-na-euv-lithography-tool — retrieved 2026-05-10 — Intel installs first commercial High-NA EUV (EXE:5200B); 2027–28 HVM timing.
[21] https://www.ametek.com/our-stories/stories/innovation/2025/april/ametek-semiconductor-technology — retrieved 2026-05-10 — AME semi end-market context: Zygo, Taylor Hobson, Gatan, CAMECA roles; end-market mix Medical 21% / A&D 18% / Power 10% / Research 10% / Semi ~9%.
[22] https://www.tickerreport.com/banking-finance/13426886/ametek-q1-earnings-call-highlights.html — retrieved 2026-05-10 — Q1 26 EIG organic revenue +2% vs orders +25%; Abaco semi-tool win; backlog $3.87B.