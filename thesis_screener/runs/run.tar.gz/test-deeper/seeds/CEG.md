# CEG — Constellation Energy Corporation

## Where this sits in the AI stack
CEG is the **power-generation layer** underneath AI compute. It does not sell silicon, packaging, networking, software, or compute capacity. It operates ~22 GW of nuclear baseload (21 reactors at 12 sites pre-Calpine) and, after closing the $16.4B Calpine acquisition on Jan 7, 2026, ~55 GW of combined nuclear/gas/geothermal generation, predominantly in PJM, ERCOT, and CAISO [1][2][9]. The workload it serves is the only one in AI that runs 24/7 at >90% utilization with near-zero carbon: hyperscaler training and inference data centers. Its product to AI is a **20-year, firm, carbon-free electron contract** denominated in $/MWh — not a commodity grid sale.

## Snapshot
- **Price:** $303.63 (2026-05-08 close) [3]
- **Market cap:** $110.0B; Enterprise value: $115.9B [3]
- **52-week range:** ~$165–$352 (52-wk total return +13.2%, but YTD 2026 ≈ –13%) [3][14]
- **Forward P/E:** 26.1× on 2026 base-EPS guide of $11.00–$12.00 (midpoint $11.50, including ~$2 of Calpine accretion) [3][15]
- **EV / NTM revenue:** ~4.5× (TTM revenue $25.5B; pro-forma post-Calpine higher) [3]
- **Consensus 12-month price target:** $380.60 (+25% from spot); 14 buy / 1 hold / 0 sell [3][16]
- **YTD total return:** approximately –13% (well off November 2025 highs) [14]
- **Short interest (% of float):** 2.85% [3]
- **Dividend yield:** 0.56% [3]

## Moat — what it is physically made of
The moat is **physical irreplaceability**, not switching costs in software. Decompose it:

1. **22 GW of operating LWR/PWR/BWR reactors with active NRC licenses.** New US reactor construction (Vogtle 3/4) ran ~14 years and ~$35B for 2.2 GW — i.e., ~$15,900/kW vs. CEG's average book at a small fraction of that. No new conventional reactor is in the US construction queue. The replacement cost / decade-to-build asymmetry is the moat [9][17].
2. **NRC subsequent license renewal (SLR) granting 80-year operating life.** Peach Bottom Units 2/3 received SLR in Dec 2025 on a 20-month NRC turnaround — fastest yet — meaning a fleet originally licensed for 40 years now runs to roughly 2053–2054. Most CEG plants have either received or are eligible for SLR. **Caveat:** NRC has in some cases ordered new environmental reviews and reversed prior SLRs (Turkey Point case), so SLR durability is not airtight [10][18].
3. **One of only ~5 restart-eligible retired reactors in the US — and they own it.** Crane Clean Energy Center (TMI-1, 835 MW): being restarted 2027 backed by a 20-year Microsoft PPA at an estimated $98/MWh base + ~$30/MWh 45U PTC ≈ $110–$115/MWh total economics. $1.6B project, $1B DOE loan, ~80% staffed [4][19][20]. The set of plants that *could* be restarted is small: Palisades (Holtec), Duane Arnold (NextEra exploring), Pilgrim, Indian Point (effectively dismantled). CEG holds one of the few remaining options.
4. **Long-dated take-or-pay contracts from creditworthy hyperscaler counterparties.** Microsoft (Crane, 835 MW, 20-yr); Meta (Clinton, 1,121 MW + 30 MW uprate, 20-yr starting June 2027, est. ~$70/MWh per Jefferies, ~$20/MWh premium to Illinois energy+capacity) [5][6][7]. These convert merchant-volatile baseload to bond-like cashflow at premium pricing.
5. **45U production tax credit floor ≈ $43.75/MWh** (1.5 ¢/kWh with prevailing-wage 5× multiplier, inflation-adjusted) through 2032 — meaningfully above CEG's all-in cash operating cost of ~$25–30/MWh. The PTC creates an effective merchant price floor regardless of market clearing [8].
6. **Existing site permits, water rights, transmission interconnections, and PJM/ISO grid positioning.** These are unobtainable for greenfield projects in 2026–2030 in any reasonable timeframe. PJM's interconnection queue has 30 GW left just from the transition queue alone [12].
7. **Uprate optionality on existing licenses.** Byron + Braidwood: $800M for +135 MW (online 2026–2029); Clinton: +30 MW under the Meta deal. Uprates are NRC-licensable in 2–4 years vs. 10+ for new builds [21].

What is *not* a durable moat: trading, retail supply, demand-response software (gridBeyond JV), or the natural gas fleet inherited from Calpine — these compete on operations, not on physics-bounded scarcity.

## AI buildout bottleneck map
The actual gating constraints on the next 24 months of US AI capacity:

- **Power generation interconnection (PJM, ERCOT, MISO):** PJM 2026/27 BRA cleared at the **$333.44/MW-day price cap** on Dec 17, 2025, up from $28.92 two years prior — a ~11× increase. Auction came in **6,623 MW short** of the 1-in-10 reliability requirement. Data centers were $6.5B (40%) of the $16.4B in clearing costs [11][12]. **CEG = the largest single beneficiary**, since they own ~22 GW of zero-marginal-cost capacity in the constrained zone.
- **Grid transmission and substation buildouts:** ~5–7 year lead times for major upgrades. Co-location at existing plants is the workaround, but is now under reformed PJM rules (see below). **CEG is the beneficiary** (their nuclear sites are the most desirable co-location targets).
- **FERC co-location / BTMG rules:** Dec 18, 2025 FERC unanimous order directed PJM to draft three new transmission services and revise BTMG rules with new MW thresholds; PJM compliance filings due Jan 20 and Feb 16, 2026; final replies April 17, 2026 [13][22]. This is the binary regulatory event for the entire "AI-nuclear" thesis. CEG was the **original complainant** and has primary positioning to monetize whichever rule emerges.
- **HBM3e/CoWoS-L allocation, GB200/MI355 supply, optical interconnect:** **CEG is indifferent** — these are NVIDIA/AMD/TSMC/SK hynix problems, not power-generation problems. They are upstream of CEG's customer.
- **Liquid cooling at >100 kW/rack, electrical contractor capacity:** **CEG is indifferent** in the literal sense but **structurally exposed** — these constrain the *pace* at which CEG's PPAs translate to consumed electrons. PPAs are take-or-pay so revenue is largely insulated, but volume growth depends on customers actually energizing racks.
- **New nuclear capacity (SMRs):** **CEG is a beneficiary in the near term and exposed in the long term.** SMR commercial operations are 2030+ for Oklo (75 MWe), 2031+ for TerraPower (345 MW Kemmerer), 2030+ for X-energy/Amazon; NuScale's 77 MW design is NRC-certified but has no committed first plant [23][24]. Until ~2030, CEG's existing reactors are the only firm 24/7 carbon-free source at GW scale.
- **Uranium fuel cycle (enrichment, HALEU):** **CEG is exposed but not differentially.** Most SMRs need HALEU, which the US doesn't yet produce at scale. CEG's LWR fleet uses standard LEU. (Inference, not cited.)

## Competitive teardown
- **Vistra (VST):** ~6.4 GW nuclear (Comanche Peak in TX, Perry/Davis-Besse/Beaver Valley acquired via Energy Harbor). Three 20-year PPAs with Meta unlocking 2.6 GW (incl. uprates) of Ohio nuclear announced Jan 2026 [4][6]. **Parity claim:** Vistra has comparable hyperscaler traction per-MW; **dis-parity:** CEG's nuclear fleet is ~3.4× larger and capacity-factor track record is better (94.6% in 2024, 98.8% summer 2025) [9]. Vistra is more gas-weighted, so it benefits more if natural gas remains the marginal AI fuel.
- **Talen Energy (TLN):** 2.5 GW Susquehanna nuclear stake. 1,920 MW, 17-year, $18B AWS PPA — **but as a front-of-the-meter deal** after FERC twice rejected the original co-location ISA in Nov 2024 [13][25]. Talen's economics on the restructured deal are worse than a behind-the-meter would have been. **One-asset concentration risk.**
- **Public Service Enterprise Group (PSEG):** Salem/Hope Creek (NJ) ~3.5 GW nuclear; regulated utility business dilutes pure-play exposure. Slower-moving on hyperscaler PPAs.
- **NextEra (NEE):** Largest US renewables developer; ~6 GW nuclear (Seabrook, Point Beach, Turkey Point, St. Lucie, Duane Arnold restart option). More diversified, less levered to nuclear scarcity.
- **SMR developers (Oklo, NuScale, TerraPower, X-energy):** **The structural competitor that matters by 2030–2033.** Estimated SMR LCOEs need to land at $70–$95/MWh to compete with restarts [24]. Factory-built modularity is the only credible path to break CEG's site-scarcity moat. **Base rate on technology displacement:** large-scale capital-intensive infrastructure transitions (e.g., gas turbines, wind, solar) have typically taken 15–25 years from first commercial deployment to >25% market share. SMRs' first commercial unit is ~2030; double-digit grid share before 2040 is unlikely.
- **Hyperscaler-owned generation (Google/Intersect, Amazon/X-energy):** Vertical integration is the displacement risk over a 10-year horizon. But none of these reach GW-scale firm carbon-free output before 2030 [24][26].

## Bull case — technical
For CEG to outperform from $303, the following technical conditions need to hold:

1. **Hyperscaler aggregate compute capex stays at or above the current ~$600B/yr trajectory through 2027** (Goldman: data-center grid demand +22% in 2026, ~3× by 2030) [27]. The Q1 2026 earnings cycle (AMZN, META, MSFT, GOOGL) is the proximate test.
2. **PJM compliance filings (Jan 20 and Feb 16, 2026 + April 17 replies) establish a workable co-location framework** that allows CEG to sell front-of-meter to hyperscalers without triggering pro-rata transmission cost socialization. The FERC Dec 18, 2025 order was unambiguously pro-asset-owner, so the framework direction is set; execution details remain [22].
3. **CEG signs ≥2 additional GW-scale 20-year PPAs in 2026 from its disclosed 147 TWh of available nuclear capacity** [15]. Realistic candidates: Google (no nuclear PPA yet at scale), Oracle, additional Microsoft tranches.
4. **Crane Clean Energy Center hits 2027 restart milestones** (fuel-loading H2 2026, criticality early 2027). On-time delivery validates the operational thesis and the restart-call-option business model [4][19].
5. **45U PTC remains in effect through 2032** despite One Big Beautiful Bill Act amendments. Bipartisan support has held through the Trump administration (the $1B DOE loan to Crane in Nov 2025 was issued under Trump) [8][19].
6. **SMRs slip past 2031 for first commercial gigawatt** (base rate strongly favors slippage in nuclear new-build; Vogtle 3/4 slipped 7 years from initial schedule). This extends CEG's monopoly window on firm carbon-free GW-scale supply.

Financial output: $11.50 → ~$14 EPS by 2028 driven by Crane (~$0.80–$1.00 EPS), Calpine synergies, additional PPAs at $70–$110/MWh vs. ~$50/MWh PJM merchant. At a 26× multiple, $360–$390 — consistent with consensus PT.

## Bear case — technical
A short-seller who actually understands the stack would write the following:

1. **The DeepSeek pattern repeats and AI training/inference efficiency improvements compress hyperscaler power growth.** CEG fell 21% in a single day in Jan 2025 on the DeepSeek announcement and is still ~14% off November 2025 highs. The 2026 YTD decline reflects the market's reduced confidence in linear extrapolation of 2024 demand curves [28]. If algorithmic efficiency (FP4 training, MoE, speculative decoding, distillation) yields 2–4× compute-per-watt every 18–24 months, the 134 GW 2030 demand number gets revised down materially.
2. **Co-location rules end up less favorable than the Dec 2025 order signaled.** PJM has historical incentives to socialize transmission costs across all loads; the eventual compliance filing may impose materially higher cost-allocation on co-located loads, pushing pricing back toward grid alternatives. Talen's experience (forced into front-of-meter) is the cautionary tale [13].
3. **Hyperscalers contract directly with SMR developers and stop expanding existing-reactor PPAs.** Meta-Oklo (1.2 GW, 2030), Meta-TerraPower (2032), Amazon-X-energy (320 MW + expansion) signal a shift in long-duration capital allocation [23][26]. If 2030–2035 incremental nuclear PPAs accrue to SMR developers rather than incumbents, CEG's terminal value compresses.
4. **NRC reverses SLR for additional CEG plants.** The Turkey Point reversal pattern repeated across 1–2 CEG sites would compress the asset's effective duration from 80 to 60 years — a material NPV hit.
5. **Calpine integration adds gas exposure at the top of the cycle.** ~28 GW of gas in regions where capacity prices may revert, and where carbon-pricing regimes (CARB, RGGI tightening) could compress margins. The $5B LS Power divestiture removed 4.4 GW of the strongest assets [1][2].
6. **PPA price discovery surfaces lower numbers.** If 2026's marginal hyperscaler PPA prints at $60–$65/MWh rather than the implied $90–$110, the implied bull-case revenue uplift on the 147 TWh of uncontracted capacity is materially lower.
7. **Valuation already prices the thesis.** At 26× forward, CEG trades at 1.6× the regulated utility average (~16×). A merchant generator historically trades 8–14× — the multiple already capitalizes the AI thesis. Two consecutive guidance disappointments unwind the re-rating fast.

Base rate context: electric utility multiple re-ratings of >2× have historically lasted 2–4 years before mean-reverting (post-deregulation 1998–2001, renewables darlings 2020–2021). CEG's re-rating began Sept 2024 with the Microsoft deal — clock is at ~20 months.

## Market view check
Spot $303 against $380.60 consensus PT and 26× forward P/E reflects a market that **already believes the thesis but has trimmed conviction**. The –13% YTD vs. flat S&P signals the market is pricing in (a) ongoing DeepSeek/efficiency overhang, (b) Calpine integration execution risk, and (c) regulatory uncertainty around the FERC compliance filings. The mispricing direction depends on which way the next 90 days resolve: a clean PJM compliance framework + a new hyperscaler PPA + stable hyperscaler capex guidance reprices toward $380+. The opposite combination compresses to $230–$250. The technical reality I described — physically scarce 24/7 carbon-free GW-scale firm power, with an effective PTC floor and 20-year contract demand — is consistent with the upside scenario, but the bear case is not trivially defeated and the multiple offers thin margin of safety.

## 90-day falsifiers
Specific, observable, datable events:

1. **Q1 2026 earnings call, May 11, 2026.** Watch for: (a) any reaffirmation/raise of $11–$12 base EPS guide; (b) named new hyperscaler PPA, especially Google or Oracle; (c) update on 147 TWh available capacity disclosure; (d) Crane restart milestones (steam generator status, fuel availability).
2. **Hyperscaler Q1 2026 capex commentary (AMZN, GOOGL, META, MSFT).** A >10% sequential cut in any one of these is a material thesis update. A reaffirm-and-raise pattern is the bullish setup.
3. **PJM April 17, 2026 reply filings on FERC compliance framework.** The shape of net-load-withdrawal rules and BTMG MW thresholds will be observable from the filings themselves.
4. **NRC actions on outstanding SLR applications** (LaSalle, Dresden, Limerick in CEG queue).
5. **Crane Clean Energy Center mid-2026 milestones:** first DOE loan tranche drawn (Q1 2026 was scheduled); main turbine refurbishment status; staff to >90%.
6. **PJM 2027/28 base residual auction outcome** (expected mid-2026): a second consecutive auction at the price cap confirms the structural shortage; a clearing well below the cap is a thesis-breaker.
7. **Any FERC SLR reversal or new environmental review order for a CEG plant.** Watch for filings against LaSalle, Limerick, or Dresden in particular.
8. **Direct SMR commercial milestone (Oklo, TerraPower, NuScale).** A meaningful slippage of any 2030–2031 first-unit COD date is bullish for CEG; an accelerated milestone is bearish.

## What I could not verify
- Exact $/MWh in the Microsoft Crane PPA (the $98 base + $30 PTC = $128 figure is a Morgan Stanley **estimate**; CEG has not disclosed the contract price). The $110–$115 blended number is widely cited but is also analyst-derived [20].
- Whether the One Big Beautiful Bill Act July 2025 amendments to 45U materially altered the prevailing-wage 5× multiplier formula — sources mention amendments but I did not find the specific subsection text [8].
- The actual capacity allocation across CEG's reactors of the 147 TWh "available" disclosure — i.e., which reactors are uncontracted vs. contracted under legacy ZEC programs.
- Calpine integration cost synergies vs. the $2 accretion claim — I have the guide but not a fully bottoms-up reconciliation against gas asset divestiture impact.
- Specific terms of any Crane DOE loan covenants that could limit dividend/buyback capacity.
- Whether any CEG NRC SLR application is currently subject to ordered re-review (analogous to Turkey Point). The Peach Bottom case suggests not, but I did not enumerate every site's SLR docket status.
- Independent technical assessment of SMR LCOE landing points — the $70–$95 figure is from industry sources, not from a DOE/EIA cost-build.

## Sources
[1] https://www.utilitydive.com/news/ferc-constellation-energy-calpine-pjm/753918/ — retrieved 2026-05-10 — FERC approval and PJM divestiture terms for Constellation-Calpine merger.
[2] https://www.powermag.com/constellation-completes-acquisition-of-calpine-groups-have-55-gw-of-generation-capacity-2/ — retrieved 2026-05-10 — Calpine close confirms 55 GW combined portfolio and ERCOT/CAISO/PJM footprint.
[3] https://stockanalysis.com/stocks/ceg/statistics/ — retrieved 2026-05-10 — Price, market cap, EV, forward P/E, EV/revenue, short interest, consensus PT as of 2026-05-08 close.
[4] https://www.utilitydive.com/news/constellation-three-mile-island-nuclear-power-plant-microsoft-data-center-ppa/727652/ — retrieved 2026-05-10 — Microsoft 20-yr PPA, 835 MW, Crane Clean Energy Center restart.
[5] https://www.utilitydive.com/news/meta-constellation-illinois-clinton-nuclear-ppa-support-ai-goals/749992/ — retrieved 2026-05-10 — Meta-Clinton 20-yr PPA, 1,121 MW, June 2027 start.
[6] https://www.utilitydive.com/news/meta-constellation-ppa-could-be-first-of-many-deals-for-existing-reactors/ — retrieved 2026-05-10 — Jefferies estimate of $70/MWh Meta-Clinton, premium to PJM energy+capacity.
[7] https://www.constellationenergy.com/newsroom/2025/constellation-meta-sign-20-year-deal-for-clean-reliable-nuclear-energy-in-illinois.html — retrieved 2026-05-10 — Constellation press release confirming Clinton 30 MW uprate and Meta deal scope.
[8] https://www.irs.gov/credits-deductions/zero-emission-nuclear-power-production-credit — retrieved 2026-05-10 — IRC 45U structure: 0.3 ¢/kWh base, up to 5× with prevailing wage, through 2032.
[9] https://www.constellationenergy.com/newsroom/2025/09/constellations-clean-energy-centers-deliver-near-perfect-summer-reliability.html — retrieved 2026-05-10 — 21-reactor fleet, 94.6% 2024 capacity factor, 98.8% summer 2025.
[10] https://www.ans.org/news/article-5/nrc-issues-subsequent-license-renewals/ — retrieved 2026-05-10 — Peach Bottom SLR Dec 2025 20-month turnaround; NRC reversal pattern at Turkey Point.
[11] https://www.utilitydive.com/news/pjm-interconnection-capacity-auction-data-center/808264/ — retrieved 2026-05-10 — PJM 2026/27 BRA cleared at $333.44/MW-day price cap, 6,623 MW short of reliability requirement.
[12] https://www.utilitydive.com/news/data-centers-pjm-capacity-auction/808951/ — retrieved 2026-05-10 — Data centers = $6.5B of $16.4B (40%) of capacity auction costs; 30 GW left in transition queue.
[13] https://www.utilitydive.com/news/ferc-interconnection-isa-talen-amazon-data-center-susquehanna-exelon/731841/ — retrieved 2026-05-10 — FERC Nov 2024 rejection of Talen-AWS Susquehanna ISA, forcing Talen to front-of-meter restructure.
[14] https://www.tikr.com/blog/constellation-energy-stock-is-down-13-in-2026-what-the-q1-2026-earnings-must-show — retrieved 2026-05-10 — YTD 2026 –13% performance context for Q1 earnings.
[15] https://www.constellationenergy.com/news/2026/02/constellation-reports-fourth-quarter-and-full-year-2025-results.html — retrieved 2026-05-10 — Q4 2025 EPS $2.30 adj, 2026 guide $11–$12 (incl. ~$2 Calpine), 147 TWh capacity disclosure.
[16] https://stockanalysis.com/stocks/ceg/forecast/ — retrieved 2026-05-10 — 14 buy / 1 hold / 0 sell, average PT $380.60 (+25%).
[17] https://www.powermag.com/subsequent-license-renewal-extending-nuclear-power-reactors-to-80-years-of-operation-and-maybe-more/ — retrieved 2026-05-10 — NRC SLR framework, 60→80 year extension regulatory basis.
[18] https://www.hoganlovells.com/en/publications/nrc-ordered-new-environmental-reviews-for-subsequent-license-renewals-reversing-approved-extensions — retrieved 2026-05-10 — NRC reversal pattern (Turkey Point, Peach Bottom) and environmental review risk.
[19] https://www.cnbc.com/2025/11/18/trump-nuclear-three-mile-island-crane-loan-constellation-ceg.html — retrieved 2026-05-10 — $1B DOE loan to Crane, 2027 restart timeline, Trump administration backing.
[20] https://markets.financialcontent.com/wral/article/tokenring-2026-1-1-the-nuclear-option-microsoft-and-constellation-energys-resurrection-of-three-mile-island-signals-a-new-era-for-ai-infrastructure — retrieved 2026-05-10 — Morgan Stanley estimate $98/MWh base + ~$30 PTC for Crane economics; estimate not confirmed.
[21] https://www.nucnet.org/news/constellation-to-invest-usd800-million-in-braidwood-and-byron-nuclear-station-uprates-2-3-2023 — retrieved 2026-05-10 — $800M Byron+Braidwood uprate program for +135 MW, 2026–2029 phased completion.
[22] https://www.ferc.gov/news-events/news/fact-sheet-ferc-directs-nations-largest-grid-operator-create-new-rules-embrace — retrieved 2026-05-10 — FERC Dec 18, 2025 co-location order — three new transmission services, BTMG threshold, compliance dates.
[23] https://dnyuz.com/2026/02/07/next-gen-nuclears-tipping-point-meta-and-hyperscalers-start-deals-with-bill-gates-terrapower-sam-altman-backed-oklo-and-more/ — retrieved 2026-05-10 — Meta-Oklo 1.2 GW 2030, Meta-TerraPower 2032 deals confirm SMR threat horizon.
[24] https://world-nuclear.org/information-library/nuclear-power-reactors/small-modular-reactors/small-modular-reactors — retrieved 2026-05-10 — SMR design status, NuScale 77 MW NRC certification, TerraPower Kemmerer 345 MW 2031 COD, LCOE ranges.
[25] https://enkiai.com/nuclear/aws-data-center-talen-energy/ — retrieved 2026-05-10 — Talen-AWS 1,920 MW, 17-year, $18B restructured PPA terms.
[26] https://introl.com/blog/google-intersect-power-acquisition-energy-vertical-integration-january-2026 — retrieved 2026-05-10 — Hyperscaler vertical integration into generation (Google-Intersect).
[27] https://www.spglobal.com/energy/en/news-research/latest-news/electric-power/101425-data-center-grid-power-demand-to-rise-22-in-2025-nearly-triple-by-2030 — retrieved 2026-05-10 — Data center grid-power +22% in 2025, nearly 3× by 2030 (S&P/Goldman forecast).
[28] https://finance.yahoo.com/news/constellation-energy-corporation-ceg-plunges-014008975.html — retrieved 2026-05-10 — DeepSeek selloff: CEG –21% single-day, Jefferies warning on AI power demand thesis.