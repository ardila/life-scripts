# CARR — Carrier Global Corporation

## Where this sits in the AI stack
Carrier sits at the **facility-thermal layer** of the AI buildout: the row of equipment between the white-space wall and the rack manifold. Specifically, it sells (a) high-capacity centrifugal water chillers (AquaEdge 19MV4 at 2.1–3.3 MW; AquaEdge 30CF air-cooled), (b) coolant distribution units (CDUs) bridging a building chilled-water loop to the technology cooling system (TCS) loop running through cold plates on GPUs, (c) computer-room air handlers (CRAH), and (d) the BMS/DCIM software wrap (Nlyte, building controls) bundled as the "QuantumLeap" suite [1][2][3][9]. It does **not** sell the cold plate, the manifold, or the in-rack plumbing in scale — that interface is owned by the IT-OEM (Supermicro, Dell) and the cold-plate specialists (CoolIT, Motivair, ZutaCore, Asetek). Carrier is workload-agnostic — it cools a hyperscaler's training cluster the same way it cools a colo's inference fleet — but the AI-driven $1.5B 2026 DC revenue line it now guides to is overwhelmingly tied to liquid-ready new-build hyperscale and colo capacity for ≥120 kW/rack GB200/GB300-class racks [3][4].

## Snapshot
- **Price:** $67.03 (2026-05-08 close; May 10 was a Sunday) [5]
- **Market cap:** $55.5B (830.6M shares × $67.03) [5][6]
- **52-week range:** $50.24 – $81.09 [5]
- **Forward P/E:** 23.9× (on FY26 consensus EPS $2.80) [7]
- **EV / NTM revenue:** ~3.0× ($55.5B equity + $10.79B net debt = $66.3B EV / $22B FY26 sales) [6][8]
- **Consensus 12-month price target:** $71.37 average / $75.00 median (implied +6%–12% from price) [7]
- **YTD total return:** +25.6% (price-only basis from end-2025) [10]
- **Short interest (% of float):** ~2.3% (Jan 30, 2026 filing) [11]
- Dividend yield: 1.41% forward [6]

## Moat — what it is physically made of
**Decompose this honestly. Carrier's "AI" moat and its core moat are different things.**

**1. Centrifugal chiller manufacturing & service base (durable).** Carrier's actual structural advantage is that it makes large positive-displacement and centrifugal chillers — including the EquiDrive two-stage centrifugal that modulates 10%–100% load, important for AI clusters that swing between idle and full-batch — through a mature TSA-aligned manufacturing footprint with a 100-year installed base and ~$8B of recurring service/aftermarket revenue across the company [2][9]. Replicating a 3 MW magnetic-bearing variable-speed chiller line is a 5–7 year, multi-hundred-million-dollar capex problem, and the AHRI certification + UL listings are genuine barriers. **This piece is real but is shared with Trane, Johnson Controls, and Daikin** — none of whom can be displaced quickly either. It is not a technology moat against competitors; it is a moat against new entrants.

**2. CDU and direct-to-chip stack (weak — and recently weakened).** Carrier's CDU lineup is *behind* the field on capacity and timing: they ship 1 MW today, 3 MW around Q3 2026, 5 MW "late 2026 or early 2027" [3]. For comparison, **Trane already ships CDUs from 2.5 MW to 10 MW** [12], **Schneider's Motivair line scales 105 kW to 2.5 MW today and is NVIDIA-certified, with Motivair powering 6 of the world's top 10 supercomputers** [13], and DCX has announced an 8.15 MW facility-scale CDU for 45 °C warm-water operation [14]. Carrier covered the cold-plate/server-side gap via **Carrier Ventures' April 2024 minority investment in Strategic Thermal Labs (STL)**[15] — but **Vertiv outright acquired STL on April 27, 2026**[16][17], converting Carrier's option into a Vertiv asset. Carrier's other named cold-plate partner, ZutaCore (two-phase dielectric, waterless), is technically interesting but is a niche architecture not yet adopted at hyperscale reference scale [18][19]; the April 2026 follow-on funding round is a tell that ZutaCore needed capital, not that Carrier locked exclusivity [19].

**3. QuantumLeap "chip-to-chiller" software wrap.** This is a real but modest asset. Nlyte (DCIM, acquired 2021) plus Carrier building controls plus a digital-twin overlay produce an integrated bid that matters in colo RFPs that price by total facility PUE rather than line-item BOM. They claim ~$300–400M of orders attributable to QuantumLeap [3]. **It is not a technical moat** — Vertiv's Trellis/Avocent and Schneider's EcoStruxure DCIM stacks are at least at parity, and many hyperscalers run their own DCIM internally and won't pay for a vendor wrap.

**4. Viessmann (acquired Jan 2024 for $13.1B)** [20]. Worth flagging as a non-AI moat asset: Europe heat-pump leadership, large but separate from the data-center thesis. Materially raised leverage and complicates the AI-narrative read of the multiple.

**Net:** Carrier's moat in AI cooling is meaningfully shallower than the "chip to chiller" marketing implies. Its durable moat is in the chiller half of the stack, where it shares the field with three other capable incumbents. On the side that's actually being repriced — CDUs and direct-to-chip — Carrier is technically behind Vertiv/Schneider/Trane and just had its bench-strength VC bet (STL) bought out from under it.

## AI buildout bottleneck map
Ordered roughly by how acute each constraint is over the next 24 months:

- **Power generation / gas turbines.** GE Vernova quoting 2028+ for new heavy-duty units; average gas-turbine lead time has risen from ~2 yr (2021) to nearly 5 yr; large transformers at 120–210 weeks; ~12 GW of planned 2026 US data-center capacity is delayed or canceled for power [21][22]. **CARR position: indifferent-to-mildly-exposed.** Carrier doesn't sell turbines, but a project that can't get power doesn't buy chillers either. Net: this bottleneck *slows the addressable market growth* for cooling, i.e., the wall on the cooling TAM is not infinite.
- **CoWoS-L advanced packaging.** TSMC scaling from ~35 kwpm late-2024 to ~130 kwpm end-2026; NVIDIA has booked >50% [23]. **CARR position: indifferent.** Tightness here changes who ships the GPUs, not whether they need cooling.
- **HBM3e/HBM4 supply.** Tight, three-supplier oligopoly. **CARR position: indifferent.**
- **Liquid cooling at >100 kW/rack — CDUs, manifolds, cold plates, quick-disconnects.** This is where CARR is exposed. **GB200 NVL72 = 120 kW/rack continuous, mandatory liquid, ~80 LPM/GPU, requiring CDUs sized 750–800 LPM with headroom** [24][25]. The CDU market is the thinnest part of the cooling supply chain — Dell'Oro and MarketsandMarkets put it at ~$2.5B in 2026 growing to ~$7.4B by 2034, with Vertiv/Schneider/nVent as named leaders [26]. **CARR position: late entrant — supplier with sub-scale share.**
- **Large air-cooled / water-cooled chillers >2 MW with high-T condenser operation.** This is CARR's strongest position. Liquid cooling does not eliminate chillers; it pushes them to warm-water (W32/W40/W45) operation, which actually plays to Carrier's variable-speed magnetic-bearing AquaEdge 19MV4 spec (chilled-water up to 35 °C, condensing up to 55 °C) [2]. **CARR position: beneficiary, with Trane/JCI/Daikin in the same lane.**
- **Electrical contractors & skilled mechanical labor.** The dirty bottleneck nobody talks about. Affects all cooling vendors equally. **CARR position: indifferent.**

## Competitive teardown
The relevant comp set is **Vertiv (VRT), Schneider Electric (SU.PA), Trane Technologies (TT), Johnson Controls (JCI), Daikin, STULZ, nVent, and the cold-plate specialists Motivair (now Schneider), CoolIT, Asetek, ZutaCore.**

- **Vertiv (the relevant comp).** ~18% global cooling share [26]; $15B+ backlog vs. CARR's "fully covered $1.5B" 2026 DC plan [27][3]; ~80% data-center revenue concentration vs. CARR's ~7% [27][4]; co-developed reference architecture for GB200 NVL72 with NVIDIA [28]; April 2026 acquisition of STL closes the cold-plate/server-side gap and converts what was a Carrier venture stake into a Vertiv-owned capability [16]. **Verdict: Vertiv is ahead on every axis that matters for the AI repricing — backlog, CDU portfolio depth, NVIDIA reference position, and cold-plate IP.** What would have to be true for CARR to take share from VRT: a GB300/Rubin-era pivot toward warm-water facility chillers (CARR's strength) at the expense of in-rack heat exchange — possible, not base case.
- **Schneider Electric + Motivair.** Motivair is the only named cold-plate specialist that has demonstrated NVIDIA silicon-level co-development and 6 of top-10 supercomputer references [13]. Combined with Schneider's UPS + EcoStruxure DCIM + ETAP grid software, this is the most complete "chip-to-grid" stack in the industry. **CARR's QuantumLeap is the same pitch with weaker components.**
- **Trane Technologies.** CDUs already at 2.5–10 MW (CARR is at 1 MW, ramping to 5 MW only late 2026/early 2027) [12][3]; 850-ton magnetic-bearing chillers; acquired Stellar Energy Digital for liquid-to-chip; partnered with NVIDIA. **Trane is technically ahead of Carrier on CDU capacity timing** — a durable embarrassment given Trane is also primarily a chiller company.
- **Johnson Controls.** Major chiller incumbent, weaker on liquid cooling. Roughly at parity with CARR on facility cooling but less aggressive on the "AI factory" positioning.
- **Daikin / STULZ / nVent / Rittal.** Top-7 collectively hold 67% of cooling market [29]; STULZ strong in CRAH/CRAC, Daikin strong globally in chillers. Each plausibly takes a slice; none is the swing factor.

**The honest picture: Carrier is roughly 4th–5th in the AI cooling pecking order on technical depth (Vertiv > Schneider/Motivair > Trane > Carrier ≈ JCI), but it is differentiated upstream by Viessmann's heat-pump exposure and downstream by service network density.** The "fivefold orders" headline is real but reflects a small base lapping; CARR is participating in the AI cooling boom, not leading it.

## Bull case — technical
The bull case requires **all of the following** to hold:
1. **Hyperscaler new-build cadence stays at or above 2026 pace through 2028.** The cooling TAM is gated by power; if turbines/transformers/grid keep delivering 35–50 GW/yr of new capacity globally [21][22], chiller and CDU demand stays >40% YoY through at least 2027.
2. **Warm-water (W32–W45) facility chiller designs win out over chilled-water-less / dry-cooler-only designs.** This favors Carrier's AquaEdge 19MV4 and 30CF [2][3]. The base rate here is favorable: hyperscalers in temperate climates increasingly want some compressor-based capacity for redundancy and turn-down, even with liquid cooling.
3. **Carrier closes the CDU capacity gap on schedule** — 3 MW Q3 2026, 5 MW late-2026/early-2027 [3]. If they ship on time and at price parity with Vertiv/Trane, they hold their ~10–15% share of greenfield project specs.
4. **The QuantumLeap integrated bid wins meaningful colo / Tier-2 hyperscale RFPs** where the buyer values single-vendor accountability over best-of-breed component selection. $300–400M YTD orders against a multi-billion addressable RFP pipeline implies ~10% win rate; needs to hold or rise.
5. **No further share defections to Vertiv/Schneider/Trane** beyond the STL loss.

If those hold: data-center revenue ramps from $1.5B (2026) to ~$3–4B by 2028, contributing 200–400 bps of incremental top-line growth and modest mix-up on margin (DC commercial HVAC is higher gross margin than residential). FY28 EPS of $3.65 (consensus) [7] is achievable; multiple expands from 24× to 26–28× as the market accepts CARR as a "data-center cooling story" rather than a "residential HVAC cyclical." Implied price: high $90s.

**Base rate caveat on technology displacement at this stage of the cycle.** Look at 2018–2021 cloud capex: hardware vendors who entered late but with credible portfolios (e.g., Dell in cloud servers vs. Supermicro) generally got share commensurate with their existing customer relationships — not zero, not parity. Applied here: CARR likely retains 60–80% of its existing chiller share at hyperscale customers it already sells residential/commercial HVAC to, but takes only 10–25% of CDU/cold-plate share against Vertiv/Schneider/Trane who have head starts. This is a "modestly winning" outcome, not a "winning the AI buildout" outcome.

## Bear case — technical
The short-seller version, written honestly:

1. **The cooling stack bifurcates into "facility chiller (commodity)" and "in-rack thermal (specialized)," and Carrier is on the wrong side.** Hyperscalers with >300 MW campuses are increasingly buying chillers as commoditized capex line items at 8–12% gross margin while paying premium price for in-rack CDUs/cold plates from specialists. Carrier participates in the commodity half. This is consistent with what Vertiv's 22%+ adjusted operating margin vs. Carrier's segment margins implies [27][8].
2. **The Vertiv-STL deal in April 2026 is a leading indicator.** Carrier had a 2-year head start as a Carrier Ventures investor and could not convert it into an acquisition or technology transfer; Vertiv simply bought the asset [15][16]. This says something about Carrier's data-center M&A muscle. Expect more of these — Asetek, CoolIT, JetCool — to be picked off by Vertiv/Schneider before Carrier moves.
3. **GB300 / Rubin-era thermal architectures may bypass facility chillers entirely.** If hyperscalers go to warm-water dry-cooler-only designs (free cooling, no compressor) in the dominant climates — the design DCX is implementing [14] — then Carrier's strongest moat (centrifugal chillers) becomes optional rather than required. This is the Microsoft Phoenix and Meta Mesa pattern. Probability: meaningful but not majority over 24 months; over 5 years, plausible base case in regions north of 35° latitude.
4. **The 500% data-center order growth lapped a tiny base.** Q1 2026 DC orders against a ~$200M/quarter run rate in Q1 2025 imply ~$1B of single-quarter orders — but the 2026 revenue plan is only $1.5B and the 2027 plan presumably $2.5–3B. The order surge is **catch-up to a backlog already covered**, not a step-change in run-rate, and the company explicitly said "still capacity to take additional orders" [3] — translation: order momentum may decelerate sharply in 2H26 as the slot-booking rush ends.
5. **Residential HVAC drag is real and lasting.** Units down 10–15% in 2026 [8]; the SEER2 / refrigerant transition bump has run; rate-cycle relief is uncertain. The DC story has to *more than offset* a ~$1B–$1.5B residential top-line headwind to drive consensus EPS, which may not happen.
6. **Viessmann goodwill risk.** $13.1B paid in early 2024 for a heat-pump franchise into a European demand softness; any impairment would be ugly relative to a $55B market cap. Not a 90-day risk but a tail.

Combined bear: organic growth 0–2% rather than mid-single, EPS lands at $2.65 vs. $2.80 consensus, multiple compresses to 18–20× as the AI bull narrative deflates. Implied price: low-to-mid $50s — i.e., back to the 52-week low.

## Market view check
At $67 / 23.9× FY26 EPS / 3.0× EV/sales, **Carrier is priced as a high-quality industrial with optionality on data center** — not as a pure AI infrastructure name. For comparison, Vertiv trades roughly 30–35× forward EPS reflecting ~80% DC revenue concentration. Schneider Electric trades ~25× on a more diversified mix. Trane trades ~28×. Carrier's 24× sits *between* the diversified industrials and the pure-plays, which is roughly correct given its ~7% DC revenue mix. The gap to consensus PT ($71) is +6% — implying the sell-side already accepts the bull case in part. **Our read:** the price is approximately consistent with the technical reality. The market is implicitly *not* believing Carrier becomes a Vertiv-tier AI cooling pure-play; it is believing Carrier participates as a #4–#5 vendor with a service-rich tail. We agree with that read. The mispricing, if any, is in the tails — a Vertiv-style bull repricing requires evidence of CDU share wins that doesn't yet exist; a bear de-rating requires either a residential collapse or an explicit hyperscaler standardization on a competitor stack.

## 90-day falsifiers
Specific events between now (May 10, 2026) and August 10, 2026:

- **Q2 2026 print (~late July).** Watch (a) data-center *orders* growth ex-base-effect — if it normalizes below 100% YoY, the "5×" narrative deflates; (b) data-center *revenue* run-rate — needs to be >$350M in Q2 to track $1.5B FY guide given the 2H weighting [3]; (c) commercial HVAC organic growth ex-DC — if this is <5%, the broader thesis weakens.
- **3 MW CDU shipping disclosure.** Carrier has guided 3 MW CDU availability "around Q3" [3]. A press release or product page update by August confirms execution; a slip to Q4 is a material credibility hit relative to Trane (already shipping 2.5–10 MW).
- **Vertiv Q2 print and any further M&A.** If Vertiv announces backlog >$17B and/or another cold-plate acquisition (Asetek, CoolIT), Carrier's competitive position is materially worse.
- **Schneider Electric H1 print (~early August)** — look for Motivair revenue contribution disclosure and any NVIDIA co-developed reference design announcements.
- **Hyperscaler capex guidance at Q2 (Microsoft, Meta, Google, Amazon — late July).** A >10% sequential cut in any one of the four cuts the cooling TAM materially; a re-acceleration confirms it.
- **NVIDIA GTC Fall (October — outside the 90-day window but watch for previews).** Any reference architecture for Rubin / R200-class racks specifying named cooling vendors will move all four stocks.

## What I could not verify
- Carrier's actual share of GB200 NVL72 deployments to date (no hyperscaler has disclosed cooling vendor splits at rack count).
- Whether QuantumLeap's $300–400M order base is incremental DC orders or a re-bundling of orders that would have been placed line-item — i.e., the marketing claim is real but its TAM-expansion claim is unverified.
- Specific gross margin of Carrier's data-center segment vs. legacy commercial HVAC (the company has not disclosed segment-level gross margin for data center separately).
- Whether the ZutaCore investment carries any exclusivity or right-of-first-refusal terms (deal terms not public).
- Float-precise short interest as of the most recent settlement (used a Jan 30 reading; more recent data not located in search).
- The exact magnitude of the 2H26 ramp in DC revenue — management referenced a "ramp" without quantifying the Q3/Q4 split.
- Carrier's CDU manufacturing capacity ceiling (no published kw/yr figure).
- Whether the divestiture proceeds (>$10B) have been fully redeployed; net-debt is still elevated which suggests partly to Viessmann leverage paydown rather than DC capex.

## Sources
[1] https://www.carrier.com/commercial/en/us/news/news-article/carrier-introduces-aquaedge--30cf-chiller-to-enhance-data-center-reliability-and-uptime.html — retrieved 2026-05-10 — Carrier AquaEdge 30CF air-cooled chiller for data centers, late-Feb 2026 launch
[2] https://www.coolingpost.com/products/aquaedge-chiller-for-data-centres/ — retrieved 2026-05-10 — AquaEdge 19MV4 specs: 2.1–3.3 MW, 35 °C chilled water, 55 °C condensing, EquiDrive 10–100% modulation
[3] https://www.fool.com/earnings/call-transcripts/2026/04/30/carrier-carr-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q1 2026 earnings call: DC orders +500%, $1.5B 2026 DC revenue plan fully covered, CDU roadmap 1→3→5 MW, QuantumLeap $300–400M orders
[4] https://247wallst.com/investing/2026/03/04/carrier-ceo-north-american-data-center-orders-surged-400-in-q4/ — retrieved 2026-05-10 — Q4 2025 NA DC orders +400%, $1B 2025 DC revenue, $1.5B 2026 plan
[5] https://www.investing.com/equities/carrier-global-corp — retrieved 2026-05-10 — CARR price $67.03, 52-week range $50.24–$81.09
[6] https://stockanalysis.com/stocks/carr/statistics/ — retrieved 2026-05-10 — Shares outstanding 830.58M, market cap ~$55.5B, dividend yield 1.41%
[7] https://www.tikr.com/blog/carrier-globals-71-street-target-vs-a-55-stock-price-what-the-gap-says-about-carr-in-2026 — retrieved 2026-05-10 — Consensus PT $71.37, FY26 EPS $2.80, FY27 $3.17, FY28 $3.65
[8] https://www.carrier.com/us/en/news/carrierreports-2025-results-and-announces-2026-outlook/ — retrieved 2026-05-10 — FY26 guidance: $22B sales, $3.4B adj op profit, $2B FCF, $2.80 adj EPS, residential units -10/-15%
[9] https://www.carrier.com/commercial/en/eu/lps/carrier-cdu/ — retrieved 2026-05-10 — Carrier CDU product page within QuantumLeap suite
[10] https://www.financecharts.com/stocks/CARR/performance/total-return — retrieved 2026-05-10 — CARR YTD 2026 price return +25.6%
[11] https://www.tickerreport.com/banking-finance/13348290/carrier-global-corporation-nysecarr-short-interest-update.html — retrieved 2026-05-10 — Jan 30 short interest 17.97M shares, ~2.3% of float
[12] https://www.datacenterfrontier.com/cooling/article/55298248/tranes-thermal-management-overhaul-modular-cooling-platforms-for-ai-driven-data-center-demands — retrieved 2026-05-10 — Trane CDUs 2.5–10 MW, 850-ton magnetic-bearing chillers, NVIDIA partnership
[13] https://www.motivaircorp.com/news/schneider-electric-unveils-liquid-cooling-portfolio/ — retrieved 2026-05-10 — Motivair CDU 105 kW–2.5 MW, NVIDIA-certified, in 6 of top-10 supercomputers
[14] https://thedatacenterengineer.com/news/dcx-announces-8-15-mw-facility-scale-cdu-for-45-c-warm-water-ai-data-center-cooling/ — retrieved 2026-05-10 — DCX 8.15 MW CDU at 45 °C warm-water operation, evidence of dry-cooler-only architecture trend
[15] https://www.corporate.carrier.com/news/news-articles/202404_carrier-ventures-announces-investment-strategic-thermal-labs-for-development-groundbreaking-data-center-cooling-technology.html — retrieved 2026-05-10 — Carrier Ventures invested in STL April 2024
[16] https://www.vertiv.com/en-us/about/news-and-events/corporate-news/2026/vertiv-strengthens-liquid-cooling-system-capability-with-acquisition-of-strategic-thermal-labs/ — retrieved 2026-05-10 — Vertiv acquired STL April 27, 2026 — Carrier's venture stake exits to a competitor
[17] https://datacenterrichness.substack.com/p/vertiv-acquires-strategic-thermal — retrieved 2026-05-10 — Independent commentary on Vertiv-STL strategic implications
[18] https://zutacore.com/ — retrieved 2026-05-10 — ZutaCore HyperCool two-phase waterless DLC architecture
[19] https://www.carrier.com/us/en/news/carrierventures-expands-investment-in-zutacore-to-scale-liquid-cooling-for-ai-data-centers/ — retrieved 2026-05-10 — Carrier Ventures expanded ZutaCore investment April 29, 2026
[20] https://www.corporate.carrier.com/news/news-articles/carrier-completes-acquisition-of-viessmann-climate-solutions.html — retrieved 2026-05-10 — Viessmann Climate Solutions acquired Jan 2, 2024 for $13.1B
[21] https://www.tomshardware.com/tech-industry/turbine-shortage-threatens-ai-datacenters-as-wait-times-stretch-into-2030 — retrieved 2026-05-10 — Gas turbine lead times 5+ years; 12 GW of 2026 US DC capacity delayed/canceled
[22] https://www.useluminix.com/reports/industry-analysis/powering-the-ai-boom-where-the-grid-breaks-first-2026-2030 — retrieved 2026-05-10 — Transformer lead times 120–210 weeks, +79% price; 2026–2030 grid demand forecast
[23] https://www.digitimes.com/news/a20251210PD218/tsmc-cowos-capacity-nvidia-equipment.html — retrieved 2026-05-10 — TSMC CoWoS scaling to 130 kwpm by end-2026; NVIDIA booking >50% for 2026–27
[24] https://introl.com/blog/gb200-nvl72-deployment-72-gpu-liquid-cooled — retrieved 2026-05-10 — GB200 NVL72 thermal: 120 kW continuous rack, 700+ LPM manifold, CDU sizing 750–800 LPM
[25] https://tonecooling.com/nvidia-gb200-nvl72-cooling-requirements/ — retrieved 2026-05-10 — NVIDIA cooling specs: 20–25 °C inlet, 80 LPM, 1.5 bar pressure drop
[26] https://www.fortunebusinessinsights.com/coolant-distribution-units-market-115841 — retrieved 2026-05-10 — CDU market $2.5B (2026) → $7.4B (2034); Vertiv/Schneider/nVent leadership
[27] https://markets.financialcontent.com/wral/article/predictstreet-2026-1-2-the-cooling-heart-of-the-ai-era-a-deep-dive-into-vertiv-holdings-vrt — retrieved 2026-05-10 — Vertiv $15B+ backlog, 80%+ DC revenue concentration, 22.3% adj op margin
[28] https://www.vertiv.com/en-emea/about/news-and-insights/news-releases/vertiv-codevelops-with-nvidia-complete-power-and-cooling-blueprint-for--nvidia-gb200-nvl72-platform/ — retrieved 2026-05-10 — Vertiv co-developed reference architecture with NVIDIA for GB200 NVL72
[29] https://www.fortunebusinessinsights.com/industry-reports/data-center-cooling-market-101959 — retrieved 2026-05-10 — Top 7 cooling vendors held 67% of market in 2025; Vertiv 18.1% leader