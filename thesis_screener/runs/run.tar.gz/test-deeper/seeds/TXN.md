# TXN — Texas Instruments Incorporated

## Where this sits in the AI stack
TXN sells analog ICs and embedded processors. In AI specifically, they sit at the **chip-level and board-level power management layer** — hot-swap eFuses, multiphase voltage regulators, isolated gate drivers, integrated GaN power stages, isolated bias supplies, current/Hall sensors, ADCs for telemetry — that take the rack-level DC bus and deliver clean low-voltage power to the GPU and HBM. They do not make compute silicon, packaging, HBM, networking ASICs, or optics. AI exposure is roughly 10–11% of revenue: data center was $1.5B FY25 (~9% of company), exited Q4 25 at ~$450M/quarter run-rate, and grew ~90% YoY in Q1 26 [3][2]. The remaining ~90% of the business is industrial and automotive analog.

## Snapshot
- **Price:** $287.15 (2026-05-10 close) [1]
- **Market cap:** ~$260B [1]
- **52-week range:** ~$143 – ~$292 (rally-driven; sources reflect a $143–$231 range from before the recent leg up, current spot above that) [1][16]
- **Forward P/E:** ~36× on 2026 consensus EPS of ~$8 [15]
- **EV / NTM revenue:** ~12× (on ~$21B 2026 consensus) [15]
- **Consensus 12-month price target:** $265 (implied **−8%** from spot) — Stifel $290, UBS $295, low $180, high $330 [15]
- **YTD total return:** +28%; trailing 12-month +72% [1]
- **Short interest:** ~1.9% of float [16]

## Moat — what it is physically made of

Decompose into four components, assessed separately.

**1) 300mm internal manufacturing scale (HIGH durability, 10+ yr):** TI's 2026 capex is $2–3B; SM1 in Sherman TX is ramping, SM2 shell complete, Lehi LFAB1 ramping 45–65nm BCD with 28nm in qual. Stated target: >95% wafers internal, >80% on 300mm by 2030 [9]. Analog transistor counts are low, so 300mm cost-per-die advantage over 200mm is structural (~40%). Only Infineon could plausibly match this in a 5–7 year timeline; ADI runs a hybrid TSMC-plus-internal model. This is the deepest part of the moat and the reason gross margin floor should normalize at 60%+.

**2) Catalog + multi-decade SKU support (HIGH for industrial, MEDIUM for AI):** ~80,000 active SKUs, ~100,000 customers, direct (non-distribution) sales since ~2020. Industrial design cycles are 5–15 years and re-qual costs are high — durable. AI server design cycles are 18–36 months and procurement is much more willing to switch — less durable.

**3) Process IP — BCD, high-voltage isolation, integrated GaN (MEDIUM-HIGH):** The LMG3650 family integrates a 650V GaN FET with high-side gate driver in TOLL packaging at >98% efficiency, >100W/in³ [4][18]. IsoShield co-packages a planar transformer with an isolated power stage at claimed 3× density versus discrete. Comparable to Infineon and ADI in high-voltage; behind MPS on point-of-load multiphase VRM density.

**4) Direct sales channel (MEDIUM):** Real customer-relationship asset but raises opex and is structurally cyclical.

**Critical hole — be honest:** TXN does **not** own the highest-volume socket in current AI servers. The 12V→1V multiphase VRM on the Bianca board for GB200/GB300 belongs to MPS, with Renesas and Infineon absorbing share after MPS execution stumbles in late 2025 [7][8]. The $250 PDB module is Renesas-exclusive [7]. TXN's "AI win" is currently the lower-value supporting analog (hot-swaps like TPS1685, GaN drivers, isolated bias, telemetry), not the marquee VRM socket. The 800VDC architecture (below) is their bid to leapfrog into that socket in the next generation.

## AI buildout bottleneck map
- **Grid transformers and turbines:** 5-year backlog on high-voltage transformers, 5-year on gas turbines. Sightline Climate: 12GW of 2026 US data center capacity announced across 140 projects, only 5GW actually under construction [12][13]. **TXN: indifferent — no exposure.** The bottleneck has migrated upstream from rack to substation, and TXN doesn't play there.
- **CoWoS-L advanced packaging, HBM3e/HBM4 yield:** **TXN: indifferent.** No exposure.
- **Rack power-architecture transition 54V → 800VDC:** TXN announced a complete 800V reference design with NVIDIA in March 2026 — 800V hot-swap controller, 800V→6V bus converter at 97.6% peak η, 6V→<1V multiphase buck, 30kW 800V AC/DC PSU, 800V capacitor bank, in a two-stage rather than three-stage topology [4][5]. Deploys with Kyber + Rubin Ultra targeted 2027, 600kW racks scaling to 1MW with Feynman 2028 [11][5]. **TXN: strategic beneficiary — this is the bet.**
- **Liquid cooling at >100kW/rack:** Marginal beneficiary (sensors, gate drivers in CDU pumps). Not material.
- **Kernel/compiler/optical interconnect:** **TXN: indifferent.** Wrong layer.
- **Industrial supply chain (90% of TXN customers):** Recovering. Industrial +30% YoY Q1 26 from a depressed base but still ~15% below 2022 peak; auto mid-single digits YoY, flat sequentially [2]. Cyclical tailwind, not a bottleneck.

## Competitive teardown

| Competitor | Axis | Current state | TXN response |
|---|---|---|---|
| **MPS** | 12V→1V multiphase VRM density | Dominant Bianca-board incumbent on GB200; some share losses in late 2025/2026 [7][8] | Bypassing via 800VDC two-stage architecture; no current parity on density |
| **Infineon** | 48V eFuses (XDP730/720/721/22), SiC, GaN | Took GB200 VRM share from MPS; arguably the most credible threat on 800VDC given auto-grade high-voltage depth | TPS1685 48V eFuse competitive; LMG3650 GaN parity-ish on integration; will compete head-to-head on 800VDC |
| **Renesas** | PDB module on GB200 (~$250 exclusive), B200 VRM share gain [7] | Strong silicon-level position; smaller 800VDC story | TXN not in the PDB socket; focus on adjacent analog |
| **ADI** | Precision data converters, signal chain, RF | Different positioning — "performance" at ~15% share vs TXN "scale" at ~20% share; ADI gross margin 65%+ vs TXN 58% [14] | Coexists more than competes; AI sockets are different |
| **Power Integrations / Navitas / EPC / Innoscience** | Pure-play GaN density | Better device-level R(on) and switching loss than TXN | TXN wins on integration, manufacturing scale, qualification; vulnerable if hyperscalers disaggregate the GaN stage |

What would have to be true for TXN to take share: 800VDC architecture is the only path to a step-change in TXN's data center mix. If NVIDIA standardizes around the TI reference design and Kyber ships on time in 2027, TXN can plausibly attach 20–30% of new-generation rack power BOM versus a sub-10% incumbency in current Blackwell.

## Bull case — technical
The 800VDC bet wins. NVIDIA's two-stage 800V→6V→<1V reference design ships with Kyber in 2027 [5], forcing a rebid of the multiphase socket where TXN's announced 97.6% peak η bus converter [4] is at least at parity with anything MPS has publicly disclosed as of May 2026. Data center grows from ~10% of revenue to ~15–20% by 2028. Concurrently, industrial cycle continues to recover — still 15% below 2022 peak [2] — giving 2–3 years of upside in the larger core business. Capex falls from peak to $2–3B run-rate, FCF inflects from $1.7B (2025) to ~$7B+ ($8/share) in 2026 toward $10–12/share by 2028 [9]. Stock works as cyclical + AI compounder.

**Base rate caution:** In analog cycles since 2000, peak-to-trough EBIT swings 30–50%, and the first 12 months off an industrial bottom have delivered 60–100% total return. TXN has done +72%. Cyclical mean reversion is largely done; from here the AI socket-share story has to do the heavy lifting.

## Bear case — technical
Three layered concerns.

**(1) TXN missed the current-gen AI VRM socket.** The 90% YoY data center print is coming off a small base on lower-margin supporting analog, not the marquee multiphase VRM held by MPS/Renesas/Infineon [7][8]. If Rubin Ultra/Kyber slips (precedent: GB300 design changes, hyperscaler preference for incremental 54V over revolutionary 800VDC), TXN's data center mix stays around 10–12% and the upside thesis fails. The 800VDC reference design announcement is a *demonstration*, not a sole-source production commitment — and TXN explicitly says it requires "only two conversion stages" but every other ecosystem partner is also working on this [10][19], so design-win exclusivity is not the default.

**(2) Multiple expansion has already happened.** ~36× forward consensus is roughly 2× TXN's pre-2022 multiple, in a business where normalized gross margin is 58–62% (not 70%+) and operating margin 35–40% (not 50%+). Consensus PT $265 already sits **below** the $287 spot. Sell-side moved estimates up and the stock overshot. Re-rating risk asymmetrically down.

**(3) The capex story cuts both ways.** $20B+ committed to internal fabs at the trough generates depreciation that suppresses gross margin for the next 5–7 years even with full utilization. Q1 26 GM of 58% is still well below the 67–70% peak of 2022. If broad-market industrial uneven-ness persists or auto recovery doesn't materialize (China down, RoW up, flat sequential [2]), the unit economics on Sherman/Lehi don't justify the multiple. TXN is becoming more cyclical and more capital-intensive than the 2015–2022 era when it traded 20–25×.

## Market view check
At $287 / ~36× forward, the market is pricing TXN as a high-quality cyclical with a real-but-contingent AI option, not yet as a pure-play AI beneficiary. Consensus PT −8% from spot is the sell-side admitting the rally has run ahead of fundamentals. The market is implicitly believing: (a) industrial cyclical recovery continues for several quarters, (b) data center compounds at high rates, (c) margins normalize toward mid-60s gross by 2027–28. (a) and (c) look likely; (b) is the genuinely binary variable. The price is approximately fair given current visibility — substantial outperformance from here requires hard evidence of 800VDC socket wins (not demonstrations) by mid-2027.

## 90-day falsifiers
- **Q2 2026 earnings (late July):** Data center quarterly run-rate. Bull thesis intact if ≥$500M/q (≥$2B annualized) and ≥60% YoY; broken if <40% YoY.
- **Q2 hyperscaler capex prints (MSFT/GOOG/META/AMZN, late July):** Any sequential capex cut >5% materially weakens the analog content second-derivative story.
- **MPS Q2 results (early August):** Commentary on GB300 VRM and any disclosed Rubin/Kyber socket allocation is the direct read on TXN's 800VDC chances. MPS retaining the multiphase VRM in 800VDC reference designs invalidates the bull thesis.
- **GTC fall update + OCP Summit (Oct 2026):** Any change to Rubin Ultra timeline, Kyber rack design, or named 800VDC ecosystem preferred suppliers.
- **Edgewater / SemiAnalysis socket-share notes:** Sell-side teardown commentary on Blackwell Ultra / Rubin shares for power.
- **Auto commentary at Q2 print:** Sequential improvement (currently flat) would confirm industrial+auto + DC triple-engine; flat-to-down would expose the rally as priced-in.

## What I could not verify
- TXN's specific $ content per GB200 / GB300 rack vs prior generations. References are qualitative — "growing" — without per-rack BOM disclosure.
- Whether TXN has any sole-source or preferred-supplier commitment from NVIDIA for 800VDC beyond a public reference-design demonstration in March 2026 [4].
- Named hyperscaler ASIC program design wins for TXN power (Trainium, MTIA, TPU, Maia) — publicly disclosed only generically.
- The exact current TXN share within MPS / Renesas / Infineon for GB200 supporting analog (eFuses, drivers, sensors). Edgewater notes [8] are sell-side, not primary.
- Specific TXN patent portfolio strength on 800VDC topologies vs Infineon's auto-grade IP.
- The precise 52-week price range; the most recent rally appears to have pushed spot above the high reported in March 2026 sources.

## Sources
[1] Yahoo Finance TXN quote, finance.yahoo.com/quote/TXN — retrieved 2026-05-10 — current price ~$287, market cap ~$260B, +72% LTM
[2] TI Q1 2026 earnings call transcript, fool.com / investing.com — retrieved 2026-05-10 — Q1 revenue $4.83B (+19%), EPS $1.68, GM 58%, OPM 37%, industrial +30% YoY, auto mid-single, broad market recovery
[3] TI Q4 2025 results, futurumgroup.com / stocktitan — retrieved 2026-05-10 — Q4 revenue $4.42B, Analog $3.6B, Embedded $662M; data center $1.5B FY25 (9%), ~$450M Q4 run-rate, +70% Q4 YoY
[4] TI press release "complete 800 VDC power architecture with NVIDIA" 2026-03-16, ti.com — retrieved 2026-05-10 — 97.6% peak η bus converter, two-stage 800V→6V→<1V, 30kW PSU
[5] NVIDIA Developer Blog: 800 V HVDC Architecture — retrieved 2026-05-10 — 1MW rack timeline starting 2027, Kyber rack 576 Rubin Ultra GPUs
[6] Schneider Electric blog 2025-10: 1 MW AI rack and 800 VDC — retrieved 2026-05-10 — 5% efficiency uplift, 70% maintenance cost reduction with 800 VDC
[7] GlobalTechResearch substack "GB200 Power Module War" — retrieved 2026-05-10 — MPS as VRM incumbent on Bianca, Renesas PDB exclusive ~$250
[8] Edgewater Research note via Yahoo / TipRanks on MPS Blackwell allocation — retrieved 2026-05-10 — MPS share losses, Renesas/Infineon gains
[9] TI Capital Management Review (investor.ti.com / Yahoo summary) — retrieved 2026-05-10 — 2026 capex $2–3B, FCF/share $8+ target, >95% internal & >80% 300mm by 2030
[10] Power Electronics News on NVIDIA 800V partnerships — retrieved 2026-05-10 — ecosystem framing
[11] Tom's Hardware: Rubin Ultra 600kW Kyber 2027 — retrieved 2026-05-10 — rack specs
[12] Power Magazine "Transformers in 2026" — retrieved 2026-05-10 — 5-year transformer backlog
[13] PowerMag/Sightline data — retrieved 2026-05-10 — 12GW announced vs 5GW under construction in 2026 US
[14] InPractise / Hudson Labs / Artificall on ADI vs TXN — retrieved 2026-05-10 — ~20% TXN share vs ~15% ADI; ADI 65%+ GM vs TXN ~58%
[15] StockAnalysis.com / SimplyWallSt — retrieved 2026-05-10 — Forward P/E 35–38×, consensus PT $265 (Stifel $290, UBS $295), 2026 EPS ~$8
[16] MarketBeat TXN short interest — retrieved 2026-05-10 — 17.3M shares short, ~1.9% of float; 52-week range $142.64–$231.32 (pre-rally)
[17] TI.com TPS1685 product page + voltpost.com coverage — retrieved 2026-05-10 — first integrated 48V hot-swap eFuse with power-path protection, >6kW scalable
[18] thevoltpost.com / Power Electronics: TI GaN at Dell/Vertiv — retrieved 2026-05-10 — Dell 1.8kW 12V PSU; Vertiv 5.5kW PSU → 132kW/rack with TI GaN
[19] DCD: NVIDIA 800V partner ecosystem — retrieved 2026-05-10 — 20+ industry partners
[20] Manufacturing Dive / Seeking Alpha on TI Q4 2025 — retrieved 2026-05-10 — industrial+auto+DC combined = 75% of revenue