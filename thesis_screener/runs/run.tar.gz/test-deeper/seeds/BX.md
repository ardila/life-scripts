# BX — Blackstone Inc.

## Where this sits in the AI stack
Blackstone is not a silicon, kernel, or systems vendor. It is the largest financial owner of the **physical real estate, power, and grid-interconnection layer** of AI infrastructure — the stratum below the hyperscaler operating system. Through QTS (acquired 2021, ~3 GW contracted, $25B development pipeline 100% pre-leased to investment-grade hyperscalers, $80B land bank) [6][9], AirTrunk in APAC (acquired with CPPIB Sept 2024 for A$24B / ~US$16.1B, >1 GW developable land) [10], BREIT data center holdings (20.4% of BREIT real estate value) [2], a PPL natural-gas generation JV in Pennsylvania, and a $3B JV with Saudi Arabia's Humain [10], the firm functions as a leveraged, fee-earning aggregator of land + power + utility relationships at a scale below hyperscalers and above traditional REITs. Workload exposure is overwhelmingly **wholesale colocation for frontier training and large inference**, not retail or edge inference.

## Snapshot
- **Price:** $123.77 (2026-05-08 close) [1]
- **Market cap:** ~$94.7B [3]
- **52-week range:** $101.73 – $190.09 [4]
- **Forward P/E:** ~19.9× (FY2026 consensus EPS $6.58) [3][7]
- **EV / NTM revenue:** ~8.9× [7]
- **Consensus 12-month price target:** $157.23 (+27% from current) [7]
- **YTD total return:** –16.3% [4]
- **Short interest (% of float):** ~3.1% — below the asset-manager peer group average of 3.64% [12]
- **Dividend yield:** ~3.8% (annualized $4.74) [4]
- **AUM:** $1.3T total ($938B fee-earning) — Q1 2026 inflows $69B, DE $1.76B (+25% YoY) [3][8]

## Moat — what it is physically made of
Blackstone's moat is not technological in the silicon/software sense. It is a **capital-scale × land × power moat**, and each component has different durability:

1. **Pre-secured power contracts and grid interconnect.** This is the single most defensible component. QTS's >3 GW already contracted [9] and the PPL JV (new gas-fired generation behind-the-meter for PA campuses) [2] sit ahead of the **PJM 643 GW interconnection queue against 142 GW installed capacity** and the **ERCOT large-load queue that quadrupled to ~226 GW in 2025** [5]. PJM's IMM has asked FERC to halt new data-center connections; PJM came up 6,625 MW short in its Dec 2025 capacity auction [5]. Replicating QTS's interconnect position now requires waiting through 5–7 year queues. **Durability: high, 3–5 years**, eroding as private/behind-the-meter generation matures.

2. **Land bank in Tier-1 markets.** $80B of developable QTS land plus AirTrunk's >1 GW APAC pipeline [9][10]. Loudoun County ended by-right data-center zoning in March 2025 [11]; Virginia HB503/HB1515 in 2026 attempt to either pass infrastructure cost to DC tenants or impose moratoria where interconnect is unfulfilled [11]. New entrants cannot replicate the geographic footprint at price. **Durability: high, 5+ years.**

3. **Capital-aggregation scale.** $1.3T AUM, $250B trailing-twelve-month inflows [3]. Blackstone can underwrite $16B single-asset deals (AirTrunk) with one phone call to CPPIB. Competitors below KKR/Brookfield/GIP scale cannot. **Durability: high but not unique** — KKR/Brookfield/Stonepeak/DigitalBridge can compete on individual deals; only BX can compete on all of them simultaneously.

4. **Underwriting + asset-management process.** BREIT's pre-leased $5.8B 2025 deployment and BXDC's filed S-11 [2][14] suggest internal underwriting machinery is genuinely differentiated, but this is **process moat, not physical moat** — replicable in 3–5 years if a competitor commits.

5. **What the moat is *not*.** No CUDA-equivalent technical lock-in. No proprietary cooling IP — the GB200 NVL72 cold-plate spec (1200W/module, 130 LPM, 30–45°C inlet, 150–200 kW CDU) is an open NVIDIA reference [13] that Equinix, Digital Realty, Vantage, CyrusOne, Aligned, and Stack all implement. No proprietary networking. The buildings are commodities; the **scarcity is upstream of the building**.

## AI buildout bottleneck map
- **Power generation & grid interconnect** — *Beneficiary + constraint owner.* QTS's 3 GW pre-secured + PPL JV positions BX on the right side of a 2,290 GW national queue [5]. PJM is the binding constraint and BX's biggest QTS footprint sits inside it.
- **Advanced packaging (TSMC CoWoS-L)** — *Indifferent.* BX has no semiconductor exposure. Its tenants are exposed.
- **HBM3e / HBM4 supply** — *Indifferent.* Same as above.
- **Optical interconnect / coherent optics** — *Indifferent.*
- **Liquid cooling at >100 kW/rack** — *Beneficiary, not constraint owner.* QTS deploys direct-to-chip per the GB200 NVL72 reference [13][15]; cooling vendors (Vertiv, Boyd, Motivair, CoolIT) hold the actual scarcity. BX is a buyer, not a supplier.
- **Electrical contractor / switchgear / transformer capacity** — *Exposed customer.* BX's $25B PA pipeline competes with Microsoft/Google/Meta self-build for the same GE Vernova transformer slots and Cummins/Caterpillar generator backlogs.
- **Permitting / land-use politics** — *Beneficiary on inventory; exposed on new entitlements.* BX's existing entitlements are an asset; new ones face Loudoun zoning + state moratorium bills [11].
- **Kernel / compiler / training-systems talent** — *Indifferent.*
- **Frontier training data quality** — *Indifferent.*

The single strongest read on BX is: **its bottleneck exposure is asymmetric — it is positioned ahead of the power constraint in PJM/ERCOT, and indifferent to the silicon/packaging/HBM constraints that limit NVDA/AVGO upside.**

## Competitive teardown
- **Equinix (EQIX) / Digital Realty (DLR)** — Direct REIT competitors. EQIX's strength is **interconnect / network density** for inference and enterprise — 8 of top 10 model providers, 4 of top 5 neoclouds expanding on-platform, 110+ network nodes [4]. DLR's strength is hyperscale wholesale at scale. BX/QTS is more pure-play hyperscale wholesale than EQIX, and trades inside a private wrapper which lets it underwrite ROIC the public REITs can't (BREIT cap-rate flexibility, opaque carry economics). **On the pure pre-leased hyperscale build axis, QTS is at parity or ahead in pipeline; on interconnect, EQIX is decisively ahead.**
- **Hyperscaler self-build (AWS, Microsoft, Google, Meta)** — The actual structural threat. Combined 2026 capex $500–630B, +62% YoY [16]. The Big Four go from ~20% of global DC capacity in 2017 toward ~60% by 2029 [16]. BX's defense: hyperscalers cannot self-build fast enough at the current tempo and lease the **delta**. Schwarzman's framing — that QTS leased capacity grew 14× since 2021 [2] — is consistent with this thesis. **The threat is not displacement, it is rate-of-growth compression once hyperscaler self-build catches up post-2027.**
- **Stargate / Crusoe / Lancium model** — OpenAI + Oracle + SoftBank + MGX, $500B target through 2029 [17]. The Abilene flagship sits on Lancium's Clean Campus, built by Crusoe. The 600 MW Abilene expansion was scrapped in 2026 over financing/capacity disagreements [17]. This proves both that **the disintermediation model works** (Crusoe + behind-the-meter gas + tenant capital can bypass colo entirely) **and that it is fragile** (deals fall apart, Microsoft picks up the canceled site [17]).
- **Neoclouds (CoreWeave, Lambda, Nebius, Crusoe)** — Customers, not competitors, of BX/QTS today. Risk: they vertically integrate into real estate as they raise debt against GPU contracts.
- **DigitalBridge / Brookfield / KKR / Stonepeak** — Capital competitors. Can match individual deals (Brookfield's $30B Compass investment, DBRG's Vantage), cannot match aggregate underwriting velocity.
- **CoreScientific / Applied Digital / IREN** — Power-first developers pivoting from crypto. Cheaper power, less polished tenant relationships. Real but small competition for tier-2 sites.

## Bull case — technical
For BX to outperform from $123.77, the following technical conditions must hold:
1. **The PJM/ERCOT power bottleneck persists through 2027.** This is the most important variable and the consensus view is correct here — interconnect queues are 5–7 years and FERC is unlikely to fast-track [5].
2. **Hyperscaler capex stays at the announced $500–630B run-rate** [16]. The marginal lease decision goes to whoever has interconnect now, not who can build the cheapest building, and that is QTS/AirTrunk.
3. **GB200/GB300 → Rubin → Rubin Ultra rack densities continue to rise** (currently 120 kW/NVL72, NVL576 reference designs at >500 kW [13][15]), which makes the existing "just power and a slab" pre-2023 wholesale stock obsolete and re-pulls demand toward purpose-built liquid-cooled inventory. QTS's $25B pipeline is built to this spec; older DLR/EQIX inventory is not.
4. **Hyperscaler self-build does not catch up before 2028.** Self-build is throttled by the same transformer/contractor/permit constraints as colo, plus internal opportunity cost of capital.
5. **BXDC IPO clears at or above the $1.75B target** [14], establishing a public mark on stabilized data-center NAV and unlocking carry crystallization at QTS-level vehicles.

**Base rate caveat:** technology platform shifts from on-prem to cloud took ~15 years (2006 EC2 → 2020 majority workloads). The colo→hyperscaler-owned shift is plausibly on a similar arc. Three years of strong tailwind is highly likely; 8 years is not yet underwritable. Financial outcome: 19.9× forward P/E on a 25%+ DE growth print [8] is not demanding. Multiple expansion to 22–24× plus EPS upside to ~$7+ supports the consensus $157 PT with normal probability, not heroically.

## Bear case — technical
The version a short who understands the stack would write:
1. **The buildout is being underwritten on a workload mix that may not exist.** If frontier training compute spend plateaus — i.e., scaling laws return diminishing returns at ~Llama-5 / GPT-6 scale and the marginal training token stops being economic — the multi-GW pre-leases become stranded by 2028. The BXDC prospectus assumes 5.75–7% returns on stabilized assets [14]; that math breaks if hyperscalers renegotiate or sublease. There is no public technical evidence that scaling has broken, but the expected-value asymmetry on the building side is bad.
2. **Stargate model generalizes.** Crusoe + Lancium + behind-the-meter gas + tenant balance sheet bypasses colo entirely. The first such site is live in Abilene; if Microsoft's pickup of the canceled 600 MW site [17] becomes the reference architecture, hyperscalers route incremental capacity around BX rather than to it.
3. **Power becomes regulated, not BX-owned.** If FERC orders PJM to halt new data-center connections at the IMM's request [5], or Virginia HB1515-class moratoria pass, BX's existing entitled inventory becomes more valuable in the short term but the **growth pipeline (the part the multiple is paying for) compresses**.
4. **AUM model lag.** BX gets paid in management fees + carry. Carry on data-center vehicles crystallizes only on realization. If BXDC IPO is the realization mechanism and it clears below target, the 2026–27 DE trajectory disappoints.
5. **BREIT redemption tail.** 20.4% of BREIT real estate is data centers [2]; if BREIT redemption queues reopen on a credit shock, BX is forced to mark or sell into a thin private market. Already-elevated short interest in BX peers like BXMT signals this concern is alive.
6. **Rate sensitivity.** Asset manager + leveraged real estate. A 100 bp move in the long end materially compresses cap rates on the 2025–28 vintage.

The honest bear take is not "AI is a bubble." It is: **at peak hyperscaler capex velocity, the marginal value capture moves toward parties that own silicon or own the customer, not parties that own the building.** BX's 2021–24 acquisitions were brilliantly timed; the 2025–26 commitments are at very different cost-of-capital.

## Market view check
At $123.77, BX trades at ~19.9× FY26 EPS and ~8.9× EV/sales, with a 27% implied upside to consensus PT $157.23 [7] and YTD return –16.3% [4]. The stock has already corrected from $190 — meaning the **market is pricing in some bear-case discount to the AI infrastructure thesis**, not extrapolating it. Consensus rating is mixed (47% Hold) [7]. The price is consistent with a market that believes (a) hyperscaler capex remains strong but (b) the fee-paying flow-through to BX's DE is uncertain, (c) BREIT redemptions remain a tail risk, and (d) hyperscaler self-build will start to compress wholesale demand growth post-2027. I think the market is roughly right on (a) and (b), too cautious on (c) given recent BREIT data center NAV strength, and **directionally correct but too aggressive on (d)** — the power-interconnect moat is harder than the bear case credits, at least through 2027.

## 90-day falsifiers
- **BXDC IPO pricing and aftermarket trading (May–June 2026).** Pricing at or above $20 with an aftermarket premium validates the stabilized-DC cap rate; pricing below or a broken IPO is a direct read that the public market is rejecting BX's NAV marks [14].
- **Hyperscaler Q2 2026 capex guides (late July / early Aug — MSFT, GOOGL, META, AMZN).** A sequential cut of >10% in 2026 capex commitment from any two of the four invalidates the demand-side bull case.
- **FERC ruling on PJM IMM petition** to halt new data-center grid connections [5]. A ruling in PJM's favor (or even a procedural endorsement) is mixed: locks in BX's existing entitlements but freezes incremental development.
- **Virginia HB1515 / HB503 progression** through reconciliation; failure to pass kills near-term moratorium risk; passage hits BX's NoVA pipeline directly [11].
- **Q2 2026 BX earnings (late July 2026):** specifically the BREIT data center deployment pace (already $5.8B in 2025; guidance is "substantially higher" in 2026 [2]) and any commentary on QTS pre-lease counterparty mix.
- **Stargate / Crusoe Phase 2 announcements** beyond Abilene — sites going live without a Blackstone/QTS/AirTrunk leasehold are evidence of the disintermediation thesis [17].
- **GB300 / Rubin deployment commitments at hyperscalers** that name specific colo partners — silence from QTS in those announcements would be a negative read.

## What I could not verify
- **QTS tenant concentration by name.** Public reporting confirms "investment-grade hyperscalers, 15+ year contracts, 100% pre-lease" [9] but not whether a single tenant (likely Microsoft based on QTS's historical mix) exceeds 30–40% of contracted MW. Concentration risk is unquantified.
- **Take-or-pay terms vs. ramped-utility terms** in QTS leases. The 100% pre-lease number is meaningless if it is ramped-utility; it is decisive if it is take-or-pay from RCD.
- **Carried-interest crystallization schedule** on BX's data center vehicles — the timing of when AUM growth becomes DE growth is opaque.
- **Specific PPL JV power-purchase pricing** and whether the gas generation is firm or interruptible — material to whether the PA pipeline survives a regional capacity-market shock.
- **Liquid-cooling vendor relationships** (Vertiv vs. Motivair vs. Boyd) at QTS sites — unverified whether QTS has any preferential allocation of CDUs in a constrained market.
- **AirTrunk customer concentration** post-acquisition — Australian disclosure is thinner than US REIT disclosure.
- **Behind-the-meter generation timeline** for the PPL JV — public reporting gives intent but not COD dates.

## Sources
[1] https://finance.yahoo.com/quote/BX/ — retrieved 2026-05-10 — May 7–8, 2026 close prices ($122.32 → $123.77).
[2] https://hedgeco.net/news/01/2026/data-centers-are-powering-blackstones-1-3-trillion-investment-engine.html — retrieved 2026-05-10 — BREIT 20.4% data center weighting; $5.8B 2025 deployment; PPL JV; QTS 14× leased capacity growth since 2021.
[3] https://www.gurufocus.com/news/8813474/blackstone-bx-reports-strong-q1-2026-earnings-with-record-aum — retrieved 2026-05-10 — Market cap ~$94.7B; P/E 31.4× / forward 19.9×; AUM $1.3T; Q1 DE $1.76B.
[4] https://www.financecharts.com/stocks/BX/performance/total-return — retrieved 2026-05-10 — 52-week range $101.73–$190.09; YTD –16.3%; dividend $4.74.
[5] https://enkiai.com/ai-market-intelligence/us-grid-congestion-2026-pjms-data-center-crisis ; https://introl.com/blog/pjm-grid-crisis-6gw-shortfall-data-center-power-2027 ; https://www.latitudemedia.com/news/ercots-large-load-queue-has-nearly-quadrupled-in-a-single-year/ — retrieved 2026-05-10 — PJM 643 GW queue / 142 GW installed; ERCOT 226 GW large-load queue (77% data center); PJM Dec 2025 capacity auction 6,625 MW short; IMM FERC petition.
[6] https://www.datacenterdynamics.com/en/news/blackstone-qts-to-spend-8bn-on-building-new-data-centers-as-investor-prepares-for-once-in-a-generation-ai-boom/ — retrieved 2026-05-10 — QTS development scale and rationale.
[7] https://stockanalysis.com/stocks/bx/forecast/ ; https://www.marketscreener.com/quote/stock/BLACKSTONE-INC-60951400/consensus/ — retrieved 2026-05-10 — Consensus PT $157.23; FY26 EPS $6.58; EV/Sales 8.88×; rating distribution.
[8] https://www.fool.com/earnings/call-transcripts/2026/04/23/blackstone-bx-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1 2026 transcript; DE +25% YoY; $69B inflows; Schwarzman/Gray AI infrastructure commentary.
[9] https://www.costar.com/article/1671634861/blackstones-qts-breaks-its-own-record-for-largest-cmbs-data-center-refinancing — retrieved 2026-05-10 — QTS 3 GW contracted; $25B development pipeline 100% pre-leased; $80B land bank.
[10] https://www.blackstone.com/insights/article/behind-the-deal-airtrunk/ ; https://pe-insights.com/blackstone-partners-with-saudi-arabias-humain-in-3bn-data-centre-venture-to-power-ai-growth/ — retrieved 2026-05-10 — AirTrunk A$24B / US$16.1B with CPPIB; >1 GW developable; Humain $3B JV.
[11] https://www.vpm.org/generalassembly/2026-01-16/2026-data-center-bills-thomas-hb155-mcauliff-hb503-pjm-dominion-energy ; https://goodjobsfirst.org/data-center-moratorium-bills-are-spreading-in-2026/ — retrieved 2026-05-10 — Virginia HB503/HB1515; Loudoun ended by-right zoning Mar 2025; 300+ state DC bills in 2026.
[12] https://www.marketbeat.com/stocks/NYSE/BX/short-interest/ — retrieved 2026-05-10 — Short interest 21.81M shares / 3.08% of float; peer average 3.64%.
[13] https://www.nvidia.com/en-us/data-center/gb200-nvl72/ ; https://introl.com/blog/gb200-nvl72-deployment-72-gpu-liquid-cooled — retrieved 2026-05-10 — GB200 NVL72 120 kW/rack; 1200W/module cold plates; 130 LPM; 30–45°C inlet; 150–200 kW CDU.
[14] https://www.bisnow.com/national/news/data-center-capital-markets/blackstone-digital-infrastructure-trust-ipo-134402 ; https://seekingalpha.com/news/4584621-blackstones-data-center-reit-aims-to-raise-174b-in-ipo — retrieved 2026-05-10 — BXDC S-11 filed Apr 10 2026; $1.75B target; $20/share; 5.75–7% expected returns; $250M–$1.5B per asset.
[15] https://www.theregister.com/2024/03/21/nvidia_dgx_gb200_nvk72/ — retrieved 2026-05-10 — DGX GB200 NVL72 120 kW reference; physical rack architecture.
[16] https://www.ciodive.com/news/hyperscalers-two-thirds-data-center-capacity-2031/817016/ ; https://datacenterrichness.substack.com/p/hyperscalers-plan-630-billion-in — retrieved 2026-05-10 — Big Four 2026 capex $500–630B (+62% YoY); hyperscaler share of global DC capacity 20% (2017) → ~60% (2029).
[17] https://www.datacenterdynamics.com/en/news/oracleopenai-drop-plans-to-expand-flagship-abilene-stargate-site-meta-in-talks-to-pick-up-crusoe-capacity-with-nvidias-help/ ; https://openai.com/index/stargate-advances-with-partnership-with-oracle/ ; https://fortune.com/2026/03/27/microsoft-texas-data-center-open-ai-former-partner-cloud-provider/ — retrieved 2026-05-10 — Stargate $500B target; Abilene Phase 1 live on Crusoe/Lancium; 600 MW expansion canceled; Microsoft pickup; 4.5 GW Oracle-OpenAI agreement.