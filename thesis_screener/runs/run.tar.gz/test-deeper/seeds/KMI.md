# KMI — Kinder Morgan, Inc.

## Where this sits in the AI stack
KMI is not a chipmaker, hyperscaler, or hardware vendor — it owns physical right-of-way and steel pipe at the deepest layer of the AI stack, the **fuel-to-power-to-compute** layer. Specifically: ~66,000–72,000 miles of large-diameter natural gas transmission, gathering, and storage assets that move ~40% of all natural gas consumed in the United States [1][12]. AI shows up in KMI's P&L as **firm-transport tariffs** on long-haul pipes feeding (a) on-site behind-the-meter gas turbines co-located with hyperscale campuses, and (b) merchant CCGT power plants whose offtake is increasingly contracted to specific data center loads [4][9]. The relevant workload is 24/7 baseload electricity for AI training and inference clusters where utility interconnect timelines (5+ years for HV substations, 3-5 years for transformers) [4] make grid-tied power non-viable on the AI capex schedule. KMI sells molecules-by-pipe, not power — but it owns the substrate the gas-turbine rush depends on.

## Snapshot
- **Price:** $31.39 (2026-05-09 close) [2]
- **Market cap:** ~$69.9B [2]
- **52-week range:** $25.60 – $34.73 [2]
- **Forward P/E:** ~23x on FY26 adj. EPS guidance of $1.36–1.37 [13]
- **EV / NTM EBITDA:** ~11.9x (EV ~$107B; FY26 adj. EBITDA guide ~$8.6–8.8B) [11][13]
- **Consensus 12-month price target:** $33.81, range $31–$38, +7.7% implied (16 analysts, "Buy") [11]
- **YTD total return:** +19% (price); ~+21% (1-yr including dividend) [2][14]
- **Short interest (% of float):** ~2.5% — low; institutional ownership >60%, net buyers [16]
- **Net debt / adj. EBITDA:** 3.6x (vs. 3.5–4.5x target band) [13]
- **Dividend:** $1.19/sh annualized (2026), 9th consecutive raise; ~3.8% yield [13]

## Moat — what it is physically made of
The "moat" decomposes into four physically distinct components, with very different durabilities:

**1. Right-of-way (highest durability, ~25-yr+).** KMI's ~72,000 miles of pipe is not a duplicable asset. New interstate gas pipelines require FERC certificates under the Natural Gas Act; even with the post-2025 reform tailwind (NEPA timelines reduced ~30% [10]), greenfield interstate construction averages 3–5 years from filing to in-service. Critically, the long-haul corridors KMI already owns — Tennessee Gas Pipeline (Marcellus → Northeast/Gulf), El Paso (Permian → California/desert SW), Southern Natural Gas (Gulf → Southeast load), CIG/Wyoming Interstate (Rockies → Midwest) — connect supply basins to the exact geographies where data center clusters are now being sited (NoVa/Loudoun, Phoenix, central Texas, Mississippi/Memphis, Ohio, Georgia). New entrants cannot replicate this; they can only build laterals off of it. This is the primary moat.

**2. Network density and connectivity (high durability).** KMI has direct interconnects to substantially every major LDC, gas-fired power plant, and LNG export facility on the Gulf. Q1 2026 system utilization on the five largest pipes was >90% [5], meaning incremental data-center load monetizes existing pipe at near-zero marginal cost — and gives KMI optionality to charge premium tariffs on debottleneck/expansion projects (the $10.1B backlog is sanctioned at a ~5.6x first-full-year EBITDA multiple [5], i.e. ~18% project-level returns).

**3. Long-term firm-transport contract book (medium durability, contract-life weighted).** ~85% of cash flow is take-or-pay or fixed-fee [12][15]; the recently announced Monument acquisition added a revenue-weighted ~9-year remaining contract life [13]. This is a rate-base-like cash flow stream — but it is *not* perpetual. As contracts roll, recontracting risk depends on where the basin/demand balance is at that point. For 2026–2030 the recontracting risk is essentially nil because the system is full; post-2030, see Bear Case.

**4. Permitting and execution machinery (medium durability, 5–10 yr).** KMI's in-house FERC, environmental, and EPC teams have shipped megaprojects (SSE4, Trident, GCX expansions) on schedule under a tightening regulatory environment. This is a soft moat — replicable by Williams, Energy Transfer, Enbridge — but an entrant or financial buyer cannot stand it up quickly.

What KMI **does not** have that gets miscategorized as moat: any proprietary technology, software, IP, or process advantage. Compression, metering, SCADA, leak detection — all commodity. The thesis is steel in the ground, not engineering.

## AI buildout bottleneck map
The actual gating constraints on the AI buildout over the next 24 months and where KMI sits on each:

| Constraint | Severity (24-mo) | KMI position |
|---|---|---|
| **Gas turbine slots (>100 MW frame)** | Severe — GE Vernova backlog 100 GW Q1 2026, expected sold out through 2030 by YE26; Siemens Energy €136B backlog, 65% of 14 GW H1 orders for data centers [3] | Indirect beneficiary — every turbine sold needs gas, and KMI is a 40%-share supplier |
| **HV substations / transformers** | Severe — 3–5 yr lead time on HV substations, 5-yr backlog on grid transformers [4] | **Beneficiary** — drives behind-the-meter / off-grid gas solutions, bypassing utility interconnect, which directly favors pipe-to-turbine-to-load |
| **Power generation siting & interconnect** | High — ~12 GW of 2026 US data center capacity announced, only ~5 GW under construction; 11 GW stuck pre-FID [4] | Beneficiary — KMI is the first call when a developer needs firm gas behind the meter |
| **Pipeline capacity to AI clusters** | High in TX, AZ, OH, southeast | **Constraint owner** — KMI directly monetizes this via Trident, Copper State, SSE4, and the Piketon/SoftBank lateral |
| **CoWoS-L / HBM3e / silicon supply** | High — gates GPU shipments | Indifferent |
| **Liquid cooling at >100 kW/rack** | High | Indifferent |
| **Permitting (FERC NEPA)** | Easing — 2025 GHG-policy withdrawal, 30% timeline compression [10] | **Strong beneficiary** — KMI's project queue moves faster, competitors with no in-house FERC team less so |
| **Cheap upstream gas (Permian/Haynesville/Appalachia)** | Currently abundant; Waha pricing weak (depressed) [7] | Beneficiary as a transporter — wide basis differentials are KMI's bread (it earns the spread, not the gas price) |

The single most important fact for the thesis: **gas turbines are the binding constraint on AI power, not gas molecules**. There is no shortage of US gas. There is a severe shortage of CCGT slots. Every turbine that comes off a GE Vernova or MHI assembly line gets sited near a pipe — and 40% of the time, that pipe is KMI's [1][3].

## Competitive teardown
Competitors are not chipmakers. They are the other Tier-1 midstreamers, plus the credible substitutes for gas-fired data center power.

**Williams Companies (WMB) — closest peer, partially differentiated.** Williams operates Transco (the nation's largest interstate gas pipeline by volume into the densest data center corridor — Mid-Atlantic/Southeast). Williams has been more aggressive in moving *up the stack* into power generation with Project Socrates (400 MW Meta-anchored in Ohio, 10-yr deal) and a stated $5B "power innovation" budget targeting 1 GW by 2027 [6]. **Technical axis where Williams beats KMI:** Williams is taking turnkey "gas-to-electrons" risk and capturing a wider spread; KMI remains a tariff-fee model. **Where KMI beats Williams:** geographic breadth (KMI plays in TX, AZ, southeast, OH; Williams is concentrated on Transco/Northeast Supply Enhancement). On a returns-on-incremental-capital basis the two are close — both sanctioning at mid-teen IRRs — but Williams has the higher beta to a data-center-specific demand surprise and KMI has the cleaner exposure to the molecule-volume surprise.

**Energy Transfer (ET).** Larger system (~130k miles total energy infrastructure), but a more diversified gas + NGL + crude footprint and a worse contract-quality reputation (more commodity-exposed segments). The Meta Richland Parish 20-yr deal (5.2 GW Entergy plants) demonstrates ET can win marquee data-center anchor deals [9]. K-shaped market: KMI is the cleaner pure-play, ET the higher-beta complex name.

**Enbridge (ENB).** Largest by enterprise value but heavily Canadian crude oil + utility-distribution. Its US gas transmission assets (post-Dominion deal) are real but less concentrated in AI corridors.

**Substitutes — the real competitive threat is not another midstreamer.**
- **SMRs (TerraPower Natrium, X-energy Xe-100, Oklo).** First commercial deployments late-2027 to early-2028 on aggressive timelines, more realistically 2030+ [8]. NRC construction permits beginning to flow (Natrium 1H26 [8]). Levelized costs $80–120/MWh by 2030 vs. CCGT all-in ~$60–80/MWh [8]. **What would have to be true for SMRs to take share:** (a) commercial operation date pulled forward by 18+ months; (b) capital cost per kW falling below $5,000; (c) hyperscalers willing to underwrite first-of-a-kind reactor risk on AI-relevant timelines. None of these are likely inside the 24-month window. SMRs are a 2030+ threat.
- **Behind-the-meter solar + storage.** Insufficient firmness for AI training (which is 24/7 high CF), can serve as a hybrid trim. Not a primary substitute.
- **Coal-to-gas conversions and existing CCGT.** Already in KMI's volumes — a *positive* not a competitive threat.

## Bull case — technical
For KMI to outperform meaningfully, four technical conditions must hold:

1. **Gas-turbine bottleneck persists into 2027–2028.** GE Vernova/Siemens/MHI capacity expansions reach ~24 GW/yr by 2028 [3], but cumulative AI power demand continues to outrun them. Each new turbine is anchor-load for a pipeline lateral. Base rate: in past industrial bottlenecks (HBM, CoWoS, advanced packaging), the constraint has typically resolved 2–3 years later than initial vendor guidance — i.e., bottlenecks last longer than the bull case usually models.
2. **AI data-center incremental gas demand lands in the 6–10 Bcf/d range by 2030**, of which KMI captures ~30–40% by virtue of network share. KMI itself disclosed >5 Bcf/d in active commercial discussions including 1.6 Bcf/d specifically tied to data centers [1].
3. **The Copper State Connector and SSE4 hit FID and reach in-service on schedule** ($3.5B / 2.1 Bcf/d to AZ by ~2028; $3–3.5B / 1.3 Bcf/d to southeast by late 2028 [9][13]). UBS modeled +$750M EBITDA on Copper State alone [9] — i.e., +9% to current run-rate EBITDA per project, contracted, no commodity exposure.
4. **The SMR timeline does *not* compress meaningfully.** First commercial SMR-to-data-center COD remains 2030+. This locks in a 4-year window where new AI baseload is overwhelmingly gas.

If 1–4 hold, KMI compounds a high-single-digit EBITDA growth rate (vs. low-single-digit pre-AI baseline), the backlog re-rates from $10B to $15–20B (KMI's stated target), and the equity captures both volume growth and modest multiple expansion — plausibly to a $40–45 stock by 2027 (12.5–13x EV/EBITDA, in line with utility-comp re-rate when growth visibility improves).

**Base rate caveat on platform-shift moats:** physical infrastructure moats (rail, pipelines, transmission) historically erode much more slowly than software moats. The pipeline industry has seen one full displacement cycle in 80 years (oil → gas, 1950s–70s), and even that was layered on top of existing right-of-way. The CPU→GPU and on-prem→cloud analogies *do not apply* to pipes.

## Bear case — technical
The honest short thesis, written by someone who understands the stack:

1. **The "AI gas demand" number is double-counted across midstream players.** KMI cites 1.6 Bcf/d data-center commercial discussions; Williams cites a similar order of magnitude; Energy Transfer cites the Meta deal independently. Industry-wide projections of 6–12 Bcf/d incremental AI gas by 2030 [4][9] reconcile only if you assume essentially every announced data-center MW comes online — and the empirical conversion rate (5 GW under construction / 12 GW announced for 2026 [4]) is ~40%. Apply that haircut and KMI's incremental data-center volume is 0.6–0.8 Bcf/d, not 1.6, by 2030. That's still positive, but it's already in the $10B sanctioned backlog and arguably in the multiple.

2. **Stranded-asset risk on 15-year contracts vs. SMR ramp post-2030.** The pipes being sanctioned now (Trident in-service 2027, Copper State ~2028, SSE4 late-2028) carry typical 15–20 year primary terms, putting expiration in 2042–2048. If SMR levelized cost falls to $80/MWh and capacity ramps to 50–75 GW by 2035, behind-the-meter nuclear becomes cost-competitive with gas before contract expiration. Recontracting risk is real on a 15-year horizon. The market does not price this.

3. **KMI is a tariff collector, not an equity participant in the AI value chain.** Compare the implied gross profit per GPU-hour: an H100 generates ~$2–3/hr in inference revenue at hyperscale margins; the gas behind it costs ~$0.05/hr in fuel and ~$0.005/hr in pipeline tariff. KMI captures less than 0.2% of the AI revenue dollar. The bull narrative ("backbone of AI") is real but the fee structure does not let KMI participate in software-layer operating leverage. The multiple is therefore correctly capped at midstream-utility levels, not AI-beneficiary levels.

4. **Behind-the-meter shift is double-edged.** If hyperscalers move to fully self-built gas turbines + on-site dedicated laterals (e.g., the SoftBank/Piketon model [9]), the long-term economic surplus moves to (a) the turbine OEM and (b) the data-center developer, with KMI getting only a modest lateral fee, not a corridor tariff. Williams's "go up the stack" strategy directly addresses this; KMI has not yet committed equivalent capital.

5. **Cyclicality of capex.** A >10% cut in hyperscaler 2027 capex guidance — already a debate among bears given $400B+ industry annual run-rate — would extend the gas-turbine queue (relieving the bottleneck KMI benefits from) and slow lateral sanctioning. The shadow backlog converts more slowly.

6. **Insider selling.** Notable insider sales through 2026 [1] are evidence (not proof) that those closest to the asset see the AI tailwind as priced.

## Market view check
At $31.39, ~24x forward EPS / ~12x EV/EBITDA, KMI trades roughly in line with its 5-yr utility-comp average, modestly above the pre-2024 midstream average (~10x EV/EBITDA). Consensus 12-month PT of $33.81 implies a benign +7-8% with the dividend taking the total return to low double digits [11]. The market view: *the AI tailwind is real but priced; KMI is a high-quality utility-like compounder with optionality.* My read of the technical reality is **directionally aligned** with this — the moat (right-of-way + network density) is durable through the 2026–2030 window where the gas-turbine bottleneck is binding, but the equity does not get to participate in AI's operating leverage and the multiple is therefore correctly capped. Mispricing, if any, is in two narrow places: (a) the market may under-credit the speed of FERC permit acceleration — a bullish asymmetry on Copper State/SSE4 sanctioning; (b) the market may under-price the post-2035 SMR substitution risk on 15-year contracts. Net: *fair, with mild positive carry from contract growth and dividend, no clear mispricing*.

## 90-day falsifiers
Specific, observable events through approximately August 2026:

- **FERC certificate orders on SSE4 and Mississippi Crossing by July 31, 2026** (FERC scheduling order already issued [1]). Slippage past August would be a meaningful negative signal on the permitting tailwind.
- **Copper State Connector FID announcement** — KMI has guided "late 2026"; an earlier sanctioning would push backlog through $14B and pull forward EBITDA visibility (UBS modeled +$750M [9]).
- **Q2 2026 earnings (mid-July): backlog change.** Look for: net adds >$500M (bullish); net adds <$200M or shadow-backlog conversion deceleration (bearish). Track explicit data-center project count vs. Q1 2026's 3 added.
- **GE Vernova / Siemens Energy turbine bookings update for Q2 2026.** GE Vernova reaching ~110 GW backlog by mid-year would confirm the bottleneck duration thesis [3]; deceleration would weaken it.
- **Hyperscaler Q2 capex guidance (Microsoft, Meta, Google, Amazon — late July/early August).** A >10% sequential cut in aggregate 2027 capex implies the AI baseload demand model has softer underwriting than current.
- **NRC construction permit decision on TerraPower Natrium (expected 1H26 [8]).** A decision pulled into this window with an aggressive COD (2029) would mark the start of the SMR substitute timeline; a slip would extend the gas window.
- **Insider transactions filings** — continued net selling at >2x the trailing 12-month rate would be a marginal negative signal.

## What I could not verify
- KMI's specific contracted vs. uncontracted revenue split on the $10.1B backlog — the company discloses 92% gas / "majority firm" but not a take-or-pay percentage by project.
- The exact KMI share of the SoftBank/Piketon Ohio gas infrastructure capex (sources confirm KMI is the "sole midstream company" but do not quantify the lateral or capex commitment [9]).
- Independent verification of the "5.6x backlog EBITDA multiple" — comes from the company's own guidance [5], not a third party.
- Whether new long-term firm-transport contracts being signed in 2026 carry 10-year vs. 15-year vs. 20-year primary terms in the data-center segment specifically — material to stranded-asset risk modeling.
- Specific CO2 / Products Pipelines / Terminals segment exposure to AI — these are smaller segments (~25% of EBITDA combined) and likely indifferent, but I did not verify segment-level commentary.
- Whether KMI is bidding for behind-the-meter equity participation (turning a tariff into an equity stake) on any active project — sources suggest the tariff model is preserved, but Williams's pivot raises the question whether KMI follows.
- Any AMD/NVIDIA/hyperscaler-level corroboration of which specific data-center campuses KMI's three Q1 2026 added projects serve.

## Sources
[1] https://naturalgasintel.com/news/natural-gas-story-has-legs-as-data-centers-spur-kmi-pipeline-expansions-says-kinder/ — retrieved 2026-05-10 — KMI's >5 Bcf/d power discussions, 1.6 Bcf/d data-center pipeline, 40% US gas market share
[2] https://finance.yahoo.com/quote/KMI/ — retrieved 2026-05-10 — current price $31.39, market cap, 52-wk range
[3] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — GE Vernova 80→100 GW backlog, sold out through 2030, Siemens Energy €136B backlog, 65% data-center share of orders
[4] https://www.americanactionforum.org/insight/ai-data-center-power-surge-shifting-trends-toward-natural-gas/ — retrieved 2026-05-10 — HV substation lead times, transformer 5-yr backlog, 12 GW announced vs. 5 GW under construction
[5] https://rbnenergy.com/daily-posts/analyst-insight/q1-2026-earnings-calls-kinder-morgan — retrieved 2026-05-10 — $10.1B backlog, 5.6x EBITDA multiple, 92% gas, Q1 2026 financials
[6] https://www.power-eng.com/gas/williams-pushes-deeper-into-power-generation-as-data-center-demand-accelerates/ — retrieved 2026-05-10 — Williams Project Socrates, $5B power innovation budget
[7] https://naturalgasintel.com/news/kinder-morgan-greenlights-permian-gcx-expansion-amid-stubbornly-weak-waha-natural-gas-prices/ — retrieved 2026-05-10 — GCX expansion, Waha basis differentials
[8] https://world-nuclear.org/information-library/nuclear-power-reactors/small-modular-reactors/small-modular-reactor-smr-global-tracker — retrieved 2026-05-10 — TerraPower Natrium 1H26 NRC permit, X-energy Xe-100, SMR commercial timing
[9] https://enkiai.com/data-center/gas-to-power-boom-ai-drives-2026-on-site-energy-shift/ — retrieved 2026-05-10 — Behind-the-meter strategy, SoftBank Piketon 9.2 GW, KMI sole midstream, Energy Transfer/Meta deal
[10] https://www.morganlewis.com/pubs/2026/05/federal-energy-priorities-reset-the-rules-for-us-permitting — retrieved 2026-05-10 — FERC NEPA timeline reduction ~30%, 2025 GHG policy withdrawal
[11] https://stockanalysis.com/stocks/kmi/forecast/ — retrieved 2026-05-10 — analyst PT $33.81, 16 analysts Buy, EV $107B, EV/EBITDA 11.9x
[12] https://en.wikipedia.org/wiki/Kinder_Morgan — retrieved 2026-05-10 — 65,000–72,000 mile system, 40% US gas, 95% fee-based contract structure
[13] https://www.businesswire.com/news/home/20251208490866/en/Kinder-Morgan-Announces-2026-Financial-Expectations — retrieved 2026-05-10 — 2026 EPS guide $1.36, dividend $1.19, leverage 3.6x, target 3.5–4.5x
[14] https://www.tikr.com/blog/why-kinder-morgan-stock-is-up-double-digits-in-early-2026-and-could-have-34-more-gains-ahead — retrieved 2026-05-10 — YTD return ~+19%
[15] https://www.tradingview.com/news/stockstory:35b922969094b:0-kmi-q1-deep-dive-natural-gas-demand-and-expansion-projects-drive-outperformance/ — retrieved 2026-05-10 — Q1 2026 deep-dive, 90% pipe utilization, 8% transport volume growth
[16] https://www.tradingpedia.com/2026/04/24/kinder-morgan-cash-flow-strength-supports-upside-outlook/ — retrieved 2026-05-10 — Short interest 2.5%, institutional ownership >60%, net buyers 2:1