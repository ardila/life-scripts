# MPWR — Monolithic Power Systems

## Where this sits in the AI stack
MPWR is a fabless analog/mixed-signal IC designer whose AI-relevant products sit at the **"last inch" of the power delivery chain**: multiphase buck-converter controllers, smart power stages (DrMOS), and increasingly module-level voltage regulators that step the 48–54 V intermediate bus down to the ~0.65–0.8 V core rail at hundreds-to-1000+ amperes immediately adjacent to each NVIDIA, AMD, or custom ASIC accelerator die [1][2][14]. They are not in HBM, not in compute silicon, not in the optical or NVLink fabric — they convert volts to amps within the few centimeters between PDB and package. Workload exposure is GPU/XPU training and inference racks (where each accelerator burns 700–1400 W), plus a growing optical-module power and 48 V intermediate-bus business that the company books under "Enterprise Data" and "Communications" [3][4].

## Snapshot
- **Price:** $1,588.12 (2026-05-08 close) [5]
- **Market cap:** $78.65B (49.13M shares outstanding) [5][8]
- **52-week range:** $630.62 – $1,662.00 [6]
- **Forward P/E:** ~74× on FY26 consensus normalized EPS of $21.57; ~61× on FY27 EPS of $25.92 [7]
- **EV / NTM revenue:** ~20× (EV ≈ $77B net of ~$1B cash; NTM revenue ~$3.85B implied from 2026 consensus of $3.70B and 2H acceleration) [7][3]
- **Consensus 12-month price target:** ~$1,597–$1,797 depending on aggregator; bracketed by KeyBanc $2,000 (high) and TipRanks median $1,425 (low) — implied range −10% to +13% from spot [9][10]
- **YTD total return:** +68% to +78% depending on source; +174% trailing 12-month vs. S&P 500 +30% [6][11]
- **Short interest:** ~2.6% of float — below peer average of ~4.0% [12]

## Moat — what it is physically made of
The most common analyst description ("MPWR has a moat in analog because analog is hard") is too lazy to act on. The moat decomposes into four physical/IP components, each with different durability:

**1. Proprietary BCD process portfolio installed on partner foundries.** MPWR's central technical asset is its own Bipolar-CMOS-DMOS (BCD) process modules — not the off-the-shelf BCD that TSMC, Hua Hong, and others license to customers, but custom flows MPWR developed and **installed on its foundry partners' equipment** [13]. BCD integrates bipolar (precision analog), CMOS (logic/control), and DMOS (high-voltage/high-current power FETs) on the same die. The competitive variable is on-resistance × area (Rdson·A) and switching loss at the operating frequency that lets you put more amps through less silicon at higher MHz. MPWR has iterated this for 25+ years; competitors using standard foundry BCD generally trail on Rdson·A by a generation. **Durability:** high but not absolute — Infineon (IDM, OptiMOS), TI (LBC), onsemi, and Renesas (R-Power) each have their own integrated power-process IP. This is a process-physics moat, not a network-effects moat. Inference, not cited.

**2. System-level co-engineering relationships.** MPWR ships customers a full power-delivery network design, not just chips: phase count, layout, PCB stackup recommendations, thermal modeling, telemetry firmware. NVIDIA's reference designs for Hopper and Blackwell HGX baseboards were built around MPWR's MPS multiphase + DrMOS reference [14]. Replicating that co-design relationship requires both silicon parity *and* applications-engineering bench depth. **Durability:** moderate — the Edgewater Research report in late 2024 that flashed Blackwell power-delivery quality issues, followed by NVIDIA pulling significant GB200 PMIC share to Infineon (estimated 60–70%) and the entire GB200 PDB module to Renesas, demonstrated that hyperscaler customers will dual- or triple-source aggressively when stakes are high [14][15]. The co-design relationship was a moat, until it wasn't.

**3. Time-to-market on new silicon.** MPWR has historically released next-generation controller/DrMOS families ahead of competitors at any given node — the fabless-lite model lets them pull a new process module forward without owning the fab capex cycle. **Durability:** moderate — Infineon's TLVR (Trans-Inductor Voltage Regulator) quad-phase modules (TDM24745T, 320 A peak in a compact module) [16] and Renesas's PDB win on GB200 show that competitors are now matching or leading at the architecture level, not just catching up on silicon.

**4. Customer/end-market diversification giving capital for analog R&D.** Roughly two-thirds of revenue is still automotive, industrial, storage, and consumer power — this funds the analog talent base. Pure-play AI competitors (e.g., Vicor) lack this. **Durability:** structural; least at risk.

Not a moat, despite being commonly cited: **scale/brand**. MPWR has ~4,000 employees [17], small versus Infineon (~58k), TI, or Renesas. The brand exists only inside hardware-engineering teams.

What MPWR **does not** have: an ecosystem switching-cost moat in the CUDA sense. There is no kernel library, no compiler stack, no developer base that retrains on MPWR-specific abstractions. A board designer can re-spin a baseboard around Infineon TDM24745T modules in roughly 1–2 quarters, and that has now happened in production [14][16].

## AI buildout bottleneck map
- **Grid interconnect & power generation (24-month gating).** Real bottleneck; gas-turbine backlogs into 2028+, transmission queues 4–7 years. MPWR position: **indifferent** — they sell into the rack regardless of where the electrons come from, and the 800 V HVDC transition (below) gives them new dollar content per rack rather than less.
- **CoWoS-L advanced packaging (TSMC).** Real bottleneck; B200/B300/Rubin all depend. MPWR position: **indifferent** — their parts ship from non-CoWoS lines.
- **HBM3e/HBM4 supply.** Bottleneck. MPWR position: **indifferent.**
- **Liquid cooling at >100 kW/rack.** Becoming acute; GB300 NVL72 ≈ 120 kW, Kyber/Rubin Ultra targeting ~600 kW–1 MW/rack [4][18][19]. MPWR position: **beneficiary** — higher rack density requires *more* power-conversion silicon per rack, and the move to vertical/near-package conversion is incremental dollar content.
- **800 V HVDC architecture for 1 MW racks (Vera Rubin/Kyber, 2027 production).** Architectural step-change. NVIDIA's published roadmap converts 13.8 kV AC → 800 VDC at the data hall perimeter, then 800 V → 54 V → core voltage at the rack/board [20]. MPWR is listed as one of ~14 named silicon partners (Analog Devices, Infineon, Innoscience, MPS, Navitas, onsemi, Renesas, ROHM, ST, TI, et al.) — i.e., one of many [20]. **Position: exposed.** The 800→54 V step is a new socket likely to be won by SiC/GaN specialists (Navitas, Infineon, Innoscience); the 54→1 V last-inch is MPWR's defensive position.
- **Vertical power delivery / power-on-package.** Vicor's ITC win (Feb 2025) against Delta, Quanta, Foxconn affiliates for patents 9,516,761 and 9,166,481 establishes that Vicor controls foundational IP on factorized/vertical 48 V power delivery [21]. MPWR was not named — but if NVIDIA or hyperscalers move VPD to mainstream, the IP topology matters. **Position: exposed but not directly sued.**
- **Kernel/compiler/training-data talent.** MPWR position: **indifferent.**

Net: MPWR is exposed to the *power-architecture* transition itself (which converter sits where in the chain), not to the more famous capacity bottlenecks. That is where to focus the thesis.

## Competitive teardown
**Infineon Technologies (IFX).** *Won the GB200 PMIC battle*. Reported 60–70% PMIC share on GB200 after the Edgewater event flagged Blackwell power-delivery issues on MPWR silicon [14][15]. Technical axis: Infineon's TLVR architecture (TDM2354xT 160 A; TDM24745T 320 A peak quad-phase) magnetically couples phase inductors to improve large-signal transient response and cut output capacitance by up to 50% [16][22]. That is a real architectural advantage at the >1 kW-per-accelerator current step domain. Infineon is also a named NVIDIA partner for the 800 V HVDC central conversion using SiC/GaN [20][23] — the deepest competitive exposure for MPWR.

**Renesas (6723.T).** *Won the GB200 Power Distribution Board socket exclusively*. PDB module is 8 kW per compute tray, two 4 kW DC-DC converters, ~$250 BOM per module [14]. MPWR has explicitly tried and failed to enter this PDB tier. Technical axis: PDB is a board-level integration product; Renesas leveraged its module/Intersil heritage. As long as NVIDIA keeps a dedicated PDB stage (likely through GB300 and into Rubin), this revenue is structurally not MPWR's.

**Vicor (VICR).** *Holds the architecturally most aggressive IP*. Vertical Power Delivery: place a current-multiplier module *underneath* the processor, cutting PDN resistance ~10×, freeing PCB topside for I/O and memory [24]. Vicor won the H100 socket initially, lost it to MPWR (lateral multiphase was cheaper) [1], and is now positioning for higher-current generations. The ITC ruling barring infringing power modules into the U.S. is a real strategic asset. *Vicor has not asserted these patents against MPWR specifically*, but if MPWR pursues true VPD (Gen 5 modules reportedly entering production with one lead customer in Q1 2026, per third-party supply-chain research [14]), IP exposure is non-trivial.

**Texas Instruments (TXN), onsemi (ON), Analog Devices (ADI).** Broader analog incumbents. None has the focused AI-power-conversion R&D depth that MPWR has built; all are credible second-sources at the controller/DrMOS level. ADI's LTC heritage is the most technically dangerous on the controller side.

**Navitas / Innoscience / Power Integrations.** GaN specialists; relevant only to the *new* 800 V → 54 V tier, not MPWR's traditional space. But that tier is where the 2027+ socket value migrates.

The honest read: MPWR has *parity or slight deficit* against Infineon on the largest current Blackwell content; *no presence* in the PDB tier (Renesas); *foundational IP exposure* against Vicor on the most aggressive next-step topology; and *one of many* in the 800 V HVDC ecosystem. The recovery to 97.7% YoY Enterprise Data growth in Q1 2026 [3] is real, but it is a regain from a low base, not a return to monopoly economics on Blackwell.

## Bull case — technical
The bull thesis requires three conditions to hold concurrently:

(1) **MPWR ships into a meaningful share of GB300 / B300 power delivery and into the Rubin (R100, sampling Q4 2026; production Q1 2027) socket** [25]. The Q1 2026 Enterprise Data revenue of $262.8M (+97.7% YoY) and the company raising its 2026 Enterprise Data growth floor to ~85% YoY [2][3] are the leading indicators that this is happening. They imply MPWR is at least a qualified second-source on GB300 and likely back to majority share on at least one Blackwell-Ultra subsystem. If verified at GTC and at NVIDIA's earnings disclosures over the next two quarters, the GB200 narrative reverses.

(2) **Per-XPU dollar content rises faster than unit growth.** Each generational power step (700 W H100 → 1 kW B200 → 1.4 kW GB300 → ~1.8 kW Rubin per published roadmaps [25][26]) requires more phases, more current density, and module-level integration. Independent supply-chain research puts vertical-power-delivery per-XPU opportunity at $200–$400 [14], in addition to traditional VRM content. If MPWR captures Gen 5 VPD design wins (one lead customer already in production [14]) the ASP per accelerator could rise materially.

(3) **The 800 V HVDC transition lands incrementally, not as a step-change displacement.** If NVIDIA's Kyber-rack architecture for Vera Rubin (2027) keeps the 54 V → core-voltage last-inch architecturally intact while only changing the upstream conversion chain [20], MPWR keeps its socket and gains content from higher per-rack accelerator count (Kyber = 576 Rubin Ultra GPUs per rack [27]).

Base rate on tech-displacement at this stage of a buildout: historical analog incumbents (Linear Tech in 2000s, Maxim in 2010s) generally hold for 2–3 product cycles even after a flagged quality event, because hyperscalers' replacement cost is real and the technical work isn't cheaply re-spun. The Q1 2026 print is consistent with that pattern. **Financial outcome:** if Enterprise Data grows ~85% in 2026 and reaccelerates in 2027 on Rubin ramp, revenue can reach $4.5–5.0B in 2027 (vs. $3.7B 2026 consensus) and EPS $30+ — supporting current ~$1,600 price at a 55–60× P/E that compresses gracefully as growth normalizes.

## Bear case — technical
The bear thesis only needs one of three to break.

(1) **The Blackwell-quality issue was structural, not transient.** The Edgewater Research call in Nov 2024 specifically tied MPWR's issue to >700 W operating power [15] — implying their existing BCD/DrMOS package could not handle the higher transient di/dt of Blackwell-class loads at the required transient response. Infineon's TLVR architecture is *physically* better-suited to fast transients (coupled-inductor topology cuts response time by design). If Rubin (1.8 kW class, even larger di/dt) repeats the issue, MPWR loses share again at the worst possible moment. **Falsifier:** NVIDIA Rubin reference designs at GTC 2026/27 — observe which vendors are anchored on the reference baseboard.

(2) **PDB-tier value migrates further upstream and MPWR can't follow.** Renesas's 8 kW PDB module already cut MPWR out of one entire conversion stage on GB200. The 800 V HVDC transition adds *another* upstream stage (800 V → 54 V) that MPWR is one of many in but has no track record of dominating. If hyperscalers consolidate more value into pre-package modules — which is what Vicor's VPD roadmap and Infineon's central-conversion roadmap both imply — MPWR's last-inch fortress shrinks. Per-socket dollar content stagnates while unit growth continues.

(3) **Vicor's VPD IP becomes load-bearing as power densities cross the breakpoint.** The lumped impedance argument for VPD (10–20× lower PDN resistance vs. lateral [24]) is physics, not marketing. Once per-accelerator currents cross some threshold (probably ~1500–2000 A at sub-0.7 V), lateral multiphase loses on efficiency and PCB area, and you have to go vertical or on-package. If MPWR can't deliver a competitive VPD product without infringing Vicor patents, they either license (margin hit) or get blocked (revenue hit).

Base rate counterpoint: customer concentration at NVIDIA + Big 4 hyperscalers means a single ASIC vendor decision can swing 15–25% of MPWR revenue in two quarters. 2024Q4's stock crash from ~$900 to ~$500 [15] is the relevant precedent for how that resolves on a single Edgewater-class data point.

**Financial outcome under bear case:** if Enterprise Data growth slows from +97% to +20% in 2H 2026 on Infineon/Renesas continuing to absorb Rubin sockets, 2027 revenue could land $3.8–4.0B (vs. bull $4.5–5.0B), EPS plateau at $22–25, and the multiple compresses to 30–40× — implying a $700–1,000 stock.

## Market view check
At $1,588 / ~74× FY26 normalized EPS / ~61× FY27 / ~20× EV/NTM revenue, the market is pricing MPWR as if it has fully regained Blackwell share, will ship into Rubin at par, captures meaningful VPD content on top, and that the 800 V HVDC transition is incremental rather than displacement. That is a coherent thesis, but it is the *full* bull case priced in. The price is no longer compensating you for the Edgewater-class risk that put a $500-handle on the stock 18 months ago. The market appears to be believing MPWR's moat is closer to TSMC's CoWoS-L position (irreplaceable in this cycle) than to what it actually is: a strong but contested last-inch analog franchise with a recent demonstrated track record of losing a major socket to competitors. The asymmetry has flipped from positive (late 2024) to neutral-to-negative (now). This is not a setup where the technical thesis and the price are out of step in your favor.

## 90-day falsifiers
- **NVIDIA Computex / GTC announcements (~late May/June 2026):** any disclosure of named power-delivery partners for Rubin reference designs. Presence/absence of MPWR on the reference HGX or NVL board for Rubin is directly observable.
- **NVIDIA Q2 FY27 earnings (mid-Aug 2026):** GB300 ramp commentary, Rubin sampling status, any commentary on supply-chain qualification.
- **MPWR Q2 2026 earnings (~late July 2026):** must hit $890–910M guide [3]; watch Enterprise Data sequential growth (>$315M would imply continued share regain, <$280M would imply guide-down risk). Critically: any commentary on "second design wins at our largest customer" or specific VPD module shipping.
- **Infineon FY26 Q3 earnings (Aug 2026):** AI-PMIC commentary. If Infineon raises AI revenue guidance materially, that is share *not* going to MPWR.
- **Vicor litigation:** any new ITC complaint naming MPWR or naming an NVIDIA contract manufacturer with MPWR content — would materially change IP risk.
- **Hyperscaler capex revisions:** META, MSFT, GOOG, AMZN Q2 2026 capex prints in late July. A combined sequential reduction of >10% would be a regime change for all AI-power names. Concentrated reduction at one hyperscaler matters less.
- **GB300 production rate:** TrendForce / Asian supply-chain channel checks on whether GB300 hits the projected 60k-rack 2026 number [25].

## What I could not verify
- **MPWR's exact GB200 vs. GB300 share split.** "60–70% Infineon on GB200" comes from third-party supply-chain research (Global Tech Research, SemiAnalysis paywalled) [14][1] but I could not get a primary-source confirmation from MPWR or NVIDIA. The +97.7% Enterprise Data Q1 print is consistent with regain but does not specify which design wins drove it.
- **MPWR's per-XPU dollar content** on B200/GB200/GB300. The $200–$400 VPD opportunity is cited [14] but I lack vendor-confirmed BOM data.
- **Whether MPWR's Gen 5 VPD product infringes Vicor patents.** Vicor has not asserted; absence of evidence is not evidence of absence. Inference, not verified.
- **MPWR's foundry node and capacity allocation.** Multi-foundry "fabless-lite" with proprietary BCD is documented [13][17]; specific TSMC node / Hua Hong / GlobalFoundries split and 2026 wafer allocation is not publicly broken out.
- **Customer concentration in the 10-K.** The 2024 10-K discloses "92% of revenue from Asia customers" and names significant distributors, but the indirect channel structure means actual NVIDIA / hyperscaler concentration as end-customer is opaque from filings alone. Inference: NVIDIA + Big 4 hyperscalers indirect is plausibly 30–45% of total revenue today and rising.
- **Whether the SemiAnalysis paywalled note on power delivery contains specific market-share datapoints I could not access** — it almost certainly does, and I would weigh the thesis differently with that read.

## Sources
[1] https://newsletter.semianalysis.com/p/energizing-ai-power-delivery-competition — retrieved 2026-05-10 — SemiAnalysis on power delivery competition (preview only; established MPWR/Vicor H100 socket history and 700 W/0.8 V/875 A baseline numbers).
[2] https://finance.yahoo.com/markets/stocks/articles/monolithic-power-systems-inc-mpwr-072022640.html — retrieved 2026-05-10 — MPWR Q1 2026 Enterprise Data $262.8M / +97.7% YoY confirmation.
[3] https://www.investing.com/news/transcripts/earnings-call-transcript-monolithic-power-systems-q1-2026-beats-forecasts-93CH-4651648 — retrieved 2026-05-10 — Q1 2026 results $804M, +26% YoY, Q2 guide $890–910M, GM 55.1–55.7%, 85% Enterprise Data growth floor.
[4] https://developer.nvidia.com/blog/how-new-gb300-nvl72-features-provide-steady-power-for-ai/ — retrieved 2026-05-10 — GB300 NVL72 65 J/GPU energy storage, LITEON cap vendor, 30% peak grid demand reduction; ~120 kW per rack.
[5] https://stockanalysis.com/stocks/mpwr/forecast/ and aggregator search — retrieved 2026-05-10 — MPWR May 8 2026 close $1,588.12, market cap $78.65B, 49.13M shares.
[6] https://www.macrotrends.net/stocks/charts/MPWR/monolithic-power-systems/stock-price-history — retrieved 2026-05-10 — 52-week range $630.62–$1,662; YTD 2026 +68–78%, TTM +174%.
[7] https://simplywall.st/stocks/us/semiconductors/nasdaq-mpwr/monolithic-power-systems — retrieved 2026-05-10 — 2026 normalized EPS $21.57, 2027 $25.92, 2026 consensus revenue $3.70B.
[8] https://companiesmarketcap.com/monolithic-power-systems/shares-outstanding/ — retrieved 2026-05-10 — Share count.
[9] https://www.marketbeat.com/stocks/NASDAQ/MPWR/forecast/ — retrieved 2026-05-10 — Average price target $1,599; recent revisions (Raymond James $1,800, TD Cowen $1,850, KeyBanc $2,000, Truist $1,805).
[10] https://www.tipranks.com/stocks/mpwr/forecast — retrieved 2026-05-10 — TipRanks aggregate price target ~$1,425.
[11] https://www.financecharts.com/stocks/MPWR/performance/total-return — retrieved 2026-05-10 — Total return performance metrics.
[12] https://www.moomoo.com/news/post/35180066/mpwr-analyzing-monolithic-power-systems-s-short-interest — retrieved 2026-05-10 — Short interest ~2.6% of float vs peer 4.0%.
[13] https://www.tsmc.com/english/dedicatedFoundry/technology/specialty/bcd — retrieved 2026-05-10 — TSMC BCD process portfolio (context for industry-standard BCD vs MPWR's proprietary process).
[14] https://globaltechresearch.substack.com/p/nvidia-nvda-us-gb300-vera-rubin-and — retrieved 2026-05-10 — Supply-chain detail on GB200 PDB (Renesas exclusive, 8 kW, $250 BOM), Infineon 60–70% PMIC share, VPD Gen 5 in production Q1 2026, $200–$400 per-XPU VPD opportunity.
[15] https://finance.yahoo.com/news/monolithic-power-falls-amid-risk-205430868.html — retrieved 2026-05-10 — Edgewater Research Nov 2024 note; Blackwell >700 W power tied to MPWR component issues, share reallocated to Renesas/Infineon.
[16] https://www.allaboutcircuits.com/news/infineon-unwraps-high-density-tlvr-modules-for-data-centers/ — retrieved 2026-05-10 — Infineon TDM2354xT (160 A) and TDM24745T (320 A) TLVR module specs.
[17] https://en.wikipedia.org/wiki/Monolithic_Power_Systems — retrieved 2026-05-10 — Company history, founder Michael Hsing, ~4,000 employees, fabless-lite model with proprietary processes on partner foundries.
[18] https://www.datacenterdynamics.com/en/news/nvidia-prepares-data-center-industry-for-1mw-racks-and-800-volt-dc-power-architectures/ — retrieved 2026-05-10 — 1 MW racks and 800 VDC roadmap context.
[19] https://www.sunbirddcim.com/blog/how-much-power-does-nvidia-gb300-nvl72-need — retrieved 2026-05-10 — GB300 NVL72 ~120 kW per rack.
[20] https://developer.nvidia.com/blog/nvidia-800-v-hvdc-architecture-will-power-the-next-generation-of-ai-factories/ — retrieved 2026-05-10 — 800 V HVDC architecture spec, 13.8 kV→800 V perimeter conversion, named silicon partners list including MPS, Infineon, Renesas, Navitas, etc.
[21] https://www.vicorpower.com/press-room/itc-bars-importation-of-power-modules — retrieved 2026-05-10 — ITC Feb 13 2025 final determination, exclusion order on Delta, Cyntec, Foxconn, Quanta, Ingrasys for patents 9,516,761 and 9,166,481.
[22] https://www.electronicdesign.com/technologies/power/article/55012693/electronic-design-inside-infineons-dual-phase-power-modules-for-ai-power-delivery — retrieved 2026-05-10 — TLVR magnetic-coupling architecture, transient-response and capacitance-reduction physics.
[23] https://www.infineon.com/press-release/2025/INFXX202505-107 — retrieved 2026-05-10 — Infineon press release on NVIDIA 800 V HVDC collaboration, GaN/SiC role.
[24] https://www.vicorpower.com/resource-library/articles/high-performance-computing/vertical-power-delivery-enables-cutting-edge-processing — retrieved 2026-05-10 — Vicor technical paper on VPD: ~10× PDN resistance reduction, 20× lumped impedance benefit vs lateral.
[25] https://www.kad8.com/ai/nvidia-blackwell-ultra-gb300-shipments-set-to-surge-in-2026/ — retrieved 2026-05-10 — GB300 shipment forecasts and Rubin sampling (Q4 2026) / production (Q1 2027) timeline.
[26] https://glennklockwood.com/garden/processors/B300 — retrieved 2026-05-10 — B300/GB300 TDP figures (1.2 kW HGX / 1.4 kW GB300) and architecture context.
[27] https://blogs.nvidia.com/blog/gigawatt-ai-factories-ocp-vera-rubin/ — retrieved 2026-05-10 — Kyber rack architecture, 576 Rubin Ultra GPUs per rack.