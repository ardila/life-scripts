I have enough to write the dossier. Drafting now.

# SNPS — Synopsys, Inc.

## Where this sits in the AI stack
Synopsys sells the **silicon-design software and silicon-proven IP blocks** that sit one layer above the foundry: every advanced-node AI accelerator — NVIDIA Blackwell/Rubin, AMD MI300/MI400, Google TPU v5/v6, AWS Trainium2/3, Meta MTIA, Microsoft Maia, Broadcom's hyperscaler ASICs — is taken from RTL to GDSII through a flow built almost entirely from Synopsys and Cadence tools, with Synopsys-licensed PHYs (HBM, PCIe, 224G SerDes, UCIe) instantiated on-die [1][9]. They do not sell training compute, fabs, or runtimes. Their workload is the months-long, signoff-quality design cycle for any chip taped out at TSMC N3/N2/A16, Samsung SF2, or Intel 18A — both frontier training silicon and inference ASICs. Post-Ansys (closed July 17, 2025), they also own the multiphysics simulation stack (thermal, electromagnetic, mechanical) that signs off 3D-stacked CoWoS-L packages [3].

## Snapshot
- **Price:** $516.48 (2026-05-08 close; 2026-05-10 is Sunday) [1]
- **Market cap:** $98.94B [1]
- **52-week range:** $376.18 – $651.73 [1]
- **Forward P/E:** ~35× on FY26 consensus EPS $14.42 (guidance midpoint $14.38–14.46) [1][2]
- **EV / NTM revenue:** ~10–11× (market cap ~$99B + net debt ~$10B from Ansys deal ÷ FY26 guide ~$9.6B) — inference from disclosed cap structure [2][4]
- **Consensus 12-month price target:** $480 (trimmed from $550); implied **–7%** vs. spot [1]
- **YTD total return:** –10.5% [1]
- **Short interest (% of float):** 2.35% (4.48M shares, April 15, 2026) [14]

## Moat — what it is physically made of
The "EDA moat" is glib. The actual moat decomposes into seven distinct layers, each with different durability:

**1. Foundry co-certification and PDK depth.** For each TSMC node (N3, N2, A16, A14), Synopsys ships *certified* digital and analog flows months before customer tape-out begins. The certification is not marketing — it's months of bug-fixing against TSMC's actual silicon corners, OPC models, BEOL stack, and FinFlex / GAA device models. The current production list includes 3DIC Compiler for CoWoS-L up to 5.5× reticle interposers, Totem-SC for analog power integrity at N2, and PathFinder-SC for multi-die ESD signoff at N2 [7]. Replicating this requires (a) TSMC sharing un-redacted PDKs, which they only do with a handful of trusted partners, and (b) ~5–10 years of accumulated silicon correlation data. *Highly durable.*

**2. The 12-stage digital implementation flow.** Synthesis (Fusion Compiler / Design Compiler) → floorplan → placement → CTS → routing → parasitic extraction (StarRC) → timing signoff (PrimeTime — the de facto industry standard for ~20 years) → power signoff → physical verification (IC Validator) → DRC/LVS → EM/IR → ESD. Each is 100–500 person-years of engineering. The handoffs between stages encode an opinionated methodology; mixing best-of-breed tools across stages historically degrades quality of results by 5–15%. *Highly durable: replicating one stage takes a decade; replicating all of them at parity is an industry, not a startup.*

**3. Verification platforms.** VCS simulator, Verdi debug, ZeBu emulation, HAPS prototyping. ZeBu and HAPS are hardware FPGA boxes deployed at customer sites — physical capex commitments that lock customers in for emulation cycles measured in years. Verification is now ~70% of frontier-chip design effort; Synopsys + Cadence have a duopoly here too. *Durable, with the additional moat of hardware-supply contracts.*

**4. DesignWare IP (silicon-proven PHYs).** Pre-laid-out, silicon-characterized hard IP for HBM3/3e/4 controllers + PHYs, PCIe 7.0/8.0, UCIe 1.1/2.0/3.0, 224G/112G SerDes, USB, MIPI, DDR5/6 — already taped out on N3/N2 at TSMC and Samsung [10]. Synopsys reported 40+ PCIe design wins and 10 lifetime wins for 224G SerDes on advanced nodes by Q1 FY26 [10]. Replacing one of these IP blocks in an AI accelerator design requires its own silicon characterization cycle (typically 12–18 months and a test chip). *Durable per design, but customers do swap IP vendors at chip-program boundaries — this is the least sticky moat layer and is where ARM, Rambus, Alphawave compete.*

**5. Multiphysics signoff (post-Ansys).** Ansys closed July 17, 2025 for $35B [4]. The promised integration — Multiphysics-Fusion — bundles RedHawk-SC (power integrity), HFSS (electromagnetic), Mechanical (thermal/warpage), and SeaScape (compute backbone) into the 3DIC Compiler signoff flow. Production GA is promised for H1 2026; Q1 FY26 results put initial customers in beta [3][11]. The strategic logic: in 3D-stacked CoWoS-L designs, thermal hotspots and warpage are signoff items, not afterthoughts, and customers were previously co-iterating with two vendors at unbearable round-trip cost. *If integration ships as advertised, this is the most strategically important moat addition in 15 years — a competitor cannot replicate without buying or rebuilding Ansys, which is what Cadence is attempting with Beta CAE + organic build-out.*

**6. AI flows: DSO.ai + Copilots + AgentEngineer.** DSO.ai (RL-driven RTL-to-GDSII space optimization, 2020 launch) has ~5,000 active users at Tier-1 customers; one disclosed case reduced 5nm design optimization from 6 months to 6 weeks [8][17]. Synopsys.ai Copilot reported 40+ customers, 20K+ active users, 5M+ queries, and 2–5× productivity gains by Q1 FY26 [17]. AgentEngineer (L4 multi-agent orchestration) was demoed at Converge 2026 and is co-developed with AMD [17]. *Moderately durable: the algorithm space is publicly understood (RL + LLM agents on tool APIs), but training data — millions of real production runs at advanced nodes — is the actual moat, and only Synopsys + Cadence have it.*

**7. NVIDIA equity partnership.** December 1, 2025: NVIDIA bought $2B of SNPS common at $414.79 (~5M shares, ~2.5% ownership) plus a multi-year joint development agreement to GPU-accelerate the EDA stack via CUDA-X libraries (cuLitho-style acceleration applied to parasitic extraction, lithography simulation, EM solvers) and integrate AgentEngineer with NVIDIA's agentic stack [12][20]. *Non-exclusive* — Cadence has its own NVIDIA partnership (ChipStack AI SuperAgent) [12]. This is NVIDIA hedging across both EDA vendors and signaling that AI-accelerated EDA is the strategic compute bucket they care about. The signal value (and the optics of NVIDIA owning the upstream design tool that designs its competitors' silicon) matters at least as much as the joint engineering.

**Switching cost arithmetic.** A re-spin at N2 due to a tool signoff bug costs $20–50M in mask sets and 12–18 months of slip — chip-program economics, not tool-license economics. Engineering teams accumulate methodology specific to a tool flow over 5–10 years. The actual customer-level decision is never "switch from Synopsys to vendor X"; it's "diversify a specific stage to vendor Y at the next chip program," which happens but is slow. Industry retention is reported at near-100% with 80–85% recurring revenue [9].

## AI buildout bottleneck map
Mapping the actual 24-month gating constraints against Synopsys's position:

- **CoWoS-L allocation at TSMC** — fully booked through 2026, ramping from ~75–80k wafers/month today to a target 120–130k by end-2026 [13]. **Synopsys is an indirect beneficiary**: every CoWoS-L design ships through 3DIC Compiler + Multiphysics-Fusion. The constraint is at TSMC, not at the EDA layer; more capacity = more design starts = more Synopsys revenue.
- **HBM3e/HBM4 supply** (SK hynix, Samsung, Micron) — secondary bottleneck even as CoWoS scales [13]. **Synopsys is a beneficiary**: every HBM stack on a package requires an HBM controller + PHY, often licensed from Synopsys.
- **Advanced node capacity (N3/N2/A16/A14)** — chip design starts at the leading edge are growing in count and complexity. **Direct beneficiary**: tool ASP per design scales with node complexity (more rule decks, more multi-patterning, more RC corners, more 3D-IC).
- **Hyperscaler custom-silicon program count** — TPU v5/v6, Trainium2/3, MTIA, Maia, plus Broadcom-fabricated designs for Google/Meta/ByteDance/Anthropic. Every program is a Synopsys + Cadence customer. **Direct beneficiary; arguably the single biggest tailwind**: NVIDIA-only world is fewer chip-program starts than NVIDIA + 5 hyperscaler ASIC programs.
- **Power generation / grid interconnect / liquid cooling >100kW/rack / electrical-contractor capacity** — real constraints on the *deployment* side, **Synopsys indifferent** at the chip-design layer, with marginal Ansys upside on thermal/cooling sim.
- **Kernel/compiler talent** (CUDA, Triton, MLIR engineers) — **Synopsys indifferent**: different talent pool entirely (Verilog, SystemVerilog, UVM, physical-design engineers).
- **Frontier training-data quality** — **Synopsys indifferent**.
- **China demand / export controls** — **exposed customer side**. China was ~16% of FY24 revenue ($1B+) [5][6]; BIS export halt May 29, 2025 was rescinded July 2, 2025 after 35 days, but FY25 China revenue ended down ~18% [5][19]. *This is the one place Synopsys is a constraint owner rather than a beneficiary, and it's policy-driven, not technical.*

Net: SNPS is positioned as a **toll on the design-count of the AI buildout** rather than on any single hardware vendor's share — which is the structurally best position in the supply chain if you believe AI chip diversity grows.

## Competitive teardown
**Cadence (CDNS) — the only real peer.** Both have AI-driven P&R (DSO.ai vs. Cerebrus) with comparable disclosed productivity (10× P&R speedup, 20% PPA improvement — neither has published an independent head-to-head benchmark; both are reinforcement-learning over tool-API action spaces) [8][15]. Cadence is ahead in: custom analog (Virtuoso franchise is dominant), PCB / system-level (Allegro), and traditional system simulation. Synopsys is ahead in: digital implementation (Fusion Compiler), static timing (PrimeTime is the industry reference for ~20 years), simulation (VCS), and now multiphysics post-Ansys. Both are TSMC-certified at every node. **The duopoly is stable** at ~38% / ~36% share (or ~46% / ~35% on a tighter EDA-only definition) [9][16] — customers carry both because retraining a 500-engineer design team on a different flow takes years and risks tape-out slips. *No technical axis where one is being displaced by the other in 2026.*

**Siemens EDA (Mentor)** — distant #3 (~10–15%). Dominant only in physical verification (Calibre DRC/LVS), where it still wins routinely. Losing ground at frontier digital implementation since the late-2010s.

**Open-source (OpenROAD + ORFS-agent)** — DARPA-funded RTL→GDSII flow [18]. ORFS-agent (arXiv 2506.08332, 2025) demonstrates LLMs driving OpenROAD end-to-end for academic designs at 7nm and above. **No production tape-outs at <7nm; no signoff-quality timing; no TSMC PDK access at frontier nodes.** Base rate: open-source EDA has been "imminent" for 25+ years (Magic, Qflow, OpenLane) and has captured ~0% of leading-edge production silicon. *This is the disruption vector to watch over a 5–10-year horizon, not 24 months.*

**In-house tools (Google, Apple, NVIDIA)** — Google has internal Plotter; Apple has internal IP characterization. None replace the Synopsys+Cadence primary flow. NVIDIA's Blackwell was designed with both. *Base rate of in-house EDA replacing commercial EDA at frontier: zero in 25 years.*

**AI-native EDA startups** (Caspia, PrimisAI, Rise, Silimate, Suitera, plus academic-spinout work) — narrow point solutions, none with a full flow [16]. Magma is the cautionary base rate: it was the supposed Synopsys disruptor of the 2000s; Synopsys acquired it in 2012 for $507M. Atoptech was similar; acquired 2015. *Acquisition is the modal outcome.*

The honest concession: **Cadence has technical parity with Synopsys on most axes**, and the post-Ansys multiphysics advantage is the one axis Synopsys is currently widening — and that advantage takes until Multiphysics-Fusion GA (H1 2026, per management) to be customer-validated.

## Bull case — technical
The technical conditions for the bull case:
1. **AI design-start count grows**, not just AI wafer volume — hyperscaler custom-silicon programs at Google, AWS, Meta, Microsoft, plus emerging entrants (Anthropic / OpenAI rumored TPU-class programs, sovereign-AI silicon programs in EU and ME) each add a Synopsys customer.
2. **Chiplet / 3D-IC becomes the dominant scaling vector** post-N2 (because monolithic reticle limits are binding). 3DIC Compiler + UCIe IP + Multiphysics-Fusion become required, not optional, signoff items.
3. **Multiphysics-Fusion ships on schedule (H1 2026)** with NVIDIA / AMD as public references — this is the single most important near-term execution falsifier.
4. **DSO.ai + Copilot productivity gains translate to ASP expansion**, not price compression — Synopsys captures value rather than passing it to customers via per-license discounts.
5. **China revenue stabilizes** at a normalized 12–14% of total without a new BIS shock.

Base rate context: software platforms entrenched at the methodology layer of a large engineering workflow (SAP, AutoCAD, MATLAB) have a near-zero displacement rate over 10–20 year horizons. The closest analog — AutoCAD vs. SolidWorks — saw market growth absorb both. EDA has shown the same pattern: Synopsys + Cadence have coexisted for 30 years and the market has 5×'d.

Financial translation: if FY27 revenue lands at $11–12B (Ansys synergies + AI flow ASPs + design-start growth) and EPS reaches $17–18, the stock at a maintained 35× clears $600. A multiple re-rating to 40–42× on confirmed AI-flow productivity → $700+. Re-test of the 52-week high ($651) is the conservative bull target.

## Bear case — technical
1. **Ansys integration drags into FY27.** Q1 FY26 GAAP EPS was $0.34 vs. non-GAAP $3.77 — the gap is primarily Ansys deal amortization, restructuring, and stock-based comp [2][3]. If Multiphysics-Fusion slips past H1 2026, the entire deal thesis (cross-sell + technical bundling) gets pushed out a year, and consensus FY26 starts looking like the high-water mark, not a baseline.
2. **Design IP keeps shrinking.** Q1 FY26 Design IP revenue was –6.5% YoY [2]. IP is the most cyclical part of the business (license bookings are lumpy) and the layer most exposed to customer in-housing — Apple, Meta, and Broadcom have been building more IP internally. If IP doesn't recover by Q3 FY26, the design-start tailwind isn't reaching the IP P&L.
3. **China cyclicality persists.** FY25 China revenue ended –18% [19]. Any renewed BIS letter mid-FY26 would knock 5–8% off forward estimates immediately, as the May 2025 episode demonstrated [5].
4. **The valuation has no cushion.** Forward P/E ~35× and EV/NTM revenue ~10–11× already prices in flawless Ansys execution and AI-flow ASP expansion. Consensus PT trimmed to $480 (–7% from spot) tells you the sell-side has been quietly de-risking [1]. A single guidance cut compresses the multiple to 28–30× → $400 area.
5. **The slow open-source / LLM-agent disruption thesis.** Not a 24-month risk, but ORFS-agent and similar work (Anthropic/Google internal projects on tool-using agents over OpenROAD) compound at the rate LLMs improve, not at the rate EDA companies improve. If a frontier-lab agent reaches first-pass silicon at 7nm in 2027, the conversation about EDA pricing power changes materially. *Probability low over 24 months, non-trivial over 5 years.*
6. **Cadence is a real competitor with the same toolkit.** The bull thesis treats the duopoly as benign; a determined Cadence push on multiphysics (organic + Beta CAE + future M&A) erodes the post-Ansys window faster than expected.

## Market view check
At $516, market cap $99B, forward P/E ~35×, EV/NTM revenue ~10–11×, with consensus PT at $480 (a rare negative implied return) and YTD –10.5%, the market is paying **a software-platform multiple for what management itself is calling a transition year** [1][2]. The buy-side is apparently believing: (a) FY26 is a digestion year for Ansys integration; (b) China and IP cyclicality drag visibility; (c) the AI tailwind is real but already priced. What I think the market is *under-pricing*: (i) the chiplet / 3D-IC structural shift that makes Multiphysics-Fusion strategically valuable and difficult to replicate; (ii) the NVIDIA equity + JDA as a multi-year signal that GPU-accelerated EDA is the next compute bucket; (iii) the fact that hyperscaler design-start count is the right exposure variable for the AI buildout, and SNPS is a near-pure-play toll on it. **Disagreement with consensus: directionally bullish on a 12–18 month horizon, conditional on Multiphysics-Fusion shipping on schedule.** Not bullish enough to underwrite chasing it at 35× into the May 20 print; the asymmetry improves at $440–460.

## 90-day falsifiers
1. **May 20, 2026 Q2 FY26 earnings print** — three specific items: (a) does Design IP return to YoY growth (was –6.5% in Q1); (b) Synopsys.ai Copilot active users (was 20K+ in Q1) — needs >30K for the bull-case productivity story; (c) any change to the $9.56–9.66B FY26 revenue guide [2].
2. **Multiphysics-Fusion production GA announcement** (promised H1 2026) [3][11] — with named flagship customers (NVIDIA, AMD, hyperscaler). Slippage past Q2 FY26 is a meaningful bear signal.
3. **TSMC Q2 2026 earnings commentary on CoWoS-L allocation** — every increment in advanced-packaging capacity above the 120k/month target is downstream demand for 3DIC Compiler [13].
4. **Any new BIS letter on EDA-to-China exports** — would trigger a guidance pull and a 10–15% drawdown in days, as May 2025 demonstrated [5].
5. **NVIDIA quarterly print + capex commentary** — hyperscaler capex guides directly drive chip-design-start expectations and therefore SNPS NTM revenue.
6. **First production tape-out at <7nm using OpenROAD or an LLM-agent flow** — improbable in 90 days, but if it happens, the disruption-base-rate thesis updates materially.
7. **Cadence (CDNS) Q1 FY26 print and competitive disclosures** — Cadence sometimes telegraphs multiphysics roadmap details that map onto Synopsys's window.

## What I could not verify
- **Net-debt and EV precisely** — Synopsys closed the Ansys deal in July 2025 with a mixed cash+stock structure; I used ~$10B net debt as a reasonable inference but did not pull the May 2026 10-Q balance sheet to confirm.
- **EV/NTM revenue** is therefore an estimate; the underlying number is sensitive to net-debt assumption ±$2B.
- **Revenue concentration by customer.** Synopsys does not disclose customer-level revenue, so the "NVIDIA / AMD / Apple / hyperscaler" split is inferred from public partnership announcements, not from filings.
- **NVIDIA equity stake voting/governance terms.** Confirmed $2B at $414.79 (~2.5% ownership) and confirmed non-exclusive [12]; did not verify board observer rights, standstills, or transfer restrictions.
- **Independent head-to-head benchmark of DSO.ai vs. Cadence Cerebrus** — both vendors publish self-reported gains, no third-party benchmark exists.
- **The $11B+ backlog composition** by segment (EDA / IP / Ansys / hardware) — disclosed as a total but not decomposed.
- **Exact share of TSMC CoWoS-L design starts running through Synopsys 3DIC Compiler vs. Cadence Integrity 3D-IC** — both are certified, market split is not publicly disclosed.
- **Synopsys revenue attributable specifically to hyperscaler in-house ASIC programs** — confirmed qualitatively, not quantified.

## Sources
[1] https://stockanalysis.com/stocks/snps/ — retrieved 2026-05-10 — SNPS price $516.48, market cap $98.94B, 52-week range $376.18–$651.73, YTD –10.5%, forward metrics
[2] https://investor.synopsys.com/news/news-details/2026/Synopsys-Posts-Financial-Results-for-First-Quarter-Fiscal-Year-2026/default.aspx — retrieved 2026-05-10 — Q1 FY26 revenue $2.41B, FY26 guide $9.56–9.66B / EPS $14.38–14.46
[3] https://futurumgroup.com/insights/synopsys-q1-fy-2026-earnings-highlight-eda-and-ansys-momentum/ — retrieved 2026-05-10 — Q1 FY26 segment breakdown, Ansys integration commentary, Multiphysics-Fusion beta status
[4] https://news.synopsys.com/2025-07-17-Synopsys-Completes-Acquisition-of-Ansys — retrieved 2026-05-10 — Ansys deal closed July 17, 2025 at $35B
[5] https://www.cnbc.com/2025/05/29/synopsys-china-export.html and https://news.synopsys.com/2025-07-02-Synopsys-Issues-Statement-in-Connection-to-the-Lifting-of-Recent-U-S-Export-Restrictions-Related-to-China — retrieved 2026-05-10 — BIS export restriction May 29 2025, rescinded July 2 2025
[6] https://www.trendforce.com/news/2025/06/02/news-china-revenue-at-risk-as-u-s-curbs-slam-eda-giants-impact-on-synopsys-cadence-and-more/ — retrieved 2026-05-10 — China ~16% of Synopsys FY24 revenue
[7] https://news.synopsys.com/2025-09-24-Synopsys-Collaborates-with-TSMC-to-Drive-the-Next-Wave-of-AI-and-Multi-Die-Innovation — retrieved 2026-05-10 — TSMC N2/A16/A14 certification, 3DIC Compiler for CoWoS-L 5.5× reticle, Totem-SC, PathFinder-SC
[8] https://www.synopsys.com/ai/ai-powered-eda/dso-ai.html — retrieved 2026-05-10 — DSO.ai reinforcement-learning P&R, reference customer-quoted productivity gains
[9] https://arvy.ch/en/cadence-and-synopsys-the-duopoly-that-never-loses-a-client/ and https://matrixbcg.com/blogs/competitors/synopsys — retrieved 2026-05-10 — EDA duopoly share data, ~80% recurring revenue, near-100% retention
[10] https://www.synopsys.com/designware-ip/interface-ip/die-to-die/ucie.html and https://www.synopsys.com/designware-ip/interface-ip/pci-express.html — retrieved 2026-05-10 — DesignWare IP portfolio, 40+ PCIe wins, 224G SerDes wins
[11] https://www.datacenterdynamics.com/en/news/synopsys-launches-ai-powered-eda-solutions-including-first-integrated-ansys-tools-since-acquisition/ — retrieved 2026-05-10 — Multiphysics-Fusion beta, H1 2026 GA promise
[12] https://nvidianews.nvidia.com/news/nvidia-and-synopsys-announce-strategic-partnership-to-revolutionize-engineering-and-design and https://www.cnbc.com/2025/12/01/nvidia-takes-2-billion-stake-in-synopsys.html — retrieved 2026-05-10 — NVIDIA $2B private placement at $414.79, JDA on CUDA-X integration, non-exclusive
[13] https://newsletter.semianalysis.com/p/ai-capacity-constraints-cowos-and and https://www.trendforce.com/news/2025/12/08/news-tsmcs-cowos-l-s-reportedly-fully-booked-osat-partners-step-up-with-ases-cowop-in-focus/ — retrieved 2026-05-10 — CoWoS-L oversubscribed through 2026, capacity ramp 75–80k to 120–130k wafers/month
[14] https://www.marketbeat.com/stocks/NASDAQ/SNPS/short-interest/ — retrieved 2026-05-10 — SNPS short interest 2.35% of float, 4.48M shares, April 15 2026
[15] https://www.goldendoorasset.com/ai-stocks/cadence-design-systems-vs-synopsys-best-ai-electronic-design-automation-stock-for-semiconductors — retrieved 2026-05-10 — DSO.ai vs. Cerebrus productivity comparison, Cadence-disclosed gains
[16] https://www.marketsandmarkets.com/Market-Reports/ai-eda-market-212473295.html — retrieved 2026-05-10 — AI EDA market sizing $4.27B 2026 → $15.85B 2032 (24.4% CAGR), market share data
[17] https://www.edge-ai-vision.com/2026/05/new-synopsys-ai-copilots-deliver-2-5x-faster-chip-design-productivity/ and https://semiwiki.com/eda/synopsys/361338-synopsys-announces-expanding-ai-capabilities-and-eda-ai-leadership/ — retrieved 2026-05-10 — Copilot adoption 40+ customers / 20K+ users / 5M+ queries, AgentEngineer at Converge 2026, AMD collaboration
[18] https://arxiv.org/html/2506.08332v1 — retrieved 2026-05-10 — ORFS-agent: LLM-driven OpenROAD optimization (open-source disruption datapoint)
[19] https://siliconangle.com/2025/12/10/synopsys-records-record-breaking-full-year-revenue-beats-expectations/ — retrieved 2026-05-10 — FY25 record revenue $7.05B, $11B+ backlog, FY25 China revenue –18%
[20] https://www.networkworld.com/article/4099517/nvidias-2b-synopsys-stake-tests-independence-of-open-ai-interconnect-standard.html — retrieved 2026-05-10 — NVIDIA Synopsys partnership strategic context, UCIe implications