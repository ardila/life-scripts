# D — Dominion Energy, Inc. (NYSE: D)

## Where this sits in the AI stack
Dominion operates the regulated electric utility (Virginia Electric & Power, "DEV") that physically connects ~70% of the world's internet traffic switching capacity in Loudoun County's "Data Center Alley" to generation. It sells **kilowatt-hours, transmission capacity, and substation-to-data-hall interconnect rights** — the physical layer underneath every GPU rack in Northern Virginia. It is not a chip story; it is the layer that gates whether a hyperscaler can energize a 250 MW Stargate-class campus in 2027 vs. 2032. The relevant workload is **frontier training and large-scale inference clusters** that require >100 kW/rack-class power densities and 24/7 firm capacity — exactly where the grid, not silicon, is currently rate-limiting.

## Snapshot
- **Price:** $61.89 (2026-05-09 close) [1]
- **Market cap:** $54.4B [1][7]
- **52-week range:** $52.53 – $67.57 [1]
- **Forward P/E:** 17.3× (on FY26 op. EPS midpoint $3.57) [2][3]
- **EV / NTM revenue:** ~6.5× — *n/a as a thesis metric; regulated utilities are valued on P/rate base, P/E, and authorized ROE, not revenue multiples* [inference from $15B rev, ~$45B net debt]
- **Consensus 12-month PT:** $66.35 (+7% from spot) [1]
- **YTD total return:** +10.3% through May 1, 2026 [4]
- **Short interest (% of float):** 2.04% (17.06M shares; ~4 days to cover) [5]
- **Dividend yield:** 4.32% ($2.67 annualized) [6]
- **Long-term op. EPS growth guidance:** 5–7%, biased to upper half 2028–2030 [2][3]
- **2025–2029 capex:** $50.1B, raised from $43.2B at start-2025; >$65B committed/announced including post-Q1 updates [7][8]

## Moat — what it is physically made of
The conventional take ("regulated monopoly") obscures *what* is monopolized. Decomposed:

1. **Sunk transmission topology into Loudoun County.** Dominion's 500-kV backbone (Mt. Storm — Doubs — Pleasant View — Brambleton) and the underlying 230-kV / 34.5-kV distribution that feeds substations like Loudoun, Brambleton, Ox, and Yardley already exist on right-of-way (ROW) acquired by eminent-domain decades ago. Replicating this requires a new entrant to (a) win Virginia SCC certification of public convenience and necessity, (b) site new ROW through one of the densest data-center corridors in the world, and (c) clear PJM's interconnection queue, which currently runs **5–6 years for generation and up to 15 years for large loads** [9]. This is the durable component — measured in decades, not person-years.

2. **Existing baseload generation that can't be cloned.** North Anna (1,892 MW) + Surry (1,676 MW) = ~3.6 GW of 24/7 carbon-free nuclear, fully licensed and on-site for SMR expansion. Amazon's MoU with Dominion to explore SMR development at North Anna [10] is a direct expression of the value: hyperscalers wanting 24/7 carbon-free power for AI training have *no* alternative in PJM to existing nuclear operators. Greenfield nuclear NRC licensing remains a >7-year process.

3. **The 14-year GS-5 contract (effective Jan 2027).** This is the *engineered* moat, often missed. Virginia SCC's Nov 2025 ruling requires data-center-class customers (>25 MW, >75% load factor) to sign **14-year contracts paying minimums of 85% of contracted T&D demand and 60% of generation demand even if unused** [11][12]. This converts a "hyperscaler-might-leave" risk into a take-or-pay annuity. It's a regulatory artifact, but it's been *granted*, in writing, and matches the amortization tail of new gas CCs.

4. **Site control + supply-chain priority.** Dominion has option/site control on 900 acres in Cumberland for a 3-GW combined-cycle gas plant announced May 7, 2026 [13], and has already secured turbines for Chesterfield's 944 MW CERC ($1.47B, online 2027) [14]. With GE Vernova's gas-turbine backlog at **100 GW with deliveries pushed to 2028–2030** [15] and Mitsubishi sold out into the same window [16], incumbency in supplier queue position is itself an asset that a new IPP entrant cannot duplicate inside 36 months.

5. **CVOW (2.6 GW) ROW and FERC-approved offtake.** The Coastal Virginia Offshore Wind project is >70% complete, first power produced March 2026, with majority of turbines in-service end-2026 and remainder early 2027; total cost $10.7–11.5B [17][18]. The asset is on regulated cost-of-service treatment in Virginia — i.e., it earns authorized ROE on capex regardless of merchant pool prices.

**What is *not* moat:** brand, customer loyalty, or any technological proprietary IP. Dominion does not invent — it executes site control, regulatory navigation, and project finance. That said, in this cycle those are the binding constraints.

## AI buildout bottleneck map
The next-24-month gating items and Dominion's posture on each:

| Bottleneck | Status | Dominion's posture |
|---|---|---|
| **Power generation** (firm capacity in PJM) | PJM 2026/27 BRA cleared at the **$329.17/MW-day FERC cap across all zones** [19] — a record signaling scarcity. PJM warns of inadequate reserves starting summer 2026 [20]. | **Beneficiary + supplier.** Earns regulated returns on every MW added; gas CC fleet (~6 GW announced/in-flight) is the marginal new supply in-region. |
| **Gas-turbine OEM capacity** | GE Vernova backlog 100 GW; new orders deliver 2028–2030 [15][16]. | **Beneficiary of incumbency.** Holds delivery slots from prior orders; new IPP entrants face 4-year delivery lag. |
| **Transmission / substation buildout** | 103 Virginia generation projects withdrawn or delayed since 2018 due to network-upgrade costs; CVOW itself capacity-constrained on delivery [21]. Dominion's substations can handle ~2,100 MW today vs. ~4,000 MW of additional load coming by 2028 [22]. | **Constraint owner.** This is the binding limit on near-term revenue conversion. Capex pipeline is fundamentally a T&D pipeline. |
| **Behind-the-meter / co-location** ("bring your own generation") | PJM filed framework with FERC 2025 capping BTM at 50 MW with a 3-year transition window [23]; FERC rejected the Talen–Amazon Susquehanna ISA expansion 300→480 MW in Nov 2024 [24]. **This is the single biggest swing variable.** | **Exposed but currently protected.** Every GW of hyperscaler load that bypasses the utility is rate-base growth Dominion loses. The current regulatory posture protects Dominion; this can flip. |
| **Nuclear baseload (existing + SMR)** | NRC licensing on greenfield >7 years; SMR commercial deployment realistically 2032+ [25][26]. | **Beneficiary.** Amazon SMR MoU at North Anna; site control + license = scarcity rent. |
| **HBM / CoWoS-L / kernel talent** | Binding on hyperscalers, not Dominion. | **Indifferent.** Slower silicon supply *helps* Dominion by stretching the timeline to fill load contracts. |
| **Liquid cooling at >100 kW/rack** | Vendor capacity tight (Vertiv, CoolIT, JetCool) but generally on-customer side of the meter. | **Indifferent.** Higher rack density = same MW per campus = same Dominion revenue. |

## Competitive teardown
Dominion's relevant displacement vectors are not other utilities (its service area is statutory). They are *alternatives to taking power from Dominion at all*:

- **Behind-the-meter gas + nuclear PPAs** (the Talen–AWS, Constellation–Microsoft, Vistra–hyperscaler playbook). Today: 46 announced projects representing **56 GW of planned BTM capacity, 90% announced in 2025** [23]. This is the actual competitor — capital flowing around the utility. **Where they have parity already:** firm 24/7 PPAs from existing nuclear (Constellation–Microsoft for Three Mile Island Unit 1 / Crane). **Where they don't:** Virginia statute and the new GS-5 rate class make this structurally harder in Dominion's service territory than in, e.g., Pennsylvania or Ohio. The FERC Nov-2024 ruling on Susquehanna is *the* precedent — currently restrictive [24].
- **Appalachian Power (AEP) Virginia.** Serves Western Virginia. Smaller data-center footprint, but a relief valve as Loudoun saturates. Not in Dominion's near-term zone of conflict.
- **Onsite generation at scale** (Caterpillar reciprocating engines, BloomEnergy fuel cells). Caterpillar is supplying 2 GW of onsite power to a single West Virginia campus tied to Microsoft/NVIDIA [23]. **Where they have parity already:** for new greenfield campuses outside Dominion's service area. **Inside DEV territory** they remain subject to backup-only rules; primary supply via Dominion remains compelled by the service-territory monopoly.
- **Texas / ERCOT and Phoenix relocations.** Some marginal hyperscaler capacity is migrating to ERCOT (faster interconnection, cheaper land). Not lost so much as not-won. Caps Dominion's TAM growth rather than displacing booked capacity.

The honest read: Dominion is competing for the *next* GW of incremental load. The 51 GW already in some stage of contracting [3] is largely captive.

## Bull case — technical
For D to outperform requires four technical conditions, in order of importance:

1. **The BTM ring-fence holds.** FERC and PJM continue to require co-located large loads to take grid service for the bulk of demand. Status: holding as of May 2026 [23][24]. **Base rate caveat:** regulatory regimes around scarce monopoly rents historically *do* erode (deregulation of telecom 1996, retail electric in TX/OH); the question is timing. 3–5 years of protection is a reasonable central estimate.
2. **Data-center load conversion materializes.** 51 GW in contracting stages → ~10–15 GW actually energized through 2030 [3]. Given GS-5 contracts impose 60% generation-demand minimum payment whether energized or not [11], the financial outcome is robust even if physical conversion is half what's contracted.
3. **CVOW completes on revised schedule and cost.** $10.7–11.5B in regulated rate base earning authorized ROE [17][18]. Already 70%+ complete with first power flowing [17] — execution risk is largely past.
4. **Authorized ROE in Virginia stays ≥9.5%.** Nov-2025 SCC ruling granted $565.7M (2026) + $209.9M (2027) of the requested $822M / $345M increases [11] — partial wins consistent with the historical Virginia regulator-utility settlement pattern.

Financial translation: rate base growth from ~$60B today toward $100B+ by 2030 at ~9.5% authorized ROE compounds book earnings at the 5–7% LT guide [2], with bias to the upper half driven by 2028+ data-center load. Dividend yield 4.3% + 5–7% EPS growth + flat-to-modest multiple = 9–12% IRR base case.

**Technology-displacement base rate:** in regulated electric utilities specifically, the half-life of a service-territory monopoly across the last 40 years (FERC Order 888, retail-choice experiments in CA/TX, distributed solar net-metering battles) is roughly 15–25 years from first credible challenge. The Susquehanna FERC ruling is the *first* credible challenge to the AI-era version. We are at the start of that clock, not the end.

## Bear case — technical
A short-seller who understands the stack writes:

1. **The BTM ring-fence cracks.** A future FERC composition (the Christie-led majority that wrote the Nov-2024 decision is not permanent) reverses on co-location, or PJM's 50-MW BTM threshold gets carved out for nuclear-adjacent loads. Net effect: hyperscalers route ~30% of incremental demand around the utility, leaving Dominion holding stranded gas-CC capex committed against load that never materializes. The 60% generation-demand minimum in GS-5 [11] partially offsets but does not eliminate this — those minimums apply only to customers who actually signed; future hyperscaler greenfields can simply not sign and go BTM-by-default.
2. **Virginia political backlash caps load growth.** The April 2026 state law requiring independent review of Dominion's load forecasts [27] is the leading indicator. A future General Assembly under cost-pressure from residential ratepayers could legislate moratoriums or shift cost burden such that Dominion's effective ROE on data-center capex falls below 9%. The cost-allocation political fight is *unresolved* and current SCC accommodation is not permanent.
3. **CVOW + Cumberland cost overruns compress earned ROE.** CVOW has already moved $9.8B → $10.7B → $11.5B [17][18]; tariff and supply-chain pressure continues. If costs run materially above SCC's "prudent" threshold, write-downs are possible (Duke, NextEra both have precedents). The Cumberland 3-GW plant won't break ground until 2029 with hydrogen-capable turbines [13] — meaningful tech and cost risk.
4. **AI capex cycle inflects.** If hyperscaler 2027 capex grows <15% YoY (vs. the 40%+ pace baked into Dominion's load forecasts), 51 GW contracted backlog gets restructured at the margin. Even with GS-5 minimums, contract renegotiation pressure rises. **The fact that PJM's Dominion zone cleared *down* to the RTO cap in the 2026/27 BRA — vs. premium pricing in 2025/26** [19] — already hints that capacity scarcity is partially resolving through new supply additions.
5. **Interest-rate sensitivity.** Dominion runs ~$45B in long-term debt. Every 100 bp on refinancing rates against a $50–65B capex program is a ~3–5% drag on cumulative net income through 2030. Not catastrophic, but it eats the 5–7% growth promise quickly.

## Market view check
$61.89 / 4.3% yield / 17× forward = priced like a high-quality regulated utility with above-average growth visibility. The S&P utilities sector forward P/E is ~17–18×; Dominion is at parity despite better-than-sector EPS growth guidance. The market is implicitly **discounting the bear cases above** — specifically BTM erosion and political risk — rather than fully capitalizing the data-center tailwind. A pure-play AI-power name would trade closer to 20–22× forward (Vistra, Constellation analogues, though those are merchant). **The mispricing, if it exists, is in the direction of underappreciation of the 14-year GS-5 take-or-pay structure**, which converts a growth thesis into a contracted-cash-flow thesis the market is still valuing on traditional regulated-utility multiples. Consensus $66.35 PT implies the sell-side sees this — slightly — but not aggressively [1].

## 90-day falsifiers
Specific, datable events through ~August 2026:

1. **PJM/FERC ruling on the next co-location ISA** (multiple cases pending). A FERC reversal expanding BTM netting beyond 50 MW = bear-case activation. A reaffirmation = bull-case durability +1.
2. **2027/28 PJM Base Residual Auction results** (typically held mid-year; clearing prices and whether Dominion zone re-separates as constrained). Dominion zone reverting to premium = supply tightening; clearing well below cap = oversupply concern.
3. **Virginia General Assembly special-session activity or interim study commission findings on data-center cost allocation.** Any legislation moving generation costs off data-center class onto residential = a direct hit on the GS-5 thesis.
4. **First commercial CVOW turbines reaching nameplate output and SCC prudency determination.** Production data <85% of forecast load factor or any prudency disallowance = capex write-down risk.
5. **Hyperscaler Q2 capex disclosures** (META/MSFT/GOOG/AMZN earnings July–August). >10% sequential cut in aggregate capex guidance = challenges the 51 GW contracting pipeline conversion. A holding-or-rising trajectory = bull validation.
6. **Cumberland 3-GW gas plant SCC application filing** (expected within 2026 per Dominion guidance [13]) — application contents reveal updated turbine vendor, cost estimate, in-service year.
7. **Amazon–Dominion SMR MoU progression to formal procurement** (vs. expiring as a non-binding study) — material call option on the 2030s.

## What I could not verify
- Exact MW count and location of Dominion's *currently energized* data-center load (vs. contracted-but-not-energized). The 51 GW figure conflates multiple stages.
- The specific authorized ROE Dominion is currently earning vs. the SCC-approved level — i.e., regulatory lag magnitude.
- Whether the $50.1B vs. $65B capex figures reflect the same scope at different dates, or a genuine post-Q1 raise.
- Turbine vendor and delivery-slot specifics for Cumberland (article said "hydrogen-capable" but no OEM identified).
- Detailed PJM zonal transmission queue position for the next ~6 GW of Dominion-zone generation interconnection — public PJM queue data is voluminous but I did not enumerate it.
- Counterparty composition (Amazon vs. Microsoft vs. Google vs. Meta share) of the 51 GW pipeline — Dominion does not disclose customer-level allocation.
- Whether the recent Q1 BRA price cap-clearing reflects a structural change in PJM supply elasticity (bullish for demand absorption) or a one-off (less informative).

## Sources
[1] https://finance.yahoo.com/quote/D/ — retrieved 2026-05-10 — price ($61.89), 52-week range, consensus PT
[2] https://www.fool.com/earnings/call-transcripts/2026/05/01/dominion-d-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q1'26 call transcript, 51 GW pipeline, 2026 EPS guide $3.45–3.69
[3] https://www.investing.com/news/company-news/dominion-energy-q1-2026-slides-data-center-boom-drives-earnings-beat-93CH-4653914 — retrieved 2026-05-10 — 10.4 GW under ESAs, 29.5 GW SELOA, 11.1 GW CLOA
[4] https://www.ytdreturn.com/dominion-energy/ — retrieved 2026-05-10 — YTD return +10.3%
[5] https://fintel.io/ss/us/d — retrieved 2026-05-10 — short interest 2.04% of float
[6] https://www.wallstreetzen.com/stocks/us/nyse/d/dividends — retrieved 2026-05-10 — dividend $2.67, yield 4.32%
[7] https://www.datacenterdynamics.com/en/news/dominion-reports-high-data-center-demand-in-northern-virginia-proposes-new-electricty-rates-for-large-load-customers/ — retrieved 2026-05-10 — $50.1B 2025–29 capex (raised from $43.2B)
[8] https://www.tikr.com/blog/dominion-energy-stock-in-2026-48-gigawatts-contracted-65-billion-committed-cvow-70-done — retrieved 2026-05-10 — $65B committed capital figure
[9] https://www.vpm.org/news/2026-05-04/energy-transmission-upgrades-pjm-nrdc-data-centers-dominion-wind-farm-lang-ree — retrieved 2026-05-10 — interconnection queue 5–6 years generation, up to 15 years large load
[10] https://investors.dominionenergy.com/news/press-release-details/2024/Dominion-Energy-and-Amazon-to-explore-advancement-of-Small-Modular-Reactor-SMR-nuclear-development-in-Virginia/ — retrieved 2026-05-10 — Dominion–Amazon SMR MoU at North Anna
[11] https://virginiamercury.com/2025/11/25/scc-approves-chesterfield-gas-plant-and-dominion-rate-hike-creates-new-rate-class-for-data-centers/ — retrieved 2026-05-10 — GS-5 rate class, 14-year contracts, 85% T&D / 60% generation demand minimums
[12] https://www.americanactionforum.org/insight/virginias-new-data-center-electricity-rate-class/ — retrieved 2026-05-10 — GS-5 details, eligibility >25 MW & >75% load factor
[13] https://virginiamercury.com/2026/05/07/dominion-announces-plans-for-new-3-gigawatt-gas-plant-in-cumberland-county/ — retrieved 2026-05-10 — Cumberland 3 GW CC announcement May 7, 2026; in-service 2033–34
[14] https://virginiabusiness.com/dominion-files-for-scc-approval-of-chesterfield-gas-fired-plant/ — retrieved 2026-05-10 — Chesterfield CERC 944 MW, $1.47B, online 2027
[15] https://www.utilitydive.com/news/ge-vernova-gas-turbine-backlog-hits-100-gw-as-prices-rise/818332/ — retrieved 2026-05-10 — GE Vernova 100 GW backlog Q1 2026
[16] https://www.utilitydive.com/news/mitsubishi-gas-turbine-manufacturing-capacity-expansion-supply-demand/759371/ — retrieved 2026-05-10 — Mitsubishi delivery 2028–2030
[17] https://www.power-eng.com/renewables/wind-energy/dominion-says-coastal-virginia-offshore-wind-project-tops-70-complete-as-turbine-installation-enters-slower-final-stretch/ — retrieved 2026-05-10 — CVOW >70% complete, in-service end-2026 / early-2027
[18] https://www.whro.org/environment/2026-02-24/pause-on-virginia-offshore-wind-farm-cost-dominion-more-than-200m-but-turbines-will-power-up-soon — retrieved 2026-05-10 — CVOW cost $9.8B→$11.5B trajectory
[19] https://www.pjm.com/-/media/DotCom/markets-ops/rpm/rpm-auction-info/2026-2027/2026-2027-bra-report.pdf — retrieved 2026-05-10 — PJM 2026/27 BRA cleared at $329.17/MW-day cap, all LDAs
[20] https://www.lod.io/blog/pjm-residual-auction-services-results — retrieved 2026-05-10 — PJM reserve adequacy starting summer 2026
[21] https://www.wvtf.org/2026-05-01/pricey-transmission-upgrades-are-stalling-much-needed-energy-projects-in-virginia-report-says — retrieved 2026-05-10 — 103 Virginia projects withdrawn/delayed; CVOW delivery-constrained
[22] https://enkiai.com/data-center/dominion-energy-nuclear-pjm-queue/ — retrieved 2026-05-10 — Dominion substation 2,100 MW vs. 4,000 MW needed by 2028
[23] https://www.datacenterfrontier.com/energy/article/55362901/pjm-moves-to-redefine-behind-the-meter-power-for-ai-data-centers — retrieved 2026-05-10 — PJM 50-MW BTM threshold, 56 GW planned BTM, Caterpillar 2 GW WV
[24] https://www.utilitydive.com/news/ferc-interconnection-isa-talen-amazon-data-center-susquehanna-exelon/731841/ — retrieved 2026-05-10 — FERC 2–1 rejection of Talen–AWS Susquehanna ISA expansion, Nov 2024
[25] https://www.utilitydive.com/news/dominion-energy-smr-small-modular-reactor-north-anna-nuclear-site/721240/ — retrieved 2026-05-10 — Dominion SMR RFP at North Anna, 2030s deployment
[26] https://cardinalnews.org/2022/12/15/dominion-energy-plans-to-deploy-small-modular-nuclear-reactors-statewide-by-2032/ — retrieved 2026-05-10 — 2032 SMR target
[27] https://virginiamercury.com/2026/04/30/new-state-law-mandates-review-of-dominions-load-forecasting-as-data-centers-raise-concerns/ — retrieved 2026-05-10 — April 2026 Virginia law requiring independent load-forecast review