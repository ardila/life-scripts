# XOM — ExxonMobil Corporation

## Where this sits in the AI stack
XOM sits at the **fuel + integrated power-plus-carbon-management layer** beneath the AI buildout — not in silicon, networking, or software. The relevant AI-related products are: (a) feedstock natural gas (Permian, Haynesville-adjacent, Marcellus equity gas and Golden Pass LNG export option) for gas-fired generation that increasingly powers data centers, (b) the announced 1.2 GW behind-the-meter natural-gas combined-cycle (NGCC) plant with post-combustion CCS being co-developed with NextEra for a Gulf-Southeast hyperscaler campus[1][7], (c) the largest US CO₂ pipeline network (~1,300 miles) and Gulf Coast saline-aquifer storage system[2], and (d) PFAS-free dielectric immersion-cooling fluids developed jointly with Intel, Infosys and UNICOM[8]. None of this touches frontier training silicon — it sits two layers below CoWoS, HBM and NVLink — but it touches the binding constraint (power) that gates every hyperscaler campus going to FID in 2026–2030.

## Snapshot
- **Price:** $144.30 (2026-05-10 close)[3]
- **Market cap:** $598.5B[3]
- **52-week range:** $101.19 – $176.41[3]
- **Forward P/E:** ~17.8× (on FY26 consensus EPS implied near $8.10, derived from $144.30 ÷ 17.8 = $8.11)[4]
- **EV / NTM revenue:** ~1.95× (market cap $598.5B + ~$30B net debt vs. ~$320B LTM revenue; consensus NTM revenue similar)[3][5]
- **Consensus 12-month price target:** $161–$165 median across 24–42 analysts (range $123–$195), implying ~+12–14% upside; Argus most recently hiked PT to $169[6]
- **YTD total return:** ~+27–29% (driven by Mideast/Hormuz risk premium in Q1 oil prices and Golden Pass LNG Train 1 first cargoes)[9][10]
- **Short interest (% of float):** n/a — not consistently disclosed in retrieved sources; XOM historically runs <1% short interest given size and ETF ownership (inference)
- **Dividend yield:** 2.70%, 44th consecutive year of increases[11]

## Moat — what it is physically made of
Honest decomposition. None of this is a CUDA-class software moat — XOM's moat is **physical, geological and regulatory**, which has different durability characteristics:

1. **CO₂ pipeline and reservoir network.** ~1,300 miles of operated CO₂ pipe stretching Texas–Louisiana–Mississippi (largest in the US), connecting to depleted hydrocarbon reservoirs and saline aquifers with potential capacity ~100 MTA against ~14 MTA contracted today[2]. Right-of-way assembly across three states took decades; replication cost is not just dollars but eminent-domain authority and Class VI well permitting timelines. **Durability: high** (15–30+ year asset life, very high replication cost). This is the single hardest-to-copy component.

2. **Permian feedstock cost position.** Pioneer-augmented Permian production tracking to ~1.8 MMBOE/d in FY26 and ~2.0 MMBOE/d by 2027[12][13]. Associated gas at Waha is trading at a –$2.00 to –$2.50 Henry Hub basis on the 2026 strip and has flashed deeply negative (–$5.69/MMBtu prompt month, –$8.25/MMBtu basis settle in early May)[14]. Until Gulf Coast Express expansion and Blackcomb come online in 2H26, Permian operators are effectively giving away methane that would otherwise be flared. For an on-site gas plant, this is fuel at near-zero variable cost. **Durability: medium-high** — basis compresses post-2H26 as takeaway builds, but Permian remains the structurally cheapest gas resource in North America for the decade.

3. **Integrated CCGT+CCS engineering at GW scale.** Post-combustion amine capture on NGCC adds roughly $22–40/MWh to LCOE and imposes a ~10–15% parasitic load (steam draw for amine regeneration)[15]. Executing 1.2 GW with 90%+ capture is not a turnkey project — it requires solvent selection (MEA vs. proprietary blends), compressor train sizing, and reservoir characterization for storage. Few firms can self-finance and self-execute the full stack; XOM, Chevron, Aramco, and Shell are the credible list. **Durability: medium** — not a unique IP moat, but a "five things have to go right simultaneously" execution moat.

4. **45Q tax-credit capture mechanism.** Post-OBBBA (2025), point-source CCS earns $85/ton for 12 years from in-service date[16]. At 90% capture on a 1.2 GW CCGT (~3.5 MtCO₂/yr emitted at base, ~3.15 Mt captured), that's ~$268M/yr of tax credits per plant — directly accruing to whoever owns the capture equipment. This is policy-conferred, not a durable moat; it's a subsidy. **Durability: low-medium** — credit survived through OBBBA but could be capped or modified in a future Congress.

5. **Immersion-cooling dielectric fluids.** Joint development with Intel, Infosys, UNICOM[8]. Real product, real chemistry IP (PFAS-free dielectric formulation), but revenue is small (sub-$100M order of magnitude — inference; not separately disclosed) and the competitive set (Shell GTL, Castrol, 3M's exit from PFAS coolants) is open. **Durability: low** — a niche, not a moat.

What is **not** a moat: gas turbines themselves (owned by GE Vernova/Siemens Energy/Mitsubishi Heavy), grid/transmission rights (NextEra is the developer of record on the JV), or the hyperscaler relationship (no announced offtaker as of Q1 2026 marketing window)[1][7].

## AI buildout bottleneck map
- **Power generation:** binding 2025–2028. EIA forecasts US data-center electricity demand growing to ~426 TWh by 2030 (+133%), with natural gas providing >40% of incremental supply (~130 TWh of additional generation)[17][18]. **XOM = beneficiary** (gas feedstock) and partial **supplier** (NextEra JV).
- **Gas turbines (heavy-frame and aero):** binding through 2030. GE Vernova's backlog + slot reservations totaled ~100 GW exiting Q1 2026, targeting ~110 GW by year-end; deliveries effectively sold out through 2030; Mitsubishi Power sold out through 2028[19][20]. **XOM = exposed customer**, not constraint owner. The NextEra JV's 5-year timeline likely reflects a turbine slot already secured — verify.
- **Grid interconnect / queue:** binding. Behind-the-meter is the explicit workaround[21]. **XOM = beneficiary** by routing around the constraint entirely.
- **CO₂ transport and storage permits (Class VI):** moderately binding. EPA Class VI well permitting backlogs are real; some states (Louisiana, North Dakota, Wyoming, West Virginia) hold primacy and move faster. **XOM = constraint owner** — its existing right-of-way and reservoir leases are scarce.
- **Advanced packaging (CoWoS-L), HBM3e/HBM4 yield, optical interconnect, NVLink-class scale-up fabric:** **XOM = indifferent.** Not in this layer.
- **Liquid cooling at >100 kW/rack:** **XOM = small supplier** via immersion fluids partnership; not a constraint owner.
- **Electrical contractor / GE switchgear / medium-voltage transformer capacity:** binding (12–24 month lead times on large transformers). **XOM = exposed customer**.
- **Kernel/compiler/scaling talent:** **XOM = indifferent.**

Net: XOM benefits from being on the upstream side of the most binding non-silicon constraint (power) and owns the rarest piece of the abatement stack (CO₂ infrastructure), while remaining exposed to gas-turbine OEMs as a customer.

## Competitive teardown
- **Chevron (CVX):** the most direct like-for-like competitor. Announced a 2.5 GW (potentially 5 GW) behind-the-meter Permian gas complex at its Nov 2025 investor day, with an exclusivity arrangement with Microsoft reported April 2026, ~$8B committed to 4 GW BTM by 2027[22][23]. Chevron is co-located in the Permian with cheaper basis-gas access than XOM-NextEra's Southeast site, but lacks XOM's Gulf Coast CO₂ pipeline footprint, so its CCS story is less integrated. On a 24/7 carbon-free metric per ton CO₂ avoided, XOM has the edge; on $/MWh delivered, Chevron may be cheaper in West Texas.
- **Constellation Energy (CEG) and Vistra (VST):** the strongest non-gas competition. Nuclear delivers 24/7 carbon-free without CCS overhead, with operating costs ~$30–40/MWh once capital is sunk. Constellation acquired Calpine ($16.4B, 2026) to add a gas fleet to its nuclear, and has restart/uprate optionality at TMI for Microsoft and Crane for similar customers[24]. **The structural problem for nuclear:** new build is ~10 years from FID to commercial operation; SMRs (Oklo, X-energy, GEH BWRX-300) are still pre-commercial. Existing nuclear is supply-capped at ~95 GW US fleet. So nuclear takes the **premium tier** of behind-the-meter deals; gas+CCS competes for everything beyond that. Meta's 6.6 GW nuclear MoUs (Oklo, Vistra, TerraPower) are a leading indicator that hyperscalers want nuclear but can't get enough[25].
- **NextEra (NEE):** simultaneously XOM's partner on the SE US plant **and** its biggest substitute — NextEra is planning 15 GW for data-center hubs by 2035, with renewables-plus-storage as the dominant technology[26]. NextEra effectively gets to optimize across gas+CCS, wind+storage, and solar+storage portfolios; XOM's exposure is via being the fuel/CCS provider in only the gas-fired share.
- **Independent BTM gas developers (Crusoe, ExxonMobil-NextEra, Talen, Stargate-affiliated entities, Williams MoU stack):** dozens of behind-the-meter gas projects with combined ~56 GW announced[21]. The market is fragmenting on the developer side; what's scarce is the integrated CCS-plus-fuel-plus-storage offering. Only XOM and Chevron credibly offer that today.
- **What would have to be true for nuclear to take share:** SMRs reach commercial operation in 4–5 years rather than 8–10; if Oklo/X-energy/Kairos hit 2028–2029 deployment dates, gas+CCS gets compressed to bridge-power role. **What would have to be true for renewables+storage to take share:** long-duration storage costs drop ~40% from current ~$200–300/kWh installed and 100-hr-class systems (form factor like Form Energy) reach commercial economics. Neither is base-case for the 2026–2028 capex cycle.

## Bull case — technical
The bull case is a four-link chain, every link of which has to hold:

1. **Hyperscaler 24/7 carbon-free commitments harden in procurement, not just PR.** Google, Microsoft, Meta procurement teams treat matched-hourly carbon-free as a non-negotiable spec for new sites > 500 MW. RECs-and-offsets stop being acceptable for incremental load.
2. **Nuclear is supply-capped through 2030.** Existing nuclear restart/uprate is finite (~5–8 GW realistically); SMRs slip to 2030+ for first commercial operation. This forces the carbon-free baseload demand onto gas+CCS as the only deployable technology at GW scale before 2030.
3. **45Q stays at $85/ton point-source.** OBBBA-set rates hold through the next Congress (base rate of technology displacement under shifting US energy policy is **moderate** — credits have survived four administrations now, but the rate is not invariant).
4. **XOM-NextEra signs a hyperscaler offtaker in 2026 and scales the model.** A single 1.2 GW signed contract would validate the cost stack. Replication across XOM's Gulf Coast CO₂-pipeline footprint could plausibly support 6–10 GW of similar plants by 2032.

**Base rate on technology displacement.** Energy-stack displacement is slow: ICE-to-EV is ~25 years from announcement to 10% share; coal-to-gas in US power generation took ~15 years (2008–2023) to flip dominance; nuclear-to-anything has barely moved in 50 years. The base rate says gas-fired electricity remains the dominant data-center power source through 2030 even in bullish renewables scenarios[17]. This favors XOM as long as the **abatement** layer (CCS) holds value, which depends on (1) above.

**Financial translation.** Even at 10 GW of behind-the-meter gas+CCS by 2032 (heroic), incremental EBITDA is probably $2–4B/yr against a $50–80B/yr current EBITDA base — meaningful kicker, not transformation. The bull case for the stock is really: AI provides demand support for **upstream gas pricing** (Henry Hub structurally $3.50–5.00 vs. $2.50 historical) plus optionality on CCS, while Guyana ramps to ~1.3 MMBO/d and oil holds $70+. The AI angle is the **option-value layer** on top of an oil-and-gas thesis.

## Bear case — technical
1. **Hyperscalers accept unabated gas plus RECs.** If 24/7 carbon-free spec gets diluted (cost pressure on AI capex, slowing CO₂-reduction urgency, or accounting rules change), CCS becomes a stranded cost premium. The bear case here is that hyperscalers are willing to pay $5–10/MWh more for CCS, not $25–40/MWh, and the unit economics of XOM's offering stop closing. This is the most credible bear path.
2. **Nuclear restart/SMR comes faster than expected.** If Constellation/Vistra add 3–5 GW of nuclear restart and Oklo or X-energy hits 2028 commercial operation, the carbon-free baseload market gets taken by nuclear before XOM-NextEra scales beyond the first plant. Meta's 6.6 GW nuclear MoU is the signal[25].
3. **45Q is weakened or capped.** A future Congress halves the credit or imposes a hyperscaler-specific carve-out reducing the $/ton flow to gas producers. Plant economics deteriorate by $200–300M/yr per gigawatt.
4. **Gas turbine OEM allocation is the binding constraint and goes to others.** GE Vernova's slots through 2030 are largely sold; if XOM-NextEra hasn't secured a specific turbine slot, the project slips into 2031–2032[19].
5. **Permian basis flips.** Once Gulf Coast Express expansion and Blackcomb come online in 2H26, Waha basis compresses from –$2.50 toward –$0.50, removing the stranded-gas tailwind for on-site Permian generation (relevant for Chevron more than XOM, but it normalizes the comp set).
6. **Oil demand peaks and 80% of the business derates.** The "AI-energy sleeve" is <5% of plausible XOM 2030 earnings; the dominant variable is still oil. A demand-peak scenario (China EV adoption + efficiency) drops Brent to $55 and the AI story doesn't save the multiple.

The short-seller-who-knows-the-stack version: *XOM has a real but capped option on data-center power. The CCS layer is overrated because hyperscalers will pay for 'carbon-free' but not for 'capture-and-store' at $30/MWh premium. Strip out the AI narrative, and you have a high-cost integrated oil major paying a 2.7% dividend, trading at 17.8x forward earnings — the same as it traded at five years ago, before AI was a story.*

## Market view check
At $144.30 and ~17.8× forward, XOM is trading above its 10-year average forward multiple (low-teens) and not far off the 2007–2014 oil-cycle peak multiple. The consensus PT of $161–165 implies the market is pricing **continued oil-cycle strength + modest AI-energy optionality**, not a regime change. EV/NTM revenue of ~1.95× and EV/EBITDA of ~12× are both modestly stretched for an integrated oil major. **My read:** the price already embeds a Hormuz-risk premium on Q1 oil prices and an AI-narrative bid; it does **not** embed a successful hyperscaler signing in 2026, which is the real near-term catalyst. Mispricing is mild — the asymmetry favors holders if the SE US plant gets a signed offtaker, and is fairly priced if it doesn't. This is not a name where the AI angle is the primary thesis; it's a name where AI extends the duration of gas demand and provides a small but real optionality kicker on a fundamentally oil-and-gas franchise.

## 90-day falsifiers
- **Hyperscaler signing on the 1.2 GW SE US site.** NextEra said Q1 2026 marketing; any announced offtaker (Microsoft, Google, Meta, Amazon, Oracle) by August 2026 confirms the model. Absence by Q3 prints is a negative signal[1][7].
- **Q2 2026 hyperscaler capex guidance.** If META/MSFT/GOOGL/AMZN guide Q3+Q4 capex flat or down sequentially, the entire data-center power demand thesis loses ~20% of its near-term torque. (Q2 prints land late-July to early-August 2026.)
- **Gas turbine OEM allocation disclosure.** GE Vernova's Q2 print (late July 2026) — backlog composition, specifically any disclosed XOM-NextEra slot — moves the timeline.
- **EPA Class VI well permit action on XOM Gulf Coast applications.** Approvals or denials in Louisiana / Texas / Mississippi sequencing through Q3 are material to the CCS scaling timeline.
- **Waha basis behavior.** If Gulf Coast Express expansion slips and Waha stays at –$3.00+ through Q3 2026, Permian gas-feedstock economics remain exceptional for on-site generation.
- **Chevron-Microsoft definitive agreement.** Final terms (announced as exclusivity in April 2026) would set a market-clearing price for behind-the-meter gas+CCS that anchors XOM-NextEra's negotiating leverage[22].
- **Constellation or Vistra signing a new hyperscaler nuclear PPA at >$120/MWh.** Confirms premium for 24/7 carbon-free without CCS, supports the gas+CCS bull case by anchoring abatement-premium pricing.

## What I could not verify
- Whether XOM-NextEra has actually secured a gas-turbine OEM slot, or is competing for one against the 100 GW backlog at GE Vernova.
- Exact capex for the 1.2 GW NGCC + 90% post-combustion CCS package; published cost ranges of $20–40/MWh LCOE-add for capture span a wide error bar[15].
- Whether any hyperscaler has signed even a non-binding term sheet for the SE US site (NextEra's Dec 2025 disclosure said marketing in Q1 2026, no customer named).
- The contracted offtaker price (PPA or capacity charge) at which the 1.2 GW plant would clear — critical to whether the project is structurally profitable or marginally so.
- XOM's specific CO₂ pipeline counterparty list and contracted MTA per counterparty (only headline ~14 MTA disclosed[2]).
- Revenue contribution from immersion-cooling fluids (not separately disclosed in segment reporting).
- Net debt as of Q1 2026 close (estimated ~$30B; could be lower given buybacks).
- Whether XOM is bidding on additional sites beyond the SE US 2,500-acre parcel.
- Short interest as a precise % of float (inferred low, not verified to one decimal).

## Sources
[1] https://www.cnbc.com/2025/12/08/nextera-exxon-develop-gigawatt-data-center-for-hyperscaler.html — retrieved 2026-05-10 — CNBC on NextEra-Exxon 1.2 GW MoU for SE US 2,500-acre hyperscaler site, Q1 2026 marketing window
[2] https://corporate.exxonmobil.com/news/viewpoints/a-breakout-year-for-our-carbon-capture-and-storage-business — retrieved 2026-05-10 — XOM disclosure of 1,300+ mile CO₂ pipeline network, ~100 MTA potential, ~14 MTA contracted
[3] https://finance.yahoo.com/quote/XOM/ — retrieved 2026-05-10 — XOM price $144.30, market cap $598.5B, 52-week range $101.19–$176.41
[4] https://stockanalysis.com/stocks/xom/statistics/ — retrieved 2026-05-10 — Forward P/E ~17.8x, EV/EBITDA ~11.9x
[5] https://finance.yahoo.com/quote/XOM/key-statistics/ — retrieved 2026-05-10 — LTM revenue ~$323.9B, P/S 1.89x
[6] https://www.marketbeat.com/stocks/NYSE/XOM/forecast/ — retrieved 2026-05-10 — Consensus PT $161–165, Argus most recent hike to $169
[7] https://www.datacenterdynamics.com/en/news/nextera-teams-up-with-exxonmobil-to-develop-12gw-natural-gas-plant-to-power-us-data-center-sector/ — retrieved 2026-05-10 — Project structure: NextEra develops, XOM provides fuel and CCS
[8] https://datacentremagazine.com/news/exxonmobil-infosys-partners-to-scale-data-centre-immersion-cooling-tech — retrieved 2026-05-10 — XOM-Infosys-Intel immersion cooling dielectric fluid partnerships
[9] https://www.financecharts.com/stocks/XOM/performance/total-return — retrieved 2026-05-10 — XOM 2026 YTD total return ~+27-29%
[10] https://investor.exxonmobil.com/company-information/press-releases/detail/1204/exxonmobil-announces-first-quarter-2026-results — retrieved 2026-05-10 — Q1 2026 earnings $4.2B; Golden Pass LNG Train 1 first production end-March 2026
[11] https://www.marketbeat.com/stocks/NYSE/XOM/dividend/ — retrieved 2026-05-10 — Dividend $4.12/share, 2.70% yield, 44 consecutive years of increases
[12] https://corporate.exxonmobil.com/news/news-releases/2024/0503_exxonmobil-completes-acquisition-of-pioneer-natural-resources — retrieved 2026-05-10 — Pioneer acquisition close (May 2024), Permian to ~2 MMBOE/d by 2027
[13] https://www.fool.com/earnings/call-transcripts/2026/05/01/exxonmobil-xom-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1 2026 transcript: 1.8 MMBOE/d FY26 target, Permian and Guyana growth, Oahu first oil late 2026
[14] https://aegis-hedging.com/insights/basis-brief-waha-gas — retrieved 2026-05-10 — Waha basis -$2.00 to -$2.50 vs Henry Hub on 2026 strip; prompt month deeply negative
[15] https://www.sciencedirect.com/science/article/pii/S2352484724002713 — retrieved 2026-05-10 — CCGT post-combustion amine CCS techno-economics; LCOE-add $20-40/MWh, cost of CO₂ avoided ~£128/t (~$160-170/t)
[16] https://carboncapturecoalition.org/wp-content/uploads/2025/06/OBBB-fact-sheet.pdf — retrieved 2026-05-10 — OBBBA-set 45Q rates: $85/ton point-source, $180/ton DAC, 12-year claim window
[17] https://www.eia.gov/pressroom/releases/press582.php — retrieved 2026-05-10 — EIA Jan 2026 forecast: strongest 4-year US electricity demand growth since 2000, data-center-driven
[18] https://www.iea.org/reports/energy-and-ai/energy-supply-for-ai — retrieved 2026-05-10 — IEA: natural gas largest incremental data-center power supply through 2030, +130 TWh
[19] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — GE Vernova gas turbine backlog ~80 GW exiting 2025, stretching to 2029-2030
[20] https://www.industrialinfo.com/iirenergy/industry-news/article/ge-vernovas-global-natural-gas-turbine-reservations-and-order-backlog-grows-to-100-gw--356705 — retrieved 2026-05-10 — Q1 2026: GE Vernova combined backlog + reservations to ~100 GW
[21] https://www.datacenterfrontier.com/energy/article/55358731/aeroderivative-turbines-move-to-the-center-of-ai-data-center-power-strategy — retrieved 2026-05-10 — 46 data centers, ~56 GW announced behind-the-meter
[22] https://fortune.com/2026/04/01/microsoft-chevron-exclusivity-powering-west-texas-data-center-complex/ — retrieved 2026-05-10 — Microsoft-Chevron exclusivity on West Texas behind-the-meter complex
[23] https://www.enr.com/articles/61972-chevron-to-build-its-first-data-center-power-plant-in-texas-permian-area — retrieved 2026-05-10 — Chevron 2.5 GW Permian BTM plant, potential expansion to 5 GW, 2027 target operation, ~$8B commitment
[24] https://markets.financialcontent.com/stocks/article/marketminute-2026-3-24-the-power-behind-the-pulse-constellation-energys-164-billion-calpine-acquisition-solidifies-the-ai-energy-backbone — retrieved 2026-05-10 — Constellation $16.4B Calpine acquisition adding gas fleet to nuclear, behind-the-meter strategy
[25] https://www.utilitydive.com/news/meta-nuclear-deal-oklo-vistra-terrapower-ai-data-centers/809215/ — retrieved 2026-05-10 — Meta 6.6 GW nuclear MoU with Oklo, Vistra, TerraPower
[26] https://www.enerdata.net/publications/daily-energy-news/nextera-energy-plans-15-gw-capacity-2035-us-data-centers.html — retrieved 2026-05-10 — NextEra 15 GW data-center capacity target by 2035