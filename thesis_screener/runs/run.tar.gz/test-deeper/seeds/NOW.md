# NOW — ServiceNow, Inc.

## Where this sits in the AI stack
ServiceNow is an application-layer enterprise SaaS company, not silicon or infrastructure. It operates the workflow system-of-record for IT service management (ITSM ~40% market share), HR service delivery, customer service management, and IT operations management at ~85% of the Fortune 500 [1][2]. In the AI stack it is positioned three layers above the GPU: above the model (it consumes Apriel-Nemotron-15B co-developed with NVIDIA, plus customer-supplied Anthropic/OpenAI/Gemini models via a router), above the orchestration runtime (it ships its own AI Agent Studio, Orchestrator, and Action Fabric), and at the same layer as Salesforce, Workday, Atlassian, and the agentic-AI wave (Claude Cowork, Microsoft Copilot Studio). Workload mix is enterprise inference — short-context, structured-output, latency-sensitive — not training and not frontier reasoning [3][4].

## Snapshot
- **Price:** $91.18 (2026-05-08 close) [5]
- **Market cap:** $94.0B (1.03B shares post 5-for-1 split executed Dec 17, 2025) [5][6]
- **52-week range:** $81.24 – $211.48 (post-split adjusted) [5]
- **Forward P/E:** 21.0× [5]
- **EV / NTM revenue:** ~5.5× FY26 subscription on $15.755B midpoint guide [7][8]
- **Consensus 12-month price target:** ~$184 mean (range $144 – $236; Bernstein top end, KeyBanc Underweight at the low end) [9]
- **YTD total return:** -42.7% [10]
- **Short interest:** 3.78% of float (38.95M shares; ~1.5 days to cover) [9]

## Moat — what it is physically made of
The moat is **not** "CUDA-style" software lock-in. It decomposes into five components, and the right question is whether each survives an agent-mediated buyer.

**1. The CMDB graph (durable).** ServiceNow's Configuration Management Database is a 15-year-old graph of every CI (configuration item) — server, container, network device, application, business service — plus the relationships between them, populated by Discovery agents and IntegrationHub connectors. For an LLM to take a *grounded* action ("restart the upstream dependency of this service") in a Fortune 500 environment, it needs this graph. Project Arc, the autonomous desktop agent ServiceNow announced May 5, 2026, is explicitly grounded in CMDB and runs inside NVIDIA's OpenShell sandbox [11][12]. Replicating a populated CMDB at parity is not a coding problem; it's a several-quarter Discovery-and-reconciliation deployment that every Fortune 500 customer has already paid for once. This is the most durable piece.

**2. Workflow Data Fabric + Context Engine (newer, more contested).** Announced at Knowledge 2026, Context Engine fuses five graphs — knowledge, action, access, asset, decision — into a single context substrate, sitting on top of RaptorDB Pro (their HTAP engine that runs operational and analytical queries on the same store) [13][14]. This is ServiceNow's bet that agent grounding requires *real-time, governed, lineage-tracked* enterprise data, not just CMDB snapshots. Engineering-wise this is well-architected and meaningfully ahead of Salesforce's Data Cloud equivalent for IT-adjacent workloads. Vulnerability: it depends on customers continuing to land their unstructured data in ServiceNow rather than Snowflake/Databricks/Foundry, and the Foundation-model vendors are pushing the opposite direction with their own context layers.

**3. AI Control Tower governance (newest, strategically critical).** Sets policy, monitors behavior, logs files-read / commands-executed / APIs-called for any agent — including Microsoft Copilot Studio agents and (per the May 2026 NVIDIA announcement) agents running anywhere in the NVIDIA Enterprise AI Factory [11][15]. If governance becomes the procurement gate for enterprise agent rollouts (CISO/Audit say "no agent without observability"), ServiceNow becomes the toll booth. This is the most strategically valuable but also the most defensible-by-others claim — Microsoft Purview, Google Agentspace, and Anthropic's Managed Agents are all competing for the same role.

**4. Native MCP, both server and client (commoditized).** As of the Zurich release, ServiceNow exposes its workflows as an MCP server *and* consumes external MCP servers as a client [16]. This is necessary table-stakes but *erodes*, not strengthens, lock-in: any LLM can now read/write ServiceNow without re-implementing integration code. It is the explicit price of remaining the system-of-action.

**5. Distribution (durable).** 8,800+ customers, 97-98% renewal rate, 85%+ of Fortune 500, 244 deals >$1M ACV in Q1 alone, and Now Assist customers expanding ACV 3× on renewal [17][18]. This is harder to disrupt than any individual technical component.

Honest assessment: the code-level moat (kernel libraries, hardware-aware compilers, foundry allocation) that NVIDIA has does not exist here. The moat is data gravity in CMDB plus distribution into IT/HR procurement. Both are real and both have a measurable half-life if agentic AI lets practitioners stand up custom workflow tooling without ServiceNow.

## AI buildout bottleneck map
ServiceNow is **structurally indifferent** to the physical AI buildout — it does not own GPUs, packaging slots, HBM contracts, or cooling capacity. Its workloads are inference, mostly served on hyperscaler-rented capacity (AWS-hosted DGX Cloud for Apriel-Nemotron training/post-training [3]) plus on-prem NVIDIA infrastructure at Fortune 500 customers via the Enterprise AI Factory partnership [11]. Where it sits relative to each gating constraint:

- **Power generation / grid:** indifferent. Inference cost is small and fits inside customer hyperscaler footprints.
- **CoWoS-L / HBM3e:** indirect beneficiary if customer demand for on-prem inference accelerates (more NVIDIA boxes → more Project Arc deployments) but not exposed to allocation directly.
- **Cooling at >100kW/rack:** indifferent.
- **Frontier training data quality:** indifferent — they use 15B-class post-trained models, not frontier-scale.
- **Kernel/compiler talent:** mild beneficiary — the Apriel partnership outsources this to NVIDIA's NeMo team rather than building it in-house.
- **Enterprise AI talent (forward-deployed engineers):** **active constraint**. The Accenture forward-deployed engineering JV announced 2026 [19] is essentially an admission that customers cannot self-serve agent rollouts at the rate needed to hit Now Assist's $1.5B ACV target. This is the single biggest non-obvious operational risk and is invisible in the financials.

ServiceNow is best characterized as an **exposed customer of LLM-economics deflation**: every cost-per-token reduction at OpenAI/Anthropic/Google flows through to better Now Assist gross margin (currently compressed from 79% → 75% sequential as the AI mix grows [20]), but it also lowers the barrier for customers or competitors to build agent stacks without ServiceNow.

## Competitive teardown
Four meaningful competitors, on different axes:

**Salesforce Agentforce** — direct overlap on customer service workflows (ServiceNow CSM vs. Service Cloud) and now ITSM (Agentforce IT Service launched mid-2025). Agentforce ARR ~$800M, 29K deals, but only 200 signups in IT Service after six months vs. ServiceNow's 8,600 ITSM accounts [21][22]. CRM data depth is Salesforce's; CMDB / IT-ops depth is ServiceNow's. Net: Salesforce is unlikely to take meaningful ITSM share in 24 months but compresses CSM pricing now. Salesforce trades at 14× forward P/E vs. NOW's 21× — the multiple gap is the market pricing this risk.

**Microsoft Copilot Studio + Microsoft 365 Agents** — partner *and* competitor. Microsoft has the M365 distribution, Graph data, and identity layer ServiceNow doesn't. The May 2026 announcements [11][15] explicitly position the relationship as *governance interop* (ServiceNow Control Tower governs Microsoft agents) rather than displacement. Microsoft has chosen, for now, not to build a CMDB. The risk is they change their mind — Copilot Studio agent counts already number in the hundreds of thousands, vs. ServiceNow's tens of thousands of Now Assist deployments.

**Anthropic Claude Cowork + Managed Agents** — the catalyst for the SaaS selloff. Cowork went GA April 2026 [23]; Managed Agents is in public beta [24]. The technical thesis (held by short-sellers) is that horizontal agent platforms will obviate vertical workflow apps. The technical *counter* is that Cowork is fundamentally a knowledge-worker assistant — it lacks system-of-action grounding, audit logging at the depth a SOX-compliant Fortune 500 audit committee will accept, and a CMDB. Today this is true. In 24 months, less obviously so. **This is the right thing to watch.**

**Workday, Atlassian, Pega, BMC Helix** — flanks. Atlassian Jira Service Management is pricing aggressively below ServiceNow at the mid-market; this caps SMB expansion but is not a Fortune 500 displacement risk. Pega's process-engine play is now decade-old; not credible.

The competitive axis the bears miss: ServiceNow's defensive value is *higher* in regulated industries (financial services, healthcare, federal) where audit-grade governance is mandatory, and *lower* in product-led / engineering-first orgs. The Q1 2026 commentary about Middle East government deal slippage [25] is partly a geopolitical artifact and partly a leading indicator that public-sector renewal cycles are extending as procurement rethinks AI integration strategy.

## Bull case — technical
The bull case requires three technical conditions:

1. **The system-of-action thesis holds.** Agents do not replace the database of record; they sit on top of it and need a permissioned, audited, transactional substrate to act through. CMDB + Workflow Data Fabric is that substrate for IT-adjacent work. Base rate from prior platform shifts: vertical SaaS that owns the data layer (Salesforce in CRM, Workday in HCM) survived the BI / dashboarding wave, the cloud migration wave, and the SaaS-on-SaaS wave; horizontal tools rarely displace systems of record where audit lineage is required. This is a positive base rate.

2. **AI Control Tower wins the governance bake-off.** If CISOs standardize on one observability/policy plane for enterprise agents, ServiceNow has both the install base and a 15-month head start vs. Microsoft Purview-for-Agents and Google Agentspace governance.

3. **Pro Plus / Enterprise Plus consumption monetization compounds.** Now Assist tracking $1.5B ACV in 2026 (raised from $1B mid-cycle) [17], $1M+ Now Assist customers up 130% YoY, three-or-more-Now-Assist-products deals up ~70% YoY — these are early-cycle adoption signals that look more like Snowflake's first three years of consumption uptake than like a stalling product. 3× ACV expansion on Now Assist renewals [18] is the single most important number on the print.

If all three hold, the financial outcome is the $30B revenue / 2030 target Bill McDermott reiterated at the May 2026 Investor Day [26], with one-third coming from AI products. At today's $94B market cap that's ~3× FY30 sales — a re-rating to even 10× would imply roughly 3× the equity, or ~$270/share post-split. This requires being right on point 1 above; it is not a multiple-expansion story, it's a thesis-vindication story.

## Bear case — technical
The version a short-seller who has read the same Knowledge 2026 announcements would write:

1. **Per-seat dies; consumption is structurally less sticky.** ServiceNow's historical NRR of 98% rests on adding fulfiller seats as customers grow. AI explicitly inverts this: enterprises now buy Now Assist *to reduce* fulfiller headcount. Pro Plus uplift (25-60% over base [27]) only partially offsets fewer seats, and in steady state, agent productivity gains accrue to the customer, not the vendor — this is the classic productivity-paradox economics that destroyed value for IBM Services in the 2010s. Gross margin compression from 79% → 75% [20] is the leading indicator.

2. **MCP commoditizes the integration moat.** Once ServiceNow exposes itself as an MCP server [16], any external LLM can read/write workflows without paying for AI Agent Studio. ServiceNow has effectively published its own commoditization protocol. The bull's "system of action" claim depends on the *interface* being valuable; MCP makes the interface free.

3. **The CMDB itself is a wasting asset in a code-generation world.** If small teams can stand up custom workflow tooling using Cowork + Cursor + a Postgres backend in days rather than the multi-quarter Discovery rollouts ServiceNow requires, the asymmetric setup cost that protects the CMDB collapses. Base rate: this is what happened to ETL vendors when dbt + Snowflake compressed the deployment cycle from quarters to days.

4. **Margin reset is not transitory.** Armis acquisition takes 75bps off operating margin and 200bps off FCF margin in 2026 [25]. That's an option premium being paid for security/asset-discovery in a world where NVIDIA OpenShell and CrowdStrike Charlotte AI are racing for the same agent-observability turf.

5. **Government / Middle East slippage is a tell.** When the most procurement-disciplined customers slow down their deal cycles citing AI strategy, that is what the early innings of platform displacement look like. It is not sufficient evidence yet, but it is consistent with the bear case.

The honest bear case is *not* "SaaS is dead." It is "ServiceNow's specific economic engine — fulfiller seats × annual price increase × land-and-expand to adjacent modules — does not survive the transition to agent-mediated work, and consumption pricing under-monetizes it. The product is fine; the unit economics revert."

## Market view check
At $91 / 21× forward P/E / ~5.5× FY26 subscription, ServiceNow is trading at the cheapest forward multiple in five years — historically it traded 40-60× forward earnings and 12-15× forward sales. The consensus PT spread is unusually wide ($144 to $236 [9]), which means the sell-side itself is bimodally split between "AI displaces them" and "AI is their tailwind." The market is *not* pricing ServiceNow as a melting ice cube (a 21× multiple still requires meaningful long-term growth) but it is pricing meaningful skepticism that the $30B 2030 target survives. Specifically, the market appears to believe Now Assist ACV growth will plateau short of management's $1.5B 2026 / proportional 2030 targets, and that gross margin will not recover from the 75% Q1 print. If both of those are wrong, the stock is materially mispriced upward. If both are right, 21× is still too expensive. **The investable question is which of those two beliefs is correct, not whether the multiple is "fair."**

## 90-day falsifiers
Specific events that would update the thesis materially before mid-August 2026:

- **Q2 2026 earnings (late July):** does subscription gross margin recover from 75% toward 78%+, or stay compressed? This is the cleanest single test of whether AI mix is structurally margin-dilutive.
- **Q2 Now Assist ACV disclosure:** the $1.5B 2026 trajectory implies ~$375M ACV/quarter run-rate; missing by >10% would invalidate the consumption-monetization bull case.
- **Project Arc GA pricing announcement:** currently "early preview" [11]. The pricing model (per-agent, per-action, or bundled into Enterprise Plus) signals how aggressively management defends per-seat economics.
- **Anthropic Cowork enterprise-customer disclosures (likely at an Anthropic event):** if they name F500 ITSM/HRSD references, that's a direct moat threat. Silence is bullish.
- **Microsoft Build (May 2026) and Google I/O announcements:** any first-party CMDB or agent-observability product from either is materially negative.
- **Federal / DoD ATO progress on Now Assist:** government slippage was cited in Q1 [25]; reversal would derisk the bear thesis on procurement-cycle elongation.
- **Salesforce Agentforce IT Service customer count update (Salesforce Q2 print, late August):** if Agentforce IT Service goes from 200 → >1,000 customers in two quarters, that is an actual share-shift signal, not just noise.

## What I could not verify
- Apriel-Nemotron-15B's published MLPerf-equivalent benchmark results vs. Llama-3.3-70B or Claude Haiku on enterprise-workflow tasks — I could not find independent third-party evals as of the cutoff.
- Exact attach rate of Pro Plus to the existing ITSM Pro install base. Third-party estimates exist; ServiceNow does not disclose.
- Whether the $1.5B Now Assist ACV figure is gross or net of cannibalization from base ITSM seats — this is the single most important disclosure investors should push for on the Q2 call.
- Specific terms of the Armis purchase price and synergy assumptions (only the dilution figures are public).
- Whether Project Arc's NVIDIA OpenShell integration is an exclusive arrangement or open to competing agent vendors.
- The actual fraction of Now Assist revenue coming from RaptorDB-backed Context Engine workloads vs. legacy GenAI Now Assist features; the architectural narrative implies one thing, the revenue mix may be different.
- Independent verification that AI Control Tower governs Microsoft Copilot Studio agents in production (not just announced as integration), and at what scale.

## Sources
[1] https://www.theregister.com/2026/04/11/salesforce_vs_servicenow_itsm_battle/ — retrieved 2026-05-10 — established ServiceNow ~40% ITSM market share and 8,600 ITSM customers.
[2] https://cyntexa.com/blog/servicenow-statistics/ — retrieved 2026-05-10 — established 8,800+ global customers, 85%+ Fortune 500.
[3] https://blogs.nvidia.com/blog/servicenow-apriel-nemotron/ — retrieved 2026-05-10 — Apriel-Nemotron-15B technical details, NVIDIA NeMo training, AWS DGX Cloud.
[4] https://www.servicenow.com/products/ai-agents.html — retrieved 2026-05-10 — AI Agent Studio, Orchestrator, Action Fabric architecture overview.
[5] https://stockanalysis.com/stocks/now/ — retrieved 2026-05-10 — current price $91.18, market cap $94.0B, shares outstanding 1.03B, 52-week range, forward P/E 21.0×.
[6] https://newsroom.servicenow.com/press-releases/details/2025/ServiceNow-Shareholders-Approve-5-for-1-Stock-Split/default.aspx — retrieved 2026-05-10 — 5-for-1 split executed Dec 17, 2025.
[7] https://stockanalysis.com/stocks/now/statistics/ — retrieved 2026-05-10 — EV $88.6B, EV/Revenue 6.34x trailing.
[8] https://futurumgroup.com/insights/servicenow-q1-fy-2026-results-raise-full-year-subscription-outlook/ — retrieved 2026-05-10 — FY26 subscription revenue guide $15.735-15.775B raised.
[9] https://www.marketbeat.com/stocks/NYSE/NOW/forecast/ — retrieved 2026-05-10 — analyst consensus PT range, short interest 38.95M shares / 3.78% of float, days to cover 1.54.
[10] https://www.financecharts.com/stocks/NOW/performance/total-return — retrieved 2026-05-10 — YTD total return -42.69%.
[11] https://newsroom.servicenow.com/press-releases/details/2026/ServiceNow-extends-agentic-AI-governance-from-desktops-to-data-centers-with-NVIDIA/default.aspx — retrieved 2026-05-10 — Project Arc, NVIDIA OpenShell integration, AI Control Tower extension to Enterprise AI Factory, dated May 5, 2026.
[12] https://tech.yahoo.com/ai/meta-ai/articles/servicenow-nvidia-launch-autonomous-desktop-132546282.html — retrieved 2026-05-10 — Project Arc CMDB grounding, Action Fabric.
[13] https://newsroom.servicenow.com/press-releases/details/2026/ServiceNow-launches-the-real-time-data-foundation-that-puts-autonomous-AI-to-work-across-the-enterprise/default.aspx — retrieved 2026-05-10 — Context Engine, Workflow Data Fabric, Autonomous Data Analytics announcements.
[14] https://www.shashi.co/2026/05/servicenow-knowledge-2026-day-2-when.html — retrieved 2026-05-10 — five-graph Context Engine architecture, RaptorDB Pro HTAP engine.
[15] https://www.cxtoday.com/security-privacy-compliance/servicenow-ai-agent-governance-knowledge-2026/ — retrieved 2026-05-10 — AI Control Tower governance scope across Microsoft 365 agents.
[16] https://www.servicenow.com/community/ceg-ai-coe-articles/mcp-the-protocol-powering-agentic-ai/ta-p/3508887 — retrieved 2026-05-10 — Zurich release native MCP server + client support.
[17] https://www.tikr.com/blog/servicenow-q1-2026-revenue-beats-but-ai-inflection-still-coming — retrieved 2026-05-10 — Now Assist $1.5B ACV target, $1M+ customers +130% YoY, three+ products +70% YoY.
[18] https://www.efficientlyconnected.com/servicenow-q1-2026-ai-platform-growth/ — retrieved 2026-05-10 — Now Assist renewals expand ACV 3×, 16 transactions >$5M net new ACV +80% YoY.
[19] https://newsroom.accenture.com/news/2026/servicenow-and-accenture-launch-forward-deployed-engineering-program-to-scale-agentic-ai-across-the-enterprise — retrieved 2026-05-10 — Accenture forward-deployed engineering JV.
[20] https://www.fool.com/investing/2026/05/03/why-servicenow-stock-fell-16-in-april/ — retrieved 2026-05-10 — gross margin 79%→75% sequential compression.
[21] https://www.aiagentlearn.site/comparisons/salesforce-agentforce-vs-servicenow-ai/ — retrieved 2026-05-10 — Salesforce Agentforce $800M ARR, 29K deals.
[22] https://www.theregister.com/2026/04/11/salesforce_vs_servicenow_itsm_battle/ — retrieved 2026-05-10 — Agentforce IT Service 200 signups vs. ServiceNow 8,600 ITSM accounts.
[23] https://9to5mac.com/2026/04/09/anthropic-scales-up-with-enterprise-features-for-claude-cowork-and-managed-agents/ — retrieved 2026-05-10 — Claude Cowork GA, Managed Agents public beta.
[24] https://claude.com/product/cowork — retrieved 2026-05-10 — Cowork product positioning.
[25] https://finance.yahoo.com/markets/stocks/articles/servicenow-q1-2026-earnings-stock-173132844.html — retrieved 2026-05-10 — Armis acquisition 75bps op margin / 200bps FCF margin dilution, Middle East deal slippage 75bps subscription headwind.
[26] https://fortune.com/2026/05/06/servicenow-30-billion-revenue-not-crazy-why/ — retrieved 2026-05-10 — $30B FY30 revenue target, ~1/3 from AI.
[27] https://redresscompliance.com/servicenow-now-assist-ai-pricing-guide.html — retrieved 2026-05-10 — Now Assist Pro Plus 25-60% pricing uplift over base Pro/Enterprise.