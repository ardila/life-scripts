I have enough to write. Drafting the dossier now.

# ROK — Rockwell Automation, Inc.

## Where this sits in the AI stack
Rockwell does **not** sit in the AI silicon/training/inference stack. It sells industrial automation hardware (Allen-Bradley PLCs — primarily the ControlLogix 5580 / CompactLogix 5380 families, motion drives, safety I/O) and the software that programs and orchestrates them (Studio 5000 Logix Designer, FactoryTalk, Plex MES, Fiix CMMS, Verve OT-cybersecurity, OTTO/Clearpath AMRs) [3][8][14]. Its AI exposure is one layer below the rack: the **building management, electrical power monitoring (EPMS), chiller/CDU sequencing, switchgear paralleling, and BMS** that keep a hyperscale or colo facility alive. The relevant workload is not a training job — it is a 50–250 MW critical facility whose owners have decided that commercial-grade DDC controllers (Distech, JCI Metasys, Honeywell ComfortPoint) are no longer acceptable for AI density, and are replacing them with industrial PLCs [4][5].

## Snapshot
- **Price:** $453.89 (2026-05-09 close) [1]
- **Market cap:** ~$50.5B [1]
- **52-week range:** $285.94 – $463.49 [11]
- **Forward P/E:** 33.3× (vs. 5-year avg ~26.3×) on FY26 adj. EPS guide $12.50–$13.10 midpoint [9][7]
- **EV / NTM revenue:** ~5.6× (EV/EBITDA ~30×; ~24.6× 2027 EV/EBITA, ~40% premium to automation peers ~18×) [9]
- **Consensus 12-month price target:** $428.66 (range $248–$495; 15 Buy / 14 Hold / 1 Sell, 26 analysts) — implies **−5.5%** from current price [8]
- **YTD 2026 total return:** ~+1.4% (1-year ~+60%; stock just printed all-time closing high $459.35 on 2026-05-06) [11]
- **Short interest:** 2.76% of shares outstanding (~3.1M shares) [10]

## Moat — what it is physically made of
Decomposed into components with separate durability:

**1) The Logix runtime and Studio 5000 toolchain.** ControlLogix/CompactLogix run a single tag-based execution model with hard real-time scan determinism; one Studio 5000 project compiles down to controllers ranging from a CompactLogix 5380 ($3–8k) to a redundant ControlLogix 5580 ($30–80k+) without rewriting the application. The lock-in is not the silicon — it is that **every line of ladder/ST/FBD an integrator has written in the last 20 years is in Studio 5000**, every I/O module is keyed to a 1756/1769 chassis, every machine state diagram presumes Allen-Bradley's Add-On Instruction abstraction. This is closer to a COBOL-class language ecosystem than to a hardware moat. **Durability: high (10+ years).** Siemens S7-1500 is faster per-instruction (~0.04 ms/1000 instructions vs. ~0.1 ms on ControlLogix) and ~30–50% cheaper on licensing [13], but a North American food-and-beverage or pharma plant cannot fire its Rockwell integrator pool overnight.

**2) EtherNet/IP + CIP.** Rockwell originated CIP (Common Industrial Protocol); ODVA administers it [12]. EtherNet/IP is the dominant North American industrial fieldbus and is now competing with PROFINET (Siemens-led) on a per-region basis. Censys recently identified 5,219 internet-exposed Rockwell/Allen-Bradley EtherNet/IP devices globally, **74.6% inside the US** [4] — a crude but useful proxy for installed-base geography. **Durability: high in NA, mediocre globally.**

**3) System integrator and certified-engineer base.** Rockwell's PartnerNetwork plus the "Advanced Logix 5000 Programmer" certification track has produced the largest English-language pool of certified PLC programmers; for a US data center general contractor (Holder, DPR, Mortenson, M.C. Dean), staffing an Allen-Bradley job is materially easier than staffing a Siemens job. Person-years to recreate this ecosystem from scratch: not the right framing — a competitor would have to wait for the **next** plant generation to bid greenfield. **Durability: high, but conditional on continued NA reshoring trajectory.**

**4) Software stack (Plex MES, Fiix CMMS, FactoryTalk Optix, Verve OT-security).** Acquired for $2.2B (Plex, 2021), ~$600M (Clearpath/OTTO, 2023), and Verve [14][15]. This is a real but unfinished pivot toward SaaS; FactoryTalk is decent but not best-in-class for true cloud-native MES at hyperscaler scale. **Durability: medium. This is the most contestable layer.**

**5) Sensia (Schlumberger JV) and Allen-Bradley brand in process industries.** Real in oil & gas; tangential to the AI thesis.

What is **not** a moat: Rockwell does not own unique silicon (controllers are off-the-shelf Arm/PowerPC SoCs from NXP/TI; ASICs in I/O are mid-volume parts), does not own a foundry relationship that matters, owns no HBM/CoWoS/optical supply, and is not on TSMC's allocation list for anything. Where the prompt asks about "TSMC CoWoS-L allocation" — irrelevant. ROK's manufacturing constraint is **its own assembly capacity in Twinsburg, OH; Singapore; and Katowice, Poland**, plus the global supply of MCUs and ruggedized passives.

## AI buildout bottleneck map
Gating constraints on the 2026–2028 AI buildout and where ROK sits:

- **Power generation & grid interconnect (5–7 year wait for new gas turbines; 4+ year interconnect queues):** ROK is **indifferent** at the generation layer but is a **direct beneficiary** of the on-site electrical scope — generator paralleling controls, automatic transfer switch (ATS) sequencing, medium-voltage switchgear automation. PLCs sit on this scope.
- **Advanced packaging (CoWoS-L), HBM3e/HBM4 yield, optical interconnect:** ROK is **indifferent**. No exposure.
- **Liquid cooling at >100 kW/rack:** ROK is a **second-derivative beneficiary**. It is listed by analysts among DC liquid-cooling supply-chain participants alongside 3M, Parker Hannifin, Schneider, Emerson [4] — but its role is sequencing the CDUs, chillers, dry coolers, and pumps via PLCs, not making cold plates or coolant. The plumbing comes from Vertiv/Boyd/CoolIT; the **control logic** runs on Logix.
- **Electrical contractor / MEP capacity:** ROK is **exposed-positive** — its products are specified in the MEP design package the contractor installs. The win at the new Texas AI data center via ATS Automation is exactly this channel [16].
- **Kernel/compiler/CUDA talent:** Irrelevant to ROK.
- **OT cybersecurity (a real bottleneck given Iran-linked attacks on PLCs documented by FBI/CISA in April 2026):** ROK is **owner-of-the-problem and seller-of-the-fix** via Verve. This is dual-edged — the same Censys report flagging 5,219 exposed AB devices [4] is a brand risk and a Verve revenue opportunity.
- **Frontier training data quality:** Irrelevant.

Net: ROK touches **two** of the eight gating constraints (on-site electrical, cooling controls) and owns the OT-cyber spillover. It is not a primary AI bottleneck holder — it is a competent toll-collector on the construction layer.

## Competitive teardown
The right competitor map is **not** NVIDIA/AMD. It is:

- **Siemens Digital Industries (SIE.DE, ~25% global PLC share vs. ROK ~15–18%) [2]:** Wins on per-instruction speed (0.04 vs. 0.1 ms / 1000 instructions on the comparable controller), wins on TIA Portal simulation/emulation, wins on license cost, wins on European installed base, **already at parity on motion in non-NA markets** [13]. Siemens loses on NA integrator availability and on cohesive single-vendor-stack story. For Siemens to take material share in US AI data centers, US EPCs would need to staff up Siemens-certified programmers — possible over 5+ years, not in the next 24 months.
- **Schneider Electric (SU.PA):** This is the more dangerous competitor for the *data center* thesis specifically. Schneider's Energy Management segment grew ~13% in Q1 FY26 and is the established hyperscaler partner of record on **power** (UPS, busway, MV switchgear, prefab modular DC) [17]. Schneider just signed a **$1.9B supply capacity agreement with Switch** for AI factories [17]. Schneider already has the BMS+EPMS franchise via EcoStruxure that competes directly with FactoryTalk-on-data-centers. The question is not whether Schneider plays — it is **already winning** at the hyperscaler level. Rockwell's data-center growth is coming disproportionately from the **colo/AI build-out tier** (the ATS Automation/Texas profile) and from the shift from commercial-DDC controllers to industrial-PLC controllers, not by displacing Schneider EcoStruxure at Microsoft/Meta/Google direct.
- **ABB:** Strong in process automation and drives. ABB and Rockwell are in a slow share-trade across motion; not the AI story.
- **Emerson:** Process control leader (DeltaV DCS). Tangential to AI data centers; relevant to the LNG-for-AI-power thesis indirectly.
- **The commercial-DDC incumbents (JCI Metasys, Honeywell ComfortPoint, Schneider EcoStruxure BMS, Distech):** This is the **share donor** in Rockwell's data center growth story. Rockwell's bull case is that AI density makes these systems' uptime SLA unacceptable and customers are migrating to industrial-grade PLC-based BMS. Q2 FY26 results suggest this is happening at the colo/AI tier [3][16].

The honest read: on **NA discrete factory automation**, Rockwell is the unambiguous leader and Siemens has been unable to crack it for 20 years. On **AI data center power & cooling**, Rockwell is a **net taker of share from JCI/Honeywell DDCs** but a **net loser of share to Schneider** at the hyperscale tier. The Q2 print represents the first effect dominating; this could reverse if Schneider integrates BMS+power more aggressively.

## Bull case — technical
Technical conditions that must hold for ROK to outperform from $454:

1. **AI data center power density continues climbing past 130 kW/rack.** Liebert/CRAC-and-DDC stacks were designed for ~10 kW racks; at 100+ kW (NVL72 class) the failure modes (cooling lag, sequencing race conditions) demand hard-real-time PLC determinism with sub-10 ms scan, which industrial PLCs deliver and commercial DDC does not. This drives the substitution Rockwell saw in Q2.
2. **Colo and neocloud build-out remains the marginal share of new AI capacity** (CoreWeave, Lambda, Crusoe, Applied Digital, Equinix xScale, Digital Realty hyperscale fit-out). These customers prefer the "speed-to-energization" of a known PLC toolchain over Schneider EcoStruxure's deeper hyperscaler integration. Q2 commentary supports this [3].
3. **Reshoring/CHIPS-funded fab automation continues.** Discrete automation in NA was only +2% in Q2 — the multiplier hasn't really kicked in yet [6][18]. If TSMC AZ, Intel OH, Samsung TX, Micron NY scale capex through 2027, ROK has a credible ~20% specified share of announced CHIPS-funded fabs [18] — note this number is hard to independently verify.
4. **Logix software attach and SaaS (Plex/Fiix/Verve) compound margin.** Q2 software & control margin already in the low 30s vs. ~20% intelligent-devices; if this mix continues, the 21.5% enterprise op-margin guide is conservative.
5. **Siemens fails to materially staff NA integrator depth** over the next 24 months. Base rate on this kind of NA-installed-base displacement is slow: x86→ARM took ~15 years in mobile and is still uncompleted in server; ICE→EV is taking 20+; the cleanest analog (Mitsubishi/Omron PLC penetration into NA discrete) has barely moved in 25 years.

Connected to financials: at the FY26 EPS midpoint $12.80, a 60% incremental-margin trajectory plus 7–10% organic growth tracks toward ~$15 FY27 EPS. At a 30× multiple (in-line with current), that supports ~$450; at 33× supports ~$495. The bull case is **earnings holding the multiple flat**, not multiple expansion from here.

## Bear case — technical
Symmetric:

1. **Data center demand is the single non-cyclical driver in the mix; everything else (auto, CPG, life sciences) is weak.** Q2 commentary explicitly called out "persistent trade volatility and geopolitical uncertainty continue to delay large capital investments" in auto and CPG [7]. If the data center vertical normalizes from +100% to +20% in FY27, organic growth math collapses to ~3-4%, not 7-9%.
2. **Schneider Electric's EcoStruxure for Data Centers gets specified at marginal hyperscaler campuses ahead of Logix.** Schneider's integrated power+cooling+BMS+monitoring story is the natural single-pane-of-glass for AI-factory PPA-driven builds; Rockwell sells the controller, not the full stack. The $1.9B Switch deal [17] is exactly this risk realized.
3. **The "industrial-grade replaces commercial-grade" thesis turns out to be a one-time substitution event, not a structural growth driver.** Once the inventory of new AI builds has been re-specified to industrial PLCs, the run-rate growth rate normalizes back to PLC-market CAGR (high single digits).
4. **OT-cybersecurity headline risk materializes into customer flight.** CISA/FBI April 2026 advisory on Iran-linked attacks targeting exposed Rockwell PLCs at critical infrastructure [4] is brand-damaging if a high-profile data center compromise gets attributed to default-credentialed Allen-Bradley devices. The Verve acquisition is a partial defense but is still a $50–100M revenue line vs. core risk.
5. **Valuation is the bear case by itself.** 33× forward P/E vs. 26× 5-year average and ~40% premium to peers [9] requires the bull case to materialize fully. Stock is +60% over 12 months and right at all-time highs. Base rate on industrial cyclicals trading at 30+ × forward: durably outperforming from this multiple is rare; the standard outcome is multiple compression at the next macro stall.

A short-seller who actually understands the stack would write: "ROK is real but priced for the entire AI tailwind to land in its quarterly numbers, and the share-donor (commercial DDC) is a finite pool. Sell the multiple, not the company."

## Market view check
At $454 the market is paying 33× FY26 EPS and 5.6× EV/sales for a company whose **organic** growth guide is 5–9% and whose enterprise op margin guide is 21.5%. The consensus 12-month target of $428.66 [8] implies the market has run ahead of the sell-side after the Q2 print. The market is apparently believing that (a) the data center vertical sustains >50% growth through FY27, (b) reshoring discrete demand inflects in H2 FY26, and (c) software-mix margin shift continues. The first is plausible, the second is unproven (discrete NA was only +2% in Q2 [7]), the third is the most credible. **My read: the technical thesis is sound but the price embeds most of it.** Mispricing direction: slightly rich on the multiple, not on the business quality. This is not a "huge mispricing" trade in either direction at $454; it is a "trim into strength, accumulate on the next industrial pullback below ~$370" trade.

## 90-day falsifiers
Specific events to watch through ~August 2026:

1. **Q3 FY26 print (early August 2026):** If data center vertical grows <70% YoY (vs. >100% in Q2), the substitution story has front-loaded. Threshold to update bull case down.
2. **Book-to-bill:** If Q3 b/b drops below 1.0 with no offsetting commentary on backlog burn from data center, growth durability is questioned. Q2 was "slightly above historical 0.95–1.1 range" [7].
3. **Schneider Electric H1 2026 results (late July):** Watch for explicit hyperscaler BMS+EPMS contract wins where Schneider takes scope Rockwell historically might have addressed. A second campus-scale deal of the Switch magnitude would confirm Schneider primacy at hyperscalers.
4. **Hyperscaler capex guidance in late July / early August prints (MSFT, META, GOOG, AMZN):** A sequential cut >10% in any of the four to Q3 capex guide would directly hit Rockwell's most explosive growth vertical with a 2–3 quarter lag.
5. **Discrete reshoring orders:** If H1 FY26 ends with NA discrete still at +0–3% (vs. expected mid-single inflection), the second leg of the bull thesis is failing.
6. **Any high-profile OT cyber incident** at a US AI data center attributed to Allen-Bradley/Logix devices. This is a tail risk but materially asymmetric — see the CISA April 2026 advisory [4].
7. **Siemens Digital Industries Q3 print (late July) and any TIA Portal–for–Data-Center push.** Siemens has not yet pivoted hard at the BMS-for-AI segment; if they do, it is a 24-month problem, not 90-day, but the announcement would matter.

## What I could not verify
- The specific claim that **"Rockwell secures ~20% of announced CHIPS-funded fab projects"** [18] — this comes from a single secondary source and I could not corroborate against a primary list of fab-project automation specs.
- **Exact data center vertical $ size.** Rockwell discloses only "low single-digit % of company sales" [7] — analyst extrapolation to "high single digits by FY27" assumes 100%/50% sequential vertical CAGR.
- **Rockwell's NA PLC market share** vs. Siemens. I have 5-vendor-77% [2] and ranking (Siemens #1, Rockwell #2 globally; Rockwell #1 in NA per anecdotal sources) but no clean NA-only split.
- **Hyperscaler-direct vs. colo/AI-build split** within Rockwell's data center vertical growth. Q2 commentary points to colo/AI-build (the ATS Automation Texas win [16]); I could not get a clean direct-hyperscaler customer list.
- **Specific patent moat** around Logix runtime / CIP. ODVA-administered CIP is by design open and royalty-free; whatever Rockwell-specific IP exists around the Logix tag database, motion-planning kernels, and Add-On Instruction was not findable as enforceable patent claims.
- **The actual liquid-cooling supply-chain role** of Rockwell beyond "sequences the CDUs/chillers via PLCs." Some secondary sources list Rockwell as a "raw material supplier" in DC liquid cooling alongside 3M and Parker Hannifin [5] — this looks like a categorical error in those reports rather than actual coolant or cold-plate participation.
- **EV/NTM revenue** specifically — I have EV/sales at 5.6× as of mid-Feb 2026 [9]; given the stock is up materially since then, the current ratio is likely ~6.3× — but I could not pin the exact NTM consensus revenue figure.

## Sources
[1] Yahoo Finance — ROK Stock Price History — retrieved 2026-05-10 — Price $453.89 close 2026-05-09; all-time-high closing $459.35 on 2026-05-06 — https://finance.yahoo.com/quote/ROK/
[2] gminsights / Mordor Intelligence — PLC market size and share — retrieved 2026-05-10 — Siemens ~22% global PLC share; top-5 (Siemens, Rockwell, Schneider, Mitsubishi, ABB) hold 77% in 2025; ~$11.7B PLC market 2025 — https://www.gminsights.com/industry-analysis/programmable-logic-controller-market
[3] Rockwell IR — Q2 FY26 Press Release & Prepared Remarks — retrieved 2026-05-10 — Q2 revenue $2.24B (+12%); Logix +20%; data center >100% YoY; op-margin 22.5%; FY26 guide raised — https://www.rockwellautomation.com/en-us/company/news/press-releases/Rockwell-Automation-Reports-Second-Quarter-2026-Results.html
[4] Industrial Cyber / Censys / FBI-CISA — Iran-linked PLC targeting — retrieved 2026-05-10 — 5,219 exposed AB/EtherNet/IP devices, 74.6% in US; April 2026 CISA advisory — https://industrialcyber.co/industrial-cyber-attacks/censys-warns-systemic-exposure-of-rockwell-plcs-enable-iran-linked-targeting-of-critical-infrastructure-ot-networks/
[5] Rockwell — Data Center Automation Framework white paper — retrieved 2026-05-10 — PLC role in BMS/EPMS/cooling control; cited inclusion in liquid cooling supply chain — https://www.rockwellautomation.com/content/dam/rockwell-automation/documents/pdf/industries/semiconductor/data-centers/0225_000669_DataCenterAutomationFramework_WhitePaper_final.pdf
[6] Stocktitan — Rockwell lifts 2026 outlook — retrieved 2026-05-10 — Warehouse/DC demand drivers, full-year guide details — https://www.stocktitan.net/news/ROK/rockwell-automation-reports-second-quarter-2026-xou48dz0tfw9.html
[7] Motley Fool — Rockwell Q2 FY26 Earnings Call Transcript — retrieved 2026-05-10 — Verbatim CEO/CFO commentary on book-to-bill (0.95–1.1 corridor), Logix +20%, data center "more than doubled", segment margins, FY26 guide — https://www.fool.com/earnings/call-transcripts/2026/05/05/rockwell-rok-q2-2026-earnings-call-transcript/
[8] StockAnalysis / MarketBeat — ROK analyst consensus — retrieved 2026-05-10 — 26 analysts, 15 Buy / 14 Hold / 1 Sell, consensus PT $428.66, range $248–$495; forward P/E 33.3× vs. 5-yr avg 26.3× — https://stockanalysis.com/stocks/rok/forecast/
[9] multiples.vc / GuruFocus / TIKR — ROK valuation multiples — retrieved 2026-05-10 — EV/Revenue 5.6×; EV/EBITDA ~30×; 2027 EV/EBITA ~24.6× vs. peers ~18× (~40% premium) — https://multiples.vc/public-comps/rockwell-automation-valuation-multiples
[10] Yahoo Finance / WallStreetZen — ROK short interest & ownership — retrieved 2026-05-10 — Short interest 2.76% of shares outstanding (~3.1M shares) — https://www.wallstreetzen.com/stocks/us/nyse/rok
[11] Macrotrends / IndexBox — ROK 52-week range and YTD return — retrieved 2026-05-10 — 52-w range $285.94–$463.49; YTD 2026 +1.36%; 1-year ~+60% — https://www.macrotrends.net/stocks/charts/ROK/rockwell-automation/stock-price-history
[12] ODVA / Copperhill — EtherNet/IP & CIP governance — retrieved 2026-05-10 — Rockwell-originated, ODVA-administered open spec; EtherNet/IP dominant NA industrial fieldbus — https://copperhilltech.com/blog/industrial-ethernet-guide-ethernetip/
[13] plcprogramming.io / IndustrialMonitorDirect — TIA Portal vs. Studio 5000 / S7-1500 vs. ControlLogix 5580 technical comparison — retrieved 2026-05-10 — Scan time (0.04 vs. 0.1 ms/1k instr.); licensing cost delta 30–50%; motion-control parity gap — https://plcprogramming.io/blog/tia-portal-vs-studio-5000-comparison
[14] Rockwell — Acquisition history (Plex $2.2B, Fiix, Verve Industrial Protection) — retrieved 2026-05-10 — Software/SaaS pivot detail — https://www.rockwellautomation.com/en-us/company/news/articles/acquisition-history.html
[15] Rockwell / Robot Report — Clearpath/OTTO Motors acquisition (~$600M, 2023) — retrieved 2026-05-10 — AMR market position; ~30% AMR market CAGR; $6.2B by 2027 — https://www.therobotreport.com/rbr50-spotlight-rockwell-automations-acquisition-otto-motors-all-around-win/
[16] InsiderMonkey / Yahoo Q2 26 transcript coverage — ATS Automation / Texas AI data center commercial-to-industrial control conversion — retrieved 2026-05-10 — Customer-win specifics — https://www.insidermonkey.com/blog/rockwell-automation-inc-nyserok-q2-2026-earnings-call-transcript-1754843/
[17] Schneider Electric / Investing.com / Facilities Dive — Schneider Q1 FY26 results; $1.9B Switch agreement; Energy Management +13% — retrieved 2026-05-10 — Competitive context for hyperscaler-direct DC scope — https://www.investing.com/news/company-news/schneider-electric-q1-2026-slides-11-organic-growth-ai-strategy-advances-93CH-4647883
[18] ad-hoc-news / Morgan Stanley note coverage — CHIPS-funded fab automation share claim (~20% Rockwell-specified) — retrieved 2026-05-10 — Reshoring exposure (unverified against primary CHIPS award documentation) — https://www.ad-hoc-news.de/boerse/news/ueberblick/rockwell-automation-stock-us7739031091-why-does-its-industrial/69152525