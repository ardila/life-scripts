# BKR — Baker Hughes Company

## Where this sits in the AI stack

Baker Hughes does not build silicon, packaging, memory, networking, racks, cooling, runtimes, or models. It sits roughly **two layers upstream of the rack**, in the *primary-mover* layer of the data-center power island: it sells (i) small- and mid-frame industrial gas turbines (NovaLT, 5.5–17.5 MW) and (ii) packaged GE-aero engines (LM2500/LM6000PF+/LM9000, 24–73 MW) plus generators, gears, controls, and balance-of-plant for behind-the-meter (BTM) power generation that bypasses the multi-year utility interconnection queue [1][3][6][12][13]. The same Florence/Nuovo-Pignone turbomachinery franchise also supplies the centrifugal-compressor "trains" inside LNG liquefaction plants — the gas pipe whose throughput is what makes BTM gas-fired AI campuses feasible at all [4][6][8]. So BKR is best read as *the rotating-equipment vendor that sits between the wellhead and the GPU rack*.

## Snapshot

- **Price:** $63.99 (2026-05-10 close) [2]
- **Market cap:** ~$63.4B [2]
- **52-week range:** $35.83 – $70.41 [11]
- **Forward P/E:** ~20.8× (on FY26 consensus EPS ~$2.67) [9][14]
- **EV / NTM revenue:** ~2.2× (EV ~$62.8B; EV/Sales 2026 ~2.23) [14][16]
- **EV / EBITDA (TTM):** 14.66× — ~19% above 10-yr median of 12.30× [16]
- **Consensus 12-month price target:** ~$67–69 (~+5–8% from $63.99) [9]
- **YTD total return:** ~+25% (price-only) [2][11]
- **Short interest (% of float):** 3.3% as of 2026-03-09; below peer-group avg of 8.77% [15]

## Moat — what it is physically made of

The "Baker Hughes moat" is not one moat; it is two assets stapled together, with very different durability.

**1. Nuovo Pignone / Florence turbomachinery franchise (durable, deep).**
The Florence complex — 350,000 m², ~4,000 employees, ~1,200 dedicated R&D engineers — has been designing centrifugal compressors and industrial turbines since the 19th century [10]. The economically valuable IP is in (a) the **aerothermal design of high-pressure-ratio centrifugal compressor stages** that pull refrigerant cycles in LNG mega-trains, and (b) the **packaging/integration** of those compressors with multi-MW drivers, instrumentation, and dynamic-stability controls. These designs are protected by decades of reference data, hot-section metallurgy know-how, and — most importantly — **customer qualification**: an EPC like Bechtel, KBR, or Saipem will only book a $3–8B liquefaction train against a vendor whose machines have a multi-decade availability record on similar duty. NextDecade's framework for Rio Grande LNG Trains 4–8, QatarEnergy LNG North Field West, and ST LNG Matagorda are all referenced wins of this sort [4]. The realistic count of vendors that can deliver a refrigerant-compression train at this scale is roughly *three globally* (BKR/Nuovo Pignone, Siemens Energy, MHI). The qualification cycle for a *new* entrant is plausibly 5–10 years and one full reference plant; it is the textbook case of a "boring" rotating-equipment moat.

**2. Aeroderivative + NovaLT package business (shallower than it looks).**
The LM2500/LM6000/LM9000 are **GE Aerospace engine cores**; Baker Hughes packages and sells them under a long-standing supply agreement and co-services them through the *Aero Alliance* JV with GE Vernova [12][7]. The economic value Baker Hughes captures here is the package (gearbox, generator, skid, controls, filter house, lube oil), the channel relationship in oil & gas, and the service revenue — not the engine IP. The *NovaLT* line (5.5–17.5 MW, ~37% simple-cycle, multi-fuel up to 100% H₂, 35,000-hr MTBM, 24-hr engine swap) is wholly Baker Hughes IP from Nuovo Pignone [3][13]. NovaLT is meaningfully differentiated on hydrogen-readiness and small-frame efficiency, but the ~5–25 MW band is fragmented: Solar Turbines (Caterpillar), Siemens SGT-A05/A35, Wärtsilä reciprocating engines, MAN, Kawasaki, and a host of Chinese OEMs all compete. Wärtsilä's 34SG just took a 412 MW Ohio hyperscale order on 40 engines [17], and Caterpillar/Solar's 3600-class wait time is now ~107 weeks with a >$63B backlog [18] — so demand is general, not BKR-specific. This is more "scale + brand + service-network" than "irreplaceable IP."

**Net:** the LNG-compression piece is the durable moat (5–10 yr replacement cycle, oligopoly), the data-center-turbine piece is a strong tailwind beneficiary but not deeply moated.

## AI buildout bottleneck map

The actual gating constraints on the AI buildout over the next 24 months and where BKR sits relative to each:

| Bottleneck | BKR position |
|---|---|
| **CoWoS-L / CoWoS-S advanced packaging** (TSMC fully booked through 2026 [19]) | **Indifferent** — not a supplier or buyer |
| **HBM3e/HBM4 supply** (SK hynix/Samsung/Micron) | **Indifferent** |
| **Optical / co-packaged optics, NVLink/Infiniband** | **Indifferent** |
| **>100 kW/rack liquid cooling** | Indifferent (unrelated) |
| **Grid interconnect queues (5–7 yrs in PJM, ERCOT)** [21] | **Beneficiary — primary** — gas-fired BTM is the explicit work-around |
| **Large-frame CCGT lead times (5–7 yrs; GE Vernova 80 GW backlog into 2029, sold-out through 2030 by end-2026)** [20][22] | **Beneficiary, secondary** — NovaLT and aero packages slot under the >100 MW frames that are the real bottleneck; deliveries in months not years |
| **Reciprocating engines (Cat 3600 wait ~107 weeks; Wärtsilä 34SG into hyperscale)** [17][18] | **Co-supplier / partial substitute** — competes with NovaLT in the 5–60 MW band |
| **Natural-gas pipeline + LNG export capacity** (the molecule supply for BTM) | **Supplier — primary** — sells the compression trains that *enable* the new molecule supply (Rio Grande Trains 4–8, NFW, ST LNG) [4] |
| **SMR / advanced nuclear** (first commercial units 2030+ realistic [23]) | **Substitute risk, but >2030 timing** |
| **Electrical contractors, switchgear, transformers** | Indifferent |
| **Kernel/compiler talent, training data quality** | Indifferent |

The compact summary: **BKR is leveraged to exactly the bottleneck the market is most worried about (electrons in 2026–2028) on two distinct vectors — the BTM turbine itself, and the LNG compressor that fuels it.**

## Competitive teardown

- **GE Vernova** — competes on the *large-frame* (HA-class, 7HA.03 ~430 MW) where BKR has no product. In the aero band BKR/GE are partners (Aero Alliance) and combined hold ~85% of aeroderivative share, ~63.7% on a 5-yr basis [5][7]. Practically: GE wins the multi-GW gas plant (e.g., the Chevron/Engine No. 1 program with seven 7HA.02 units [24]) and BKR wins (a) the LNG compressor on the supply side and (b) the smaller distributed/BTM gas yard. This is more co-existence than head-to-head except in the small-frame.

- **Siemens Energy** — direct competitor on (i) heavy-frame for utility-grade (SGT5/6-9000HL), (ii) compression for LNG (Dresser-Rand). Plans to scale heavy-frame production from ~48 to 70–80 units/yr by 2026 with a $1B US capex [22]. The credible BKR-displacing scenario is Siemens taking LNG-compression share on a tight project schedule where BKR's slot allocation slips.

- **Mitsubishi Power** — heavy-frame and J-class. Already competes on integrated combined-cycle. Less of a direct overlap with NovaLT.

- **Caterpillar / Solar Turbines** — the most direct *small/mid-frame* competitor and the one that should keep BKR honest. Solar Titan 250/350 (22–40 MW) overlaps NovaLT and LM2500 territory; Cat reciprocating engines (3600 class) overlap NovaLT in the 5–20 MW BTM use case. Cat's $63B backlog and 2–3× capacity-expansion plan into 2027–2029 is a direct demand sponge [18].

- **Wärtsilä** — taking 34SG reciprocating into hyperscale (412 MW Ohio, Apr 2026 [17]). Key technical dispute is **part-load/ramp and water consumption**: RICE engines arguably better for variable/peaking; aero/NovaLT better for high-availability baseload at higher exhaust temperature (waste-heat to a steam topping cycle).

- **Honest parity calls.** On *speed-to-power for a 50–250 MW BTM gas yard in 2026–2027*, BKR is competitive but not unique — Cat/Solar and Wärtsilä can fill many of the same orders, and customers are dual- or tri-sourcing. On the *LNG mega-train compression train at 4–8 MTPA* the credible alternative supplier set narrows to Siemens Energy and MHI; BKR is not unique but the qualification moat is real.

## Bull case — technical

For BKR to outperform, the following technical conditions need to broadly hold:

1. **Hyperscaler "speed-to-power" trumps the carbon math through 2028.** Gas-fired BTM remains the marginal megawatt for new training campuses (Stargate-Abilene, Meta Hyperion 5 GW, the wave of 100 MW–1 GW Permian / Wyoming / Louisiana sites [24][26]) because SMRs are not commercial at scale before ~2030 [23] and grid interconnect remains 5–7 yrs.
2. **The 5–60 MW BTM band stays structurally tight.** NovaLT and packaged aero engines absorb the demand that cannot wait for HA-class slots, with the aero segment in particular benefiting because GE Vernova's heavy-frame is sold-out into 2030 [20]. Result: BKR's announced data-center order pipeline ($0 → $1B in 2025; target $3B cumulative 2025–27 [4]) is conservative; orders trend toward $2B/yr run-rate by 2027.
3. **The LNG super-cycle holds.** Trains 4–8 at Rio Grande, QatarEnergy NFW, ST LNG, plus a wave of US permitting unlocks, drive IET compression bookings such that BKR's $40B+ Horizon-2 IET-order target by 2028 is credible rather than aspirational [1][4]. (Management raised this on the Q1 2026 call.)
4. **The Aero Alliance / GE relationship remains co-operative**, so BKR continues to capture aero packaging margin without GE Aerospace going direct.
5. **OFSE softness doesn't get worse than "flat-to-slightly-down."** Permian decline rates and OPEC+ discipline keep US service intensity from collapsing. This is the *unsexy* condition that has to hold for the whole sum-of-parts to re-rate.

If these hold, IET margins expand to the stated 20% target [25], the mix shift continues to derate the OFS exposure in investor mental-models, and BKR rerates from "service co. with an industrial turbine kicker" to "industrial-tech name with an oil-services tail" — a multiple closer to ETN/EMR/PWR than to HAL/SLB.

**Base rate caveat.** Heavy industrial rotating-equipment incumbents historically rerate slowly and revert to ~12–13× EV/EBITDA after capex super-cycles end. BKR is at 14.66× TTM today, ~19% above its own 10-yr median [16]; the bull case is that this cycle is longer (gas+AI dual demand) than the 2010–14 LNG-only cycle, not that the multiple sustains 20×+.

## Bear case — technical

A short-seller who actually understands the stack would write this version:

1. **The data-center turbine business is a real but small slice.** Even at the bull-case $3B cumulative data-center bookings 2025–27, that is single-digit % of a $33.1B IET backlog [1] — and BTM gas turbines are commoditising fast (Cat, Solar, Wärtsilä, MAN, Kawasaki, Mitsubishi all chasing the same hyperscaler RFPs). The market is paying a "data-center beneficiary" multiple on a number that does not yet move group EBITDA dramatically.
2. **The LM-series isn't BKR's IP.** GE Aerospace owns the engine cores; if cycle conditions shift, GE Vernova/GE Aerospace could compress BKR's packaging margin or go more direct in non-O&G applications. The *Aero Alliance* JV is durable but the underlying commercial agreement is not infinite.
3. **The NovaLT band gets squeezed**. RICE engines (Wärtsilä 34SG, Cat 3600) have **better part-load efficiency, faster ramp, and lower water consumption** than small aeroderivatives — properties data-center campuses actually care about for variable HPC load. Order data through 2026 (Wärtsilä's 412 MW Ohio order [17]) suggests this is happening at the margin.
4. **SMR timing risk to the *option value*.** If Kairos/Oklo/X-energy slip from "2030+" to "demonstrated economics by 2028," the *forward valuation* of BKR's BTM gas franchise compresses immediately even if 2026–28 deliveries are fine. The bear case is not that gas turbines stop selling; it's that the *terminal* of the BTM-gas thesis shortens [23].
5. **OFSE is a real anchor.** Half the revenue ($14.3B, ~52% of 2025 [25]) is still oilfield services tied to Permian rig count, Saudi Aramco capex cadence, offshore subsea spend. In a $60 oil scenario, this segment compresses 200–400 bps of margin and the IET tailwind has to do all the work.
6. **Carbon-intensity pushback.** If a Democratic administration or California-style state regulation in 2027 forces *operating* (not just permitting) restrictions on uncontrolled gas BTM, the backlog shape changes — toward more carbon-capture-equipped projects (which BKR arguably also benefits from via its CCS partnership with Frontier [3], but with longer cycles and lower margin).
7. **The valuation has run.** EV/EBITDA 14.66× is 19% above 10-yr median; the stock is up ~50% on a 12-month basis [11][16]. The "AI power" trade is consensus, not contrarian, after the Google Cloud collaboration headlines [4] and Q1 IET print.

## Market view check

At $63.99 / ~14.7× TTM EV/EBITDA / ~20.8× forward P/E / ~2.2× EV/Sales [2][14][16], with consensus PT ~$67–69, the sell-side is pricing BKR roughly *at* its current technical reality: a real beneficiary of the 2026–28 BTM gas turbine + LNG-compression cycle, with margin expansion coming through, and a partially de-emphasized OFSE business. The market is **not** mispricing the data-center order book itself (the headlines are well-telegraphed). What the market may *under*-price is the **durability of the LNG-compressor franchise as a 5–10-yr revenue-and-service annuity** — that is a Florence/Nuovo-Pignone aerothermal-design moat that few sell-side energy analysts model with the rigor they apply to NVDA software lock-in. What the market may *over*-price is the small/mid-frame turbine moat — there are too many competent global suppliers to support a structural pricing-power story there. Net: fairly priced on group, with mix risk skewed toward the "compressor durability is under-modeled" thesis.

## 90-day falsifiers

Things you could actually check between today and ~early August 2026:

1. **Q2 2026 print (late July).** Specifically: (a) IET orders ≥ $4.5B (continuation of >$4B/qtr book level); (b) data-center-specific bookings disclosed at ≥$500M for the quarter; (c) IET EBITDA margin tracking toward the 20% target. Material miss on (a) or (c) breaks the rerating thesis.
2. **GE Vernova / Siemens Energy Q2 prints + commentary on heavy-frame slot reservations into 2030.** If heavy-frame lead times *shorten* (capacity adds bite), BKR's small/mid-frame premium compresses. The reverse (further extension into 2031) widens it.
3. **A second hyperscaler-disclosed BTM gas RFP outcome.** Watch Stargate phase-2 (Abilene), Meta Hyperion balance-of-plant, and any Microsoft Wisconsin / Mt. Pleasant disclosure for whether BKR vs. Cat/Solar vs. Wärtsilä wins. Two consecutive losses to Cat or Wärtsilä would weaken the bull mix-shift case.
4. **NextDecade Rio Grande FID on Trains 4–5 / FERC permitting.** Direct read-through to BKR compression-train bookings.
5. **Kairos/Oklo regulatory milestones (NRC).** Any acceleration of first-deployment timing meaningfully degrades the BTM-gas terminal.
6. **Hyperscaler 2026 capex guides on Q2 calls (MSFT/META/GOOG/AMZN, late Jul – early Aug).** A ≥10% sequential cut to FY26 capex is a system-level falsifier; a re-acceleration is a confirmation.
7. **Aero Alliance / GE Aerospace any disclosure** of changes to the LM-series supply or service economics — would directly hit BKR aeroderivative margin.

## What I could not verify

- Exact share of the $1B 2025 "data center" order figure attributable to NovaLT vs. packaged aero vs. balance-of-plant; management aggregates the line.
- Margin profile of data-center turbine sales relative to LNG compression and OFS; the 10-K segment disclosure does not split this granularly.
- Actual installed efficiency of NovaLT16 in a *typical* 2026 data-center configuration vs. Wärtsilä 34SG and Cat 3600 under variable HPC load profiles. I cite ISO/datasheet figures, which overstate field efficiency.
- Specific contractual terms of the GE Aerospace ↔ Baker Hughes LM-series supply agreement — what fraction of margin GE captures vs. BKR, and renewal mechanics.
- Whether the Google Cloud "AI-enabled power optimization" collaboration [4] is a meaningful software/services franchise or a marketing wrapper. No technical paper, no shipped product disclosure as of search date.
- BKR's specific allocation of CoWoS, HBM3e — not applicable; flagging only because a sell-side note might confuse "AI infrastructure exposure" with "AI silicon exposure." It has none of the latter.
- Hydrogen-blend fleet operating data on NovaLT at >50% H₂; vendor claims exist, third-party validation is thin.

## Sources

[1] https://investors.bakerhughes.com/news/press-releases/news-details/2026/Baker-Hughes-Announces-First-Quarter-2026-Results/default.aspx — retrieved 2026-05-10 — Q1 2026 results: $6.6B revenue, $4.9B record IET orders, $33.1B record IET backlog, raised Horizon-2 IET orders >$40B by 2028.
[2] https://finance.yahoo.com/quote/BKR/ — retrieved 2026-05-10 — current BKR price ($63.99) and market cap (~$63.4B).
[3] https://investors.bakerhughes.com/news-releases/news-release-details/baker-hughes-supply-novalttm-gas-turbines-frontier — retrieved 2026-05-10 — Frontier Infrastructure 16-NovaLT/270 MW BTM data-center order; multi-fuel/H₂ capability; CCS partnership.
[4] https://www.globenewswire.com/news-release/2026/03/24/3261053/0/en/Baker-Hughes-Develops-AI-Enabled-Power-Optimization-and-Sustainability-Solutions-for-Data-Centers-with-Google-Cloud-Technology.html — retrieved 2026-05-10 — Google Cloud collaboration; $0→$1B 2025 data-center orders, $3B 2025–27 target; Rio Grande LNG Trains 4–8, QatarEnergy NFW, ST LNG references.
[5] https://www.turbomachinerymag.com/view/gas-turbine-market-report-2024-posts-highest-units-mws-in-22-years — retrieved 2026-05-10 — combined GE/BKR aeroderivative ~63.7% 5-yr share; ~85% recent share.
[6] https://www.bakerhughes.com/gas-turbines/novalt-technology — retrieved 2026-05-10 — NovaLT specs: 5.5–17.5 MW, ~37% simple-cycle, hydrogen capability, 35,000-hr MTBM.
[7] https://www.gevernova.com/gas-power/services/service-centers/aero-alliance — retrieved 2026-05-10 — Aero Alliance JV (GE Vernova + Baker Hughes) for LM2500/LM6000/LMS100 service.
[8] https://www.turbomachinerymag.com/view/baker-hughes-divests-waygate-technologies-doubles-down-on-rotating-equipment-and-lng — retrieved 2026-05-10 — strategic focus: rotating equipment + LNG.
[9] https://www.marketbeat.com/stocks/NASDAQ/BKR/forecast/ — retrieved 2026-05-10 — analyst PT $67.25 avg ($41–$80); fwd EPS $2.67.
[10] https://www.bakerhughes.com/baker-hughes-italia — retrieved 2026-05-10 — Florence Nuovo Pignone facility: 350,000 m², ~4,000 employees, 1,200 R&D engineers.
[11] https://www.tikr.com/blog/bkr-stock-has-surged-42-in-2026-heres-why-the-ai-data-center-bet-could-pay-off — retrieved 2026-05-10 — 52-week range $35.83–$70.41; YTD performance.
[12] https://www.bakerhughes.com/gas-turbines/aeroderivative-technology/lm9000-aeroderivative-gas-turbine — retrieved 2026-05-10 — LM9000 73.1 MW, "world's most efficient simple cycle" claim.
[13] https://gasturbineworld.com/baker-hughes-hydrogen-turbines/ — retrieved 2026-05-10 — NovaLT16 100% hydrogen capability and switching with no hardware changes.
[14] https://stockanalysis.com/stocks/bkr/forecast/ — retrieved 2026-05-10 — forward P/E ~20.8×, EV/Sales ~2.23 on 2026 estimates.
[15] https://www.benzinga.com/insights/short-sellers/26/03/51128509/looking-into-baker-hughes-cos-recent-short-interest — retrieved 2026-05-10 — short interest 25.12M shares / 3.3% of float as of 2026-03-09; below 8.77% peer avg.
[16] https://www.gurufocus.com/term/enterprise-value-to-ebitda/BKR — retrieved 2026-05-10 — EV $62.84B, EBITDA TTM $4.29B, EV/EBITDA 14.66× (10-yr median 12.30×).
[17] https://www.wartsila.com/media/news/16-04-2026-wartsila-s-34sg-engine-makes-its-data-center-debut-with-new-412-mw-u-s-project-3740972 — retrieved 2026-05-10 — Wärtsilä 34SG 412 MW Ohio hyperscale order — competitive read-across.
[18] https://www.manufacturingdive.com/news/caterpillar-triple-power-generation-capacity-raises-2030-targets-q1-2026-earnings/819078/ — retrieved 2026-05-10 — Caterpillar $63B Q1 2026 backlog, 3600 family ~107-week wait, 3× capacity expansion plan.
[19] https://newsletter.semianalysis.com/p/ai-capacity-constraints-cowos-and — retrieved 2026-05-10 — CoWoS/HBM is the binding silicon-side bottleneck (BKR not exposed; included to bound scope).
[20] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — GE Vernova ~80 GW backlog into 2029; sold-out through 2030 by end-2026.
[21] https://avanzaenergy.substack.com/p/data-centers-are-killing-the-grid — retrieved 2026-05-10 — 5–7 yr interconnection queue; BTM economics for data centers.
[22] https://www.industrialinfo.com/iirenergy/industry-news/article/siemens-ge-vernova-increase-us-investment-to-meet-gas-turbine-power-demand--352984 — retrieved 2026-05-10 — Siemens Energy heavy-frame ramp 48→70–80 units/yr; $1B US capex.
[23] https://www.eia.gov/todayinenergy/detail.php?id=67584 — retrieved 2026-05-10 — SMR US deployment timelines: first commercial units realistically early-to-mid 2030s.
[24] https://www.datacenterfrontier.com/energy/article/55264592/chevron-ge-vernova-engine-no1-join-race-to-co-locate-natural-gas-plants-for-us-data-centers — retrieved 2026-05-10 — Chevron / Engine No. 1 / GE Vernova multi-GW BTM-gas program with 7HA.02 turbines (heavy-frame competitor mix).
[25] https://markets.financialcontent.com/wral/article/finterra-2026-1-16-baker-hughes-the-great-pivot-from-oilfields-to-energy-technology — retrieved 2026-05-10 — 2025 segment split OFSE $14.32B / IET $13.41B; IET margin 20% target; 2026 outlook commentary.
[26] https://ibinterviewquestions.com/guides/energy-investment-banking/data-center-power-boom-ai-demand-hyperscaler — retrieved 2026-05-10 — hyperscaler power demand outlook (50+ GW incremental, 20 GW/yr 2027–29).