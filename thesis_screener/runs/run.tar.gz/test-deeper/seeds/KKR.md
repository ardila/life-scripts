I have enough technical detail to write the dossier. Drafting now.

# KKR — KKR & Co. Inc.

## Where this sits in the AI stack
KKR does not design silicon, write CUDA, or sell GPUs. It owns and finances the **physical substrate beneath the rack** — land, transmission rights, gas turbines, data center shells, fiber, and (selectively) liquid-cooling kit — and rents that bundle to hyperscalers on long-duration contracts. It sits one layer below the cloud (compute-as-a-service) and two below the model (inference/training): a power-and-real-estate balance-sheet provider to the AI buildout, with insurance float (Global Atlantic) as the funding source and a private-equity overlay (Strategic Holdings) on top. The workload it supports is hyperscale training **and** AI inference at the campus level, not edge or on-device. [1][2][6]

## Snapshot
- **Price:** $101.08 (2026-05-10 close) [3]
- **Market cap:** ~$91.4B [3]
- **52-week range:** $82.67 – $153.87 (currently ~34% off the high) [9]
- **Forward P/E:** ~17–19× consensus 2026 EPS of ~$5.39; ~14–15× on the previously budgeted but now flagged-uncertain $7 ANI/share target [4][13]
- **EV / NTM revenue:** n/a — for an alt-asset manager the relevant multiples are price/FRE and price/distributable earnings; revenue is not the operating economic [14]
- **Consensus 12-month price target:** ~$143–$148 (implied ~+42–46% from spot, "Buy" consensus across ~21 analysts) [4]
- **YTD total return:** approximately -8% to -18% (sources disagree; the larger figure includes peak-to-date drawdown) [9]
- **Short interest (% of float):** n/a — current SI not confirmed in available primary sources; float is ~684M shares [9]

## Moat — what it is physically made of
KKR's moat is **not** technical IP. It is a stack of scarce, slow-to-replicate physical and balance-sheet assets. Honest decomposition:

1. **Power-generation pipeline and turbine slots.** Through the $50B Energy Capital Partners (ECP) JV announced Oct 2024, the partnership claims ~100 GW of operating and development-ready power gen and ~8 GW of data-center pipeline already in-flight. [6][2] Slot allocations on GE Vernova / Siemens Energy / Mitsubishi heavy-duty gas turbines — where backlogs now stretch through 2028–2030 — are the **gating constraint** for behind-the-meter AI campuses, and these are awarded on relationship and balance-sheet depth, not on price. [11][12] This is the hardest part to replicate: there are only three credible large-frame turbine OEMs globally. [12]
2. **Five-to-six operating data-center platforms.** CyrusOne is the flagship (55+ facilities, multi-GW Texas pipeline at Thad Hill and Freestone, an active 200MW DFW7 build, a US Army AI campus mandate). [1][7] Add Global Technical Realty (Europe, ~$2B with Oak Hill), and APAC platforms — ~155 facilities and a ~15 GW development pipeline cited by KKR. [5]
3. **Insurance float (Global Atlantic).** Long-duration, spread-funded liabilities match the 15–25 year cash flows of power and data-center assets. This is structurally cheaper than non-insurance-backed PE money and is hard for a fund-only competitor to recreate without buying a life co. [10]
4. **Hyperscaler relationship capital.** Hiring Adam Selipsky (ran AWS through the GenAI ramp, doubled revenue past $100B) to head **Helix Digital Infrastructure**, the new $10B+ "full-stack landlord" vehicle launched Apr 30, 2026, is explicitly a relationship-underwrite: Helix sells land + power + transmission + cooling + fiber as one SKU so a hyperscaler can outsource the buildout and preserve balance sheet for chips. [1][8] This relationship is real but **easily duplicated** — Blackstone, Brookfield, Apollo and GIP/BlackRock all play the same game.
5. **What it is *not*:** there is no CUDA-equivalent lock-in. No kernel-library moat, no patent thicket on advanced packaging, no proprietary cooling design at scale (KKR *exited* CoolIT at ~15× cost in Q1 2026, monetizing the cooling thesis rather than holding it). [3]

Durability ranking, most-to-least: power/turbine pipeline > insurance float > platforms > brand > hyperscaler relationships.

## AI buildout bottleneck map
The 24-month gating list and KKR's position on each:

| Bottleneck | State | KKR position |
|---|---|---|
| **Grid interconnect** | ~2,600 GW US queue, ~5y median wait, up to 12y in PJM/Northern VA [11] | **Beneficiary / constraint owner.** Behind-the-meter generation pipeline lets KKR/ECP bypass the queue. |
| **Heavy-duty gas turbines** | GE Vernova ~55–60 GW backlog through ~2028; Mitsubishi doubling capacity over 2 yrs; only 3 OEMs [12] | **Constraint owner via allocations** — owns slot economics. |
| **Power purchase / generation (gas, nuclear, renewable)** | Hyperscalers competing for PPAs; CyrusOne signed 1,100+ MW with Constellation/Calpine [7] | **Supplier** through ECP JV. |
| **CoWoS-L / HBM3e supply** | Tight through 2026 | **Indifferent** — KKR doesn't own this layer. |
| **Optical interconnect / co-packaged optics** | Constrained but improving | **Indifferent.** |
| **Liquid cooling at >100kW/rack** | Direct-to-chip mandatory at GB200/MI300 densities | **Recently exited** (CoolIT). No durable exposure here. [3] |
| **Electrical contractor / EPC capacity** | Severely tight in Texas, Arizona, Virginia | **Exposed customer** — projects can slip on EPC. |
| **Kernel / compiler / model talent** | Not a KKR layer | Indifferent. |
| **Land + zoning** | Tightening (utility moratoria in N. Virginia, etc.) | **Beneficiary** — large existing land bank. |

Net: KKR is positioned around the **two hardest** 2026–2028 bottlenecks (grid + turbines) and explicitly **not** around the chip-side bottlenecks where the cycle could surprise to the downside.

## Competitive teardown
Not "Blackstone competes with KKR." Specifically:

- **Blackstone** runs QTS (acquired 2021 at $6.7B; grown from ~400MW to ~3GW operating, with a development pipeline reported north of $25B and a portfolio valued >$70B) plus AirTrunk in APAC. [5] Blackstone's edge is **earlier scale at the data-center-asset layer** and a deeper credit platform; KKR's edge is **deeper integration into power generation** via ECP. On a pure data-center-only basis, Blackstone is ahead in operating capacity today. On the power-bundled model, KKR is more concentrated.
- **Brookfield (BIP / BAM)** owns Compass and Data4 (~$9B combined), plus the largest pure-renewables operating fleet of any alt manager and a compute layer via Radiant. [5] Brookfield's renewable-first positioning has fewer permitting/emissions headwinds than KKR's gas-heavy ECP partnership; the gap closes if/when natural-gas backlash from data-center siting accelerates (PJM tensions are an early signal). [11]
- **Apollo, GIP (now BlackRock)** — Apollo competes on insurance-balance-sheet financing (Athene mirrors Global Atlantic). GIP was already a co-investor in CyrusOne; under BlackRock its scale-up is a direct competitive shift. KKR's relative advantage is the integrated operator-developer stack rather than financier-only.
- **What's at parity already:** ability to write equity checks ≥$5B per asset; access to hyperscaler procurement teams; access to turbine OEM allocations (all three have these). What's **not** at parity: Adam Selipsky's specific Rolodex (genuine — for now); CyrusOne's Texas land position (genuine — but Texas zoning is loosening, not tightening).

For a competitor to take share over 24 months, the credible path is **price**: an oversupplied campus market means KKR's marginal new deal underwrites at lower IRRs, not that it loses existing contracted cash flows.

## Bull case — technical
The technical claims that need to hold:

1. **Inference compute scales for the next 24 months, even if frontier-training capex plateaus.** Brookfield's own framing — inference =75% of AI compute by 2030 — is the right shape; inference is power-hungry, geographically distributed, and contracted at long duration. [5] This is the workload KKR's bundle most directly supports.
2. **Power, not silicon, remains the binding constraint.** As long as the 2,600 GW interconnect queue and 5+ year wait holds, behind-the-meter campus offerings command pricing power. [11]
3. **Hyperscalers continue to prefer outsourcing the *physical* buildout** so balance sheet stays on chips/software. Helix's thesis. [1][8]
4. **Turbine OEM concentration persists.** Three suppliers, multi-year backlogs, no credible new entrant. [12]
5. **Liquid-cooling, HBM, and CoWoS issues remain "someone else's bottleneck."**

**Base rate on technology displacement at this stage:** infrastructure asset moats (toll-road-style, long-contract, physical-permit-gated) historically erode over 10–20 year horizons, not 2–3 years. The credible 24-month risk is **oversupply at the margin** depressing new-deal IRRs, **not** demand collapse or asset stranding. Compare to the 2000s telecom buildout: fiber assets were overbuilt for a decade but eventually got monetized; the equity-financiers who had insurance float (=patient capital) survived; the leveraged fund-only sponsors did not.

Financial sanity check on the bull: if FRE compounds 20%+ off the current $1.02B/quarter run-rate and Strategic Holdings prints as guided, then sub-15× forward FRE is unreasonable for a duopolistic alt manager — implying re-rating toward the consensus $143–148. [4][10]

## Bear case — technical
Written as a short-seller who reads the stack:

1. **Howard Marks is right that hyperscaler leases have walk-away/flex clauses.** With ~31.6 GW in planning and 6.3 GW under construction across NA, modest cancellation could move vacancy from 2.3% through 5% (oversupply trigger) in 12–18 months. [15] When the few buyers are also the tenants, leverage in renegotiation sits with the tenant.
2. **Inference compute may compress per-token economics faster than expected.** If MoE + speculative decoding + smaller frontier models reduce the *physical* footprint needed per query, contracted capacity gets pre-paid but new bookings slow. Asset values are marginal-deal-driven.
3. **Behind-the-meter gas faces a political ceiling.** PJM tensions and state-level resistance are real and rising. [11] A gas-heavy 100 GW pipeline is more exposed than Brookfield's renewable-first stack.
4. **Helix is unproven.** A $10B vehicle with a celebrity CEO and no announced anchor tenant is a thesis, not a moat. The 90-day proof point is whether Helix announces a real hyperscaler take-or-pay.
5. **KKR's own ANI guidance was just trimmed.** CFO Lewin explicitly said landing below the $7/share 2026 budget is "more likely." [13] This is monetization-environment driven (gross carry slower than budgeted), and that's a multi-quarter problem, not a one-print problem.
6. **Multiple compression risk.** Trailing P/E in the mid-30s with monetization headwinds is fragile. The stock is already -33% off highs and finding a 14–17× forward floor; another leg down to 12× is not technically unsupportable.

Base rate: PE/alt-asset multiples are tightly correlated with the credit cycle and IPO/M&A windows. The bear case is not that KKR's data centers go vacant — it's that **gross carry compresses for 4–6 quarters** while the AI infra mark-up cycle is still running, decoupling the stock from the narrative.

## Market view check
At $101 with a $143–148 consensus PT and a 14–18× forward multiple, the market is pricing **partial monetization-cycle pain combined with intact long-duration AI infra thesis.** [3][4][13] The 33% drawdown from the 52-week high reflects (a) the ANI walkdown, (b) broader alt-manager de-rating, and (c) AI overbuild noise. What the market apparently believes that I'd push back on: the buyside seems to treat KKR as primarily a *carry / monetization* story (which is in the soft spot of the cycle) and underweight the *Helix + ECP + CyrusOne* power-bundling story (which is structural and 5–10-year). If you believe (i) inference compute continues to scale and (ii) the grid stays gated, the stock at sub-15× a stretch $7 ANI looks structurally mispriced lower; if you believe AI capex peaks in 2026, the multiple is fair-to-rich.

## 90-day falsifiers
Specific things observable by ~Aug 10, 2026:

1. **Hyperscaler Q2 2026 capex guides** (Microsoft, Meta, Google, Amazon, reporting late-Jul/early-Aug). A ≥10% sequential cut in aggregate run-rate is a clear bear-thesis confirmation; ≥10% raise is the inverse.
2. **Helix announces (or fails to announce) an anchor tenant** — a named hyperscaler take-or-pay on a specific MW campus. Absence of a signed anchor by 90 days is meaningful negative.
3. **KKR Q2 2026 print (early Aug):** does FRE growth remain >20% YoY *and* is ANI guidance reaffirmed or further cut from the trimmed level? A second walkdown of the $7 target is materially negative.
4. **PJM interconnection reform vote / FERC interconnect policy update.** Any rule change that materially shortens queue times weakens the behind-the-meter moat (good for hyperscalers, bad for KKR's pricing power).
5. **GE Vernova / Siemens Energy / Mitsubishi turbine backlog disclosure** in their Q2 prints. Material new-capacity announcements or backlog softening would compress the scarcity rent on slot allocations.
6. **CoreWeave / Nebius / Crusoe pricing.** GPU-as-a-service spot pricing rolling over by >15% is an early signal of inference-side compute compression.
7. **A second large data-center lease cancellation or renegotiation** (post the Microsoft pullback reports of 2025). Two more would materially shift the oversupply narrative.

## What I could not verify
- Helix's specific equity stake economics for KKR (LP vs. GP vs. management-co) and whether sovereign-wealth co-investors got preferred terms. [1][8]
- The portion of CyrusOne's 15 GW pipeline that is **contracted (preleased)** vs. **speculative**. Crucial for oversupply sensitivity. [5][7]
- Lease structure detail on existing hyperscaler contracts — duration, renewal rights, walk-away/flex clauses. Howard Marks alleges these are tenant-friendly; I could not confirm contract-level. [15]
- Current short interest as a % of float (sources lagged or behind paywall). [9]
- KKR's exact slot allocation share with GE Vernova/Mitsubishi vs. Blackstone, Brookfield, Apollo. Strongly suspected to be top-3 but not disclosed.
- Whether ECP JV's 100 GW "operating and development-ready" figure is heavily weighted to early-stage permits vs. shovel-ready interconnects. The distinction is enormous for IRR.
- Specifics of the US Army AI data-center contract economics. [1]
- Forward EV/Revenue for KKR is not a market-standard metric for alt managers; consensus revenue lines diverge widely depending on whether Global Atlantic spread income is counted gross or net.

## Sources
[1] https://www.datacenterdynamics.com/en/news/helix-digital-infrastructure-kkr-plans-10bn-ai-data-center-firm-headed-by-former-aws-ceo-report/ — retrieved 2026-05-10 — Helix Digital Infrastructure $10B+ launch, Selipsky as CEO, full-stack landlord model.
[2] https://www.publicpower.org/periodical/article/kkr-ecp-50-billion-partnership-support-ai-growth-through-investments-data-centers-generation — retrieved 2026-05-10 — $50B KKR/ECP partnership, 100 GW power pipeline, 8 GW data center pipeline.
[3] https://finance.yahoo.com/markets/stocks/articles/kkr-co-inc-q1-2026-205417840.html — retrieved 2026-05-10 — Q1 2026 metrics, AUM $758B, FRE $1.02B, CoolIT 15× exit, six data center platforms, $40B+ digital infra deployed.
[4] https://public.com/stocks/kkr/forecast-price-target — retrieved 2026-05-10 — Consensus price target ~$143, Buy rating, 16–21 analyst coverage, EPS forecast ~$5.39.
[5] https://www.globaldatacenterhub.com/p/what-kkr-and-blackstone-just-signaled — retrieved 2026-05-10 — Comparative positioning of KKR (155 facilities, 15 GW pipeline) vs Blackstone (QTS, AirTrunk) vs Brookfield (Compass, Data4, Radiant).
[6] https://media.kkr.com/news-details?news_id=8f924dd6-41ea-480d-9a96-d854c7232bbc — retrieved 2026-05-10 — KKR/ECP partnership official release; $29B prior digital infra investments, $15B power/utilities.
[7] https://www.cyrusone.com/resources/press-releases/calpine-and-cyrusone-announce-phase-2-of-powered-land-agreement-to-support-hyperscale-data-center-at-thad-hill-energy-center-in-texas — retrieved 2026-05-10 — CyrusOne Texas pipeline detail: Thad Hill 400MW, Freestone, DFW7 200MW; Constellation 1,100+ MW commitments.
[8] https://www.bloomberg.com/news/articles/2026-04-30/kkr-preparing-new-10-billion-ai-firm-led-by-ex-amazon-web-chief — retrieved 2026-05-10 — Helix funding from sovereign wealth fund + two strategic partners, additional raises planned.
[9] https://www.tikr.com/blog/kkr-stock-is-down-33-from-its-52-week-high-heres-what-q1-earnings-mean-going-forward — retrieved 2026-05-10 — Price $101.08, 52w range $82.67–$153.87, drawdown context.
[10] https://www.stocktitan.net/sec-filings/KKR/8-k-kkr-co-inc-reports-material-event-77e0b43d20f9.html — retrieved 2026-05-10 — Q1 AUM $758B, FRE $1.02B (+23.5% YoY), Global Atlantic insurance role.
[11] https://www.enr.com/articles/62227-grid-access-not-land-emerges-as-bottleneck-for-data-center-construction — retrieved 2026-05-10 — Grid interconnection queue 2,600 GW, 5y median wait, PJM/Northern Virginia bottleneck.
[12] https://power.mhi.com/regions/amer/insights/us-power-outlook-and-long-term-trends — retrieved 2026-05-10 — GE Vernova 55–60 GW turbine backlog through 2028, Mitsubishi doubling capacity, three-OEM concentration.
[13] https://finance.yahoo.com/markets/stocks/articles/kkr-shares-slip-weak-ani-124600770.html — retrieved 2026-05-10 — CFO Lewin's ANI walkdown commentary, $7/share 2026 target now likely undershot.
[14] https://www.theglobeandmail.com/investing/markets/markets-news/Tipranks/1758732/kkr-earnings-call-record-fees-cautious-2026-outlook/ — retrieved 2026-05-10 — Record-fee print, cautious monetization outlook, strategic holdings context.
[15] https://pestakeholder.org/news/critical-questions-about-private-equitys-big-bet-on-data-centers/ — retrieved 2026-05-10 — Overbuild risk framing, Howard Marks warning on tenant flex clauses, 6.3 GW under construction + 31.6 GW planning, 2.3% vacancy.