# ROP — Roper Technologies, Inc.

## Where this sits in the AI stack
ROP sits **above** the AI infrastructure stack, not inside it. It is a holding company of ~30 vertical-market software businesses (Aderant for legal billing, Vertafore for insurance distribution, Deltek for govcon ERP, Strata for hospital financial planning, PowerPlan for utility tax/asset accounting, DAT for trucking load-matching, ConstructConnect for construction takeoff, CentralReach for ABA therapy EMR) plus a smaller Technology-Enabled Products segment (Neptune water meters, Verathon medical, NDI optical tracking) [1][3]. None of it ships silicon, kernels, fabric, or training-platform software. Workload mix is overwhelmingly **transactional, regulated, multi-tenant SaaS at the application layer** — exactly the layer most directly contested by Anthropic Claude Cowork / Salesforce Agentforce / OpenAI enterprise plug-ins. ROP is therefore an **AI-demand-side bet on incumbent workflow systems remaining the system of record** as agents do more of the work above them.

## Snapshot
- **Price:** $343.32 (2026-05-08 close) [9]
- **Market cap:** $34.65B [9]
- **52-week range:** $313.07 – $584.03 [9]
- **Forward P/E:** 15.22× (on FY26 DEPS guide $21.80–$22.05) [9][2]
- **EV / NTM revenue:** ~5.1× (EV $44.73B; NTM revenue ~$8.7B implied by ~8% guide on $8.12B TTM) [9][2]
- **Consensus 12-month price target:** $495.43 (implied +44%; 14 analysts, "Buy") [11]
- **YTD total return:** approximately −20.6% [12]
- **Short interest (% of float):** 3.78% as of 2026-04-15, up from 1.3% in late October 2025 — the only datapoint in this snapshot showing a regime change rather than continuation [10]

## Moat — what it is physically made of
The real moat is **the chart of accounts and the regulator**, not the code. Decomposing:

**Aderant (legal — ~mid-single-digit % of revenue, inferred):** the moat is the trust accounting ledger and the WIP-to-billing-to-collections graph that integrates with state bar IOLTA rules, OCG (outside counsel guideline) compliance, and per-firm rate cards. Migration cost cited at 6+ months of partner-rate downtime [8]; the binding constraint is not software replacement but **data and configuration custody** with audit history. Aderant's defensive move is the Stridyn cloud platform with embedded MADDI AI layer, plus the Harvey partnership announced 2025 — Harvey writes the work, Aderant captures the time and bills it [4][6]. This co-opts rather than competes with the AI-native threat. Durability: high in the 5-year window; medium beyond, because Harvey/Thomson Reuters CoCounsel/Lexis+ AI could in principle bundle billing/trust as a feature once they own the workflow.

**Vertafore (insurance — largest single business, inferred ~10–12% of revenue):** the moat is the **AMS360/Sagitta/QQCatalyst integrations into 1,000+ carrier rating engines** and the standardized data interchange (ACORD forms) that brokers, MGAs, and carriers all use. A new entrant must either rebuild thousands of carrier connectors or get carriers to adopt their schema — neither is feasible without 5–10 years and carrier sponsorship. Velocity AI agents (submission processing, reference-connect, reconciliation) sit on top of this connector graph; the connectors are the moat, the agents are the upsell [5].

**Deltek (govcon ERP):** the moat is **DCAA audit compliance**. Costpoint's general ledger structure is configured to survive a Defense Contract Audit Agency review; ripping it out invites disallowed costs on cost-plus contracts. Dela AI agents add proposal generation and resource planning on top [7]. This is the most defensible asset in the portfolio — the regulator effectively certifies the incumbent.

**DAT Freight:** the moat is **two-sided liquidity** on the load board (carriers and brokers) plus the historical RateView pricing dataset, now with the Convoy automated-matching technology stack acquired from Flexport in 2024 [13]. This is the one asset that looks like a network rather than a configuration moat.

**CentralReach (ABA therapy):** mission-critical EMR for autism providers; CentralReach disclosed **75% of new business bookings are AI-related** with AI-generated session notes (5–10 min → ~30 sec) [14]. This is the cleanest AI-monetization datapoint in the entire portfolio and the only one that is publicly quantified.

**What is NOT a moat:** the holding company itself. There is no shared code, no shared data plane, no platform synergy — businesses are run independently and the corporate value-add is decentralized capital allocation. That is precisely the basis for the May 2026 shareholder spin-off proposal (urging tax-free separation of Application + Network Software), which the board has formally opposed [15][16].

Aggregate enterprise gross retention disclosed by management as "consistently in the mid-90% range" — gross, not net [14]. Net retention is undisclosed; third-party estimates of 105–115% [8] are consistent with mid-90s gross plus AI-driven upsell, but not independently verifiable.

## AI buildout bottleneck map
Every supply-side bottleneck on the next 24 months — power generation and grid interconnect, CoWoS-L allocation, HBM3e/HBM4 yield, 800G/1.6T optics supply, >100kW/rack liquid cooling, NCCL/NVSHMEM-class fabric talent, training-data quality — ROP is **indifferent**. It owns no fab, no packaging line, no datacenter, no model. It is a **demand-side beneficiary** only insofar as enterprise AI capex creates labor-budget reallocation that AI features inside its products can capture. Management's framing on Q1 2026 is explicit: "the whole point of the AI effort is monetize labor spend...different bucket of opportunity" — i.e., not seat cannibalization of the existing software budget but expansion into the services/labor wallet [14]. This is the right framing. It is also the framing every horizontal SaaS incumbent uses; whether vertical incumbents capture more of that wallet than horizontal AI agents do is the central unresolved question.

The one place ROP has any AI-supply-chain exposure is **inference cost as COGS**. If an Aderant customer's seat license now has to fund 50× more tokens for Stridyn agentic features, gross margin compresses unless prices rise faster than token cost falls. So far token cost has been falling ~3–4× per year, which favors ROP, but this is an open variable.

## Competitive teardown
Threats are segment-specific, not company-wide. The naive "agentic AI eats SaaS" thesis is too coarse.

| Segment | Specific threat | Technical axis | Current evidence |
|---|---|---|---|
| Aderant (legal) | Harvey + Thomson Reuters CoCounsel | Workflow capture upstream of billing — once Harvey owns drafting/research, can it bundle time capture? | Harvey at $11B valuation (Mar 2026), 28% of Am Law 100, 100K+ lawyers across 1,300 orgs [4]. Aderant chose to partner with Harvey rather than fight, suggesting management read the same threat. |
| Vertafore (insurance) | Applied Systems + Guidewire AI features; insurtech AI startups | Connector/data network is hard to disintermediate, but AI agent layer above could commoditize the AMS into a thin client | No specific evidence of share loss; segment growth still mid-single digits organically [2]. |
| Deltek (govcon) | Unison, Procas, Microsoft Dynamics + ISV layer with AI proposal tooling | DCAA compliance is the moat; AI proposal generation is contestable | G2 still ranks Deltek #1 ERP 2026 [7]. The DCAA regulatory wall is the single most defensible moat in the portfolio. |
| DAT (freight) | Uber Freight, native AI brokerage agents, Loadsmart | Two-sided liquidity moat is real; AI may compress broker margins (the customer), reducing TAM | DAT acquired Convoy and Trucker Tools in 2024-25, consolidating the digital matching stack [13]. |
| CentralReach | AlohaABA, Rethink, vertical AI EMR startups | ABA-specific clinical data labels are the moat | 200K+ professionals on platform, 75% AI attach on new bookings [3][14]. |
| Across portfolio | Anthropic Claude Cowork / Salesforce Agentforce / OpenAI enterprise plug-ins via MCP | Read/write agents that use the underlying SaaS as a system of record but compress the seat count needed | Cowork launched 2026-02-24, contributed to ~$285B SaaS sell-off [17]. The mechanism that hurts horizontal SaaS (seat-count compression) applies less to vertical SaaS where the data of record + regulatory configuration is the product, not the seats. |

The honest read: **horizontal SaaS is more exposed to the agentic-AI thesis than vertical SaaS**, because horizontal seats are interchangeable and agents can substitute. Vertical SaaS sells the regulator-blessed system of record; agents will use it, not replace it — until or unless an AI-native competitor reproduces the regulatory configuration end-to-end.

## Bull case — technical
**Base rate:** vertical-software incumbents that own the regulated system of record have very long half-lives. Bloomberg Terminal has survived 30+ years of "Bloomberg killers" because the data + workflow + compliance bundle is durable; SAP has survived every "kill SAP" startup since 1995 for the same reason. The relevant base rate is closer to 10–20 years of durability for an established vertical incumbent, not 2–3 years.

**Conditions for outperformance:**
1. AI agents settle into a **co-pilot-on-top-of-system-of-record** equilibrium, not a system-of-record replacement (most likely outcome on a 3–5 year horizon).
2. Roper successfully captures labor-wallet expansion via usage-based AI add-ons. CentralReach's 75% AI attach on new bookings is the leading indicator [14]; if Vertafore Velocity, Aderant Stridyn, and Deltek Dela hit similar attach rates by FY27, organic growth re-accelerates from 6% toward double digits.
3. Inference cost continues to fall faster than token consumption rises per workflow → AI gross margin stays neutral-to-accretive.
4. Forward P/E of 15.2× re-rates back to the 25–30× decade average as the "AI threat" narrative dissipates. A re-rating to 22× FY27 EPS (~$24) implies ~$528 — roughly the consensus PT.

The trade is buying a 32% FCF-margin compounder at a 15× forward multiple after a 40% drawdown, with optionality on a forced spin-off (board opposing it does not prevent it from eventually happening).

## Bear case — technical
**Base rate counter:** within software, the cases where displacement was fast (Lotus → Excel; on-prem ERP → cloud ERP for SMB) shared a common feature — the new entrant didn't just match features, it shipped on a fundamentally cheaper substrate (PC vs. workstation; multi-tenant cloud vs. licensed install). Agentic AI may be that substrate shift for **drafting-heavy** vertical workflows (legal, insurance underwriting, proposals).

**Conditions for underperformance:**
1. The Harvey/Aderant partnership inverts: Harvey accumulates enough partner-firm trust that it offers a thin billing/trust module and starts disintermediating Aderant on new logos — even 5–10% logo loss collapses NRR math, because vertical SaaS economics depend on >100% net retention.
2. Anthropic/OpenAI/Salesforce enterprise agent platforms become the **default workflow shell** in 2027–28, and the underlying SaaS becomes a commodity API behind it. Pricing power transfers to the agent layer.
3. Capital allocation breaks. ROP has done $3.3B of acquisitions in 2025 alone (CentralReach $1.65B, Subsplash $800M) [18] at a moment when seller multiples for vertical SaaS are still 6–12× revenue but the durability of those revenues is the entire question. Net debt $10.08B, net debt/EBITDA ~3.0× [19] — leverage is manageable but not the ammo it was in 2018. If they overpay in 2026–27 to chase AI-positioned targets, ROIIC drops.
4. Inference cost falls less than expected (e.g., reasoning models gate on test-time compute), and AI feature gross margin is dilutive rather than accretive — the CFO's "all of their AI is incremental...accretive" line [14] would have to start fraying within 4–6 quarters.
5. The spin-off proposal fails at the May 19 vote, leaving the conglomerate discount intact while AI fears compress vertical-SaaS multiples further.

The short thesis a stack-literate seller would write: this is a leveraged roll-up of seat-count-priced workflow software at the exact moment seat-count-priced workflow software is being repriced.

## Market view check
At $343 / 15.2× forward / 5.1× NTM revenue, the market is pricing ROP closer to a no-growth diversified industrial than a software compounder. Decade-average forward P/E is ~25–30×; current is roughly half that. Short interest tripling from 1.3% to 3.78% in six months [10] confirms the regime change is "AI threatens vertical SaaS multiples," not "macro slowdown." Consensus PT of $495 implies analysts believe the de-rating is overdone; the market clearly does not yet agree. **The mispricing — if it is one — is in the multiple, not in the technical thesis.** The market is implicitly assigning a >50% probability to material moat erosion within 5 years, which is high relative to the historical base rate for regulated-system-of-record incumbents but defensible given how new the agentic substrate is.

## 90-day falsifiers
- **2026-05-19 annual meeting:** spin-off proposal vote. Even a >30% support level is a meaningful signal that the conglomerate structure is unstable; below 15% is endorsement of status quo [15][16].
- **Q2 2026 earnings (late July):** does enterprise gross retention stay in mid-90s, or does it slip to low-90s? Slippage of >150 bps is the leading indicator of agentic disintermediation showing up in churn rather than just headlines.
- **Q2 2026 AI attach disclosure:** does management quantify AI attach beyond the CentralReach 75% datapoint? Specifically watch Vertafore Velocity ARR contribution and Aderant Stridyn/Harvey joint customer count.
- **Harvey funding/acquisition activity:** if Thomson Reuters or LexisNexis acquires Harvey, the legal segment threat consolidates and Aderant's partnership leverage drops. If Harvey raises again at >$20B with billing/trust adjacent products in roadmap, the disintermediation thesis sharpens.
- **Anthropic/OpenAI roadmap for vertical-specific agent templates:** if Cowork ships pre-built agents for "law firm operations" or "insurance brokerage" that read/write directly into competing systems of record, the threat surface widens.
- **Any further $1B+ ROP acquisition:** EV multiple paid and segment fit will reveal whether management is doubling down or being disciplined.

## What I could not verify
- True net revenue retention by segment — management discloses gross only; the 105–115% NRR figure is third-party inference [8].
- Aderant's specific revenue and operating margin (Roper does not segment-disclose at the business unit level).
- Exact CoGS impact of inference costs on AI features at any portfolio business — the "AI is accretive" claim [14] is unverifiable from outside.
- Whether the Harvey–Aderant integration is exclusive, non-exclusive, or carries any anti-displacement provisions.
- Specifics of the Anthropic Claude Cowork plug-in roadmap for legal, insurance, or govcon verticals — TechCrunch coverage references finance, engineering, design only [17].
- Internal returns on the 2025 acquisition vintage (CentralReach, Subsplash); ROIIC will not be measurable for 2–3 years.
- The actual price ROP would re-rate to in a benign AI scenario — peer comps are unstable in a market actively repricing the entire vertical SaaS cohort.

## Sources
[1] https://en.wikipedia.org/wiki/Roper_Technologies — retrieved 2026-05-10 — Roper portfolio composition by segment, list of operating businesses
[2] https://www.stocktitan.net/sec-filings/ROP/10-q-roper-technologies-inc-quarterly-earnings-report-a24b34a3af85.html — retrieved 2026-05-10 — Q1 2026 10-Q segment revenue, organic growth, raised DEPS guidance $21.80–$22.05
[3] https://www.ropertech.com/application-software/overview — retrieved 2026-05-10 — official Roper business listings and descriptions
[4] https://www.cnbc.com/2026/03/25/legal-ai-startup-harvey-raises-200-million-at-11-billion-valuation.html — retrieved 2026-05-10 — Harvey $11B valuation March 2026 round
[5] https://www.aderant.com/news-pr/aderant-and-harvey-announce-market-defining-partnership/ — retrieved 2026-05-10 — Aderant–Harvey partnership announcement, integration scope
[6] https://news.aderant.com/cloud/stridyn-an-ai-driven-cloud-platform-unlocking-advanced-technology-for-law-firms/ — retrieved 2026-05-10 — Stridyn platform technical description, MADDI AI layer
[7] https://www.deltek.com/en/blog/govcon-ai-opportunity-proposal-tools — retrieved 2026-05-10 — Deltek Dela AI, GovWin/Costpoint AI integration, G2 2026 Best ERP recognition
[8] https://medium.com/omers-ventures/the-challenges-of-legal-vertical-saas-56ec53ebe2b9 — retrieved 2026-05-10 — legal SaaS migration timing (6+ months), switching cost mechanics
[9] https://stockanalysis.com/stocks/rop/statistics/ — retrieved 2026-05-10 — ROP price $343.32, market cap $34.65B, EV $44.73B, EV/Rev 5.51×, EV/EBITDA 14.0×, fwd P/E 15.22×, beta 0.80, dividend 1.06%
[10] https://www.marketbeat.com/stocks/NASDAQ/ROP/short-interest/ — retrieved 2026-05-10 — short interest 3.78% of float as of 2026-04-15, up from 1.3% Oct 2025
[11] https://www.marketbeat.com/stocks/NASDAQ/ROP/forecast/ — retrieved 2026-05-10 — analyst consensus PT $495.43, "Buy" rating from 14 analysts
[12] https://www.tikr.com/blog/roper-technologies-stock-is-down-40-from-its-52-week-high-heres-what-could-drive-the-next-move — retrieved 2026-05-10 — YTD performance ~−20.6%, 40% drawdown from 52-week high
[13] https://www.truckinginfo.com/news/dat-to-acquire-convoy-automated-freight-matching-platform-from-flexport — retrieved 2026-05-10 — DAT acquisition of Convoy automated freight-matching from Flexport
[14] https://www.fool.com/earnings/call-transcripts/2026/04/23/roper-rop-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — CEO/CFO direct quotes on AI monetization, retention "mid-90% gross," CentralReach 75% AI attach, Velocity AI/Stridyn/Dela/Convoy Load Notes specifics
[15] https://www.stocktitan.net/sec-filings/ROP/def-14a-roper-technologies-inc-definitive-proxy-statement-3719e1216d60.html — retrieved 2026-05-10 — definitive proxy, May 19 2026 meeting, spin-off proposal, board opposition
[16] https://www.sahmcapital.com/news/content/assessing-roper-technologies-rop-valuation-as-spin-off-proposal-and-board-opposition-draw-focus-2026-04-21 — retrieved 2026-05-10 — Friedman shareholder proposal for tax-free spin-off of Application + Network Software
[17] https://techcrunch.com/2026/02/24/anthropic-launches-new-push-for-enterprise-agents-with-plugins-for-finance-engineering-and-design/ — retrieved 2026-05-10 — Anthropic Claude Cowork enterprise plug-ins launch 2026-02-24, MCP-based read/write
[18] https://www.ainvest.com/news/roper-technologies-capital-allocation-conviction-software-industrial-rotation-2601/ — retrieved 2026-05-10 — $3.3B of 2025 acquisitions, CentralReach $1.65B, Subsplash $800M
[19] https://www.investing.com/news/transcripts/earnings-call-transcript-roper-technologies-q3-2025-shows-solid-eps-beat-93CH-4305030 — retrieved 2026-05-10 — Q3 2025 net debt/EBITDA 3.0×, $710M drawn on $3.5B revolver, Q1 2026 net debt $10.08B