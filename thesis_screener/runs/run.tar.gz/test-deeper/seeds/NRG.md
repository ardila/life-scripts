# NRG — NRG Energy, Inc.

## Where this sits in the AI stack
NRG is a US merchant power producer and competitive retailer — it sells **electrons**, not chips. Post the January 2026 close of the LS Power deal, it operates ~25.8 GW of generation (76% natural gas, 50% in ERCOT, 39% in PJM) and serves ~7M retail customers, ~1.5M of them on the Reliant brand in deregulated Texas [1][2][3]. Its AI exposure is at the **power layer** of the AI stack: dispatchable thermal generation feeding hyperscaler training and inference data centers via long-dated retail contracts, plus a 5.4 GW combined-cycle development pipeline targeted at the 2029–2032 vintage of AI buildouts in ERCOT and PJM [4][5]. The workload it serves is power-agnostic — what matters is 24/7 firm capacity behind the meter or in nearby load zones, with the heaviest demand from training clusters and large-batch inference whose tolerance for curtailment is approximately zero.

## Snapshot
- **Price:** $139.89 (2026-05-08 close) [6]
- **Market cap:** ~$29.5B [6]
- **52-week range:** $117.44 – $189.96 [7]
- **Forward P/E:** ~15.5× (midpoint of FY26 guidance EPS $7.90–$9.90, midpoint $8.90) [8]; n/a on a consensus basis as MarketBeat aggregates show $9.02 ⇒ ~15.5× as well [9]
- **EV / NTM revenue:** ~0.9× (EV ≈ $36B vs. ~$36–38B revenue; revenue mix is dominated by low-margin retail pass-through and is not the relevant valuation metric — EV/EBITDA at ~9× on $4.05B 2026 EBITDA guidance is the cleaner read) [10]
- **Consensus 12-month price target:** $197 (+~41% from price) [1]
- **YTD total return:** Not directly disclosed in retrieved sources; the 52-week high of $189.96 suggests YTD is negative from peak; unverified — see "What I could not verify"
- **Short interest (% of float):** 2.3% [7]

## Moat — what it is physically made of
NRG's moat is a **stack of scarce physical and contractual assets**, not technology. Decomposing it:

**1. Turbine slot reservations (medium-strong, 3–5 year durability).** NRG has a project development agreement with GE Vernova and Kiewit for up to 5.4 GW of 7HA-class combined cycles, with two 7HA units already secured under slot reservation for the first 1.2 GW block in COD 2029 [4][5]. This matters because GE Vernova's gas turbine backlog hit ~100 GW in Q1 2026 (up from ~80 GW year-end 2025), lead times have stretched to 3–4 years for prioritized customers and 5–7 years otherwise, and the OEM only expects 20 GW of annualized output by Q3 2026 [11][12]. Mitsubishi Power and Siemens Energy face similar queues. A new entrant trying to build merchant gas in ERCOT in 2026 cannot order turbines and expect 2029 COD; NRG can. This is a hard, dated, falsifiable advantage.

**2. EPC and gas-balance-of-plant capacity (medium, 2–3 year durability).** Kiewit is the dominant US EPC for combined-cycle power; the bottleneck on AI-era gas buildouts is increasingly skilled trades and BOP integration, not the turbine island. NRG has a named-counterparty EPC framework with Kiewit covering all four pipeline projects [4]. Replicable in principle (Bechtel, Black & Veatch, Burns & McDonnell exist) but not at speed.

**3. Texas Energy Fund 3% loans (strong, contractually fixed).** Three TEF projects totaling 1.547 GW (T.H. Wharton 415 MW, Cedar Bayou 5 689 MW, Greens Bayou 6 443 MW) are funded at 60% LTV with 20-year fixed 3% PUCT loans, several hundred basis points below market for a sub-IG IPP — this is a permanent subsidy embedded in the cap stack, ~$1B+ of below-market debt [13][14][15]. Not replicable: the program is fixed-pool and substantially allocated.

**4. ERCOT geographic + interconnection position (strong, 5+ year durability).** NRG's gas fleet sits on legacy Cedar Bayou, T.H. Wharton, Greens Bayou, and Limestone sites — i.e., sites with existing 345 kV interconnection rights, water rights, and gas laterals. ERCOT's queue interconnection backlog and SB6's new co-location study/approval process (120-day ERCOT study + 60-day PUCT review for any net-metering ≥75 MW with a pre-9/1/2025 generator) make brownfield expansion materially faster than greenfield [16][17]. Hyperscalers care about COD year, not LCOE, so a 2-year speed advantage is worth a lot of marginal-cost premium.

**5. Retail integration (medium, durable but commoditizing).** Reliant + Direct Energy + Green Mountain serve ~7M customers, ~1.5M in Texas. The retail book is the hedge that gives NRG fundamentally lower earnings volatility than a pure merchant — short physical gen, long retail load matches MWh shipped to MWh sold and largely insulates against ERCOT scarcity spikes [2][18]. Vistra has an even bigger retail book (TXU); Constellation does not. This is a real edge over Constellation/Talen for serving hyperscaler retail load directly, but not over Vistra.

**6. CPower C&I VPP (weak-to-medium, 3–5 year durability).** 6 GW of dispatchable C&I demand response across all deregulated US markets, acquired from LS Power [3][19]. Useful, but VPP is a crowded segment (AutoGrid, Voltus, Enel X) and the moat is the customer book, not technology.

**What is not a moat:** Nothing here is a software, IP, or scaling-law advantage. There is no equivalent of CUDA or HBM lock-in. The "moat" is contractual scarcity in a window the industry is racing to close. Base rate on contractual-scarcity moats in commodity industries (US shale 2014, LNG 2010s, lithium 2022): they monetize for 5–8 years and then compress as supply chains catch up. The right framing is **option value on a 2026–2030 window**, not perpetual franchise.

## AI buildout bottleneck map
Gating constraints over the next 24 months, and NRG's position on each:

- **Gas turbine supply (GE Vernova, Mitsubishi, Siemens Energy):** Backlog ~100 GW at GEV, slots through 2029–2030 [11][12]. NRG is a **constraint owner / beneficiary** — it has reserved capacity, new entrants can't.
- **HV grid interconnect and transmission:** ERCOT and PJM both have multi-year queues; ERCOT large-load queue is >367 GW of requests by 2033 vs. ~98 GW peak today [20]. NRG is a **beneficiary** because brownfield sites bypass much of the queue.
- **EPC/skilled trades capacity:** Kiewit, Bechtel, Zachry are oversubscribed. NRG is a **beneficiary** via Kiewit framework [4].
- **Gas pipeline and midstream takeaway (Houston Ship Channel, Permian-to-Houston):** Real constraint on Houston-area combined cycles. Cedar Bayou and Greens Bayou are on existing interstate-connected systems but incremental firm transport is tight. NRG is **exposed** here.
- **HBM yield, CoWoS-L allocation, optical interconnect:** Indifferent / **neutral** — NRG sells electrons, not silicon.
- **Power generation primary fuel (LNG export competition for gas):** ERCOT gas burn competes with Gulf Coast LNG offtake. Henry Hub strip rising = NRG retail/gen spread compression unless hedged. **Exposed customer** on the cost side.
- **Liquid cooling, advanced packaging:** Indifferent.
- **Permitting (air permits, water rights, federal NEPA where applicable):** Texas has fast permitting relative to PJM states; brownfield air permit modifications are weeks/months, not years. NRG is a **beneficiary** in ERCOT, more exposed in PJM/NY.
- **SMR fuel (HALEU), nuclear restart capability:** NRG has no nuclear. **Indifferent / negative** — competitor advantage.

The honest synthesis: NRG's moat exists *because* of the bottleneck. If turbine production unlocks faster than expected — Mitsubishi has been ramping aggressively, and Chinese OEMs (Harbin, Dongfang) are not yet a meaningful export factor but could be by 2028 — then NRG's slot-reservation advantage compresses.

## Competitive teardown
Specific axes, current evidence:

**Vistra (VST) — most direct comparable.** 44 GW total, 6.4 GW nuclear (Comanche Peak + the 2024 Energy Harbor nuclear), big Texas retail book (TXU, 5M+ customers), Meta 2.6 GW nuclear deal in Ohio/PA [21][22]. On the **retail+gen-integrated axis**, Vistra has scale advantage. On the **nuclear baseload axis** for hyperscaler 24/7 carbon-free contracts, Vistra has an asset NRG cannot replicate — Meta, Microsoft, Google all prefer nuclear PPAs for CFE matching. NRG cannot win those specific contracts. On the **new gas build axis**, NRG and Vistra are head-to-head; Vistra committed to a $1.9B / 2.6 GW gas acquisition rather than greenfield build, which is a signal that Vistra also sees turbine constraints [22].

**Constellation Energy (CEG) — nuclear-led, now gas via Calpine.** Acquired Calpine for $16B in 2025 [21], adding ~26 GW of mostly gas combined-cycle (Calpine has the largest US CCGT fleet). Three Mile Island restart for Microsoft is grid-injection, not behind-the-meter [23]. After Calpine, Constellation is the closest peer to NRG on combined-cycle gas — and has nuclear on top. The honest read: Constellation already has parity-plus on the gas axis post-Calpine, and structural advantage on nuclear. CEG trades at a richer multiple but for arguably better reasons.

**Talen Energy (TLN).** Susquehanna 2.5 GW nuclear, plus PJM gas. The Amazon 1.92 GW Susquehanna PPA was the trailblazer for behind-the-meter nuclear, but FERC rejected the uprate above 300 MW for the direct co-location in November 2024 [24][25]. The FERC December 2025 PJM co-location order then created a new framework (Firm Contract Demand / Non-Firm Contract Demand transmission services) that could revive these structures by ~April 2026 [26][27]. Talen is the **purest play on behind-the-meter monetization** — if the FERC rulemaking lands favorably, Talen captures the most upside; NRG benefits indirectly via the same framework applied to PJM gas. NRG has no nuclear so it cannot compete on the 24/7 CFE axis.

**Calpine (now part of Constellation).** Was the dominant CCGT operator, ~26 GW. As an embedded competitor inside CEG, it now competes head-on with NRG on the new-build gas axis in ERCOT and PJM.

**Pre-emptive note on hyperscaler self-build:** Microsoft, Meta, Google have all signaled willingness to procure gen-tied land, gas turbines (Microsoft + Mitsubishi rumored, unverified), and EPC capacity themselves. This is the most credible long-term competitive threat — vertical integration by the offtaker. NRG's response (long-dated 10–20 year PPAs at fixed structure) is rational but only works if signed before the hyperscaler decides to self-build.

## Bull case — technical
The technical conditions that have to hold:

1. **ERCOT large-load demand materializes ≥80% of the 367 GW request queue by 2033** [20]. Even at 30% conversion, that is ~100+ GW of incremental load — and NRG's 5.4 GW pipeline is a small share of what a tight market needs. Reserve margins go negative-net-peak in 2026 already [28].
2. **GE Vernova turbine slot scarcity persists through 2029.** GEV backlog growth (~+20 GW per quarter on a ~20 GW production rate) implies no relief until 2030+ even if production hits the 24 GW target. NRG's reserved 5.4 GW is then worth a substantial premium to spot.
3. **PUCT / ERCOT do not impose retroactive co-location restrictions that strand NRG's hyperscaler optionality.** SB6's prospective rules (applied only to plants existing as of 9/1/2025 entering net-metering) are workable for NRG's brownfield and new-build sites if structured as load zone serving, not co-location.
4. **Henry Hub strip stays sub-$5/MMBtu enough of the time that combined-cycle dispatch margins remain attractive.** EIA strip in late 2025 was ~$3.50–$4.50 through 2030; CCGT heat rates of ~6,400 Btu/kWh on 7HA imply variable cost ~$22–28/MWh, comfortably below ERCOT data center contract floor.
5. **Hyperscaler self-build of gen does not progress materially before 2028.** Vertical integration is a 3–5 year project including turbine queue + EPC + permitting; NRG's window is real but not infinite.

If all five hold, the 2026 EBITDA of $4.05B compounds at ~14% (management's stated EPS/FCF guidance) toward $7–8B by 2030, before the 5.4 GW pipeline EBITDA contribution which Jefferies has sized at $1B by 2030 / $2.5B by 2033 [1]. At 9× EBITDA the equity gets to ~$50–60B (~$200–280/share), consistent with sell-side targets. **Base rate caveat:** IPPs have historically been highly cyclical (NRG itself went through Chapter 11 in 2003 after the 2001–2002 power glut; merchant gas multiples compressed from 12× to 4× EBITDA between 2001 and 2009). The current cycle could rhyme. The bull thesis depends on AI being a structural, not cyclical, driver.

## Bear case — technical
What a credible short who understands the stack would write:

1. **Turbine supply unlocks 2028–2029 from Mitsubishi M501JAC and Siemens SGT5-9000HL ramp-ups, plus second-shift production at GEV Greenville.** Already GEV is targeting 24 GW by 2028 vs. 20 GW Q3 2026 [11]; if Mitsubishi adds 8–10 GW and Siemens 4–6 GW, the global market goes from 30 GW/yr to 50+ GW/yr by 2029. Slot-reservation premium collapses. NRG's 5.4 GW pipeline becomes one of dozens.
2. **AI training capex curve flattens in 2027–2028 as scaling-law returns diminish at frontier.** If hyperscaler capex grows from ~$400B (2025) at 10%/yr instead of 30%+, ERCOT large-load queue conversion goes from speculative 30% to 10–15%, and ERCOT reserve margins recover. This is the central technical question for the entire AI power thesis and NRG cannot control it.
3. **FERC and PUCT impose dispatchable-capacity-must-stay rules that block behind-the-meter monetization.** SB6 already requires that any dispatchable generation that "previously made capacity available" to ERCOT continue to do so [16]. This caps the upside of selling existing fleet output to a co-located hyperscaler at a premium — you can serve the load *and* keep grid obligation, but the premium thins.
4. **Henry Hub strip rises >$5/MMBtu on LNG export demand (Plaquemines, Rio Grande, Port Arthur ramps).** Texas gas burn for power competes with Gulf Coast LNG offtake; 2027–2028 strip currently shows tightness. Variable cost of CCGT rises faster than retail electricity price re-prices, compressing spark spreads. This is the most under-appreciated bear catalyst.
5. **Nuclear restart wave (Three Mile Island 2028, Palisades 2025, Duane Arnold) plus first SMRs (Kairos 2030, X-energy 2030, Oklo 2027+) re-rate the carbon-free 24/7 product** [29]. Hyperscalers paying $80–110/MWh for nuclear CFE will not pay the same for gas with unbundled RECs. NRG has no nuclear option. Constellation, Vistra, Talen do. Within 5 years this is a real differentiation, especially as Scope 2 reporting tightens.
6. **Vistra's TXU retail + nuclear stack out-competes NRG's Reliant + gas stack** for hyperscaler retail-served load in ERCOT. Vistra already has Comanche Peak nuclear in ERCOT — NRG does not.
7. **LS Power integration risk.** ~$3.2B of debt assumed [30]; the acquired fleet includes older quick-start peakers whose value in a peakier ERCOT is real but whose capex/maintenance profile is harder than greenfield H-class.

A short who got these right would point out: the 24% upside to consensus PT implies the bull case is partly priced in already, and the 52-week high of ~$190 prices in even more. The bear case asymmetry is real if AI capex disappoints in 2027–2028.

## Market view check
At ~$140 / ~15.5× forward / ~9× 2026 EBITDA, NRG is priced **above utility median (~13×) but materially below Constellation and Vistra (mid-20s× forward P/E)**. The market is paying for: (i) the LS Power-doubled fleet now contributing for 11 months of 2026, (ii) confirmed 5.4 GW turbine pipeline, and (iii) credible 14% EPS CAGR guide. The market is *not* fully paying for: (a) the nuclear-led 24/7 CFE premium that Vistra/CEG/TLN command, (b) full materialization of the ERCOT 367 GW large-load queue. My read: the multiple gap to CEG/VST is technically justified by the missing nuclear option, not by quality of gas execution. So the stock is reasonably priced relative to peer set on the gas axis but cheap if you think gas-fired CCGTs end up being the marginal AI power source through 2030 (which is the physical-realism call — SMRs slip, nuclear restarts are limited in count).

## 90-day falsifiers
- **Bullish trigger:** Announcement of the rumored ~1 GW+ hyperscaler combined-cycle PPA (Jefferies referenced this for 1H26) [1]. Specifically a long-dated (15+ year) tolling or take-or-pay structure with a named counterparty.
- **Bullish trigger:** GE Vernova 2Q26 earnings showing backlog >110 GW and pricing power confirmation; or Q2 ERCOT CDR showing summer 2027 net-peak reserve margin worsening from -6.2%.
- **Bearish trigger:** FERC final rulemaking on PJM co-location (expected by ~April 2026) [26] lands restrictively, requiring continued grid obligation for ALL generation including new-build — this caps NRG's PJM data center premium directly.
- **Bearish trigger:** Texas PUCT issues an order under SB6 implementation imposing dispatchable-generation-must-stay on new-build (not just existing); kills the standalone hyperscaler PPA at premium-to-grid pricing.
- **Bearish trigger:** Q2 2026 hyperscaler capex guidance from any two of MSFT/META/GOOG/AMZN cut by >10% sequentially. ERCOT large-load queue is forward-looking and a guidance cut signals the request-to-energization conversion will be lower.
- **Bearish trigger:** Mitsubishi Power announces second-shift / capacity expansion adding >5 GW/yr of M501JAC production by 2028; meaningfully erodes GEV slot scarcity.
- **Material:** T.H. Wharton 415 MW commercial operation by end of May 2026 [15]. Slip = execution credibility hit on the broader 5.4 GW pipeline.
- **Material:** Q2 2026 earnings disclosure of the data center pipeline conversion — management said in Q1 that 2026 needs to see signed agreements to hit 2029 COD [31]. Quarterly disclosure of signed long-term contracts is the cleanest read on the thesis.

## What I could not verify
- **Exact YTD 2026 total return:** Snapshot sources gave price + 52-week range but not a clean YTD return number with dividend reinvestment. Inferring from $189.96 high (likely Q4 2025 / early Q1 2026) and $139.89 current, YTD looks meaningfully negative from peak but the YTD-from-Jan-1 figure is unverified.
- **Exact EV/NTM revenue:** Mix of regulated retail pass-through revenue and merchant generation revenue makes the ratio noisy; preferred metric is EV/EBITDA which is more reliably ~9× 2026.
- **Specific identity of the rumored ~1 GW+ hyperscaler counterparty.** Jefferies note referenced this but did not name the buyer.
- **Mitsubishi Power and Siemens Energy turbine backlog disclosure** with comparable specificity to GE Vernova's 100 GW figure. Both are non-US-listed and disclose less.
- **Henry Hub strip detail through 2030 at a daily-quote level**; I relied on directional EIA-style ranges.
- **Whether NRG's 5.4 GW pipeline turbines are formally booked as orders or only as slot reservations.** Slot reservations carry meaningfully different contractual exposure than firm orders; GEV uses both classes.
- **Hyperscaler-specific commitments to behind-the-meter vs. front-of-meter mix** post-FERC December 2025 order; the legal framework just changed and customer behavior is still settling.
- **The fraction of LS Power acquired fleet capacity that has already been contracted long-term** — material to underwriting the deal's accretion.

## Sources
[1] investing.com — retrieved 2026-05-10 — Jefferies note referencing 5.4 GW pipeline, $1B EBITDA upside by 2030, $2.5B by 2033, and a rumored ~1 GW+ hyperscaler announcement targeted for 1H26: https://www.investing.com/news/analyst-ratings/jefferies-raises-nrg-energy-stock-price-target-on-data-center-growth-93CH-4609436
[2] en.wikipedia.org — retrieved 2026-05-10 — NRG retail footprint (7M+ customers, 24 states + DC + Canada); Reliant ~1.5M in Texas: https://en.wikipedia.org/wiki/NRG_Energy
[3] investors.nrg.com — retrieved 2026-05-10 — Completion of 13 GW LS Power acquisition + CPower VPP (Jan 30, 2026): https://investors.nrg.com/news-releases/news-release-details/nrg-energy-completes-acquisition-13-gw-power-generation-and-ci
[4] utilitydive.com — retrieved 2026-05-10 — NRG/GE Vernova/Kiewit 5.4 GW project development agreement, COD 2029–2032: https://www.utilitydive.com/news/nrg-aims-for-2026-next-step-in-54-gw-gas-deal-with-ge-vernova-kiewit/805692/
[5] energychoicematters.com — retrieved 2026-05-10 — Original 5.4 GW JV announcement; two 7HA units secured under slot reservation: https://www.energychoicematters.com/stories/20250226a.html
[6] finance.yahoo.com — retrieved 2026-05-10 — NRG price $139.89, market cap $29.5B, May 8 2026 close: https://finance.yahoo.com/quote/NRG/
[7] dailypolitical.com / fintel.io — retrieved 2026-05-10 — 52-week range $117.44–$189.96 and short interest 2.3%: https://www.dailypolitical.com/2026/05/02/nrg-energy-inc-nysenrg-short-interest-update.html
[8] gurufocus.com — retrieved 2026-05-10 — Forward P/E 17.18× as of April 28, 2026 (snapshot; current is lower at midpoint guide): https://www.gurufocus.com/term/forward-pe-ratio/NRG
[9] marketbeat.com — retrieved 2026-05-10 — Consensus EPS $9.02 FY26: https://www.marketbeat.com/stocks/NYSE/NRG/earnings/
[10] seekingalpha.com — retrieved 2026-05-10 — 2026 adjusted EBITDA $4.05B target with data center strategy detail: https://seekingalpha.com/news/4517808-nrg-outlines-4_05b-2026-adjusted-ebitda-target-as-company-expands-data-center-strategy-and
[11] utilitydive.com — retrieved 2026-05-10 — GE Vernova gas turbine backlog 100 GW Q1 2026; 20 GW/yr by Q3 2026, 24 GW by 2028: https://www.utilitydive.com/news/ge-vernova-gas-turbine-backlog-hits-100-gw-as-prices-rise/818332/
[12] nextbigfuture.com — retrieved 2026-05-10 — Lead times 3-7 years, slot scarcity through 2030: https://www.nextbigfuture.com/2025/09/2028-2030-to-get-a-ge-290-430mw-natural-gas-turbine.html
[13] utilitydive.com — retrieved 2026-05-10 — Texas Energy Fund secured loans for NRG, 3% rate, 60% LTV, 20-year: https://www.utilitydive.com/news/texas-loan-fund-tops-35-gw-of-gas-capacity-secured-with-latest-nrg-deal/806144/
[14] gov.texas.gov — retrieved 2026-05-10 — TEF loan terms confirmation for Greens Bayou 6: https://gov.texas.gov/news/post/governor-abbott-announces-texas-energy-fund-loan-to-456-mw-natural-gas-facility-in-houston
[15] utilitydive.com — retrieved 2026-05-10 — T.H. Wharton 415 MW near COD end of May 2026: https://www.utilitydive.com/news/nrg-close-to-completing-415-mw-gas-plant-backed-by-texas-energy-fund/819587/
[16] weil.com — retrieved 2026-05-10 — Texas SB6: 75 MW threshold, ERCOT 120-day study + PUCT 60-day review, dispatchable-must-stay clause: https://www.weil.com/-/media/files/pdfs/2025/july/weil-energy-alert--senate-bill-6-reforms-interconnection-and-colocation-rules-for-data-centers-and-o.pdf
[17] perkinscoie.com — retrieved 2026-05-10 — SB6 implementation tracks, co-location and large-load forecasting: https://perkinscoie.com/insights/update/sb-6-implementation-shaping-data-center-future-texas
[18] reliant.com — retrieved 2026-05-10 — Reliant Texas retail (subsidiary brand): https://www.reliant.com/
[19] cpowerenergy.com — retrieved 2026-05-10 — CPower 6 GW C&I VPP, 2000+ customers: https://cpowerenergy.com/virtual-power-plants/
[20] datacenterdynamics.com — retrieved 2026-05-10 — ERCOT 367 GW large-load request queue by 2033; peak load forecast 98→111-117 GW 2026→2031/32: https://www.datacenterdynamics.com/en/news/ercot-and-miso-forecast-huge-increases-in-peak-load-driven-by-data-center-demand/
[21] fool.com — retrieved 2026-05-10 — Vistra 44 GW / 6.4 GW nuclear; Constellation acquired Calpine $16B: https://www.fool.com/investing/2026/02/11/better-utility-stock-constellation-energy-v-vistra/
[22] utilitydive.com — retrieved 2026-05-10 — Meta-Vistra 2.6+ GW nuclear deal; Vistra $1.9B / 2.6 GW gas acquisition: https://www.utilitydive.com/news/meta-nuclear-deal-oklo-vistra-terrapower-ai-data-centers/809215/
[23] enkiai.com — retrieved 2026-05-10 — Constellation Three Mile Island restart for Microsoft, grid injection structure: https://enkiai.com/nuclear/microsoft-constellation-ai-data-centers/
[24] cnbc.com — retrieved 2026-05-10 — FERC rejection of Talen-Amazon Susquehanna uprate above 300 MW: https://www.cnbc.com/2024/11/04/tech-partnerships-with-power-companies-for-ai-in-doubt-after-ferc-order.html
[25] enkiai.com — retrieved 2026-05-10 — AWS-Talen 1.92 GW 17-year PPA detail: https://enkiai.com/nuclear/aws-data-center-talen-energy/
[26] bakerbotts.com — retrieved 2026-05-10 — FERC December 18 2025 PJM co-location order; Firm/Non-Firm Contract Demand transmission services: https://www.bakerbotts.com/thought-leadership/publications/2025/december/ferc-issues-order-providing-guidance-for-co-locating-power-plants-with-data-centers-within-pjm
[27] ferc.gov — retrieved 2026-05-10 — FERC commissioner concurrence and fact sheet on co-location: https://www.ferc.gov/news-events/news/fact-sheet-ferc-directs-nations-largest-grid-operator-create-new-rules-embrace
[28] ercot.com — retrieved 2026-05-10 — Summer 2026 reserve margins: -6.2% net peak, +5.2% peak: https://www.ercot.com/files/docs/2025/05/16/CapacityDemandandReservesReport_May2025_Revised.pdf
[29] cleanenergyforum.yale.edu — retrieved 2026-05-10 — SMR commercial timeline analysis; Kairos/X-energy/Oklo 2027–2030+: https://cleanenergyforum.yale.edu/2026/04/26/an-analysis-of-small-modular-reactors-smrs-for-commercial-electricity-generation-in-the
[30] power-technology.com — retrieved 2026-05-10 — LS Power deal cap stack ($6.4B cash, $2.8B stock, $3.2B net debt, $0.4B tax NPV): https://www.power-technology.com/news/nrg-energy-asset-deal-ls-power/
[31] fool.com — retrieved 2026-05-10 — Q1 2026 earnings transcript: 2026 signings required to hit 2029 COD, gas-supply/interconnection coordination as primary hurdle: https://www.fool.com/earnings/call-transcripts/2026/05/06/nrg-nrg-q1-2026-earnings-call-transcript/