I have enough material. Composing the dossier now.

# LRCX — Lam Research Corporation

## Where this sits in the AI stack
LRCX sells **wafer fabrication equipment (WFE)** — specifically the **etch, deposition, clean, and dry-resist tools** that physically sculpt and metallize transistors and 3D memory stacks. Lam does not touch GPUs, networking, power, or runtime software. Their AI exposure is one layer below: every Blackwell/Rubin GPU built at TSMC, every HBM3E/HBM4 stack built at SK Hynix/Samsung/Micron, and every QLC SSD shipped to a hyperscaler runs through Lam etch chambers (Vantex, Akara, Sense.i) and Lam ALD/CVD tools (Vector, Striker, ALTUS Halo). They are picks-and-shovels at the *material physics* layer — atomic-scale removal and addition of films — not at the silicon-design or packaging-bonder layer.[1][2][3]

## Snapshot
- **Price:** $294.84 (2026-05-10 close)[4]
- **Market cap:** ~$367.7B[4]
- **52-week range:** $74.65 – $298.00[4][5]
- **Forward P/E:** ~42–43× (on FY27 consensus EPS; FY26E EPS tracking ~$5.65 vs $3.36 in CY24)[6][7]
- **EV / NTM revenue:** ~13× (FY27E revenue ~$26–27B against EV ~$348B, market cap less ~$20B net cash)[8] — *inferred from cap + Investor Day midpoint guide*
- **Consensus 12-month price target:** $315 median (43 analysts, range $220–$385); implied +6.8% from spot[6][9]
- **YTD total return:** +116.4%[5]
- **Short interest:** 27.97M shares, 2.24% of shares outstanding[10]

## Moat — what it is physically made of
Lam's moat is **not "CUDA-style" software lock-in.** It is a process-recipe + tool-of-record + co-development moat that is unusually durable for a hardware company. Decomposed:

**1. Conductor and dielectric etch IP — the highest-aspect-ratio chambers in production.**
- Lam holds ~**45% of global etch equipment** revenue and **>60% of the ALE (atomic layer etch) segment** (2024).[11][12]
- *Specific tools:* Vantex (dielectric, cryo HAR), Akara (conductor, 6F²/4F²-extendible), Sense.i, Syndion (TSV).[1][2][13]
- Cryo etch 3.0 maintains <0.1% CD deviation on 10µm-deep, >50:1 aspect-ratio channels — the physical prerequisite for 3D NAND beyond ~200 layers.[14][15] The competitive issue (see bear): TEL beat Lam to this technology by ~1.5 years for some customers.[16][17]
- *Replicating at parity:* TEL has been chasing HAR cryo etch since ~2019 and only now has POR at one customer (Samsung V10) for one application. Total customer-qualification cycle for a new etch tool is typically 18–36 months per recipe per fab, per device. The institutional friction is real.[16][17]

**2. ALD/CVD for 3D memory metallization — installed base lock-in.**
- ALTUS Halo (Mo ALD, announced Feb 2025) is the **first production tool for the tungsten→molybdenum transition** in 3D NAND wordlines, DRAM bitline spacers, and logic interconnect — delivers >50% resistance reduction without an adhesion barrier. Lam already owns "the largest installed base for 3D NAND wordline metallization."[2][18][19] This is the rare case where an incumbent gets to *re-sell* their installed base on a material change.
- Striker ALD is qualified as a tool-of-record at leading memory makers for DRAM 1c-node bitline spacer.[3]

**3. HBM-specific: TSV etch + dielectric.**
- Syndion is described as "the gold standard for Through-Silicon Via etching."[20] Every HBM3E 12-Hi → HBM4 16-Hi → HBM4E 20-Hi stack multiplies TSV count per wafer linearly with die count, and HBM4 introduces a logic base die that needs its own TSV processing.
- SK Hynix signed a $2.3B multi-year tool agreement (Nov 2025) explicitly to support HBM3E and HBM4 etch.[11]
- Advanced packaging revenue: ~$1B CY24 → ~$3B CY25 → growth >50% in CY26 (so ~$4.5B+).[3][20]

**4. Aether — dry photoresist for EUV.**
- Adopted by a leading memory manufacturer as **production tool-of-record for the most advanced DRAM** (Jan 2025). Uses 5–10× less raw resist material; co-developed with ASML/imec and Entegris/Gelest.[21][22] This is a *new* leg — it is selling into a market historically owned by TOK / JSR / Shin-Etsu (wet resists) and is the only WFE moat-extension Lam has built outside its core in ~15 years.
- *Replication cost:* the dry-resist stack required ~10 years of dedicated R&D plus co-development with ASML and a chemistry consortium. AMAT has no equivalent program in production.[23]

**5. SAM expansion mechanics.**
- Lam's Serviceable Available Market is on a structural path from low-30% to **high-30% of WFE** because etch+deposition intensity grows faster than lithography as devices go vertical (3D NAND, GAA, 3D DRAM, advanced packaging).[24][25] This is the single most important technical fact about LRCX: *the bottleneck of chip-making is migrating into their wheelhouse.*

**Honest assessment of durability:**
- Most durable: Mo ALD installed base, dry-resist IP (10-year head start), TSV etch (Syndion is the franchise).
- Less durable: HAR cryo etch (TEL just took share at Samsung V10); some conductor etch overlap with AMAT Sym3.
- Brand/scale doesn't move tools. Process recipes do. Customer switching cost is measured in months of qual time per recipe per fab.

## AI buildout bottleneck map
Constraints over the next ~24 months, with Lam's actual exposure:

| Bottleneck | LRCX position | Evidence |
|---|---|---|
| **CoWoS-L allocation** (TSMC: 35k WPM late-24 → 130k WPM target end-26; Nvidia booked ~60%/595k wafers in 2026) | **Indirect beneficiary.** Lam does *not* sell the hybrid/thermocompression bonders (Besi, ASMPT lead); Lam supplies the interposer wafer's etch/deposition and the TSV chain. ~$3B advanced-packaging revenue is the real number. | [26][27] |
| **HBM bit supply & TSV intensity** | **Direct beneficiary.** Syndion TSV etch is gold-standard; 12-Hi → 16-Hi → 20-Hi stacks scale TSV count linearly. $2.3B SK Hynix MOU signed. | [11][20] |
| **3D NAND layer scaling >200L** | **Direct beneficiary, with TEL contesting.** $40B of NAND conversion spend now pulled forward to land before end-CY27 — driven by AI SSD/QLC demand. Lam Cryo 3.0 + ALTUS Halo Mo wordline. | [3][28][18] |
| **GAA (2nm) ramp at TSMC/Samsung/Intel 18A** | **Direct beneficiary.** Selis selective etch for SiGe channel release is the critical step; etch intensity rises 25–30% per wafer at GAA vs FinFET. | [29][30] |
| **HBM hybrid bonding (HBM4E/4F)** | **Partial / contested.** Lam, AMAT and TEL all competing for Besi-style copper-copper bond integration; Samsung is building dedicated hybrid-bond line at Cheonan. Lam supplies the surface prep / CMP / dielectric, not the bonder itself. | [31][32] |
| **Advanced power / 100kW+ rack cooling / electrical grid** | **Indifferent.** No exposure. | — |
| **Photolithography (EUV / High-NA EUV)** | **Indirect tailwind via Aether dry resist** (one POR at a memory leader for DRAM). Not a primary exposure. | [21] |
| **Kernel/compiler talent, training data** | **Indifferent.** | — |

The clean reading: Lam captures the *memory + advanced-packaging* tail of the AI buildout in a way that AMAT/TEL share but ASML and KLA do not. They do **not** capture the bonder leg of CoWoS-L. Their best leverage is to HBM stack height growth and NAND layer-count growth — both of which are accelerating.

## Competitive teardown

**Applied Materials (AMAT)** — Broader portfolio (etch + dep + epi + implant + CMP + e-beam metrology). Leads deposition overall; trails Lam in etch and especially ALE. On HBM TSV etch, AMAT Sym3 Y chamber and Lam Flex/Syndion both report double-digit order growth from HBM3E adopters — this is *parity by tonnage, Lam-favored by recipe specificity.*[12][33] AMAT is the better diversified play; Lam is the better pure-play on the *atomic-scale physics* axis.

**Tokyo Electron (TEL)** — The credible technical threat. TEL holds ~10–15% of 3D NAND etch and won **Samsung V10 (400+ layer) cryogenic channel-hole etch POR for 2026** — the first meaningful crack in Lam's NAND etch dominance in ~15 years.[16][17][34] TEL is also pushing Mo deposition. SemiAnalysis (paywalled) frames >$1B of NAND revenue as in motion.[34] *What would have to be true for TEL to take real share:* TEL extends cryo etch wins beyond Samsung to SK Hynix or Micron, and TEL's Mo deposition qualifies at any leading-edge customer. As of May 2026, that's one win at one customer for one application — not a rout, but a directional crack.

**Hitachi High-Tech, Kokusai Electric** — Hitachi competes in select etch (~3–5% share); Kokusai is the batch-ALD specialist that benefits from GAA but in a different niche. Neither threatens Lam's franchise platforms.

**NAURA, AMEC, SiCarrier, Hwatsing (China domestic)** — NAURA has climbed to #5 globally (FY25 revenue ¥29.8B), passing several incumbents on Chinese tooling demand; AMEC is at 5nm-class etch.[35][36] These are real and growing, but the threat is mostly *to LRCX's China revenue line,* not to its leading-edge accounts. China share of Lam revenue is expected to drop below 30% in CY26 (from 43% in Q1 FY26) — partly export controls, partly indigenous substitution.[37][38]

**ASML, KLA** — Different layers (litho, metrology). Not direct competitors; mostly co-beneficiaries of WFE growth.

**Net competitive read:** Lam's franchise is durable on TSV etch, ALE, and Mo ALD. The exposed flank is HAR cryo etch in NAND. The China revenue line is structurally compressing and the domestic competitor set is climbing the curve faster than most US investors appreciate.

## Bull case — technical
The bull case rests on four technical conditions, not on multiple expansion:

1. **HBM stack height keeps climbing on cadence.** HBM4 12-Hi/16-Hi production volume ramps in CY26; HBM4E 16-Hi/20-Hi follows in CY27. Every additional die multiplies TSV intensity per wafer. Lam's Syndion + dielectric etch + Mo ALD chain captures most of this dollar growth.[20][39]
2. **3D NAND >200-layer conversion accelerates.** AI training and especially RAG/inference checkpointing pulls QLC SSD demand forward; the $40B conversion spend now happens by end-CY27 not later, and Lam Cryo 3.0 holds the *majority* (not all — see bear) of HAR etch share.[3][28]
3. **Mo ALD becomes the industry standard for wordline, bitline, and eventually logic via.** Because ALTUS Halo is the only Mo ALD production tool today and Lam already owns the wordline installed base, this is a *near-monopoly transition* if customers ramp on Lam's cadence.[18][19]
4. **GAA ramp at TSMC N2/Samsung SF2/Intel 18A drives etch intensity +25–30%.** Selis selective etch is the gating tool.[29][30]

**Financial connection:** Investor Day midpoint of $26B revenue, 50% GM, $6.50 EPS in CY28 implies ~14% revenue CAGR off CY24 base and ~18% EPS CAGR.[24] At spot, you are paying ~45× CY28 EPS now — high, but consistent if all four conditions hold AND multiple holds.

**Base rate on this kind of moat erosion:** WFE share has historically moved at 50–150 bps/year in normal cycles; the AMAT/LRCX/TEL/ASML/KLA oligopoly has been stable since the late-2010s consolidation. Moats in equipment break on *single-customer single-recipe wins, compounded over multiple node generations* — the Samsung V10 cryo win is the kind of event that can compound, but it took TEL roughly seven years of dedicated R&D to land. That is the correct base-rate framing: this is a 5–10-year share-shift dynamic, not a 12-month one.

## Bear case — technical
A real short-seller would write this:

1. **Cryo etch share loss is starting, not theoretical.** Samsung V10 (400L+) POR went to TEL.[16][17] Customers explicitly want dual-source on every critical step. If Lam loses any single recipe at SK Hynix HBM4 or Micron's QLC NAND in the next four quarters, the narrative breaks. Lam was *late* to cryogenic etch as a paradigm — TEL got there ~1.5 years earlier — and customer dual-sourcing pressure is structural in memory.[16]
2. **China revenue is a one-way ratchet down.** From ~43% in Q1 FY26 to <30% guided for CY26-exit, with a stated ~$600M CY26 revenue drag from new restrictions and ~$700M from the Dec-24 rules.[37][38] NAURA (#5 global) and AMEC are taking domestic share at the trailing edge. The China-revenue replacement assumption (US/Korean/Taiwanese customers absorb the lost dollars) only holds if global WFE actually scales to $140B+.
3. **Advanced packaging is *not* primarily a Lam franchise on the bonder side.** Besi owns hybrid bonding; AMAT and TEL are credibly competing. The "$3B in CY25 advanced packaging" number is dominated by TSV etch, dielectric dep, plating, and CMP — not the high-margin bonding step that captures most of CoWoS economics.[31][32]
4. **WFE estimate has run from $135B to $140B in one quarter — classic late-cycle.** Lam itself flagged the "trade ratio gets a little more challenging" between HBM3E and HBM4 — i.e., wafer demand per HBM bit doesn't scale as fast as the revenue narrative implies.[40] If hyperscaler capex digestion shows up in any single quarter and HBM customers push out a quarter of orders, the cyclical de-rating off ~43× forward is harsh.
5. **Valuation: forward multiples reflect zero cyclicality.** Lam trades at ~43× forward EPS, mid-teens EV/Sales — multiples consistent with a software franchise, not an equipment cyclical. Historical LRCX P/E mid-cycle is ~15–20×. The market is pricing this as a structurally re-rated franchise; if it's a cyclical, the down-move is 40%+ before the cycle narrative resets.

## Market view check
At $294 / ~43× forward EPS, ~13× NTM revenue, and only ~7% to consensus PT, the market is pricing LRCX **as if the SAM-to-high-30%-of-WFE expansion is fully real and durable** — i.e., as a franchise that captures a structurally larger share of a larger pie. That is consistent with the technical reality on Mo ALD, Syndion TSV, and Aether dry resist. It is **not** consistent with the Samsung V10 cryo loss being the start of a real share-shift, nor with China revenue compressing faster than the global WFE pool expands. The disagreement vs. consensus is: the market believes the moat is essentially intact and the cycle is structural; the technical evidence is that the moat is intact in 3 of 5 legs but actively contested in NAND HAR etch, and the cycle is real but maturing. At this multiple, you are not paid for that nuance.

## 90-day falsifiers
Specific, observable items in the next ~90 days:

- **June Q FY26 print and Sep Q guide.** Beat $6.6B / $1.65 EPS? Memory mix DRAM stays ≥27% and NAND ≥12%? China share drops below 30% as guided?[40][41]
- **TEL Q1 CY26 earnings (Aug 2026).** Does TEL disclose additional cryogenic etch POR wins beyond Samsung V10 — specifically at SK Hynix or Kioxia? Watch for "high-aspect-ratio etcher" order commentary.[17]
- **SK Hynix and Samsung HBM4 ramp commentary** (Q2 CY26 earnings). Does HBM4 enter qualification on schedule with 16-Hi by year-end? TSV intensity per wafer commentary.
- **TSMC CoWoS WPM disclosure** (July CY26 earnings). Does the 130k WPM end-26 target hold? Any pull-in to 2027 from CoWoS-L bonder/yield constraints?[26]
- **Naura / AMEC quarterly disclosures.** Any 5nm-class or HBM-relevant tool POR at a non-Chinese customer? (Unlikely, but watch for it.)
- **Aether dry resist scope expansion.** Does a *second* memory or logic customer announce POR in CY26?
- **Any new US export-control action** post US/China bilateral updates: a sudden $200M+ additional revenue cut would mark the China headwind escalating.

## What I could not verify
- Exact Lam vs. AMAT vs. TEL share within the **HBM TSV etch** sub-segment specifically (sources cited "double-digit order growth" at both but did not split share).[12]
- Lam's actual **dollar exposure to hybrid bonding** vs. the front-end etch/deposition pieces of advanced packaging — the $3B CY25 advanced-packaging number is a corporate aggregate, not a tool-mix breakdown.[20]
- The specific **NAND HAR etch share** TEL has won after the Samsung V10 POR — sources estimate TEL was at 10–15% but do not quantify the post-V10 number.[17]
- Whether **Aether dry resist** has a path beyond memory into logic without a structural ASML co-development; the Jan-25 POR announcement named a "leading memory manufacturer" without confirming logic adoption.[21]
- The forward P/E figure of "42.8×" vs "~28×" varied across sources; the 42–43× figure is consistent with FY26 EPS run-rate (~$5.65) and FY27 consensus, but I could not reconcile every aggregator.[6][7]
- Net cash / EV precisely — used estimated ~$20B net cash from 10-K; FY26 buybacks may have reduced this.

## Sources
[1] https://www.lamresearch.com/products/our-processes/etch/ — retrieved 2026-05-10 — Lam etch tool family (Vantex, Akara, Sense.i, Syndion).
[2] https://newsroom.lamresearch.com/inside-the-chip-advanced-packaging — retrieved 2026-05-10 — Lam advanced packaging overview, TSV/RDL/hybrid bonding role.
[3] https://newsroom.lamresearch.com/how-deposition-and-etch-are-reshaping-chips-for-the-ai-era — retrieved 2026-05-10 — Etch/dep intensity in 3D scaling.
[4] https://finance.yahoo.com/quote/LRCX/ — retrieved 2026-05-10 — Spot price $294.84, market cap, May 10 trading range.
[5] https://www.ytdreturn.com/lrcx/ — retrieved 2026-05-10 — YTD total return +116.40%, 52-week high $298.
[6] https://public.com/stocks/lrcx/forecast-price-target — retrieved 2026-05-10 — Forward P/E 42.8×, 43-analyst median PT $315 (range $220–$385).
[7] https://stockanalysis.com/stocks/lrcx/statistics/ — retrieved 2026-05-10 — TTM revenue $21.68B, margin profile.
[8] https://filecache.investorroom.com/mr5ir_lamresearch2/1435/Lam%20Research%202025%20Investor%20Day%20FINAL.pdf — retrieved 2026-05-10 — 2028 financial targets $25–27B / 50% GM / $6–7 EPS.
[9] https://www.marketbeat.com/stocks/NASDAQ/LRCX/forecast/ — retrieved 2026-05-10 — Analyst rating distribution 27 Buy / 7 Hold / 1 Sell.
[10] https://www.nasdaq.com/market-activity/stocks/lrcx/short-interest — retrieved 2026-05-10 — Short interest 27.97M shares, 2.24% of OS.
[11] https://www.deepresearchglobal.com/p/lam-research-swot-analysis-report — retrieved 2026-05-10 — ~45% etch share, $2.3B SK Hynix MOU Nov 2025.
[12] https://www.gminsights.com/industry-analysis/atomic-layer-etching-equipment-market — retrieved 2026-05-10 — Lam 60.9% of ALE in 2024; AMAT 29.5%, TEL 19.6%.
[13] https://www.prnewswire.com/news-releases/lam-research-unveils-industrys-most-advanced-conductor-etch-technology-to-date-302380153.html — retrieved 2026-05-10 — Akara extendible to 4F²/3D DRAM/CFET.
[14] https://www.prnewswire.com/news-releases/lam-research-introduces-lam-cryo-3-0-cryogenic-etch-technology-to-accelerate-scaling-of-3d-nand-for-the-ai-era-302211557.html — retrieved 2026-05-10 — Cryo 3.0 specs, <0.1% CD deviation, 10µm depth.
[15] https://electronics360.globalspec.com/article/21376/lam-provides-a-path-toward-1-000-layer-3d-nand-flash — retrieved 2026-05-10 — 1,000-layer NAND roadmap.
[16] https://www.yolegroup.com/industry-news/tokyo-electron-takes-aim-at-nand-etching-leader-lam-research/ — retrieved 2026-05-10 — TEL ~1.5 years ahead of Lam on cryo; customer dual-sourcing motive.
[17] https://x.com/Jukanlosreve/status/1893917099816587452 — retrieved 2026-05-10 — Samsung V10 (10th-gen NAND, 400L+) cryogenic etch POR to TEL.
[18] https://newsroom.lamresearch.com/2025-02-19-Lam-Research-Ushers-in-New-Era-of-Semiconductor-Metallization-with-ALTUS-R-Halo-for-Molybdenum-Atomic-Layer-Deposition — retrieved 2026-05-10 — ALTUS Halo Mo ALD; >50% resistance reduction, NAND wordline base.
[19] https://www.semiconductor-digest.com/molybdenum-the-metal-enabling-next-big-leap-in-chip-manufacturing-for-the-ai-era/ — retrieved 2026-05-10 — Mo transition rationale and process advantages.
[20] https://markets.financialcontent.com/stocks/article/finterra-2026-2-9-the-architecture-of-ai-a-deep-dive-into-lam-research-lrcx-and-the-advanced-packaging-revolution — retrieved 2026-05-10 — Syndion TSV gold-standard; advanced packaging revenue $1B → $3B → +50%.
[21] https://investor.lamresearch.com/2025-01-29-Breakthrough-EUV-Dry-Photoresist-Technology-from-Lam-Research-Adopted-by-Leading-Memory-Manufacturer — retrieved 2026-05-10 — Aether dry resist as production tool-of-record for leading-edge DRAM.
[22] https://www.imec-int.com/en/articles/lam-research-unveils-technology-breakthrough-for-euv-lithography — retrieved 2026-05-10 — Dry-resist ASML/imec co-development.
[23] https://newsletter.semianalysis.com/p/lam-research-lrcx-dry-deposit-and — retrieved 2026-05-10 — SemiAnalysis on dry resist as multi-billion opportunity (paywalled summary).
[24] https://x.com/TheAmericanCEO/status/1894133373943046243 — retrieved 2026-05-10 — Investor Day 2025: 2028 targets $25–27B / 50% GM / 34–35% OM / $6–7 EPS.
[25] https://seekingalpha.com/news/4475062-lam-research-projects-sam-expansion-to-midminus-30-percent-of-wfe-in-2025-as-advanced — retrieved 2026-05-10 — SAM expansion to mid-30s%, high-30s% long-term.
[26] https://www.digitimes.com/news/a20260410VL204/packaging-capacity-tsmc-nvidia-demand.html — retrieved 2026-05-10 — TSMC CoWoS 35k → 130k WPM trajectory, ~80% CAGR.
[27] https://www.astutegroup.com/news/industrial/advanced-packaging-demand-soars-nvidia-secures-60-of-cowos-capacity/ — retrieved 2026-05-10 — Nvidia ~60% of CoWoS, 510k CoWoS-L wafers 2026.
[28] https://www.stockinsights.ai/us/LRCX/earnings-transcript/fy26-q3-0bff — retrieved 2026-05-10 — $40B NAND conversion pulled forward to end-CY27.
[29] https://semianalysis.com/2023/10/15/going-vertical-gate-all-around-3d/ — retrieved 2026-05-10 — GAA etch intensity +25–30%, Kokusai/Lam roles.
[30] https://www.lamresearch.com/product/selective-etch-product-family/ — retrieved 2026-05-10 — Selis selective etch for SiGe channel release at GAA.
[31] https://www.itiger.com/news/1159006392 — retrieved 2026-05-10 — AMAT/LRCX competing for Besi-style hybrid bonding integration.
[32] https://economy.ac/news/2026/02/202602288324 — retrieved 2026-05-10 — Samsung Cheonan dedicated HBM4 hybrid bond line.
[33] https://semiengineering.com/hbm-options-increase-as-ai-demand-soars/ — retrieved 2026-05-10 — Sym3 Y / Flex order growth; HBM3E 12-Hi TSV scaling.
[34] https://newsletter.semianalysis.com/p/nand-flash-monopoly-broken-tokyo — retrieved 2026-05-10 — SemiAnalysis: >$1B NAND revenue in motion from TEL cryo/Mo.
[35] https://www.trendforce.com/news/2026/02/02/news-three-chinese-chip-toolmakers-reportedly-enter-global-top-20-as-naura-rises-to-fifth-by-sales/ — retrieved 2026-05-10 — NAURA #5 globally, AMEC #13.
[36] https://247wallst.com/technology-3/2026/05/01/chinas-semiconductor-equipment-companies-gain-share-despite-u-s-sanctions/ — retrieved 2026-05-10 — Chinese equipment makers gaining share despite controls.
[37] https://finance.yahoo.com/news/lrcxs-china-revenue-drop-below-132200026.html — retrieved 2026-05-10 — China expected <30% of LRCX revenue in 2026.
[38] https://finance.yahoo.com/markets/stocks/articles/lam-research-faces-china-curbs — retrieved 2026-05-10 — Hua Hong restrictions, $200M Q2 / $600M CY26 drag.
[39] https://www.nomadsemi.com/p/deep-dive-on-hbm — retrieved 2026-05-10 — HBM4/4E stack height roadmap and TSV intensity.
[40] https://finance.biggo.com/news/US_LRCX_2026-04-22 — retrieved 2026-05-10 — Q3 FY26: $5.84B rev, 49.9% GM, $1.47 EPS; WFE raised to $140B.
[41] https://www.prnewswire.com/news-releases/lam-research-corporation-reports-financial-results-for-the-quarter-ended-march-29-2026-302750629.html — retrieved 2026-05-10 — Official Q3 FY26 results, June Q guidance $6.6B ± $400M.