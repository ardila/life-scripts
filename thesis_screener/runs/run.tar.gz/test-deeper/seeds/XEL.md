I have sufficient research. Now writing the dossier.

# XEL — Xcel Energy Inc.

## Where this sits in the AI stack
XEL is **not** an AI infrastructure vendor in any conventional sense — it is a regulated electric and gas utility holding company (NSP-Minnesota, NSP-Wisconsin, PSCo Colorado, SPS Texas/New Mexico) whose physical product is megawatt-hours and firm capacity delivered through its own generation, high-voltage transmission, and distribution assets. Within the AI stack it sits **upstream of the rack** at the lowest physical layer — primary energy and grid interconnection — across two of the most desirable U.S. data-center geographies for new builds (Twin Cities / Becker MN; Front Range CO; Texas Panhandle near Amarillo). For frontier AI buildouts, where the gating constraint is no longer GPUs but power delivery in the 2027–2030 window, XEL's relevant unit of inventory is **interconnection rights + firm 24/7 capacity inside its franchised service territory** [2][3][7].

## Snapshot
- **Price:** $79.39 (2026-05-08 close; 2026-05-10 is a Sunday) [1]
- **Market cap:** $49.56B (624.3M shares outstanding) [1][14]
- **52-week range:** $65.21 – $84.23 [1]
- **Forward P/E:** 18.7× (on FY2026 mid-guide EPS $4.10; consensus $4.16) [4][12]
- **EV / NTM revenue:** ~5.2× (inferred: ~$81B EV against ~$15.5B NTM revenue; ~$32B long-term debt estimate) — flag as inference, utilities are not typically valued on this multiple [12][13]
- **Consensus 12-month price target:** $90 (median, 27 analysts), implied +13% [4]
- **YTD total return:** ~+10–13% estimated; could not verify cleanly. Stock printed 52-week high $84.23 in Feb 2026 [11], dividend hike to $2.37 annualized [5]
- **Short interest (% of float):** 0.87% (4.79M shares short) — well below the 2.5% utility peer average [14]
- **Dividend yield:** ~2.99% (forward $2.37/sh) [5][12]

## Moat — what it is physically made of
The moat is **not technological** and it is critical to be honest about that. A regulated utility's moat is a stack of legal, physical and regulatory rights that are extremely costly to replicate but conceptually simple:

1. **State-granted exclusive franchise** to serve retail electric load in defined service territories — this is a statutory monopoly, not a competitive product win. In MN, CO, and the SPS footprint, no one else can lawfully sell delivered electrons to a 100MW data-center load behind a meter on XEL's wires without going behind-the-meter (constrained by FERC, see below).
2. **Physical right-of-way**: existing 345kV / 230kV transmission corridors and substation real estate that took 30+ years and exercise of eminent domain to assemble. New corridors face 8–12 year siting/permit horizons in MN and CO. The Joint Targeted Interconnection Queue (JTIQ) MISO-SPP project at the MN/ND seam is co-developed with XEL and ITC and unlocks ~30 GW of new generation transfer — XEL owns the franchise side of that buildout [9].
3. **Long-lived rate-based capital**: $56B rate base in 2025 → projected $94B by 2030 (~11% CAGR) backed by a $60B 2026-2030 capex plan [10][3]. Every dollar of "used and useful" capex earns an allowed return on equity (9.8% in CO/WI most recent decisions, 10.3% requested MN) [10] — the more grid the AI buildout demands, the larger the asset base earning regulated returns. This is a *positive-convexity* moat: external demand stress makes the moat bigger, not smaller.
4. **Generation in place / extension rights**: Monticello and Prairie Island nuclear extended into the 2040s/2050s — these are 24/7 carbon-free baseload assets that hyperscalers with clean-power PPAs prize and cannot replicate [8]. Coal-to-data-center site reuse at Sherco (Becker, MN) inherits permitted transmission, water rights, and substation footprint that took decades to build [6].
5. **Tariff design control**: The large-load tariff XEL filed April 2, 2026 with the Colorado PUC — 15-year contracts, 80% minimum-take, exit fee = sum of all remaining minimum bills, developer-funded transmission and generation — converts hyperscaler load into something close to a **take-or-pay infrastructure cash flow** [2][7]. Similar filings planned in TX, NM, WI [2].

What is **not** moat: brand, technology, operational efficiency. XEL is broadly comparable to NextEra, Dominion, Constellation operationally; what differs is service-territory geography (proximity to wind resource and to where hyperscalers want to site) and regulatory relationships.

**Durability assessment:** the franchise and ROW components are very durable (decade-plus, requires statutory change to erode). The tariff-design component is the most fragile and the most contested — see Bear case.

## AI buildout bottleneck map
The actual binding constraints on U.S. AI buildout over 24 months, ranked roughly by tightness, with XEL's position on each:

| Bottleneck | Tightness | XEL position |
|---|---|---|
| **Grid interconnect timeline** | Severe — PJM reformed cycle, GIA processing 1-2 years, MISO 2023 cycle completing in 2026, ERCOT tracking 205GW of large-load requests [15][20] | **Beneficiary / gatekeeper.** XEL controls interconnect approval inside its retail footprint |
| **Gas turbine slots** | Severe — GE Vernova backlog 80GW stretching into 2029; expected 110GW total backlog by YE2026; aero "bridge" units scarce [17] | **Exposed customer.** XEL needs ~3GW of new gas in its plan; gas slots compete with hyperscaler self-build |
| **Long-lead transformers / HV switchgear** | Severe — 2-3 year lead times | Exposed; same procurement queue |
| **Transmission corridor permitting** | Severe (8-12 yr greenfield) | **Beneficiary** — existing ROW + state policy support (CO SB25-280, MN tariffs) |
| **Generation queue (wind/solar/storage)** | Moderate — MISO queues elongated but products available | XEL is one of largest U.S. wind operators (10GW+) [8] |
| **Skilled electrical labor / linemen** | Tight regionally | Exposed but advantaged via legacy workforce |
| **GPUs, CoWoS-L, HBM** | Not XEL's problem | Indifferent |
| **Cooling at >100kW/rack** | Tight | Indifferent — sells the upstream electricity |
| **Wildfire mitigation capex** | Cost driver | Exposed — $5B of $60B plan is wildfire hardening [3] |

The structural insight: **XEL benefits asymmetrically when the upstream constraint moves from "we can ship more GPUs" to "we have nowhere to plug them in."** That transition arguably completed in 2024-25. The Q1 2026 print of 4GW contracted by YE27 and $6-8B incremental data-center capex framework [3] is the financial manifestation of that.

## Competitive teardown
Competition for AI-driven utility upside is not within XEL — it is across **alternative routes to power** that bypass franchised utility delivery:

**1. Behind-the-meter co-location at existing power plants.** The Talen-AWS Susquehanna 1,920MW BTM deal was rejected by FERC 2-1 in November 2024 and the rehearing was denied; Talen restructured to a **front-of-the-meter retail** structure in June 2025 [18]. FERC's December 2025 order to PJM directs creation of three colocation transmission products (firm/non-firm/interim) effective January 2026 [18]. **Read:** the cleanest BTM bypass path has been narrowed — colocated loads will pay grid charges. This is materially favorable to XEL's tariff thesis. Status on this axis: **XEL ahead on regulatory durability**.

**2. ERCOT direct interconnect / "bring-your-own-power" (BYOP).** Texas allows much faster siting (months vs. years) and direct merchant generation siting. Stargate Abilene (4.5GW, OpenAI/Oracle/SoftBank target YE2026) and Fermi/Texas Tech Advanced Energy and Intelligence Campus (11GW, Amarillo) are both **inside or adjacent to XEL's SPS footprint** but use behind-the-meter and merchant gas to bypass utility tariff [16]. **This is the real competitive frontier.** Status: **XEL behind on Texas-style speed**, partially offset because SPS still owns the transmission backbone and large-load tariff filings are planned in TX [2].

**3. SMR / on-site nuclear (NuScale, X-Energy, Oklo).** Multi-year timeline (mid-2030s at earliest for commercial deployment at scale). Not a 2026-2028 competitive threat — but it is the existential 2030s scenario. NuScale CEO publicly downplayed the Talen-Amazon FERC decision impact on their pipeline [18]. Status: **distant competitive threat, near-term irrelevant**.

**4. Adjacent utilities competing for siting.** Alliant (WI Meta deal), Dominion (VA), Entergy (LA/MS Meta Richland Parish), AEP (OH), Constellation (Three Mile Island). These are not "competitors" in the share-loss sense — site selection is what is contested. XEL's MN/CO advantage is cool climate + cheap wind + nuclear-eligible carbon-free 24/7 power. Status: **mid-tier site mix** — better than Texas on power cost-stability, worse than VA on existing data-center cluster gravity.

**5. The Google deal as template.** February 2026 Google/Pine Island MN: 1.9GW of *new* renewables (1,400MW wind, 200MW solar, 300MW/30GWh Form Energy iron-air storage) plus Google paying all infrastructure costs and $50M into Capacity*Connect [19]. XEL CEO Frenzel publicly framed this as the **template for large-load tariff** [2]. Read: XEL is selling a productized regulated-tariff structure, not just electrons.

## Bull case — technical
Technical conditions required:
1. **AI capex super-cycle persists into 2028+ with power as the binding constraint** (not GPU availability). This requires hyperscaler capex commentary to keep ratcheting up — Microsoft, Google, Meta, Amazon are all still in "build first, optimize later" mode through 2026.
2. **FERC/state regulators continue to disfavor pure BTM colocation** and require front-of-the-meter retail structures with grid charges — the December 2025 FERC PJM order is directly on this trajectory [18].
3. **Gas turbine slot scarcity continues** (GE Vernova sold out into 2030 by YE26 per management) [17], forcing hyperscalers to depend on utilities with existing fleet and existing slot allocation.
4. **XEL converts the 3GW contracted YE2026 → 6GW YE2027 pipeline into rate-based capex on schedule**, with Colorado PUC approving the April 2026 large-load tariff structure substantively intact [2][7].
5. **No second Marshall Fire-class event.** The $640M settlement (of which $350M was insurance-funded) is digested; wildfire mitigation capex ($5B of $60B plan) is value-accretive, not destructive [21][3].

Financial outcome: rate base CAGR ~11% supports ~9% EPS growth (already implied by management long-term 6-8%+ guide with admitted upside from data centers) [10]. At 18.7× forward P/E, a 9% EPS CAGR with stable multiple delivers ~12% total return with dividend. Multiple expansion to ~20-22× (precedent: NEE peak) on credible data-center "growth-utility" rerating delivers another 7-15% one-time.

**Base rate on technology displacement at this stage:** regulated electric utilities have been displaced by behind-the-meter / off-grid generation in fewer than 5% of historical analogous load-growth periods in the past 50 years. The structural barrier — local franchise + transmission ownership + long-term contract enforceability — has not historically eroded inside a decade. The closest analog is the 1980s industrial cogeneration wave under PURPA, which did not meaningfully erode integrated-utility share of large-load.

## Bear case — technical
A short-seller who understands the stack writes this:

1. **The "AI utility rerating" is procyclical and reverses.** XEL traded at ~15× forward P/E for most of the 2018-2023 era. The current 18.7× embeds an AI growth premium. If hyperscaler capex disappoints — most likely catalyst: a sequential Q3 2026 capex guide-down by >10% from any of MSFT/GOOG/META/AMZN — the multiple compresses back to the high-15s, a ~15% drawdown before any earnings effect. Utilities are negatively convex on multiple compression because they have nowhere to grow into.
2. **The Sherco / coal retirement timing mismatch.** Sherco 1 retires 2026, Sherco 3 in 2030, Allen S. King in 2028 [8]. Net thermal capacity is going *down* through the late 2020s while contracted data-center load is going up. The new build is gas + wind + storage. If new gas turbine deliveries slip (real risk given GE Vernova / Siemens backlog into 2029-2030 [17]) and Form Energy iron-air or similar long-duration storage misses commercial cost targets, **XEL ends up either short on firm capacity or forced to pay merchant peak prices to serve hyperscaler take-or-pay loads it cannot exit.** This is asymmetric downside.
3. **Texas Panhandle (SPS) loses to ERCOT-direct merchants.** Fermi Advanced Energy Campus (11GW), Stargate Abilene, and similar sites are increasingly using BTM gas + merchant solar arrangements to bypass utility tariff entirely [16]. SPS is the smallest XEL operating company but the Texas large-load tariff filing has the highest political risk. If TX regulators reject Xcel's filing while approving competing direct-interconnect routes, the bull thesis loses a leg.
4. **Wildfire tail risk under climate change.** Marshall Fire ($640M; $290M out-of-pocket after insurance) is precedent that catastrophic wildfire liability lands on the utility even when the company maintains it "did not spark" the fire [21]. Front Range CO grass-fire exposure is structural and growing. PG&E's $30B reorganization is a base rate that the market sometimes forgets utility tails are open-ended.
5. **The Colorado PUC's 6GW cap on approved data-center capacity** [22 — included in CO Sun coverage of August 2025] signals **active regulatory skepticism** about overbuild. If data-center demand softens and stranded capacity emerges, the minimum-bill protection in the tariff faces legal/political challenge from residential ratepayer coalitions — exactly the "Big Tech subsidized by grandma" framing that has dogged Virginia.
6. **FERC could reverse course on colocation.** The December 2025 PJM order is not statutorily entrenched; a future Commission could re-open the BTM path. If hyperscalers get even partial BTM bypass at scale, the 80% minimum-take economics of XEL's large-load tariff become much less defensible.

The bear case is **not** "AI is a bubble." It is "XEL is a regulated utility being priced as a growth utility on technology demand it does not control and on regulatory protection that is one Commission vote away."

## Market view check
At $79.39 / 18.7× FY26 EPS, XEL trades roughly 1-2 turns above its 5-year average and ~3-4 turns above the regulated-utility long-run average of ~15×. Consensus PT of $90 implies the Street sees ~13% upside, consistent with the data-center growth narrative being broadly priced in. The market view appears to be: **9% EPS CAGR is durable, 11% rate-base CAGR is committed, large-load tariffs will pass substantively intact.** This is consistent with the technical bull case in this dossier. The market is **not** pricing a wildfire tail or a meaningful BTM regulatory reversal. If the technical thesis is right, the stock is fairly valued to mildly cheap and the alpha is in the *duration* (does the 9% growth extend to 2030+ as data center buildout matures, or does it normalize to 6% by 2028?). If the bear thesis is right on either the tariff fragility or wildfire axes, the stock is 15-25% overvalued.

## 90-day falsifiers
- **Colorado PUC ruling on April 2 large-load tariff filing** (proceeding 24A-0442E follow-on) — expect intervenor testimony June-July 2026. If minimum-take percentage is reduced below 70% or contract term shortened below 12 years, that is a material negative [2][7].
- **Q2 2026 earnings (mid-July)** — watch for: (a) reaffirmation of 4GW YE2027 contracted target, (b) update on the additional ~1GW expected to be contracted in 2026, (c) any incremental capex framework above $60B for 2026-2030.
- **Texas large-load tariff filing** announced for "coming months" — actual filing date and proposed structure [2].
- **Hyperscaler Q2 2026 capex commentary** (late July/early August) — if any of MSFT/GOOG/META/AMZN guides Q3 capex down sequentially >10%, the AI-utility multiple compresses immediately.
- **Sherco 1 retirement execution** (scheduled 2026) — if delayed, suggests firm capacity tightness; if on schedule, watch reserve margin commentary.
- **GE Vernova Q2 2026 update on 2027-2030 turbine slot allocation** — XEL doesn't disclose its specific slot dates, but tightening supply is a positive read-through to XEL pricing power on tariff design.
- **FERC enforcement / DC Circuit ruling on PJM colocation compliance** — any reversal of the December 2025 framework is a meaningful negative.
- **Wildfire ignition events in Front Range CO, Texas Panhandle** in Q2-Q3 2026 dry season.

## What I could not verify
- **Total long-term debt and exact enterprise value as of Q1 2026** — only retrieved Q1 2026 capex flows and the 60/40 debt/equity funding plan; the ~$32B LT debt figure is an estimate from prior filings extrapolated and the EV/revenue is inference. A primary-source 10-Q read is needed [13].
- **Precise YTD 2026 total return** — estimated 10-13% based on 52-week range, ATH February 2026, and current price [11], but I did not retrieve a clean 2025-12-31 closing print.
- **XEL's specific gas turbine slot positions with GE Vernova / Siemens / MHI** — companies do not disclose this; the inference that XEL is reasonably positioned versus a hyperscaler self-build comes from XEL's incumbency and existing maintenance relationships, not a specific slot count.
- **The exact percent of CO PUC-approved 6GW data-center capacity that has firm offtake versus letters of intent** — public reporting is ambiguous; the 4GW YE2027 figure is XEL management's commercial pipeline, not a regulator-approved committed-capacity figure.
- **MISO interconnect-queue position** of specific XEL-served generation supporting the data-center contracts — would require parsing the MISO queue at the project level.
- **Whether the Google/Pine Island 1.9GW package economics actually save customers $1-1.5B as XEL claims** [3] — this depends on counterfactual modeling I could not independently verify.
- **Specific take-rate sensitivity on the 80% minimum bill** — i.e., the actual probability-weighted exit fee economics if a hyperscaler walks at year 7 of a 15-year contract.

## Sources
[1] https://finance.yahoo.com/quote/XEL/ — retrieved 2026-05-10 — current price $79.39, market cap $49.56B, 52-week range, May 8 close.
[2] https://www.utilitydive.com/news/xcel-energy-pursuing-large-load-tariffs-in-4-states-amid-data-center-growth/811518/ — retrieved 2026-05-10 — XEL pursuing CO/TX/NM/WI large-load tariffs; 2GW+ contracted in queue; 6GW YE2027 target.
[3] https://www.investing.com/news/company-news/xcel-energy-q1-2026-slides-60b-capital-plan-data-center-growth-drive-outlook-93CH-4650612 — retrieved 2026-05-10 — Q1 2026 slides: $60B 2026-2030 capex, $6-8B incremental data-center framework, Google deal $1-1.5B customer savings claim.
[4] https://public.com/stocks/xel/forecast-price-target — retrieved 2026-05-10 — 27 analysts, $90 median PT, $73-$95 range; FY26 EPS $4.04-4.16.
[5] https://investors.xcelenergy.com/news-events/news-releases/news-details/2026/Xcel-Energy-Inc--Board-Increases-2026-Common-Dividend-Declares-Dividend-on-Common-Stock/default.aspx — retrieved 2026-05-10 — dividend hike to $2.37 annualized (4% increase), 23 consecutive years of increases.
[6] https://www.startribune.com/amazon-data-center-xcel-sherco-becker-minnesota/601180310 — retrieved 2026-05-10 — Sherco / Becker MN coal site reuse for hyperscaler data centers, Amazon $73.6M land purchase, Microsoft 295-acre purchase.
[7] https://coloradosun.com/2026/04/02/data-centers-xcel-energy-colorado-rate-tariff-consumers/ — retrieved 2026-05-10 — Colorado large-load tariff filed April 2 2026: 15-year contract, 80% minimum bill, exit fee = remaining minimum bills, 50MW+ threshold.
[8] https://www.startribune.com/state-regulators-ok-xcel-plan-that-shifts-from-coal-to-more-renewable-nuclear-energy/600144545 — retrieved 2026-05-10 — coal retirement schedule (Sherco 1 2026, King 2028, Sherco 3 2030), Monticello/Prairie Island nuclear extension, 10GW+ wind portfolio.
[9] https://newsroom.xcelenergy.com/news/xcel-energy-projects-among-464-million-department-of-energy-grant-to-expand-tran-MCJ5DSXIEGLNBCZM5NJZ7XQETGYQ — retrieved 2026-05-10 — JTIQ MISO-SPP transmission project unlocking ~30GW transfer capacity at MN/ND seam, DOE $464M grant.
[10] https://www.investing.com/news/company-news/xcel-energy-q3-2025-slides-60b-capital-plan-to-drive-11-rate-base-growth-93CH-4321125 — retrieved 2026-05-10 — rate base $56B → $94B 2025-2030, 11% CAGR; ROE 9.8% in CO/WI, 10.3% requested MN; 6-8%+ long-term EPS guide.
[11] https://www.themarketsdaily.com/2026/02/25/xcel-energy-nasdaqxel-reaches-new-52-week-high-heres-why.html — retrieved 2026-05-10 — XEL all-time high February 2026 at ~$84.23.
[12] https://stockanalysis.com/stocks/xel/ — retrieved 2026-05-10 — forward P/E 18.65×, dividend yield 2.99%.
[13] https://www.businesswire.com/news/home/20260205283532/en/Xcel-Energy-2025-Year-End-Earnings-Report — retrieved 2026-05-10 — 2025 revenue $14.67B (+9.14%), 2025 ongoing EPS $3.80, capex funding 60% debt / 40% equity.
[14] https://www.benzinga.com/insights/short-sellers/25/05/45523637/looking-into-xcel-energys-recent-short-interest — retrieved 2026-05-10 — short interest 4.79M shares (0.87% of float), 1.26 days to cover, peer average 2.50%.
[15] https://www.zeroemissiongrid.com/insights-press-zeg-blog/pjm-2026-cycle/ — retrieved 2026-05-10 — PJM reformed interconnection cycle, GIA 1-2 year processing, transition queue ~63GW.
[16] https://siteselection.com/texas-connections/ — retrieved 2026-05-10 — Fermi 11GW Texas Panhandle data center, Stargate Abilene 4.5GW, ERCOT 205GW large-load interconnect requests.
[17] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — GE Vernova 80GW backlog stretching into 2029, 110GW expected YE2026, 20GW annualized output Q3 2026; data centers $2.4B Q1 2026 orders.
[18] https://www.datacenterfrontier.com/energy/article/55264293/talen-energy-continues-behind-the-meter-power-fight-for-aws-data-center-campus — retrieved 2026-05-10 — Talen-AWS Susquehanna BTM FERC rejection upheld, restructured to front-of-the-meter PPA June 2025; FERC December 2025 PJM colocation order.
[19] https://newsroom.xcelenergy.com/news/xcel-energy-to-power-new-google-data-center-in-minnesota — retrieved 2026-05-10 — Google Pine Island data center; 1,400MW wind + 200MW solar + 300MW/30GWh Form Energy iron-air storage; $50M Capacity*Connect; Google pays all infrastructure costs.
[20] https://www.texastribune.org/2026/01/19/ercot-texas-data-centers-electricty-demand/ — retrieved 2026-05-10 — ERCOT 205GW of large-load interconnect requests, 70%+ from data centers.
[21] https://www.cpr.org/2026/01/13/marshall-fire-trail-claims-excel-boulder/ — retrieved 2026-05-10 — Marshall Fire $640M settlement (~$350M insurance-funded), 4,000 plaintiffs, January 2026 hearing status.
[22] https://coloradosun.com/2025/08/18/colorado-xcel-data-center-demand-spending/ — retrieved 2026-05-10 — Colorado PUC approved 6GW new capacity for data centers, $22B grid upgrade plan; regulator concern about overbuild risk.