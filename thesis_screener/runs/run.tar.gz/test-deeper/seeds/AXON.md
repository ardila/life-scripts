# AXON — NVIDIA Corporation (NVDA)

## Where this sits in the AI stack

NVIDIA sits at the convergence point of silicon, system, and software for AI training and inference at frontier scale. Physically it sells: (1) GPU dies on TSMC leading-edge nodes packaged on CoWoS-L (Blackwell B200/B300, Rubin VR200, the disaggregated Rubin CPX); (2) full rack-scale systems with copper NVLink scale-up fabric (GB200/GB300 NVL72, Rubin Kyber NVL144/NVL576); (3) Ethernet (Spectrum-X) and InfiniBand (Quantum-X) scale-out networking on its own SerDes; (4) the CUDA stack — driver, libraries (cuDNN, cuBLAS, CUTLASS, NCCL, NVSHMEM), compilers (Triton, TensorRT, TensorRT-LLM), and the Dynamo inference orchestration layer. The unit of sale is no longer "a GPU"; it is an AI factory whose smallest meaningful SKU is a rack.

## Snapshot

- **Price:** $215.02 (2026-05-08 close) [1]
- **Market cap:** $5.23T (24.30B shares out) [1]
- **52-week range:** $120.28 – $217.80 [21]
- **Forward P/E:** 26.0× on FY27E EPS ~$8.34 (trailing P/E 43.7×) [1]
- **EV / NTM revenue:** ~14–15× (EV ≈ $5.18T on FY27E revenue $337–370B consensus range) [22]
- **Consensus 12-month price target:** ~$274 (n=42 analysts, implied +27%) [18]
- **YTD total return:** ~+8% to +15% (data sources diverge; flagged in *What I could not verify*) [20]
- **Short interest (% of float):** 1.17% (283M shares; 1.96 days to cover) [20]

## Moat — what it is physically made of

Decomposing into components and rating durability:

**Scale-up fabric (NVLink + NVSwitch).** The hardest piece to replicate. NVLink 5 at 1.8 TB/s per GPU plus the NVL72 copper backplane gives 72 Blackwells one coherent memory domain; Rubin's Kyber rack scales this to NVL144 / NVL576 with NVLink 6 at ~3.6 TB/s aggregate per link [9]. AMD's Helios rack with MI400 is the first credible answer and ships H2 2026 — roughly one generation behind. Reaching parity is a multi-year SerDes + switch ASIC + signal-integrity problem, not a software port. **Durable through Rubin (≥18 months).**

**CUDA software stack.** Not one thing. Depth lives in cuDNN's hand-tuned attention/conv kernels, NCCL's topology-aware all-reduce, CUTLASS as a fork target for frontier-lab kernel engineers, TensorRT-LLM quantization paths, and Dynamo's KV-aware routing for disaggregated inference [14]. ROCm is now PyTorch first-class and the per-workload gap has narrowed to 10–30% on commodity inference [10] — but new techniques (FP4 training, long-context prefill, custom attention variants) still land on CUDA 6–12 months earlier. **Eroding at the inference commodity layer; durable at the frontier-training layer.**

**Advanced-packaging supply lock.** NVIDIA has booked ~60% of TSMC's 2026 CoWoS-L capacity (~510K wafers of a ~150K wafer/month target run-rate) [4]. This is not switching cost — it is *physical optionality*: whatever CoWoS-L expands by, NVIDIA gets ~60% of the expansion. **Durable through 2027** because CoWoS-L fab build-out has 18–24 month lead times.

**HBM supply position.** SK Hynix carries >50% of NVIDIA's 2026 HBM; Samsung negotiated >30% on HBM4; Micron ramping to 15K wafers/month dedicated by end-2026 [5]. The three-supplier policy keeps each vendor competing on yield/price. The 16-Hi HBM4 ramp targeted for Q4 2026 is the next yield cliff [5]. **Durable but not exclusive** — the same memory ships to MI400, TPU v7, Trainium 3.

**Networking (Spectrum-X / Quantum-X).** Often missed by the equity narrative. Spectrum-X exited FY26 at >$10B annualized run-rate [17]; this is the scale-out leg that the GPU pulls into the BOM. Margins not separately disclosed; believed accretive. **Durable** because it is co-designed with NCCL.

**Developer ecosystem.** The "~4M CUDA developers" figure is stale and unreproducible at audit, but the operational fact is sharper: every major training framework lands CUDA support first; *time-to-first-flop* on a new architecture is measurably longer on AMD. The long-run threat is PyTorch's Inductor / Triton abstractions actively decoupling the user from CUDA. **Slowly eroding.**

What is *not* the moat: brand, founder mystique, or aggregate capex. The moat is fabric + packaging allocation + software, in that order.

## AI buildout bottleneck map

Binding constraints over the next 24 months, ordered by tightness:

1. **Power generation and grid interconnect.** ~2,300 GW stuck in U.S. interconnect queues; 7-year wait in Columbus, OH; GE Vernova and Mitsubishi gas turbines sold through 2028; only 5 GW of 12 GW announced 2026 U.S. capacity is actually under construction [11]. **NVIDIA: exposed customer, not constraint owner.** NVIDIA can ship faster than customers can energize — which paradoxically hardens long-dated commitments (e.g., $725B 2026 hyperscaler capex aggregate [6]).
2. **CoWoS-L advanced packaging.** Oversubscribed through 2026 [4]. **NVIDIA: dominant beneficiary** at ~60% share; risk is to competitors, not to NVIDIA.
3. **HBM4 yield, especially 16-Hi stacks (Q4 2026).** **Beneficiary** of multi-source competition but exposed if SK Hynix slips on Rubin Ultra 16-Hi quals [5].
4. **Liquid cooling at >100 kW/rack.** GB300 already at ~100 kW/rack; Rubin Kyber roadmaps 600 kW/rack by 2027 [9][16]. **Indirect beneficiary** — Vertiv/nVent/Delta capture the cooling revenue, but Rubin Kyber deployment pacing depends on DLC supply.
5. **Optical interconnect / co-packaged optics.** Pulled by Quantum-X / Spectrum-X switch upgrades. **Beneficiary.**
6. **Frontier data + kernel-engineering talent.** Soft constraints that gate the labs, not the silicon vendor. **Indifferent.**

The asymmetry: NVIDIA benefits from constraints #2 and #3 (own moat reinforces), is long #4 and #5, and is exposed only to #1 — which is the binding constraint that paradoxically locks in long-dated backlog because customers pre-buy compute they can't yet plug in.

## Competitive teardown

**AMD (MI400 series, Helios rack, H2 2026).** Genuine single-node hardware competitiveness: 432 GB HBM4 at 19.6 TB/s on MI455X versus Blackwell Ultra's 288 GB HBM3e at 8 TB/s — a single MI455X can hold a 216B-param model at FP16 without GPU partitioning [3]. The gap is on (a) ecosystem maturity: in MLPerf Inference v6.0 (April 2026), AMD did *not* submit DeepSeek-R1 or multimodal Qwen3-VL; NVIDIA submitted a 288-GPU four-rack GB300 NVL72 cluster over Quantum-X800 at ~2.49M tokens/s on DeepSeek-R1 [3a]; (b) multi-rack scale-up, which AMD has not demonstrated. Realistic 2026 share take: high single-digits in inference, low single-digits in frontier training.

**Google TPU v7 (Ironwood).** GA April 2026 [7]. SemiAnalysis labels it the "900-lb gorilla." Anthropic committed up to 1M TPU chips and >1 GW capacity (phase one: 400K Ironwood) [7]. Google projects 4.3M shipments in 2026, 10M in 2027 [7]. The threat is qualitative: Anthropic running production frontier workloads on non-NVIDIA silicon falsifies "frontier training needs CUDA." This is the most credible existential threat in 2026.

**Amazon Trainium 2+3 (Project Rainier).** $100B Anthropic-AWS commitment, up to 5 GW capacity, mixed T2/T3 deployment; Rainier already at ~500K Trainium2 [8]. Less software-mature than TPU; wins on TCO and AWS-native customer proximity.

**Broadcom XPU (Google TPU partner, Meta MTIA, OpenAI 10 GW, ByteDance).** AI revenue $8.4B in Q1 FY26, guided $10.7B Q2 — versus NVIDIA's $62B *quarterly* data-center alone [12]. The strategic edge is the *dual-vendor dynamic*: OpenAI committed to both 10 GW of Vera Rubin systems with NVIDIA (up to $100B partnership, first GW H2 2026 [13]) *and* 10 GW of Broadcom co-developed XPUs starting H2 2026 [12]. Hyperscalers aren't displacing NVIDIA — they are running a parallel custom stack to claw margin on workloads they understand best (own-model inference). NVIDIA's structural answer is Rubin CPX [14]: a GDDR7-based prefill-phase chip that disaggregates from HBM-rich decode GPUs and prices to undercut a custom ASIC at its strongest claim.

Honest read: NVIDIA has not been displaced on any axis in 2026. Share has compressed from ~90% to ~86% of data-center accelerator revenue [10]. The compression is real; structural displacement is not yet visible.

## Bull case — technical

For the stock to compound from $215, this needs to hold: (i) Rubin VR200 ships H2 2026 on schedule with Kyber NVL144, capturing the OpenAI Stargate first-gigawatt and Anthropic-Google overflow [9][13]; (ii) CoWoS-L allocation share holds ≥55% through 2027 — this alone constrains competitor unit volume regardless of demand strength [4]; (iii) Rubin CPX disaggregated inference [14] becomes the default architecture for long-context workloads, foreclosing the cleanest custom-ASIC value claim (cheap prefill); (iv) the 700+ GW of stalled grid interconnect [11] energizes slowly enough that hyperscaler capex commitments harden into purchase orders rather than trim. **Base rate:** platform incumbents at >80% share with deep software ecosystems (x86 server 2005–2017, iOS App Store 2010–) historically lose share at 1–3 pts/year for many years before "displacement" appears in revenue. NVIDIA is two years into that decay curve. Financial outcome: ~$370B FY27 revenue × 75% GM with continued buyback supports forward EPS to ~$10–11; at a 25× multiple that yields ~$250–275, which is approximately the current consensus PT.

## Bear case — technical

Not "AI bubble pops." The bear case worth writing: **the moat is in the fabric, and the fabric is being routed around.** Specifically: (i) ROCm + PyTorch Inductor + Triton make AMD GPUs drop-in for >70% of inference workloads by mid-2026; an MI455X serves a 200B model from one chip [3], undercutting GB300 economics for dense-MoE inference. (ii) Hyperscaler XPUs (TPU v7 at 4.3M units [7], Trainium 3 absorbing $100B Anthropic spend [8], Broadcom-Meta MTIA, Broadcom-OpenAI 10 GW [12]) absorb the *next* gigawatts of inference rather than NVIDIA. (iii) The Vera Rubin Kyber 600 kW/rack target [9] collides with grid-interconnect queues [11]; the physical buildout throttles NVIDIA's ability to convert backlog to revenue, while lower-TDP XPUs become preferable on inference-per-watt economics. (iv) Margin compression from HBM/CoWoS pricing — Microsoft attributed $25B of 2026 capex to memory/component inflation [6]; if 16-Hi HBM4 yields underperform, NVIDIA's recovery to 75.0% GM [19] partially reverses, breaking 73% and triggering multiple compression. Reasonable short target: $150–170, not $50 — even the bear case has FY27 revenue growing.

## Market view check

At $215 / $5.23T, NVIDIA trades ~14–15× EV/NTM revenue and 26× forward EPS [1][22] — for a business growing 60–75% at 50% net margins. The multiple is not speculative; it implies the market believes FY27 numbers and that FY28 grows further. Consensus PT $274 (+27% [18]) reads as: sell-side positioned for Rubin to ramp cleanly and packaging allocation to hold. What the market is *not* pricing: the share-compression curve from 86% toward ~75–80% that custom ASICs imply over 2026–2028, *and* the optionality value of being the bottleneck downstream of the binding constraint (power) that the company itself doesn't own. Net: price ≈ technical reality, slightly tilted bullish. Mispricing lives in the *tails*, not the median — both upside if Rubin CPX wins the inference architecture battle, and downside if HBM4 16-Hi yield slips or NVLink generational execution stumbles.

## 90-day falsifiers

- **Q1 FY27 earnings (May 28, 2026):** guide $78B [2]. A Q2 FY27 guide below $85B is deceleration beyond what's priced. GM print <74% pre-Rubin is a yield/cost flag [19].
- **Computex (early June 2026):** Rubin VR200 production-ready signaling, NVL144 rack demonstrations, HBM4 supplier qualification dates.
- **MLPerf Training v5.2 submissions (summer 2026):** AMD Helios + MI455X first multi-node training submissions on GPT-class architectures. AMD within 10% of Blackwell Ultra at FP4 on a 70B-class model materially strengthens the bear case.
- **CoWoS-L allocation revisions (August 2026):** Morgan Stanley/Digitimes re-issue 2027 allocation shares. NVIDIA below 55% is a falsifier of the packaging moat thesis [4].
- **Anthropic Ironwood Phase 1 deployment cadence:** Visible 400K-TPU deployment ahead of schedule in Google Cloud's calendar Q2 2026 earnings [7] undercuts the "frontier needs CUDA" claim.
- **First named Rubin CPX customer:** any hyperscaler commitment validates the disaggregated-inference architecture [14] as the structural answer to inference XPUs.
- **Hyperscaler Q2 calendar 2026 capex commentary:** any of MSFT/AMZN/GOOGL/META cutting 2026 capex by >10% sequentially is the cleanest single-print bear signal [6].
- **H20/H200 China shipments:** approved batch ordered by ByteDance/Alibaba/Tencent (~400K units) [15]; visible quarterly contribution restores ~$5–8B / quarter revenue and re-rates the China optionality.

## What I could not verify

- NVIDIA 2026 unit allocation by hyperscaler at a customer-level (MSFT vs. ORCL vs. META vs. AWS share of Blackwell/Rubin units). Aggregated commentary only.
- Margin on networking (Spectrum-X / Quantum-X) standalone vs. blended; suspected accretive but not segment-disclosed.
- Actual 16-Hi HBM4 yields at SK Hynix and Samsung — "formidable" cited [5] but no quantified yield data.
- Customer-side production maturity of Dynamo's KV-aware routing beyond first-mover labs.
- Whether Rubin Kyber 600 kW/rack [9] is facility-deployable by 2027 given DLC supply.
- Net cash as of May 2026 (EV approximated from last reported balance sheet).
- The genuine YTD 2026 return — public data sources spread from –6.7% to +15% depending on date and dividend treatment [20]. The ~+15% figure is more consistent with the April 27 ATH of $216.87.
- The "~4M CUDA developers" figure — corporate citation unchanged for ~18 months; treat as directional only.

## Sources

[1] https://www.financecharts.com/stocks/NVDA/value/pe-ratio — retrieved 2026-05-10 — NVDA $215.02 close, trailing P/E 43.65, forward P/E 26.0×, market cap $5.23T.
[2] https://www.fool.com/earnings/call-transcripts/2026/02/25/nvidia-nvda-q4-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q4 FY26: $68B revenue, $62B data center, FY26 data center $194B, Q1 FY27 guide $78B.
[3] https://www.tomshardware.com/pc-components/gpus/amd-says-instinct-mi400x-gpu-is-10x-faster-than-mi300x-will-power-helios-rack-scale-system-with-epyc-venice-cpus — retrieved 2026-05-10 — AMD MI455X specs (432 GB HBM4, 19.6 TB/s), Helios rack, 216B-param FP16 single-GPU capacity.
[3a] https://the-decoder.com/nvidia-sets-new-mlperf-records-with-288-gpus-while-amd-and-intel-focus-on-different-battles/ — retrieved 2026-05-10 — MLPerf Inference v6.0 results: NVIDIA 288-GPU GB300 NVL72 at 2.49M tokens/s DeepSeek-R1; AMD did not submit DeepSeek-R1 or Qwen3-VL.
[4] https://www.digitimes.com/news/a20251210PD218/tsmc-cowos-capacity-nvidia-equipment.html — retrieved 2026-05-10 — NVIDIA secures >50% of 2026–27 CoWoS capacity; ~60% per Morgan Stanley estimates; ~510K wafers.
[5] https://www.trendforce.com/news/2026/03/09/news-samsung-sk%E2%80%AFhynix-reportedly-tapped-as-nvidia-rubin-hbm4-suppliers-shipments-could-start-in-march/ — retrieved 2026-05-10 — HBM4 supply: SK Hynix lead, Samsung >30% on Vera Rubin, Micron ramping; 16-Hi target Q4 2026.
[6] https://www.tomshardware.com/tech-industry/big-tech/big-techs-ai-spending-plans-reach-725-billion — retrieved 2026-05-10 — Hyperscaler 2026 capex aggregate $725B; MSFT $190B (with $25B attributed to memory/component inflation); GOOG ~$190B, AMZN $200B, META $125–145B.
[7] https://newsletter.semianalysis.com/p/tpuv7-google-takes-a-swing-at-the — retrieved 2026-05-10 — TPU v7 (Ironwood) GA April 2026; Anthropic up to 1M chips / >1 GW (400K Ironwood phase 1); 4.3M Google shipments target 2026.
[8] https://www.anthropic.com/news/anthropic-amazon-compute — retrieved 2026-05-10 — Anthropic-AWS $100B / up to 5 GW Trainium 2+3 commitment; Project Rainier already at ~500K Trainium2.
[9] https://newsletter.semianalysis.com/p/vera-rubin-extreme-co-design-an-evolution — retrieved 2026-05-10 — Vera Rubin, NVLink 6, Kyber rack architecture (NVL72/144/576), 600 kW/rack 2027 target.
[10] https://aimultiple.com/cuda-vs-rocm — retrieved 2026-05-10 — 2026 share: NVIDIA ~86% data-center GPU revenue (down from ~90% in 2024); ROCm gap narrowed to 10–30% per-workload; PyTorch ROCm first-class.
[11] https://avanzaenergy.substack.com/p/data-centers-are-killing-the-grid — retrieved 2026-05-10 — U.S. interconnect queue ~2,300 GW; 7-year wait Columbus OH; GE Vernova turbines through 2028; 12 GW announced 2026 capacity, 5 GW under construction.
[12] https://www.techradar.com/ai-platforms-assistants/chatgpt/nvidias-biggest-customers-are-lining-up-to-take-it-down-using-asics-and-broadcom-could-be-the-winner-of-that-battle — retrieved 2026-05-10 — Broadcom XPU customer roster (Google, Meta, OpenAI, ByteDance); Q1 FY26 $8.4B AI; OpenAI 10 GW co-dev H2 2026.
[13] https://nvidianews.nvidia.com/news/openai-and-nvidia-announce-strategic-partnership-to-deploy-10gw-of-nvidia-systems — retrieved 2026-05-10 — OpenAI-NVIDIA 10 GW / up to $100B partnership; first GW H2 2026 on Vera Rubin.
[14] https://developer.nvidia.com/blog/nvidia-rubin-cpx-accelerates-inference-performance-and-efficiency-for-1m-token-context-workloads/ — retrieved 2026-05-10 — Rubin CPX architecture: 30 PFLOPS NVFP4, 128 GB GDDR7, 3× attention accel vs GB300 NVL72; Dynamo KV-aware routing.
[15] https://www.computerweekly.com/news/366625005/Nvidia-takes-45bn-hit-due-export-restrictions — retrieved 2026-05-10 — H20 revenue impact: $4.6B Q1 FY26, $2.5B unshipped, $8B Q2 hit; 15% (H20) / 25% (H200) China revenue share to U.S. Commerce; ~400K H200 batch approved.
[16] https://www.financialcontent.com/article/predictstreet-2026-1-2-the-cooling-heart-of-the-ai-era-a-deep-dive-into-vertiv-holdings-vrt — retrieved 2026-05-10 — Vertiv DLC at 120–150 kW/rack; 2026 as DLC "mass adoption" inflection (>50% of new builds).
[17] https://www.fool.com/investing/2026/03/26/nvidias-networking-grew-263-ai-trade-gpus/ — retrieved 2026-05-10 — NVIDIA networking trajectory; Spectrum-X >$10B annualized run-rate.
[18] https://www.tipranks.com/stocks/nvda/forecast — retrieved 2026-05-10 — Consensus 12-month PT $270–274 (n=42–71 analysts), Strong Buy.
[19] https://nvidianews.nvidia.com/news/nvidia-announces-financial-results-for-fourth-quarter-and-fiscal-2026 — retrieved 2026-05-10 — Q4 FY26 GAAP GM 75.0% (up from 73.4% Q3); Q1 FY27 GM guide 74.9% ± 50 bp; Q4 net income $43B.
[20] https://www.marketbeat.com/stocks/NASDAQ/NVDA/short-interest/ — retrieved 2026-05-10 — Short interest 283M shares (1.17% of float), 1.96 days to cover.
[21] https://finance.yahoo.com/quote/NVDA/ — retrieved 2026-05-10 — 52-week range $120.28–$217.80; 1-yr return +84.48%.
[22] https://finance.yahoo.com/quote/NVDA/analysis/ — retrieved 2026-05-10 — FY27 revenue consensus range ~$337–370B.