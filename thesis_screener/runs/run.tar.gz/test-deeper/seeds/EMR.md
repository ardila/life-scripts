# EMR — Emerson Electric Co.

## Where this sits in the AI stack
EMR is **not** in the AI silicon, packaging, memory, networking, rack, or cooling stack. It sells the **control plane between the power plant and the data hall**: distributed control systems (DCS) for gas turbines, balance-of-plant, and microgrids (the Ovation platform), and — via AspenTech — software for utility transmission/distribution and process-plant optimization. The relevant workload is not training or inference itself; it is the **on-site (behind-the-meter, "BTM") generation and grid-edge interconnect** that hyperscalers are building because the public grid cannot deliver gigawatt-class capacity in their 2026–2028 build window. EMR's content per AI campus is the turbine governor controls, SIL3 safety system, microgrid/island-mode controller, the SCADA/EMS layer, and the AspenTech DGM stack on the utility side that interconnects it [3][6][9][14].

## Snapshot
- **Price:** $140.20 (2026-05-08 close) [7]
- **Market cap:** ~$78.8B (562M shares × $140.20) [16]
- **52-week range:** $109.53 – $165.15 [11]
- **Forward P/E:** 21.7× (on FY26 guide midpoint EPS $6.475; consensus prints 22.3× on a slightly older EPS) [4][2]
- **EV / NTM revenue:** ~4.6× (EV ~$86.6B / NTM rev ~$18.8B at low-single-digit growth on $18.02B FY25 base) [16][18]
- **Consensus 12-month price target:** $164.24 (implied +17.1%); rating "Hold" [4]
- **YTD total return:** ~flat (-0.02% per IndexBox at last refresh) [11]
- **Short interest (% of float):** n/a — not confirmed in cited sources; institutionally heavy holder base (Principal alone files ~$86M) [10]

## Moat — what it is physically made of
The moat is **not** "industrial brand" and it is **not** a software API. It decomposes as:

1. **Ovation installed base in NA power generation.** Emerson's own claim: Ovation runs ~20% of global and **~50% of North American power generation** capacity, with 1,100 gas-turbine control retrofits across GE, Siemens, Mitsubishi, and Ansaldo frames in 35 countries representing 60+ GW [13]. This is the durable piece. A power-plant DCS is a 25–40-year asset; ripping it out costs $50–500M per site and risks NERC CIP recertification. Once Ovation is on a gas turbine, the next data-center campus that wants to add capacity to that site stays on Ovation by default. **Durable, but only at the installed asset.**

2. **OEM-agnostic turbine controls.** Unlike GE Vernova (Mark VIe) and Siemens Energy (Omnivise T3000, formerly SPPA-T3000), Ovation will retrofit **any** OEM frame [13][20]. With gas-turbine OEMs sold out 5–7 years and operators running mixed fleets (new GE 7HA + repurposed Frame 5/6 + aero-derivatives from ProEnergy), the OEM-agnostic vendor wins the **fleet-wide** standardization deal. **Durable; structurally stronger as the BTM market fragments by OEM.**

3. **AspenTech Digital Grid Management (ex-OSI Inc.).** OSI Monarch SCADA, EMS, ADMS, DERMS — the software that utilities use to actually dispatch generation and operate distribution networks. ACV growth +25% in Q1 FY26, +31% in Q2 FY26 [1][12]. This is a different moat: it is **certification + integration**, not silicon. Replacing an EMS at a regional utility is a multi-year project that touches NERC reliability standards. **Durable, but small ($1.56B total Software ACV across all of AspenTech at FY25 close, growing 10%+) [21].**

4. **Project Beyond / Boundless Automation platform.** Announced May 2025 — the "software-defined OT" stack that re-platforms DeltaV (process), Ovation (power), and AspenTech onto a common data fabric [19]. This is a **promise**, not yet a moat. Industrial customers buy DCS on 5–7-year qualification cycles; meaningful adoption is FY28+. Treat as optionality, not as evidence of current durability.

5. **What it is NOT.** Emerson divested Network Power (now Vertiv, the data-hall power+cooling business) in 2016 and Climate Technologies (now Copeland, the HVAC compressor business) in 2023–24 for combined cash of ~$13B [15][24][25]. Anything you read claiming Emerson sells "precision cooling" or "rack power" for AI data centers is either confused or referring to those legacy assets. EMR today touches the data center **upstream of the meter** and at the **plant/grid control layer**, not inside the white space.

Person-years to replicate: the gas-turbine governor library and SIL3-certified safety logic alone is probably 500–1,000 person-years of plant-validated engineering work, plus 60+ years of plant-specific tuning data in service contracts. The **EMS/SCADA** library at OSI is comparable. Neither is a *technical* moat in the sense a CUDA kernel is — it is a *certification, liability, and reference-installation* moat.

## AI buildout bottleneck map
The 24-month gating constraints, with EMR position on each:

| Bottleneck | EMR position |
|---|---|
| **Power generation (gas turbines, 5–7 yr OEM lead time)** [22][26] | **Direct beneficiary.** Ovation is the de facto NA controls layer; OEM-agnostic. Q1 FY26 Ovation orders +74%, Q2 +41% YoY [1][12]. |
| **Grid interconnect / T&D modernization** | **Direct beneficiary.** AspenTech DGM ACV +25–31% YoY; explicit ERCOT-region utility wins [1][12]. |
| **Behind-the-meter microgrid / island operation at hyperscale** | **Direct beneficiary.** 1.7 GW US AI data-center BTM win in Q1 FY26 (customer not disclosed); JV with Mitsubishi Power (Prevalon Energy) for utility-scale BESS [1]. SemiAnalysis projects 25–35 GW of BTM through 2030 [22]. |
| **CoWoS-L advanced packaging (sold out through mid-2026, NVIDIA ~60% of allocation)** [27][28] | **Indifferent / not exposed.** No semiconductor packaging revenue. |
| **HBM3e/HBM4 supply** [27] | **Indifferent.** |
| **Optical interconnect, NVLink/scale-up fabric** | **Indifferent.** |
| **Liquid cooling at >100 kW/rack (DLC, immersion)** [29] | **Not exposed** — that's Vertiv, Schneider, nVent, Boyd. EMR is upstream. |
| **Electrical contractor + skilled-trade capacity** | **Indirect beneficiary** — same labor pool installs Ovation-equipped plants. |
| **Kernel/compiler talent** | **Indifferent.** |
| **LNG capacity (gas supply for BTM turbines)** | **Beneficiary.** Final Control valves into LNG are 85% of the $11.2B project funnel along with power and life sciences [12]. |

EMR is concentrated almost entirely on the **electrons-into-the-rack** half of the bottleneck map. If your model of the AI buildout binds on power, EMR sits on the power side and has measurable order growth proving it. If your model binds on packaging, memory, fabric, or chips, EMR is **not the way to express that view** — own NVDA, ASML, ANET, or the HBM trio instead.

## Competitive teardown
On the technical axis that matters — **software and controls for NA gas-turbine BTM at hyperscale** — the field is narrow:

- **GE Vernova (GEV) — Mark VIe DCS.** Bundled with the dominant US gas-turbine OEM (~50% of the installed F-class/H-class fleet). GEV's $163B backlog [22] is an order of magnitude bigger than Emerson's and gives them the ability to **lock in** their DCS at greenfield on every new GE frame they ship. **Where they have parity or advantage:** any greenfield where GE's turbine wins, Mark VIe is the path of least resistance for the OEM scope; on aeroderivative and LM6000/LMS100 retrofits GEV defaults in. **Where EMR wins:** mixed-fleet operators, aftermarket retrofits, BOP integration with non-GE turbines, and customers who want a single DCS across mixed-OEM gas + nuclear + renewables (e.g., the Doel nuclear contract + Entergy three-plant Ovation 4.0 win [21]).

- **Siemens Energy — Omnivise T3000.** Same OEM-bundling logic for Siemens SGT frames; very strong in Europe and Middle East, weaker in NA [20][14]. Siemens Energy's €136B backlog is largely European and grid-equipment heavy [22]. Not the primary NA threat.

- **ABB — Symphony Plus.** ~50 GW lifetime install base in power; updated 2023 [14]. Real competitor for greenfield BOP and balance-of-plant retrofits, particularly outside NA. Loses on the OEM-mixed-fleet axis where Emerson's relationships with multiple turbine OEMs are strongest.

- **Honeywell — Experion PKS + Forge Operations Assistant.** Strong in O&G, refining, and discrete chemicals (Honeywell has ~20% overall DCS share, Emerson ~6.7% overall but ~29% O&G and a much larger NA power slice) [17]. **Power gen is a weakness** for Honeywell; their LLM-on-controls story (Experion Operations Assistant) is real and Emerson will need to match it via Project Beyond by FY27/28 to avoid losing ground in adjacent process verticals [30].

- **Schneider Electric — EcoStruxure / DCIM.** Different layer. Schneider is fighting for the **data-hall** controls (BMS, EPMS, SCADA inside the white space), now consolidated in EcoStruxure Foresight, with a co-developed reference design with NVIDIA for liquid-cooled clusters [29]. Not a substitute for Ovation upstream of the substation; competes more with Vertiv than with EMR.

- **Yokogawa — CENTUM.** Strong in JP/APAC O&G, weak in NA power. Not a meaningful threat in the BTM AI thesis.

- **Hyperscaler in-housing.** AWS, Microsoft, and Google have all built proprietary DCIM and automation layers. None have built a NERC-compliant gas-turbine governor or a SIL3-certified safety system, and the regulatory and liability profile makes this **unlikely** to be in-housed in a 5-year window. This is the largest *long-term* threat but not a 2026–2028 threat.

The honest read: **Mark VIe is the single competitor that can take share** on the marginal new-build BTM dollar, because GE wins the turbine. EMR's defense is fleet standardization and the aftermarket. AspenTech DGM has very few credible competitors at the utility EMS scale (Hitachi/ABB Network Manager, GE Digital GridOS, Schneider's grid software) — all real, but none growing 25%+ ACV today.

## Bull case — technical
Conditions that need to hold:
1. **Power, not chips, remains the binding constraint** on AI training/inference deployment through 2027. Verifiable via SemiAnalysis BTM tracking, hyperscaler PPA disclosures, and quarterly turbine-OEM backlog [22][26].
2. **Gas-turbine OEM lead times stay >4 years**, forcing operators into mixed-OEM fleets (new H-class + repurposed aeroderivatives + reciprocating engines + BESS), which structurally favors the **OEM-agnostic** controls vendor (Ovation) over the OEM-bundled vendors (Mark VIe, T3000) [13][22].
3. **AspenTech DGM ACV compounds at 20%+** as utility T&D capex inflects from grid-connection backlogs (ERCOT, MISO, PJM all 5+ year queues). The DGM growth seen in Q1/Q2 FY26 (+25–31%) sustains rather than mean-reverts to the corporate 10% software ACV target [1][12][21].
4. **Project Beyond catches a real industrial-AI inflection** by FY28 — not just AI demos for refinery planning (Aramco) but autonomous closed-loop control on operator workflows, defending against Honeywell Forge.
5. **Mark VIe does not sweep the new-build market.** Verifiable via greenfield BTM project announcements over next 4–6 quarters.

If 1–3 hold, FY27 EPS lands above the current ~$7.30 consensus, the multiple holds at ~22×, and the stock works toward the $164–180 range. The base rate on installed-base-driven industrial moats is favorable: DCS displacement cycles in regulated power have historically taken 15–25 years even when the challenger has technical parity, because of NERC/CIP recertification, operator retraining, and fleet standardization. This is closer to the airliner/avionics replacement curve than the cloud or smartphone curves.

## Bear case — technical
Conditions a sophisticated short would press:
1. **The "data center" share of Ovation orders is real but small.** EMR has not disclosed a percentage. The +74% / +41% Ovation order growth is on a small base and includes utility fleet modernization unrelated to AI [1][12]. If you back out conventional utility capex and BTM that would have happened anyway (LNG export buildout, IRA-driven peakers, coal retirements), the AI-incremental piece may be 1–2% of total EMR revenue. The narrative is doing more work than the dollars.
2. **GE Vernova and Siemens Energy can bundle.** With GEV's $163B backlog and Siemens Energy's €136B [22], a bundled "turbine + Mark VIe + service contract" pricing strategy can structurally lock EMR out of new build at marginal cost to the OEM. This is the most credible erosion mechanism. Falsifier: greenfield BTM announcements over the next 12 months that disclose DCS vendor.
3. **AspenTech goodwill risk.** EMR paid ~$17B EV for AspenTech (full take-private March 2025), funded with cash and new debt; net debt is ~$12B [16][24]. At 4.6× EV/NTM revenue and 22× forward EPS, the stock is priced as a software-tinged industrial. If DGM growth decelerates to industry-average 8–10% and AI-optimization ACV stays in the "early" bucket described by the CEO [12], the multiple compresses toward the 16–18× historical industrials range, which is ~25–30% downside even with EPS holding.
4. **Power cycle is cyclical.** The LNG cycle is up; the utility cycle is up; data-center BTM is the hot tape. All three peak together. Industrial cap-ex peaks have historically given back 30–50% of stock price. Backlog at $8.2B (book-to-bill 1.07) is 2.4× quarterly revenue — healthy but not extreme [12].
5. **DCS market growth is modest** — ~5.2% CAGR overall [17]. EMR's outperformance is concentrated in one vertical (power) at one point in a cycle. The structural growth rate of the franchise outside the power-AI bubble is probably 4–6%.
6. **The deepest technical bear:** in a 7–10 year window, gas turbines may be displaced by combined SMR + grid-side dispatch (NuScale, X-energy, KAIROS), in which case the controls layer fragments away from Ovation's BOP heritage toward nuclear-specific stacks (Westinghouse, Curtiss-Wright, Framatome). EMR's nuclear footprint exists (Doel) but is small.

## Market view check
At $140.20 / 22× forward / ~4.6× EV/sales / consensus PT $164 (Hold), the market is paying a **modest premium to industrial peers** (the multi-industrial median is ~18–20× forward) but not a software multiple. The implied view is that EMR is a low-double-digit EPS-grower with cyclical exposure to power and process, partly re-rated for AspenTech's software ACV. That is **roughly consistent** with the technical reality I see — the market is not paying for an AI-data-center pure-play, and rightly so, because EMR isn't one. The mispricing, if any, is a **directional optionality call**: if BTM gas-turbine controls become a sustained 20%+ growth pocket inside the Software & Control segment for 3+ years, the segment re-rates, and EMR could get a Schneider-Electric-style 25–28× multiple. If BTM is mostly a 2026–2027 surge that levels off, the stock is fairly valued at $140 with a $164 PT being analyst optimism on the same cyclical extrapolation.

## 90-day falsifiers
Specific, observable through ~mid-August 2026:

1. **Q3 FY26 earnings (early August 2026):** Ovation order growth materially decelerates (e.g., below +20% YoY off the +41% Q2 base) — would weaken the BTM-AI narrative. Conversely, +50%+ would strengthen it.
2. **AspenTech DGM ACV growth on the same call:** sustained at 25%+ vs. reverting toward 10–15%. The thesis needs sustained, not one-quarter, growth.
3. **Hyperscaler Q2 26 capex commentary (MSFT/META/GOOG/AMZN late July):** any sequential cut >10% to FY26 power infrastructure budgets, or pull-back from BTM commitments, hits orders with a 2–3 quarter lag.
4. **GE Vernova / Siemens Energy disclosure of a bundled DCS-with-turbine commercial offering** at a major hyperscaler — would be the first hard evidence of bundling threat playing out in the AI vertical.
5. **Named hyperscaler customer disclosure** for the 1.7 GW Q1 win (still anonymous) — naming the customer (especially if it is one of the top three hyperscalers) re-rates investor perception of the franchise.
6. **FERC / ERCOT regulatory action on BTM** — any constraint on co-located generation (load study requirements, capacity payments) slows the buildout EMR is benefiting from. Watch FERC docket activity around AEP / Talen / Susquehanna.
7. **Project Beyond customer reference at Boundless Automation Summit** (typically September) — first paying production deployment vs. continuing to be a roadmap.

## What I could not verify
- **EMR short interest.** Cited sources did not provide a current % of float; I would expect it to be low (single-digit) given the institutional/dividend-aristocrat profile, but I did not confirm.
- **Customer name on the 1.7 GW BTM win.** Q1 FY26 transcript explicitly does not name them [1].
- **What % of FY26 revenue is "AI data center" related.** Management has not disclosed; I believe it is small in absolute terms (likely 1–3% of total revenue today, embedded in Ovation power-vertical orders), but this is inference, not a disclosed figure.
- **GEV / Siemens Energy DCS attach rates** on greenfield BTM gas-turbine wins. No clean disclosure; bundling is asserted in industry conversation but not quantified.
- **Whether the $164 consensus PT bakes in further BTM acceleration** or just FY26 guidance — the breakdown of analyst assumptions wasn't accessible at the level of detail I would want.
- **Net debt service cost on the AspenTech financing** and how much of the ~$12B net debt is fixed vs. floating; relevant for a higher-rates scenario.
- **Project Beyond architecture details** beyond the marketing material — no third-party teardown of the data fabric, no published latency/scale numbers, no customer benchmarks.
- **Specific Texas grid-mod customer** referenced in Q2 FY26 ("Encore" per transcript fetch — likely Oncor mis-transcribed; not independently confirmed).

## Sources
[1] https://www.fool.com/earnings/call-transcripts/2026/02/03/emerson-emr-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q1 FY26 transcript: 1.7 GW BTM AI data center win; Ovation orders +74%; AspenTech DGM ACV +25%; CEO Karsanbhai, CFO Baughman, COO Krishnan named.
[2] https://news.alphastreet.com/emerson-electric-co-emr-q2-fy2026-earnings-preview-process-momentum-ai-tailwinds-and-margin-discipline-in-focus/ — retrieved 2026-05-10 — Q2 FY26 preview noting AI tailwinds and management framing of data-center exposure.
[3] https://www.emerson.com/en-us/automation/control-and-safety-systems/distributed-control-systems-dcs/ovation-distributed-control-system — retrieved 2026-05-10 — Ovation DCS product description and install base claim.
[4] https://www.americanbankingnews.com/2026/05/10/emerson-electric-nyseemr-price-target-raised-to-155-00.html — retrieved 2026-05-10 — Consensus Hold rating, average PT $164.24.
[6] https://www.emerson.com/en-us/automation/brands/ovation/data-center-energy-management — retrieved 2026-05-10 — Ovation positioned for data-center microgrid control, island mode, BTM gas turbine integration.
[7] Yahoo Finance / Marketbeat aggregate via web search — retrieved 2026-05-10 — May 8, 2026 close $140.20.
[9] https://www.aspentech.com/en/acquisition/osi — retrieved 2026-05-10 — Digital Grid Management product line origin (OSI Inc.); DERMS, EMS, ADMS, SCADA components.
[10] https://www.marketbeat.com/instant-alerts/filing-principal-financial-group-inc-has-8591-million-stake-in-emerson-electric-co-emr-2026-05-07/ — retrieved 2026-05-10 — Institutional holder filing (Principal $86M).
[11] https://www.financecharts.com/stocks/EMR/growth/total-return — retrieved 2026-05-10 — 52-week range and YTD ~flat.
[12] https://www.fool.com/earnings/call-transcripts/2026/05/05/emerson-emr-q2-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q2 FY26 transcript: Ovation orders +41%, DGM ACV +31%, BTM data-center commentary, $11.2B funnel, $8.2B backlog, book-to-bill 1.07.
[13] https://www.emerson.com/en-us/automation/control-and-safety-systems/distributed-control-systems-dcs/ovation-distributed-control-system/gas-turbine-controls — retrieved 2026-05-10 — 1,100 turbine retrofits, 60+ GW, 35 countries; OEM-agnostic across GE/Siemens/Mitsubishi/Ansaldo.
[14] https://www.nextmsc.com/blogs/why-are-honeywell-abb-giants-in-the-dcs-market — retrieved 2026-05-10 — DCS market structure; ABB Symphony Plus, Honeywell Experion, Siemens, Yokogawa, Emerson.
[15] https://www.blackstone.com/news/press/blackstone-completes-acquisition-of-majority-stake-of-copeland-formerly-emerson-climate-technologies/ — retrieved 2026-05-10 — Copeland (former Emerson Climate Tech) divested to Blackstone, $14B EV.
[16] https://stockanalysis.com/stocks/emr/statistics/ — retrieved 2026-05-10 — 562M shares outstanding, $14B debt, $1.75B cash, EV ~$86.55B.
[17] https://www.mordorintelligence.com/industry-reports/distributed-control-system-market — retrieved 2026-05-10 — DCS TAM $23.89B 2026, 5.2% CAGR; top-5 (ABB, Emerson, Honeywell, Siemens, Yokogawa) ~60% share; Emerson 6.7% overall, 29% O&G.
[18] https://ir.emerson.com/news-events/press-releases/detail/617/emerson-reports-fourth-quarter-and-full-year-2025-results-provides-initial-2026-outlook — retrieved 2026-05-10 — FY25 revenue $18.02B, FY26 EPS guide.
[19] https://www.emerson.com/en-us/news/2025/05-emerson-project-beyond-to-modernize-and-seamlessly-integrate-the-industrial-automation-technology-stack — retrieved 2026-05-10 — Project Beyond software-defined OT platform launch May 2025.
[20] https://www.siemens-energy.com/global/en/home/products-services/product/omnivise-t3000.html — retrieved 2026-05-10 — Siemens Energy Omnivise T3000 DCS product page.
[21] https://www.fool.com/earnings/call-transcripts/2025/11/05/emerson-emr-q4-2025-earnings-call-transcript/ — retrieved 2026-05-10 — Q4 FY25 transcript: Entergy 3-plant Ovation 4.0 win, Doel nuclear, Software ACV $1.56B +10%, FY26 ACV growth >10% guide.
[22] https://newsletter.semianalysis.com/p/how-ai-labs-are-solving-the-power — retrieved 2026-05-10 — SemiAnalysis on BTM gas as the practical bridge for AI power; 25–35 GW BTM through 2030; turbine OEM 5–7 yr lead times; GEV $163B and Siemens Energy €136B backlogs.
[24] https://www.emerson.com/en-us/news/2025/emerson-completes-acquisition-of-remaining-outstanding-shares-of-aspentech — retrieved 2026-05-10 — AspenTech full take-private completed March 12, 2025 at $265/share; ~$17B EV.
[25] https://en.wikipedia.org/wiki/Vertiv — retrieved 2026-05-10 — Vertiv (formerly Emerson Network Power) divested to Platinum Equity 2016 for $4B.
[26] https://www.primary.vc/articles/the-gas-turbine-bottleneck-reshaping-energy-infrastructure-ex8qe — retrieved 2026-05-10 — Gas turbine OEM lead times and backlog dynamics; energy infrastructure framing.
[27] https://newsletter.semianalysis.com/p/ai-capacity-constraints-cowos-and — retrieved 2026-05-10 — CoWoS-L and HBM allocation as the binding semiconductor-side bottleneck; NVIDIA ~60% allocation through 2026.
[28] https://wccftech.com/nvidia-alone-has-tsmc-advanced-packaging-lines-booked-for-several-years-ahead/ — retrieved 2026-05-10 — NVIDIA's CoWoS booking dominance.
[29] https://www.se.com/ww/en/work/software/data-center-infrastructure-management-dcim/ — retrieved 2026-05-10 — Schneider EcoStruxure DCIM; data-hall control layer (different from EMR's plant-side scope).
[30] https://www.honeywell.com/us/en/press/2024/10/honeywell-to-power-energy-sector — retrieved 2026-05-10 — Honeywell Forge / Experion Operations Assistant AI strategy in process control.