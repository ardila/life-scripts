# ORCL — Oracle Corporation

## Where this sits in the AI stack
Oracle is, as of mid-2026, the world's fourth hyperscaler by GPU-cluster revenue and, on a per-MW basis, the most NVIDIA-pure of them. It does not sell silicon, packaging, or HBM; it sells **rented training and inference capacity** built on leased datacenter shells filled with NVIDIA (Hopper, Blackwell, soon Rubin) and a smaller AMD Instinct fleet, stitched together by Oracle's own Acceleron RoCEv2 fabric and Linux-host stack. Workload mix skews toward **frontier-scale pretraining** (OpenAI, ByteDance, Meta in discussions, xAI via Microsoft sub-allocation per public reporting) rather than retail inference. The legacy database business (Oracle Database 26ai / Exadata / Autonomous DB) is increasingly delivered into AWS, Azure and GCP data halls as a co-located Exadata stack — a separate, higher-margin moat that the AI infrastructure narrative has overshadowed.

## Snapshot
- **Price:** $194.59 (2026-05-08 close; 2026-05-10 is a Sunday) [1]
- **Market cap:** $563.6B [1]
- **52-week range:** $134.57 – $345.72 (high set 2025-09-10 immediately after the OpenAI $300B disclosure; low set in the Oct-25 / Q1-26 drawdown around Moody's negative outlook and the leaked 14% AI-cloud GM) [1][12][13]
- **Forward P/E:** 26.0× (on consensus FY27 EPS; one tracker quotes 22.0× on a slightly different base) [1]
- **EV / NTM revenue:** ~10.7× (EV $686.6B, FY27 consensus revenue ~$90.6B) [1]
- **Consensus 12-month price target:** $260.11 (implied +33.7%) — 36 analysts, "Buy" consensus, range $160–$400 [1]
- **YTD total return:** approximately −14% (one tracker cites −14.3%, another −25% at a lower mid-quarter print; both reflect a sharp Q4-2025 / Q1-2026 derate from the Sept-2025 peak) [1] (inference)
- **Short interest (% of float):** 1.73% (29.34M shares, ~1.0 day to cover, as of 2026-04-15) [20]

## Moat — what it is physically made of
Decomposed by component, with durability assessed separately:

**1. Acceleron RoCEv2 network fabric — moderate, contestable.** Oracle's edge over AWS/GCP in pure NVIDIA scale-up clusters is a multi-plane RDMA-over-Ethernet topology built around NIC-resident four-port switches (using NVIDIA ConnectX-7 / BlueField-3, and BlueField-4 in Zettascale10). Each GPU NIC fans out to *isolated network planes*, letting traffic shift planes on link failure without stalling collectives — material because at >32k-GPU jobs a single bad link in a Clos tree can idle the whole cluster. Topology: three-tier non-blocking Clos, 400 Gbps per port, 2 µs first-tier / 5 µs second-tier / 8 µs third-tier latency, scaling to 131,072 NVIDIA GPUs (current Supercluster) and 800,000 GPUs across multi-GW campuses (Zettascale10, taking orders, 2H26 availability) [4][5][2]. SemiAnalysis's independent ClusterMAX 2.0 benchmark places OCI in the **Gold tier** alongside Nebius and Azure, with NCCL all-reduce performance "very competitive with Spectrum-X Ethernet" [3][2]. *Durability:* erodes as Spectrum-X Ethernet and AWS-EFA v3 catch up; the design is patentable but the *idea* (multi-plane, NIC-switched) is not proprietary silicon. 2–3 years of lead, maybe.

**2. Power and shell control — large, hard to replicate in <24 months.** Oracle has secured ~10 GW of contracted data-center power for the next three years and stood up 400 MW in Q3 FY26 alone [9]. The OpenAI contract alone requires 4.5 GW from 2027 [8]. Against GE Vernova gas-turbine slots sold out through 2027 [18] and PJM capacity prices >10× prior years [18], this is a *physical* moat — but **Oracle leases shells rather than self-building**, so the moat is really *long-dated leases with Crusoe/DayOne/GDS*, not Oracle property. A competitor with similar lease commitments could match.

**3. Customer-funded GPU model — clever, but inverts the risk.** Per Catz on the Q3 FY26 call, "most of the equipment is either funded upfront via customer prepayments…or the customer buys the GPUs and supplies them to Oracle" [7]. This *reduces* working-capital risk but means Oracle is also surrendering the residual-value option. *Durability:* a financing structure, not a moat.

**4. Oracle Database / Exadata @ AWS, Azure, Google — strong, dull, underrated.** Oracle DB on Exadata in *competitor* data centers (DB@Azure 21 regions, DB@Google 11 regions, DB@AWS expanding to 20) is the underdiscussed part of the story [19]. Multicloud DB revenue +531% YoY in Q3 FY26 [7]. The moat here is real: SQL semantics, PL/SQL, RAC, and Exadata smart-scan + storage-server offload — replicated only with great pain. Migrations off Oracle DB take 18–36 months and routinely fail. *Durability:* this is the actual decades-long moat; AI infrastructure rents have not yet replaced it as the gross-profit center.

**5. Cost of capital and ODM sourcing — modest.** Investment-grade balance sheet (still Baa2, but on negative outlook) gives Oracle cheaper debt than CoreWeave / Nebius / Crusoe [2][12]. Direct sourcing from Foxconn (bypassing Dell/SMCI margin) gives a claimed ~20% capex advantage over neocloud peers per SemiAnalysis [2]. *Durability:* erodes if Moody's downgrades again, which would tighten the spread vs. AAA-rated AWS/Microsoft/Google.

**What Oracle does NOT have:** no scale-up fabric (NVLink/NVSwitch are NVIDIA-owned); no custom silicon (no equivalent of Trainium/TPU/Maia/MTIA); no proprietary kernel/compiler stack (uses CUDA, cuDNN, NCCL, TensorRT — same as everyone); no datacenter self-build expertise; no first-party frontier model; no consumer/agent distribution. The CUDA moat *protects* Oracle from non-NVIDIA disruption while exposing it to NVIDIA's pricing.

## AI buildout bottleneck map
Mapping each gating constraint to Oracle's position:

| Bottleneck | 2026 status | ORCL position |
|---|---|---|
| **Grid interconnect / generation** | PJM under reliability target by 2027; ERCOT large-load queue >233 GW; capacity prices >10× [18] | **Beneficiary of locked-in 10 GW** [9]; **exposed** to right-shift if Stargate sites get queue-bumped |
| **Gas turbines** | GE Vernova sold out 2026–27; supply 27→42 GW by 2027 [18] | Indirect — partners (Crusoe) bear procurement risk |
| **CoWoS-L** | NVIDIA holds 60–70% of TSMC's 2026 CoWoS capacity; 50+ week lead time [17] | **Exposed customer** — Oracle's GPU mix is ~95% NVIDIA; AMD MI355X (130k cluster) is a partial hedge [15] |
| **HBM3e (and HBM4 ramp)** | 8-hi and 12-hi fully allocated for 2026; +15–22% YoY pricing [17] | **Exposed customer** — passed through in GPU prices, compresses GM |
| **Liquid cooling >100 kW/rack** | GB200 NVL72 = 120 kW, fully liquid, no air variant [GB200 hardware refs] | **New competence**; Oracle is one of the four named GB200 NVL72 cloud destinations [GB200] but lacks the multi-year liquid-cooling integration depth of Azure/AWS |
| **Optical interconnect (400G→800G ZR/ZR+)** | Tight on coherent optics, especially for multi-DC training | Beneficiary of Zettascale10's multi-DC fabric design — but supply is industry-wide |
| **Kernel/compiler talent** | Concentrated at NVIDIA, OpenAI, Anthropic, DeepMind | **Indifferent** — Oracle does not need this layer, runs customer stacks |
| **Frontier training data** | Constraint for model labs | **Indifferent** — landlord, not tenant |

The single largest *Oracle-specific* swing factor here is power-interconnect timing on the Stargate Phase-2 sites, because OpenAI revenue recognition begins only when the megawatts energize.

## Competitive teardown

**vs. AWS** — different fight. AWS's AI infrastructure is increasingly **Trainium-centric**; 500k+ Trainium2 chips in production by late-2025, Trainium3 in 2026, and the Anthropic $20B/Project Rainier buildout is on Trainium not NVIDIA [21]. AWS's NVIDIA fleet uses EFA (Elastic Fabric Adapter), not RDMA-over-Ethernet — different semantics, configurationally more complex, optimized for AWS workloads. Where Oracle wins: pure-NVIDIA-at-scale, fast time-to-deploy, lower published $/GPU-hr. Where AWS wins: TCO for AWS-native customers, custom silicon optionality, self-build (private substations, own datacenter shells).

**vs. Azure** — frenemy, asymmetric. Microsoft Maia 200 (3nm TSMC, 216 GB HBM3e, >10 PFLOPS FP4) is the biggest 2026 custom accelerator by memory and runs OpenAI inference internally [21]. But Azure still ~70% NVIDIA. Crucially, the OpenAI account moved *to Oracle* for Stargate — Microsoft is no longer the exclusive compute provider. ClusterMAX puts Azure and Oracle at parity (Gold) on NVIDIA clusters [3]. DB@Azure (21 regions, +531% YoY multicloud DB revenue) makes them mutual customers in the database layer [7][19].

**vs. GCP** — different lane. Google's TPU v7 Ironwood + the $10B+ Anthropic deal lock most of Google's frontier training internally and to a single big tenant [21]. GCP NVIDIA cluster offering is Silver in ClusterMAX [3]. Not a head-on competitor on pure NVIDIA capacity at frontier scale.

**vs. CoreWeave** — the only Platinum ClusterMAX provider [3]. CoreWeave wins on operational maturity, monitoring, and observability — premium pricing justified by lower TCO. But its cost-of-capital disadvantage (junk-bond financed at higher rates) limits its ability to underprice Oracle on long-duration contracts. Oracle has the funding to outbid for the OpenAI-class workloads; CoreWeave has the polish for the 1k–10k-GPU tier.

**vs. Nebius** — Gold-tier peer [3], smaller scale, similar RoCE architecture. Limited ability to compete on multi-GW campuses.

**Base rate on platform displacement:** The CPU→GPU displacement for training took ~7 years from first credible threat (AlexNet 2012) to dominance. The on-prem→cloud shift took 10+ years to cross 50%. x86→ARM in mobile was decisive in ~5 years because the workload (mobile battery life) forced it; in data center it has taken 10+ years and is still <30% share. Hyperscaler custom-silicon displacement of NVIDIA in training is following the slower (data-center ARM) curve, not the faster (mobile) curve — because CUDA is a deeper moat than x86 was, and because training workloads are *less* homogeneous than mobile SoC workloads. **Reasonable base rate: 3–5 more years before custom silicon dents NVIDIA training share by more than 25%, which gives Oracle a multi-year tailwind even on a pessimistic custom-silicon view.**

## Bull case — technical
Conditions that need to hold:

1. **Frontier training scales past 100k-GPU jobs** to 250k–500k for trillion-parameter dense and multi-trillion sparse models, which is where Oracle's multi-plane RoCE fabric specifically beats single-plane Spectrum-X and EFA. Independent NCCL all-reduce numbers at >32k-GPU scale (which Oracle currently leads on per ClusterMAX [3]) translate to lower TCO per training step.
2. **CUDA remains the dominant runtime through 2028**, so the NVIDIA-pure strategy is not stranded by a TPU/Trainium/Maia tide.
3. **OpenAI becomes cash-flow positive enough by 2027–28 to fund the $60B/yr drawdown** against the $300B contract, removing counterparty doubt and unlocking RPO→revenue conversion.
4. **AI-cloud gross margin migrates from 14–16% to 30%+** as scale absorbs the H100/H200 depreciation and Blackwell utilization rises. Management says it is already at 32% on Q3 capacity [7]; The Information's leaked internal docs and Stifel's 16% baseline say not yet [13].
5. **Multicloud DB compounds at >50% for three more years**, becoming the high-GM offset to lower-GM AI rentals. This is the most underappreciated piece — Oracle DB inside Azure/AWS/GCP halls is the rare strategic moat that *strengthens with hyperscaler success*.

Financial translation: if (4) and (5) hold, FY28 OCI revenue ≈ $80–100B at ≥25% segment GM with DB business compounding at low double digits, supporting a low-30s P/E on $12–15 EPS — i.e. a $360–$400 stock by late 2027.

## Bear case — technical
Conditions a stack-literate short would underwrite:

1. **AI gross margin stays sub-20%.** The Information's leaked Q1 FY26 numbers show 14% GM on the $900M/qtr GPU-rental segment, with *negative* GM on the new Blackwell deployments [13]. If the depreciation curve on H100/H200 (~5-year useful life claimed; real economic life closer to 3 given the FP4-native Blackwell/Rubin step) accelerates, the unit economics never inflect. Management's claim of 32% Q3 GM on AI capacity is unaudited and uses Oracle's segment definitions [7]; Stifel's 16% baseline assumes scale leverage that may not arrive.
2. **OpenAI counterparty failure or renegotiation.** Moody's explicitly flagged Oracle's bet on a single counterparty as "one of, if not the world's largest, project financing" and downgraded outlook to negative [12]. OpenAI was ~$2B ARR with negative cash flow when it committed to $60B/yr against Oracle [2]. Some lenders are already declining to participate in Stargate-adjacent financings [12]. If OpenAI takes a haircut in 2027–28, Oracle eats the GPU residuals.
3. **Custom silicon eats faster than base-rate suggests.** If Trainium3 + Maia 200 + TPU v7 take 35–40% of new training capacity in 2026–27 (Amazon at 500k+ Trainium2 deployed; Anthropic-on-TPU; OpenAI's own Broadcom ASIC reportedly 2026–27), NVIDIA-only Oracle is a contra-trade to the underlying trend.
4. **CoWoS-L / HBM4 allocation tightens further** and NVIDIA prioritizes hyperscalers with self-build power (Azure, AWS, Google) over Oracle for GB300/Rubin allocation [17]. Oracle's GPU supply becomes the constraint, not its sales.
5. **Power interconnect right-shift on Stargate.** ERCOT/PJM queue backlogs and GE Vernova turbine slots push the 4.5 GW OpenAI buildout by 12–18 months [18], compressing the IRR on capex already sunk.
6. **Leverage to ~4× EBITDA.** Moody's expects this trajectory [12]; with $123B net debt today implied by EV–MC and >$50B/yr capex going forward [9], a credit cycle would hit ORCL hard.

The bear thesis is *not* "AI demand falls". It is: "Oracle is a high-fixed-cost landlord with one tenant worth >50% of the contracted backlog [7], on rented land, in a power-constrained market, selling a commodity (NVIDIA hours) whose unit margin is structurally lower than the database business it is being valued like."

## Market view check
At $194.59, ORCL trades at ~10.7× EV/NTM revenue and ~26× forward EPS [1] — roughly Microsoft's multiple on a much higher growth rate (consensus +32% revenue FY27 [1]) and a much lower margin profile (14–32% AI segment GM vs. Azure ~70% [13]). The market is implicitly pricing **(a)** RPO-to-revenue conversion close to face value, and **(b)** AI-cloud GM expansion from the leaked low-teens toward management's claimed 30s. The down ~14% YTD and ~44% off the Sept-2025 peak [1] shows the market has *partially* absorbed the Moody's counterparty concern and the leaked margin data, but the consensus +33% PT [1] implies analysts still expect those resolve favorably. The disagreement I have with consensus is on (b): I do not think AI rental GM gets to 25%+ on the current GPU mix and contract structure without either (i) NVIDIA price concessions, which are not happening on Blackwell, or (ii) the customer-supplied-GPU model becoming the majority of new deals, which transfers economic upside to the customer. The stock therefore looks **fairly priced for a base case and expensive for the bear case**, with the asymmetry being negative — limited upside above $260 because the multiple is already full, sizeable downside to $130 if AI GM stays sub-20%.

## 90-day falsifiers
- **Oracle Q4 FY26 earnings (~mid-June 2026):** OCI segment gross margin disclosure (will Catz/Ellison restate the 32% AI GM, or quietly back away?), FY27 capex guide, RPO directionality, and whether the customer-supplied-GPU share is rising.
- **Meta $20B deal confirmation** or quiet death [11]. A signed contract would materially diversify the OpenAI concentration.
- **Stargate Phase-2 site announcements**: which power markets (ERCOT, MISO, SPP) — the choice will telegraph what interconnect timelines Oracle thinks it can hit.
- **Moody's / S&P follow-up rating action** post-Q4 earnings. Either an outlook restoration or a downgrade to Baa3 would move the curve materially.
- **MLPerf Training v5.x submissions** featuring OCI on Blackwell NVL72 and AMD MI355X at scale. Independent collective-comms numbers at >16k GPUs vs. Azure/AWS submissions would either validate or undercut the Acceleron pitch.
- **NVIDIA GB300/Rubin allocation disclosures** at GTC or Hot Chips 2026 — if Oracle's allocation share lags AWS/Azure/Google, the bear case strengthens.
- **OpenAI revenue print** (typically leaks via The Information / Reuters): the ~$20B run-rate would need to be tracking toward ~$60B by 2027 to support the Stargate drawdown without a renegotiation.

## What I could not verify
- Whether the $30B unnamed-customer SEC filing of June 2025 was OpenAI or a separate party (industry consensus is OpenAI but never confirmed in disclosure).
- Whether xAI's Colossus 1/2 has any meaningful Oracle component. Public reporting points to a Memphis-area self-built / SpaceX-rented arrangement, with Anthropic now renting Colossus 1; I could not source an Oracle-xAI contract.
- The actual silicon vendor inside Oracle's Acceleron-Acceleron switching tier (NVIDIA Spectrum-X vs. Broadcom Tomahawk 5 vs. Marvell Teralynx) — Oracle's own descriptions are vendor-agnostic, but the NIC-side is clearly NVIDIA ConnectX-7 / BlueField-4.
- Exact YTD 2026 total return — sources disagree (−14% vs. −25% at differing print dates); I have approximated and flagged.
- The dividend yield (one source cited 1.0%; not corroborated in the statistics page I read).
- Independent third-party gross-margin validation for AI-cloud at scale beyond The Information's leak and Oracle's management commentary — there is no audited segment breakout this granular.
- Whether the customer-supplied-GPU contracts include residual-value-sharing clauses (would materially change the depreciation question).

## Sources
[1] https://stockanalysis.com/stocks/orcl/statistics/ — retrieved 2026-05-10 — ORCL May 8 2026 price ($195.95 close cited here; $194.59 cited in market-search snapshot), 52-week range, fwd P/E 26.0×, EV/Rev 10.7×, market cap $563.6B, EV $686.6B, consensus PT $260.11, analyst count 36, YTD ~−14%.
[2] https://newsletter.semianalysis.com/p/how-oracle-is-winning-the-ai-compute-market — retrieved 2026-05-10 — SemiAnalysis on Oracle's AI compute strategy: Acceleron RoCEv2 inherited from Sun, OpenAI/Crusoe Abilene contract structure, ByteDance as largest GPU customer, ODM (Foxconn) sourcing, 20% capex advantage over neoclouds, Crusoe credit/duration-risk caveats.
[3] https://newsletter.semianalysis.com/p/clustermax-20-the-industry-standard — retrieved 2026-05-10 — ClusterMAX 2.0: CoreWeave Platinum; Oracle/Nebius/Azure/Crusoe/Fluidstack Gold; AWS/GCP Silver. Evaluation across 10 criteria (security, reliability, networking, etc.). Notes Oracle's weak AMD Slurm offering.
[4] https://blogs.oracle.com/cloud-infrastructure/first-principles-zettascale-oci-superclusters — retrieved 2026-05-10 — OCI cluster topology: three-tier non-blocking Clos, 400 Gbps/port, 2/5/8 µs latency tiers, 131,072 NVIDIA GPU scale, 52 Pbps aggregate.
[5] https://www.oracle.com/news/announcement/ai-world-oracle-unveils-next-generation-oci-zettascale10-cluster-for-ai-2025-10-14/ — retrieved 2026-05-10 — Zettascale10 / Acceleron design: multi-plane NIC-resident switching with BlueField-4, 800k-GPU scale, 16 zettaFLOPS peak, multi-GW campus, taking orders, 2H26 availability.
[6] https://www.oracle.com/news/announcement/q3fy26-earnings-release-2026-03-10/ — retrieved 2026-05-10 — Q3 FY26 results: revenue $17.2B (+22%), Cloud +44%, OCI $4.9B (+84%), RPO $553B (+325% YoY), multicloud DB +531%, AI infra revenue +243%.
[7] https://www.fool.com/earnings/call-transcripts/2026/03/10/oracle-orcl-q3-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q3 FY26 transcript. Management asserts 32% AI-capacity GM, customer-funded GPU model, 5-year RPO converts to $144B FY30 OCI revenue.
[8] https://openai.com/index/stargate-advances-with-partnership-with-oracle/ — retrieved 2026-05-10 — Stargate / Oracle: 4.5 GW capacity, 5-year deal from 2027, ~$300B/$60B per year economics, >5 GW total Stargate buildout with Abilene Phase 1.
[9] https://www.datacenterdynamics.com/en/news/oracle-stood-up-400mw-of-data-center-capacity-in-latest-quarter-has-secured-10gw-of-power-for-the-next-three-years/ — retrieved 2026-05-10 — Oracle 10 GW power secured over three years; 400 MW stood up in Q3 FY26; FY26 capex ~$50B (raised $15B); 2.45 GW Bloom fuel-cell allocation; Oracle leases rather than self-builds.
[10] https://www.bloomberg.com/news/articles/2025-09-24/oracle-looks-to-raise-15-billion-from-corporate-bond-sale — retrieved 2026-05-10 — Oracle $18B six-tranche IG bond (up from $15B) Sept 2025; $38B parallel loan facilities arranged for AI capex.
[11] https://www.datacenterdynamics.com/en/news/meta-in-talks-to-sign-20bn-oracle-cloud-deal-report/ — retrieved 2026-05-10 — Meta–Oracle $20B multi-year cloud talks for NVIDIA GPU training/inference capacity.
[12] https://www.theregister.com/2025/09/22/moodys_raises_questions_over_oracles/ — retrieved 2026-05-10 — Moody's negative outlook on Oracle, Baa2 rating, leverage trajectory toward ~4× EBITDA, single-counterparty risk flagged on the OpenAI book; some lenders pulling back from Stargate-tied financings.
[13] https://www.digitimes.com/news/a20251008PD224/oracle-cloud-computing-business-gross-margin-revenue.html — retrieved 2026-05-10 — Leaked internal Oracle docs: ~$900M GPU-rental revenue Q1 FY26 at 14% gross margin; loss of ~$100M on Blackwell rentals in the quarter; Stifel's 16% baseline expectation.
[14] https://www.tomshardware.com/tech-industry/artificial-intelligence/musks-spacex-has-rented-out-access-to-its-supercomputers-220-000-nvidia-gpus-and-300-megawatts-of-ai-compute-power-to-rival-anthropic — retrieved 2026-05-10 — xAI Colossus 1 (220k GPUs, 300 MW) rented to Anthropic; not via Oracle (used to source xAI-Oracle relationship; could not confirm).
[15] https://www.datacenterdynamics.com/en/news/oracle-to-deploy-cluster-of-more-than-130000-amd-mi355x-gpus/ — retrieved 2026-05-10 — Oracle 131,072-GPU AMD MI355X cluster live; AMD Helios (MI450 + Venice + Vulcano) committed for next-gen OCI clusters.
[16] https://www.g42.ai/resources/news/global-tech-alliance-launches-stargate-uae — retrieved 2026-05-10 — Stargate UAE: 1 GW cluster (200 MW first phase 2026) in Abu Dhabi 5 GW UAE-US AI campus; Oracle co-operator with OpenAI/G42/NVIDIA/SoftBank/Cisco.
[17] https://newsletter.semianalysis.com/p/ai-capacity-constraints-cowos-and — retrieved 2026-05-10 — CoWoS-L/HBM3e bottleneck through 2027; NVIDIA holds 60–70% of TSMC CoWoS capacity; CoWoS 50+ week lead times; HBM3e fully allocated, +15–22% YoY pricing.
[18] https://modoenergy.com/research/en/ercot-data-center-buildout-projection-load-forecast-senate-bill-six-gas-turbine-shortage — retrieved 2026-05-10 — ERCOT large-load queue >233 GW; PJM capacity prices >10× prior years; GE Vernova gas turbines sold out 2026–27; supply ramps 27→42 GW by 2027.
[19] https://www.oracle.com/cloud/multicloud-database-aws-google-azure/ — retrieved 2026-05-10 — Oracle DB@Azure (21 regions), DB@Google (11 regions), DB@AWS (5 regions, expanding to 25); Exadata co-located inside hyperscaler data halls.
[20] https://www.marketbeat.com/stocks/NYSE/ORCL/short-interest/ — retrieved 2026-05-10 — Short interest 29.34M shares, 1.73% of float, 1.0 day to cover, as of 2026-04-15.
[21] https://www.cnbc.com/2025/11/21/nvidia-gpus-google-tpus-aws-trainium-comparing-the-top-ai-chips.html — retrieved 2026-05-10 — Custom-silicon landscape: AWS Trainium2 500k+ deployed, Trainium3 2026; Microsoft Maia 200 (3nm, 216 GB HBM3e, >10 PFLOPS FP4); Google TPU v7 Ironwood + $10B+ Anthropic deal; Azure still ~70% NVIDIA.