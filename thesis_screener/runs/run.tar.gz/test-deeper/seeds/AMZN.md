All research complete. Synthesizing the dossier now.

```
# AMZN — Amazon.com, Inc.

## Where this sits in the AI stack
AWS operates simultaneously across nearly every layer of the AI stack: it designs custom silicon (Trainium2/3, Inferentia2, Graviton4) through Annapurna Labs in Israel [29][30]; runs the largest single cloud infrastructure for AI training and inference (~28% cloud share, $150B AWS run-rate at Q1 2026) [26][1]; operates Bedrock as a multi-model serving layer with frontier models from Anthropic, OpenAI, Meta, plus its own Nova [37]; and provides SageMaker HyperPod for training-cluster orchestration. The workload mix skews toward inference and model-serving rather than pure frontier pre-training — but Project Rainier (Indiana, ~1M Trainium2 chips) is now a frontier-training site for Anthropic's Claude [12][27]. Critically, AWS is *both* a NVIDIA reseller at scale (1M+ GPUs deploying 2026, including Project Ceiba's 20,736 B200s) and the largest hyperscaler custom-silicon program by unit count (~1.4M Trainium chips landed) [4][6].

## Snapshot
- **Price:** $272.68 (2026-05-08 close; May 9 was Saturday) [21]
- **Market cap:** ~$2.93T [21]
- **52-week range:** $196.00 – $278.56 [21]
- **Forward P/E:** ~33× FY2026 consensus EPS (~$7.73); ~27× FY2027 (~$9.40) [21]
- **EV / NTM revenue:** ~3.5× (derived: EV ~$2.84T / FY26 consensus rev ~$800B; no source publishes this directly — EV/LTM = 3.97×) [21]
- **Consensus 12-month price target:** $306 (StockAnalysis, 41 analysts; "Strong Buy"; +12.2% implied) [22]
- **YTD total return:** +17.86% [21]
- **Short interest (% of float):** 0.96% (FINRA 4/15/26 settlement) [21]

## Moat — what it is physically made of

Decomposed by component, with honest durability assessment:

**1. Trainium silicon program (durability: medium).** Annapurna Labs (Yokneam/Haifa, Israel; ~$350M acquisition 2015 [29]) plus design partners — Marvell on Trn2 front+back-end, Alchip on Trn3 back-end after Marvell execution issues on the Trn3 RDL interposer [35]. Trn2 is TSMC N5, 96 GB HBM3e, 2.9 TB/s memory bandwidth, 1.3 PF dense FP8, ~500W, ~$3.72/FP8-TFLOPS vs $3.91 on EC2-P6 NVIDIA Blackwell [4][34][15]. Trn3 is TSMC N3P, 144 GB HBM3e at 9.6 Gbps pin speed (highest HBM3e disclosed) [5][16], 2.52 PF FP8/chip, MXFP4 supported (Trn2 has none), 4.9 TB/s HBM, NeuronSwitch-v1 switched all-to-all (replacing Trn2's PCIe-Gen5 3D torus) [5]. Trn3 NL72x2 UltraServer = 144 chips / 362 PF FP8 / 706 TB/s HBM — at the system level approximately matches GB300 NVL72 on FP8 throughput but SemiAnalysis explicitly notes Trn3 is "much worse on FP4" [5]. AWS's competitive position is "good-enough at lower TCO," not best-in-class per chip.

**2. Custom networking (durability: medium).** Scalable Reliable Datagram (SRD) in Nitro hardware spreads each flow over up to 64 ECMP paths with proactive congestion control, ~10× p99 latency reduction vs TCP [44]. EFA v3 carries 3.2 Tbps per Trn2 instance / 12.8 Tbps per UltraServer [15]. NeuronLink-v3 is PCIe-Gen5 point-to-point torus at ~1 TB/s/chip — fundamentally cheaper than NVLink's switched fabric, but lower aggregate bandwidth per chip than NVLink5 (1.8 TB/s) [4]. NeuronLink-v4 doubles to 2.56 TB/s/chip with switches [5].

**3. Software/runtime (durability: weak-to-medium).** Neuron SDK supports PyTorch + JAX; NKI ("Neuron Kernel Interface") is a Triton-style tile-DSL released Sept 2024 in beta [42][43]. Anthropic engineers write low-level NKI kernels directly and report ~60% Tensor-Engine utilization on Trn2 / >90% on Trn3 [27][28]. But: this is a single-customer collaboration. The CUDA ecosystem has ~4M+ developers, ~15 years of cuDNN/cuBLAS/CUTLASS/Triton/TRT depth; Neuron has thousands of developers and effectively one frontier customer driving the kernel library. This is not durable in the CUDA sense.

**4. Compute capacity at scale (durability: strong).** $364B AWS backlog end-Q1 2026 (excludes the new $100B Anthropic deal); $225B+ Trainium-specific revenue commitments per Jassy on Q1 2026 call; Trainium3 already "nearly fully subscribed," much of Trainium4 reserved [2]. AWS chip business (Graviton + Trainium) >$10B annualized at triple-digit growth [3]. This is harder to displace than silicon design — multi-year customer contracts plus physical hall capacity.

**5. Power and grid (durability: very strong).** Amazon is the largest corporate clean-energy buyer globally, ~40+ GW contracted [7]. The Talen Susquehanna nuclear deal — initially behind-the-meter, twice rejected by FERC in 2024-25 — was restructured into a $18B / 17-year / 1,920 MW front-of-the-meter PPA closed in 2025 [14]. AWS anchored a $500M Series C-2 in X-Energy for SMR deployment scaling toward 5 GW by 2039 [32]. Project Rainier alone is 2.2 GW at full build [12][13]. These are 10-20 year contracts; near-impossible for a new entrant to replicate.

**6. Bedrock as the "AWS Marketplace of LLMs" (durability: strong).** 100,000+ companies running on Bedrock, multi-billion run-rate, +60% QoQ Q4 2025 [3]. Hosts Claude (Opus/Sonnet/Haiku), Llama, Mistral, DeepSeek, Nova, and OpenAI 5.4 (5.5 next) [37][24]. The strategic position is "multi-model neutral" vs Azure (OpenAI-led) and GCP (Gemini-led). The closest historical parallel is AWS's broader cloud-services moat: not best at any one thing, dominant on breadth. This is the most durable software-layer moat.

**7. Anthropic anchor — but now contested (durability: degrading).** $8B initial equity (2023-24) + up to $25B announced April 2026 → up to $33B total [9]. Anthropic's compute commitment to AWS: $100B over 10 years, up to 5 GW Trainium capacity [8]. BUT: Anthropic took $5B + $30B Azure compute Nov 2025; expanded to up to 1M Google TPUs / >1 GW / ~$200B over 5 years via Google + Broadcom (Oct 2025) [10][11][25]. **This is no longer an exclusive moat.** Anthropic is firmly multi-cloud. The Trainium commitment is contractually real but the frontier-lab capture narrative is broken.

## AI buildout bottleneck map

- **Power generation and grid interconnect:** **Beneficiary.** 40+ GW contracted; Talen 1.92 GW nuclear front-of-meter [7][14]; X-Energy SMR program [32]. Project Rainier 2.2 GW capacity online. Bottleneck for industry, locked in for AWS.
- **CoWoS-L advanced packaging:** **Exposed customer.** TSMC controls ~90% of CoWoS, sold through 2026 [40]. AWS uses CoWoS-S/R (Trn2) and CoWoS-R organic interposer (Trn3) [4][5]. CoWoS-L is the NVIDIA-allocated variant; AWS's R/S packaging is at lower capacity tier — less constrained but also lower performance ceiling.
- **HBM3e supply:** **Exposed customer.** Trn3 uses SK Hynix 12-Hi HBM3e at 9.6 Gbps and Micron — Samsung dropped due to underperformance [5]. SK Hynix had ~62% HBM share Q2 2025 [36]. Sold out 2026.
- **Optical interconnect:** **Indirect supplier dependency.** Marvell supplies DSPs and AECs for Trainium clusters; tight supply industry-wide. AWS's per-cluster optical demand is below NVIDIA NVL72 (less switching, lower scale-up density).
- **Liquid cooling >100 kW/rack:** **Catching up.** Trn3 NL72x2 is AWS's first >100kW/rack liquid-cooled deployment [5]. NVIDIA GB200 NVL72 ~120 kW/rack has been deployed at scale for ~12 months. AWS is 6-9 months behind on rack density.
- **Kernel/compiler talent:** **Exposed.** Neuron SDK lags CUDA. Anthropic is essentially the only frontier-lab customer writing NKI kernels at scale. If Anthropic reallocates kernel engineers to Google TPU/XLA, Trainium's software gap widens fast.
- **Frontier training data:** **Indifferent.** No AWS-specific position.

## Competitive teardown

**NVIDIA.** AWS is simultaneously NVIDIA's largest customer and competitor. EC2 P6-B200 / P6-B300 GA Nov 2025 (8× Blackwell Ultra, 2.1 TB HBM, 6.4 Tbps EFA) [15]. Project Ceiba = 20,736 B200 GPUs. AWS will deploy 1M+ NVIDIA GPUs in 2026, comparable in unit count to its 1.4M Trainium installed base. **Trn2 vs B200 per chip:** 1.3 PF FP8 vs 4.5 PF FP8; 2.9 TB/s HBM vs 8 TB/s; **no native FP4 on Trn2.** Trn3 closes the system-level gap on FP8 (NL72 vs NVL72 GB300) but lags on FP4 where inference is migrating [5]. AWS strategy is TCO not peak performance; durable as long as inference workloads tolerate FP8.

**Google TPU.** Most material competitor on technical axes. **TPU v7 Ironwood** (Nov 2025/GA April 2026): 4.6 PF/chip, 192 GB HBM3e, 9,216-chip superpod / 42.5 EFLOPS; SemiAnalysis assesses "nearly closes the gap to NVIDIA flagship on FLOPS, memory, bandwidth" [7]. **TPU v8** (announced Cloud Next April 2026): bifurcated 8t (training) / 8i (inference), TSMC 2nm, Virgo Network linking **134K TPUs/data-center and >1M TPUs across multiple sites in a single training cluster** [31]. Anthropic contracted for up to 1M TPUs / >1 GW / ~$200B over 5 years [10][11]. Google has fewer external TPU customers than AWS has Trainium customers — but the technical gap is now closed, and Anthropic has hedged.

**Microsoft Azure.** Lost OpenAI exclusivity January 2025 [17]. Maia 200 launched Jan 2026: TSMC 3nm, 216 GB HBM3e, ~10 PF FP4 — explicitly inference-only, not competing on training [18]. Cobalt 200: 132 Neoverse V3 cores, Graviton4 competitor. Microsoft **froze 1.5 GW of planned 2025-26 capacity** due to weaker internal demand. The Azure narrative inverted in 2025 — went from leading to defensive.

**Oracle.** Backlog $523B end-CY25, $300B OpenAI 5-yr deal (signed July 2025, activates 2027) [19]. Stargate program ~7 GW / ~$400B (OpenAI/SoftBank/Oracle/MGX — Microsoft excluded). Capex stepped to $50B/yr. From a rounding error in cloud rankings to a primary frontier-training provider in ~18 months. **This is the biggest single competitive surprise of 2024-25.**

**AMD MI400.** H2 2026 GA, CDNA 5. 40 PF FP4, 432 GB HBM4, 19.6 TB/s memory BW per GPU. OpenAI 6 GW MI450 deal (Oct 2025) [20]. Networking/scale-up fabric still behind NVIDIA NVLink. Not yet a credible Trainium replacement, but is a pricing pressure point on NVIDIA — indirectly compressing AWS's NVIDIA-resale GPU margins.

**Broadcom & Marvell.** Arms dealers to the anti-NVIDIA hyperscaler movement. Broadcom: Google TPU v7/v8, Meta MTIA v4 (1 GW, TSMC 2nm — world's first 2nm AI silicon [39]), targeting $60-90B AI revenue from 3 hyperscalers by FY27. Marvell: concentrated on AWS Trainium (Trn2 + partial Trn3+); lost the primary Trn3 socket to Alchip due to RDL interposer execution issues [35]. Marvell is the Trainium-supply-chain risk indicator: if Marvell loses more Trainium content, signals AWS silicon roadmap delays.

**CoreWeave.** NVIDIA-pure neocloud. 2025 revenue $5.13B → 2026 guidance $12-13B, $99.4B backlog Q1 2026, Microsoft 67% concentration declining as OpenAI ($22.4B) and Meta ($14.2B) ramp [23]. Not direct AWS competitor for general cloud but is the alternative path for frontier compute outside AWS's reach.

Base rate on technology displacement: In platform-shift cycles (CPU→GPU 2007-2020, x86→ARM in mobile/server 2010-2024, on-prem→cloud 2009-2020), incumbents with deep customer relationships have generally retained those customers through 2-3 generations of the new technology even when technically inferior, *unless* the anchor customer hedged credibly to an alternative. Apple's 2018-2020 move from Intel to TSMC/Apple Silicon is the closest cautionary base rate: anchor-customer defection compounded faster than analysts modeled. Anthropic hedging to Google TPU rhymes with that pattern.

## Bull case — technical

Required conditions:
1. **Inference dominates AI workloads through 2028,** scaling 5-10× current run-rate. Bedrock economics compound. AWS's "multi-model neutral" position becomes the LLM distribution layer.
2. **Trainium3 delivers in the field** — the SemiAnalysis claim of 30% better TCO/FP8 vs GB300 NVL72 holds in production, customers beyond Anthropic ramp by Q3 2026 (Apple beyond evaluation, Databricks production, OpenAI's 2 GW Trainium commitment ramps).
3. **Anthropic remains substantially on Trainium for serving** even if it splits training to Google TPU v8. Serving is the higher-revenue, higher-utilization workload. AWS only needs the inference half.
4. **Power and HBM3e supply tightness compound** — by 2027, Trainium fleet locked in with grid capacity becomes harder to replicate than the silicon itself.
5. **Marvell's Trn3 stumble was one-off, not structural.** Alchip executes the back-end, AWS roadmap stays on cadence (Trn4 announced Dec 2025 [33]).

Financial outcome: AWS 2026 revenue $170-180B (28% blended), $200B capex returns on >35% AWS operating margin sustained, backlog burns at $80-90B/yr through 2027. AMZN re-rates to $310-325.

## Bear case — technical

Required conditions:
1. **Anthropic training migrates to Google TPU v8/Virgo at scale.** The $33B equity becomes mark-to-market; the $100B Anthropic→AWS revenue depends on serving (lower margin than training). Anthropic's $30B+ 2026 run-rate (and growth toward $100B+) increasingly served on TPU [25].
2. **FP4 gap kills Trainium3 in inference.** Production inference workloads (which already dominate revenue) move to FP4 [5]. NVIDIA B300/Rubin and Google TPU v8 both have full-rate FP4. Trainium3 is forced into FP8 niches.
3. **Software/talent gap widens.** Anthropic reallocates kernel engineers to TPU/XLA. NKI kernel ecosystem stalls. Neuron SDK fades.
4. **$200B capex doesn't return.** Depreciation hits ~$25-35B/yr by 2028. If Trainium fleet utilization disappoints (Bedrock fails to scale beyond Anthropic + OpenAI subset), AWS operating margins compress to 30-32%.
5. **Synergy data accelerates.** Currently AWS +28% vs Azure ~+40% vs GCP +63% in Q1 2026 [26]. The AI-specific share gap is widest. If that compounds another 6 quarters, AWS becomes #2.
6. **OpenAI integration stays shallow.** The April 2026 Amazon-OpenAI deal layers in $50B equity + 2 GW Trainium [24], but OpenAI primary compute remains Oracle/Microsoft/CoreWeave. Amazon is the third or fourth cloud for OpenAI in practice.

Financial outcome: AWS 2027 growth decelerates to <20%, margins to 30%, capex sustains regardless. AMZN derates to $210-230.

## Market view check

At $272.68 and ~33× FY26 EPS, the stock prices AWS as a durable AI infrastructure compounder — consistent with the bull case's *first three* conditions but **not pricing the Anthropic-to-Google migration risk meaningfully.** Q1 2026 sell-side coverage barely mentioned that Anthropic's >1 GW / 1M-TPU Google commitment is substantively similar in magnitude to its AWS Trainium commitment. Consensus model assumes Anthropic stays primarily on Trainium for both training and serving; the public evidence is that Anthropic has explicitly diversified. The asymmetry has shifted: at $230 in late 2025 (before the April 2026 Amazon-OpenAI re-bundle), the bull case was substantially under-priced. At $272.68 it is mostly priced in; the bear case (anchor-customer hedge, FP4 gap, capex-return risk) is the cleaner asymmetry now. Not short here, not aggressive long — fairly valued with degrading moat narrative.

## 90-day falsifiers

1. **Anthropic's next frontier model (Claude Opus 5 or successor) — which silicon trains it?** TPU v8 = thesis weakens materially. Trn3 NL72 = thesis confirmed. This is the single highest-signal observable.
2. **AWS Q2 2026 capex (reports July 31, 2026).** If pace exceeds $50B/quarter or FY26 guide raised to $220-230B, signals Anthropic+OpenAI demand pulling forward. <$45B/quarter flatline signals utilization issues.
3. **AWS Q2 2026 revenue growth rate.** $40B+ Q2 = >30% growth, confirms ramp. <$39B = decelerating into Azure/GCP gap.
4. **Trainium3 NL72x2 customer scale-out beyond Anthropic by end-Q3 2026.** SemiAnalysis customer tracking or AWS disclosure of named non-Anthropic Trn3 production customer (Databricks, Apple, OpenAI 2 GW ramp). Absence = breadth concern.
5. **NVIDIA Rubin H2 2026 GA performance.** >2× Blackwell at FP4 widens Trainium gap; 30-40% bump keeps it manageable.
6. **TPU v8 external availability and Anthropic deployment ramp.** If 2+ frontier labs run training on v8 externally by Q3, Google solves its external-TPU access bottleneck.
7. **AWS-Marvell vs AWS-Alchip allocation on Trn4.** If Alchip captures Trn4 entirely (Marvell loses more content), signals AWS silicon roadmap depends on partner execution AWS doesn't control.
8. **Q2/Q3 disclosure on Trainium revenue commitment composition.** If the $225B figure is revealed to be heavily Anthropic-loaded, single-customer concentration risk becomes a sell-side talking point.

## What I could not verify

- AWS share of TSMC CoWoS-S/R/L capacity — SemiAnalysis estimates ~10-15% but not officially disclosed.
- AWS NVIDIA-to-Trainium ratio in actual FLOPS or HBM bytes served (only chip-count headlines).
- Trainium3 production yield and whether Dec 2025 GA means meaningful volume or limited EAP cohort.
- Real utilization of Project Rainier — "operational" 500K-1M chips ≠ utilized FLOPS.
- Independent verification of Anthropic's published kernel-utilization (60% Trn2, >90% Trn3); Anthropic-sourced claim only.
- Whether the $225B Trainium revenue commitment includes or excludes the Anthropic $100B; conflicting interpretations across coverage.
- No public MLPerf Training or Inference submissions exist for Trainium2 or Trainium3 in v5.0/v5.1 cycles. Independent head-to-head benchmarks limited to SemiAnalysis modeling.
- Inferentia2 deployment scale today — largely subsumed into Trainium2 marketing; no recent disclosure.
- Status of Apple Trainium2 evaluation — Apple confirmed Inferentia/Graviton production but Trainium evaluation status unchanged since re:Invent 2024.
- True economics of Talen restructured PPA — front-of-meter is grid-priced, less margin certainty than the rejected behind-the-meter ISA would have had.
- Anthropic's "5 GW" Trainium commitment timing — gating on Project Rainier completion (2027-28+) plus Trainium3/4 ramp; the headline is contractual, not operational.

## Sources

[1] https://ir.aboutamazon.com/news-release/news-release-details/2026/Amazon-com-Announces-First-Quarter-Results/ — Amazon Q1 2026 IR release — AWS rev $37.6B +28%, capex $44.2B, backlog $364B
[2] https://www.fool.com/earnings/call-transcripts/2026/04/29/amazon-amzn-q1-2026-earnings-call-transcript/ — Q1 2026 transcript — Jassy: $225B Trainium commitments, Trn3 nearly fully subscribed, AI run-rate >$15B
[3] https://www.fool.com/earnings/call-transcripts/2026/02/05/amazon-amzn-q4-2025-earnings-call-transcript/ — Q4 2025 transcript — Bedrock +60% QoQ, chip business >$10B run-rate
[4] https://newsletter.semianalysis.com/p/amazons-ai-self-sufficiency-trainium2-architecture-networking — SemiAnalysis Trn2 deep dive — chip arch, CoWoS-S/R, NeuronLink torus, ~500W, 2.9 TB/s HBM
[5] https://newsletter.semianalysis.com/p/aws-trainium3-deep-dive-a-potential — SemiAnalysis Trn3 deep dive — N3P, 144 GB HBM3e at 9.6 Gbps, MXFP4 support, FP4 gap vs GB300
[6] https://newsletter.semianalysis.com/p/amazons-ai-resurgence-aws-anthropics-multi-gigawatt-trainium-expansion — Anthropic multi-GW Trainium expansion economics
[7] https://newsletter.semianalysis.com/p/tpuv7-google-takes-a-swing-at-the — SemiAnalysis TPU v7 Ironwood — closes gap to NVIDIA flagship
[8] https://www.anthropic.com/news/anthropic-amazon-compute — Anthropic announcement of $100B compute, 5 GW Trainium
[9] https://www.cnbc.com/2026/04/20/amazon-invest-up-to-25-billion-in-anthropic-part-of-ai-infrastructure.html — Amazon +$25B Anthropic April 2026
[10] https://www.datacenterdynamics.com/en/news/google-and-anthropic-confirm-massive-1gw-cloud-deal-with-up-to-one-million-google-tpus/ — Anthropic 1M Google TPUs, >1 GW
[11] https://www.googlecloudpresscorner.com/2025-10-23-Anthropic-to-Expand-Use-of-Google-Cloud-TPUs-and-Services — Google press confirming Anthropic TPU expansion
[12] https://www.aboutamazon.com/news/aws/aws-project-rainier-ai-trainium-chips-compute-cluster — AWS Project Rainier description, Trn2 UltraServer cluster on EFAv3
[13] https://www.cnbc.com/2025/10/29/amazon-opens-11-billion-ai-data-center-project-rainier-in-indiana.html — Project Rainier $11B Indiana, 2.2 GW
[14] https://www.utilitydive.com/news/talen-amazon-aws-susquehanna-nuclear-data-centert/750440/ — Talen-Amazon $18B 17-yr 1,920 MW restructured PPA
[15] https://aws.amazon.com/ec2/instance-types/trn2/ — Trn2 instance specs, UltraServer specs, EFAv3 bandwidth
[16] https://aws.amazon.com/ec2/instance-types/trn3/ — Trn3 instance specs and UltraServer description
[17] https://www.cnbc.com/2025/01/21/microsoft-loses-status-as-openais-exclusive-cloud-provider.html — End of Microsoft-OpenAI cloud exclusivity
[18] https://blogs.microsoft.com/blog/2026/01/26/maia-200-the-ai-accelerator-built-for-inference/ — Maia 200 launch, inference-only, 216 GB HBM3e
[19] https://erp.today/oracle-loads-up-on-ai-infrastructure-as-oci-backlog-data-center-commitments-surge/ — Oracle $523B backlog
[20] https://techcrunch.com/2025/10/06/amd-to-supply-6gw-of-compute-capacity-to-openai-in-chip-deal-worth-tens-of-billions/ — AMD-OpenAI 6 GW MI450 deal
[21] https://stockanalysis.com/stocks/amzn/ — AMZN price/cap/52w/PE/short-interest data
[22] https://stockanalysis.com/stocks/amzn/forecast/ — AMZN consensus PT $306, 41 analysts
[23] https://investors.coreweave.com/news/news-details/2026/CoreWeave-Reports-Strong-First-Quarter-2026-Results/ — CoreWeave Q1 2026 $2.1B rev, $99.4B backlog
[24] https://www.tomshardware.com/tech-industry/amazon-invests-50-billion-in-openai — Amazon $50B OpenAI equity, 2 GW Trainium addition
[25] https://www.datacenterfrontier.com/machine-learning/article/55335703/inside-anthropics-multi-cloud-ai-factory-how-aws-trainium-and-google-tpus-shape-its-next-phase — Anthropic multi-cloud strategy analysis
[26] https://www.srgresearch.com/articles/cloud-market-share-trends-big-three-together-hold-63-while-oracle-and-the-neoclouds-inch-higher — Synergy Q1 2026 cloud share AWS 28%
[27] https://www.anthropic.com/news/anthropic-amazon-trainium — Anthropic-AWS Trainium engineering collaboration
[28] https://claude.com/blog/trainium2-and-distillation — Anthropic Trn2 kernel utilization disclosure
[29] https://en.wikipedia.org/wiki/Annapurna_Labs — Annapurna founding, acquisition, locations
[30] https://siliconangle.com/2024/11/27/amazons-secretive-ai-weapon-exclusive-look-inside-aws-annapurna-labs-chip-operation/ — Annapurna Labs Israel/Austin facilities, engineers
[31] https://techcrunch.com/2026/04/22/google-cloud-next-new-tpu-ai-chips-compete-with-nvidia/ — TPU v8 announcement, Virgo Network 1M+ TPUs
[32] https://introl.com/blog/nuclear-power-ai-data-centers-microsoft-google-amazon-2025 — AWS X-Energy SMR anchor investment, Dominion/EN MOUs
[33] https://www.nextplatform.com/2025/12/03/with-trainium4-aws-will-crank-up-everything-but-the-clocks/ — Trainium4 architecture preview
[34] https://www.nextplatform.com/cloud/2025/07/10/sizing-up-aws-blackwell-gpu-systems-against-prior-gpus-and-trainiums/1651108 — Per-FLOPS economics Trn2 vs B200/B300
[35] https://globaltechresearch.substack.com/p/marvell-mrvl-us-vs-alchip-3661-tt — Marvell vs Alchip on Trainium back-end execution
[36] https://news.skhynix.com/2026-market-outlook-focus-on-the-hbm-led-memory-supercycle/ — SK Hynix HBM share, 2026 supply outlook
[37] https://aws.amazon.com/bedrock/model-choice/ — Bedrock model catalog
[38] https://variety.com/2026/digital/news/amazon-q4-2025-earnings-capex-advertising-sales-1236653797/ — Amazon $200B FY26 capex guidance reaction
[39] https://siliconangle.com/2026/04/14/meta-doubles-partnership-broadcom-committing-1-gigawatt-custom-ai-processors/ — Meta-Broadcom MTIA v4 1 GW deal
[40] https://info.fusionww.com/blog/inside-the-ai-bottleneck-cowos-hbm-and-2-3nm-capacity-constraints-through-2027 — TSMC CoWoS allocation concentration
[41] https://newsletter.semianalysis.com/p/huawei-ai-cloudmatrix-384-chinas-answer-to-nvidia-gb200-nvl72 — Huawei CloudMatrix 384 details, HBM bottleneck
[42] https://aws.amazon.com/about-aws/whats-new/2024/09/aws-neuron-nki-nxd-training-jax/ — Neuron 2.20 NKI, NxD, JAX release
[43] https://awsdocs-neuron.readthedocs-hosted.com/en/latest/nki/get-started/about/index.html — NKI architecture and programming model
[44] https://assets.amazon.science/a6/34/41496f64421faafa1cbe301c007c/a-cloud-optimized-transport-protocol-for-elastic-and-scalable-hpc.pdf — Amazon Science SRD protocol paper
```