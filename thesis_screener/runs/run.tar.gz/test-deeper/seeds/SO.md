# SO — The Southern Company

## Where this sits in the AI stack
SO is a vertically integrated, regulated electric utility holding company operating Georgia Power, Alabama Power, Mississippi Power, and Southern Company Gas, with ~44 GW of generation [6], own transmission inside its SERC service territory, and the only two new-build U.S. AP1000 reactors (Vogtle 3 & 4) in commercial operation [4][6]. It does not sell silicon, packaging, or runtime — it sells the binding upstream input to AI training and inference: utility-scale firm electricity, delivered behind a regulated monopoly franchise, in the geography (metro Atlanta, central Georgia, Mississippi I-20 corridor) where U.S. data-center load growth is currently most concentrated outside Northern Virginia [2][12].

## Snapshot
- **Price:** $91.80 (2026-05-08 close) [1][9]
- **Market cap:** $103.49B [9]
- **52-week range:** $83.09 – $100.84 [13]
- **Forward P/E:** 20.05× (on FY26 mid-point adj. EPS $4.55) [9][14]
- **EV / NTM revenue:** 6.30× (EV $178.51B; net debt $75.0B) [9]
- **Consensus 12-month price target:** $101.71 (implied +10.8%) [3]
- **YTD total return:** ~flat (price within ±2% of YE-2025; 200-day MA $92.69) [9] — exact figure not retrieved
- **Short interest (% of float):** 2.23% [9]

## Moat — what it is physically made of
The moat is not "regulated utility" as a category. Many utilities are regulated and earning sub-9% ROEs. SO's moat is the **specific overlap of four physical and institutional facts** that, together, make it one of perhaps three franchises in the country that can deliver multi-GW of new firm capacity to a hyperscaler on a 36–60 month horizon.

**1. Vertically integrated franchise inside SERC, not PJM/MISO.** SERC is not an organized RTO; each utility runs its own interconnection process [11]. PJM's interconnection-to-COD timeline has stretched from <2 years in 2008 to >8 years in 2025 [22]. Georgia Power's 2025 IRP — five new combined-cycle units at Bowen (1,482 MW), Wansley (1,453 MW), and McIntosh (757 MW), plus 11 BESS facilities, totaling ~9,885 MW — was filed, contested, and approved by the Georgia PSC inside ~9 months [10][16]. A hyperscaler signing a load contract with Georgia Power gets one regulator (PSC), one transmission owner (SO), one generation operator (SO subsidiaries) — a vertically integrated single point of decision. In PJM that same load needs RTO interconnect study, transmission owner coordination, separate generator developer, and FERC-jurisdictional rate filings.

**2. Vogtle 3 & 4 — paid-for clean baseload at a regulator that already approved cost recovery.** Units 3 (COD July 2023) and 4 (COD April 2024) make the Vogtle site the largest clean-energy generator in the U.S. [6]. Cost was a disaster for ratepayers — $36B total versus ~$14B initial estimate, with $7.56B of overruns shifted to ratepayers via 25% combined rate hikes [4][20]. From an *equity holder* perspective this is ex-post free option on AI demand: the assets are in rate base, earning the PSC-allowed 9.5–11.9% ROE band [21], and now also collecting IRA §45J zero-emission nuclear credits (Georgia Power began receiving 45J credits in late-2023 / early-2024 [8]). Replacement cost of ~2.2 GW of new clean baseload at current costs is uncomputable because no one is building AP1000s in the U.S. — there is no comparable asset a competitor could replicate within a decade.

**3. Existing physical infrastructure: substations, rights-of-way, gas interconnects, water rights.** This is the under-appreciated piece. Mississippi Power delivered ~500 MW to Compass Datacenters' $10B Lauderdale County campus partly because the I-20/59 industrial park already had substation footprint and gas interconnect [12]. Alabama Power *acquired* a 900-MW gas plant rather than building one, to compress time-to-power [12]. The moat is not a single asset but the option-bundle of brownfield sites with permitted air, water, gas, and transmission already in place. Greenfield equivalents face FERC §1222, NEPA, and 5+ year right-of-way litigation.

**4. PSC-approved cost-recovery mechanisms specifically for large-load build.** The December 2025 PSC unanimous approval includes a 6,000–8,500 MW band with quarterly Large Load Economic Development Reports — a regulatory framework designed to let SO file, recover, and earn on incremental data-center capex without a full rate case each cycle [2][15][16]. Georgia Power earned a 13.69% ROE in 2022 against an allowed top-of-band of 11.9% [21]; the regulator allowed the over-earning. This is structurally bullish if it persists — and the political risk to it is exactly what the bear case turns on (see below).

**Decomposition of moat durability:**
- Vogtle 3/4 nameplate and rate-base inclusion: **very durable** (15–30 yr).
- Vertically integrated single-point-of-decision in SERC: **durable** absent FERC-mandated RTO formation in the Southeast (no near-term path).
- Brownfield siting bundle: **durable** (regulatory complexity is the moat).
- PSC allowed-ROE band and cost-recovery mechanisms: **politically contingent** (see Nov 2026 PSC election).

There is no software or kernel-library moat to assess here. The moat is steel, copper, water rights, and political capital.

## AI buildout bottleneck map
The actual gating constraints on the U.S. AI buildout over the next 24 months, with SO's position vs. each:

- **Power generation capacity (gas turbine OEM throughput).** GE Vernova ~55 GW backlog; Siemens Energy €136B record backlog; OEMs adding capacity from ~50 to ~80 heavy-duty units/yr by end of 2026 [19]. Installed CCGT cost has roughly doubled to $2,000–$2,500/kW [19]. **SO is exposed but advantaged** — GE turbines for Plant Yates Unit 9 have already been delivered [10], and Bowen/Wansley/McIntosh slots are presumably ordered. New entrants cannot pull turbines forward.
- **Power transmission and interconnect.** PJM 8+ year timelines; SERC utility-by-utility processing in ~2–4 yrs [11][22]. **SO is a constraint owner, not a victim** — controls interconnect studies on its own grid.
- **Grid interconnection queue (generation side).** Bottleneck for would-be merchant generators trying to sell into wholesale markets. **SO sidesteps this** because it self-builds for native load under its IRP.
- **Advanced packaging (CoWoS-L) and HBM yield.** Constrains GPU shipments. **SO indifferent** — affects the demand pull, not SO's supply-side position. A demand reset would, however, hurt SO's contracted-pipeline conversion.
- **Liquid cooling at >100kW/rack.** Affects DC operator capex per MW; raises useful work per delivered MW, marginally negative for utility kWh demand per GPU. **SO indifferent / slightly negative**.
- **Optical interconnect supply (transceivers, fiber).** **Indifferent.**
- **Electrical contractor / linemen capacity.** Real and binding for substation buildouts. **SO exposed alongside everyone**, mitigated by long-standing in-region trade relationships.
- **Training data quality at the frontier.** **Indifferent.**
- **Hyperscaler capex itself.** This is the demand variable. SO's 23 GW contracted/late-stage pipeline [17] is essentially a leveraged bet on hyperscaler capex through 2030. A capex reset is the central bear-case trigger.

Net: SO is a *constraint owner* on the grid-interconnect axis and an *advantaged customer* on the turbine axis. The constraints that matter most to SO are political (PSC composition) and macro (hyperscaler capex), not physical bottlenecks.

## Competitive teardown
SO does not compete with NVIDIA or Constellation in the obvious sense — it competes with other U.S. utilities for the *siting decision* of hyperscaler campuses, and with merchant generators (and behind-the-meter colocation models) for the *power-procurement structure* hyperscalers choose.

- **Dominion (D) — Northern Virginia.** Direct competitor for hyperscaler siting. ~40 GW pipeline as of Dec 2024 vs. 21 GW prior July, ~88% sequential growth [18]. PJM zone, summer peak +23% since 2019 [18]. Capex $50.1B 2025–2029 [18]. **D is ahead on cumulative connected MW; SO is ahead on time-to-power for new sites** because Northern Virginia has saturated transmission and Virginia's SCC approved (Nov 2025) a new data-center rate class requiring 85% of contracted T&D and 60% of generation demand pre-paid [18] — pricing that pushes marginal new load to other geographies. Atlanta is the obvious second choice, which is why SO's pipeline is growing.
- **Duke (DUK) — Carolinas.** Adjacent SERC franchise, similar vertically integrated regulated structure. Comparable structural advantages. **DUK is a peer, not a displacer.** Real question is incremental siting share inside the Southeast, where SO appears to be winning Mississippi (Compass) and central Georgia (multiple unnamed hyperscaler sites in the 23 GW pipeline).
- **Constellation (CEG) — merchant nuclear.** 32.4 GW nuclear fleet, Microsoft TMI restart (Crane CEC, 835 MW), Meta Clinton 20-yr PPA [5][7]. CEG closed Calpine acquisition March 2026 ($16.4B), bolting nuclear onto premier gas/geothermal [7]. **CEG is a different business model** — merchant generator selling under long-dated contracted PPAs, exposed to wholesale prices on the unsigned portion. CEG wins the *behind-the-meter / colocation* path that the FERC December 2025 PJM order opened up [23]. SO wins the *front-of-meter regulated rate-base* path. Hyperscalers will use both.
- **Vistra (VST).** ~38.7 GW ERCOT-heavy, in active hyperscaler co-location discussions at Comanche Peak [5]. **Different geography, different model** (ERCOT energy-only, no capacity market until recently). Not a direct competitor for SO's load.
- **NextEra (NEE).** Largest renewables developer; primarily competes via supplying solar+storage PPAs to hyperscalers regardless of utility. **Indirect competitor** — share gain by NEE on the renewables-procurement side does not directly take share from SO's regulated rate-base growth.

The honest competitive concern is structural, not company-specific: if hyperscalers shift mix toward behind-the-meter colocation (CEG/VST/Talen model) or onsite gas turbines (the SemiAnalysis "onsite gas" thesis [referenced in primary VC note 19]), then SO's regulated rate-base growth thesis decays even with strong national AI capex. The December 2025 FERC PJM colocation order [23] has not yet been replicated in SERC, but is the template that would get exported.

## Bull case — technical
The technical conditions for SO outperformance:

1. **Hyperscaler training+inference capex sustains at announced trajectories** (Microsoft, Meta, Google, Amazon ~$300B+/yr combined 2025–2027). The 23 GW SO pipeline converts to >70% signed long-term contracts under SO's standard rate structure (paid-demand floors per the 2025 PSC stipulation) [16][17].
2. **Gas turbine supply remains the binding national bottleneck through 2027–28** [19]. SO's already-secured turbine slots (Yates 9 delivered, Bowen/Wansley/McIntosh ordered [10][16]) become a non-replicable advantage versus utilities that file IRPs in 2026–27.
3. **PJM colocation rules do not propagate to SERC** before 2027; SO captures the front-of-meter regulated structure for the bulk of new Southeast siting.
4. **Georgia PSC composition stays Republican-majority** through Nov 2026 election; allowed-ROE band stays 9.5–11.9%; over-earning continues to be permitted [21].
5. **Vogtle 3/4 capacity factor remains >90%** and 45J PTC continues to flow [8].

Financial mechanics if those hold: $81B 2026–2030 capex [14] at ~58% equity-funded into a rate base earning ~10.5% midpoint ROE → 8% adjusted EPS CAGR through 2030 (consistent with management guidance of 8–9% to 2028, 7–8% thereafter [14]). At sustained 20× forward P/E the stock compounds at high-single-digits + 3.3% yield = ~12–13% total return — not a moonshot, but a high-Sharpe utility that re-rates from 18× to 22× as the market accepts the load-growth durability.

**Base rate caveat:** technology-driven displacement of utility load (cogeneration, on-site solar, distributed gas) has historically been slow — measured in decades, not quarters. The CPU→GPU shift took ~15 years to fully commit. The on-prem→cloud shift was ~12 years to majority share. Even if hyperscaler colocation is the future, the regulated-utility offtake path remains the dominant structure for at least the next 5–7 years simply because it is faster to permit.

## Bear case — technical
The version a short-seller who reads PSC dockets would write:

1. **The Nov 2026 Georgia PSC election flips control 3-2 Democratic** (Democrats won both 2025 seats — first statewide office wins since 2006 [24]). Both 2026 candidates from both parties are running on "clawback" rhetoric of the $16B authorization [24]. Even partial clawback — disallowing a portion of CCGT capex from rate base, or compressing the 9.5–11.9% ROE band toward the 9.5% national average — meaningfully resets SO's 8% EPS CAGR.
2. **Hyperscaler capex resets in 2026–27** as scaling-law efficiency gains (FP4 inference, sparse MoE training, distillation) reduce kWh-per-useful-token. The 23 GW pipeline includes ~12 GW in "latent" stage [17] — non-binding LOI-level commitments. A 30–40% pipeline cancellation rate would leave SO's CCGT build over-sized for actual load, and the regulator would have to choose between stranding the assets or socializing the cost across residential ratepayers.
3. **FERC propagates the December 2025 PJM colocation framework to SERC** [23], either via complaint or NOPR. Hyperscalers shift new siting to behind-the-meter colocation at existing nuclear or new merchant gas, bypassing SO's regulated franchise.
4. **CCGT inflation eats the rate-base thesis.** Installed costs at $2,000–$2,500/kW [19] versus historical $1,000/kW means rate base grows but customer bills grow proportionally; political pushback compresses the allowed-ROE band or forces formula-rate concessions.
5. **Coal extension creates stranded-asset and ESG-funded-cost risk.** Bowen extended past 2034, Scherer to 2038, Daniel and Gaston extended [25]. If carbon regulation tightens or hyperscalers (under their own net-zero commitments) refuse coal-blended supply, SO either accelerates retirement (writedown) or loses contracts.
6. **Vogtle was 2× over budget on a fleet that had built a dozen comparable units globally; the Bowen/Wansley/McIntosh CCGT builds are happening in a turbine-supply-constrained market with first-time EPC inflation.** Pattern recognition says cost overruns are likely. Under construction work-in-progress accounting they hit ratepayers, but political tolerance is finite — and the PSC composition is changing.

## Market view check
At $91.80, 20× forward EPS, and 6.3× EV/NTM-revenue [9], SO trades at a meaningful premium to the regulated utility universe (sector median forward P/E ~16–18×) and to its own pre-AI-narrative average (~16× during 2018–2022). The market is therefore pricing in some — but not all — of the data-center thesis. With the consensus PT at $101.71 (+10.8%) and a hold rating from 16 analysts [3], sell-side is positioning for in-line returns. The asymmetry I see is primarily on the political axis: the multiple does *not* appear to fully discount the Nov 2026 PSC election downside, nor does it fully price the optionality on the 12 GW of "latent" pipeline converting to firm. This is a name where the technical thesis is roughly consensus on the bull side, contested on the political side, and the right framing is less "is this a great buy" than "is this 12-month volatility around a 5-year compounder you want to own through the election."

## 90-day falsifiers
- **Q2 2026 earnings call (late July): large-load contracted MW.** Bull confirms if pipeline moves >2 GW from latent to signed; bear confirms if any signed contracts cancel.
- **Georgia PSC primary results May 19, 2026** [24]: candidate field for Nov 2026 narrows; if reform-aligned challengers lead in fundraising/endorsements, multiple compression risk increases.
- **Any FERC filing or NOPR extending the PJM colocation framework to SERC.** Would re-rate the bear case meaningfully.
- **GE Vernova / Siemens Energy guidance updates on 2027–28 turbine slot availability.** Tightening reinforces SO's already-secured-slot moat; loosening compresses it.
- **A specific hyperscaler announcement of behind-the-meter co-location at a non-SO Southeast site** (e.g., Duke, Santee Cooper, TVA territory) — would falsify the "front-of-meter regulated path is the only option in SERC" assumption.
- **Quarterly Large Load Economic Development Report** filings to GA PSC (mandated under the Dec 2025 stipulation [16]). Watch for downward revisions in MW commitments.

## What I could not verify
- Exact YTD return for SO (Dec 31 2025 close not retrieved; estimated approximately flat from 200-day MA and current price proximity).
- Counterparty identities and credit terms behind the 23 GW pipeline. SO discloses aggregates only ("high credit quality hyperscalers" [17]); I could not source the per-customer split (Microsoft vs Google vs Meta vs Amazon vs colos).
- Whether SO's CCGT EPC contracts at Bowen/Wansley/McIntosh are fixed-price or cost-plus — material to the inflation pass-through risk.
- The capacity factor and forced-outage rate for Vogtle 3 in its first 22 months (commercial operation since July 2023 [4]); AP1000 fleet outside U.S. has had mixed early-life reliability.
- Exact composition of "latent" vs "signed" within the 23 GW pipeline figure; 11 GW signed implies 12 GW non-binding [17] but no public detail on stage-gating.
- Whether SO has any behind-the-meter or colocation-style filings prepared as a hedge against the FERC-PJM precedent migrating to SERC.
- Specific transmission constraint analysis inside SO territory — the "constraint owner" framing assumes SO's intra-territory transmission is not itself congested for new loads of 500+ MW; I could not confirm with primary planning data.

## Sources
[1] https://finance.yahoo.com/quote/SO/ — retrieved 2026-05-10 — current SO price and quote data, $91.80 close on 2026-05-08.
[2] https://www.utilitydive.com/news/georgia-power-irp-coal-gas-plants-data-centers/753170/ — retrieved 2026-05-10 — Georgia Power 2025 IRP keeps coal plants online to serve data centers, 83% of large load is data centers.
[3] https://stockanalysis.com/stocks/so/forecast/ — retrieved 2026-05-10 — analyst PT consensus $101.71 (high $114, low $81).
[4] https://en.wikipedia.org/wiki/Vogtle_Electric_Generating_Plant — retrieved 2026-05-10 — Vogtle 3 COD July 2023, Vogtle 4 COD April 2024, $36B total cost.
[5] https://www.tikr.com/blog/constellation-energy-vs-vistra-which-nuclear-powered-utility-has-more-upside — retrieved 2026-05-10 — CEG 32.4 GW nuclear fleet; VST 38.7 GW capacity.
[6] https://www.southerncompany.com/content/dam/southerncompany/sustainability/pdfs/diverse-energy-portfolio/resource-planning-electric-operations-fact-sheet.pdf — retrieved 2026-05-10 — 44 GW generation; 49% gas / 18% coal / 19% nuclear / 14% renewables 2024 mix.
[7] https://markets.financialcontent.com/stocks/article/marketminute-2026-3-10-constellation-energy-finalizes-164-billion-calpine-acquisition-solidifying-lead-in-ai-data-center-power-race — retrieved 2026-05-10 — CEG closed Calpine $16.4B March 2026.
[8] https://iratracker.org/programs/ira-section-13105-zero-emission-nuclear-power-production-tax-credit/ — retrieved 2026-05-10 — IRA §45U/§45J nuclear PTC mechanics; Georgia Power began receiving 45J credits late-2023.
[9] https://stockanalysis.com/stocks/so/statistics/ — retrieved 2026-05-10 — market cap $103.49B, EV $178.51B, fwd P/E 20.05, EV/Rev fwd 6.30, net debt $75.02B, beta 0.36, short interest 2.23%, dividend yield 3.31%.
[10] https://www.georgiapower.com/news-hub/press-releases/turbine-generator-unit-9-plant-yates.html — retrieved 2026-05-10 — first GE turbine delivered to Plant Yates Unit 9.
[11] https://epeconsulting.com/epe-intelligence/news/navigating-sercs-q1q2-2025-interconnection-windows-what-developers-need-to-know — retrieved 2026-05-10 — SERC each utility runs own interconnection rules; multi-year study timelines.
[12] https://www.southerncompany.com/miscellaneous-pages/2025-year-in-review.html — retrieved 2026-05-10 — Mississippi Power Compass Datacenters $10B Lauderdale County; Alabama Power 900 MW gas plant acquisition.
[13] https://www.marketbeat.com/stocks/NYSE/SO/ — retrieved 2026-05-10 — 52-week range $83.09 – $100.84.
[14] https://markets.financialcontent.com/stocks/article/finterra-2026-2-19-the-ai-utility-southern-company-so-and-the-new-energy-tsunami — retrieved 2026-05-10 — $81B capex 2026–2030, FY26 EPS $4.50–$4.60, 8–9% LT growth target.
[15] https://perkinscoie.com/insights/blog/georgia-public-service-commission-approves-georgia-powers-major-generation-expansion — retrieved 2026-05-10 — PSC approval of major generation expansion specifically for data center load.
[16] https://georgiarecorder.com/2025/12/19/georgia-regulators-approve-massive-power-grid-expansion-to-serve-data-centers/ — retrieved 2026-05-10 — December 2025 PSC unanimous approval; 9,885 MW of new resources; 6,000 MW min / 8,500 MW max band; 5 CCGT units (Bowen, Wansley, McIntosh) and 11 BESS facilities.
[17] https://news.alphastreet.com/the-southern-company-so-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q1 2026 earnings: data center consumption +42% YoY, 23 GW contracted/latent, 1.9 GW recent hyperscaler additions, adj EPS $1.32.
[18] https://www.datacenterdynamics.com/en/news/dominion-reports-high-data-center-demand-in-northern-virginia-proposes-new-electricty-rates-for-large-load-customers/ — retrieved 2026-05-10 — Dominion 40 GW pipeline Dec 2024; $50.1B 2025–29 capex; VA SCC Nov 2025 new rate class requires 85% T&D / 60% generation pre-pay.
[19] https://www.primary.vc/articles/the-gas-turbine-bottleneck-reshaping-energy-infrastructure-ex8qe — retrieved 2026-05-10 — GE/Siemens/Mitsubishi 5-yr backlogs; Siemens Energy €136B backlog; CCGT installed cost $1k → $2.0–2.5k/kW.
[20] https://www.utilitydive.com/news/after-2-years-ratepayer-pain-political-fallout-georgia-nuclear-vogtle/817792/ — retrieved 2026-05-10 — Vogtle ratepayer rate increases (7.8% then 15.9% = ~25% combined) and political fallout.
[21] https://www.georgia-ces.org/2022-rate-case — retrieved 2026-05-10 — GA PSC allowed-ROE band 9.5%–11.9%; actual 13.69% in 2022.
[22] https://rmi.org/pjms-speed-to-power-problem-and-how-to-fix-it/ — retrieved 2026-05-10 — PJM interconnection timeline rose from <2 yrs (2008) to >8 yrs (2025).
[23] https://introl.com/blog/ferc-data-center-power-plant-colocation-december-2025 — retrieved 2026-05-10 — FERC Dec 18, 2025 unanimous order directing PJM to establish colocation rules; three new transmission service options.
[24] https://www.ajc.com/politics/2026/04/power-bills-data-centers-dominate-republican-georgia-psc-debate/ — retrieved 2026-05-10 — Nov 3, 2026 PSC election; Democrats won both 2025 seats; bipartisan "clawback" rhetoric on $16B authorization; staff estimates $50B+ ultimate cost.
[25] https://energyandpolicy.org/southern-company-extends-life-of-coal-plants-to-power-data-centers-appears-to-abandon-net-zero-goal/ — retrieved 2026-05-10 — Plant Bowen extended past 2034; Plant Scherer to 2038; Plant Daniel and Gaston extensions to serve data center load.