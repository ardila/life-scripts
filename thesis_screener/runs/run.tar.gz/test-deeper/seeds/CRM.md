I have sufficient research. Writing the dossier now.

# CRM — Salesforce, Inc.

## Where this sits in the AI stack
Salesforce sits at the **application and orchestration layer** of the AI stack — specifically the *workflow-of-record* layer for sales, service, marketing, and back-office processes — not at the silicon, packaging, networking, or foundation-model layer. It is a **consumer** of inference compute, not a supplier of it. Its proprietary AI artifacts are: (1) the **Atlas Reasoning Engine**, a hybrid orchestration layer that routes a query through 8–12 specialist models, retrieval, and tool calls in a ReAct loop [4]; (2) **Data Cloud / Data 360**, a federated customer-data plane with zero-copy connectors into Snowflake/Databricks/BigQuery [3]; and (3) **Agentforce**, a deterministic-plus-probabilistic agent framework that bolts on top of CRM, Service, Slack, and (post-November-2025) Informatica metadata/governance [10][2]. The underlying foundation models are largely third-party (Anthropic Claude, OpenAI, Google) hosted within Salesforce's "trust boundary" VPCs [9]. Workload mix is overwhelmingly **enterprise inference, real-time + batch**, not training.

## Snapshot
- **Price:** $180.43 (2026-05-08 close) [1]
- **Market cap:** ~$148.7B [1]
- **52-week range:** $163.52 – $296.05 (low 2026-04-10; high 2025-05-14) [11]
- **Forward P/E:** 13.9× (on FY27 consensus EPS, vs. trailing 23.6×) [5]
- **EV / NTM revenue:** ~3.0× (EV ~$140B / FY27 guide midpoint $46B) [5][14] — inference, since explicit EV/NTM sales is not commonly reported for CRM at this multiple
- **Consensus 12-month PT:** ~$261 (range $190–$400, n=35; implied +45% from price) [5]
- **YTD total return:** −26% to −30% (worst-performing megacap software name 2026 YTD) [12][16]
- **Short interest (% of float):** 2.46% (low; not a contested-short situation) [13]

## Moat — what it is physically made of
CRM's moat is **software and contractual**, not physical. It does not own fabs, packaging slots, HBM contracts, optical inventory, grid capacity, or kernel-level differentiation. Decomposed:

1. **Metadata/declarative platform lock-in (durable, ~5–10 years).** Customers build on a proprietary metadata model with Apex, Flow, Lightning Web Components, Visualforce, custom objects, sharing rules, and validation logic. A typical Fortune-500 Salesforce org has 5,000–50,000 custom metadata items accumulated over a decade. Replatforming costs run into 8–9 figures and 18–36 months. This is the hard part of the moat. *Falsifier:* an LLM-driven "metadata-to-anything" migration tool that compresses migration to weeks at <$1M; not yet credible.

2. **Customer data gravity via Data Cloud (medium durability).** 32T records ingested in Q3 FY26, 15T via zero-copy (+341% YoY) [3]. Zero-copy is genuinely useful — federated queries into Snowflake/Databricks rather than copies — but it is also a *commoditizing* technology: it explicitly accepts that customer data may live in Snowflake or Databricks, weakening Salesforce's claim to be the system of record for that data. The unification *layer* is sticky; the *storage* is not.

3. **AppExchange / ISV + AgentExchange ecosystem (medium).** ~7,000 listed apps and a developer base measured in the high-single-million certifications. AgentExchange (2026) tries to make this a flywheel for agent skills [17]. This is a legitimate network effect, but ISV ecosystems have moved before (Lotus Notes, BlackBerry); they are not load-bearing on the scale of CUDA's developer base.

4. **Multi-year contracts / cRPO (mechanical, 12–36 months).** $35.1B cRPO +16% YoY, $72B total RPO +14% [14]. This guarantees revenue continuity but does not guarantee *renewal at growing ACV* in an AI agent world where seat counts are under pressure (see bear case).

5. **Slack as a workflow surface (contested).** Slack ($27.1B acquisition, 2021) is being repositioned as the "agentic surface" — Slackbot powered by Claude, Agentforce agents native in Slack [10]. This is genuinely interesting *if* Slack wins the enterprise chat-as-OS battle, but it is losing that battle to Microsoft Teams in seats and bundle economics.

6. **What the moat is NOT:** It is not foundation-model IP (those are licensed from Anthropic/OpenAI). It is not silicon, networking, or compute. It is not even an inference-cost advantage — Salesforce pays retail-ish rates for tokens and resells with markup. The $2/conversation and Flex Credits pricing models are explicit pass-throughs of token economics [8].

**Base rate on application-layer SaaS moats during platform transitions:** historically poor. Lotus, Siebel (the company Salesforce displaced), BlackBerry, and Oracle's apps stack all saw moats compress within 3–7 years of the underlying platform shifting beneath them. The CUDA/NVIDIA-style "10-year impregnable" moat does not generalize to application SaaS. Default prior: meaningful erosion within 5 years unless the company captures the new platform layer itself.

## AI buildout bottleneck map
CRM's relationship to the physical bottlenecks of the 2026 AI buildout is mostly **indifferent or mildly negative**, not beneficiary:

| Bottleneck | CRM's position |
|---|---|
| **Power generation / grid interconnect** | Indifferent. Salesforce runs on Hyperforce (AWS, GCP, Azure). Hyperscaler power problems → higher inference COGS for CRM, slight negative. |
| **CoWoS-L advanced packaging** | Indifferent / mild negative. Tight packaging keeps Blackwell/MI400 supply rationed → token prices stay higher → Agentforce gross margin pressure. |
| **HBM3e/HBM4 supply** | Indifferent / mild negative (same mechanism). |
| **Optical interconnect / 800G–1.6T pluggables** | Irrelevant. |
| **Liquid cooling >100kW/rack** | Irrelevant. |
| **Frontier training data quality** | Irrelevant — Salesforce does not train frontier models. They fine-tune small models and use the Trust Layer for grounding. |
| **Kernel/compiler talent (CUDA, Triton, ROCm)** | Irrelevant. |
| **Enterprise data integration / governance** | **Beneficiary and supplier.** The Informatica acquisition ($8B, closed Nov 2025) [7] explicitly targets the data-prep/governance bottleneck for agent grounding. This is the one segment of the bottleneck map where CRM is structurally long. |
| **Application-layer AI orchestration talent** | Beneficiary as a tooling vendor (Agent Builder, Vibes IDE, Agent Script). |

The honest read: **CRM is not exposed to the physical bottlenecks that drive the NVIDIA/TSMC/utilities thesis.** Its AI exposure is downstream — it benefits if and only if enterprise *application-layer* spend on agents materializes, regardless of whether the buildout is constrained by power or packaging. This makes it a poor proxy for AI infrastructure tightness and a fairer proxy for *enterprise AI software-budget conviction*.

## Competitive teardown

**Microsoft (Dynamics 365 + Copilot for Sales/Service).** The structural threat. Microsoft's axis of attack is *bundle and distribution*, not feature parity. Copilot for Sales is included in Dynamics 365 Sales Premium at $150/seat [6]; Salesforce sells AI as add-ons, with Agentforce conversation pricing at $2/conversation or Flex Credits [8]. Microsoft 365 Copilot crossed 20M paid seats in April 2026, +33% from 15M in January [15] — that is the largest installed base of business-context-aware AI in the enterprise. Dynamics 365 holds ~7–9% CRM share to CRM's ~24% [6], but Microsoft's growth rate (cited 40% YoY in financial services/healthcare per their disclosures) and the bundle math mean share of *new logos* is what matters. **Where Microsoft already has parity:** broad SOC2/governance, audit, data residency. **Where they trail:** vertical clouds (FSC, Health Cloud), depth of Sales Cloud workflow customization. **What would have to be true for them to take share:** Copilot Studio agents need to demonstrate parity with Agentforce on cross-CRM-object workflows in enterprise references — partially true today.

**ServiceNow.** Encroaching from workflow side. Knowledge 2026 announcements [16-equiv] expanded "AI specialists" across CRM, HR, IT, procurement. ServiceNow's lead in the *workflow* fabric (vs. Salesforce's lead in the *data*) means the two are converging from opposite directions. ServiceNow's per-seat pricing is higher; deal economics make it primarily a threat in service-cloud-adjacent and back-office automation rather than core sales-rep CRM.

**HubSpot.** Mid-market threat moving up. Spring 2026 release added Breeze AI agents and AEO; Futurum cites 44% of decision-makers ranking GenAI as top buying criterion [17]. HubSpot's threat is not enterprise displacement — it is starving Salesforce of new mid-market logos that grow into enterprise.

**Pure-play vertical AI agent vendors (Sierra, Decagon, Cresta, Crescendo).** Highest-velocity threat in customer service specifically. These vendors are already cited in Salesforce-displacement deals where the customer rebuys "service AI" outside the Service Cloud seat. Salesforce's response — Agentforce Service Agent at $2/conversation — is a direct admission that the seat model loses here.

**The Klarna data point is informative but misread.** Klarna's September-2024 announcement of cancelling Salesforce/Workday became the bear poster child, but the company subsequently admitted the cost cuts went too far and is rehiring [18]. The honest reading: AI substitution for SaaS is a real phenomenon but harder than the bull case for AI assumed in 2024; it is also harder for Salesforce to defend than the 2023 bull case assumed. Both sides should update toward the middle.

## Bull case — technical
The bull case requires three technical conditions to hold:

1. **Agent activity becomes the dominant unit of work in CRM-adjacent processes, and Salesforce monetizes it via consumption + per-seat-uplift faster than seats deflate.** Concretely: Agentforce ARR was $800M Q4 FY26 (+169% YoY) [12]; combined Agentforce + Data Cloud was $2.9B (+200% YoY) [12]; 60% of Q4 Agentforce bookings came from expansions [11]. If Agentforce ARR doubles annually for two more years, it covers any plausible 10–15% seat erosion on the $35B+ Sales/Service base.

2. **Atlas + Data Cloud + Informatica becomes the de facto enterprise context layer for third-party agents (including Claude, ChatGPT Enterprise, Microsoft Copilot via MCP).** Anthropic's MCP Apps integration with Slack and Agentforce 360 [9] is the leading indicator: if every major LLM provider treats Salesforce as the canonical source of structured customer/account/case context, CRM extracts a tax on the agent economy regardless of which model wins.

3. **Metadata lock-in holds.** Custom Apex/Flow/object stacks remain economically immovable for the next 5+ years, even with LLM-assisted migration tools.

Connected to financial outcome: at 13.9× forward P/E [5] with $35B cRPO and a $50B buyback authorization (~28% of market cap) [12][20], the stock does not need growth to re-accelerate to outperform — it needs growth to *not collapse*. FY27 guide of 7–8% organic ex-Informatica [12] is the bar. If Agentforce expansions prove that AI is additive rather than substitutive, the multiple re-rates from "ex-growth software" to "AI-platform-with-installed-base."

**Base rate:** when a dominant SaaS incumbent successfully captures the next platform layer (Microsoft with cloud, Adobe with creative cloud), it can sustain mid-cycle multiple expansion of 50–100%. When it doesn't (Oracle Apps, IBM, BlackBerry), the stock drifts as a value trap for years. The base rate of incumbents successfully capturing the next layer is, candidly, ~30–40% — not the >70% the bull case implicitly assumes.

## Bear case — technical
A short-seller fluent in the stack would write this:

1. **Seat economics are structurally broken and the company has admitted it.** SaaStr publicly disclosed paying Salesforce 83% more while using *fewer* seats [19] — Salesforce is recapturing value through price hikes on shrinking seat counts, which works for one to two renewal cycles and then customers re-bid the contract. Salesforce's Agentic Enterprise License Agreement (AELA) [19] is the explicit acknowledgment that the per-seat unit is dead.

2. **Salesforce does not own the model, the inference, or the agent runtime that customers actually want to use.** Anthropic's MCP and the "Claude in your CRM" partnership [9] is described by Salesforce as a moat reinforcement; it is equally readable as Anthropic acquiring Salesforce as a *data plane* for Claude, not the other way around. If end-users converse with Claude or Copilot directly and Salesforce is just a context provider, Salesforce monetization compresses to a metadata API tax.

3. **Microsoft's bundle economics are unanswerable in the mid-market and increasingly in enterprise.** $150/seat for Dynamics + Copilot for Sales [6] vs. Sales Cloud Enterprise ($165) + Agentforce add-ons + Data Cloud + Tableau is not a fair fight on TCO. Microsoft 365 Copilot at 20M paid seats [15] gives Microsoft a frontline AI presence Salesforce cannot match without owning a productivity suite.

4. **Marketing Cloud and Commerce Cloud are shrinking.** −1% constant currency in Q4 FY26 on $5.4B of revenue [12]. These are ExactTarget (2013) and Demandware (2016) acquisitions — the original "platform of platforms" thesis — and they are in absolute decline. This is what late-stage moat erosion looks like in real time.

5. **Organic growth is ~7–8% ex-Informatica** [12]. Informatica was acquired for $8B to add 3 points to FY27 growth; that is expensive headline-revenue purchasing. The buyback ($50B authorization, ~28% of cap) is a financial-engineering response to organic deceleration, not a confidence signal.

6. **The $800M Agentforce ARR is real but small.** It is ~2% of FY26 revenue. To matter to the FY27 guide it must continue compounding at >100% — and the deal-count growth (29,000, +50% QoQ) is decelerating in percentage terms. Some portion of Agentforce ARR is reclassified from existing Service Cloud — true incremental ARR is harder to verify and Salesforce does not break it out.

## Market view check
At $180/share, ~$149B market cap, 13.9× forward P/E [1][5], CRM trades at a multiple that already prices in the bear case for a mature ex-growth software business. Consensus PT $261 [5] implies the sell-side has not capitulated — they are waiting for an Agentforce inflection. The market disagreement is sharp: long-term holders see a 28%-of-cap buyback, $35B cRPO, and 169% Agentforce ARR growth as a coiled spring; the YTD −27% performance [12] says the market believes seat deflation is a faster reality than Agentforce monetization. **The price is roughly consistent with "good but not great" outcomes:** ~7-8% organic growth, gradual Agentforce ramp, no Microsoft share-loss accident. It is *not* pricing in either (a) Microsoft taking measurable share of net-new enterprise CRM bookings, or (b) Agentforce inflecting to >$3B ARR in 18 months. Asymmetry depends on which side you handicap. The technical reality I described above leans slightly bearish on the moat-erosion vector but the multiple has done much of the work already.

## 90-day falsifiers
- **Q1 FY27 print (late May 2026):** Agentforce ARR sequential growth. If it does not grow >$150M sequentially (~$950M+), the "doubling annually" thesis is dead.
- **Q1 cRPO growth:** must hold ≥13% constant currency ex-Informatica to validate organic trajectory.
- **Marketing Cloud + Commerce Cloud:** if they remain negative or worsen sequentially, the "old portfolio" cancer is metastasizing.
- **Microsoft Build (May 19–22, 2026) Copilot announcements:** specifically watch for Copilot Studio cross-system agent demos using Salesforce data without Agentforce — this would validate the "Salesforce as data plane only" bear scenario.
- **Independent enterprise references for AELA renewals:** if 2–3 large AELAs (>$10M ACV) renew at flat-to-down ACV, seat-deflation is winning.
- **Anthropic / OpenAI direct-to-enterprise CRM moves:** any announcement of Claude or ChatGPT shipping a "CRM-native" experience that bypasses Salesforce as the workflow surface.
- **Hyperscaler Q1 capex commentary:** weakening hyperscaler capex would *help* CRM at the margin (cheaper inference) but signal broader AI demand softness — read both directions.
- **Salesforce headcount actions:** further sales-org cuts in the next 90 days would imply the company is sizing for slower bookings.

## What I could not verify
- **Salesforce's current dollar-based net retention rate for FY26.** Salesforce stopped breaking this out years ago; sources cite ~92% retention but no clean NRR. Material gap.
- **True incremental Agentforce ARR** (vs. reclassified Service Cloud ARR). Not disclosed.
- **Token-economic gross margin on Agentforce.** Salesforce has not disclosed agent COGS. Conversation pricing at $2 with Anthropic/OpenAI inference costs implies a margin range of 40–80% but cannot be triangulated without internal data.
- **Specific CoWoS-L or HBM contract exposure.** None expected (Salesforce is cloud-tenant, not hyperscaler), but unverified.
- **Microsoft Dynamics 365 specific FY26 enterprise CRM net-new bookings vs. Salesforce.** Microsoft does not disclose D365 separately from Business Applications.
- **The exact split of Agentforce ARR by industry vertical.** Anecdotal references (Wiley 213% ROI, Saks, Adecco) but no quantitative disclosure [11].
- **Whether the 18,500 Agentforce customer figure represents paid customers or includes pilots/Foundations free-tier users.** Likely a mix; not disclosed cleanly.
- **The 8–12 model count in Atlas Reasoning Engine** is from Salesforce engineering blogs/InfoWorld write-ups [4]; the specific model identities and routing logic are not public.

## Sources
[1] https://finance.yahoo.com/quote/CRM/ — retrieved 2026-05-10 — CRM price ($180.43 close 2026-05-08), 52-week range, market cap.
[2] https://www.salesforceben.com/4-critical-features-for-agentforce-architecture-in-2026/ — retrieved 2026-05-10 — Agentforce 2026 architecture: data layer, Atlas, agent layer; 18,500 customers / 3B monthly workflows.
[3] https://valintry360.com/blogs/zero-copy-data-and-data360-the-architecture-behind-2026-ready-analytics — retrieved 2026-05-10 — Q3 FY26 Data Cloud: 32T records ingested, 15T via zero-copy (+341% YoY).
[4] https://www.infoworld.com/article/3542521/explained-how-salesforce-agentforces-atlas-reasoning-engine-works-to-power-ai-agents.html — retrieved 2026-05-10 — Atlas Reasoning Engine: 8–12 specialist models per query, ReAct loop, async event-driven, YAML-declared agents.
[5] https://stockanalysis.com/stocks/crm/forecast/ and https://stockanalysis.com/stocks/crm/statistics/ — retrieved 2026-05-10 — Forward P/E 13.9×, trailing P/E 23.6×, consensus PT $261, n=35 analysts.
[6] https://www.virtasant.com/ai-today/microsoft-vs-salesforce-the-feud-shaping-ai-in-crm and https://www.sybill.ai/blogs/microsoft-dynamics-365-vs-salesforce — retrieved 2026-05-10 — Salesforce ~24% CRM share, Dynamics 7–9%; Copilot for Sales bundled at $150/seat in D365 Sales Premium; Microsoft 40% YoY growth in financials/healthcare.
[7] https://www.salesforce.com/news/press-releases/2025/11/18/salesforce-completes-acquisition-of-informatica/ — retrieved 2026-05-10 — Informatica acquisition closed Nov 18, 2025 at ~$8B equity value; data catalog/governance/MDM into Salesforce.
[8] https://ekfrazo.com/resources/blogs/resources-blogs-salesforce-agentforce-pricing-2026/ and https://www.salesforce.com/agentforce/pricing/ — retrieved 2026-05-10 — Agentforce pricing: $2/conversation, Flex Credits per-action, AELA blended.
[9] https://www.salesforce.com/news/stories/salesforce-anthropic-trusted-context-ai-actions-on-claude/ and https://developer.salesforce.com/blogs/2026/04/new-developer-edition-agentforce-vibes-claude-mcp — retrieved 2026-05-10 — Anthropic MCP Apps with Slack/Agentforce; Anthropic first LLM provider fully inside Salesforce trust boundary; Headless 360 with 60+ MCP tools (TDX 2026).
[10] https://techcrunch.com/2026/03/31/salesforce-announces-an-ai-heavy-makeover-for-slack-with-30-new-features/ and https://www.cnbc.com/2026/01/13/salesforce-releases-updated-slackbot-powered-by-anthropics-ai-model.html — retrieved 2026-05-10 — Slackbot powered by Claude; Agentforce native in Slack (Sales, IT, HR, Tableau).
[11] https://www.salesforceben.com/agentforce-customers-are-doubling-down-60-of-q4-bookings-came-from-expansions/ and https://www.cxtoday.com/crm/agentforce-case-studies/ — retrieved 2026-05-10 — Q4 FY26 Agentforce: 60% of bookings from expansions; 29,000 deals (+50% QoQ); Wiley 213% ROI; Saks/OpenTable/Adecco references.
[12] https://www.salesforce.com/news/press-releases/2026/02/25/fy26-q4-earnings/ and https://s205.q4cdn.com/626266368/files/doc_financials/2026/q4/CRM-Q4-FY26-Earnings-Press-Release.pdf — retrieved 2026-05-10 — Q4 FY26: Rev $11.2B (+12%), FY26 $41.5B (+10%); Agentforce ARR $800M (+169%); combined Agentforce+Data360 $2.9B (+200%); FY27 guide $45.8–46.2B (10–11% incl ~3pts Informatica); Marketing/Commerce Cloud −1% in Q4.
[13] https://fintel.io/ss/us/crm and https://www.benzinga.com/quote/CRM/short-interest — retrieved 2026-05-10 — Short interest ~2.46% of float.
[14] https://futurumgroup.com/insights/salesforce-q4-fy-2026-earnings-show-agentic-ai-scaling-guidance-steadies/ — retrieved 2026-05-10 — Q4 FY26 RPO $72B (+14%), cRPO $35.1B (+16%, +13% CC); FY27 non-GAAP op margin guide 34.3%, GAAP 20.9%.
[15] https://windowsnews.ai/article/microsoft-365-copilot-hits-20m-paid-seats-enterprise-ai-adoption-governance-roi.415952 — retrieved 2026-05-10 — Microsoft 365 Copilot 20M paid seats April 2026, +33% from 15M in Jan 2026.
[16] https://247wallst.com/investing/2026/04/27/which-software-stock-has-been-the-worst-performer-in-2026-adobe-salesforce-or-servicenow/ and https://fortune.com/2026/05/05/servicenow-knowledge-2026-autonomous-workforce-microsoft-nvidia-ai-announcements/ — retrieved 2026-05-10 — CRM YTD −27%, ServiceNow Knowledge 2026 Autonomous Workforce expansion across CRM/HR/IT/security/procurement.
[17] https://oktana.com/agents-salesforce-ai-strategy/ and https://futurumgroup.com/insights/can-hubspots-agentic-ai-bet-disrupt-enterprise-crms-old-guard/ — retrieved 2026-05-10 — AgentExchange skills flywheel; HubSpot Spring 2026 Breeze agents; 44% of decision-makers cite GenAI as top buying criterion.
[18] https://www.salesforceben.com/klarna-cut-ties-with-salesforce-to-go-all-in-on-ai-now-theyre-hiring-humans-back/ and https://diginomica.com/those-shutting-down-salesforce-and-workday-rumors-klarna-no-we-didnt-replace-saas-llm-admits-ceo — retrieved 2026-05-10 — Klarna AI-replaces-SaaS narrative was overstated; CEO admitted cuts went too far, partial reversal.
[19] https://www.saastr.com/why-we-pay-salesforce-83-more-than-last-year-but-stopped-using-notion-entirely-the-ai-agent-seat-problem-is-real/ and https://www.theregister.com/2025/12/12/ai_agents_salesforce_pricing/ — retrieved 2026-05-10 — Customer paying 83% more on fewer seats; AELA structure; seat-deflation evidence.
[20] https://finance.yahoo.com/markets/stocks/articles/salesforce-50-billion-buyback-bet-143142916.html — retrieved 2026-05-10 — $50B buyback authorization (~28% of market cap), 5.8% dividend hike, no execution timeline.