I have enough material. Writing the dossier now.

# IRM — Iron Mountain Incorporated

## Where this sits in the AI stack

IRM is fundamentally a physical-storage REIT (paper boxes, tape, end-of-life IT hardware) that is bolting on a wholesale/colocation data center business. It does not sell silicon, compilers, or networking. Its AI exposure is at the bottom of the stack — real estate, substations, switchgear, chillers, slabs — plus a fast-growing IT Asset Disposition (ITAD/ALM) business that decommissions and recovers value from hyperscaler GPU racks at end of life. Of $7.8B 2026 revenue guidance, ~$1B (~13%) is data centers and ~$1B is ALM; the remaining ~$5.8B is records management and digital services [1][2][12]. IRM's DC product targets multi-MW hyperscale build-to-suit and dedicated halls (10-year leases, customers ramp power in stages), not retail interconnection a la Equinix [2][3].

## Snapshot

- **Price:** $132.06 (2026-05-07 close) [19]
- **Market cap:** ~$38.5B [19]
- **52-week range:** $77.77 – $134.09 [19]
- **Forward P/AFFO:** ~22.5× (on FY26 AFFO/share guide of $5.79–$5.86, midpoint $5.825) [2][20]; reported GAAP forward P/E shows ~45× [20] but that is depreciation-distorted as is typical for REITs
- **EV / NTM revenue:** ~7.0× (EV ≈ $55.5B = $38.5B equity + $17.1B long-term debt; NTM revenue ≈ $7.875B midpoint) [2][17]
- **Net debt / EBITDA:** ~7.8× (REIT sector avg ~1.1×); net lease-adjusted leverage 4.9× per company definition [17]
- **Consensus 12-month price target:** ~$138 (+4.5% from spot), Strong Buy consensus [18]
- **YTD total return:** +33% (roughly 2× the broader REIT index) [21]
- **Short interest (% of float):** 2.78% [18]

## Moat — what it is physically made of

IRM's moat is three different moats glued together. They have very different durabilities and shouldn't be valued as one.

**1. Storage (the cash machine).** ~735M cubic feet of stored physical records, ~700M boxes, average dwell time 14.5 years, customer retention ~98%, 37 consecutive years of organic storage rental revenue growth [4]. The moat is not "brand" — it is the *ratio of retrieval cost to storage cost*. A box sitting in an IRM warehouse generates ~$3–6/year in rent; the labor cost to identify, ship, re-barcode, and re-shelve it elsewhere is multiples of that. Over 50% of boxes ingested 15 years ago are still on shelf [4]. Compliance certifications (chain-of-custody, HIPAA, FedRAMP HIGH at Boyers) gate competition further. This business is in slow secular decline in volume terms in developed markets but offsets via mid-single-digit pricing and emerging-market growth. Durability: high, decade-plus.

**2. Northern Virginia/Manassas + global power footprint (the AI lottery ticket).** This is the moat the market is paying for. IRM owns 142 acres in Manassas with an existing 280 MW campus and 150 MW expansion underway, plus a dedicated substation [13][14]. The reason this matters is not the steel or the racks — it is that Dominion Energy has effectively stopped guaranteeing new power delivery in Loudoun/Prince William until major transmission upgrades complete in 2026+, and the queue for new grid interconnections in primary US data center markets now exceeds **four years** [6][11]. NoVA colocation vacancy is 0.72% [11]. Translation: every operating MW IRM has in NoVA today is effectively scarce, non-replicable inventory for the next 24–36 months. IRM is also the only data-center REIT with a meaningful Indian footprint via Web Werks (now 100% owned), and is building in Mumbai and the FLAP+I markets [1][2]. Durability: high for in-place capacity (10-year leases, locked in), medium-low for being able to *grow* this advantage — entitled-and-powered land everywhere is being bid up.

**3. ALM / hyperscale decommissioning (the AI second derivative).** Q1 2026 ALM revenue $232M, +92% YoY, with **>100% organic growth in data center decommissioning** [12]. Because IRM already has chain-of-custody trust with the hyperscalers and federal customers from the storage business, it is the natural counterparty when they retire A100/H100/older Trainium fleets. The 2023 Regency acquisition added e-scrap processing scale. Recovery values of decommissioned GPUs in secondary markets are non-trivial (used H100s still trade at high four figures). Durability: medium — the technical barrier is not deep, but the customer-trust + scale combo is hard to copy fast.

What is NOT a moat: IRM's "AI-ready" technical specs. The published IMDC modular product supports up to 36 kW/rack [5]. That is *not* AI training infrastructure by frontier standards — NVIDIA GB200 NVL72 racks consume ~120 kW each and Vantage's Stargate Texas build supports >250 kW/rack [14][15]. IRM's high-density build-to-suit halls clearly go higher than 36 kW (this is a published colocation product, not their hyperscale ceiling) but they have published no floor-loading, CDU-per-rack, or rear-door HX specifications competitive with Vantage/QTS/CoreWeave-affiliated builders. **I read this honestly: IRM is selling power, land, and shell to AI customers, not differentiated AI infrastructure.** That's a real product — power is the binding constraint — but it is not a technical moat; it is a permits-and-substations moat.

## AI buildout bottleneck map

The 24-month gating constraints on the global AI buildout, ranked by current tightness, with IRM's exposure:

| Bottleneck | State | IRM position |
|---|---|---|
| **Grid interconnect / new generation** | 4-year queue in primary US markets; Dominion suspended/limited new NoVA capacity through 2026 [6][11] | **Beneficiary** — owns powered, energized capacity in NoVA |
| **CoWoS-L advanced packaging** | TSMC ramping 35k → ~130k wafers/mo by end-2026; NVIDIA holds ~60%+ of allocation through 2027; oversubscribed [7] | **Indifferent** — IRM's revenue is gated by power not chips, but customer ramp pace is gated by chip deliveries |
| **HBM3e/HBM4 supply** | Fully allocated through 2026 [7] | **Indifferent** (same as above) |
| **Liquid cooling at >100 kW/rack** | Industry pivoting from air to direct-to-chip + rear-door HX; supplier capacity (Vertiv, Schneider, CoolIT, Boyd) tight | **Exposed customer** — must retrofit older halls; capex risk |
| **Electrical contractor / switchgear lead times** | 50–80 week lead times for medium-voltage switchgear, transformers | **Exposed customer** — but IRM's developer relationships are mature |
| **Optical interconnect (800G/1.6T transceivers, CPO)** | LPO/CPO transition mid-decade; supply tight on 1.6T DSP-based | **Indifferent** — customer-supplied |
| **Frontier training data quality** | Saturating public web; synthetic data + post-training scaling debated | **Indifferent** |
| **Kernel/compiler talent (CUDA, Triton, ROCm)** | Acutely scarce | **Indifferent** |

The takeaway: IRM's bottleneck exposure is asymmetric in a useful way. Its *supply* is gated by the same constraint (power) that's making its product scarce. Its *customers' demand* is gated by chips (CoWoS/HBM), which is a different constraint and not currently slipping into 2027. This dual-gating means demand stays robust even if NVIDIA can't ship more units — the AI customers signed today will keep ramping into 2027–28 leases.

## Competitive teardown

IRM is not the marginal supplier of frontier training capacity. It is a mid-pack hyperscale colo with ~488 MW operating + 191 MW under construction (total ~1.3 GW when fully developed) [1][2].

| Competitor | Operating capacity / pipeline | Where they beat IRM | Where IRM is at parity or ahead |
|---|---|---|---|
| **Equinix (EQIX)** | ~430 MW xScale leased + much larger retail; 23 metros [3] | Interconnection density (Equinix Fabric), scale, retail enterprise | IRM has ~zero accounting overhang vs the still-resolving Hindenburg-driven civil suits at EQIX [8][9] (SEC dropped probe but private suits remain); IRM's leverage and AFFO accounting is more straightforward |
| **Digital Realty (DLR)** | 289 MW delivered 2025, 769 MW under construction, recently signed largest hyperscale lease in company history [3] | Pipeline depth, hyperscale relationships at scale, geographic reach | IRM growth rate higher off smaller base; less capital intensity to fill |
| **Vantage Data Centers** (DigitalBridge-controlled, private) | 1.4 GW Stargate Texas single site, supports >250 kW/rack [15] | Frontier AI density, OpenAI/Oracle relationship, GW-scale single-customer builds | IRM is in liquid public markets; Vantage requires private capital |
| **CoreSite (American Tower)** | 253 MW, urban interconnect-focused | Urban metro dominance | IRM has hyperscale + emerging markets that CoreSite doesn't |
| **QTS (Blackstone-owned, private)** | Multi-GW hyperscale campus model | Mega-campus speed-to-market, Blackstone capital | IRM is still public with daily liquidity; QTS unavailable to public investors |
| **CoreWeave / Crusoe / "neocloud" build-to-suit** | Vertically integrated GPU cloud with bespoke builds | Tighter physical-to-software integration for AI training | IRM's diversification across customers/use cases |

The honest read: IRM cannot win the *largest* AI training campuses. Those go to private specialists (Vantage, QTS, Crusoe, CoreWeave-affiliated developers) who can move faster on bespoke 1+ GW builds with single counterparties. IRM's natural deal size is 16–72 MW (per actual 2024–26 wins: Miami 16 MW, Manassas 20–72 MW, Frankfurt 27 MW, Amsterdam 10 MW) [2][13]. That's enterprise AI inference, second-tier hyperscaler training, and AI-for-government workloads — a real but smaller TAM than the OpenAI/Anthropic frontier campuses.

## Bull case — technical

The conditions under which IRM materially outperforms over 12–24 months:

1. **NoVA grid stays gated through 2027.** Dominion's transmission projects slip, PJM interconnection queue stays long, and operating MW remains the binding currency [6][11]. IRM's 280 MW Manassas campus is then a literally non-replicable asset and the next 150 MW expansion (with substation) commands premium pricing.
2. **AI inference (not just training) drives sustained MW absorption.** Inference workloads spread across more metros than training (latency matters), favoring IRM's Frankfurt/Amsterdam/Mumbai/India footprint over single-tenant GW campuses in Texas/Wisconsin. >25% DC revenue growth sustains into 2027 and stays gross-margin accretive (52% segment EBITDA margin in 2025) [4].
3. **ALM growth is not a 2026 anomaly.** As hyperscalers refresh A100/H100 fleets in 2026–28 with Blackwell/Rubin, the decommissioning wave is just beginning. ALM run-rate moves from ~$1B to $2B+ over three years, providing a second growth engine independent of new DC builds.
4. **Storage funds the capex.** $2.0B 2026 growth capex [2] is largely covered by storage cash flow + securitization; no major equity issuance needed at $130+ price; net leverage stays in the 5× range on lease-adjusted basis even while building.
5. **Base rate check on platform-shift winners:** at this stage of an infrastructure cycle (analogous to fiber cos in 1999, tower cos in 2003–06, cloud REITs in 2014–18), the *picks-and-shovels real estate plays* with operating capacity tend to outperform until supply catches up. Tower REITs delivered ~3× the S&P over 2003–10. The pattern is not guaranteed but it is the relevant base rate, not pure-tech displacement.

Financial outcome: $5.86 → ~$7 AFFO/share by 2028 at 24× → $168 (+27%); plus ~2.6% dividend.

## Bear case — technical

The conditions under which the moat erodes or demand evaporates:

1. **Hyperscalers self-build past colo.** AWS, Microsoft, Google, Meta, and now OpenAI/Stargate are increasingly going direct-to-developer with site selection, owning land and substation entitlements themselves [16]. If self-build absorbs the marginal MW, colo's role compresses to inference / second-tier / enterprise — a slower-growing TAM. Stargate alone is targeting 9+ GW by 2029 with no IRM involvement disclosed.
2. **Power constraint resolves faster than expected.** SMR deployments (Oklo, X-energy, Kairos), behind-the-meter gas turbines, and grid upgrades all step in. If NoVA reopens cleanly by mid-2027, IRM's scarcity premium evaporates and pricing compresses. Note: turbine backlogs are quoted in years, but a step-change in policy (FERC fast-track, expedited interconnection) could shift this.
3. **AI rack densities leave IRM's older inventory stranded.** Frontier training is moving to 120–250+ kW/rack with direct liquid cooling [14][15]. IRM's published 36 kW IMDC product line [5] suggests the legacy inventory was built for earlier-generation workloads; meaningful retrofit capex (CDUs, floor reinforcement, chilled water) eats into the 52% segment EBITDA margin. The capex needed to keep older halls AI-relevant is unverified but non-trivial.
4. **Leverage bites.** 7.8× net debt/EBITDA is REIT-extreme [17]. If the 10Y rises 100bps and AI capex disappoints simultaneously, refinancing cost compounds with multiple compression. IRM rolled $1B+ of notes annually in 2024–25 at higher coupons; another 100bps move adds tens of millions to interest expense.
5. **Storage runs off faster than expected.** Paper records volume in developed markets is in slow decline; if AI-driven document digitization accelerates (LLM-powered OCR, automated retention scheduling), the dwell-time math (14.5 years) shortens and the storage cash flow that funds DC capex compresses.
6. **ALM is cyclical, not secular.** Decommissioning revenue is lumpy and tied to specific customer refresh cycles. The 92% YoY growth print is partly a comp issue (Regency integration year) and partly real demand; separating the two from outside is hard.

Falsifier-style bear watchpoint: **rack density disclosure.** If IRM publishes spec sheets showing they top out at <80 kW/rack in operating halls (vs Vantage at 250 kW), the AI-narrative premium is not earned.

## Market view check

At ~22.5× forward AFFO and ~7× EV/NTM-revenue, with 33% YTD return, IRM is priced as a hybrid: storage REIT (~15× AFFO baseline) + fast-growing data center REIT (Equinix at ~25–30× AFFO, DLR ~22×). The blended multiple implies the market is giving IRM credit for its DC growth but discounting it vs pure plays — fair, given the sub-scale hyperscale position and the leverage. The implicit bet at this price is that the storage business is a stable annuity and ALM + DC compound at ~20–25% for several years. That looks consistent with current run-rate. Where the market may be *wrong* in the bull direction: it appears to be valuing the NoVA scarcity at a normal cap rate, not at the option value of a 4-year power queue. Where it may be *wrong* in the bear direction: it is not pricing the leverage tail risk if AFFO growth disappoints by even 200bps, because the equity is the residual claim against $17B of debt.

## 90-day falsifiers

Specific events between now and ~mid-August 2026 that would update the thesis:

- **Q2 2026 earnings (early August):** signed leasing MW YTD vs the 100+ MW guide; pricing per MW disclosed or implied; any pull-forward from 2027 commencements; ALM organic growth ex-Regency.
- **Hyperscaler Q2 capex calls (late July – early August):** Microsoft, Meta, Alphabet, Amazon, Oracle. A coordinated >10% sequential capex cut would compress lease velocity. Continued upward revisions are bullish for IRM's pipeline.
- **Dominion Energy NoVA transmission status update:** completion or delay of the Goose Creek 500 kV transformer and 230 kV reconductoring projects [6] directly governs how long IRM's existing-MW scarcity premium lasts.
- **A new IRM hyperscale lease ≥50 MW at Manassas Phase 2 (the +150 MW expansion) [13]:** would lock in the next leg of revenue and validate the substation investment.
- **Any IRM credit rating action.** Moody's/S&P watch list movement on the heels of $2B 2026 capex.
- **Equinix Q2 print + private-suit progression [8].** If EQIX leaks share to IRM/DLR on pricing or on customer trust loss, IRM benefits asymmetrically.
- **MLPerf v5.0 inference results (typical late-summer cadence):** workload mix shifts to inference favors IRM's distributed-metro footprint over single-site GW campuses.
- **Stargate site progress disclosures from OpenAI/Oracle/Vantage [16]:** if Stargate slips, marginal AI demand spills to colo.

## What I could not verify

- IRM's actual maximum rack density and direct-to-chip cooling deployment in operating halls. The 36 kW IMDC number is the published colocation product [5]; build-to-suit halls clearly support more, but I found no spec sheet, third-party teardown, or MLPerf submission that pins the number. This is the single biggest gap in the technical thesis.
- The retrofit capex to bring legacy halls (e.g., older NJ, Boston, Phoenix) up to AI-training spec.
- Specific named hyperscale tenants of recent leases. Q1 2026 Miami 16 MW is "an existing ALM decommissioning customer" and Amsterdam 10 MW is "a major global cloud player" — neither named [2]. Identifying the customer matters for credit risk and renewal probability.
- IRM's effective $/kW/month pricing on recent hyperscale deals vs the CBRE/JLL market average of $184–$200+/kW/month [11]. Without this, AFFO walk math has wide error bars.
- The contractual structure of power pass-through vs fixed price in 2025–26 leases — i.e., who eats Dominion rate increases.
- 2027 commencement schedule by site — whether 191 MW under construction is evenly spread or back-loaded.

## Sources

[1] https://www.ironmountain.com/data-centers — retrieved 2026-05-10 — IRM stated 1.3 GW global portfolio, customer mix, AI-ready positioning
[2] https://www.fool.com/earnings/call-transcripts/2026/04/30/iron-mountain-irm-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1 2026 transcript: $255M DC revenue +47%, 22 MW signed, 100+ MW 2026 leasing target, 400 MW energizable over 24 months, 2026 AFFO guide $5.79–$5.86
[3] https://www.datacenterdynamics.com/en/news/data-center-colo-results-q4-2025-digital-realty-equinix-iron-mountain-american-tower/ — retrieved 2026-05-10 — competitor capacity comparison: EQIX xScale 430 MW, DLR 769 MW under construction
[4] https://investors.ironmountain.com/news/news-details/2026/Iron-Mountain-Reports-Fourth-Quarter-and-Full-Year-2025-Results/default.aspx — retrieved 2026-05-10 — 2025 full-year results: $6.9B revenue, 488 MW operating at 97% leased, 191 MW under construction at 67% pre-leased, 30% DC growth, 52% DC segment EBITDA margin
[5] https://resources.ironmountain.com/solution-guides/d/data-centers-iron-mountain-data-center-modules — retrieved 2026-05-10 — IMDC modules support up to 36 kW rack density (published colocation product spec)
[6] https://www.datacenterdynamics.com/en/news/dominion-energy-admits-it-cant-meet-data-center-power-demands-in-virginia/ — retrieved 2026-05-10 — Dominion power delivery constraints in NoVA through 2026; transmission project list (Goose Creek 500 kV, 230 kV reconductoring)
[7] https://info.fusionww.com/blog/inside-the-ai-bottleneck-cowos-hbm-and-2-3nm-capacity-constraints-through-2027 — retrieved 2026-05-10 — TSMC CoWoS ramp 35k → 130k wafers/mo by end-2026, NVIDIA holds 60%+ allocation through 2027, HBM3e fully allocated through 2026
[8] https://hindenburgresearch.com/equinix/ — retrieved 2026-05-10 — Hindenburg allegations: AFFO/maintenance capex misclassification, capacity oversubscription, ~$3B cumulative AFFO impact 2015–2023
[9] https://www.datacenterdynamics.com/en/news/sec-drops-investigation-into-equinix-following-short-seller-accusations-of-accounting-manipulation/ — retrieved 2026-05-10 — SEC closed Equinix investigation without action; private class actions remain
[10] https://www.cbre.com/insights/books/north-america-data-center-trends-h2-2025 — retrieved 2026-05-10 — N. America DC trends, vacancy and pricing context
[11] https://datacenterhawk.com/resources/fundamentals/colocation-data-center-pricing-a-2026-beginner-s-guide — retrieved 2026-05-10 — primary market vacancy 1.6%, NoVA 0.72%, $184/kW/mo for 250–500 kW deployments, 4+ year grid wait
[12] https://resource-recycling.com/e-scrap/2026/05/05/iron-mountain-puts-itad-at-the-center-of-its-growth/ — retrieved 2026-05-10 — Q1 2026 ALM revenue $232M +92%, 100%+ organic in DC decommissioning; Regency integration
[13] https://investors.ironmountain.com/news/news-details/2024/Iron-Mountain-Expands-Planned-Data-Center-Capacity-in-Virginia-by-more-than-350-Megawatts/default.aspx — retrieved 2026-05-10 — Manassas 142-acre 280 MW campus + 150 MW expansion + dedicated substation
[14] https://www.nvidia.com/en-us/data-center/gb200-nvl72/ — retrieved 2026-05-10 — GB200 NVL72 specs: ~120 kW/rack, mandatory liquid cooling
[15] https://www.datacenterdynamics.com/en/news/vantage-breaks-ground-on-texas-gigawatt-data-center-campus-for-openai/ — retrieved 2026-05-10 — Vantage Stargate Texas: 1.4 GW, supports >250 kW/rack
[16] https://openai.com/index/five-new-stargate-sites/ — retrieved 2026-05-10 — Stargate's 9+ GW plan and partner site list (no IRM disclosed)
[17] https://fiscal.ai/company/NYSE-IRM/metrics/ratios/net-debt-ebitda/ — retrieved 2026-05-10 — IRM net debt/EBITDA ~7.8×; lease-adjusted leverage 4.9×; total debt ~$17.1B
[18] https://www.marketbeat.com/stocks/NYSE/IRM/forecast/ — retrieved 2026-05-10 — analyst PT ~$138, Strong Buy consensus; short interest 2.78% of float
[19] https://finance.yahoo.com/quote/IRM/ — retrieved 2026-05-10 — price $132.06, market cap $38.5B, 52w range $77.77–$134.09
[20] https://www.gurufocus.com/term/forward-pe-ratio/IRM — retrieved 2026-05-10 — GAAP forward P/E 44.75 (note: depreciation-distorted for REIT)
[21] https://www.financecharts.com/stocks/IRM/growth/total-return — retrieved 2026-05-10 — IRM YTD total return +33%, top decile of industry