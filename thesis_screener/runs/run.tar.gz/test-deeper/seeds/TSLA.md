# TSLA — Tesla, Inc.

## Where this sits in the AI stack
Tesla is a vertically-integrated AI-embodiment company. It operates at four layers simultaneously: (1) custom inference silicon (AI4/HW4 deployed in ~3M vehicles, AI5 taped out April 2026 at dual foundry — TSMC Arizona N3 and Samsung Taylor) [8][9]; (2) a frontier training cluster (Cortex 1+2 at Giga Texas, targeting ~280k H100-equivalent GPUs by mid-2026) [11][12][55]; (3) real-time edge robotics applications — driving (FSD v14, end-to-end transformer policy) and humanoid motor control (Optimus) [18][37]; and (4) a real-world data fleet (~7M vehicles, ~7B cumulative FSD miles) [35]. No other public company spans all four. The relevant workload is **edge-inference at automotive ASIL-D safety and 36 Hz video latency budget**, with offline supervised/imitation training on a hyperscaler-class cluster. It is **not** a chip vendor, a foundry, a cloud, or a foundation-model lab.

## Snapshot
- **Price:** $428.35 (2026-05-08 close) [2]
- **Market cap:** ~$1.61T [2]
- **52-week range:** $273.21 – $498.83 [2]
- **Forward P/E:** ~197.7× on FY26 consensus EPS; ~145.5× on FY27 [59]
- **EV / NTM revenue:** ~14.9× [53]
- **Consensus 12-month price target:** ~$405–$459 (29 analysts; wide $300–$600 dispersion, Hold/Buy split) — implies roughly flat to +7% [59]
- **YTD total return:** approximately −5% to −6% (down ~14% at Q1 print, recovered most of it) [52]
- **Short interest (% of float):** ~1.82% (60.86M shares) [51]

## Moat — what it is physically made of

Tesla bulls describe "the AI moat" as a single thing. It is not. Decompose:

**1. Custom inference silicon (AI4 → AI5 → AI6).** AI4 is Samsung 7nm, ~500 TOPS aggregate board, ~160W, deployed in vehicles since 2023 [49]. AI5 taped out April 15, 2026 — same RTL run on TSMC Arizona N3 and Samsung Taylor with slightly different physical implementations [9]. AI6 is contracted to Samsung 2nm GAA at Taylor ($16.5B baseline, July 2025) [10]. The moat element here is **co-design** — the chip is shaped to the FSD/Optimus inference graph and ships in volume the chip can never reach on the open market (3M+ vehicles/year). Versus Nvidia Drive Thor (the only credible alternative at this performance class), the per-vehicle cost differential is plausibly 5–10× in Tesla's favor at scale. **Durability:** medium-high for inference; Tesla cannot match Nvidia in the open training/datacenter market and has now admitted this by shutting Dojo down. **Vulnerability:** AI5 production slipped ~2 years, forcing Cybercab to launch on AI4 [58] — execution risk is real.

**2. Dojo — written off.** Bloomberg reported the team disbanded August 7, 2025; Musk called the architecture "an evolutionary dead end" four days later [5][6]. ~20 senior engineers — including Ganesh Venkataramanan — left to found DensityAI [7]. The lesson: Tesla cannot beat Nvidia at training silicon at frontier scale, and Tesla now concedes this by relying on H100/H200 for Cortex and pivoting AI6 to do double duty as both inference and training compute. Anyone valuing TSLA on the Dojo TAM narrative from 2022-2024 should mark it to zero.

**3. Training compute (Cortex 1 + Cortex 2).** ~120k H100-equiv at YE 2025, targeting ~280k by mid-2026; Cortex 2 powered on April 22, 2026 [1][11][12]. **This is not unique** — xAI's Colossus 2 in Memphis is a gigawatt-scale buildout [16], and Meta/Microsoft/Google operate clusters of comparable or larger scale. The Cortex network fabric (InfiniBand vs. Spectrum-X vs. custom Ethernet) is not publicly disclosed — flag as unverified.

**4. Real-world fleet data.** ~7M vehicles, ~7B FSD miles, ~2.5B "city" miles [35]. The bull framing is volume. The technically honest framing is that **modern ML is bottlenecked by curation, not raw volume**, and Tesla's auto-labeling pipeline is real but the marginal value of clip N+1 of highway cruising approaches zero. Waymo's ~200M autonomous miles are *evaluation* miles under driverless conditions [29] — the actual metric L4 regulators care about. Tesla has substantially zero such miles. Net: data is a real but oversold advantage for breadth/long-tail; neutral-to-negative for the kind of validation L4 deployment requires.

**5. Manufacturing cost basis.** ~$400 sensor BOM (cameras only) vs. Waymo 5th-gen ~$13K — a 30× per-vehicle gap. Cybercab on Unboxed manufacturing claims <10s assembly cycle vs. Model Y's ~34s [48]. Unboxed has never been demonstrated at >1k unit/week volume. **Durability:** real if it works; unverified at scale.

**6. There is no "CUDA equivalent."** Tesla's software stack is internal. Migration costs for *Tesla* customers don't exist; Tesla customers buy cars. The CUDA-style developer moat (~4M devs, kernel libraries, decade of accumulated software) does not transfer here. The relevant question is whether Tesla's *in-house algorithms* are at frontier — and on this point Tesla publishes essentially nothing, while Figure (Helix 02 architecture published) [44], Physical Intelligence (π0.5 on arXiv) [64], and NVIDIA (GR00T N1 open) [65] do. **Algorithmic moat is unverified at best.**

## AI buildout bottleneck map

- **Power generation and grid interconnect** — gating most hyperscaler buildouts (multi-quarter turbine backlogs). Tesla is a **net beneficiary on both sides**: Cortex 2 is 500MW; Megapack sales to xAI Colossus 2 exceed $375M [16]. Energy storage is a 28% gross margin business that is in fact under-modeled in Tesla bull cases.
- **CoWoS-L advanced packaging** — gating Nvidia/AMD at frontier training. Tesla AI4/AI5/AI6 are LPDDR5X/6 based, **do not use CoWoS-L or HBM**. Indifferent.
- **HBM3e supply** — Tesla **indifferent** for inference silicon.
- **Optical interconnect / 800G** — Cortex fabric undisclosed. Likely standard ConnectX. Indifferent at current cluster scale.
- **Liquid cooling >100 kW/rack** — Tesla is **doing it in-house** at Giga Texas; vertical integration is a modest cost advantage.
- **Kernel/compiler talent** — Tesla is a **weak position**. The MLIR rewrite of the FSD runtime is real but the talent depth in CUDA/Triton/XLA optimization sits at Nvidia and frontier labs.
- **Training data quality at frontier** — Tesla has a **breadth advantage** for autonomous-driving/embodied AI specifically; **no advantage** for general-purpose foundation models.
- **Humanoid actuator supply** — Tesla placed a $685M Sanhua (China) order for ~180k robots' worth of linear actuators in October 2025 [41]; harmonic drives sourced from Suzhou Green Harmonic (~25% of supply); NdFeB magnets ~90% China-processed [42]. **Geopolitical fragility is the under-priced bear point** for Optimus economics.

## Competitive teardown

**FSD vs Waymo — Tesla loses on the only L4 metric that matters today.** Waymo: ~3,000 vehicles, ~250k paid trips/week across 5 US cities with 5 more announced 2026; ~200M cumulative autonomous miles; peer-reviewed Swiss Re study showing 88% reduction in property damage claims vs. human baseline at 25.3M autonomous miles [29][30]. Tesla Austin: ~50-200 vehicles, ~245 sq mi geofence, ~20-27% truly unsupervised, 14 crashes in first 8 months ≈ ~1 per 57k miles vs. Tesla's own human baseline of ~1 per 229k = **~4× worse than human** at minor-incident rate [24][25]. Tesla declines to publish per-mile disengagement data. Tesla California: zero autonomous test miles in 6 years; CPUC publicly confirmed Tesla is "not operating an autonomous vehicle service" [26][27]. Where Tesla has a real edge: cost basis and architectural elegance (end-to-end vision NN, no HD maps). Where Tesla has not converted: verified L4 deployment.

**FSD vs. Baidu Apollo Go / Pony.ai / WeRide** — China-side operators have ~149M cumulative miles, ~250k rides/week (Apollo Go alone), commercial driverless in 22+ cities. They lock Tesla out of China at L4 even though FSD is licensed there for supervised use.

**FSD vs. Mobileye Chauffeur / Nvidia Drive** — Tier-1 supplier model. Mobileye SuperVision in ~300k vehicles (Zeekr, Polestar) [62]. Nvidia Thor reference platform. Neither is operating an L4 service; both are building a horizontal floor that erodes Tesla's vertical advantage if FSD/Robotaxi delays.

**Optimus vs. Figure / Apptronik / Agility / 1X / Boston Dynamics** — Tesla is **behind on the only metric available** today (paying customer deployment). Figure 02 logged 1,250 hours and contributed to 30,000 X3s at BMW Spartanburg, with Figure 03 deploying at BMW Leipzig 2026 [45]. Agility Digit moved 100k+ totes at GXO Spartanburg under a multi-year RaaS [46]. Apptronik raised $520M at $5B (Google, Mercedes lead) Feb 2026 with active Mercedes/GXO/Jabil pilots [47]. Tesla in Q4 2025 admitted Optimus units in its factories are "primarily for learning, not productive tasks." Demos at the Cybercab event (Oct 2024) and Miami (Dec 2025) were caught as teleoperated [40].

**VLA models** — Helix 02 (Figure, on-robot 7B VLM + 80M policy at 200 Hz), π0.5 (Physical Intelligence, published), GR00T N1 (NVIDIA, open) are the public state of the art [44][64][65]. Tesla publishes nothing. Skild AI raised $1.4B at $14B in January 2026 on the thesis that the algorithmic brain is a **horizontal layer**, not a form-factor capability [66]. If correct, Tesla's vertical integration becomes a hedge requiring its in-house algorithms to keep pace with labs that publish, recruit, and compound on each other's work.

**Base rate context.** Platform-shift moats erode on 5-10 year cycles when (a) the incumbent's vertical stack contains a part where horizontal players can outscale (Intel vs. TSMC + ARM in mobile; Cisco vs. merchant silicon in networking). The structural risk for Tesla is that **algorithms** become the horizontal layer where labs out-scale it, and **silicon** stays vertical only as long as AI5/AI6 ship on time.

## Bull case — technical

For TSLA to outperform from here, the following technical conditions must hold:

1. **AI5 ships in volume by Q3 2026 at claimed performance.** "10×AI4, H100-class for Tesla's workload" must benchmark within ~25% of the claim. This is the foundation under FSD scaling, Optimus, and the Cybercab unit economics story.
2. **FSD v14 → v15 delivers a step change.** Musk's claim of a 10× parameter increase to ~10B params with proportional capability gain must hold; AI4 fleet must run the model at acceptable latency.
3. **Robotaxi expansion to ≥10 cities by YE26 without an NHTSA-forced sensor retrofit.** The visibility EA on 3.2M vehicles [32] resolves into something less than a mandatory hardware change.
4. **Optimus V3 reaches even 10k units in real customer deployments by YE26.** Doesn't need to match Tesla's targets — needs to match Figure/Apptronik on credibility.
5. **The Megapack-into-AI-buildout flywheel** remains under-modeled by sell-side — energy storage attached to hyperscaler capex is a real, growing, high-margin secondary thesis [16].

**Base rate note:** Platform incumbents who own the form factor (vehicle, robot) historically capture more value than software-only entrants when the application *requires* tight HW/SW co-design — see iPhone vs. Android margins. Tesla's bet is that embodied AI is this kind of application, not the kind where horizontal foundation models commoditize the form factor.

Financial translation: AI5 + Optimus deployment + robotaxi at-scale could justify $700-1000 per share on a sum-of-parts (auto at 1× sales + robotaxi at SaaS multiple + Optimus option value + energy at 6× sales).

## Bear case — technical

The version a short-seller who reads SemiAnalysis would write:

1. **Dojo's August 2025 shutdown is the leading indicator** — Tesla concedes it cannot beat Nvidia at training silicon at frontier scale. Multiple billions of capex written off. The vertical-integration thesis has now lost one of its four pillars.
2. **AI5 slipped 2 years and Cybercab launches on AI4.** The chip roadmap is more aspirational than execution-grade. Compare to Nvidia's 18-month tick-tock cadence.
3. **NHTSA Engineering Analysis covers 3.2M vehicles and includes one pedestrian fatality** [32]. A mandatory recall that forces a sensor retrofit (radar reinstated, LiDAR added) would invalidate the vision-only architectural bet, force a hardware refresh in the installed base, and obliterate the cost basis advantage Tesla counts on.
4. **Austin crash rate ~4× human at minor-incident threshold** despite the safety monitor in the front seat [24]. Tesla declines to publish per-mile data — the only reason an operator does this is unfavorable numbers. Crowdsourced ~450 mi between critical disengagements on AI4 [20] vs. Waymo ~2,500-17,000 mi in CA DMV submissions = order-of-magnitude gap.
5. **Algorithm risk on Optimus.** Tesla publishes nothing on robotics. Figure (Helix 02 architecture), Physical Intelligence (π0.5 paper), NVIDIA (GR00T N1 open) all do. Skild raised $1.4B on the thesis that the *brain* is the durable moat, not the body. Tesla could be behind and we wouldn't know.
6. **Supply chain dependence on China.** Sanhua $685M actuator order; Suzhou Green Harmonic ~25% supply; NdFeB magnets ~90% China-processed. Geopolitical fragility is structural — and Chinese humanoid competitors (Unitree, AgiBot, XPeng, Xiaomi) sit on top of the same supply chain at lower cost.
7. **Tesla-xAI entanglement creates governance risk.** $2B Series E in Jan 2026 converted to SpaceX Class A; $573M of related-party transactions in 10-K; Nvidia GPU diversion incident in 2024 [14][56]. The 197× forward P/E does not include a related-party-transaction discount.
8. **Musk political activity** — $20M+ to GOP for 2026 midterms — extends brand-risk vector to the buyer demographic Tesla cars actually rely on.

Financial translation: Auto business at ~10× P/E (Toyota multiple) is ~$80. Energy at 6× sales is ~$30. Robotaxi/Optimus option value worth maybe $50-100 if you're generous about timeline. Combined: $160-210 fair value.

## Market view check

At $428 with $1.61T market cap, 197× forward P/E, and 14.9× EV/NTM revenue, TSLA prices in essentially the full bull case. Toyota trades at ~10× P/E and BYD at ~22× — the ~$1.5T premium versus Toyota at equivalent unit volume is the implicit valuation of "AI option value" (FSD + robotaxi + Optimus). Consensus PT $405-459 [59] is unusual: equity-research analysts as a class are saying the bull thesis is reasonably priced. The technical reality is harsher: Tesla lost on training silicon (Dojo cancelled), is behind on verified L4 deployment (Waymo ~200× more autonomous miles), has not converted its data fleet into validation evidence, is execution-late on AI5 (Cybercab now launches on AI4), publishes nothing on Optimus algorithms while competitors publish, and depends materially on Chinese suppliers for the actuator stack. The market is paying for option value on the assumption that vertical integration converts. The asymmetric trade is **not long** at these multiples; the asymmetric trade is **long energy + short auto/AI premium** as a paired spread, sized for the wide PT dispersion. The crowd is buying narrative; the technical substrate underneath supports a price closer to $250-300 absent verified L4 or scaled Optimus.

## 90-day falsifiers

Through August 2026:

1. **NHTSA visibility Engineering Analysis** (3.2M vehicles) — resolution as: closed without action / voluntary OTA recall / **mandatory hardware recall**. The third is a 30%+ downside event.
2. **AI5 first silicon back from fabs.** Taped out April 15; first samples expected ~July-August. If yield is bad or thermals miss, AI5 ship date slips again.
3. **Optimus V3 reveal** (Musk: "mid-year"). Watch for: scripted vs. truly autonomous demo, third-party benchmark of dexterity, named customer pilots beyond Tesla factories.
4. **Robotaxi expansion to Phoenix / Miami / Orlando / Tampa / Las Vegas** (Tesla H1 2026 promise). Either the cities open or they don't.
5. **Q2 2026 earnings (late July).** Watch: AI capex run-rate vs. >$25B guide [55]; FSD subscription revenue (or lack thereof); Optimus production rate disclosed (or quietly omitted); Cybercab first customer deliveries.
6. **Cybercab production start** (target April 2026, almost certainly slips). Public unit count delivered.
7. **Waymo cumulative trips** (currently ~250k/week, targeting 1M/week by YE26). If they hit it, the L4 gap widens further.
8. **Figure 03 BMW Leipzig deployment** (summer 2026). If Figure deploys hundreds of robots while Optimus stays in Tesla factories, the algorithmic-vs-vertical debate gets evidence.
9. **Sanhua Q1 2026 deliveries** from Mexico — actual unit count of Optimus actuators delivered, measurable through Chinese trade press.
10. **NHTSA / DOJ resolution on Musk OpenAI trial statements** (week 2 ongoing as of 2026-05-07; Musk under oath admitted Tesla is not pursuing AGI [57], contradicting tweets — securities-law implications if material).

## What I could not verify

- Cortex network fabric (InfiniBand vs. Spectrum-X vs. custom Ethernet). Tesla has not disclosed.
- Absolute FSD parameter counts beyond Musk's verbal "1B → 10B" statements; no peer-reviewed paper exists.
- AI5 actual TOPS in standard benchmarks; "H100-equivalent for Tesla's workload" is workload-specific and unbenchmarked.
- Whether Optimus uses end-to-end policy or hierarchical (Helix-style) architecture; Tesla publishes nothing.
- Audited Optimus production rate. "1,000 deployed at Fremont/Texas" is Tesla communications, not audited disclosure.
- Formal Tesla–xAI compute/data sharing agreement terms beyond the Megapack hardware sale and Grok-in-car integration disclosed in 10-K.
- Independent measurement of Optimus Gen 3 hand grip force / finger bandwidth / backdriveability.
- Peter Bannon's destination after departing Tesla Dojo (rumors point to DensityAI or xAI; not confirmed on record).
- Whether vision-only is L4-sufficient — no peer-reviewed publication or independent ablation study exists.
- Cybercab actual unit cost and Unboxed manufacturing cycle time at >1k unit/week scale.

## Sources

[1] https://assets-ir.tesla.com/tesla-contents/IR/TSLA-Q1-2026-Update.pdf — retrieved 2026-05-10 — Q1 2026 results, $22.39B revenue, 19.2% auto GM ex-credits, capex raised to >$25B, AI5 taped out, HW3 cannot achieve unsupervised FSD.
[2] https://finance.yahoo.com/quote/TSLA/ — retrieved 2026-05-10 — TSLA closing price, market cap, 52w range.
[3] https://hc34.hotchips.org/assets/program/conference/day2/Machine%20Learning/HotChips_tesla_dojo_uarch.pdf — retrieved 2026-05-10 — Talpes et al., Hot Chips 34 paper on DOJO D1 microarchitecture.
[4] https://newsletter.semianalysis.com/p/tesla-dojo-unique-packaging-and-chip — retrieved 2026-05-10 — SemiAnalysis Dojo packaging and chip analysis.
[5] https://www.bloomberg.com/news/articles/2025-08-07/tesla-disbands-dojo-supercomputer-team-in-blow-to-ai-effort — retrieved 2026-05-10 — Bloomberg first report that Tesla disbanded the Dojo team.
[6] https://techcrunch.com/2025/08/11/elon-musk-confirms-shutdown-of-tesla-dojo-an-evolutionary-dead-end/ — retrieved 2026-05-10 — Musk confirms Dojo shutdown.
[7] https://www.bloomberg.com/news/articles/2025-08-06/former-tesla-executives-start-automotive-ai-company-densityai — retrieved 2026-05-10 — Bloomberg on DensityAI formed by Venkataramanan and ~20 ex-Dojo engineers.
[8] https://electrek.co/2026/04/15/tesla-ai5-chip-taped-out-musk-ai6-dojo3/ — retrieved 2026-05-10 — AI5 tape-out April 15, 2026; AI6 and Dojo 3 roadmap.
[9] https://www.tomshardware.com/tech-industry/artificial-intelligence/elon-musk-demonstrates-first-sample-of-tesla-ai5-processor-accidentally-thanks-tsc-rather-than-tsmc — retrieved 2026-05-10 — Tom's Hardware on AI5 dual-foundry (TSMC AZ + Samsung Taylor).
[10] https://www.datacenterdynamics.com/en/news/samsung-electronics-signs-165bn-deal-with-tesla-to-manufacture-ai6-chips-at-taylor-texas-fab/ — retrieved 2026-05-10 — $16.5B Samsung 2nm GAA AI6 contract.
[11] https://www.datacenterdynamics.com/en/news/teslas-50000-gpu-cortex-supercomputer-went-live-in-q4-2024/ — retrieved 2026-05-10 — Cortex 1 50k H100 cluster online Q4 2024.
[12] https://convergedigest.com/tesla-activates-cortex-2-data-center-at-gigatexas/ — retrieved 2026-05-10 — Cortex 2 activation April 22, 2026.
[13] https://www.fool.com/earnings/call-transcripts/2025/01/29/tesla-tsla-q4-2024-earnings-call-transcript/ — retrieved 2026-05-10 — Q4 2024 transcript; ~$5B cumulative AI capex disclosed.
[14] https://www.cnbc.com/2024/06/04/elon-musk-told-nvidia-to-ship-ai-chips-reserved-for-tesla-to-x-xai.html — retrieved 2026-05-10 — Nvidia diverting Tesla-reserved H100s to xAI/X.
[15] https://electrek.co/2026/04/13/tesla-spring-update-2026-hey-grok-self-driving-app-pet-mode/ — retrieved 2026-05-10 — Spring 2026 update with Grok integration in vehicles.
[16] https://newsletter.semianalysis.com/p/xais-colossus-2-first-gigawatt-datacenter — retrieved 2026-05-10 — SemiAnalysis on xAI Colossus 2 gigawatt buildout and Megapack deployment.
[17] https://en.wikipedia.org/wiki/Colossus_(supercomputer) — retrieved 2026-05-10 — Colossus history, capacity.
[18] https://www.notateslaapp.com/news/2354/whats-coming-in-fsd-v13 — retrieved 2026-05-10 — FSD v13 architectural scaling factors (3× model, 4.2× data, 5× compute).
[19] https://creativestrategies.com/research/tesla-ai-autonomy-fsd-v13-update/ — retrieved 2026-05-10 — FSD v13 deep technical review.
[20] https://eletric-vehicles.com/tesla/tesla-fsd-v14-data-shows-major-improvement-in-miles-between-interventions/ — retrieved 2026-05-10 — Crowdsourced FSD v14 disengagement data.
[21] https://www.teslaoracle.com/2025/10/07/tesla-tsla-beings-the-rollout-of-fsd-v14-software-update-2025-32-8-5-release-notes/ — retrieved 2026-05-10 — FSD v14 rollout.
[22] https://electrek.co/2025/06/20/tesla-releases-details-robotaxi-launch-safety-monitor-front-seat/ — retrieved 2026-05-10 — Austin Robotaxi launch June 2025 details.
[23] https://electrek.co/2026/03/31/tesla-expands-unsupervised-robotaxi-service-area-still-only-handful-vehicles/ — retrieved 2026-05-10 — Austin geofence expansion to 245 sq mi.
[24] https://electrek.co/2026/02/17/tesla-robotaxi-adds-5-more-crashes-austin-month-4x-worse-than-humans/ — retrieved 2026-05-10 — Robotaxi crash rate ~4× human baseline.
[25] https://www.cbsnews.com/news/tesla-robotaxi-austin-14-crashes-nhtsa/ — retrieved 2026-05-10 — CBS on 14 Austin Robotaxi crashes in 8 months.
[26] https://electrek.co/2026/03/25/california-regulator-confirms-tesla-not-operating-autonomous-vehicle-service/ — retrieved 2026-05-10 — CPUC statement Tesla is not operating an AV service in CA.
[27] https://www.detroitnews.com/story/business/autos/2026/02/28/musks-robotaxi-ambitions-stalled/88919264007/ — retrieved 2026-05-10 — Tesla zero CA autonomous test miles in 6 years.
[28] https://waymo.com/blog/2026/02/dallas-houston-san-antonio-orlando/ — retrieved 2026-05-10 — Waymo 2026 expansion to 4 new cities.
[29] https://waymo.com/safety/impact/ — retrieved 2026-05-10 — Waymo safety impact stats; ~200M cumulative driverless miles.
[30] https://www.tandfonline.com/doi/full/10.1080/15389588.2025.2499887 — retrieved 2026-05-10 — Peer-reviewed Waymo safety study (Traffic Injury Prevention 2025).
[31] https://insideevs.com/news/778232/tesla-cybercab-production-april-2026/ — retrieved 2026-05-10 — Cybercab April 2026 production target.
[32] https://electrek.co/2026/03/19/nhtsa-upgrades-tesla-fsd-visibility-investigation-3-2-million-vehicles/ — retrieved 2026-05-10 — NHTSA Engineering Analysis upgrade, 3.2M vehicles, one fatality.
[33] https://www.techbuzz.ai/articles/nhtsa-finds-80-tesla-fsd-violations-expands-safety-investigation — retrieved 2026-05-10 — 80 verified traffic-law FSD violations.
[34] https://www.tesery.com/blogs/news/tesla-full-self-driving-achieves-monumental-breakthrough-in-european-expansion — retrieved 2026-05-10 — Netherlands RDW type approval April 10, 2026.
[35] https://www.tesery.com/blogs/news/tesla-fsd-fleet-nears-7-billion-miles-with-2-5-billion-city-miles-marking-major-ai-milestone — retrieved 2026-05-10 — ~7B cumulative FSD miles.
[36] https://www.basenor.com/blogs/news/tesla-optimus-gen-3-hands-22-dof-50-actuators-explained — retrieved 2026-05-10 — Optimus Gen 3 actuator architecture (22 DoF hands, 50 actuators per pair).
[37] https://en.wikipedia.org/wiki/Optimus_(robot) — retrieved 2026-05-10 — Optimus overview, Q4 2025 Musk acknowledgment that factory units are "primarily for learning."
[38] https://electrek.co/2026/04/22/tesla-optimus-production-fremont-model-sx-line/ — retrieved 2026-05-10 — Fremont S/X line repurposed for Optimus; V3 mid-year reveal.
[39] https://electrek.co/2025/12/07/tesla-optimus-robot-takes-suspicious-tumble-in-new-demo/ — retrieved 2026-05-10 — Suspicious Optimus fall in Miami demo.
[40] https://eu.36kr.com/en/p/3510288514980998 — retrieved 2026-05-10 — Sanhua $685M Optimus actuator order, October 2025.
[41] https://www.mckinsey.com/industries/industrials/our-insights/turning-humanoid-supply-chain-constraints-into-billion-dollar-wins — retrieved 2026-05-10 — McKinsey humanoid supply chain analysis (harmonic drives, NdFeB).
[42] https://www.figure.ai/news/helix — retrieved 2026-05-10 — Figure Helix architecture (7B VLM + 80M policy at 200Hz).
[43] https://www.figure.ai/news/production-at-bmw — retrieved 2026-05-10 — Figure 02 at BMW Spartanburg, 90k parts, 30k X3s.
[44] https://www.agilityrobotics.com/content/digit-moves-over-100k-totes — retrieved 2026-05-10 — Agility Digit 100k+ totes at GXO Spartanburg.
[45] https://www.cnbc.com/2026/02/11/apptronik-raises-520-million-at-5-billion-valuation-for-apollo-robot.html — retrieved 2026-05-10 — Apptronik $520M raise at $5B valuation.
[46] https://arxiv.org/abs/2504.16054 — retrieved 2026-05-10 — Physical Intelligence π0.5 paper.
[47] https://arxiv.org/abs/2503.14734 — retrieved 2026-05-10 — NVIDIA GR00T N1 humanoid foundation model paper.
[48] https://www.businesswire.com/news/home/20260114335623/en/Skild-AI-Raises-$1.4B-Now-Valued-Over-$14B — retrieved 2026-05-10 — Skild AI $1.4B Series C at $14B (Jan 2026).
[49] https://en.wikipedia.org/wiki/Tesla_Cybercab — retrieved 2026-05-10 — Cybercab specs and Unboxed manufacturing claims.
[50] https://www.notateslaapp.com/news/3337/tesla-delays-next-gen-ai5-to-mid-2027-cybercab-will-launch-on-ai4-hardware — retrieved 2026-05-10 — AI5 delay, Cybercab launches on AI4.
[51] https://www.marketbeat.com/stocks/NASDAQ/TSLA/short-interest/ — retrieved 2026-05-10 — Short interest 1.82% of float.
[52] https://www.cnbc.com/2026/04/22/tesla-tsla-q1-2026-earnings-report.html — retrieved 2026-05-10 — Q1 2026 earnings coverage.
[53] https://multiples.vc/public-comps/tesla-valuation-multiples — retrieved 2026-05-10 — EV/NTM revenue ~14.9× (May 2026).
[54] https://www.basenor.com/blogs/news/tesla-cortex-2-0-powers-up-in-april-what-it-means-for-optimus — retrieved 2026-05-10 — Cortex 2 powered up April 2026.
[55] https://www.basenor.com/blogs/news/tesla-raises-2026-capex-forecast-to-25b-what-it-means — retrieved 2026-05-10 — 2026 capex guidance raised to >$25B.
[56] https://electrek.co/2026/05/01/tesla-tsla-web-transactions-musk-companies-spacex-xai-10ka-2025/ — retrieved 2026-05-10 — Tesla 10-K/A disclosures on xAI/SpaceX related-party transactions ($573M).
[57] https://www.cnbc.com/2026/05/07/open-ai-trial-shivon-zilis-musk-altman-tesla-board.html — retrieved 2026-05-10 — Musk OpenAI trial admission Tesla not pursuing AGI.
[58] https://www.notateslaapp.com/news/3933/elon-musk-fsd-10x-parameter-upgrade-now-coming-with-v15 — retrieved 2026-05-10 — Musk verbal claim of 10× parameter step for v15.
[59] https://stockanalysis.com/stocks/tsla/forecast/ — retrieved 2026-05-10 — Analyst price target consensus $405-459, 29 analysts.
[60] https://www.mobileye.com/solutions/super-vision/ — retrieved 2026-05-10 — Mobileye SuperVision deployment (~300k vehicles).
[61] https://www.autopilotreview.com/tesla-hardware-4-rolling-out-to-new-vehicles/ — retrieved 2026-05-10 — HW4/AI4 silicon specs (Samsung 7nm, ~500 TOPS).
[62] https://www.trendforce.com/news/2025/10/23/news-tesla-ai5-production-split-between-samsung-tsmc-musk-cites-samsungs-advanced-equipment/ — retrieved 2026-05-10 — AI5 production split between Samsung and TSMC.