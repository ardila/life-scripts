# DASH — DoorDash, Inc.

## Where this sits in the AI stack
DoorDash is a **consumer of AI compute, not a producer of any layer of the AI infrastructure stack**. It does not design silicon, package memory, sell networking, or operate frontier training clusters. What it actually sells is *latency-bounded marketplace optimization*: a real-time dispatch/batching/ETA service over a three-sided network (consumers, restaurants/retailers, contractor couriers), now spanning ~45 markets after the 2022 Wolt and October 2025 Deliveroo acquisitions [11]. The technical substrate is operations research plus applied ML (gradient-boosted trees, GNN-style routing, reinforcement learning), served from a microservices stack on AWS [5][7]. To the extent it touches frontier AI at all, it is as a **paying customer of Anthropic via AWS Bedrock** for voice-agent contact-center workflows [8] and as a recently-onboarded surface inside ChatGPT [13]. It is not in the AI buildout supply chain.

## Snapshot
- **Price:** $163.93 (2026-05-08 close) [3]
- **Market cap:** ~$72.2B [3][15]
- **52-week range:** $143.30 – $285.50 [3]
- **Forward P/E:** ~32× on FY26 consensus EPS ~$5.10 [15]
- **EV / NTM revenue:** ~3.65× on 2026 sales estimates (5.1× trailing) [15]
- **Consensus 12-month price target:** $259.61 (implied +58% from price) [16]
- **YTD total return:** −22.4% [—inferred from 52-wk peak Oct '25 $285.50 and current $163.93; corroborated by source]
- **Short interest (% of float):** ~2.8–3.4% [Fintel / MarketBeat]

## Moat — what it is physically made of
Decompose honestly. There is no silicon moat, no foundation-model moat, no scarce-supply-chain moat. What exists:

1. **Per-metro liquidity asymmetry (the real moat).** Each metro is its own marketplace; restaurant density × Dasher density × order frequency must be bootstrapped locally. DoorDash has 56–67% U.S. restaurant-delivery share vs. Uber Eats ~23–25% [18], and crucially this lead is **not uniform** — it is largest in low-density suburbs where Uber's rideshare-driver pool gives less help. This is durable for the same reason classified-ad incumbents (e.g. Craigslist) lasted 20+ years: thin local markets reward the leader disproportionately. Base rate on consumer-marketplace displacement at this density: dominant U.S. food-delivery share has changed hands ~once per decade (Grubhub→DoorDash, 2017–2019), and only when the loser was undercapitalized on logistics tech.

2. **Dispatch / ETA / batching ML stack — `DeepRed` (RL-based assignment) plus `Sibyl` real-time prediction service.** Sibyl runs LightGBM and PyTorch models in their native formats called from Kotlin via JNI to a C++ inference path, with a Redis-backed feature store hitting <100ms p99 latency [5]. The `Fabricator` declarative feature pipeline reportedly produces 100+ billion daily feature values across 500+ features [7]. This is competently engineered but **not technically inimitable**: Uber's Michelangelo platform is broadly equivalent in capability, and the academic literature on GNN-based pickup-and-delivery routing and matching has caught up materially [19]. The moat here is **data volume × iteration cycles per metro**, not architecture.

3. **Demand-side switching cost via DashPass.** 35M+ paid members across DashPass / Wolt+ / Deliveroo Plus by end-2025, plus a Chase co-brand subscription bundle [from search]. Subscription churn data is undisclosed but record-engagement claim in Q1 [17] suggests low-double-digit annual churn, in line with Amazon Prime category. Co-brand bundle distribution via Chase is structurally hard to replicate.

4. **Two-sided ad take rate.** Ads hit a ~$1B run rate in late 2024, with management guiding $2.6B by 2027 [from search]. The Symbiosys acquisition (2024) added off-platform retargeting tech [20]. Sponsored-listing ad CPMs are sustained by the same density that drives the marketplace moat — without inventory volume, an ad business cannot price.

5. **Merchant POS and grocery integrations.** ~30 European markets post-Deliveroo plus Wolt; 100+ U.S. grocery banner integrations including Albertsons, Wegmans, Aldi. Each integration is a multi-month effort and once installed, contractually sticky.

What is **NOT** a moat: AWS infrastructure (rentable), generic LLM access (commoditized), brand (defensible only in conjunction with #1).

## AI buildout bottleneck map
- **Power generation / grid interconnect:** indifferent. DASH compute footprint is modest AWS spend (likely sub-$300M/yr — undisclosed); not capacity-constrained on generation.
- **Advanced packaging (CoWoS-L) / HBM3e / HBM4:** indifferent. No exposure as supplier or constrained customer.
- **Optical interconnect (CPO, 1.6T):** indifferent.
- **High-density liquid cooling (>100 kW/rack):** indifferent.
- **Kernel / compiler talent (CUDA, Triton, XLA):** indifferent — DASH ML stack uses standard frameworks.
- **Frontier-model training data quality:** indifferent.
- **Inference compute pricing for medium-quality LLMs:** **EXPOSED CUSTOMER, NET BENEFICIARY OF DEFLATION.** Voice-agent contact center on Bedrock+Claude (latency 2.5s, agent-transfer cuts of 49%, $3M annual savings cited) [8]; agentic merchant tooling and consumer assistant features depend on cost-per-token continuing to fall. A 5–10× collapse in mid-tier inference cost (Claude Haiku-class, GPT-mini-class) directly expands DASH's automatable customer-service and merchant-ops surface area.
- **Last-mile autonomy (sidewalk + drone):** **PARTNER MODEL, INDIRECT BENEFICIARY.** Coco Robotics 10K-robot 2026 deployment target across LA/Chicago/Miami including grocery [9], plus Wing/Alphabet drone delivery in Charlotte and Atlanta with SF Bay expansion in 2026 [10]. DASH gets the data network effect without taking the AV capex; the structural question is whether Coco/Wing eventually go vertical and bypass DASH (see bear case).

Net: DASH is **largely indifferent to the AI infra physical bottlenecks** that drive NVDA / AVGO / VRT / TSM theses. Its sensitivity is to the *price curve of inference*, not the physical capacity curve of training.

## Competitive teardown
- **Uber Eats.** Closest peer. Smaller U.S. restaurant share (~23–25%) but a structurally larger overall platform with rideshare cross-subsidy on driver supply. **Technical parity claim:** Uber's Michelangelo, Manifold, and DeepETA stacks are credibly within a generation of DoorDash's Sibyl/DeepRed. DASH's moat over Uber is **liquidity in U.S. suburbs**, not algorithm quality. Take share back would require Uber to win a category transition (groceries) before DASH closes its grocery unit-economics gap (which DASH has guided to inflect positive H2 2026 [17]).
- **Instacart (CART).** Adjacent, not direct. Has now embedded *Uber Eats* for restaurants inside its own app — explicit acknowledgment that they cannot solve restaurant logistics. Battleground is grocery, where Instacart still leads in retailer integrations but DASH's Wolt/Deliveroo rails plus DashMart give it scale. DASH grocery contribution-margin convergence is the key 2026 watch item.
- **Foundation-model agentic commerce stacks (OpenAI's ACP/Stripe, Anthropic's MCP, Google's Gemini agents).** The **most important competitor and the one not on a sell-side analyst's radar**. OpenAI shipped the Agentic Commerce Protocol (ACP) with Stripe and DoorDash launched a grocery surface inside ChatGPT in December 2025 [13]. Tony Xu's framing — agents handle discovery, DASH handles fulfillment [14] — is the *bull* read. The *bear* read: if ACP/MCP commoditize the consumer-facing UI, DASH's marketplace becomes a fulfillment API, and the take-rate split between "agent layer" and "fulfillment layer" gets renegotiated by whoever controls demand. Today the agent platforms have no driver supply, so DASH's negotiating position is strong. In 24 months that is less obvious.
- **Coco Robotics / Wing (Alphabet).** Today: partners. Risk vector: Coco's Coco-2 next-gen autonomous platform launched Feb 2026; if Coco achieves true L4 sidewalk autonomy at <$0.50/delivery cost, the marginal value of DASH's Dasher network falls. Wing/Alphabet has Walmart as an alternate distribution partner — this matters because it means DASH does not control Wing's roadmap.
- **International quick-commerce specialists (Bolt, Glovo, Just Eat Takeaway in pockets).** Wolt is gaining share in every operating country per Q1 transcript [17]; Deliveroo growing fastest in 4 years [17]. Integration risk and 3-stack overhead (~$100M tech replatform charge running through 2026 into early 2027 [17]) is the cost.

## Bull case — technical
For DASH to outperform from $164:
1. **Per-metro density compounding holds.** No major U.S. metro flips to a competitor; suburban share widens further. Falsifier: Second Measure / Bloomberg quarterly share data shows U.S. share <55% by Q4 2026.
2. **Inference-cost deflation continues.** Mid-tier LLM cost drops 3–5× over 24 months, allowing voice-ordering and merchant-agent workflows to expand from current pilots to >50% of inbound restaurant phone volume — directly converting unanswered-call revenue into a new high-margin SKU [8].
3. **Agent-layer fulfillment economics favor incumbents.** ACP/MCP integrations let DASH be the default fulfillment back-end for ChatGPT/Claude/Gemini commerce — replicating the pattern where Shopify became the back-end of e-commerce despite Amazon's surface dominance.
4. **Coco/Wing partnerships scale without going vertical.** 10K Coco robots deployed in 2026 [9] adds last-mile cost relief without DASH taking AV-fleet capex. Drone density triples in suburbs by year-end.
5. **Grocery contribution margin inflects positive H2 2026 as guided** [17], unlocking the largest unaddressed TAM (U.S. grocery is ~$1.4T vs. ~$300B restaurant).

If those hold, DASH grows GOV at 25%+ for 24 months, ad revenue prints $2.0B+ in 2026, EBITDA margin re-expands to 3.0% of GOV (vs. 2.4% in Q1) once replatform lap is done, and fair value reaches the consensus PT band of $250–$280.

**Base rate:** local-marketplace incumbents who maintain density typically hold share for 7–10 years post-IPO before serious displacement (eBay, Booking, Airbnb pattern). DASH IPO'd Dec 2020, so the natural displacement window is 2027–2030 — which lines up exactly with the agentic-commerce maturation window.

## Bear case — technical
A short-seller who understands the stack writes:
1. **Agentic commerce flips the consumer surface in 24 months.** OpenAI Instant Checkout, Anthropic MCP commerce, and Google's Gemini ordering all reach critical mass. The default consumer entry point for "I want pad thai" becomes a chat interface, not the DoorDash app. The DashPass switching cost — built around a *consumer-app* habit — degrades because the user no longer opens the app. DASH is reduced to a fulfillment commodity competing with Uber Eats on cost-per-delivery for an aggregator that captures the customer relationship and the take rate. This is the **single largest risk and is undermodeled by sell-side**.
2. **Algorithmic moat is shallow.** Sibyl, DeepRed, and Fabricator are good engineering [5][6][7] but the academic literature on GNN-based pickup-and-delivery and RL-based matching is now public and well-explored [19]; Uber's stack is at parity. A new entrant with $500M and 18 months can hire competent ML talent and bootstrap dispatch quality to within 5% of DASH in any single metro. The moat lives in the marketplace data, not the algorithm.
3. **AV/drone partners go vertical.** Coco-2 [9] and Wing [10] both have credible paths to bypassing DASH: Wing already serves Walmart directly. If Coco at >5K-robot scale can offer restaurants a direct-integrated delivery API undercutting DASH's commission by 5–10 points, DASH faces an asymmetric squeeze.
4. **Three-stack integration cost overruns.** $100M replatform charge through 2026 [17] is the *guided* number; integration of three incompatible code bases (DASH, Wolt, Deliveroo) historically slips 30–50% on cost in similar cross-border tech mergers (cf. Just Eat Takeaway / Grubhub).
5. **Take-rate compression structural, not cyclical.** Restaurants have post-pandemic normalized to dual-listing on multiple apps; commission resistance has forced caps in NYC, Chicago, San Francisco. International gig-worker classification rulings (UK, EU) have not yet hit, and a Deliveroo-territory adverse ruling would re-rate margins.
6. **Consumer discretionary beta.** Delivery is highly cyclical with low-end consumer wallet; if 2H'26 sees a labor-market slowdown, GOV decel exceeds modeled assumptions.

The clean bear thesis: **DASH at 32× forward earnings is priced for marketplace dominance to compound. The probability that an LLM-agent layer captures the consumer relationship within 36 months is materially higher than the consensus PT implies.** Fair value in that scenario is closer to fulfillment-utility multiples (~15–18× FCF), or roughly $90–110.

## Market view check
At $164 the stock has compressed ~42% from its October 2025 peak of $285.50 [3], with the YTD drawdown of ~22% [from search] coming despite a Q1 GOV beat [17]. The market is pricing two simultaneous worries: (a) revenue miss in Q1 implying take-rate compression in mix shift toward grocery/international, and (b) the agentic-commerce disintermediation tail risk. Sell-side consensus PT of $259 [16] embeds the bull case (per-metro density wins; ad business compounds; grocery inflects). The stock at $164 is **roughly the midpoint between a clean bull and clean bear**: bull says +50–60%, bear says −30–40%. The technical thesis I believe is most undermodeled is the agent-layer one — neither bulls nor bears have a confident view of how the take-rate split will be negotiated when agentic commerce reaches scale, and that single variable likely drives the next 24 months of the multiple more than EBITDA cadence does.

## 90-day falsifiers
- **Q2 2026 print (early August):** GOV growth <25% YoY, or U.S. restaurants GOV growth <15%, would invalidate the per-metro density thesis.
- **Material agentic-commerce announcement:** A major restaurant chain (McDonald's, Chick-fil-A, Domino's) signs *exclusive* fulfillment with Uber Eats inside ChatGPT/Claude — direct disintermediation evidence.
- **Coco Robotics 10K deployment cadence:** Public deployment count by end of Q3 — under 4,000 in-service indicates 2026 target slip.
- **Q2 EBITDA-margin trajectory:** if Adj EBITDA / GOV remains <2.5% (vs. 2.4% Q1, 2.6% prior), the replatform-cost narrative is hiding structural margin pressure.
- **Wolt/Deliveroo combined organic GOV growth:** sub-20% would suggest international integration drag is worse than the Q1 transcript framed [17].
- **Tech replatform cost guidance:** If management raises 2026 replatform spend above the original $100M envelope by >25% [17].
- **DashPass net-add disclosure:** any sequential decline in MAU or member growth deceleration discussed on Q2 call.
- **Regulatory:** UK Deliveroo gig-worker classification ruling — there is an ongoing process; an adverse ruling would re-rate the international segment.

## What I could not verify
- Exact take rate by segment (U.S. restaurants vs. grocery vs. international vs. ads) — DASH does not disclose at this granularity.
- Cost-per-delivery for Coco robot deliveries vs. human Dashers; only the 14,000-pilot delivery number is public.
- Independent benchmark of DASH's ETA prediction error vs. Uber's DeepETA — no MLPerf-equivalent exists for delivery ML.
- Specific AWS spend at DASH (rumored mid-9-figure but not disclosed) — directly relevant to Bedrock/Claude exposure sizing.
- Whether the Anthropic Bedrock contract is exclusive or whether DASH is dual-sourcing on OpenAI / Gemini for any customer-facing surfaces.
- Patent inventory specifically on dispatch / batching — DASH appears to be relatively patent-light (filed defensively, not offensively) but I could not verify exhaustively.
- Headcount split: ML/infrastructure engineers vs. total — relevant to "person-years to replicate" estimate in the moat section.
- Inference cost as % of revenue for the contact-center use case beyond the disclosed $3M savings figure [8] — net cost, not gross.
- Forward EPS consensus for FY26 used in the P/E math — composite from analyst targets; not all sources agree to the cent.

## Sources
[1] https://www.cnbc.com/2026/05/06/doordash-dash-earnings-q1-2026.html — retrieved 2026-05-10 — Q1 2026 earnings summary, stock reaction, revenue miss vs. EPS beat.
[2] https://www.stocktitan.net/sec-filings/DASH/8-k-door-dash-inc-reports-material-event-904631efb7bc.html — retrieved 2026-05-10 — Q1 2026 8-K, Marketplace GOV $31.6B (+37%), revenue $4.0B (+33%), Adj. EBITDA $754M.
[3] https://finance.yahoo.com/quote/DASH/history/ — retrieved 2026-05-10 — historical close $163.93 (May 8, 2026), 52-wk range $143.30–$285.50.
[4] https://ir.doordash.com/news/news-details/2026/DoorDash-Releases-First-Quarter-2026-Financial-Results/default.aspx — retrieved 2026-05-10 — official Q1 2026 financial release.
[5] https://careersatdoordash.com/blog/doordashs-new-prediction-service/ — retrieved 2026-05-10 — Sibyl architecture: LightGBM/PyTorch via JNI from Kotlin, Redis feature store, <100ms p99 latency.
[6] https://careersatdoordash.com/blog/using-ml-and-optimization-to-solve-doordashs-dispatch-problem/ — retrieved 2026-05-10 — DeepRed dispatch RL system, ML+optimization architecture.
[7] https://careersatdoordash.com/blog/introducing-fabricator-a-declarative-feature-engineering-framework/ — retrieved 2026-05-10 — Fabricator framework, ~500 features and 100B+ daily feature values.
[8] https://aws.amazon.com/solutions/case-studies/doordash-bedrock-case-study/ — retrieved 2026-05-10 — Anthropic Claude on Bedrock for voice contact center, 49% transfer reduction, $3M annual savings.
[9] https://about.doordash.com/en-us/news/doordash-coco-expand-partnership — retrieved 2026-05-10 — Coco Robotics partnership Miami expansion Nov 2025; 10K robots target in 2026.
[10] https://about.doordash.com/en-us/news/doordash-wing-expand-to-atlanta — retrieved 2026-05-10 — DoorDash + Wing drone delivery Atlanta launch April 2026, Charlotte expansion to 60K homes.
[11] https://ir.doordash.com/news/news-details/2025/DoorDash-Completes-Acquisition-of-Deliveroo/default.aspx — retrieved 2026-05-10 — Deliveroo acquisition close October 2025, $3.9B, 9 new countries.
[12] https://about.doordash.com/en-us/news/prop-22-decision — retrieved 2026-05-10 — California Supreme Court upheld Prop 22 (July 2024), independent contractor classification preserved.
[13] https://about.doordash.com/en-us/news/openai — retrieved 2026-05-10 — DoorDash launches grocery shopping inside ChatGPT (Dec 2025).
[14] https://www.restaurantbusinessonline.com/technology/why-doordash-isnt-afraid-ai-shopping-agents — retrieved 2026-05-10 — Tony Xu's positioning that DASH retains fulfillment as agents disintermediate discovery.
[15] https://stockanalysis.com/stocks/dash/statistics/ — retrieved 2026-05-10 — forward P/E ~32×, EV/Revenue trailing/forward multiples, valuation snapshot.
[16] https://public.com/stocks/dash/forecast-price-target — retrieved 2026-05-10 — 33 analysts, consensus PT $259.61, individual targets ($260 Jefferies, $275 Needham, $283 Citi, $320 Mizuho).
[17] https://www.fool.com/earnings/call-transcripts/2026/05/06/doordash-dash-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1 2026 earnings call: $100M tech replatform, Wolt/Deliveroo growth, grocery unit-economics inflection guided H2 2026.
[18] https://secondmeasure.com/datapoints/food-delivery-services-grubhub-uber-eats-doordash-postmates/ — retrieved 2026-05-10 — Bloomberg Second Measure on DASH 56–67% U.S. share, Uber Eats 23–25%.
[19] https://dl.acm.org/doi/10.1145/3494530 — retrieved 2026-05-10 — FoodMatch academic paper on bipartite-matching for batching, illustrating that the dispatch literature is now public.
[20] https://www.restaurantbusinessonline.com/technology/doordash-developing-ai-phone-answering-system — retrieved 2026-05-10 — DoorDash voice-ordering AI rollout for restaurants, building on Bedrock+Claude stack.
[21] https://www.statista.com/statistics/1550802/doordash-uber-gov-quarterly/ — retrieved 2026-05-10 — DASH Q4'25 GOV $29.68B vs. Uber Eats $25.43B comparison.