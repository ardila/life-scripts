# PLTR — Palantir Technologies, Inc.

## Where this sits in the AI stack
PLTR sells software at the **operationalization layer** sitting above the AI compute stack — not silicon, packaging, memory, networking, power, cooling, or model training. Specifically: a multi-tenant **object/relationship layer ("Ontology")** that sits on top of an Apache Iceberg data plane ("Multimodal Data Plane"), an **agent runtime ("AIP Logic")** that brokers prompts to OpenAI / Anthropic / Google / open-weights models hosted on customer or hyperscaler infra, and a **pull-based hub-and-spoke continuous-delivery substrate ("Apollo")** that lets the same stack run from AWS commercial all the way to DoD IL6 / air-gapped / tactical-edge environments [6][7][8]. Workload mix: enterprise/government inference orchestration with operational write-back to systems of record (ERP/MES/CRM/EHR/C2). They neither train frontier models nor sell GPUs.

## Snapshot
- **Price:** $137.80 (2026-05-08 close — most recent trading day) [1]
- **Market cap:** ~$327B [2]
- **52-week range:** $114.90 – $207.52 (currently ~34% below high) [1]
- **Forward P/E:** ~95× midpoint (range 87×–111× across sources on FY2026 consensus EPS ~$1.45) — multiples vary materially post-Q1 print [3]
- **EV / NTM revenue:** ~46× on management's raised FY26 guide of $7.65–7.66B [4][24]
- **Consensus 12-month PT:** $172.64 (Public.com, 29 analysts) to $194.17 (MarketBeat); implied +25% to +41% [5]
- **YTD total return:** approximately −17% (sources span −13.8% to −21.1%) [6]
- **Short interest:** 2.35–2.40% of float (~52M shares) [7]
- **Analyst distribution:** ~24–34 analysts; consensus "Moderate Buy" — roughly 18 Buy / 10 Hold / 2 Sell [5]
- **Insider activity:** ~$433M in insider sales last ~3 months, zero open-market buys; Thiel sold ~2M shares 3/2/26 at $141–$147 (~$290M over 6 months) [8]

## Moat — what it is physically made of
Decomposing into the actual technical components, with durability assessed separately.

**1. The Ontology (the highest-leverage piece).** Not a knowledge graph in the Neo4j sense — Palantir's own community forum acknowledges it is *weaker* than dedicated graph DBs on traversal [9]. It is a **microservices object/relationship layer** with Object Storage V2 architecture separating indexing (low-latency, streaming) from query execution (Spark) [10]. The differentiator vs. a dbt+LookML semantic layer is that it stores **Actions** (write-back functions with permissions, validators, rollback semantics) as first-class objects alongside data and models, propagating writes back into ERPs/MES/CRM/EHR/C2. Durability: medium-high. A read-only semantic layer is days of work; a *bidirectional operational* layer with permissioned action staging is a multi-year build, and Palantir has 10+ years of customer-installed schemas. Snowflake and Databricks have publicly conceded this layer in the last 12 months (see "Competitive teardown"), which is the strongest evidence the moat is real today. Estimated person-years to reach parity: **400–800 engineer-years**, and that does not include the installed-base effect.

**2. AIP Logic + AIP Evals (the agent runtime).** Three things: (i) model broker routing to OpenAI/Anthropic/Google/xAI/open-weights with contractual no-retention, (ii) agent runtime where agents call Ontology Actions as tools, (iii) audit log + eval harness [11]. The honest assessment: the *runtime* itself is replicable in 6–12 months (LangChain + Bedrock Agents + Pydantic guardrails gets you 70% there). The moat is **not** the runtime — it is the Ontology underneath, and the human-in-the-loop **Action staging** model that makes regulated customers comfortable letting agents write to production systems. Durability: low for runtime; medium for the staging/eval ergonomics; high in conjunction with Ontology.

**3. Apollo (the most underrated piece of IP).** Pull-based hub-and-spoke CD with cryptographically signed artifacts; same release stream deploys to AWS commercial, Azure Government, AWS GovCloud, DoD IL6, classified TS networks, on-prem, edge, and fully disconnected environments [12]. Apollo is what lets Palantir run as one product across all DoD impact levels without one release engineer per environment. Replicating this is a 2–4 year build that almost no one is trying to do — hyperscalers solve the multi-environment problem by *not* federating their environments. Durability: high.

**4. Government accreditations.** FedRAMP High (granted December 2024, after ~4 years of sponsor work and "60 people across 25 teams full-time for a year") [13], DoD IL5, DoD IL6 (one of ~6 cloud providers cleared), CMMC Level 2 (Sept 2025), ITAR. **FedStart** productizes this — Palantir now sells the accreditation substrate to other SaaS vendors [14]. Durability: high but eroding from the top — Google Distributed Cloud (air-gapped) achieved IL6 in 2025 with Gemini at IL6/TS [21], and Bedrock AgentCore came to AWS GovCloud in May 2026 [22]. The window is closing but is still ~24–36 months wide.

**5. Forward-Deployed Engineers (FDEs).** Embedded engineers who build production workflows inside customer environments for months at a time. Structurally a product-discovery mechanism, not a services business — features proven in the field get productized. Honest gap: Palantir does *not* disclose an FDE-to-license-revenue ratio; published "3× ARR growth from FDE motion" claims trace back to VC marketing, not audited data. Durability: medium — competitors can hire ex-Palantir FDEs (and do), but the institutional muscle for running this model at scale is rare. ServiceNow, Snowflake, Databricks all run more partner-led delivery.

**6. Patents.** ~155 ontology-related filings, ~51 granted globally; foundational US7962495B2 (dynamic ontology) and US8930897B2 (data integration) [15]. Enforceability untested in litigation against well-funded competitors — assume patents are *deterrent* value, not bankable defense. Durability: unverified.

**Honest summary:** the durable moat is items 1, 3, and 4 *in combination* — Ontology + Apollo + accreditations. AIP Logic is replicable; the FDE motion is hard to clone but is not by itself the moat. Brand effect inside DoD/Three-Letter agencies is genuine but is shorthand for the technical assets above.

## AI buildout bottleneck map
This is where the dossier template (designed for hardware/infrastructure names) doesn't fit cleanly — but the honest mapping itself is informative:

- **Grid interconnect / power generation:** Indifferent. Consumes hyperscaler compute downstream; does not own a turbine queue position.
- **Advanced packaging (CoWoS-L) / HBM3e / HBM4 supply:** Indifferent — but **indirect beneficiary**: more deployed accelerator capacity → cheaper inference → more enterprise AI applications → more demand for the orchestration/ontology layer. The Karp thesis explicitly is "tokens deflate, workflows capture value" [16].
- **Liquid cooling / >100 kW racks:** Indifferent.
- **Optical interconnect / scale-out fabric:** Indifferent.
- **Kernel / compiler talent (CUDA, Triton, TensorRT):** Indifferent — they don't write kernels.
- **Frontier model availability and pricing:** **Dependency** (they route to OpenAI/Anthropic/Google), not bottleneck-owner. Risk: if model providers vertically integrate down-stack (Anthropic's Claude for Enterprise, OpenAI's Stargate-era enterprise push), Palantir gets squeezed.
- **Training data quality at frontier:** Indifferent (don't train), but they *are* the system that fragments-then-unifies enterprise data — the bottleneck *their customers* face.
- **DoD/IC accreditation pipeline:** **Bottleneck owner.** This is their actual moat. The accreditation pipeline is a 1–4 year process and Palantir is one of a handful with FedRAMP High + IL5 + IL6 + CMMC L2 + ITAR.
- **FDE talent supply:** **Bottleneck owner internally.** Karp said on the Q1 call "we just cannot meet demand" [17] — the gating factor on commercial growth is FDE/Deployment Strategist hiring throughput, not pipeline.
- **Enterprise change management / data engineering scarcity at customers:** **Beneficiary.** Their value prop is precisely that customers can't hire enough data engineers fast enough to integrate their own systems.

The frame to use: PLTR is the **operationalization stack downstream of the buildout**. Hyperscaler capex is fuel, not constraint. The constraints it owns (accreditation + FDE throughput) are software/talent, not silicon.

## Competitive teardown
Threat mapping, in descending order of credibility:

**Microsoft (most credible structural threat in gov, currently a partner).** Fabric + Copilot Studio + Azure AI Foundry, with Azure Government / Gov Secret / TS clouds. Microsoft is the dominant DoD productivity incumbent. The Aug 2024 partnership lets Palantir Federal Cloud Service run on Azure Gov / Gov Secret / TS [18] — coopetition. Microsoft keeps compute revenue; Palantir keeps the ontology/workflow. The longer Copilot Studio's agent orchestration matures and Office/Teams gravity pulls users in, the more Microsoft can wedge into the commercial mid-market. Defense displacement is not credible in the current Maven contract window (through 2029).

**ServiceNow (the most underrated rival, almost no analyst frames it this way).** Now Assist ACV reached ~$600M in 2025, tracking >$1B by year-end; Workflow Data Fabric + AI Agent Fabric + RaptorDB + AI Control Tower [19]. ServiceNow already owns the IT/HR/CRM workflow plane in the F500. Adding agents to existing deployments is a low-friction wedge into "AI workflows on enterprise data." ServiceNow runs ~3× Palantir revenue at ~21% growth. Where ServiceNow loses: cross-domain ontology, multi-INT fusion, classified.

**Databricks (parity threat on data layer, partner on workflow).** Acquired Tabular (>$1B, June 2024); Unity Catalog now supports Iceberg REST Catalog ending table-format lock-in; Agent Bricks (June 2025) directly mimics AIP's "build agents on your data" pitch [20]. ~$5.4B ARR, ~65% YoY, $134B post-money pre-IPO. *But*: March 2025 strategic partnership with Palantir, >150 joint production customers including DoD, Treasury, BP. Databricks effectively conceded the operational/ontology layer.

**Snowflake (now partner, conceded).** Cortex AI/Agents/Intelligence; Streamlit-in-Snowflake. The October/November 2025 Snowflake–Palantir announcement of bidirectional zero-copy Iceberg interop is the most concrete public evidence that the warehouse layer has stopped trying to build the workflow layer [23].

**AWS (partner, with a tailwind kicker).** Bedrock AgentCore launched in AWS GovCloud May 2026 [22]. The March 2026 DoD designation of Anthropic as a "supply chain risk" (forcing AWS to carve Claude out of defense workloads) is, paradoxically, a tailwind for PLTR — it cements that the accreditation moat (not the model) is what defense buyers are paying for.

**Google (real air-gapped threat in 2026–28).** Google Distributed Cloud air-gapped achieved DoD IL6 in 2025; Gemini at IL6/TS [21]. First credible hyperscaler-native alternative for classified workloads. Watch JWCC ($9B IDIQ, runs through ~June 2028) task order distribution as the canary.

**Anduril.** Complement, not competitor — PLTR's TITAN team explicitly includes Anduril alongside Northrop, L3Harris, SNC. The combined Anduril/Palantir stack is the de facto "modern defense software" reference architecture. Lattice OS competes with Gotham only at the tactical-edge C2 layer, not in mission-planning/multi-INT fusion.

**C3.ai.** Q1 FY26 revenue −19% YoY, 26% RIF in April 2026, narrative collapsed [25]. Useful only as a counter-example: same vertical, same "enterprise AI platform" pitch, totally different outcome — which is *evidence* that the Palantir moat is not just vertical software branding.

**OSS build-it-yourself (LangChain/LlamaIndex/Haystack + Bedrock/Vertex).** Caps mid-market commercial TAM. Make-vs-buy flips toward AIP when (a) >5 source systems, (b) regulated/classified, (c) operational write-back required.

**No published independent benchmark** (no MLPerf analog) compares AIP head-to-head with these alternatives on workflow accuracy or TCO. Evaluation is narrative — Gartner Peer Insights, AIPCon demos, customer testimonials.

## Bull case — technical
The conditions that have to hold:

1. **Ontology + Action staging + Apollo remain the path of least resistance for regulated, multi-system, write-back AI workflows.** Base rate for platform moats at this maturity (10+ years of installed schemas, customer dependency on Foundry pipelines for operational systems): erosion happens slowly. Compare CPU→GPU (15 years to displace), on-prem→cloud (15+ years and still incomplete in defense), x86→ARM in mobile (10 years and never reached server parity). A workflow-layer moat reinforced by accreditation typically takes 5–10 years to erode once entrenched.
2. **Frontier-model commoditization continues.** Token prices have fallen ~1000× in ~3 years [17]. If this continues, value migrates from model providers to the orchestration/ontology layer — exactly where PLTR sits. Sankar's framing ("tokens are the new coal, AIP is the train") is the right shape of the bet.
3. **FDE throughput scales.** Currently the binding constraint; if Palantir can scale FDE hiring 30–40% YoY while maintaining Bootcamp conversion (615 US commercial customers, +42% YoY), the US commercial growth runs above 100% YoY for another 4–6 quarters.
4. **DoD/IC consolidation accelerates.** $10B Army Enterprise Agreement consolidated 75 active contracts; Maven Smart System ceiling raised to $1.3B with NATO adoption; >20k Maven users across 35 tools, 4× growth in a year [26][27]. DOGE-era posture is net-positive for Palantir as the consolidator, not negative.
5. **Hyperscaler air-gap (GDC IL6, Bedrock AgentCore in GovCloud) does not reach Palantir parity on multi-INT ontology before 2028.**

Financial outcome conditional on the above: revenue compounds 50%+ for 3 more years to ~$25B by FY29, FCF margin holds 55–60%, the multiple compresses from 46× EV/NTM to ~25× — yielding ~30% IRR from $138.

## Bear case — technical
A short-seller who actually reads the stack would write this:

1. **The Ontology is not as proprietary as Palantir's branding suggests.** Iceberg is open. Unity Catalog (Databricks), Polaris (Snowflake), Glue (AWS) are all converging on multi-engine open catalogs. The *Actions* layer is what's left, and Databricks/ServiceNow are explicitly building it.
2. **AIP's runtime moat is thin.** Bedrock AgentCore + Knowledge Bases + Anthropic Claude with bidirectional tool calling reaches functional parity with AIP Logic for ~80% of enterprise use cases in 12–18 months. Customers running Foundry will keep it; greenfield AI buyers in 2027 evaluate AIP against AgentCore + Vertex Agent Builder, not against 2023-era LangChain.
3. **Accreditation moat is closing.** GDC + Gemini at IL6/TS is a 2025 fact. Bedrock AgentCore in GovCloud is a 2026 fact. The pipeline that took Palantir 4 years to navigate is becoming a standard hyperscaler offering. By 2028 the marginal new defense customer has more credible alternatives than today's selection set suggests.
4. **The FDE motion does not scale linearly with revenue.** Karp's "we cannot meet demand" cuts both ways — it's either a tailwind or an admission that there's a structural ceiling.
5. **International commercial is genuinely weak.** Germany's Bundeswehr declined adoption in April 2026 in favor of Almato/Orcrist/ChapsVision [28]. UK NHS FDP rollout is partial (797k patients off waiting lists but >50% of trusts not actively using it; February 2027 break-clause being considered on the £330M contract) [29]. Europe is building sovereign alternatives. International rev is 21% of total and shrinking as a share.
6. **Insider behavior.** $433M of insider sales over 3 months with zero open-market buys; Thiel selling $290M over 6 months at $141–$147 [8]. Insiders sell for many reasons but rarely buy under-valued names; the absence of buys when the stock is 34% off its high is a real signal.
7. **Valuation already prices perfection.** 46× EV/NTM revenue, ~95× forward P/E. For comparable software-at-scale: Snowflake ~12× EV/rev, ServiceNow ~14× EV/rev, Salesforce ~7× EV/rev. PLTR is priced 3–6× richer than the peer set with structurally similar end-state economics. Even if every technical bull case point holds, a 25× EV/rev multiple is a -45% compression by 2028.

## Market view check
At $138, 46× EV/NTM revenue, ~95× forward P/E, consensus PT $172–194 (~25–41% upside), and YTD −17% off a $208 high: the market is currently pricing **"best-in-class software execution + measured multiple compression."** Q1 2026 was a genuine blowout (revenue +85% YoY, US +104%, Rule of 40 = 145, FCF margin 57%, NDR 150%, guide raised to $7.65B vs $7.27B consensus) — and the stock fell 5–6% on the print. That price action says the print is priced in and the question is forward sustainability, not current quality. The market apparently believes: (a) the technical reality is roughly what I describe above, (b) growth decelerates from current 85% to ~30–40% over 2 years, (c) multiple compresses to 20–25× EV/rev. The honest disagreement to surface is: if you think the hyperscaler air-gap closes the accreditation moat faster than 2028, the consensus PT is too high. If you think frontier-model commoditization accelerates (token prices keep falling 5× annually) and value migration to the workflow layer is faster than consensus, the PT is too low.

## 90-day falsifiers
- **Q2 FY26 earnings (early Aug 2026):** US commercial growth holding above 100% YoY would confirm thesis; deceleration below 80% with no guide raise would be the first material crack.
- **Maven Smart System / JWCC task order announcements:** any sign DoD is opening Maven-equivalent workflows to MSFT/AWS/Google rather than expanding Palantir's footprint.
- **Bootcamp conversion print:** Palantir occasionally publishes US commercial customer count and $1M+/$5M+/$10M+ TCV deal cohorts in monthly investor decks. A sequential customer-count miss after 8 quarters of acceleration is a leading indicator.
- **Insider buying or further selling at scale:** any 13D/4 filing showing Karp/Sankar/Cohen buying would update the bear-case insider-behavior signal materially. Continued ~$100M/month sales would reinforce it.
- **UK NHS FDP February 2027 break-clause posture:** any official UK government statement in next 90 days about contract review.
- **AIPCon 9 (likely Sept/Oct 2026):** announced new customer logos vs. notable absentees; any new product layer announced (memory, multi-agent orchestration, foundation-model-of-record).
- **Google Distributed Cloud / Bedrock AgentCore enterprise adoption:** any large defense customer publicly announces selecting GDC + Gemini or Bedrock AgentCore over PLTR for a workflow PLTR would have won 12 months ago.
- **ServiceNow Now Assist FQ disclosure:** ACV crossing $1B with named cross-domain AI agent workloads (not ITSM-adjacent) would confirm the workflow-encirclement bear case.
- **Bundeswehr-style European declines:** any second NATO member publicly choosing a non-Palantir AI workflow stack.

## What I could not verify
- Exact storage engines underlying Object Storage V2 (Palantir does not disclose) — material to "person-years to replicate" estimate.
- Current FDE headcount and FDE-to-license-revenue ratio — material to scalability ceiling.
- True AIP Bootcamp conversion rate (sources spread 30% to 75%) — Palantir-sourced figures are higher than third-party estimates.
- Patent enforceability against well-funded competitors — no high-profile Palantir patent litigation has tested the moat.
- Q1 2026 international commercial growth detail (not headlined in available coverage).
- Precise stock-based compensation in Q1 2026 (FY2025 SBC ~$684M / ~9% of revenue; specific quarterly figure requires the 10-Q).
- Whether a Sankar appearance on Dwarkesh exists (Stratechery 2023, Shawn Ryan, ARK, Alphalist do; Dwarkesh I could not confirm) — minor.
- Independent benchmark of AIP vs. Bedrock AgentCore / Vertex Agent Builder / Fabric IQ on workflow accuracy or TCO (no MLPerf analog exists).
- Forward P/E precise multiple — analyst EPS estimates span $1.25–$1.58 for FY26 yielding 87×–111× spread.

## Sources
[1] https://finance.yahoo.com/quote/PLTR/ — retrieved 2026-05-10 — established the May 8 2026 close of $137.80 and 52-week range $114.90–$207.52.
[2] https://companiesmarketcap.com/palantir/marketcap/ — retrieved 2026-05-10 — established market cap ~$325–330B.
[3] https://stockanalysis.com/stocks/pltr/statistics/ — retrieved 2026-05-10 — established forward P/E range 87×–111× across sources; FY26 EPS consensus $1.25–$1.58.
[4] https://www.tikr.com/blog/palantir-stock-has-dropped-31-from-its-peak-heres-where-pltr-could-go-in-2026 — retrieved 2026-05-10 — established EV/NTM revenue ~46× on $7.65B FY26 guide.
[5] https://www.tipranks.com/stocks/pltr/forecast — retrieved 2026-05-10 — established consensus 12-mo PT range $172.64 (Public.com) to $194.17 (MarketBeat), 24–34 analysts covering.
[6] https://www.financecharts.com/stocks/PLTR/performance/total-return — retrieved 2026-05-10 — established YTD 2026 total return of approximately −17%.
[7] https://www.marketbeat.com/stocks/NASDAQ/PLTR/short-interest/ — retrieved 2026-05-10 — established short interest 2.35–2.40% of float.
[8] https://www.ad-hoc-news.de/boerse/news/ueberblick/palantir-s-433-million-insider-sell-off-sets-stage-for-high-stakes/69176208 — retrieved 2026-05-10 — established ~$433M insider sales in 3 months and Thiel/Karp/Cohen specifics.
[9] https://www.palantir.com/docs/foundry/architecture-center/ontology-system — retrieved 2026-05-10 — established Ontology as microservices object/relationship layer (not a Neo4j-style graph DB).
[10] https://www.palantir.com/docs/foundry/object-backend/overview — retrieved 2026-05-10 — established Object Storage V2 architecture separating indexing from query execution.
[11] https://www.palantir.com/docs/foundry/architecture-center/aip-architecture — retrieved 2026-05-10 — established AIP as model broker + agent runtime + audit/eval layer.
[12] https://www.palantir.com/assets/xrfr7uokpv1b/3B5KbQ9ujsiDCX4Tnfz3Hy/8d3ee9a6911665f036ce3d28c19cfa0d/PalantirApolloTechnicalWhitePaper.pdf — retrieved 2026-05-10 — established Apollo as pull-based hub-and-spoke CD with cryptographic signing across IL5/IL6/air-gapped environments.
[13] https://investors.palantir.com/news-details/2024/Palantir-Granted-FedRAMP-High-Baseline-Authorization/ — retrieved 2026-05-10 — established FedRAMP High authorization December 2024 and accreditation process scope.
[14] https://www.palantir.com/offerings/fedstart/ — retrieved 2026-05-10 — established FedStart as productized accreditation substrate sold to other SaaS vendors.
[15] https://patents.google.com/patent/US7962495B2/en — retrieved 2026-05-10 — established foundational dynamic-ontology patent US7962495B2.
[16] https://www.palantir.com/q1-2026-letter/en/ — retrieved 2026-05-10 — established Karp/Sankar token-commoditization framing ("tokens are the new coal, AIP is the train").
[17] https://www.fool.com/earnings/call-transcripts/2026/05/04/palantir-pltr-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — established Karp Q1 2026 call quotes including "we cannot meet demand" and token-cost 1000× decline framing.
[18] https://news.microsoft.com/source/2024/08/08/palantir-and-microsoft-partner-to-deliver-enhanced-analytics-and-ai-services-to-classified-networks-for-critical-national-security-operations/ — retrieved 2026-05-10 — established Aug 2024 Microsoft–Palantir partnership for Azure Gov / Gov Secret / TS clouds.
[19] https://cloudwars.com/innovation-leadership/palantir-puts-bullseye-on-servicenow-re-ai-platform-supremacy/ — retrieved 2026-05-10 — established ServiceNow Now Assist ACV trajectory ~$600M → $1B+ and competitive positioning.
[20] https://www.databricks.com/company/newsroom/press-releases/databricks-launches-agent-bricks-new-approach-building-ai-agents — retrieved 2026-05-10 — established Databricks Agent Bricks June 2025 launch and competitive overlap with AIP.
[21] https://cloud.google.com/blog/topics/public-sector/google-distributed-cloud-gdc-gdc-air-gapped-appliance-achieve-dod-impact-level-6-il6-authorization — retrieved 2026-05-10 — established Google Distributed Cloud air-gapped IL6 authorization in 2025.
[22] https://aws.amazon.com/about-aws/whats-new/2026/05/bedrock-agentcore-launch-aws-govcloud-us/ — retrieved 2026-05-10 — established Bedrock AgentCore launch in AWS GovCloud May 2026.
[23] https://www.snowflake.com/en/news/press-releases/snowflake-palantir-announce-strategic-partnership-for-enterprise-ready-ai-analytics/ — retrieved 2026-05-10 — established Snowflake–Palantir Iceberg interop partnership Oct/Nov 2025.
[24] https://investors.palantir.com/files/Palantir%20-%20Q1%202026%20Business%20Update.pdf — retrieved 2026-05-10 — established Q1 2026 results and raised FY26 guide of $7.65–7.66B.
[25] https://www.fool.com/coverage/charts/2026/04/09/c3ai-vs-palantir-technologies-diverging-paths-in-revenue/ — retrieved 2026-05-10 — established C3.ai Q1 FY26 revenue −19% YoY and competitive collapse.
[26] https://defensescoop.com/2025/05/23/dod-palantir-maven-smart-system-contract-increase/ — retrieved 2026-05-10 — established Maven Smart System contract ceiling raised to $1.3B through 2029.
[27] https://defensescoop.com/2026/04/15/palantir-maven-smart-system-pentagon-program-transition-feinberg/ — retrieved 2026-05-10 — established April 2026 DoD posture accelerating Maven adoption across components.
[28] https://www.escudodigital.com/en/defense/europe/palantir-embeds-across-european-militaries-nato-germany-holds-back.html — retrieved 2026-05-10 — established Bundeswehr April 2026 decline and European sovereign alternatives.
[29] https://www.digitalhealth.net/2026/04/fdp-to-ramp-up-ai-use-with-scheduling-triage-and-discharge-tools/ — retrieved 2026-05-10 — established UK NHS FDP partial rollout status and Feb 2027 break-clause consideration.