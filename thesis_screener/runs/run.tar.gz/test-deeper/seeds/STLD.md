Synthesis complete. Writing the dossier now.

# STLD — Steel Dynamics, Inc.

## Where this sits in the AI stack
STLD is not in the AI stack in any silicon, packaging, networking, or software sense. It is a U.S. electric-arc-furnace (EAF) "mini-mill" steel producer (≈16Mt/yr flat-rolled, long-products, joist/deck, plus a ramping ~650kt/yr aluminum flat-roll mill) [1][8][14]. Its AI exposure is one layer below the rack: structural carbon steel, galvanized sheet, and steel joists/deck feeding **data center building construction**, plus aluminum sheet that touches conductors and HVAC. It does **not** make grain-oriented electrical steel (GOES) for transformer cores — that is Cleveland-Cliffs' (CLF) sole-source U.S. franchise [4][12]. STLD is a beneficiary of the AI buildout via construction tonnage, not via the electrical bottleneck that is actually gating the buildout.

## Snapshot
- **Price:** $241.84 (2026-05-07 close) [1]
- **Market cap:** ~$33.1B [1][15]
- **52-week range:** $119.89 – $243.73 (trading ~0.8% below 52-week high) [1]
- **Forward P/E:** ~26.8× (consensus FY26 EPS $9.01) [1][16]
- **EV / NTM revenue:** ~1.54× (EV ~$33.7B / consensus 2026 rev $21.9B) [15][16]
- **EV / TTM EBITDA:** ~14.6× (EBITDA TTM $2.32B) [15]
- **Consensus 12-month price target:** $215.62 (implies **-10.8%** from current; analysts behind the stock) [13]
- **YTD total return:** n/a — could not source a verified May-7 YTD print; from the $119.89 52-wk low the stock has roughly doubled, so trailing 12-month return is order-of-magnitude +100% [1]
- **Short interest:** 3.06% of shares outstanding (~4.43M shares) [13]

## Moat — what it is physically made of
STLD's moat is **not** a software ecosystem or IP fortress; it is the conjunction of three durable, physical advantages and one regulatory one. Decomposing:

1. **EAF cost structure vs. integrated BF-BOF.** Mini-mill capex is ~$140–200/ton of installed capacity vs. ~$1,000/ton for an integrated mill, with $8–18/ton maintenance vs. $14–28/ton for BF-BOF, plus the ability to ramp on electricity price [11]. STLD operates an internally integrated scrap supply (OmniSource — ~6Mt/yr of processed scrap) that hedges ~40% of its busheling feedstock at a time when prime busheling is at $423/GT, near 2-year highs and >70% of EAF variable cost [10][11]. **Durability: high but commoditizing** — Nucor (NUE), CMC, and a wave of new EAF entrants (US Steel's Big River 2 ramped to 6Mt total capacity 2026 [9]) are replicating this model. EAF share of U.S. steel production has gone from ~50% in 2010 to ~70% today; the technology arbitrage is mostly priced in.

2. **Specific physical assets in their ramp years.** Sinton, TX (3Mt/yr flat-roll EAF, $1.9B build) is exiting 2026 at ~90% of nameplate, with four downstream value-add coating/paint lines [3][14]. Aluminum Dynamics (Columbus MS, 650kt/yr + 150kt slab in Mexico/Arizona) is exiting 2026 at ~75% utilization, targeting $650–700M of through-cycle EBITDA when ramped [5][14]. Management states the three new projects combined will add **$1.4B/yr of through-cycle EBITDA** [14]. That number is the actual investable thesis: vs. 2024 base of ~$2B EBITDA, this is a ~60–70% earnings step-up that is mechanical, not market-dependent, **if** the mills run as designed.

3. **Joist & deck dominance via New Millennium Building Systems**, the #2 U.S. producer of steel joist/deck [6]. This product is the unsexy core of the data-center-construction beneficiary thesis: it ships from Indiana, Florida, Virginia, Utah, and Mexico into the actual structural envelope of a hyperscale shell. Switching cost here is logistics-driven (joist is a low-density freight product where regional supply ≈ moat) — competitors are Nucor Vulcraft (the #1) and Canam, and the market is consolidated to a near-duopoly with NUE.

4. **Section 232 50% tariff wall** [7]. Trump's June 2025 doubling of Section 232 from 25% → 50%, expanded in April 2026 to apply duties on full-customs-value of imports, is the single biggest reason U.S. HRC trades at ~$1,000/t vs. world (~$550) [2][7]. This is a regulatory moat, not a physical one — it is durable across administrations (Biden retained Section 232; Trump expanded it) but has a real falsifier in trade-deal carve-outs.

What STLD's moat is **not**:
- It is **not** a GOES franchise. The U.S. transformer-steel monopoly is CLF (Butler, PA + Zanesville, OH, ~250kt/yr) [4][12]. If the narrative you want to own is "transformer shortage → grid steel," CLF is the stock.
- It is **not** technology IP. EAF and continuous-casting know-how is broadly licensed (SMS group, Danieli, Primetals build these mills for anyone with capital) [3].
- It is **not** customer lock-in. Steel is a spec'd commodity; switching costs are logistics, not technical.

A competitor with $5–7B of capital and 4 years of patience can replicate the cost structure. The U.S. mini-mill build pipeline (Big River 2, NUE West Virginia mill, NUE Apple Grove plate mill, CMC Arizona 2) confirms this is happening [9].

## AI buildout bottleneck map
The 24-month gating constraints on AI deployment in order of bindingness, and where STLD sits on each:

| Bottleneck | Status (2026) | STLD position |
|---|---|---|
| **Power generation & interconnect** | Gas-turbine backlog >5 yrs (GE Vernova, Siemens Energy book-to-bill ~2.5×); utility interconnect queues >24 months in PJM, ERCOT [2] | **Indifferent.** Sells some structural to power-plant builds, no direct turbine exposure. |
| **Large power transformers (LPT) and GSU transformers** | Lead times 128–144 weeks; prices +77% since 2019; **GOES is the binding sub-input** [2] | **Negative-adjacent.** Transformer scarcity *slows* the data centers that buy STLD's joist. Not a beneficiary. CLF is the GOES winner here. |
| **Advanced packaging (CoWoS-L)** | TSMC adding capacity through 2027; still tight | **Indifferent.** |
| **HBM3e/HBM4** | Samsung, SK Hynix, Micron tight | **Indifferent.** |
| **Optical interconnect / co-packaged optics** | Constrained | **Indifferent.** |
| **Liquid cooling >100kW/rack** | Vertiv, nVent, Boyd, CoolIT scaling | **Marginal beneficiary** through galvanized sheet for cooling units. |
| **Data-center building shell (steel, concrete, electrical)** | 60M sq ft of hyperscale construction planned 2026; cold-formed and structural steel demand growing 30% YoY [8][17] | **Direct beneficiary.** Joist/deck backlog +38% YoY, extending into Oct 2026 [3][6]. |
| **Electrical contractor / switchgear** | Eaton, Schneider book-to-bill >1.5× | **Indifferent.** |
| **Kernel/compiler/training talent** | Tight | **Indifferent.** |

Read this honestly: the binding constraints on the AI buildout are electrical (transformers, switchgear, generation). **Steel is not a bottleneck.** When a hyperscaler delays a build, it is because they cannot get a 500MVA transformer or a 230kV interconnect — not because they cannot get HRC. This means STLD's data center demand is **derivative of and capped by** the slower upstream bottleneck. The narrative that conflates "AI buildout" with "steel boom" overstates the magnitude of STLD's upside.

## Competitive teardown
On the axes that matter to STLD:

- **Nucor (NUE)** — the dominant comp, ~$73B market cap (~2.2× STLD). Nucor states it supplies "over 95%" of steel products used in U.S. data center construction [3][18]. Vulcraft (Nucor's joist arm) is bigger than New Millennium; Nucor's "Warehouse Systems" and "Data Systems" dedicated business units launched 2022/2024 specifically targeting this segment [18]. **Verdict: NUE has structural advantage in this exact end-market.** STLD has higher net margins (~6.5% vs. 5.4%) but smaller absolute data-center share [18]. If you want pure-play U.S. data-center carbon steel, NUE is the better expression; STLD is the levered second-best.

- **Cleveland-Cliffs (CLF)** — the only meaningful overlap is in commodity flat-rolled. CLF is sole-source for U.S. GOES (transformer cores) and a major NOES producer (motor laminations) [4][12]. **They are not really competing on the same axis as STLD.** CLF owns the transformer-steel bottleneck; STLD does not.

- **U.S. Steel / Nippon Steel (X)** — Big River 2 ramped in early 2026, adding 3Mt of flat-rolled EAF capacity, total 6Mt at the campus [9]. This is *the* direct supply threat to STLD's Sinton ramp economics — it's another modern EAF flat-rolled mill in the same product/geographic adjacency. **Sinton's ramp to 90% utilization is partially contingent on demand outrunning BR2's parallel ramp.**

- **Imports / Posco / ArcelorMittal / China** — capped by 50% Section 232. The tariff is the single largest variable here. A trade deal that exempts even one major exporter (Korea, Brazil, Mexico) could compress HRC by $150–250/t. **Verdict: regulatory moat, not technological — and 2025-2026 saw it strengthened, not weakened** [7].

- **Aluminum competitors (Novelis, Constellium, Kaiser)** — STLD's new Aluminum Dynamics ramp lands into a market where Novelis (Hindalco) is dominant in can-sheet and auto-body. STLD is going after the 45% beverage-can / 35% auto / 20% industrial mix [5]. **They will not displace Novelis; the question is whether they can hit ~75% utilization without margin destruction.** ADI's first coil shipped June 2025 — too early to judge yield, surface quality, and OEM qualification (multi-month process for auto-body).

## Bull case — technical
For STLD to outperform from $241, three technical conditions must hold:

1. **Sinton and Aluminum Dynamics hit ramp targets without yield disasters.** Sinton's exit-2026 90% utilization is the critical mechanical step-up. Aluminum's auto-body qualification matters more than the headline can-sheet shipments. Base rate on greenfield steel/aluminum mill ramps: first 18-24 months typically run 10-20 points below plan (Sinton itself slipped 2022-2024). If the projects hit, mechanical EBITDA adds $1.4B/yr [14] — a >50% increase on TTM.

2. **Section 232 stays at 50% and HRC stays above $900/t.** U.S. HRC at ~$1,000 is almost entirely tariff-supported; world HRC trades closer to $550 [7]. STLD's $1,193/t average Q1 realized price [3] embeds this. Any softening of tariffs compresses through-cycle realizations directly.

3. **Data center carbon-steel pull-through continues into 2027.** 60M sq ft of hyperscale construction planned 2026, with backlog +38% YoY into October 2026 [3][17]. Base rate: hyperscale capex cycles run 8-12 quarters from announcement; we are 6-8 quarters in. There is likely 12-18 months of structural-steel pull-through before any deceleration.

If all three hold, STLD can sustain mid-to-upper-cycle margins for 6-8 more quarters, deliver $11-12 EPS through 2027, and re-rate modestly. **Base rate on technology displacement at this stage:** steel is not subject to technology displacement on a 5-year horizon. The risk is cyclical, not substitution.

## Bear case — technical
The version a short-seller who has read steel cycles 1995-2024 would write:

1. **Mid-cycle peak pricing in a 27× forward P/E.** STLD at $241 trades at ~26.8× forward EPS [1][16]. Historical steel cyclicals trade 5-9× peak earnings, not 25-30×. The market is pricing the new mills + AI data-center demand as **permanent through-cycle**, not peaking. Steel multiples have *never* sustained at this level. STLD's own 5-year historical EPS growth is 1.6%/yr [13] — the 21%/yr growth analysts now project is a regime change, not a continuation.

2. **Scrap squeeze on the EAF model.** Prime busheling at $423/GT is at 2-year highs as every new EAF (BR2, NUE WV, CMC AZ2) competes for the same prime scrap pool [10]. The U.S. produces a finite amount of #1 busheling; the EAF buildout is **demand-pulling** its own raw material cost. STLD's scrap-derived margin advantage compresses as EAF share approaches 80%+ of U.S. output. CLF and NUE both face the same dynamic, but STLD is more scrap-exposed than CLF (which still has BF-BOF capacity).

3. **Section 232 fragility.** Tariffs are an executive action, reversible by executive action. Any trade-deal exemption (UK already got 25% vs. 50%) [7], or a recession-driven political backlash on input costs, removes $150-250/t from HRC. STLD's 2026 EBITDA is significantly more tariff-sensitive than its multiple acknowledges.

4. **Big River 2 and the EAF flat-rolled glut.** With Sinton, BR2, and announced NUE West Virginia capacity, the U.S. is adding ~9Mt of new EAF flat-roll into a market that historically absorbs 35-40Mt domestically. Even with strong demand, this risks a 2027-2028 oversupply just as data-center construction normalizes from its surge [9].

5. **Steel is not actually constraining the AI buildout.** Transformers, generation, and interconnect are. If the *real* bottlenecks delay 30-50% of planned data center MW into 2027-2028 [2], steel demand front-loaded into 2026 reverses. The market is treating STLD as if it sits at the AI bottleneck. It does not.

6. **Aluminum Dynamics is a $2.7B capex bet against entrenched competition.** ADI ramping into a market dominated by Novelis with no obvious technology or cost edge — just capacity. Auto-body qualification is multi-year; if commercial discipline slips in beverage-can to fill the mill, EBITDA targets miss. The $650-700M guide is unstress-tested.

The honest base rate: U.S. integrated and mini-mill steel stocks have **never** sustained 25× forward multiples through a cycle. The closest analog (1996, 2008, 2014, 2021) saw 50-70% drawdowns from cyclical peaks within 18 months of the peak P/E print.

## Market view check
At $241 vs. $215 consensus PT [13], the stock trades **above** sell-side estimates — the analyst community is behind, not ahead, of the price. EV/TTM EBITDA at 14.6× and forward P/E at 26.8× embed a permanent-mid-cycle scenario: that Sinton + ADI ramp fully, that 50% tariffs persist, and that data-center steel demand stays elevated through 2027-2028. This is internally consistent only if AI infrastructure spend continues to surprise upward *and* the EAF flat-rolled supply additions get absorbed without margin damage. My read: the market is paying for **mechanical EBITDA growth from the new mills** at quality-compounder multiples while ignoring that the new mills land into peak steel pricing that is unlikely to persist. A 5× EBITDA cyclical multiple on a fully-ramped $3.5-4B EBITDA gives $17-20B EV — meaningfully below today. A 10× quality-mini-mill multiple on the same EBITDA gives $35-40B EV — roughly today. The market is paying the quality-compounder price for a tariff-supported, cyclical-peak business. **Direction: I disagree on the durability of the multiple, not on the next 2-3 quarters of earnings.**

## 90-day falsifiers
- **Sinton Q2 2026 utilization disclosure** (~late July earnings). If utilization slips below ~75% by Q2 print, the exit-2026 90% target loses credibility and the $1.4B incremental EBITDA story compresses. Conversely, ≥80% Q2 utilization confirms the ramp.
- **ADI Q2 utilization and any auto-body qualification commentary.** Trajectory toward the 40-50% mid-year / 75% exit-2026 target [5]. Margin disclosure on aluminum will reveal whether they are filling at price.
- **Prime busheling and shredded scrap pricing through July-August seasonality.** A move above $475/GT compresses STLD's metal spread; a move back to $375/GT supports the model.
- **HRC futures (CME) curve.** Front-month HRC dropping below $850/t (current ~$1,000) would signal Section 232 fatigue or import workaround.
- **Section 232 carve-out announcements.** Watch for Korea, Mexico, Japan, or Brazil exemption negotiations. Any meaningful exemption is a -$10-20 stock event.
- **Nucor Q2 earnings (mid-July).** Their data-center commentary is the cleaner real-time read on hyperscale construction demand. A Vulcraft backlog deceleration would foreshadow STLD's joist/deck print.
- **U.S. Steel Big River 2 utilization commentary.** BR2 ramping faster than planned signals oversupply risk for STLD's Sinton.
- **One large hyperscaler capex revision** (META, MSFT, GOOGL, AMZN Q2 earnings late-July). A cut of >10% sequential signals the construction backlog turns.

## What I could not verify
- **STLD's actual electrical steel (NOES) capacity.** Public materials and Q1 transcript do not break out non-oriented electrical steel as a distinct product line; I treat this as essentially zero relative to CLF, but a focused investor-relations call could change this.
- **STLD's exact data-center end-market share of revenue.** Management speaks qualitatively about data center, manufacturing, warehouse, healthcare being demand drivers [3] but does not disclose %-of-revenue. NUE's "95%+ of data center steel" claim is also self-reported and unaudited.
- **Verified YTD 2026 total return** — I had price points and 52-week range but did not source a clean Jan 1, 2026 → May 7, 2026 number.
- **Net debt detail.** I inferred ~$3.4B from EV - market cap, but did not directly source debt and lease balances from the 10-Q.
- **Tons-per-MW steel intensity for data centers.** Sources gave 20,000+ tonnes per hyperscale facility but no clean tons/MW ratio I could verify across the major hyperscalers [8][17].
- **OmniSource scrap self-supply ratio.** I stated ~40% self-supply for STLD from general industry context; the precise current figure is not in the materials I reviewed.

## Sources
[1] https://finance.yahoo.com/quote/STLD/ — retrieved 2026-05-10 — STLD price $241.84, 52w range $119.89-$243.73, May 7 2026 close
[2] https://www.powermag.com/transformers-in-2026-shortage-scramble-or-self-inflicted-crisis/ — retrieved 2026-05-10 — Power transformer lead times 128-144 weeks; data center delay attribution to electrical equipment
[3] https://ir.steeldynamics.com/steel-dynamics-reports-first-quarter-2026-results/ — retrieved 2026-05-10 — Q1 2026 results: $5.2B rev, $403M NI, 3.6Mt shipped, $1,193/t avg, backlog +38% YoY into Oct 2026, data center as named demand driver
[4] https://www.clevelandcliffs.com/operations/steelmaking/butler-works — retrieved 2026-05-10 — CLF sole U.S. producer of GOES at Butler, PA + Zanesville, OH (~250kt/yr)
[5] https://www.aluminummarketupdate.crugroup.com/growth-markets/steel-dynamics-produces-aluminum-from-mississippi-as-flat-rolled-operations-ramp-up/ — retrieved 2026-05-10 — ADI Columbus MS 650kt + 150kt slab; exit 2026 at 75%, $650-700M EBITDA target
[6] https://www.newmill.com/ — retrieved 2026-05-10 — New Millennium Building Systems #2 U.S. joist/deck producer
[7] https://www.whitecase.com/insight-alert/united-states-modifies-steel-aluminum-and-copper-section-232-tariffs — retrieved 2026-05-10 — Section 232 doubled to 50% June 2025; April 2026 expansion to full-customs-value
[8] https://datacentremagazine.com/articles/the-role-of-steel-in-todays-data-centre-industry — retrieved 2026-05-10 — Hyperscale facility 20,000+ tonnes structural steel; data center steel demand scaling
[9] https://www.ussteel.com/w/the-next-generation-of-american-steelmaking-is-big-and-well-underway — retrieved 2026-05-10 — Big River 2 ramped early 2026, 6Mt total campus capacity; direct EAF flat-rolled supply addition
[10] https://www.steelmarketupdate.com/2026/05/10/final-thoughts-a-look-at-mays-scrap-market/ — retrieved 2026-05-10 — Busheling at $423/GT near 2-year high; sentiment elevated
[11] https://www.steeldynamics.com/eafvsblastfurnace/ — retrieved 2026-05-10 — EAF capex ~$140-200/ton vs. ~$1,000/ton integrated; cost/maintenance comparison
[12] https://energynewsbeat.co/ai/more-than-half-of-the-data-centers-may-be-delayed-due-to-lack-of-transformers-and-electrical-equipment-2/ — retrieved 2026-05-10 — CLF sole U.S. GOES producer; China 8× U.S. output; GOES prices doubled since 2020
[13] https://www.marketbeat.com/stocks/NASDAQ/STLD/forecast/ — retrieved 2026-05-10 — Consensus PT $215.62, Buy rating, 8-11 analyst coverage; short interest 3.06%
[14] https://www.fool.com/earnings/call-transcripts/2026/04/21/steel-dynamics-stld-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1 2026 transcript: $1.4B through-cycle EBITDA from new projects; $600M 2026 capex; HRC pricing >$1,000
[15] https://www.gurufocus.com/term/ev/STLD/Enterprise-Value/Steel-Dynamics-Inc — retrieved 2026-05-10 — EV $33.74B; EV/EBITDA 15.96; TTM EBITDA $2.316B
[16] https://stockanalysis.com/stocks/stld/statistics/ — retrieved 2026-05-10 — 2026 revenue forecast $21.9B; 2026 EPS forecast $9.01; statistics
[17] https://www.steelmarketupdate.com/2025/10/31/nucor-targets-white-hot-data-center-boom/ — retrieved 2026-05-10 — NUE forecasts 60M sq ft of data center construction in 2026; NUE supplies 95%+ of data center steel
[18] https://www.aaii.com/investingideas/article/24779-which-is-a-better-investment-nucor-corporation-or-steel-dynamics-inc-stock — retrieved 2026-05-10 — STLD vs. NUE net margin comparison (6.5% vs. 5.4%); competitive positioning