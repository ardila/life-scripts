# CDW — CDW Corporation

## Where this sits in the AI stack
CDW is not in the AI stack in any silicon, kernel, or fabric sense. It is the **procurement, financing, configuration, and services intermediary** that sells the boxes — NVIDIA-accelerated Dell/HPE/Supermicro/Lenovo servers, Cisco/Arista networking, Pure/NetApp/VAST storage, Microsoft/ServiceNow licenses — to **non-hyperscaler buyers**: U.S. mid-market commercial, federal civilian/DoD, state and local, K-12, higher-ed, and healthcare [1][3]. The frontier-training market (Microsoft, Google, Meta, Amazon, Oracle, plus neoclouds like CoreWeave) buys direct from NVIDIA and OEMs and does not transact through CDW at all [11][16]. CDW sits one layer above OEM distribution and one layer below systems integration: it is a value-added reseller (VAR) for enterprise **inference, fine-tune, and AI-adjacent infrastructure** — not frontier training.

## Snapshot
- **Price:** $104.79 (2026-05-08 close, post Q1 earnings drop) [10]
- **Market cap:** ~$13.7B (≈131M shares outstanding × $104.79) [10][13]
- **52-week range:** $104.41 – $192.30 [9]
- **Forward P/E:** ~10.6× (annualizing Q1 non-GAAP EPS of $2.28 to ~$9.85; pre-drop forward P/E was 13.2× at $130) [4][6]
- **EV / NTM revenue:** ~0.8× (EV ≈ $18.7B against ~$23B NTM revenue at 2.5–3% top-line growth and 2.4× net leverage on ~$2.2B EBITDA) [6][12] — inference, flagged
- **Consensus 12-month price target:** ~$130 post-Q1 (JPM $130, Barclays $123, UBS $147; legacy median $210 is stale and pre-revision) [17] — implied +24% from price on the post-cut numbers
- **YTD total return:** -16.7% [9]
- **Short interest:** 2.09% of float (below the IT-services peer median of 4.66%) [14]

## Moat — what it is physically made of
Be honest: **CDW has no technical moat.** It owns no silicon, writes no compilers, holds no packaging allocation, runs no fabric. What it owns is a **distribution and procurement moat** built from five components, each with very different durability:

1. **Sales-coverage density.** ~6,500 customer-facing coworkers organized vertically — CDW-G (federal, with cleared personnel and GSA/SEWP/NASA SEWP-VI procurement vehicles), CDW Healthcare, CDW Education — selling to ~250,000 customer accounts that individually are too small to merit OEM direct coverage [3][7]. This is the most durable component: an HHS hospital system or a mid-sized state university cannot pick up the phone and call NVIDIA's enterprise team, and Dell's direct sales force does not economically cover a $400k order at a 600-bed hospital. Replicating it requires headcount and contract vehicles, not capital.

2. **Procurement vehicles & financing.** Public-sector contracts (GSA Schedule 70, SEWP V/VI, NASPO ValuePoint, state master contracts) are *legally* required channels for federal/state/education spend and take years of contract performance to qualify for. CDW Financial Services books $5M+ AI deals on its own paper. This is a regulatory-process moat, not technical, but it is hard to replicate — Amazon Business has been trying for a decade and is still mostly transactional.

3. **SKU breadth + single-PO.** 250,000 SKUs across ~1,000 brands sold under one PO, one configuration center, one warranty desk, one financing line [3]. The benefit is logistical, not technical. Replicable in principle by Insight, SHI, or Ingram Micro — and they do replicate it — but with switching costs to customers measured in months of re-procurement work.

4. **Services attach — partially technical.** Post-Sirius (acquired 2021 for $2.5B [20]), CDW has IBM zSystems mainframe practice, hybrid-cloud architecture services, SOC-as-a-service, and an NVIDIA Elite Partner designation for AI infrastructure design. This is the only component that touches actual engineering. Even so, the bench is consulting-services depth, not kernel-level expertise — CDW's people configure DGX BasePOD reference architectures [21], they don't optimize CUTLASS kernels or tune NCCL collectives.

5. **Vendor-program economics.** Tier-1 status in NVIDIA NPN, Microsoft (global strategic), Cisco, Dell, HPE means co-funded marketing, lead-share, and rebate tiers that smaller VARs structurally cannot match. This rebate-and-MDF stack is a real economic moat at scale but compresses any time a vendor pushes direct.

**Durability ranking, my view:** public-sector contract vehicles and sales-coverage density are durable for 5+ years. SKU breadth and financing are durable but commoditizing. Services attach is the *swing factor* — if AI services attach holds at historical software-and-services rates, the moat strengthens; if AI commoditizes integration (Dell AI Factory, HPE Private Cloud AI shipping as turnkey appliances [18]), it weakens.

This is not a CUDA-class moat. It's a Sysco-class moat — distribution, financing, route density, vendor program access — applied to IT.

## AI buildout bottleneck map
The 2026–2027 AI buildout is gated by, roughly in this order [11][16]:

- **CoWoS-L advanced packaging at TSMC** — ~75K wpm in 2025 growing to ~120–130K wpm by EOY 2026; NVIDIA already booked >60% [16]. **CDW position: indifferent on supply, exposed on availability.** CDW does not have allocation; it sells whatever NVIDIA-OEM systems land in non-hyperscaler channels.
- **HBM3e/HBM4 supply (SK Hynix dominant, Samsung lagging on qualification, Micron ramping)** — same dynamic. **CDW position: indifferent.**
- **Hyperscaler GPU allocation** — Microsoft, Google, Meta, Amazon, Oracle committed $600–630B 2026 capex, ~75% AI [16]. They take direct shipments. **CDW position: explicitly disadvantaged** — every Blackwell that ships to Azure is one CDW cannot resell. This is structural, not cyclical.
- **Liquid cooling at >100kW/rack and grid interconnect** — gating hyperscaler campus expansion (turbine backlog measured in quarters, GE Vernova / Siemens Energy gas-turbine lead times 3–5 years). **CDW position: indifferent on hyperscaler side; mild beneficiary on enterprise side** as enterprises buy cooled GB200 NVL72-style racks pre-integrated through OEMs.
- **NVIDIA software stack (CUDA, NIM microservices, NeMo)** — moat to NVIDIA, not CDW. CDW resells NVIDIA AI Enterprise licenses, which is margin-positive via netted-down revenue, but the moat sits with NVIDIA [22].
- **Enterprise GPU lead times** — H100 SXM5 nodes reportedly at 36–52 weeks from resellers [16]. **CDW position: this is actually a *headache* — long lead times stretch working-capital and create backlog accounting noise**, which is exactly what Q1 2026 inventory build showed [5].
- **Kernel/compiler/MLE talent and training-data quality** — irrelevant to CDW directly.

The honest read: **CDW is downstream of every bottleneck and upstream of none.** It is a beneficiary of *aggregate* enterprise AI demand, exposed customer of allocation tightness, and a price-taker on every component. The "AI for CDW" trade has been *enterprise AI infrastructure builds out faster than hyperscalers crowd out non-hyperscaler supply.*

## Competitive teardown
The relevant axis is **share of non-hyperscaler IT spend**, not technology axis. CDW is ~3× the size of its nearest US peer [3].

- **Insight Enterprises (NSIT).** $8.3B TTM, services now 22% of net sales, executing a more aggressive services-led pivot with the Inspire11 acquisition (proprietary AI delivery platform) and 2026 Google Cloud Workplace AI Partner of the Year award [7]. **Where Insight has parity or ahead:** generative AI consulting/delivery; Insight is named an "Emerging Leader" in Gartner's 2025 Generative AI Consulting Innovation Guide and CDW is not. **Where CDW is ahead:** scale of public-sector book, federal contract vehicles, financing depth. If you believe AI margin comes from *services attach*, Insight's pivot is more credible than CDW's.

- **ePlus (PLUS).** FY26 9-month revenue $1.86B, +22% YoY; product +23%, services +19% [8]. Smaller, more concentrated in networking/security; the relevant data point is the *growth rate* — ePlus is growing 2–3× faster than CDW into the same AI infrastructure cycle, suggesting CDW is losing relative share at the high end.

- **SHI International (private).** Software-license heavy, often undercuts on enterprise software agreements [3]. The real competitive risk to CDW's *netted-down revenue line*, which is what drove the Q1 margin miss.

- **Connection (CNXN), Softchoice, Zones, WWT, Presidio.** Smaller or private; collectively meaningful but no individual existential threat.

- **Amazon Business.** Has been chipping at commodity IT procurement for ~7 years with limited margin impact on CDW. Real but slow.

- **Direct vendor sales (Dell AI Factory, HPE Private Cloud AI, Lenovo, Supermicro).** This is the more important competitor. Dell's AI-optimized server revenue +342% YoY in FQ4'26 reaching $9B [15], much of it *direct* to enterprise. Dell already covers Tier-1 commercial; the question is whether the AI Factory motion pushes downmarket into CDW's mid-market core. As of Q1 2026 there is no clear evidence it has — but the playbook is built and the salesforce is being trained.

The most credible bear scenario isn't a single competitor; it's **OEM-direct + hyperscaler-direct collectively absorbing the largest, fastest-growing AI deals**, leaving CDW with the long tail at compressed margins.

## Bull case — technical
For CDW to outperform, you need to believe:

1. **Enterprise AI buildouts in 2026–2027 disproportionately favor on-prem and hybrid over public cloud** for inference at scale. The TCO math supports this above ~60% sustained GPU utilization [19]; if enterprises with stable inference workloads (regulated industries, healthcare, government) move from cloud spend to on-prem, this is *exactly* the buyer CDW covers, and the GPU server, networking, and storage refresh cycle (+20%/+20%/+20% in Q1 [2]) is in early innings.

2. **Services attach normalizes back to historical rates** as customers move from "AI exploration" to production. Management's claim that AI deals are "margin-accretive" through orchestration services [2][5] requires netted-down revenue to recover from the 34.5% of GP trough back toward 36.5%+ [5]. If Q3–Q4 2026 prints show that, the Q1 margin scare looks cyclical, not structural.

3. **Public-sector AI is real.** Federal IT contract spend rose to ~$130B in FY25 despite DOGE [17][24]; sovereign AI and Defense modernization (CDW-G's franchise) sustain. State and local AI for citizen services begins to scale.

4. **Geared for Growth delivers** — $100M run-rate savings 2027, $200M 2028 [2][12]. At 11M shares of buyback annual capacity plus $300M+ in opex savings, EPS compounds at high-single-digits even on flat-ish revenue growth.

**Base rate on VAR resilience.** In every prior technology platform shift (mainframe→client-server, on-prem→cloud, x86→ARM in mobile-adjacent), the IT-channel survived by absorbing the new layer as services revenue: CDW's net sales grew through the cloud era despite predictions it would be disintermediated. The historic base rate for "VAR gets killed by platform shift in 24 months" is essentially zero outside of dot-com era pure-play hardware catalog sellers. Channel-margin compression is gradual, not cliff-edge.

**Financial outcome:** at 10.6× forward P/E, 2.4% dividend yield, 7%+ buyback yield on $750M-plus authorization against $13.7B cap, you don't need much. Stabilize gross margin and the equity re-rates to 13–14× and pays you to wait.

## Bear case — technical
The version a credible short would write:

1. **The Q1 2026 print is the signal, not the noise.** Hardware grew +10%, software +11%, services lagged — the mix moved *toward* low-margin pass-through, gross margin compressed 60 bps, netted-down dropped from 36.5% → 34.5% of GP [5]. The bull narrative ("AI = more services") is empirically falsified by the most AI-heavy quarter in CDW history. AI deals look like *boxes*, not *consulting hours*, because NVIDIA Enterprise AI software, NIM microservices, and OEM reference architectures (DGX BasePOD, Dell AI Factory) **internalize the integration work that used to be the VAR's value-add** [21][18]. The moat thins exactly where the dollars are largest.

2. **Hyperscaler-direct is generalizing to "AI-factory-direct."** Dell's $9B AI-server quarter at +342% YoY [15] is largely landing direct with enterprises that *would otherwise* have transacted through CDW. Supermicro's compliance issues opened share for Dell and HPE, both of which prefer direct relationships at >$1M deal sizes [15]. CDW's quote in Q1 — "customer urgency for AI and infrastructure hardware investments" — is consistent with CDW being a *spillover* channel, not the channel of choice.

3. **GPU-as-a-service via Boost Run is execution-risky.** Boost Run is going public via Willow Lane SPAC merger and is scaling from ~$100M to >$250M of GPU deployment in Q1 2026 [4]. Reselling capacity from a sub-scale neocloud SPAC is a fragile substitute for actually owning allocation. If Boost Run stumbles, CDW's AI cloud story stumbles.

4. **Public sector exposure is asymmetric to the downside.** Federal IT contract spend held in FY25 [24], but acquisition-officer vacancy rates approaching 40% at some agencies [24] guarantee procurement slowdowns. CDW's public-sector segment is ~38% of revenue and is now structurally lower-growth.

5. **The multiple isn't cheap if growth is structurally 3–4%.** A 10.6× forward P/E on a ~3% top-line grower with no IP moat is appropriate, not cheap. The right comparison is Genuine Parts at ~13×, not Accenture at ~25×.

**Falsifier-symmetric to bull #1:** if Q3 2026 prints show netted-down revenue *below* 34% of GP again, the structural-erosion thesis is confirmed and the multiple should re-rate down, not up.

## Market view check
Consensus has already moved: JPMorgan from $160 → $130, Barclays $144 → $123, UBS $162 → $147 [17]. The stock dropped 22.9% on Q1 results week [9][17] from ~$135 to $104.79, taking the multiple from 13× to ~10.6× forward. The market reaction is consistent with the bear view that **AI is a margin-compressing mix shift for CDW, not the margin-expanding services boom management has been narrating for 18 months**. The price now embeds something close to "low-single-digit growth, structurally lower gross margin, opex savings as the EPS lever." That seems reasonable, not extreme — i.e. the stock is fairly priced for the bear case, not the bull case. If you believe the technical bull case (on-prem AI accelerates, services attach normalizes), the asymmetry is moderately attractive. If you don't, it's a value trap with a 2.4% yield.

## 90-day falsifiers
- **Q2 2026 print (early August):** netted-down revenue % of gross profit — recovery toward 36% confirms cyclical; further drop below 34% confirms structural [5].
- **Insight Enterprises Q2 (early August):** if Insight's services-led mix delivers gross margin expansion while CDW's compresses, the share-loss-on-services thesis is confirmed.
- **Dell FQ2'26 earnings (late August):** AI server bookings mix between hyperscaler and "enterprise" — if Dell's enterprise AI Factory bookings step up materially, OEM-direct disintermediation is real.
- **Boost Run SPAC close + first deployment milestones:** does the $250M GPU deployment in Q1'26 actually land? Slippage signals CDW's "GPU-as-a-service" leg is weaker than presented.
- **NVIDIA Q2 FY27 commentary (late August):** any change in NPN partner allocation policy or enterprise direct-sales push.
- **Federal IT obligation run-rate through Q3 FY26 (USAspending.gov):** confirms or refutes whether DOGE-era procurement officer attrition is hitting actual obligation velocity into CDW-G's lane.
- **CoWoS allocation updates from TSMC's July earnings:** if NVIDIA's allocation share rises *above* 60%, more crowd-out of enterprise; if it drops, enterprise GPU lead times ease and CDW's hardware book grows.

## What I could not verify
- **CDW's actual NVIDIA NPN tier and revenue concentration with NVIDIA-accelerated hardware.** CDW does not disclose vendor concentration by SKU family. NVIDIA-attached server revenue is inferred, not disclosed.
- **Exact AI revenue contribution.** Management referenced ~+20% growth in networking/servers/storage [2][5] but does not break out "AI revenue." Estimates from sell-side imply 5–10% of group revenue is AI-attributable; I could not verify a number.
- **Direct-sales share by Dell/HPE inside CDW's customer base.** I could not find primary data on what fraction of Tier-2 commercial AI server purchases are flowing direct vs. through VARs.
- **Boost Run's actual GPU deployment status, vendor mix, and unit economics.** Press releases [4] are not audited; full visibility waits for post-merger 10-Q.
- **Geared for Growth program details.** $100–200M savings claim is announced but unaudited; I have no independent view of where it lands.
- **Q1 2026 backlog composition.** Management referenced "increased backlog" but did not size it or attribute to AI hardware specifically [5].
- **Federal IT 2026 budget actuals beyond run-rate observations** — the FY27 budget process and Continuing Resolution mechanics are inherently uncertain.

## Sources
[1] https://www.cdw.com/ — retrieved 2026-05-10 — CDW corporate site confirming VAR positioning and 250,000-SKU catalog claim
[2] https://stockstory.org/us/stocks/nasdaq/cdw/news/earnings-call/cdw-q1-2026-deep-dive-hardware-demand-and-ai-initiatives-outweigh-margin-headwinds — retrieved 2026-05-10 — Q1 2026 earnings call deep-dive: hardware +10%, software +11%, services-lagging, networking/server/storage each +20%, Geared for Growth program
[3] https://moiglobal.com/alex-furmanski-202306/ — retrieved 2026-05-10 — established CDW as ~3× nearest US VAR competitor and the breadth of product/service portfolio
[4] https://www.prnewswire.com/news-releases/boost-run-expands-ai-infrastructure-ecosystem-with-additional-gpu-data-center-financing-and-customer-partnerships-as-it-prepares-to-merge-with-willow-lane-acquisition-corp-302642687.html — retrieved 2026-05-10 — Boost Run scaling to $250M GPU deployment Q1'26 and Willow Lane SPAC merger; relevant for CDW's GPU-as-a-service offering
[5] https://www.investing.com/news/transcripts/earnings-call-transcript-cdw-q1-2026-beats-forecasts-but-faces-stock-slump-93CH-4663893 — retrieved 2026-05-10 — Q1 2026 earnings call transcript: gross margin 21.0% (-60bps), netted-down 34.5% of GP (vs. 36.5%), Boost Run partnership announcement, inventory build commentary
[6] https://stockanalysis.com/stocks/cdw/statistics/ — retrieved 2026-05-10 — CDW valuation metrics (forward P/E pre-drop 13.2×, EV/EBITDA 11.7×, TTM revenue $21.3B)
[7] https://investor.insight.com/news-releases/news-release-details/2025/Insight-Enterprises-Acquires-Inspire11-to-Expand-AI-and-Business-Transformation-Capabilities/default.aspx — retrieved 2026-05-10 — Insight Enterprises Inspire11 acquisition; AI delivery platform positioning
[8] https://www.eplus.com/about-us/press-releases/details/2026/02/04/eplus-reports-third-quarter-and-first-nine-monthsfinancial-results-of-fiscal-year-2026 — retrieved 2026-05-10 — ePlus FY26 9-month revenue $1.86B +22%, product +23%, services +19%
[9] https://www.benzinga.com/markets/earnings/26/05/52340425/cdw-stock-sinks-to-52-week-low-heres-why — retrieved 2026-05-10 — CDW 52-week low details, -22.9% week of Q1 print, post-earnings reaction
[10] https://www.businesswire.com/news/home/20260506229467/en/CDW-Reports-First-Quarter-2026-Earnings — retrieved 2026-05-10 — Q1 2026 earnings release primary source: $5.679B revenue +9.2%, $2.28 non-GAAP EPS
[11] https://markets.financialcontent.com/wral/article/tokenring-2026-1-1-the-great-packaging-pivot-how-tsmc-is-doubling-cowos-capacity-to-break-the-ai-supply-bottleneck-through-2026 — retrieved 2026-05-10 — CoWoS capacity and NVIDIA's >60% allocation share through 2026–27
[12] https://www.stocktitan.net/news/CDW/cdw-authorizes-750-million-share-repurchase-program-increase-and-h6bsmbn2s8cq.html — retrieved 2026-05-10 — $750M buyback authorization, net leverage 2.4×, capital return targets 50–75% of FCF
[13] https://companiesmarketcap.com/cdw-corporation/marketcap/ — retrieved 2026-05-10 — share count and market cap reference (~131M shares)
[14] https://www.benzinga.com/insights/short-sellers/24/11/42235158/peering-into-cdws-recent-short-interest — retrieved 2026-05-10 — short interest 2.09% of float vs. 4.66% peer median
[15] https://rollingout.com/2026/05/08/dell-record-43b-backlog-117m-deal-nvidia/ — retrieved 2026-05-10 — Dell AI-optimized server revenue +342% YoY to $9B; relevant for OEM-direct disintermediation risk
[16] https://info.fusionww.com/blog/inside-the-ai-bottleneck-cowos-hbm-and-2-3nm-capacity-constraints-through-2027 — retrieved 2026-05-10 — CoWoS, HBM, hyperscaler capex $600–630B 2026, enterprise GPU lead times 36–52 weeks
[17] https://www.tickerreport.com/banking-finance/13433906/cdw-nasdaqcdw-given-new-130-00-price-target-at-jpmorgan-chase-co.html — retrieved 2026-05-10 — JPMorgan PT cut $160 → $130; Barclays $144 → $123; UBS $162 → $147 post-Q1
[18] https://www.dell.com/en-us/lp/dt/nvidia-ai — retrieved 2026-05-10 — Dell AI Factory turnkey reference for OEM-direct AI infrastructure motion
[19] https://www.spheron.network/blog/llm-inference-on-premise-vs-cloud/ — retrieved 2026-05-10 — On-prem vs. cloud GPU TCO break-even analysis; >60% utilization favors on-prem
[20] https://investor.cdw.com/news/news-details/2021/CDW-Completes-Acquisition-of-Sirius-Computer-Solutions/default.aspx — retrieved 2026-05-10 — Sirius Computer Solutions $2.5B acquisition completed Dec 2021; services-led mainframe/hybrid infrastructure capabilities
[21] https://docs.nvidia.com/dgx-basepod/reference-architecture-infrastructure-foundation-enterprise-ai/latest/dgx-basepod-overview.html — retrieved 2026-05-10 — NVIDIA DGX BasePOD reference architecture, the kind of design CDW resells/integrates
[22] https://www.cdw.com/content/cdw/en/brand/nvidia.html — retrieved 2026-05-10 — CDW–NVIDIA partner page confirming NPN positioning and AI Enterprise software resale
[23] https://www.stocktitan.net/sec-filings/CDW/10-k-cdw-corp-files-annual-report-0657980a9629.html — retrieved 2026-05-10 — 2025 10-K: $22.4B net sales, Corporate $9.4B (+6.8%), Small Business $1.7B (+13.3%), Public $8.5B (+4.6%)
[24] https://www.nextgov.com/policy/2025/09/government-pacing-toward-increased-it-contract-spending-despite-doge-cuts/408002/ — retrieved 2026-05-10 — Federal IT contract spend ~$130B FY25 vs. $126B FY24; acquisition-officer vacancy concerns