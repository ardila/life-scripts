# MCHP — Microchip Technology Incorporated

## Where this sits in the AI stack
MCHP is principally a broad-line analog + microcontroller + mixed-signal vendor for industrial, automotive, and aerospace/defense customers; its connection to the AI buildout runs through a narrower (~18%-of-revenue) Data Center & Compute segment that sells PCIe switches (Switchtec, the Microsemi-acquired line, now in 3 nm Gen 6), a newly-launched Gen 6 retimer companion die, signal-integrity & timing parts, NAND flash controllers, and PolarFire FPGAs used at the intelligent edge[1][2][3][6]. It does **not** sell GPUs, HBM, optics, or training-system silicon. Inside an AI rack it shows up on PCIe fan-out between hosts/accelerators/storage, in BMC/management subsystems, and increasingly in CXL 2.0/PCIe 5.0/6.0 retimer sockets — i.e. plumbing inside the host/scale-up box, not the scale-out fabric or the compute itself[2][6].

## Snapshot
- **Price:** $99.20 (2026-05-08 close)[4]
- **Market cap:** ~$48.7B[5]
- **52-week range:** $48.52 – $105.91[7]
- **Forward P/E:** 32.6× on consensus FY27 EPS (vs. 5-yr avg ~25.3×)[5]
- **EV / NTM revenue:** ~10.5× (EV ~$54.3B / NTM revenue ~$5.15B implied by June-Q guide $1.456B × 4 + growth)[5][1]
- **Consensus 12-month price target:** $85.59 (implied **−13.7%** from spot; 22 analysts; range $66–$120; Citi $113, Needham $120 post-print)[5][12]
- **YTD total return:** **+53.8%**[7]
- **Short interest (% of float):** 5.2% (~27.6M shares, +10.3% from prior settle)[14]

## Moat — what it is physically made of
Decomposed by component, with durability assessed separately:

**1. MCU socket stickiness (durable, slow erosion).** MCHP is the #1 8-bit MCU vendor at ~32% share vs. NXP ~11%, and the only Tier-1 still seriously investing across 8/16/32-bit families (PIC, AVR via the 2016 Atmel acquisition, plus 32-bit PIC32/SAM/MIPS, and now PIC64 + RISC-V)[10][11]. Embedded design sockets in industrial gear average 7–17 years of in-production life with very stable ASPs; ~50% of MCHP revenue still flows through distribution to a long tail of small customers, which raises the cost-to-displace because no single account is large enough to justify a competitor's NRE to chase[1][13]. This is a classic analog/MCU moat: not technological brilliance, but the per-socket switching cost (re-spin, re-qual, re-cert, re-write firmware) is high relative to the dollar value of any one part.

**2. Microsemi-derived rad-hard / mission-critical (durable, regulated).** RTG4 radiation-tolerant FPGAs are QML Class V-qualified — the highest DLA tier for Class 1 space flight — and were the first >150k-LE rad-tolerant FPGA to clear it[15]. This is a moat made of paperwork as much as silicon: requalifying a satellite payload around a different vendor is multi-year. A&D was the strongest-growing end market in Q4 FY26[8].

**3. Switchtec PCIe switch franchise (contested, currently widening).** The Microsemi switch IP gives MCHP a genuine seat in the PCIe switch oligopoly. Industry data has the top-5 vendors (Broadcom, Astera Labs, Microchip, TI, ASMedia) holding ~91% share of a ~$1.4B 2024 market growing to ~$5B by 2031 (~16% CAGR), with Broadcom ~28% in Gen 4 and growing in Gen 5/6[16][17]. MCHP claimed first-to-3 nm on a Gen 6 fanout switch in Oct 2025 (20 ports / 10 stacks / 160 lanes, post-quantum-safe root-of-trust)[18][3], and disclosed **six Gen-6 switch design wins** plus a surprise PCIe Gen-6 **retimer** win at a major OEM, displacing the incumbent — almost certainly Astera Labs, which has ~47% of the merchant retimer market and was first-to-market on Gen 5/6 Aries parts[1][8][19]. The retimer entrance is a companion die strategy: socketed *with* the switch, not on its own merits — that's the credible angle but also the ceiling.

**4. Manufacturing footprint (mixed; shrinking on purpose).** Internal fabs at Gresham (OR, Fab 4), Colorado Springs (Fab 5), and historically Tempe (Fab 2, sold via Macquarie, shuttered ahead of plan in May 2025; ~$90M annual savings)[20][21]. This is **trailing-node** capacity (180/130/90nm-class analog/mixed-signal) — not relevant to AI silicon. Switchtec Gen 6 at 3 nm is fabbed externally, almost certainly at TSMC (unverified — see §11). The trailing-node owned fabs are a cost moat in a recovery (gross margin guided 62.8% Q1FY27, up from 53.7% YoY trough[1][8]) but are *not* a competitive weapon vs. TXN's 300mm scale advantage[22].

**5. Software / dev ecosystem.** MPLAB, MCC, Harmony, VectorBlox SDK for PolarFire AI inference[6]. These are sticky for existing customers but not a developer-flywheel like CUDA: there is no global pool of "MPLAB developers" anyone is fighting over. Treat as a per-customer switching cost amplifier, not a platform moat.

Person-years-to-replicate (inference): the MCU portfolio is essentially un-replicable as a greenfield project — Renesas spent ~$10B on Dialog + IDT to assemble half of it. The Switchtec PCIe switch line is replicable on a ~4-5 year horizon, which is why Broadcom/Marvell are doing exactly that.

## AI buildout bottleneck map
24-month gating constraints, with MCHP's posture:

| Constraint | 24-mo state | MCHP posture |
|---|---|---|
| HBM3e/HBM4 yield & supply | Tight; SK Hynix/Samsung/Micron-bound | **Indifferent** — does not consume HBM, does not sell into HBM stack |
| CoWoS-L / advanced packaging at TSMC | Sold out through 2026, Broadcom/NVIDIA-allocated | **Indifferent** — Switchtec is monolithic |
| ABF substrate (FC-BGA) | 2026 Semco capacity reportedly fully booked by Alphabet/Apple/AWS/Broadcom/Tesla[23] | **Constrained / exposed** — Sanghi explicitly flagged on the Q4 FY26 call that substrates are constraining data center, networking, *and* auto[24] |
| Power generation / grid interconnect | Multi-quarter turbine backlogs | Indifferent at the chip level |
| Liquid cooling > 100 kW/rack | Vendor-limited (CoolIT/Vertiv/Boyd) | Indifferent |
| 800G optical / co-packaged optics | Tight DSP & laser supply | **Not a player** — no optical DSP, no laser IP |
| PCIe scale-up plumbing (switches, retimers) | Bandwidth-bound at the rack; Gen 6 ramping 2026–27 | **Beneficiary, contested** — direct exposure via Switchtec + new retimer, but #3 player |
| Kernel / compiler talent (CUDA/Triton) | Acutely scarce | Indifferent |
| Trailing-node analog/MCU wafer supply | Tightening post-correction; 70–80% of MCHP's nodes called "constrained" by Sanghi on Q4 call[24] | **Constraint owner** — owns the supply, hence pricing power without broad price increases |

So the honest reading: MCHP is **not** exposed to the binding constraints on frontier AI training (HBM, CoWoS, power), and it is **not** a sell-shovels-to-the-gold-rush name in the way Broadcom or ASTS or Vertiv are. Its AI-cycle benefit is two derivatives removed: rack-level PCIe plumbing (small, contested), plus a broad analog/MCU upcycle that *includes* AI servers but is mostly driven by industrial and auto restocking.

## Competitive teardown

**vs. Broadcom (AVGO) — PCIe switches & retimers.** AVGO is the share leader in PCIe switches (~28% Gen 4 share, growing in Gen 5/6) with vastly larger engineering scale and tighter hyperscaler relationships from XPUs and Tomahawk/Jericho switching[16][17]. AVGO launched Gen 5/6 retimers in 2025 explicitly aimed at Astera Labs[19]. Axis: scale, hyperscaler relationships, fab process node. Current state: **AVGO is structurally ahead**; MCHP's edge is on a narrow timing window (claimed first-to-3 nm on the Gen 6 switch[3][18]) and on the willingness to sell switch+retimer as a paired SKU. What would have to be true for MCHP to take share: Gen 6 switch wins translate to *production volume* at hyperscalers, not just the 6 disclosed design wins. Unverified.

**vs. Astera Labs (ALAB) — PCIe retimers.** ALAB pioneered the smart retimer category, has ~47% merchant share, and has COSMOS fleet-management software that is the closest thing to a CUDA-style ecosystem in retimers — telemetry, diagnostics, validation suites tightly integrated into hyperscaler ops[19][25]. MCHP's entrance is via Switchtec attach, not a standalone software-rich retimer. Honest axis: ALAB has **software depth** and incumbency MCHP cannot replicate in 12 months. The "displaced an incumbent at a major OEM" headline is single-design-win evidence, not a share shift.

**vs. Marvell — PCIe Gen 6 retimers / DC connectivity.** MRVL is shipping 5 nm Gen 6 retimers at ~10 W typical (lower than Aries 6 and Broadcom Vantage 6 per teardowns) and has the deeper DSP/SerDes IP library from Inphi[26]. MCHP is not the technology leader here.

**vs. AMD (Xilinx) & Altera — FPGAs.** PolarFire's positioning is **low-power, mid-density, edge**, not data center; the VectorBlox AI inference flow targets <25W edge use cases[6]. PolarFire SoC (RISC-V + flash-based fabric, 90% YoY growth in year 5[27]) is taking edge/industrial sockets from Lattice and from low-end Xilinx Spartan/Artix — not competing for hyperscaler smartNIC/DPU sockets where Xilinx Versal is dominant.

**vs. TXN & ADI — broad analog.** TXN's 300mm internal-fab cost structure is the structural advantage and will reassert as utilization recovers; ADI is stronger in high-performance precision signal chain[22][28]. MCHP's analog franchise is narrower than either but is bundled with the MCU socket (sell the MCU, attach the PMIC / Ethernet PHY / signal-conditioning). Q4FY26 non-GAAP GM of 61.6% is already above TXN's Q1FY26 GM of 58%[8][22] — but that reflects MCHP's MCU-heavy mix more than fab efficiency, and the gap is unlikely to widen further once TXN's 300mm absorption normalizes.

**vs. Renesas / NXP / STM / Infineon — MCUs + auto.** MCHP retains #1 in 8-bit but is **#5-or-lower** in 32-bit/Arm Cortex-M MCUs where STM, NXP, Renesas, Infineon dominate auto MCU sockets. The new automotive Ethernet PHY family (LAN878x/LAN888x, MACsec + TSN + ISO 26262 ASIL-B, announced May 7 2026)[29] is a credible product but enters a market where ADI (Vitesse acquisition) and Marvell already have 1G/10G T1 PHYs.

## Bull case — technical
Conditions that must hold:

1. **Analog/MCU restocking cycle has 6–8 quarters left**, not 2–3. Base rate on industrial semi cycles: post-2009 the trough-to-peak was ~10 quarters of revenue growth; post-2016, ~8 quarters; post-2020, ~7 quarters before the 2023–24 correction. MCHP exited the correction in Q3FY26; if the upcycle follows the median pattern, sequential growth carries into FY28 with peak revenue ~$7B (vs. FY26 $4.71B[1]) and operating margin returning to the ~45% peak — exactly what consensus and Citi/Needham are now baking in[12].
2. **Switchtec Gen 6 ramps from 6 design wins into volume**, with the retimer attach rate at >30% on each. PCIe switch TAM is going from ~$1.4B → ~$5B by 2031[16][17]; MCHP holding even a flat ~15% share captures ~$750M revenue at peak — incremental, not transformational, but pure-margin and explicitly tied to AI-rack count growth.
3. **Substrate constraints persist** long enough for MCHP to take pricing on the existing analog/MCU book without losing share (Sanghi said no broad price increases — but mix and lead-time-driven ASP creep is happening regardless)[24].
4. **AI/FPGA business unit pivot** materializes in PolarFire revenue: 90% growth on a small base needs to compound for 3–4 years to matter at the corporate P&L level[27].
5. Bear-side competitor paths fail: AVGO/MRVL/ALAB don't fully displace the Switchtec OEM wins before Gen 6 ramps.

Technology-displacement base rate caveat: in connectivity ASIC categories (Ethernet PHYs, PCIe switches, retimers), incumbents historically retain ~70% of their share over a 3-generation transition unless they miss a node — MCHP not missing the 3 nm Gen 6 node is the key fact for the bull case.

Financial sanity: at $99, $54.3B EV / ~$5.5B NTM rev = ~10× sales. Bull case revenue at $7B FY28 with 70% peak gross margin and 45% op margin → ~$2.4B free cash flow → ~22× EV/FCF on peak earnings — defensible but not cheap.

## Bear case — technical
Conditions for the moat to erode or demand to evaporate:

1. **Gen-6 design wins don't convert to volume.** Six pre-production design wins is a *pipeline*, not a backlog. Broadcom has more engineering resources and longer hyperscaler whisper-channel relationships; if the OEM wins are at second-tier ODMs while Broadcom locks AVGO into Tier-1 hyperscaler reference designs, Switchtec Gen 6 revenue tops out at ~$200–300M annually — material to data-center segment but lost in the noise of a $5B+ revenue base.
2. **The retimer "displacement" is one socket, not a category shift.** ALAB's COSMOS software stack and validated-with-NVIDIA reference platforms are exactly the kind of moat ALAB built between 2019–2024 while incumbents underestimated it. A single OEM win does not mean MCHP wins the next 10 sockets.
3. **Analog/MCU upcycle is *priced in* and 2H26 sees normalization.** YTD +54%, forward P/E 32× vs. 5-yr avg 25× — the multiple already reflects mid-cycle peak earnings. Consensus PT $85.59 implies the average analyst thinks the AI-rerating is overdone[5][12]. Historical base rate: analog stocks that re-rate >2 turns above 5-yr-avg forward P/E mean-revert within 12 months ~60% of the time when revenue surprises stop expanding.
4. **Substrate constraint flips from "pricing tailwind" to "revenue cap."** Sanghi flagged 70–80% of nodes are constrained[24]. If MCHP can't ship to bookings (April was the largest booking month in nearly four years[24]), the FY27 revenue ramp underperforms guidance and the multiple compresses.
5. **TXN 300mm advantage reasserts.** TXN's CapEx-heavy 300mm strategy is currently a margin drag (GM 58% vs. MCHP 61.6%) but is structurally a long-term cost weapon. As TXN absorbs new capacity, it can win analog sockets on price that MCHP retains today on incumbency[22].
6. **PIC64 / RISC-V MCU expansion fails** to break into 32-bit Cortex-M sockets dominated by STM/NXP/Renesas — leaving MCHP stuck at 8-bit dominance in a 32-bit-growing market (32-bit is 51% of MCU revenue and growing[11]).

A short-seller who understands the stack would frame it: *you are paying 33× forward earnings for a trailing-node analog company with a small contested data-center plumbing business, priced as if the data-center business were ALAB.*

## Market view check
At $99.20 the stock prices in (a) the cyclical recovery being durable through FY28, (b) the Switchtec Gen 6 wins converting to volume, and (c) some residual AI-narrative multiple expansion vs. peers. Consensus PT $85.59 (-13.7%)[5] is the cleanest tell that **sell-side analysts collectively believe the cyclical recovery is real but the AI re-rating has run ahead of the technical reality of what MCHP actually sells**. The Citi and Needham hikes to $113/$120[12] reflect the upside scenario; the median analyst is anchored on cycle-normalized earnings, not peak. What the market apparently believes that I would push back on: that the *18% data-center exposure* deserves a Broadcom-like multiple on the whole company. The bookings strength and gross-margin recovery are real and verifiable; the AI-pure-play framing is not.

## 90-day falsifiers
Each observable by ~mid-August 2026:

1. **Q1 FY27 (June quarter) actual vs. midpoint guide of $1.456B revenue / 62.8% GM / $0.69 EPS**[1]. A beat-and-raise reinforces the cycle; an in-line print with substrate-constrained guidance is the first crack.
2. **Switchtec Gen 6 production-volume disclosure** — Sanghi said production releases were targeted for end of the June quarter[24]; either named-OEM disclosures or a quantified data-center-segment dollar print should land on the August call. >$60M Q1FY27 data-center segment sequential lift = bull confirmation; flat or down despite design wins = bear confirmation.
3. **Astera Labs (ALAB) Q2 2026 print on retimer share** — if ALAB reports any Gen 6 retimer share loss commentary or weaker sequential, MCHP's "displaced a competitor" story gains credibility; if ALAB reports continued >30% sequential growth in retimers, the displacement was a one-off.
4. **Broadcom Gen 6 PCIe switch design-win disclosures at hyperscalers** at any of: AVGO July earnings, OCP Summit (October), Hot Chips (August). Tier-1 hyperscaler reference platform wins for AVGO Gen 6 = ceiling on MCHP Switchtec.
5. **Substrate / wafer supply commentary** from TSMC July earnings, Semco/Ibiden capacity guidance, and on the MCHP call. Easing = MCHP can ship to bookings (bull); tightening = revenue capped at supply (mixed).
6. **Auto SDR/SDV Ethernet design-win cadence** from MCHP press releases on the LAN878x/LAN888x family. >3 named OEM design wins by August = the auto franchise is competitive with ADI/MRVL on the new SPE generation.
7. **Insider activity / Sanghi tone shift** — the 9-point plan is largely executed; a CEO succession comment would materially de-rate the stock given how anchored the narrative is to Sanghi's return.

## What I could not verify
- Whether Switchtec Gen 6 is fabbed at TSMC N3 specifically (3 nm process is disclosed; foundry is not in any source I found)[18][3].
- The identity of the "displaced incumbent" on the Gen 6 retimer OEM win — circumstantially Astera Labs but unconfirmed[1][8].
- Specific hyperscaler customer names for the six Gen 6 switch design wins.
- Customer concentration at the data-center segment level (10-K typically discloses >10% customers; FY26 10-K not yet filed at writing).
- Whether MCHP has any meaningful exposure to NVIDIA-reference HGX/MGX boards beyond the public retimer/switch wins.
- Float-precise share count for the snapshot — used Yahoo's market-cap implied count (~491M) and reported short-interest as % of float at 5.2% from Marketbeat[14]; trade Q1FY27 10-Q for precision.
- Margin attribution between MCU mix uplift and Fab 2 closure savings — both contributing to 61.6% Q4 GM but not separately disclosed[1].
- The base-rate claim on analog stocks mean-reverting when forward P/E sits >2 turns above 5-yr avg is from market memory of the 2022–23 correction, not a published study; treat as inference.

## Sources
[1] https://ir.microchip.com/news-events/press-releases/detail/1387/microchip-technology-announces-financial-results-for-fourth-quarter-and-fiscal-year-2026 — retrieved 2026-05-10 — MCHP Q4 FY26 release: $1.311B Q4 revenue, $4.713B FY26, 61.6% Q4 GM, June guide midpoint $1.456B and 62.8% GM, Sanghi quote on data-center engagement.
[2] https://www.microchip.com/en-us/about/media-center/blog/2024/importance-of-retimers-in-large-scale-generative-ai-systems — retrieved 2026-05-10 — MCHP positioning on PCIe retimer role in generative AI systems.
[3] https://ir.microchip.com/news-events/press-releases/detail/1338/microchip-unveils-first-3-nm-pcie-gen-6-switch-to-power-modern-ai-infrastructure — retrieved 2026-05-10 — Switchtec Gen 6 3 nm switch launch, Oct 2025.
[4] https://www.quiverquant.com/news/MICROCHIP+TECHNOLOGY+%28%24MCHP%29+Releases+Q4+2026+Earnings%2C+Stock+Rises — retrieved 2026-05-10 — MCHP May 8 2026 close $99.20; +7.2% extended trading reaction to Q4 print.
[5] https://stockanalysis.com/stocks/mchp/statistics/ — retrieved 2026-05-10 — Forward P/E 32.6×, 5-yr avg fwd P/E 25.27, EV ~$54.3B, market cap ~$48.65B, P/S 9.6×, consensus PT $85.59 from 22 analysts, range $66–$120.
[6] https://www.microchip.com/en-us/products/fpgas-and-plds/system-on-chip-fpgas/polarfire-soc-fpgas — retrieved 2026-05-10 — PolarFire SoC FPGA technical capabilities, VectorBlox SDK for edge CNN inference, RISC-V cores.
[7] https://ideas.quantcha.com/2026/04/30/52-week-high-alert-trading-todays-movement-in-microchip-technology-mchp/ and Yahoo Finance MCHP page — retrieved 2026-05-10 — 52-week range $48.52–$105.91, YTD +53.77% as of May 7 2026.
[8] https://finance.biggo.com/news/US_MCHP_2026-05-07 — retrieved 2026-05-10 — Q4 FY26 details: 6 Gen 6 switch wins, retimer entry displacing competitor at major OEM, 35.1% YoY revenue growth, A&D strongest segment, FY26 end-market mix (Industrial 31% / DC&C 18% / Auto 17% / A&D 16% / Comm 9% / Consumer 9%).
[10] https://www.prnewswire.com/news-releases/microchip-reclaims-top-8-bit-microcontroller-revenue-ranking-300072100.html — retrieved 2026-05-10 — Historical 8-bit MCU share leadership.
[11] https://www.mordorintelligence.com/industry-reports/8-bit-microcontroller-market-industry — retrieved 2026-05-10 — Microchip 32% / NXP 11% 8-bit MCU share; 32-bit segment 51.4% of total MCU revenue 2025.
[12] https://www.gurufocus.com/news/8846907/mchp-maintained-by-citigroup-price-target-raised-to-113 — retrieved 2026-05-10 — Citi PT raised to $113; Needham to $120; consensus rating Buy.
[13] https://www.patreon.com/posts/semiconductor-11-157003424 (Tradenometry Semi Series) and Kearney analog renaissance article — retrieved 2026-05-10 — 7–17 year design-socket lifetime in industrial analog, switching-cost dynamics; ~50% of MCHP revenue through distribution.
[14] https://www.marketbeat.com/stocks/NASDAQ/MCHP/short-interest/ — retrieved 2026-05-10 — Short interest 27.6M shares, 5.2% of float, +10.3% sequential.
[15] https://www.microchip.com/en-us/about/news-releases/products/microsemi-rtg4-fpgas-become-industry's-first-high-speed-signal-processing-radiation-tolerant-fpgas-to-achieve-qml-class-v-qualification — retrieved 2026-05-10 — RTG4 first >150k-LE rad-tolerant FPGA at QML Class V.
[16] https://www.qyresearch.com/news/12401/pci-express-switches — retrieved 2026-05-10 — Global PCIe switch market $1.427B 2024; top 5 vendors 91% share.
[17] https://www.globenewswire.com/news-release/2025/11/06/3182816/28124/en/PCIe-Switch-Market-Report-2025-2034 — retrieved 2026-05-10 — Broadcom ~28% Gen 4 PCIe switch share 2025.
[18] https://www.microchip.com/en-us/about/media-center/blog/2025/introducing-the-first-3nm-gen-6-pcie-switchtec-family — retrieved 2026-05-10 — Switchtec Gen 6: 20 ports, 10 stacks, 160 lanes, post-quantum-safe root-of-trust.
[19] https://www.servethehome.com/broadcom-fires-a-shot-at-astera-labs-and-more-with-new-pcie-and-cxl-retimers/ and https://newsletter.semianalysis.com/p/astera-labs-ipo-the-next-connectivity — retrieved 2026-05-10 — ALAB ~47% retimer share; AVGO/MRVL launching Gen 6 retimers targeting ALAB.
[20] https://ir.microchip.com/news-events/press-releases/detail/1298/microchip-technology-engages-macquarie-group-to-facilitate-sale-of-tempe-fab-2-wafer-fabrication-facility — retrieved 2026-05-10 — Fab 2 sale via Macquarie; ~$90M annual savings; shutdown May 2025.
[21] https://www.manufacturingdive.com/news/microchip-tempe-arizona-chip-plant-closure-layoffs-inventory/735145/ — retrieved 2026-05-10 — Tempe shutdown details, 500-job cut.
[22] https://simplywall.st/community/narratives/us/semiconductors/nasdaq-txn/texas-instruments/pop3u7hv-texas-instruments-inc-txn-the-analog-recovery-and-the-300mm-competitive-moat and https://www.fool.com/earnings/call-transcripts/2026/04/22/txn-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — TXN 300mm cost moat, Q1 2026 GM 58%, +30% industrial YoY, +90% DC YoY.
[23] https://www.digitimes.com/news/a20251124PD204/semco-capacity-2026-abf-substrate-demand.html — retrieved 2026-05-10 — Semco 2026 ABF capacity fully booked by AWS/Alphabet/Apple/Broadcom/Tesla.
[24] https://www.fool.com/earnings/call-transcripts/2026/05/07/microchip-mchp-q4-2026-earnings-transcript/ and https://markets.financialcontent.com/stocks/article/stockstory-2025-11-7-mchp-q3-deep-dive-strategic-shift-to-ai-data-centers-amid-inventory-headwinds — retrieved 2026-05-10 — Sanghi commentary: 70–80% of nodes constrained, substrate constraints in DC/networking/auto, April largest booking month in nearly 4 years, "well above 1" book-to-bill.
[25] https://www.asteralabs.com/products/pcie-cxl-smart-dsp-retimers/ and SemiAnalysis ALAB IPO note — retrieved 2026-05-10 — COSMOS software stack as differentiator.
[26] https://www.servethehome.com/marvell-extending-pcie-gen6-reach-from-3-5-inches-to-meters/ — retrieved 2026-05-10 — Marvell Gen 6 retimer ~10W typical, 5nm process.
[27] https://www.eejournal.com/article/microchip-polarfire-and-the-imperative-of-the-intelligent-edge/ — retrieved 2026-05-10 — PolarFire 90% YoY growth in year 5, 65% of top-20 customers at intelligent edge.
[28] https://heavymoatinvestments.substack.com/p/analog-devices-vs-texas-instruments — retrieved 2026-05-10 — TXN vs. ADI positioning: ADI high-performance, TXN 300mm cost.
[29] https://ir.microchip.com/news-events/press-releases/detail/1385/nextgeneration-1001000baset1-single-pair-ethernet-phys-integrate-macsec-security-tsn-and-functional-safety — retrieved 2026-05-10 — LAN878x/LAN888x SPE PHYs with MACsec, TSN, ISO 26262 ASIL-B.