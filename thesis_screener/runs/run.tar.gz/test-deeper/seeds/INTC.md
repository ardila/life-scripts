# INTC — Intel Corporation

## Where this sits in the AI stack

Intel sits at three discrete layers that are increasingly being treated as separable businesses: (1) general-purpose host **server CPUs** for AI training/inference clusters (Xeon 6 "Granite Rapids" and "Clearwater Forest" — the CPU that sits next to Blackwell/MI300 trays, runs orchestration, agentic tool calls, and database/microservice workloads); (2) **leading-edge logic foundry capacity** (Intel 18A in HVM at Fab 52 Arizona today, 14A using ASML High-NA EUV starting risk-production 2027) — the only non-TSMC, non-Samsung leading-edge fab in the West; and (3) **advanced packaging** (EMIB-T, Foveros) — a second source to TSMC CoWoS-L. Its merchant AI accelerator effort (Gaudi 3, Falcon Shores → cancelled → Jaguar Shores) is a distant fourth and not currently a viable training competitor to Blackwell/MI400. The thesis is now about foundry + advanced packaging, not about competing GPUs.

## Snapshot

- **Price:** $124.92 (2026-05-08 close) [1]
- **Market cap:** ~$585B [2]
- **52-week range:** $18.97 – $130.57 [3]
- **Forward P/E:** ~117× on FY consensus EPS (range 117–125× depending on source/EPS revision) [2]
- **EV / NTM revenue:** n/a — could not source a clean consensus NTM revenue figure; on Q1'26 run-rate of ~$13.6B × 4 = ~$54B, EV/sales ≈ ~10.5×, an extraordinary multiple for a low-growth integrated logic + foundry business [4]
- **Consensus 12-month price target:** $65.44–$75.42, implying **–40% to –48%** from spot [5]
- **YTD total return:** +150% to +190% (sources disagree on whether the late-rally Apple-deal jump is captured) [6][7]
- **Short interest:** ~144M shares, **~2.9% of float** as of mid-April 2026, up ~21% MoM [5]

## Moat — what it is physically made of

Intel's moat has changed character entirely in the last 18 months. Decomposing what is left:

**1. Leading-edge fab capacity in the US (durable, structurally scarce).** Intel 18A is in volume manufacturing at Fab 52 in Arizona for Panther Lake client tiles, with Intel 3 and 4 also at production yields [4][8]. TechInsights' process scorecard ranks 18A at **2.53 vs TSMC N2 at 2.27** — Intel is genuinely competitive on raw PPA, and is **first to high-volume backside power delivery (PowerVia)**, which gives ~30% voltage-droop reduction and frees front-side metallization for signal routing [9]. TSMC N2 is denser (313 vs 238 MTr/mm²) but does not have backside power until A16/A14 in 2027–28 [9]. The non-fungible asset is *western leading-edge wafer starts*, which Apple, the DoD, Tesla, and OpenAI-class customers cannot get anywhere else — TSMC Arizona is one node behind Taiwan and gated by labor/yield differences. This is a real moat, but its value depends on whether anyone besides Intel itself buys those wafers (see Bear).

**2. Advanced packaging as a second source to CoWoS-L (medium durability, real today).** TSMC CoWoS-L is fully booked through 2027 by NVIDIA, AMD, Google TPU, AWS Trainium, and Broadcom [10][11]. Intel's EMIB (silicon bridges in substrate) and Foveros (vertical die stacking) provide functionally similar heterogeneous integration with **EMIB-T heading to fab rollout in 2026** [10]. Intel claims some CoWoS-scoped designs port to Foveros without modification [11]. New Mexico facility EMIB capacity expanding +30%, Foveros +150% [11]. Crucially, Intel packaging is not at saturation — for hyperscalers with chip projects blocked by CoWoS allocation, Intel is the closest alternative on the planet. Google is reportedly evaluating EMIB for TPU v8e [8].

**3. x86 server ISA with NVIDIA co-design (re-rated, not eroded).** September 2025 NVIDIA $5B equity at $23.28/share + commitment to build **NVIDIA-custom x86 CPUs integrated via NVLink** for AI infrastructure platforms, plus x86 SoCs with RTX GPU chiplets for PC [12]. This is the most important moat development in 5 years: NVIDIA, whose Grace ARM CPU was supposed to displace Xeon in AI racks, instead spent $5B to ensure x86 stays in those racks. Intel still has 64.2% server CPU unit share in Q1 2026 (down from 77% in 2021, but stabilizing) [13]. AMD passed Intel on data-center *revenue* ($5.8B vs $5.1B) but Intel holds units — meaning AMD is winning the high-ASP top-end while Intel keeps the volume [13][14].

**4. US sovereign backstop (implicit, hard to value).** The Trump administration bought **9.9% of Intel at $20.47/share for $8.9B** (Aug 2025), drawn from CHIPS Act grants + secure-enclave funds, with a warrant for an additional 5% if Intel ceases to be majority owner of the foundry [15]. This is not a board seat, but it is an implicit floor — the US government is structurally invested in Intel surviving as a foundry. Apple's preliminary 18A-P deal (May 2026) is reasonably interpreted as a political contribution as much as a commercial one [16][7].

**5. Software (oneAPI/SYCL) — not a moat.** SYCL adoption outside HPC remains thin; CUDA's 4M-developer ecosystem and decade of accumulated cuDNN/CUTLASS/NCCL primitives is not being meaningfully eroded by oneAPI [17]. Treat Intel's software story as a checkbox, not a defensible asset.

**What is not a moat anymore:** Merchant AI accelerators (Gaudi 3 is competitive on Llama 2 70B inference vs *H100* — i.e., 2022 hardware — and offers no training-frontier story [18]); Falcon Shores cancelled; Jaguar Shores rack-scale HBM4 system not shipping in volume before 2027 [19]; mainstream Diamond Rapids Xeon 7 *delayed to mid-2027* [20]. Intel has openly conceded that "competitive AI chips won't arrive until 2027" [21].

## AI buildout bottleneck map

The actual gating constraints on AI buildout over the next 24 months, with Intel's position on each:

| Bottleneck | Status | Intel position |
|---|---|---|
| **Power generation / gas turbines** | GE Vernova, Siemens, Mitsubishi all booked ~5 years out; Siemens Energy €136B backlog [22] | **Indifferent** — Intel is a customer of power, not a supplier; its fabs need enormous power too |
| **Grid transformer lead times** | 128 weeks vs 24–30 months pre-2020 [22] | **Exposed customer** (Arizona/New Mexico/Ohio fab buildouts depend on grid interconnect) |
| **CoWoS-L advanced packaging** | TSMC fully booked through 2027; 12GW of 2026 capacity announced but only 5GW under construction [22] | **Beneficiary / supplier** — EMIB + Foveros are the credible second source; this is the cleanest part of the bull thesis [10][11] |
| **HBM3e/HBM4 supply** | SK Hynix dominant, Samsung trying to qualify, Micron ramping | **Indifferent / exposed** — Intel does not make HBM; Jaguar Shores depends on SK Hynix HBM4 [19] |
| **Optical interconnect / silicon photonics** | Co-packaged optics scaling for 800G/1.6T | **Modest player** — Intel has historic silicon photonics IP, Jaguar Shores claims rack-scale photonics focus [23], but not a leadership position |
| **Liquid cooling at >100kW/rack** | Direct-to-chip and immersion supply constrained | **Indifferent** |
| **Kernel/compiler talent (CUDA)** | Severe shortage | **Disadvantaged** — Intel pays full freight for talent that defaults to CUDA |
| **Leading-edge logic wafer starts (US)** | Only TSMC AZ (one node behind Taiwan) + Intel AZ/NM/OH | **The constraint owner**, alongside TSMC AZ. This is the strongest single position [4][8] |
| **Training data quality at the frontier** | Synthetic + post-training | **Indifferent** |

Where Intel uniquely benefits is the intersection of *US-sited leading-edge logic capacity* and *advanced packaging not gated by CoWoS-L*. Where it does not benefit is anywhere AI compute itself sits — its accelerator and software story is a follower.

## Competitive teardown

**vs. TSMC (foundry):** TSMC has ~20 years of customer trust, every leading fabless customer in production, and superior yields at maturity. Intel 18A is competitive on raw transistor metrics [9] and is **first to backside power**, but TSMC N2 reaches HVM only weeks/months behind 18A and TSMC's A16 (Super Power Rail, ~2026–27) closes the backside-power gap [9]. The axis Intel can win on for the next 2–3 years: **US-sited capacity for customers who care about it** (Apple post-2027 entry M-series chips [16], Tesla Terafab 14A [24], potentially AWS Trainium and Google TPU packaging [25]). What would need to be true for TSMC to remain dominant: continued execution on N2/A16 + Arizona ramp + customer inertia. Base rate for foundry leadership shifts: only one node-leadership transition in 30 years (Intel → TSMC, ~2018–20). Reverse transitions in this industry are essentially unprecedented at scale; Intel is more credibly positioned as a *second source at premium price* than as a leadership-displacing primary.

**vs. AMD (server CPU):** AMD EPYC Turin holds ~41% server CPU revenue share, ~29% units [14][26]; Venice (Zen 6, 256 cores, TSMC N2, 2026) will widen the performance gap on the top end [26]. Intel's counters: Clearwater Forest 288-core E-core (1H26 on 18A) targets hyperscaler scale-out; Diamond Rapids P-core delayed to mid-2027 [20] — this is a **critical execution failure** that gives AMD a full extra year to gain share. Granite Rapids has had to be price-cut after launch [20]. Intel's structural advantage is still unit volume in enterprise/legacy, plus the NVIDIA NVLink-x86 partnership pulling a premium AI-host SKU through [12]. Parity claim: in raw socket-level perf/W, AMD is ahead on TSMC nodes; Intel can argue tighter NVIDIA integration is differentiated for AI hosts.

**vs. NVIDIA (AI accelerator):** Not a real competition anymore. Gaudi 3's ~20% inference throughput edge over H100 [18] is irrelevant when Blackwell B200/B300 and GB300 NVL72 are the deployed reality and MI400 is shipping. Intel has reframed Jaguar Shores as a 2026/27 rack-scale *inference* system on HBM4 with silicon photonics [23][19] — competitive positioning, but not vs. NVIDIA's training scale-up moat (NVLink72 + NVSwitch + NCCL stack + Mellanox InfiniBand + Spectrum-X). What would have to be true for Intel to compete: a multi-year credible roadmap with FP4 training parity, NVLink-equivalent scale-up fabric, and a 1M+ developer ecosystem on oneAPI. None of these are true today.

**vs. Broadcom / Marvell (custom ASIC):** Broadcom is the *de facto* hyperscaler ASIC designer; Intel's Foundry can manufacture the silicon and package it, but does not own the customer relationship. Intel-Google custom IPU collaboration [25] is the model that scales — Intel as foundry + packaging, hyperscaler as designer.

## Bull case — technical

For Intel to outperform from $125 over the next 24 months, the following technical conditions must hold:

1. **18A yields continue improving** to a level where wafer cost per good die is within ~15–20% of TSMC N2 at equivalent design rules. Q1'26 commentary indicated Intel 4/3/18A yields improving, narrowing foundry loss [4][27].
2. **At least one of (Apple, NVIDIA, Microsoft, AWS, Tesla, Google) converts a preliminary engagement to a >$1B/yr wafer commitment** by end of 2027. Apple 18A-P entry M-series 2027 [16] and Tesla Terafab 14A [24] are the closest. CoWoS-L scarcity continues 24+ months, forcing hyperscaler ASIC programs onto EMIB/Foveros [10][11].
3. **NVIDIA-custom x86 + NVLink platforms ship in volume** in 2027, locking Intel into Blackwell-successor server architectures (Rubin Ultra trays) and providing a structural revenue stream uncorrelated with AMD share trajectory [12].
4. **Clearwater Forest holds the line on E-core hyperscaler share** while Diamond Rapids slips to mid-2027; Mercury Q2/Q3 unit share above 60% [13].
5. **Foundry external revenue inflects from $174M/Q to $500M+/Q** by Q4 2027 (still tiny vs market cap, but the *direction* is what re-rates the multiple).
6. **US government backstop persists** — no warrant exercise event, continued CHIPS-linked subsidies.

Financial outcome: this combination justifies modeling Intel Foundry as a 10-year strategic asset rather than an industrial cyclical, sustaining a 5–8× EV/sales multiple. Base rate: technology platform shifts that take this long (5+ years from concession of leadership to recapture) have ~1 successful precedent (AMD 2017–2024) and many failures (IBM, Sun, DEC).

## Bear case — technical

A short-seller who understands the stack would write the following:

1. **Foundry external revenue is $174M against a $585B+ market cap.** [27] The "Apple deal" is preliminary, for an entry-level M-series chip on 18A-P that won't ship before 2027, in volumes Apple has not specified and that Apple can renegotiate or cancel at any time [16]. Tesla Terafab is contingent on a $25B Musk-led project that has not started construction [24]. Treat all foundry pipeline as optionality, not revenue, until tapeouts and PDKs convert to wafer commitments.

2. **Diamond Rapids slipping to mid-2027** [20] gives AMD Venice (Zen 6, 256 cores, N2) a full year of uncontested top-end share gains. Mercury share data shows units stabilizing but ASP/mix continues eroding — AMD revenue past Intel in Q1'26 [13][14].

3. **18A is competitive but more expensive per wafer than N2** due to backside-power processing complexity [9]. If Apple, NVIDIA, or AWS care about cost-per-good-die rather than backside-power benefit on their specific design, they will stay with TSMC. The customer wins to date are politically pressured (US-sited capacity) more than economically pulled.

4. **AI accelerator story is dead until at least 2027.** Falcon Shores cancelled, Gaudi 3 competes against 3-year-old NVIDIA hardware, Jaguar Shores HBM4 rack-scale system delayed [19][21][18]. Intel will not capture meaningful share of the $400B+ AI accelerator TAM through this cycle.

5. **High-NA EUV economics are unproven.** EXE:5200B at ~$380M/scanner [28]. 14A risk production 2027, HVM 2028 [29] — Intel is betting the company on being first to a tool that has never been proven at HVM yields. If High-NA yields disappoint, the 14A roadmap slips and the entire foundry narrative collapses.

6. **Forward P/E of 117–125×, consensus PT 40–48% below spot** [2][5]. The 33 Hold + 6 Sell consensus is not analyst laziness — it reflects a structural disconnect between the financial reality (DCAI growth modest, foundry external trivial, AI accelerator absent) and a stock price that has 5× in <12 months on government-stake + Apple-deal-PR + retail momentum.

7. **Base rate on technology displacement:** Companies that lose process leadership rarely regain it. IBM ceded leadership in the 2000s and is now a foundry-of-record only for niche government work. Going from "first to backside power on 18A" to "winning a foundry business with TSMC's customer trust" is a 7–10-year project even if Intel executes flawlessly. The market is paying year-7 prices for a project at year 1–2.

## Market view check

The stock at $125 against a consensus PT of $65–75 [5][1] is an unusually wide divergence and the most important single signal in the file. The price is consistent with the market believing: (a) Intel Foundry external revenue inflects in 2027–28 to a $5–10B+ annual run-rate, (b) the US government implicitly underwrites the equity, (c) the Apple/Tesla/NVIDIA partnerships convert from preliminary to binding, and (d) Intel is a "strategic national asset" multiple, not an industrial cyclical. Analysts are skeptical because the *current* financials (foundry external $174M/Q [27], DCAI $5.1B but losing share to AMD on revenue [13][14], AI accelerator absent, EPS still depressed) do not support any of those beliefs. The market is making a sovereign-backed option bet on foundry execution; analysts are pricing the operating business. The disconnect is the trade. A long position here is implicitly long Intel Foundry execution + US industrial policy. A short is implicitly short the same two things — and short something the US government just bought $8.9B of.

## 90-day falsifiers

Specific, observable events in the next ~90 days (through August 2026) that would update the thesis materially:

1. **Q2 2026 earnings (~July 23):** Intel Foundry external revenue — does it move materially above $174M/quarter [27]? Diamond Rapids tapeout/silicon status. Any binding Apple wafer agreement or "preliminary" still-preliminary.
2. **Apple 18A-P PDK release / binding wafer commitment:** Currently characterized as preliminary [16][7]. A definitive supply agreement (volume, ASP, duration) versus continued vague language.
3. **Mercury Research Q2 2026 server CPU report (July/August):** Did Intel unit share hold above 63% or did AMD Venice ramp accelerate share loss [13]?
4. **Hot Chips 2026 (mid-August):** Jaguar Shores deep dive — HBM4 bandwidth, scale-up fabric, FP4/FP8 numerics. Compare against Blackwell Ultra and MI400 published specs.
5. **ASML earnings (July):** High-NA EUV EXE:5200B shipment cadence and Intel-specific delivery confirmation for 14A risk production [28].
6. **Tesla Terafab milestones:** Construction commencement in Austin, equipment orders. As of Q1, this remains a press release; physical progress would be a major positive falsifier [24].
7. **Mercury / TrendForce CoWoS allocation reports:** If TSMC announces additional CoWoS capacity online in Q3, Intel's EMIB/Foveros bull case weakens; if backlog widens, it strengthens [11].
8. **Any Intel Foundry customer cancellation** (Microsoft has gone quiet; Broadcom previously walked from 18A in 2024). A high-profile drop would be a major negative falsifier.
9. **A US administration policy event** that adjusts the federal stake or warrant terms (e.g., exercising the 5% warrant if any foundry spin/sale is mooted) [15].

## What I could not verify

- **Specific 18A yield numbers.** Intel public commentary is qualitative ("yields improving" [4][27]); no quantified defect density vs. TSMC N2 in public sources.
- **Apple 18A-P wafer volume, ASP, or contract duration.** All coverage characterizes the agreement as "preliminary" [16][7]. The actual commercial terms are not public.
- **NVIDIA-custom x86 SKU specifications and shipping cadence.** The September 2025 announcement is strategic [12]; no public roadmap of the actual product timeline beyond "multiple generations."
- **AWS, Microsoft, Google foundry-design wafer commitments.** Coverage refers to "advanced talks" and "co-development" but no specific tapeouts/wafer volumes [25].
- **Real cost-per-good-die comparison between Intel 18A and TSMC N2.** Industry consensus that 18A is more expensive per wafer [9], but quantitative gap is not public.
- **Jaguar Shores actual silicon timeline and customer commitments.** "Rack-scale 2026" claims [23][19] sit next to "competitive AI chips won't arrive until 2027" [21] — these are inconsistent and Intel has not reconciled them publicly.
- **Foundry segment profitability inflection point.** Intel has guided break-even "by end of 2027" historically; under Tan, no specific date has been re-affirmed.
- **EV/NTM revenue with consensus 2027 estimates.** Consensus models are in flux post-Apple-deal news and most aggregators show wide ranges.

## Sources

[1] https://finance.yahoo.com/quote/INTC/history/ — retrieved 2026-05-10 — INTC closing price $124.92 on 2026-05-08

[2] https://www.gurufocus.com/term/forward-pe-ratio/INTC — retrieved 2026-05-10 — Forward P/E 117.38 as of 2026-05-09; market cap data point

[3] https://247wallst.com/investing/2026/05/04/intel-stock-has-quintupled-from-lows-is-the-easy-money-already-gone/ — retrieved 2026-05-10 — 52-week range $18.97–$130.57; stock quintupled from lows

[4] https://d1io3yog0oux5.cloudfront.net/_2cc2e214977e16134faf0e97e6380cbb/intel/db/887/9254/prepared_remarks/1Q2026-Earnings-Call.pdf — retrieved 2026-05-10 — Q1 2026 earnings call: Foundry revenue $5.4B, 18A volume manufacturing at Fab 52, yield improvements

[5] https://www.marketbeat.com/stocks/NASDAQ/INTC/short-interest/ — retrieved 2026-05-10 — Short interest ~144M shares (2.9% of float), +20.9% MoM April 2026; consensus PT $75.42 (9B/33H/6S)

[6] https://finance.yahoo.com/markets/stocks/articles/intel-stock-190-2026-trump-131501491.html — retrieved 2026-05-10 — Intel stock up ~190% YTD 2026; Trump valuation commentary

[7] https://www.fxleaders.com/news/2026/05/09/intel-intc-stock-analysis-126-after-back-to-back-10-sessions-apple-deal-sambanova-approval-and-the-valuation-question/ — retrieved 2026-05-10 — $126 close after Apple deal and SambaNova approval

[8] https://www.trendforce.com/news/2026/04/29/news-intel-foundry-gains-momentum-apple-reportedly-eyes-18a-p-as-google-explores-advanced-packaging/ — retrieved 2026-05-10 — Apple 18A-P evaluation, Google TPU v8e exploring EMIB packaging

[9] https://www.tomshardware.com/pc-components/cpus/intels-18a-production-starts-before-tsmcs-competing-n2-tech-heres-how-the-two-process-nodes-compare — retrieved 2026-05-10 — 18A vs N2 PPA, density (238 vs 313 MTr/mm²), TechInsights score 2.53 vs 2.27, PowerVia 30% voltage droop reduction

[10] https://www.tomshardware.com/tech-industry/semiconductors/intels-emib-t-heads-for-fab-rollout-this-year — retrieved 2026-05-10 — EMIB-T fab rollout 2026, CoWoS capacity stretched

[11] https://www.tomshardware.com/tech-industry/semiconductors/intel-gains-ground-in-ai-packaging-as-cowos-capacity-remains-stretched — retrieved 2026-05-10 — Intel NM packaging expansion +30% EMIB, +150% Foveros; CoWoS-to-Foveros design ports

[12] https://nvidianews.nvidia.com/news/nvidia-and-intel-to-develop-ai-infrastructure-and-personal-computing-products — retrieved 2026-05-10 — NVIDIA $5B equity at $23.28/share; custom x86 CPUs with NVLink; x86+RTX chiplet SoCs

[13] https://winbuzzer.com/2026/05/08/analysis-amd-overtakes-intel-in-data-center-revenu-xcxwbn/ — retrieved 2026-05-10 — Mercury Research Q1 2026: Intel 64.2% server CPU shipments (down from 77% in 2021); AMD DC revenue $5.8B vs Intel DCAI $5.1B

[14] https://www.cnbc.com/2026/05/05/amd-q1-2026-earnings-report.html — retrieved 2026-05-10 — AMD Q1 2026 data center revenue $5.8B

[15] https://www.cnbc.com/2025/08/22/intel-goverment-equity-stake.html — retrieved 2026-05-10 — US government 10% stake at $20.47/share ($8.9B); warrant for additional 5% if Intel not majority owner of foundry

[16] https://www.macrumors.com/2026/05/08/apple-intel-preliminary-chip-deal/ — retrieved 2026-05-10 — Apple-Intel preliminary deal; 18A-P; entry M-series 2027 (Ming-Chi Kuo)

[17] https://www.devclass.com/development/2023/08/22/interview-intel-beats-the-drum-for-oneapi-and-sycl-in-place-of-nvidias-cuda/1627073 — retrieved 2026-05-10 — oneAPI/SYCL adoption status outside HPC remains weak vs CUDA

[18] https://www.tomshardware.com/tech-industry/artificial-intelligence/intel-launches-gaudi-3-accelerator-for-ai-slower-than-h100-but-also-cheaper — retrieved 2026-05-10 — Gaudi 3 ~20% throughput edge on Llama 2 70B vs H100; 128GB HBM2e; price-positioned alternative

[19] https://www.tomshardware.com/tech-industry/artificial-intelligence/intel-jumps-to-hbm4-with-jaguar-shores-2nd-gen-mrdimms-with-diamond-rapids-sk-hynix — retrieved 2026-05-10 — Jaguar Shores HBM4 from SK Hynix; rack-scale design

[20] https://www.tomshardware.com/pc-components/cpus/intels-upcoming-xeon-7-diamond-rapids-server-cpus-reportedly-delayed-to-2027-next-gen-coral-rapids-lineup-lands-2028-but-can-be-accelerated-according-to-new-leak — retrieved 2026-05-10 — Diamond Rapids delayed to mid-2027; Granite Rapids price cuts; 256/512 core configurations

[21] https://www.ofzenandcomputing.com/intel-ceo-plans-to-turn-company-around-with-strategic-restructuring-initiative/ — retrieved 2026-05-10 — Lip-Bu Tan restructuring; 15% headcount cut; "competitive AI chips won't arrive until 2027"

[22] https://introl.com/blog/hyperscaler-capex-690-billion-microsoft-azure-power-bottleneck-2026 — retrieved 2026-05-10 — Hyperscaler $660–690B 2026 capex; power bottleneck; 128-week transformer lead times; gas turbine 5-year backlogs

[23] https://www.tomshardware.com/tech-industry/artificial-intelligence/intel-redefines-ai-strategy-jaguar-shores-to-be-rack-level-design-with-focus-on-silicon-photonics — retrieved 2026-05-10 — Jaguar Shores rack-scale, silicon photonics focus

[24] https://www.techpowerup.com/348487/intel-posts-strong-q1-2026-results-lands-tesla-as-first-14a-node-major-customer — retrieved 2026-05-10 — Tesla as first major 14A customer; Terafab Austin $25B project for autos/robots/orbital data centers

[25] https://247wallst.com/investing/2026/04/06/intel-is-on-the-verge-of-delivering-its-first-billion-dollar-foundry-wins/ — retrieved 2026-05-10 — Google/Amazon advanced packaging talks; Intel-Google custom IPU collaboration

[26] https://www.servethehome.com/amd-epyc-venice-2026-with-1-3x-thread-density-and-1-7x-performance/ — retrieved 2026-05-10 — AMD EPYC Venice 256 Zen 6 cores on TSMC N2; performance metrics

[27] https://www.intc.com/news-events/press-releases/detail/1767/intel-reports-first-quarter-2026-financial-results — retrieved 2026-05-10 — Intel Q1 2026 press release: $13.6B revenue, Foundry external revenue $174M, $2.4B foundry operating loss, non-GAAP GM 41%, non-GAAP EPS $0.29

[28] https://www.tomshardware.com/tech-industry/semiconductors/intel-installs-industrys-first-commercial-high-na-euv-lithography-tool-asml-twinscan-exe-5200b-sets-the-stage-for-14a — retrieved 2026-05-10 — ASML EXE:5200B installed at Intel for 14A development; ~$380M/scanner

[29] https://www.trendforce.com/news/2025/12/16/news-intel-completes-first-2nd-gen-high-na-euv-acceptance-testing-asml-eyes-2027-28-mass-production/ — retrieved 2026-05-10 — 14A risk production 2027, HVM 2027–28