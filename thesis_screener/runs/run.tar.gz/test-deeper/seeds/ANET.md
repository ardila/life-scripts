# ANET — Arista Networks, Inc.

## Where this sits in the AI stack
ANET sells high-radix Ethernet switches and the software that runs them (EOS + CloudVision) at the **scale-out** layer of AI clusters — the leaf/spine fabric that connects accelerator pods together once a job exceeds one rack of NVLink-bonded GPUs/XPUs. The hardware is merchant Broadcom silicon: Tomahawk 5/6 for low-buffer leaf switches (7060X6 family, 51.2 Tbps) and Jericho3-AI + Ramon for deep-buffer, virtual-output-queued AI spines (7800R4, 460 Tbps; 7700R4 DES distributed system scaling to 27,000+ 800G ports) [1][2][14]. ANET does **not** play meaningfully today in scale-up (GPU-to-GPU inside the rack — NVLink/UALink/Maia ATL territory) and is only now staging into scale-across (DCI) and a 2027+ Ethernet scale-up via the ESUN OCP workstream [4][15]. The workload is overwhelmingly distributed training and large-cluster inference, not retail enterprise switching.

## Snapshot
- **Price:** $141.50 (2026-05-08/10 close) [3]
- **Market cap:** $178.5B [3]
- **52-week range:** $83.86 – $179.80 (low 2025-05-07, high 2026-04-24) [5]
- **Forward P/E:** 37.4× (NTM) [3]
- **EV / NTM revenue:** ~14.4× (EV ≈ $166B against FY26 guide of $11.5B; trailing EV/Rev cited at 17.1× on $9.0B FY25) [3][7]
- **Consensus 12-month price target:** ~$175–181 (implied +24–28%) [6]
- **YTD total return:** n/a — could not source exact 2025-12-31 close; the stock is roughly mid-range after a -14% post-earnings drawdown from the April $179.80 high [3][5]
- **Short interest:** 1.38–1.66% of float (low) [9][3]

## Moat — what it is physically made of
The brand-and-relationships story (Jayshree Ullal, Andy Bechtolsheim, founding 2004) is real but secondary. The defensible substrate is three layers:

**1. EOS as a single-binary, multi-process state-sharing Linux NOS.** EOS runs an unmodified Linux kernel with all protocol/forwarding/management state held in a publish-subscribe central database (Sysdb-style architecture) so processes crash and restart without dropping forwarding state. Crucially the *same* binary boots on Trident, Tomahawk, Jericho, and now Tomahawk 6 — meaning a Microsoft or Meta network engineering team writes one EOS automation stack and gets the same CLI, the same streaming telemetry semantics, and the same upgrade path across five silicon generations [10][11]. SONiC (Microsoft's own open NOS, now Linux Foundation) is the credible threat here, with Aviz and others certifying enterprise distributions and Dell'Oro projecting >$5B SONiC switch revenue by 2026 [22]. The honest read: SONiC has gone from "Microsoft tier-0 only" to "credible at any hyperscaler that wants to disaggregate," and EOS's *technical* lead over SONiC at the protocol-richness, EVPN-VXLAN, and operational-tooling layer has narrowed from ~5 years to ~2.

**2. CloudVision telemetry/automation ingrained in customer runbooks.** Roughly 3,000 customers deploy CloudVision; this is where the actual switching cost lives. Replacing the switch is straightforward; replacing the change-management workflow, the streaming telemetry pipelines, the AVA (Autonomous Virtual Assist) AI/ML traffic-pattern models, and the integrations with customer NetDevOps tooling is a 12–18 month project per cluster [11][20]. This is the same stickiness pattern that kept Cisco IOS dominant for 25 years — it's real, but it is also a function of customer **willingness** to pay for it rather than a physical constraint on the competitor.

**3. The Cisco settlement and the Broadcom relationship.** ANET paid Cisco $400M in 2018 to clear the CLI-copyright/patent overhang; the 5-year covenant-not-to-sue has expired but no new litigation has emerged [16]. More important: ANET is Broadcom's lead high-end customer for Jericho3-AI and Ramon — the deep-buffer cell-spraying VOQ architecture used in the 7800R4 spine is *not* something a white-box ODM can casually ship, because the system-level scheduler integration with EOS is non-trivial and Broadcom appears to gate the highest-end Jericho/Ramon SKUs and reference designs through tier-1 partners (Arista, Cisco, Juniper) before broader OEM/ODM availability [1][2]. The 7700R4 DES — a multi-chassis distributed switch presenting as one logical switch — is the clearest example of system engineering ANET adds on top of merchant silicon that competitors cannot trivially copy.

**Honest summary of moat durability:**
- EOS as software differentiation vs. SONiC: **eroding slowly but steadily** (5 → 10 years, not 20)
- Hyperscaler operational lock-in via CloudVision/automation: **strong for installed base, weaker for greenfield AI back-end clusters** where the customer is already rewriting tooling for new workloads
- Broadcom system-level partnership on Jericho/Ramon deep-buffer spines: **durable as long as Broadcom wants a tier-1 systems partner**, which is the variable to watch

What is **not** the moat: custom silicon (ANET has none), proprietary protocols (their Ethernet runs UEC/RoCEv2 same as everyone else), or scale (Cisco is 4× larger by revenue).

## AI buildout bottleneck map
The 24-month gating constraints and where ANET sits on each:

| Bottleneck | Status | ANET position |
|---|---|---|
| TSMC CoWoS-L packaging | NVIDIA has booked >50% of 2026 capacity; line is sold to ~120-130k wafers/mo by YE26 [12] | Indirect — limits **NVIDIA scale-up**, which marginally helps Ethernet scale-out share |
| HBM3e/HBM4 | 8-hi and 12-hi fully allocated through 2026, prices +15-22% YoY [12] | Indifferent — switches don't use HBM |
| 800G EML transceivers | McKinsey: production 40–60% short of demand through 2027; Lumentum is sole 200G/lane volume supplier; Coherent InP sold through 2027 [18] | **Exposed customer** — ANET buys these to ship systems; prepaid commitments doubled YoY per Q1 call [13] |
| 1.6T optics | 30–40% short through 2029 [18] | Same exposure; gating their 2027 1.6T scale-out generation |
| Co-packaged optics | Broadcom TH6-Davisson shipping Oct 2025 (102.4 Tbps CPO); NVIDIA Spectrum-X Photonics 2H 2026 [8][19] | Beneficiary if open Broadcom CPO wins, vulnerable if NVIDIA's vertically integrated CPO becomes the default |
| Grid power / interconnect | 5-yr transformer backlog; 40% of 2027 AI DCs expected to be power-constrained; GE Vernova gas turbines ~3-yr lead [21] | Indirect beneficiary — every constrained MW is allocated to compute first, networking second, but networking gets bought |
| Liquid cooling at 100kW+/rack | Vertiv MegaMod HDX, CoolIT in 300 DCs — capacity is being built but still tight [23] | Indifferent — switches are still air-cooled in most racks; CPO will eventually require it |
| Kernel/compiler talent | Severe NCCL/CUTLASS/Triton scarcity | Indifferent on the silicon side; EOS team is a separate labor pool |
| Switch ASIC supply (Tomahawk, Jericho) | Broadcom yields appear adequate; lead-time pressure is more about board/system integration | Direct supply dependency — also TH6 shipping June 2025 [8] is the next-gen platform |

**Net read:** ANET's bottleneck exposure is concentrated in **optical transceivers**, not silicon. Their Q1 2026 disclosure of doubled prepaid component commitments [13] is consistent with management buying forward against the Lumentum/Coherent supply squeeze. This is also the most plausible explanation for the Spectrum-X Meta deal — when 800G optics are 40-60% short, hyperscalers will dual-source the *system* vendor to get more optics quota, not because Spectrum-X is technically superior.

## Competitive teardown

**NVIDIA Spectrum-X (the existential threat).** Spectrum-4 silicon (51.2 Tbps SN5600) paired with BlueField-3 SuperNIC packet-spraying and adaptive routing. Spectrum-X grew **+760% YoY to $1.46B in Q1 CY2025, basically tied with ANET's $1.48B** in datacenter Ethernet [17]. xAI Colossus (100k GPUs) and now Meta and Oracle have standardized on it [24][26]. Technical axis: NVIDIA wins the *bundled* sale when the customer is also buying GB200/GB300/Rubin — the SuperNIC + Spectrum-4 combination is co-designed for NCCL collective patterns and gets to 95% effective bandwidth utilization. ANET's response is UEC 1.0 conformance + Etherlink + 7700R4 DES. On a pure-Ethernet-fabric merits basis they are close to parity, but the customer choice is increasingly "do I take the full NVIDIA reference design or assemble myself?" Already a structural loss of optionality for ANET, even when ANET wins the deal (as it did at Meta's DSF). **Falsifier: if NVIDIA's Q2 CY26 networking segment exceeds $2.5B run-rate, Spectrum-X is taking share at the same gross pace that ANET is adding it.**

**Cisco Silicon One (G200 → G300).** Cisco finally has competitive 51.2 Tbps silicon (G200 in Nexus 9364E-SG2 and Cisco 8122 systems) and announced G300 in Feb 2026 [25]. Their AI revenue hit $600M+/quarter, 2× YoY. Cisco's *technical* problem is not silicon anymore — it's that IOS-XR/NX-OS were not designed for the streaming-telemetry, API-first operational model AI clusters need. Cisco bought Splunk for $28B partly to address this. ANET is still ahead on operational software but not by the margin it was 24 months ago.

**Broadcom + ODMs (Celestica, Accton/Edgecore) running SONiC.** This is the underappreciated threat. **Celestica was the Dell'Oro #1 vendor in BOTH AI-Networks Ethernet switching AND >800G high-speed switching in 2024** [27][17]. When NVIDIA + Celestica together captured 50% of AI back-end network revenue in 2025, **ANET ranked third** [17]. Meta's "DSF" architecture is explicitly designed to disaggregate to white-box where possible and only pull in Arista/NVIDIA where the system engineering is too hard. The Q1 disclosure of a neocloud migrating *from* white-box *to* Arista 800G Etherlink [13] is real, but the gravity at the very largest customers runs the other way.

**Hyperscaler in-house networking.** Three of the top six AI buyers do not need ANET for their core training network:
- **Google:** Apollo OCS + Jupiter SDN, ~9,216 TPU pods, with networking <5% of pod capex and <3% of power. ANET shipments to GCP are minimal [29].
- **AWS:** Project Rainier 500k Trainium2 chips connected by in-house EFAv3 (12.8 Tbps per UltraServer) with proprietary multipathing congestion control [30]. ANET is at the front-end/management network only, not back-end.
- **Microsoft Maia 200:** Custom ATL transport layer, in-house NIC with packet spraying, scale-up over Ethernet on Microsoft-designed switches. Microsoft still buys Arista for some top-of-rack but dual-sources Cisco; the Maia network displaces ANET from the highest-margin GPU-fabric layer [31].

**Meta:** Mixed. Deploys Arista 7700R4 DES in its Disaggregated Scheduled Fabric for ~100k DPUs *and* deploys NVIDIA Spectrum-X for newer clusters [14][24]. Meta's 16% revenue concentration is real but distributed-fabric specific.

## Bull case — technical

**Base rate first.** In networking, the incumbent NOS franchise tends to be durable: Cisco IOS held a >70% data-center share from 1996 to 2014 — an 18-year run — and was eroded by both white-box (Cumulus/SONiC) *and* a software-first competitor (Arista). The base rate for a software-anchored networking franchise to compound 15-20% revenue for 5+ years through a platform shift is reasonable; the base rate for it to *outperform* the broader AI-infra basket through that shift is lower because the shift itself compresses pricing.

**Technical conditions that need to hold:**
1. Ethernet continues to gain back-end AI share at Dell'Oro's projected pace — crossing 50% of AI back-end revenue in 2025 (already true at 2/3 [32]) and dominant by 2027 [33]. **Probably true.**
2. ANET's 7700R4 DES distributed architecture proves to be a meaningful technical differentiator at >32k-port scale where flat Clos topologies start hurting on cabling/latency/blast radius. **Plausible — Meta deployment is the proof point.**
3. UEC 1.0 deployments converge on multi-vendor interop, breaking NVIDIA's "buy the bundle" sales advantage. **Open question; 2026 deployments will tell.**
4. ESUN Ethernet-for-scale-up reaches production by 2027/2028 and ANET captures share against NVLink/UALink in the scale-up layer. **Speculative — Ullal herself said "not material until 2027+" [4].**

**Financial translation:** $11.5B 2026 → $14B+ 2027 (~22%) → $17B 2028. At 50% incremental operating margin, that's ~$8B+ FCF in 2028. At 30× = ~$240B market cap, ~35% upside over 30 months. Not a multi-bagger from here; a "good but unspectacular" outcome consistent with where the multiple already sits.

## Bear case — technical

**The technical short-seller's case** is not "AI demand slows." It is:

1. **The Ethernet-vs-InfiniBand victory is also a victory for Spectrum-X, not ANET.** The ANET bull case implicitly treats "Ethernet wins" as equivalent to "ANET wins." But the Q1 CY25 data point ($1.48B ANET ≈ $1.46B Spectrum-X) [17] suggests Ethernet displacement of InfiniBand is going *to NVIDIA*, not to the merchant ecosystem. If NVIDIA networking compounds 100% YoY from here while ANET compounds 30%, the share crossover happens by end-2026.

2. **The customer concentration is going the wrong way.** Microsoft (26%) and Meta (16%) [7] are exactly the two customers most aggressively building in-house alternatives (Microsoft ATL/Maia network, Meta DSF + white-box). The "third 10% customer" management hopes for in 2026 is likely a neocloud (Oracle/CoreWeave) — a customer with much weaker pricing power than a Microsoft, where ANET's GM was already pressured (Q4 GM down 80bps YoY due to AI mix [34]).

3. **SONiC is now good enough at the leaf.** Microsoft, Meta, and Google all run SONiC or in-house derivatives. As SONiC enterprise distros (Aviz, Celestica) mature, the EOS-vs-SONiC technical gap closes from "5 years" to "comparable for most workloads." When that gap reaches 0, the >65% gross margin is at structural risk.

4. **Co-packaged optics consolidate around vertically integrated stacks.** Broadcom TH6-Davisson (Oct 2025) and NVIDIA Spectrum-X Photonics (2H 2026) both ship the optics co-packaged with the switch silicon [8][19]. This *helps* ANET as long as Broadcom continues to offer the silicon to systems partners — but it weakens ANET's room to add system-level value, because the optics + ASIC integration is done at the silicon level, not the system level. The system vendor margin compresses toward an ODM-like 25-30% gross margin floor over 3–5 years.

5. **The 1.6T optics shortage will eat 2027 numbers.** McKinsey-cited shortage of 30-40% on 1.6T through 2029 [18] is a hard physical constraint on the units ANET can ship. Bookings keep going up but shipments don't.

**Falsifier for the bear case:** if 2026 GM holds at or above 64% with the AI mix going to 30%+ of revenue, the margin compression thesis is wrong.

## Market view check
At $141.50, 37× forward EPS, ~14× FY26 EV/rev, the market is pricing ANET as a high-quality, durable-growth name with some platform-shift risk — *not* as the unambiguous Ethernet-AI winner. The 22% drawdown from the April $179.80 high after a Q1 beat-and-raise [5] is informative: the market saw the +35% revenue growth and the $3.5B AI target, and *still* compressed the multiple. The implied disagreement is between (a) sell-side $175-181 PTs that extrapolate AI fabric to $5-6B in 2027 at preserved margins, and (b) market-clearing price that haircuts the AI-fabric ramp for share loss to Spectrum-X and gross-margin compression to the AI mix. **My read: the market is closer to right than the sell-side.** ANET is a +10-20%/yr equity from here, not a +30%/yr equity. The 35–40× forward P/E already prices in a successful platform navigation; the asymmetry is to the downside if Spectrum-X share gains continue at the Q1 CY25 pace.

## 90-day falsifiers
- **Q2 2026 earnings (early August):** Does AI fabric run-rate annualize >$3.5B? Does GM hold above 63.5%? Does management add a third 10% customer? Did Spectrum-X take share again (look for management's tone on Meta/Oracle scope).
- **NVIDIA Q2 CY26 networking segment (late August):** If >$2.5B (vs ~$1.46B Q1 CY25 baseline), Spectrum-X is on a $10B run-rate and ANET share narrative is dead.
- **Broadcom CY3Q26 earnings:** Tomahawk 6 ramp commentary. If TH6 lead customer disclosures lean toward ODMs/hyperscalers shipping direct (not via Arista), the merchant-silicon-bypass risk is materializing.
- **OCP Global Summit (October 2026):** ESUN protocol maturity. Real silicon roadmap from Broadcom/Marvell? Or still PowerPoint?
- **CoreWeave or Oracle reaching 10% of ANET revenue:** disclosed in 10-Q. Confirms diversification but at lower-margin customers.
- **Any Microsoft disclosure that Maia 200 scale-up Ethernet displaces Arista TOR in new regions:** Phoenix datacenter coming online; networking vendor mix matters.
- **800G/1.6T transceiver supply readouts from Lumentum and Coherent quarterly calls:** if InP shortage worsens, ANET shipments are physically capped regardless of bookings.

## What I could not verify
- Exact 2025-12-31 close for ANET (sources gave 52-week return and recent prices but not the year-end close needed for a clean YTD figure).
- Whether ANET's Cisco settlement covenant-not-to-sue has been formally extended past 2023 or has lapsed without new litigation; the public record is silent.
- Specific gross margin by product family (AI back-end leaf vs. spine vs. enterprise campus); ANET does not disclose this.
- The *specific* technical reason Meta added Spectrum-X for some clusters while keeping Arista DES for the DSF — the public framing is "dual-sourcing for diversity" but the engineering rationale is opaque.
- ANET's actual share of Tomahawk 6 Davisson CPO designs vs Cisco vs ODMs — Broadcom has not disclosed customer allocation.
- Whether the in-progress NVLink Fusion partnership announcement (March 2026) [4] is a genuine technical integration or a marketing mention.
- The contribution margin of CloudVision software — ANET reports a combined "software and services" line that is not broken out.

## Sources
[1] https://www.arista.com/en/products/7800r4-series — retrieved 2026-05-10 — 7800R4 460 Tbps spine specs, Jericho3-AI silicon
[2] https://www.arista.com/assets/data/pdf/Datasheets/7700R4-Distributed-Etherlink-Switch-Datasheet.pdf — retrieved 2026-05-10 — 7700R4 DES architecture, 27,000+ 800G port scaling
[3] https://stockanalysis.com/stocks/anet/statistics/ — retrieved 2026-05-10 — current price, market cap, forward P/E, EV/Rev, short interest, shares outstanding
[4] https://www.nextplatform.com/connect/2026/05/07/arista-rides-ai-scale-out-networks-moves-into-scale-across-and-awaits-scale-up/5235293 — retrieved 2026-05-10 — Ullal's scale-out/across/up framework, Q1 2026 financials, prepaid commitments doubled
[5] https://www.indmoney.com/us-stocks/arista-networks-inc-share-price-anet — retrieved 2026-05-10 — 52-week high $179.80 (Apr 24, 2026) and low $82.80 (May 7, 2025)
[6] https://www.marketbeat.com/stocks/NYSE/ANET/forecast/ — retrieved 2026-05-10 — analyst consensus PT ~$175-181
[7] https://intellectia.ai/news/stock/aristas-2025-revenue-reliance-on-microsoft-and-meta — retrieved 2026-05-10 — Microsoft 26%, Meta 16% of FY2025 revenue
[8] https://investors.broadcom.com/news-releases/news-release-details/broadcom-ships-tomahawk-6-worlds-first-1024-tbps-switch — retrieved 2026-05-10 — Tomahawk 6 102.4 Tbps shipping June 2025, TH6-Davisson CPO October 2025
[9] https://fintel.io/ss/us/anet — retrieved 2026-05-10 — 17.3M short shares, 1.38% of float
[10] https://www.arista.com/assets/data/pdf/EOSWhitepaper.pdf — retrieved 2026-05-10 — EOS single-binary, multi-process state-sharing, Linux-based architecture
[11] https://blogs.arista.com/blog/cloudvision-the-first-decade-2025 — retrieved 2026-05-10 — CloudVision ~3,000 customer deployments
[12] https://www.fusionww.com/insights/blog/inside-the-ai-bottleneck-cowos-hbm-and-2-3nm-capacity-constraints-through-2027 — retrieved 2026-05-10 — CoWoS-L oversubscribed 2026; HBM3e fully allocated; prices +15-22%
[13] https://infotechlead.com/networking/arista-networks-q1-2026-revenue-surges-35-as-ai-networking-cloud-titans-and-enterprise-demand-drive-growth-95620 — retrieved 2026-05-10 — Q1 2026 $2.71B revenue +35.1%; $3.5B 2026 AI fabric target; $11.5B FY26 guide
[14] https://blogs.arista.com/blog/meta-and-arista-build-ai-at-scale — retrieved 2026-05-10 — Meta 7700R4 DES deployment for DSF / 100K-DPU AI cluster
[15] https://www.opencompute.org/blog/introducing-esun-advancing-ethernet-for-scale-up-ai-infrastructure-at-ocp — retrieved 2026-05-10 — ESUN OCP workstream founding members and scope
[16] https://www.datacenterdynamics.com/en/news/arista-to-pay-cisco-400m-to-settle-patent-lawsuit/ — retrieved 2026-05-10 — Arista paid $400M to Cisco, 2018 settlement, 5-year covenant
[17] https://www.nextplatform.com/2025/06/23/nvidia-passes-cisco-and-rivals-arista-in-datacenter-ethernet-sales/ — retrieved 2026-05-10 — Q1 CY25: ANET $1.48B vs NVIDIA Spectrum-X $1.46B; Spectrum-X +760% YoY
[18] https://iamfabian.substack.com/p/pluggables-power-and-geopolitics — retrieved 2026-05-10 — 800G optics 40-60% short through 2027; 1.6T 30-40% through 2029; Lumentum sole 200G/lane EML at volume
[19] https://www.tomshardware.com/networking/nvidia-outlines-plans-for-using-light-for-communication-between-ai-gpus-by-2026 — retrieved 2026-05-10 — NVIDIA Quantum-X early 2026, Spectrum-X Photonics 2H 2026
[20] https://www.alphaspread.com/security/nyse/anet/qualitative/block/economic-moat — retrieved 2026-05-10 — EOS/CloudVision technical lock-in narrative; merchant-silicon strategy
[21] https://enkiai.com/data-center/liquid-cooling-the-2026-mandate-for-100kw-ai-racks — retrieved 2026-05-10 — 40% of 2027 AI DCs power-constrained; GE Vernova gas turbine ~3-yr lead
[22] https://www.techtarget.com/searchnetworking/news/366537548/SONiC-NOS-faces-challenges-fitting-in-with-mainstream — retrieved 2026-05-10 — SONiC adoption status and EOS competitive positioning; >$5B 2026 SONiC switch revenue projection
[23] https://datacentremagazine.com/news/why-vertivs-new-cooling-is-suitable-for-high-density-data-centre-racks — retrieved 2026-05-10 — Vertiv MegaMod HDX, 50–100+ kW/rack, direct-to-chip 70-75% heat removal
[24] https://investor.nvidia.com/news/press-release-details/2025/NVIDIA-Spectrum-X-Ethernet-Switches-Speed-Up-Networks-for-Meta-and-Oracle/default.aspx — retrieved 2026-05-10 — Meta and Oracle standardize on Spectrum-X (October 2025)
[25] https://www.networkworld.com/article/4130263/cisco-amps-up-silicon-one-line-delivers-new-systems-and-optics-for-ai-networking.html — retrieved 2026-05-10 — Cisco G200 51.2 Tbps, Nexus 9364E-SG2, $600M AI revenue 2× YoY
[26] https://www.sdxcentral.com/analysis/inside-spectrum-x-nvidias-ethernet-networking-platform/ — retrieved 2026-05-10 — xAI Colossus 100k GPU Spectrum-X deployment, 95% effective throughput
[27] https://www.genaitech.net/p/four-strategic-moats-and-a-99-increase — retrieved 2026-05-10 — Celestica Dell'Oro leader AI-network switches and >800G in 2024
[28] https://stordis.com/ultra-ethernet-vs-infiniband-roce-and-tcp/ — retrieved 2026-05-10 — UEC 1.0 specification scope, RDMA over Ethernet, congestion control
[29] https://research.google/pubs/jupiter-evolving-transforming-googles-datacenter-network-via-optical-circuit-switches-and-software-defined-networking/ — retrieved 2026-05-10 — Google Apollo OCS / Jupiter SDN networking <5% of TPU pod capex
[30] https://www.sdxcentral.com/analysis/the-network-engine-behind-aws-massive-rainier-supercluster/ — retrieved 2026-05-10 — AWS EFAv3 12.8 Tbps, in-house multipath transport, Project Rainier 500k Trainium2
[31] https://www.sdxcentral.com/news/microsoft-reveals-maia-200-network-architecture-pushing-scale-up-inference-efficiency/ — retrieved 2026-05-10 — Microsoft Maia 200 custom ATL transport, in-house NIC with packet spraying
[32] https://www.delloro.com/news/ai-back-end-networks-continue-their-shift-to-ethernet-now-accounting-for-over-two-thirds-of-3q-2025-switch-sales-in-ai-clusters/ — retrieved 2026-05-10 — Ethernet >2/3 of AI back-end switch sales by 3Q 2025
[33] https://www.prnewswire.com/news-releases/ethernet-is-winning-the-war-against-infiniband-in-ai-back-end-networks-according-to-delloro-group-302501890.html — retrieved 2026-05-10 — Ethernet expected to surpass InfiniBand by 2027 in AI back-end
[34] https://futurumgroup.com/insights/arista-networks-q4-fy-2025-revenue-beat-on-ai-ethernet-momentum/ — retrieved 2026-05-10 — Q4 2025 non-GAAP GM 63.4% (-80bps YoY) due to AI/cloud titan mix; FY25 GM 64.6%, OM 48.2%