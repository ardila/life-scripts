# VST — Vistra Corp.

## Where this sits in the AI stack
VST is not in the silicon stack — it sits one step before it. Vistra is an independent power producer (IPP) operating ~43.7 GW of dispatchable generation (nuclear, combined-cycle gas, peakers, coal, modest solar/storage) across ERCOT (Texas) and PJM (Mid-Atlantic/Ohio) — the two grids absorbing the bulk of new AI training and inference load [1][2]. The thesis is that AI compute is gated by **electrons before it is gated by GPUs**: a Blackwell rack at 120+ kW is useless without firm power and a working interconnect, and the U.S. cannot build new nuclear or large gas plants on the timeline required by hyperscaler 2027–2030 capex schedules. VST sells two things to that bottleneck: existing operating capacity behind 20-year hyperscaler PPAs, and merchant exposure to PJM/ERCOT capacity prices that are already at administrative caps.

## Snapshot
- **Price:** $153.95 (2026-05-07 close) [3]
- **Market cap:** ~$51.9B (337.18M shares × $153.95; some sources quote $52.4B) [3][4]
- **52-week range:** $133.73 – $219.82 (all-time high $217.32 on 2025-09-22) [3]
- **Forward P/E:** 19.4× on FY consensus [4]
- **EV / NTM EBITDA:** ~9–10× (EV ~$66B incl. Cogentrix debt assumption, on $7.2B 2026E EBITDA midpoint); LTM EV/EBITDA prints at ~12.8× [4][5]
- **Consensus 12-month price target:** $234.09 (+42.4% from spot) [4]
- **YTD 2026 total return:** -4.4% [3]
- **Short interest (% of float):** 3.4% (~11.2M shares as of 2026-04-15) [6]

## Moat — what it is physically made of
The "Vistra moat" is not software, brand, or scale economies in any conventional sense. It is **four physical and regulatory rights** that cannot be re-created in less than a decade, plus locked-in contracts:

**1. Operating nuclear licenses on 6,448 MW.** VST owns Comanche Peak (Texas, 2 units, ~2.4 GW) and Energy Harbor's former PJM fleet — Perry, Davis-Besse, Beaver Valley (~4.0 GW combined) [1]. There are only ~30 firms in the U.S. qualified to operate commercial nuclear, and the NRC's Part 50 licensee list is closed in practice — last greenfield operating license issued was Vogtle 4 (2024). Subsequent license renewals (60→80 years) are administrative for a competent operator and *worthless* without operator capability. Constellation, Vistra, Duke, Southern, and a handful of others are the entire competitive set.

**2. Existing grid interconnect rights with capacity to spare.** PJM's interconnection queue averages 4–5+ years to study completion; ERCOT's "large load" interconnect queue jumped ~300% in 2025 to >233 GW of requests, of which ERCOT itself flags many won't be built [7]. VST's plants are already physically interconnected — that "interconnect option" is increasingly the binding moat. The Permian Basin Power Plant (325→1,185 MW expansion, online Q4 2027) leverages an existing interconnect that no greenfield site could match on timeline [8].

**3. 20-year hyperscaler offtake at premium pricing.** As of Q1 2026, ~3.8 GW is contracted under long-dated PPAs:
- **Meta:** 20-year, 2,176 MW operating + 433 MW uprates from Perry/Davis-Besse/Beaver Valley; deliveries start Dec 2026 (Perry) and Dec 2027 (Davis-Besse) [9][10]
- **AWS:** 20-year, 1,200 MW from Comanche Peak; deliveries Q4 2027 ramping to full by 2032; option to extend +20 years [11][12]
- Plus solar PPAs with Microsoft (Pulaski 405 MW IL) and Amazon (Oak Hill 200 MW TX) [10]

These are **front-of-meter** structures (energy flows through the grid), which neatly sidesteps the FERC rejection of Talen's behind-the-meter Susquehanna ISA [13]. Pricing is undisclosed, but Microsoft's Three Mile Island restart with Constellation prices nuclear at >$100/MWh on a 20-year strip — the implied benchmark [14][15]. By comparison, ERCOT real-time clears at $25–35/MWh on average. The PPAs are a pricing **lift**, not a discount.

**4. Gas turbine "slot rights" via existing fleet.** GE Vernova ended Q1 2026 with a 44 GW backlog and 56 GW in slot reservations; CEO Strazik expects to be sold out through 2030 by end-2026, and Q1 2026 H-class pricing is +10–20% above Q4 2025 levels [16][17]. Mitsubishi and Siemens Energy quote 2028–2030 delivery on new orders [18]. VST's existing 26 GW gas fleet plus the Cogentrix acquisition (5,500 MW PJM/ISO-NE/ERCOT gas, $4B, closing 2H26) [19][20] is effectively an option on a turbine-constrained world.

**What is *not* a moat:** retail brand (TXU Energy is solid, but commoditizable), generic merchant gas (re-creatable in 5–7 years if turbines free up), or any software/IP. Be honest: VST's "AI moat" is permits, licenses, and steel in the ground. That's actually durable — but it's a finite-supply moat, not a scaling one.

## AI buildout bottleneck map
Ranked by what actually gates the next 24 months of frontier AI deployment:

| Bottleneck | Status | VST position |
|---|---|---|
| **Power generation & grid interconnect** | PJM 2026/27 capacity auction cleared at the **administrative cap** of $329.17/MW-day, up from $269.92/MW-day prior year (record) [21][22]. ERCOT projects peak demand from 85 GW today to 152 GW by 2030 (43 GW of net adds needed) [7][23]. | **Direct beneficiary** — both grids, both sides of the meter. |
| **Gas turbines (H-class)** | GE Vernova/MHI/Siemens combined backlog approaching 8-year lead times; ~10 GW of GEV slots remain across 2029–2030 combined [16][18]. | **Beneficiary** — has operating fleet + slots already secured for Permian (860 MW by Q4 2027) [8]. |
| **HBM/CoWoS-L/optical** | Severe through 2026; eases gradually | **Indifferent** — VST sells the input upstream of these. |
| **Liquid cooling at >100 kW/rack** | Constrained | **Indifferent**. |
| **NRC operator capability** | Effectively closed market | **Beneficiary** — already in. |
| **Skilled electrical contractors / 765kV transmission** | Tight; ERCOT building Permian 765kV backbone [7] | **Beneficiary on the gas side, neutral on rest**. |
| **Hyperscaler capex availability** | $600B+ committed for 2026 across the Big 5 [24] | **Exposed customer** — concentration risk on Meta/AWS/Microsoft. |

Net: VST sits on the *supply side* of three of the top five gating bottlenecks and on the *customer side* of one (hyperscaler willingness to keep spending).

## Competitive teardown
This is a small competitive set because the moat is mostly licenses and rights-of-way, not technology.

- **Constellation Energy (CEG)** — the direct comp. ~22 GW of nuclear, including the Microsoft-funded Crane (TMI Unit 1) restart targeting 2028 with $1B DOE loan and $1.6B total budget [14][25][26]. CEG has more nuclear scale and the marquee Microsoft deal; trades richer. CEG already established the >$100/MWh nuclear PPA benchmark, which is **good** for VST's undisclosed Meta/AWS pricing. Where VST wins: more diversified (gas + retail), larger merchant capacity exposure to PJM/ERCOT auctions, ERCOT footprint that CEG lacks.

- **Talen Energy (TLN)** — single-asset concentration on Susquehanna (2.5 GW). Forced by the Nov 2024 FERC rejection of its 480 MW behind-the-meter ISA into a restructured front-of-meter PPA with AWS in June 2025 (17-year, ~$18B, up to 1,920 MW) [13][27][28]. Talen survived the FERC episode but it's a one-trick story; VST has portfolio depth.

- **NRG, Calpine (private), AEP, Dominion** — primarily gas/coal IPPs without VST's nuclear position. Calpine's gas-only fleet competes for PJM/ERCOT capacity payments but has no nuclear premium PPA option.

- **New nuclear (SMRs — NuScale, X-Energy, BWXT, Kairos, Oklo)** — first commercial SMR in the U.S. is unlikely before 2030 at scale; current capex/MWh estimates run $100–$200/MWh installed, often double VST's avoided cost. Real risk is *narrative* compression of VST's premium, not actual displacement on the relevant time horizon.

- **Hyperscaler self-build (Meta data center campuses, AWS in-house generation)** — limited by the same turbine and interconnect constraints. Meta's 2,600 MW Vistra deal exists *because* Meta couldn't self-build to that timeline.

The honest competitive read: **on a 5-year horizon, VST's moat is intact because nobody can build the alternative**. On a 10-year horizon, SMRs + transmission expansion + improved grid interconnect process could erode it. The thesis is therefore time-bounded.

## Bull case — technical
For VST to outperform from $154, the following technical conditions need to hold:

1. **Hyperscaler capex sustains**. Combined Big 5 capex stays north of $600B in 2026 and grows in 2027 [24]. Falsifier: any of the Big 4 cuts capex guidance >10% sequentially.

2. **Inference scaling preserves baseload demand**. Even if FP4/FP8 efficiency cuts joules-per-token, *aggregate* tokens served grows faster (Jevons). Watch model release cadence and inference per-MAU at OpenAI/Anthropic/Google.

3. **PJM/ERCOT capacity prices stay near caps**. The 2027/28 PJM auction (likely July 2026) is the single most important price signal for VST's merchant generation.

4. **Nuclear PPA pricing migrates higher**. Microsoft/Constellation set $100+/MWh; the next round of long-dated nuclear PPAs (including any new VST signings) likely prints $120–150/MWh as scarcity becomes obvious.

5. **Cogentrix integration delivers**. Mid-single-digit FCFE accretion in 2027, high-single-digit by 2027–2029 [19][20]. Adds PJM gas exposure into the highest-priced capacity zone.

6. **6,448 MW nuclear gets uprated ~10%** (~660 MW high-margin capacity) starting early 2030s [29]. This is essentially free incremental EBITDA on already-paid-for assets.

**Base rate caveat:** infrastructure bull cases historically work for 18–36 months and then de-rate as supply catches up. The 1999 telecom buildout, the 2007 coal/gas IPP cycle, and the 2014 frac-sand cycle all show the same pattern — multiples expand on perceived scarcity, then compress when 2-year-lead-time supply arrives. VST's moat is *less* susceptible to this than commodity gas IPPs (because nuclear can't be replicated at all), but the gas piece (~60% of capacity) is.

## Bear case — technical
Written as a short who actually understands the stack:

1. **Inference compute efficiency outruns demand growth.** If FP4 + speculative decoding + MoE sparsity cut frontier-model inference cost 5–10× over 2026–2028 (plausible based on current trajectory), hyperscalers don't need the capacity they signed PPAs for. PPAs are *take-or-pay*, so VST is fine on existing contracts — but **incremental** PPA pricing collapses and the merchant tail re-rates.

2. **The data-center load queue is fictitious.** ERCOT itself has flagged that "many of the large-load projects submitted by utilities may not materialize on time, at full scale, or at all" [7]. If 233 GW of interconnect requests collapses to 60–80 GW realized, gas IPPs over-build, and PJM/ERCOT capacity prices crater post-2027.

3. **FERC removes or raises the cap, but downward.** The current PJM cap is administrative. A new commission could *lower* the cap or restructure capacity market design — there's already political pressure from state regulators about cost shift to retail consumers (BGE/Dominion zones cleared at $466 and $444/MW-day respectively in 2025/26 [22]).

4. **Hyperscaler PPA counterparty discipline.** Meta, AWS, Microsoft have AAA-equivalent credit, but they have also walked away from infrastructure commitments before (Microsoft canceling 2 GW of leases in early 2025 was a real episode). 20-year contracts have material breakage / restructuring risk.

5. **Coal regulatory acceleration.** VST still owns 4,570 MW of coal. Coleto Creek retires 2027 [29]; further accelerated retirement by EPA action loses near-term EBITDA before gas repowers come online.

6. **Cogentrix doesn't close.** $4B deal needs FERC, DOJ/HSR, state approvals [19]. HSR review of consolidation in PJM gas merchant capacity is non-trivial given that Vistra would be the largest U.S. competitive generator.

7. **SMR cost curves bend faster than expected.** Less likely on 5-year view but real on 10-year.

8. **Hedge book exhaustion.** VST is 98% hedged for 2026, 89% for 2027, only 65% for 2028 [30]. The 2028+ open position is real merchant exposure if power curves moderate.

## Market view check
At $154 with 2026E EBITDA midpoint of $7.2B [30] and ~$66B EV (post-Cogentrix), VST trades at ~9× forward EV/EBITDA. Forward P/E is 19×. Consensus PT of $234 implies the Street still sees ~40% upside. The stock is **down 30% from its September 2025 high of $217**, which reflects two things: (1) a broader unwind of the AI-power trade after some hyperscaler capex digestion concerns, and (2) absorption of the Cogentrix deal cost. The current price is essentially saying: *the contracted PPA portfolio is worth roughly what's quoted, but don't pay much for incremental optionality.* That looks too conservative if the 2027/28 PJM auction prints at the cap again and if even 1–2 more nuclear PPAs get signed at $100+/MWh. It looks about right if hyperscaler capex flatlines and inference efficiency does the work.

## 90-day falsifiers
- **PJM 2027/28 base residual auction (expected July 2026):** does it clear at the $329.17 cap again or moderate? A clear of <$250 would be a meaningful bearish signal.
- **Q2 2026 hyperscaler capex prints (late July/early Aug):** Microsoft, Meta, Amazon, Alphabet, Oracle. Watch for any sequential cut >10% or commentary on "demand digestion."
- **Vistra Q2 2026 earnings (early Aug):** any updates to PPA pipeline; commentary on Cogentrix regulatory progress; 2027 hedge book.
- **Cogentrix HSR/FERC progress**: if either agency issues a second request or stalls beyond Q3, deal risk rises.
- **FERC PJM compliance filing on Dec 2025 co-location order:** PJM's filing was due ~February 2026; the substance of the rule (specifically the BTM threshold and the grandfathering scope) determines how much new co-location structure becomes available [31][32].
- **Any new VST hyperscaler PPA announcement:** specifically watch for Google, Oracle, or xAI (none currently a Vistra customer).
- **NRC milestones on TMI/Crane (target 2027 ROD):** delays push out CEG's competitive nuclear supply, marginally helping VST's PPA pricing power.
- **GE Vernova / Mitsubishi Q2 backlog updates:** if 2030 slots fully sell out and 2031 pricing spikes, VST's existing fleet revalues higher.

## What I could not verify
- **Specific $/MWh pricing on the Vistra–Meta and Vistra–AWS PPAs.** Disclosed deal economics (Meta: 20-year, 2,176 MW; AWS: 20-year, 1,200 MW) but no $/MWh. Implied pricing of $100–130/MWh is inferred from the Constellation/Microsoft TMI benchmark, not stated.
- **Whether Vistra has firm GE Vernova or MHI turbine slot reservations** for the Permian buildout, vs. relying on equipment already on order or in inventory. Public disclosures don't specify.
- **Cogentrix purchase-price allocation and accretion mechanics in detail** — the PR cites mid-to-high single-digit FCFE accretion but doesn't break down the underlying capacity-pricing assumptions.
- **VST's actual share of PJM 2025/26 and 2026/27 capacity auction revenue** — known to be material but not separately disclosed by zone.
- **Whether the post-Dec 2025 FERC co-location rules, when they finalize in 2026, expand or contract VST's behind-the-meter optionality at Comanche Peak.** Cumulative effect is unclear given the 3-year transition period.
- **Confidence on ERCOT's 152 GW 2030 peak forecast** — ERCOT itself has cautioned that the underlying large-load submissions may not materialize. The "true" interconnect realization rate is unknown and is the core variable for the bull case.

## Sources
[1] vistracorp.com/generation — retrieved 2026-05-10 — VST generation portfolio breakdown, ~43.7 GW total.
[2] https://en.wikipedia.org/wiki/Vistra_Corp. — retrieved 2026-05-10 — corporate overview, history of Energy Harbor acquisition.
[3] https://finance.yahoo.com/quote/VST/ — retrieved 2026-05-10 — May 7 2026 close $153.95, 52-week range, all-time high September 2025.
[4] https://stockanalysis.com/stocks/vst/statistics/ — retrieved 2026-05-10 — forward P/E 19.4, EV/EBITDA 12.8 LTM, 337.18M shares out.
[5] https://valueinvesting.io/VST/valuation/ev_ebitda-multiples — retrieved 2026-05-10 — EV/EBITDA history quarterly.
[6] https://www.marketbeat.com/stocks/NYSE/VST/short-interest/ — retrieved 2026-05-10 — 11.2M shares short, 3.4% of float.
[7] https://www.utilitydive.com/news/ercots-large-load-queue-jumped-almost-300-last-year-official/808820/ — retrieved 2026-05-10 — ERCOT 233 GW interconnect queue, ERCOT cautions on materialization.
[8] https://www.utilitydive.com/news/vistra-corp-natural-gas-permian-basin-power-plant/761358/ — retrieved 2026-05-10 — Permian Basin 325→1,185 MW expansion, Q4 2027 online.
[9] https://www.world-nuclear-news.org/articles/ppas-support-extended-operations-at-vistra-plants — retrieved 2026-05-10 — Meta 2,176 MW + 433 MW uprate PPA terms.
[10] https://www.ans.org/news/article-7668/the-metavistra-deal-a-closer-look/ — retrieved 2026-05-10 — Meta-Vistra deal mechanics; Pulaski/Oak Hill solar PPAs.
[11] https://www.power-eng.com/nuclear/vistra-secures-long-term-nuclear-ppa-from-comanche-peak-nuclear-plant/ — retrieved 2026-05-10 — Comanche Peak 1,200 MW 20-year PPA.
[12] https://www.publicpower.org/periodical/article/generator-enters-20-year-ppa-supply-power-texas-nuclear-power-plant — retrieved 2026-05-10 — confirms AWS as counterparty, ramp to 2032.
[13] https://www.utilitydive.com/news/ferc-interconnection-isa-talen-amazon-data-center-susquehanna-exelon/731841/ — retrieved 2026-05-10 — FERC 2-1 rejection of Talen-Amazon ISA, Nov 2024.
[14] https://www.utilitydive.com/news/constellation-three-mile-island-nuclear-power-plant-microsoft-data-center-ppa/727652/ — retrieved 2026-05-10 — TMI Unit 1 / Crane 835 MW restart 2028 for Microsoft.
[15] https://introl.com/blog/power-purchase-agreements-ai-data-centers-renewable-energy-strategies — retrieved 2026-05-10 — Microsoft TMI nuclear pricing >$100/MWh.
[16] https://www.power-eng.com/gas/turbines/data-centers-drive-record-surge-in-ge-vernova-power-equipment-orders-as-turbine-slots-tighten-through-2030/ — retrieved 2026-05-10 — GEV 44 GW backlog + 56 GW slot reservations, sold out through 2030 by end-2026, +10–20% pricing.
[17] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — GEV 80 GW backlog stretching to 2029 (pre-Q1 2026 update).
[18] https://www.utilitydive.com/news/mitsubishi-gas-turbine-manufacturing-capacity-expansion-supply-demand/759371/ — retrieved 2026-05-10 — MHI/Siemens 2028–2030 lead times.
[19] https://investor.vistracorp.com/2026-01-05-Vistra-Adds-to-its-Industry-Leading-Generation-Portfolio-with-Acquisition-of-Cogentrix — retrieved 2026-05-10 — $4B Cogentrix deal terms, 5,500 MW gas across PJM/NE/ERCOT.
[20] https://www.utilitydive.com/news/vistra-cogentrix-natural-gas-energy-deal-data-centers/808854/ — retrieved 2026-05-10 — Cogentrix portfolio detail, mid-to-late 2026 close.
[21] https://insidelines.pjm.com/pjm-auction-procures-134311-mw-of-generation-resources-supply-responds-to-price-signal/ — retrieved 2026-05-10 — PJM 2026/27 cleared at $329.17/MW-day cap.
[22] https://www.spglobal.com/energy/en/news-research/latest-news/electric-power/073024-pjm-power-capacity-auction-clears-at-record-high-price-of-26992mw-day-for-most-of-footprint — retrieved 2026-05-10 — PJM 2025/26 $269.92/MW-day, BGE/Dominion zones $466/$444.
[23] https://www.eia.gov/todayinenergy/detail.php?id=65844 — retrieved 2026-05-10 — Texas/Mid-Atlantic demand growth projections.
[24] https://fortune.com/2026/04/30/big-tech-hyperscalers-will-spend-700-billion-on-ai-infrastructure-this-year-with-no-clear-end-in-sight-eye-on-ai/ — retrieved 2026-05-10 — Big 5 hyperscaler 2026 capex >$600B.
[25] https://www.constellationenergy.com/news/2024/Constellation-to-Launch-Crane-Clean-Energy-Center-Restoring-Jobs-and-Carbon-Free-Power-to-The-Grid.html — retrieved 2026-05-10 — Crane Clean Energy Center launch, 2028 target.
[26] https://www.utilitydive.com/news/doe-loan-constellation-crane-nuclear-restart/805923/ — retrieved 2026-05-10 — DOE $1B loan to Crane restart.
[27] https://www.utilitydive.com/news/talen-amazon-aws-susquehanna-nuclear-data-centert/750440/ — retrieved 2026-05-10 — Talen-AWS restructured deal, 1.92 GW, 17-year, $18B.
[28] https://www.theregister.com/2025/06/12/amazon_talen_nuclear_deal/ — retrieved 2026-05-10 — confirms front-of-meter restructure post-FERC.
[29] https://www.powermag.com/vistra-in-talks-to-expand-power-for-data-centers-through-nuclear-gas-options/ — retrieved 2026-05-10 — Coleto Creek retirement 2027, ~10% nuclear uprate potential early 2030s.
[30] https://www.stocktitan.net/news/VST/vistra-reports-first-quarter-2026-3bxu8ev9jw5b.html — retrieved 2026-05-10 — Q1 2026 results, 2026 EBITDA guidance $6.8–$7.6B, hedge book 98%/89%/65%.
[31] https://www.ferc.gov/news-events/news/fact-sheet-ferc-directs-nations-largest-grid-operator-create-new-rules-embrace — retrieved 2026-05-10 — FERC Dec 18 2025 co-location order fact sheet.
[32] https://www.akingump.com/en/insights/blogs/speaking-energy/ferc-clears-the-way-for-co-location — retrieved 2026-05-10 — analysis of new transmission service categories and BTM 3-year transition.