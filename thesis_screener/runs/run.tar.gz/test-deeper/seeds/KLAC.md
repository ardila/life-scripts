All four research agents complete. Composing the dossier now.

# KLAC — KLA Corporation

## Where this sits in the AI stack
KLA sells the **process control** equipment — optical and e-beam inspection, optical CD/film/overlay metrology, mask inspection, and advanced-packaging inspection — that fabs use to find defects and measure dimensions on every wafer at every critical layer of every node. They sit **upstream of the silicon**: their tools enable yield at TSMC N2/N3/A16, Intel 18A, Samsung GAA, and at SK Hynix/Samsung/Micron HBM and TSMC CoWoS-L. They build no chip and ship no compute, but a Blackwell die, an HBM3e stack, and a CoWoS-L interposer all touch ~10–20 KLA tools each at the foundry/OSAT before they reach a server [1][2][7].

## Snapshot
- **Price:** $1,869.19 (2026-05-08 close) [3]
- **Market cap:** $244.2B [3]
- **52-week range:** $696.73 – $1,939.36 [3]
- **Forward P/E:** 35.3× (FY27 consensus EPS) [3]
- **EV / NTM revenue:** ~16× (calculated; not directly published — EV ~$228.6B / annualized Q4 FY26 guide $14.3B run-rate) [3]
- **Consensus 12-month price target:** $1,676–$1,768 (mean ~$1,724) — implies **−6% to −10%** vs. current [3]
- **YTD total return (CY 2026):** +85.5% [3]
- **Short interest (% of float):** 3.04% [3]

Sell-side targets are *below* the spot price after an 85% YTD ripper — the price has run past the analyst pencil. That tension is the central data point of this dossier.

## Moat — what it is physically made of
KLA's moat is not "process control" generically. It is six specific, separately durable assets:

**(1) Broadband plasma optical inspection.** The 29xx and newer **39xx (3935)** patterned-wafer inspectors run a **laser-sustained xenon plasma (LSP) light source** — KLA acquired Energetiq, which holds the bulk of LSP IP — that is the only merchant source bright enough across DUV→VIS→NIR for simultaneous multi-band imaging. That spectral diversity lets BBP separate Cu void vs. embedded particle vs. EUV stochastic microbridge by signature, which a single-wavelength DUV laser inspector physically cannot do. Combined with two decades of TDI-sensor + die-to-database algorithms and per-customer recipe libraries, this delivers ~75–80% share of leading-edge patterned wafer optical inspection [1][8]. Switching cost is months of yield ramp risk per layer per node — not a PO.

**(2) Surfscan / unpatterned wafer inspection.** ~90%+ share, structurally protected for two decades [8].

**(3) Overlay (Archer).** ~70% share. Losing some EUV-coupled layers to **ASML YieldStar** because YieldStar ships co-located with the scanner and shares the recipe stack with Brion OPC, but Archer remains the absolute-precision leader for non-EUV layers [8].

**(4) Advanced-packaging coverage breadth.** **Kronos 1080/1190XR** (patterned bumped/thinned/diced wafers down to ~150 nm), **CIRCL-AP** cluster (all-surface inspection + metrology + review on warped substrates), **ICOS** (incoming/outgoing component). No competitor covers the full HBM/CoWoS bumped-wafer flow; Onto leads at die-level macro, Camtek has Hawk for chiplets, but only KLA does the wafer-level Cu-pillar/µbump/TSV/RDL/hybrid-bonding suite end-to-end [1][2].

**(5) Klarity + ADC software stickiness.** Klarity ACE/SSA/Defect plus customer-trained CNN ADC classifiers run on KLA's specific TDI-sensor PSF and noise model — the trained weights *do not transfer* to a competitor's hardware. Replacing it means re-validating thousands of inspection recipes and recalibrating ADC across a fab's MES — a multi-year project no fab voluntarily undertakes [1].

**(6) R&D + recipe library institutional capital.** $1.36B FY25 R&D (~11% of revenue, sustained), ~15,200 employees, ~12,750 patents filed (~7,400 granted) concentrated in optics/computational imaging [1].

**Real moat vulnerabilities to name explicitly.** (a) **E-beam multi-beam.** KLA's eSL10 is best-in-class single-column; **ASML/HMI eScan 1100 (25-beam, ~15× throughput)** is the first credible production multi-beam inspector, gaining design-ins at TSMC N2 and Samsung GAA pilot lines [1][8]. (b) **Actinic patterned mask inspection.** **Lasertec ACTIS A150/A300** monopolizes 13.5 nm actinic mask inspection; KLA developed APMI, then **shut it down for lack of customer co-funding**. KLA's Teron 670 + 39xx "Print Check" workaround prints to a wafer to inspect — works but slower than direct actinic [1]. (c) **3D-stack OCD ML modeling.** Onto's **Atlas G6 + AI-Diffract** is taking incremental OCD share at customers needing fast 3D regression on buried multi-layer structures (nanosheet stacks, inner-spacer recess) [1][8]. None of these threatens the BBP cash core; each constrains incremental SAM at N2 and below.

## AI buildout bottleneck map
| Bottleneck | KLA position | Evidence |
|---|---|---|
| **CoWoS-L capacity** (TSMC 75k → 130k WPM by late-2026) | **Direct supplier/beneficiary** | KLA AP process control: $635M CY25 → ~$1B CY26 (+57%); +14 ppt advanced WLP share gain in 2025 [4][7] |
| **HBM3e/4 yield (hybrid bonding)** | **Beneficiary of the yield crisis** | Samsung HB-HBM4 reportedly ~10% yield; every yield ramp = more Kronos/CIRCL pulls [4] |
| **Leading-edge logic at N2/A16/18A (GAA + BSPDN)** | **Confirmed structural beneficiary** | KLA-disclosed: GAA = +30% film metrology layers, +50% critical inspection layers vs. FinFET; equipment $/100k WPM rises from $6B → $7B [4] |
| **High-NA EUV** | **Net beneficiary either way** | TSMC deferred HNA (A14/A12/A13 stay Low-NA multi-patterned → more inspection passes); Intel 14A HNA HVM 2027; KLA owns >34% of EUV mask inspection [4][8] |
| **Power / grid (turbines, PJM queues)** | **Indifferent at first order** | GE Vernova 80GW backlog to 2029 doesn't constrain fab tool installs [4] |
| **Optical interconnect / liquid cooling** | **Indifferent** | No tool exposure |
| **Compiler/kernel talent** | **Indifferent** | No exposure |
| **Silicon photonics / TSMC COUPE** | **Emerging beneficiary** | COUPE volume 2026 on 12-inch 65nm SiPh; CIRCL-AP + Zeta 3D profilers extend into PIC inspection; smaller dollar magnitude than HBM/CoWoS [4] |

KLA is leveraged to **fab capex, which lags hyperscaler capex by ~12 months**. Aggregate hyperscaler 2026 capex ~$700–725B (+64% YoY) is already inflecting [4]; the implied 2027 WFE tape is strong.

## Competitive teardown
**Applied Materials (PDC).** Has *lost* share across most inspection sub-segments four years running. **SEMVision H20** (Feb 2025, cold-field-emission column, +50% resolution, 10× imaging speed) is a credible defect-review tool but not a high-throughput inline inspector [1][8]. No evidence AMAT closes the gap on optical patterned inspection.

**ASML.** Strategic bundle of YieldStar overlay + HMI multi-beam e-beam + Brion computational litho around the EUV monopoly. **HMI eScan 1100** is the real credible threat — multi-beam e-beam at 15× single-beam throughput, design-ins at TSMC N2 and Samsung GAA [1][8]. ASML has *not* built a patterned-wafer optical inspector and shows no signs of doing so. KLA's BBP fortress is uncontested.

**Hitachi High-Tech.** Holds **65–70% of CD-SEM** structurally; KLA exited that fight years ago. New **GT2000** for HNA-EUV-generation metrology launched 2024. Adjacent expansion (LS9300AD into bare wafer) is plausible but slow [8].

**Onto Innovation.** Real competitor on two axes: **macro defect inspection** (~50%+ share with Dragonfly G3, vs. KLA ~30%) and **OCD** (~25–30% share, gaining at advanced packaging). Signed >$240M HBM volume PA through 2027 [8]. KLA's wafer-level bump metrology + overlay still wins the leading-edge AP slice; Onto wins the die-level macro slice.

**Lasertec.** Effective monopoly in EUV mask blank actinic (ABICS) and growing in actinic patterned (ACTIS). Two overhangs: METI export controls on China sales (since Jul 2023), and the **Scorpion Capital short report (Jun 2024, 334 pages)** alleging accounting fraud [8]. Core monopoly intact; this constrains KLA's mask-inspection SAM, not its core cash flow.

**China indigenous (Skyverse, SiCarrier, Yitang, RSIC, AMIES).** Per CFR Nov 2025 testimony, **U.S./allied vendors retain ~100% share of leading-edge process control sold into China** — PC is the **single hardest WFE segment to indigenize**. Sensor IP, custom illumination, and recipe libraries are ~5–10 year replication tasks at minimum [8].

**Base rate.** Process control has been winner-take-most for ~30 years (KLA-Tencor merger 1997). Lasertec took ~10 years to consolidate the EUV mask blank monopoly. Onto's gains in OCD/macro have taken ~7 years post the Rudolph + Nanometrics merger. **Displacement in this segment runs in 5–10 year cycles, not quarters.**

## Bull case — technical
For KLAC to compound from here, three technical conditions must hold:

1. **GAA/CFET intensity scales as advertised.** The +30%/+50% layer-count claim translates to PC dollars/wafer rising ~17% per node transition; this should hold through 2nm and into 1.4nm/A14 because the fundamental defect-mode count rises with stack height and EUV pitch [4]. **Base rate: PC intensity has risen every node since 28nm.**
2. **Hybrid bonding at HBM4 stays hard for 2+ years.** The Samsung HB-HBM4 ~10% yield issue persists across vendors [4]; CIRCL/Kronos pulls keep growing >25% CAGR. SK Hynix's MR-MUF discipline is the only thing preventing an inspection bonanza, and even MR-MUF requires KLA tools.
3. **Multi-beam e-beam stays a niche, not a wedge into BBP optical.** ASML/HMI takes share within e-beam but cannot displace BBP for optical-domain defects (which are most defects). KLA's own multi-beam roadmap (eSL15+) closes the gap before it costs them an HVM design-in at A14.

If all three hold, **WFE cycles to ~$155–170B in 2027**, KLA grows revenue mid-teens, and the AP segment doubles again to ~$2B. The technical setup is favorable; the *price* is the challenge (see Market view).

## Bear case — technical
Four technical conditions that would damage the thesis, written as a short-seller who reads the stack would write them:

1. **The 85% YTD move has front-run the cycle.** Q3 FY26 already saw Patterning −3% YoY [3] — the early sign of segment-level digestion. WFE cycles peak when intensity narratives go vertical; KLA's 39xx-era pricing power is well-known and may already be in the ~$3.575B Q4 guide.
2. **Multi-beam e-beam compounds at GAA.** GAA's voltage-contrast inspection requirement scales e-beam throughput as the binding constraint. If HMI eScan 1100 wins TSMC N2 production-grade slots and Samsung GAA pilots, KLA loses the *next-node* roadmap conversation, not just one tool category. This is the single highest-impact technical risk.
3. **China revenue cliff.** China is **24% of Q3 FY26 revenue** [3]. Further BIS/Bureau of Industry & Security tightening — particularly on optical inspection — could remove 10–15 ppt of revenue with limited short-term replacement.
4. **Onto + Lasertec take the AP and mask growth slices.** If Onto's HBM volume PA ($240M+ through 2027) compounds and Lasertec's actinic monopoly extends into the patterned mask layers, KLA's incremental AP/mask SAM at N2/A14 is materially smaller than the bull case implies. Importantly, KLA still owns BBP/Surfscan/Archer cash flows — but the *growth narrative* compresses, and 35× forward P/E does not survive a growth-narrative compression.

## Market view check
KLAC at $1,869 / 35× forward / +85% YTD with consensus median PT *below* spot ($1,724) is the textbook look of a high-quality compounder where the buy-side has run past the sell-side on the AP/HBM intensity narrative. The market is pricing in: (a) WFE >$140B in 2026 with a $155B+ 2027 setup; (b) AP segment doubling to ~$2B; (c) GAA layer-count benefit fully captured; (d) no meaningful China cliff. Each of those is *defensible*, but they are largely already in the multiple. The historical KLAC mid-cycle forward P/E has run ~18–22×; current 35× embeds either (i) permanent structural re-rating because PC is the highest-leverage AI buildout exposure, or (ii) cyclical peak. Inference (not from a cited source): the market has correctly identified the technical reality; the disagreement is on whether 35× is a fair price for that reality. **My read: the thesis is right and the price is full** — long-term holders win on compounding, but new money entering at 35× has limited margin of safety against a cyclical pause.

## 90-day falsifiers
- **TSMC July 2026 capex update**: if 2026 capex is cut from $52–56B guidance to <$50B (10%+ cut), the AP/leading-edge tailwind narrative weakens.
- **KLA Q4 FY26 print (late July 2026)**: Patterning segment second sequential decline (>−5% YoY), or AP CY26 revenue guide held flat at ~$1B (vs. potential raise to $1.1B+), would signal AP intensity narrative is mature.
- **ASML Q2 2026 print**: HMI inspection bookings line item — if HMI inspection grows >40% YoY, multi-beam e-beam wedge is real and accelerating.
- **Samsung HBM4 NVIDIA qualification**: if Samsung qualifies HB-HBM4 in Q3 2026, hybrid-bonding yield improvement reduces inspection intensity per stack (bear).
- **BIS rule update**: any expansion of US export controls on optical inspection to China (currently lighter than on litho/etch) — would directly hit KLA's 24% China revenue.
- **MLPerf June 2026 round** (less direct, but signals hyperscaler buying tempo) — if accelerator vendor diversity increases, foundry capex resilience is stronger.

## What I could not verify
- **Exact KLA content $/CoWoS-L interposer** and $/HBM stack — only blended segment numbers are disclosed; the per-package math is industry inference, not company disclosure.
- **eScan 1100 actual production-grade design-in count at TSMC/Samsung** — referenced in trade press, but no public unit-shipment data.
- **Samsung HB-HBM4 ~10% yield** — Tom's Hardware/TrendForce reporting, not Samsung-confirmed; could be stale or wrong by Q3 2026.
- **EV/NTM revenue 16×** — calculated by me from Q4 guide annualization; no consensus published EV/NTM revenue figure was found.
- **Specific KLA multi-beam roadmap timing (eSL15+)** — KLA does not publicly disclose; I could not find a credible leak with date specificity.
- **OCD share at N2 specifically** (vs. blended) — Castellano/SemiAnalysis claim KLA is gaining vs. Onto at leading-edge logic, but no granular share figure is published.
- **Hyperscaler capex → fab capex 12-month lag** — referenced as conventional wisdom; the empirical lag distribution from 2018–2024 was not directly verified in this research pass.

## Sources
[1] KLA Corporation — Q3 FY26 Shareholder Letter & technical product portfolio pages (Energetiq LSP, eSL10, Teron, SpectraShape, Kronos/CIRCL/ICOS, Klarity) — https://ir.kla.com/news-events/press-releases/detail/514/kla-corporation-reports-fiscal-2026-third-quarter-results and https://www.kla.com/products — retrieved 2026-05-10 — established product taxonomy, FY26 financial milestones, advanced-packaging revenue trajectory, R&D intensity.
[2] KLA Advanced Packaging Portfolio Overview (PDF) — https://www.kla.com/wp-content/uploads/Advanced_Packaging_Portfolio_Overview.pdf — retrieved 2026-05-10 — established Kronos/CIRCL/ICOS coverage of HBM/CoWoS flows.
[3] Financial market data — Yahoo Finance / stockanalysis.com / GuruFocus / TIKR / MarketBeat / TipRanks / financecharts.com / Investing.com Q3 FY26 slides — retrieved 2026-05-10 — established price, market cap, multiples, consensus PT, YTD return, short interest, segment mix, China geographic share.
[4] AI buildout / WFE intensity / capacity sources — TrendForce, FinancialContent, SemiWiki on TSMC CoWoS 75k → 130k WPM; Tom's Hardware / TrendForce on Samsung HB-HBM4 ~10% yield; 36Kr / SemiAnalysis on GAA +30% metrology / +50% inspection layers; TrendForce on TSMC HNA deferral and COUPE; Futurum / Tunguz on 2026 hyperscaler capex; KLA Q3 FY26 transcript on $140B+ WFE outlook — retrieved 2026-05-10 — established bottleneck specifics.
[5] Energetiq LSP source / EUV Litho Workshop S63 (2017) — https://www.euvlitho.com/2017/S63.pdf — retrieved 2026-05-10 — established LSP technical baseline (xenon plasma, brightness, lifetime).
[6] SemiAnalysis — "How Onto Innovation Is Gaining Market Share From KLA" — https://semianalysis.com/2022/09/06/how-onto-innovation-is-gaining-market/ — retrieved 2026-05-10 — established Onto OCD/macro share dynamics and GAA modeling claims.
[7] KLA Q3 FY26 earnings call transcript (Motley Fool) — https://www.fool.com/earnings/call-transcripts/2026/04/29/kla-klac-q3-2026-earnings-call-transcript/ — retrieved 2026-05-10 — established CY26 advanced packaging $1B raise, +14 ppt WLP share gain, $140B WFE outlook, 58% PC share.
[8] Competitive landscape sources — Castellano Substack on PC market share; ASML eScan 1100 / YieldStar product pages; Lasertec ABICS/MATRICS/ACTIS coverage and Scorpion Capital short report (Fortune, HBS case); Hitachi GT2000; Onto Atlas G6 + Q4 2025 results; AMAT SEMVision H20; CFR Nov 2025 testimony on China indigenous PC; CSET / American Affairs on Skyverse/SiCarrier/Yitang — retrieved 2026-05-10 — established sub-segment shares, competitor product specifications, and China indigenization status.