I have enough material. Let me write the dossier.

# AAPL — Apple Inc.

## Where this sits in the AI stack
Apple's AI position sits at the **edge-inference + integrated client device** layer, not the frontier-training layer. The hardware is A-series and M-series silicon — Apple10 GPU architecture with per-core Neural Accelerators, a 16-core Neural Engine at ~45 TOPS, and unified LPDDR5X memory — running a ~3B-parameter quantized on-device foundation model (AFM), with overflow to Apple-controlled Private Cloud Compute (PCC) servers built from the same M-series silicon [1][2][6]. Apple does **not** train frontier models on its own infrastructure: AFM is pre-trained on Google TPU v4/v5p slices via JAX/AXLearn [4], and Apple is paying Google ~$1B/yr to license a custom Gemini model as the brain of the redesigned Siri shipping in iOS 26.4 [12]. The workload Apple owns is real-time, latency- and privacy-sensitive consumer inference distributed across ~2.5B active devices [21]; the workload it rents is everything else.

## Snapshot
- **Price:** $293.86 (2026-05-08 close) [1]
- **Market cap:** $4.31T [1]
- **52-week range:** ~$169 – $294 [13]
- **Forward P/E:** ~34.6× (FY26 consensus EPS $8.50; trailing P/E 32.9×) [14]
- **EV / NTM revenue:** ~9.0× ($4.31T mkt cap – $62B net cash ÷ ~$470B implied NTM revenue from current run-rate + guide [10][19])
- **Consensus 12-month price target:** $303.39 (implied +3.2% from price; 27 analysts, "Buy") [14]
- **YTD total return:** n/a — sources did not surface a clean YTD figure; market cap rose ~13% in the trailing 30 days alone [1], suggesting a strongly positive YTD on the post-Q2 print
- **Short interest (% of float):** n/a — recent absolute number not surfaced in search; historically <1% and not a sentiment signal at this size

## Moat — what it is physically made of
The popular thesis ("CUDA-like switching costs") is wrong about Apple. Apple's moat is **not** in the AI stack; it is in the device platform on top of which AI features ship. Decomposed:

**1. Manufacturing / advanced packaging access (high durability, 5–7 years).** Apple has reserved ≥50% of TSMC's N2 (2nm) capacity for 2026 — the A20 ("Borneo"/"Borneo Ultra") in iPhone 18, M6 in MacBooks, and R2 in the Vision Pro refresh all sit on N2 [9]. Critically, Apple is also transitioning from InFO to **WMCM (Wafer-Level Multi-Chip Module) packaging** for A20, with a dedicated line at TSMC's Chiayi P1 ramping from 10k wafers/mo at launch toward ~60k by year-end and ~120k in 2027 [22]. WMCM puts CPU/GPU/memory/I/O dies on a shared RDL at wafer level — higher interconnect density and better thermals than InFO. For server chips (Baltra, see below), Apple uses **TSMC SoIC** for 3D die stacking [22]. No other smartphone OEM has comparable allocation or process-node priority; this is a 2–3 year structural lead at the silicon layer.

**2. Vertically integrated silicon → OS → app stack.** Apple ships its own ISA-extended cores, its own Neural Engine, its own Metal/MPS/CoreML/MLX runtime, and its own OS. Competitors must compose Snapdragon + Android + TensorFlow Lite / LiteRT + Play Store across vendors who don't co-design [16]. The MLX framework (open-source, ~30k GitHub stars) was specifically extended in October 2025 to expose the per-GPU-core Neural Accelerators on M5 via matrix-multiply primitives [15] — that puts on-device LLM throughput meaningfully above Snapdragon NPU-targeted LiteRT for the same model size. But MLX is roughly **two orders of magnitude smaller than CUDA's developer ecosystem** and is irrelevant for training; this part of the moat is real for client inference, weak everywhere else.

**3. Installed-base lock-in.** 2.5B active devices, 1.15B paid subscriptions, ~$174 revenue/device/year ($129 product + $45 services) [21]. Services posted a 76.7% gross margin in Q2'26 [19] — that is the moat in $ form. AI features are now a switching-cost lever: an iPhone user with on-device transcription, visual intelligence, and a Siri Extensions stack (Claude/Gemini/ChatGPT pluggable from iOS 27 [12]) loses optionality moving to Android.

**4. Brand and price-power.** 49.3% blended gross margin at the corporate level [19] is unmatched in consumer electronics. iPhone 17 cycle drove +22% iPhone revenue YoY in the March quarter [19]; pricing held through the tariff cycle [20].

**5. What is NOT the moat.** Foundation models (rented from Google), training infrastructure (rented from Google), agentic-AI software (deferred / outsourced via Extensions). Apple has effectively admitted via the Gemini deal that it cannot build a frontier model competitive with Google/OpenAI/Anthropic on its own timeline, and the original "merge Siri with new AI" architecture failed internal testing at ~30% incorrect responses, forcing a full LLM rebuild under Mike Rockwell after Giannandrea was removed [11].

**Base rate on displacement.** Mobile-OS duopolies have been remarkably durable: Apple's iPhone-era moat is now ~17 years old; Microsoft Office's productivity moat is ~30 years and still intact; Intel's x86 moat survived 25+ years before ARM cracked it in mobile (and Intel still dominates desktop x86). The base rate for displacing an installed base of 2.5B devices over a 24-month horizon is ~zero. The realistic risk is **margin compression**, not displacement.

## AI buildout bottleneck map
Constraint-by-constraint, where Apple sits:

- **Power / grid interconnect** (hyperscaler-critical, turbine backlogs 4–6 quarters): **indifferent.** Apple's total capex is ~$13–14B/yr [10] versus hyperscaler 2026 capex of $600–830B [10]. Apple is not building gigawatt campuses. PCC's Houston facility is small by AI-DC standards.
- **CoWoS-L advanced packaging** (NVIDIA-critical): **indifferent / indirect**. Apple uses InFO→WMCM and SoIC, distinct packaging lines [22]. Apple's allocation does not compete with NVIDIA's CoWoS-L pool.
- **HBM3e / HBM4 supply** (NVIDIA/AMD/cloud TPU bottleneck): **indifferent.** Apple's unified-memory architecture uses LPDDR5X, not HBM. M-series Ultras may eventually need HBM-class bandwidth, but not in the 24-month window.
- **TSMC N2 wafer capacity:** **constraint owner.** Apple has the lead reservation [9]; competitors get residual.
- **Optical / NVLink-class fabric:** **not exposed.** Apple's PCC clusters are not scale-out training fabrics.
- **Liquid cooling >100kW/rack:** **not exposed** (PCC racks are not Blackwell-class density).
- **Kernel / compiler talent:** **moderately exposed.** MLX team is small (~dozens); the Siri rebuild required a full team reorg under Rockwell/Federighi, and AI leadership turned over (Giannandrea retiring spring 2026) [11].
- **Training data quality at the frontier:** **not exposed directly** (Apple is not at the frontier), but **exposed indirectly** because Apple's product quality now depends on whoever's model it licenses (Google).

Net: Apple is largely **insulated** from the AI capex bottlenecks that gate NVIDIA/AMD/hyperscalers, which is why its capital intensity stays low and margins stay high. The trade-off is that Apple is **also not a beneficiary** of the buildout — it captures none of the $600B+ flowing into 2026 AI infrastructure [10].

## Competitive teardown

| Competitor | Axis | Evidence | Apple's gap |
|---|---|---|---|
| **Google (Pixel + Gemini + TPU)** | Full-stack including frontier model; smart-glasses partnership pipeline | Google's TPUv5p trained Apple's own foundation models [4]; Google now powering Siri's reasoning via $1B/yr custom Gemini [12] | Apple owns the device; Google owns the intelligence layer behind it. Asymmetric dependence. |
| **Qualcomm + Samsung (Snapdragon 8 Elite Gen 4)** | Edge NPU performance | Hexagon NPU +45% gen-over-gen, 3nm, multimodal on-device [16]; Galaxy S25 Geekbench MT ~10k vs A18 ~8k | Apple's edge: full-stack co-design, unified memory, MLX. Qualcomm's edge: raw NPU throughput on some workloads. Effective parity on benchmarks, Apple ahead on developer integration. |
| **Meta (Ray-Ban + Orion)** | Smart-glasses form factor | 7M units sold 2025, ~82% market share, $800 Ray-Ban Display already shipping in-lens screen [23] | Apple's N50 glasses (4 designs in testing) ships H2'26 [23]; Meta has a 2-year head start in the form factor most likely to be the next AI primary endpoint. **This is the most credible Apple-erosion path.** |
| **Huawei (Kirin + HarmonyOS + Mate 80 / Pura X foldable)** | iPhone substitute in China | Q1'26 China share: Huawei 19.8% vs Apple 18.9% [17] — Huawei #1 for first time in 5 years; Apple still grew 33.3% YoY off the iPhone 17 cycle [17] | China-specific; HarmonyOS is structurally locked out of the West. Margin/mix risk, not existential. |
| **OpenAI / Anthropic** | Agentic AI consumer surface | OpenAI's hardware (Jony Ive collab, Broadcom chips) and ChatGPT app strength; Anthropic walked away from Siri deal over pricing [12] | Apple controls the OS surface; OpenAI controls the killer app. The Extensions architecture in iOS 27 [12] is Apple conceding the model layer to keep the platform layer. |

The pattern: Apple has parity-to-lead on **device + edge silicon + ecosystem**, and is openly behind on **frontier models + agentic intelligence**. Its mitigation is to commoditize the model layer (Extensions / multi-vendor) so no single AI partner gains structural leverage over the device.

## Bull case — technical
1. **Edge inference becomes the dominant AI workload by volume.** Privacy regulation, latency, and cost-per-token economics push more inference to the device. Apple's per-core GPU Neural Accelerators + WMCM packaging + unified memory architecture is a 2-year hardware lead and compounding (N2 in 2026, N2P in 2027) [9][22]. If 20%+ of AI-tokens-generated globally shift to on-device within 36 months, Apple is the largest beneficiary by volume.
2. **Installed-base AI monetization.** Apple Intelligence becomes a paid tier ("Apple Intelligence+" at $9.99–$19.99/mo) layered onto 1.15B paid subscriptions. At 30% attach on the premium iPhone base (~300M users) × $15/mo, that's ~$54B incremental services revenue at ~75% gross margin — a re-rating event.
3. **Siri-LLM ships in spring 2026 (iOS 26.4) and works.** Federighi's quote — "a much bigger upgrade than what we envisioned" [11] — is testable in 60 days. Successful launch closes the perception gap with Gemini/ChatGPT.
4. **Smart glasses launch H2'26 with iPhone-tethered Siri** captures form-factor share from Meta before Meta extends its display advantage [23].
5. **N2 allocation becomes a moat in itself.** Competitors stuck on N3P until 2027 face a one-node performance/power deficit during the AI-features-as-differentiator cycle.

Connect to financials: if Apple Intelligence drives an iPhone replacement supercycle (Q2'26 iPhone +22% YoY is already evidence [19]) AND services attaches a paid AI tier, EPS could compound at 15–18%/yr through FY28 vs. consensus ~9–10%. The multiple holds at ~34× because services mix increases.

**Base rate caveat:** Apple replacement cycles have lengthened from ~2.5 to ~4+ years over the past decade. A genuine supercycle requires the feature set to actually deliver, which the failed Siri launch in 2024–25 specifically undermined.

## Bear case — technical
1. **Apple is now structurally a model renter, not a model owner.** Paying Google $1B/yr for Gemini is a public admission [12]. If frontier intelligence is where the consumer value accrues — and the Gemini/Claude/GPT-5+ trajectory keeps widening the gap from AFM-3B — Apple is paying margin to its competitor to keep its OS relevant. Anthropic's billion-dollar+ demands and Apple killing that deal [12] suggests Apple cannot price-match what the model layer is actually worth.
2. **Smart glasses are the next platform and Meta won the start.** Meta sold 7M Ray-Bans in 2025 and holds 82% share [23]. If glasses become the primary AI endpoint by 2028, Apple is the next Nokia in a category it didn't define. Vision Pro is already effectively shelved [23].
3. **Edge inference advantage erodes faster than expected.** Snapdragon 8 Elite Gen 5 (2026 flagship cycle) closes the NPU gap [16]. Google's Tensor + Gemini Nano integration on Pixel is also tight. If Android OEMs ship comparable on-device LLM UX, Apple's silicon edge becomes a benchmark trivia point, not a buying reason.
4. **Regulatory take of services revenue.** US Supreme Court declined to block external-link payments; EU DMA non-compliance fine €500M plus Core Technology Commission restructure [18]. Estimated $2–4B annual hit to App Store commission [18] is small versus $124B services revenue but compresses the **incremental** services growth that justifies the multiple.
5. **Tariffs + India transition costs.** India production runs ~5–8% above China cost, partly offset by lower 10% tariff vs ≤30% from China [20]. Q2'26 gross margin guide of 47.5–48.5% (down from 49.3%) explicitly cites higher memory costs [19] — the gross margin direction is **down**, not up, in the very next quarter.
6. **The Q2'26 iPhone print may be a pull-forward.** +22% iPhone YoY against an unusual base (iPhone Air launch, Apple Intelligence rollout, tariff pre-buy) sets a difficult comp. If FY27 iPhone reverts to mid-single-digit, the supercycle narrative dies and the multiple compresses.

**Base rate caveat:** Brand-driven moats with 2.5B installed devices and 76% services gross margin do not collapse in 24 months. The bear case is **multiple compression to ~25× and 5–10% EPS growth**, not a structural break.

## Market view check
At $293.86 and a market cap of $4.31T, AAPL trades at ~34× forward EPS — roughly 1.7× its 10-year median, and at a premium to MSFT (~32×) and GOOGL (~22×) despite materially weaker AI training/infrastructure positioning. Consensus 12-month PT is $303 — **+3% implied** — meaning the sell-side is at "hold" in price-target terms while keeping "Buy" ratings on momentum. The market is paying a frontier-AI multiple for a company whose AI strategy is to **rent the brains and own the eyeballs**. That is logically defensible (the eyeballs are where margin accrues) but it requires Siri-LLM to ship and Apple Intelligence as a paid tier to monetize. The market is not discounting either of those failing. Net: price reflects best-case execution; downside skew if Siri-LLM slips again or smart glasses underwhelm.

## 90-day falsifiers
- **iOS 26.4 / Siri-LLM ships and reviewers benchmark it within 15% of Gemini Live on standard task suites.** Confirms bull thesis. (Apple targeted spring 2026 [11]; slip past WWDC25 = bear signal.)
- **WWDC 2026 (June) announces a paid Apple Intelligence tier with disclosed pricing.** Confirms services monetization path. Absence = bear.
- **Q3 FY26 print (early August): iPhone revenue growth ≤ +5% YoY** would invalidate the supercycle narrative built on Q2's +22%.
- **Q3 FY26 gross margin: below 47.5% (low end of guide)** would confirm the tariff/memory cost headwind is structural rather than transient.
- **Smart-glasses unveil at September event with shipping date and price within $100 of Ray-Ban Display ($800).** Catch-up signal. No mention = ceding the form factor.
- **Baltra (custom AI server chip) tape-out / production confirmation from Broadcom or Apple** by end of CY26 H2 [7]. Slip = continued dependence on M-series for PCC scale.
- **TSMC quarterly call confirms Apple takes ≥50% of N2 wafer starts** through 2026 [9]. Slip = ceding the process-node lead.
- **China Q3 share data: Apple vs. Huawei share gap >300bps** in Huawei's favor would signal real share loss, not just normal cycling.

## What I could not verify
- **Precise short interest % of float** for AAPL as of the May 2026 print. Historically immaterial (<1%), but not confirmed in this research.
- **Specific YTD total return for 2026.** Only trailing 30-day market-cap delta (+13%) and trailing 12-month (~+45%) surfaced.
- **Exact Apple capex run-rate for FY26.** A $3.46B June-quarter capex number was cited [10] but annualized FY26 guidance was not pinned down.
- **Actual benchmark performance of Siri-LLM vs Gemini Live / ChatGPT Advanced Voice.** Apple has not released, and external reviewers have not measured.
- **PCC server fleet size / token throughput.** Apple discloses architecture [2] but not capacity. Cannot size Apple's actual inference compute against, e.g., OpenAI's reported deployments.
- **Baltra die size, perf/W, or comparison vs. NVIDIA H200 / Google TPU v6** — only that it exists, is TSMC N3E, uses Broadcom networking IP, and targets inference [7].
- **Net economic value of the Gemini $1B/yr deal** — whether Apple gets exclusivity on the Gemini variant, whether Apple captures any of the consumer-paid AI revenue, or whether it is pure license cost.
- **Whether Apple plans HBM in M-series Ultra by 2027** for training-class workloads. Architecturally rumored, not confirmed.
- **Smart-glasses unit cost / margin profile** vs. iPhone — material for the 2027 mix narrative.

## Sources
[1] https://capital.com/en-int/markets/shares/apple-inc-share-price/market-cap — retrieved 2026-05-10 — established AAPL May 8–9 2026 close ($293.86) and ~$4.31T market cap
[2] https://security.apple.com/blog/private-cloud-compute/ — retrieved 2026-05-10 — Apple's primary technical description of PCC architecture (Secure Enclave, hardened OS, narrow attack surface)
[3] https://9to5mac.com/2026/02/17/apple-plans-m5-based-private-cloud-compute-architecture-for-apple-intelligence/ — retrieved 2026-05-10 — established M5-based J226C model running PCC
[4] https://machinelearning.apple.com/research/introducing-apple-foundation-models — retrieved 2026-05-10 — Apple's primary source: AFM trained on TPU v4 (8192 chips, server) and v5p (2048 chips, on-device) using AXLearn/JAX
[5] https://www.tomshardware.com/desktops/servers/apples-houston-built-ai-servers-now-shipping — retrieved 2026-05-10 — Houston PCC server production
[6] https://www.apple.com/newsroom/2025/10/apple-unleashes-m5-the-next-big-leap-in-ai-performance-for-apple-silicon/ — retrieved 2026-05-10 — M5: 16-core Neural Engine, per-GPU-core Neural Accelerators, 4x peak GPU AI compute vs M4
[7] https://www.theregister.com/2024/12/12/apple_ai_chip_broadcom/ — retrieved 2026-05-10 — Baltra AI server chip codename, Broadcom networking partnership, 2026 mass production
[8] https://wccftech.com/apples-ai-server-chip-baltra-likely-to-be-used-primarily-for-ai-inference/ — retrieved 2026-05-10 — Baltra targeted at inference workloads, TSMC N3E
[9] https://technode.com/2025/09/21/apple-secures-over-half-of-tsmcs-2nm-2026-capacity-adopts-advanced-wmcm-packaging/ — retrieved 2026-05-10 — Apple ≥50% N2 reservation; WMCM adoption for A20
[10] https://introl.com/blog/hyperscaler-capex-600b-2026-ai-infrastructure-debt-january-2026 — retrieved 2026-05-10 — 2026 hyperscaler capex $600B+ baseline; Apple capex June quarter $3.46B
[11] https://www.macrumors.com/guide/llm-siri/ — retrieved 2026-05-10 — Siri-LLM rebuild after ~30% failure rate; Giannandrea removed, Rockwell+Federighi leading; iOS 26.4 spring 2026 target
[12] https://techcrunch.com/2026/01/12/googles-gemini-to-power-apples-ai-features-like-siri/ — retrieved 2026-05-10 — $1B/yr Google Gemini deal for Siri; OpenAI/Anthropic alternatives evaluated; iOS 27 Extensions for Claude/Gemini/ChatGPT
[13] https://stockanalysis.com/stocks/aapl/forecast/ — retrieved 2026-05-10 — 52-week range and analyst consensus context
[14] https://www.marketbeat.com/stocks/NASDAQ/AAPL/forecast/ — retrieved 2026-05-10 — 27 analysts, "Buy" rating, $303.39 PT, FY26 EPS $8.50 consensus
[15] https://machinelearning.apple.com/research/exploring-llms-mlx-m5 — retrieved 2026-05-10 — MLX exposes M5 GPU Neural Accelerators for on-device LLM matmul
[16] https://www.androidheadlines.com/qualcomm-snapdragon-8-elite — retrieved 2026-05-10 — Snapdragon 8 Elite NPU specs, 3nm, +45% NPU gen-over-gen
[17] https://counterpointresearch.com/en/insights/china-smartphone-market-q1-2026 — retrieved 2026-05-10 — Q1'26 China share: Huawei 19.8%, Apple 18.9% (+33.3% YoY)
[18] https://blog.funnelfox.com/apple-app-store-fees-2026-eu-dma/ — retrieved 2026-05-10 — EU DMA non-compliance €500M fine; Core Technology Commission restructure Jan 2026
[19] https://www.macrumors.com/2026/04/30/apple-2q-2026-earnings/ — retrieved 2026-05-10 — Q2'26: Rev $111.2B (+17%), iPhone $58B (+22%), Services $31B, GM 49.3%, June-quarter GM guide 47.5–48.5%
[20] https://appleinsider.com/articles/26/03/12/india-is-considering-more-incentives-to-capture-a-larger-share-of-iphone-production — retrieved 2026-05-10 — India ~25% of global iPhone production, 32% target by FY27, 5–8% cost premium, 10% vs ≤30% tariff differential
[21] https://asymco.com/2026/02/02/1-7-billion-customers/ — retrieved 2026-05-10 — Apple installed base 2.5B active devices, 1.15B paid subs, ~$174 rev/device/yr
[22] https://wccftech.com/apple-a20-and-server-chips-to-use-tsmc-wmcm-and-soic-packaging-from-2026/ — retrieved 2026-05-10 — WMCM line at TSMC Chiayi P1, 10k→60k→120k wafer/mo scaling; SoIC for Baltra server chip
[23] https://appleinsider.com/articles/26/04/20/smart-glasses-race-heats-up-as-apple-prepares-for-late-2026-entry — retrieved 2026-05-10 — Apple N50 glasses 4 designs, H2'26 unveil; Meta 7M Ray-Ban units 2025, 82% share, $800 Ray-Ban Display