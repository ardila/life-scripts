# DLR — Digital Realty Trust

## Where this sits in the AI stack
DLR is a wholesale and colocation data center REIT. Its product is the building shell, the power feed from the utility (down to the busway and PDU), the cooling plant (CRAH and increasingly direct liquid cooling loops), the meet-me-room fiber, and the lease contract — everything *up to but not including* the IT equipment. Workload mix is shifting hard from traditional cloud (compute/storage) toward AI **inference** plus enterprise hybrid; DLR is largely *not* the chosen substrate for greenfield frontier *training* clusters, which are flowing to vertically-integrated builders (Crusoe-for-Stargate, Microsoft self-build, Meta self-build, CoreWeave) [12][14]. The single largest deal in company history — the Q1'26 200 MW Charlotte lease with a "AA-rated hyperscaler" — was explicitly marked AI **inference** by management [2][3].

## Snapshot
- **Price:** $194.54 (2026-05-08 close, last available pre-query) [1]
- **Market cap:** ~$71.0B [1]
- **52-week range:** $143.83 – $208.14 [1][21]
- **Forward P/E:** 97.7× — **misleading for a REIT**; on 2026 core FFO guidance midpoint of $8.05, P/FFO is **~24.2×** [1][2]
- **EV / NTM revenue:** ~13.5× (EV ≈ $71B equity + $18.4B net debt + ~$0.6B preferred ÷ ~$6.7B 2026 revenue guide) [1][3][20]; cite as inference from disclosed components
- **Consensus 12-month price target:** ~$210.50 mean (+8% from price); 22-analyst Buy consensus [21]
- **YTD total return:** ~+9–10% (inferred from Dec'25 close ≈ $176 area implied by 52-wk range and post-Q1 rally; **not verified** to a precise figure) — flag as low confidence
- **Short interest (% of float):** 3.89% (10.0M shares short, latest report) [22]
- **Net debt / Adj. EBITDA:** 4.9× at 4Q'25; total debt $18.4B [20]

## Moat — what it is physically made of
The DLR moat decomposes into five components of very different durability:

1. **Power entitlement / land bank in supply-constrained metros.** The most durable piece. In Loudoun County alone DLR holds ~1,000 acres with ~575 acres still developable on top of ~600 MW of operating IT load, plus ~50 MW/yr of leases rolling on already-energized capacity for the next 4–5 years [16]. Globally the company runs ~3 GW operating with ~6 GW of future capacity already controlled, ~60% of which sits in >100 MW campus blocks — i.e. AI-shaped [3][4]. Greenfield competitors face PJM interconnect queues that have lengthened from <2 yrs (2008) to ~5 yrs today, with the Loudoun 500 kV remediation not in service until 2026 [6][24]. A queued land position with a signed Dominion ATO is *the* hard-to-arbitrage asset in this market, and DLR was already in line. **Durability: high, ~5+ year visibility, but decays as transmission catches up.**

2. **High-density retrofit capability (rear-door HX + DLC).** DLR's HD Colo program offers direct-liquid-to-chip cooling supporting 30–150 kW/rack across 170+ data centers globally [5]. That window covers GB200 NVL72 (120–132 kW/rack) and conventional H200 fleets, but **not** Vera Rubin Ultra / "Kyber" 600 kW racks slated for 2H'27 [18]. So this moat component is good for the current GPU cycle and obsoletes mid-decade unless DLR plumbs CDU capacity 3–4× higher — possible in new builds, hard to retrofit. **Durability: medium, 2–3 year window.**

3. **Interconnection ecosystem (PlatformDIGITAL / ServiceFabric).** 232,000 cross-connects across 55 metros [10]; ServiceFabric exposes ~200 cloud on-ramps. Real but second-tier vs. Equinix's IBX network, which is why Equinix and DLR are repeatedly described as "interconnect leader vs. hyperscale operating-leverage leader" [11][13]. Cross-connect revenue is high-margin recurring but a small share of total. **Durability: medium, slowly accreting.**

4. **Capital partners that lower DLR's effective WACC.** $7B JV with Blackstone (DLR keeps 20% / earns dev + operating fees on 80% of capital) plus the $3.25B Hyperscale Fund close in March'26 [19][23]. This is genuinely important: DLR's REIT cost of equity is high, private infra capital is cheap, and the JV structure lets DLR develop ~5× the capacity per dollar of own equity. Replicable by EQIX (already done with GIC/CPP at $15B [11]); **not** replicable by smaller REITs or balance-sheet-only privates. **Durability: medium, contingent on infra-equity flows staying open.**

5. **Operating skill (PUE, uptime, Tier III/IV certs).** Largely commoditized — every serious operator has it. **Durability: low; not really a moat.**

What is *not* on this list: DLR has no chip, no NVLink/NVSwitch substitute, no compiler, no kernel library, no GPU fleet. The "moat" is real but it is a **physical-real-estate-plus-utility-permitting** moat, not an AI-system moat. The technology that runs in DLR boxes determines DLR's revenue; DLR does not determine the technology.

## AI buildout bottleneck map
24-month gating constraints, mapped to DLR position:

| Bottleneck | State of art (Q2'26) | DLR position |
|---|---|---|
| **CoWoS-L advanced packaging** | TSMC ~75K wpm rising to 120–130K wpm by YE'26; NVIDIA has booked ~800–850K wafers for 2026, >50% of capacity [8] | **Indifferent** — DLR sits one layer above silicon |
| **HBM3e / HBM4 supply** | SK Hynix-led, 3× the wafers/GB vs. DDR5; high-teens to 20% pricing [8] | **Indifferent** |
| **Liquid cooling (DLC) + CDUs >1 MW** | NVL72 mainstream; Rubin Ultra needs 600 kW racks and zero-fan immersion-class cooling [18] | **Beneficiary near-term, exposed long-term** — current 30–150 kW envelope is competitive for NVL72; needs another step-change for Kyber |
| **Power generation (gas turbines)** | GE Vernova 80 GW backlog, Strazik says sold-out through 2030 by YE'26; lead times 5–8 yrs [9] | **Beneficiary** — sites with energized utility power command premium; behind-the-meter gas is a hyperscaler/neocloud play, less DLR's domain |
| **Grid interconnect / transmission** | PJM $11.8B RTEP; Dominion 500 kV Loudoun 2026; CA queues >9 yrs [6][24] | **Strong beneficiary** — DLR is *the* large incumbent in Loudoun with energized + permitted MW [16] |
| **Optical interconnect / scale-out fiber** | 800G ZR+ ramping; submarine cable congestion in EMEA | **Indifferent / mild beneficiary** via PlatformDIGITAL fiber assets |
| **Skilled electrician / DC-construction labor** | Industry-acknowledged shortage; DLR cited it on Q1 call [2] | **Constraint owner** — same problem as everyone, mild edge from scale procurement |
| **Frontier-model training data** | Increasingly synthetic/RL; gating to compute side | **Indifferent** |

The clean read: DLR is most levered to the **grid + permitting** bottleneck and the **rack-density** bottleneck, indifferent to the silicon stack. That is exactly the right profile if you believe the binding constraint of the AI cycle is *getting electrons under a roof on a delivery date*, not silicon flops.

## Competitive teardown
**Equinix (EQIX)** — the cleanest peer. EQIX has a deeper interconnect moat (IBX network effect, more cross-connects per site), DLR has more raw MW and more aggressive hyperscale build velocity. The $15B EQIX/GIC/CPP xScale JV (1.5+ GW US) is the symmetric response to DLR's Blackstone JV [11]. Both will share the >100 MW hyperscale market; DLR has more developable land in Loudoun, EQIX has stickier retail revenue. On AI specifically: roughly comparable retrofit capability; EQIX has been later to liquid cooling at scale.

**Iron Mountain (IRM)** — sub-scale at 488 MW with 400 MW pipeline [25]. Real but a different game; roll-up of records management plus opportunistic data center. Not a credible threat at the >100 MW hyperscale tier.

**Aligned Data Centers (private, MIP)** — ~2,000 MW at full build-out [26]. Real wholesale competitor in the same hyperscale lanes; private capital structure means it can hold longer at lower yields. Recently partnered closely with hyperscalers; among the most credible long-cycle threats to DLR's market share.

**Vantage (DigitalBridge)** — ~1,500 MW operating + 2.5 GW announced new [26]. Direct competitor for hyperscale wholesale, similar construction velocity.

**QTS (Blackstone)** — taken private in 2021; now developing aggressively (~9.35M sq ft) on Blackstone capital. Important: Blackstone now sits on **both sides** of the DLR JV and as owner of QTS — so QTS competes with DLR while Blackstone is also DLR's largest dev partner. Worth flagging as a structural awkwardness [26].

**Neoclouds (CoreWeave, Nebius, Crusoe, IREN, Lambda)** — these are **not direct DLR competitors at the real-estate layer** but they are the swing factor on the *demand* side. CoreWeave is targeting 1.7 GW active by YE'26 from 850 MW at YE'25 [14]; Nebius targets 2.5 GW contracted / 0.8–1 GW physically built in 2026 [14]; Crusoe is the operator behind Stargate Abilene's 1.2 GW [12]. These players are increasingly self-building or leasing build-to-suit from non-REIT developers, capturing the *training* spend that does *not* flow to DLR. The 200 MW Charlotte deal being **inference**, not training, is consistent with this — DLR gets the post-training, deployable workload.

**Hyperscaler self-build** — the deepest threat. Microsoft picked up the Crusoe Abilene adjacent 900 MW after OpenAI redirected [12]; Meta is doing $48B with CoreWeave/Nebius rather than DLR/EQIX; Google has long self-built. The structural question is whether hyperscalers lease ~30–40% of their capacity (long-running mix) or migrate toward 80%+ self-build for AI-optimized campuses. Capital and labor scarcity makes 100% self-build impossible, which is the source of DLR's bid.

**Competitive axes table:**

| Axis | DLR position |
|---|---|
| Hyperscale wholesale velocity | Top 2 (with Aligned/Vantage closing) |
| Interconnect / cross-connect density | #2 behind EQIX |
| AI inference colocation (NVL72-class) | Strong, retrofit-capable across 170 sites [5] |
| AI training (frontier) | Weak — losing to neoclouds + hyperscaler self-build |
| 600 kW rack readiness (Rubin Ultra '27) | Unproven; needs new construction generation |
| Cost of capital | Mid — lower than balance-sheet privates after JVs, higher than infra funds and hyperscalers |

## Bull case — technical
The bull case rests on **three technical conditions** holding:

1. **The grid stays the binding constraint through ≥2027.** Gas turbines are sold out [9], PJM transmission is multi-year out, behind-the-meter gas is slow to permit. Every quarter the grid stays gated, DLR's pre-permitted Loudoun + similar positions accrue scarcity rent. Q1'26's 11.4% expected yield on $16.5B of construction *while* construction costs inflate is the live evidence [3].
2. **Inference demand is real and grows ≥3×.** SemiAnalysis-modeled US AI critical IT power goes from ~3 GW (2023) to >28 GW by 2026 [7]. Inference, unlike training, fans out to many sites and is geography-bound by latency — a structural fit for DLR's distributed metro footprint vs. a few hyperscaler mega-campuses. The Charlotte deal is the canary [2][3].
3. **Retrofit window stays profitable through Vera Rubin (2026) but not necessarily Rubin Ultra (H2'27).** As long as the GPU mainstream stays at 120–200 kW/rack, DLR's installed DLC fleet [5] earns a premium. New construction (the 1.2 GW under construction at 11.4% yields) handles whatever comes next.

Base rate context: data-center REITs' last analogous cycle was 2007–2010 wholesale buildout; valuations compressed as private capital arrived but core operating businesses compounded. The displacement risk to physical real-estate-plus-utility moats is **low** in 2-year windows (transmission can't be built faster than physics) and **medium** in 5-year windows (entrants with patient capital catch up). Historically, wholesale colo CAGR has run 12–15%; AI stretches that to 20%+ at the supply-constrained end. **Financial outcome:** if 2026 FFO of $8.05 grows ~10–11% via mix shift to higher-yielding AI builds, FY28 FFO is ~$9.80; at a 25× multiple (premium to 21× sector average reflecting embedded land-bank optionality), that's ~$245 — call it ~25% upside over ~30 months.

## Bear case — technical
The honest version of the short:

1. **Inference moves to ASICs and to lower-density edge.** Google TPU v5p/v6 already serve a meaningful share of Google inference; AWS Trainium2/Inferentia2 are ramping; Meta's MTIA is in production. As FP4/INT4 inference becomes dominant, $/inference drops 5–10× and the workload **migrates to edge POPs, telco DCs, and enterprise on-prem** as latency requirements bind. Wholesale 200 MW campuses are not optimal for this. The Charlotte deal could turn out to be the **last** big inference colo deal of the cycle, not the first.

2. **AMD MI400 (H2'26) on TSMC N2, anchored by the OpenAI 6 GW deal, breaks NVIDIA's pricing power** [13]. MI355X already matches B200 on Llama-3-70B FP8 at the chip level. Lower NVIDIA premium → less hyperscaler P&L room → tighter colo lease economics on the margin. Not catastrophic for DLR, but compresses re-leasing spreads (currently +7.4% on >1 MW renewals [2]) on the next cycle.

3. **600 kW Rubin Ultra (H2'27) breaks DLC retrofit economics** [18]. Going from ~150 kW to 600 kW per rack is not a software upgrade — it is rip-and-replace CDU plant, larger riser piping, possible immersion at the chassis level, and substantially more water. Retrofit cost rises non-linearly past 200 kW. If the next NVIDIA-class fleets standardize at 600 kW, much of DLR's currently-leased non-AI footprint becomes a slow-decay annuity, and only the 1.2 GW of greenfield is "real" AI capacity. The enterprise narrative compresses to the *new build* narrative — which is more capital-intensive and lower-multiple.

4. **The bear's bear: hyperscaler self-build crosses 70%+ for AI campuses.** Microsoft taking Crusoe Abilene adjacent [12], Meta-CoreWeave $48B, Google's lifelong self-build pattern — if the structural mix shifts from ~60/40 self-build/lease to 80/20 for AI specifically, DLR's net new TAM compresses materially. The colo bid becomes second-tier customers (financials, GPU-as-a-service neoclouds with weaker credit), and the AA-hyperscaler deals become the exception, not the trend.

5. **Power moats are **temporary** moats.** The 500 kV Loudoun line completes 2026 [6][24]; PJM RTEP is $11.8B of new transmission [27]. By 2028, the queue clears; new entrants pour in. Base rate on real-estate moats based on permitting/utility gating: they erode on a 3–5 year timeframe in every cycle.

6. **Forward P/FFO of 24× on a REIT with 4.9× ND/EBITDA leverage** [20] is priced for execution — any 2 quarters of pipeline conversion slowness materially compress the multiple. This isn't a deep-value name; the technical thesis must be right for the price to work.

## Market view check
At $194.54, ~24× P/FFO on the 2026 midpoint, EV/EBITDA in the high-20s, and a 2.4% dividend yield, DLR is priced as a **growth REIT, not a yield REIT**. The implied embedded growth is ~10% FFO CAGR, materially above the 6–7% DLR delivered last cycle. The market is therefore implicitly pricing in: (a) the AI inference colo wave is real and DLR captures it, (b) the 1.2 GW under construction lands at ~11% yields, (c) the Loudoun land bank monetizes through 2028+, and (d) hyperscaler self-build does *not* exceed ~50% of incremental AI campus capacity. With consensus PT at $210 (+8%) [21] and Buy ratings, the Street agrees with this base case. The mispricing question is asymmetric: bulls need *one more leg* of multiple expansion (hard to argue at 24×); bears need either Rubin-Ultra-driven retrofit obsolescence to start showing in earnings, or hyperscale self-build to accelerate visibly. My read: **fairly priced on the base technical thesis, modestly long-tail bullish if grid stays gated, with asymmetric downside if the Rubin Ultra cycle exposes the retrofit ceiling sooner than expected.**

## 90-day falsifiers
Things you could actually check between mid-May 2026 and mid-Aug 2026:

1. **Q2'26 DLR earnings (late July).** Watch: (a) backlog growth from the $1.8B Q1 base — flat or declining = the Charlotte deal was a pull-forward, not a new run-rate; (b) AI-oriented share of 0–1 MW + interconnect signings vs. Q1's 21% — sustained ≥20% confirms inference colo thesis; (c) any **training** lease at >50 MW would be a meaningful upgrade; absence reinforces the inference-only positioning.
2. **MSFT/META/GOOG/AMZN July capex prints.** A combined sequential capex cut of >5% would meaningfully tighten the demand pipe; an *increase* with explicit "leasing more colo" commentary is bullish.
3. **Dominion 500 kV Loudoun in-service announcement.** If energization slips into 2027, DLR's NoVa scarcity rent persists; if it lands on time mid-2026, DLR's power-entitlement moat starts ticking down.
4. **GE Vernova / Siemens Energy Q2 turbine bookings.** If the YE'26 sold-out-through-2030 narrative intensifies (>20 GW Q2 bookings at GEV), behind-the-meter alternatives stay slow → grid moat extends.
5. **AMD MI400 customer disclosures at AI Advancing-AI event / earnings.** A second hyperscaler beyond OpenAI committing >1 GW of MI400 capacity changes the GPU pricing curve.
6. **Rubin Ultra "Kyber" rack reference designs from OEM partners.** If Vertiv/Schneider/Eaton publish 600 kW reference architectures with retrofit pathways for sub-150 kW DLC sites, the bear case on DLR's installed base softens; if they publish only greenfield-optimized designs, it sharpens.
7. **Aligned, Vantage, or QTS announcing a >500 MW hyperscale anchor in Loudoun, Charlotte, or Atlanta** — direct competitive pressure on DLR's signature markets.
8. **Any DLR equity issuance.** A large ATM raise at ≥$200 funds the pipeline cheaply; a delayed raise at <$170 forces JV reliance and slower growth.

## What I could not verify
- **Top-customer concentration percentages** in the FY25 10-K (the customer concentration table). The 10-K excerpt I retrieved did not surface the named-tenant rent table; this matters because DLR's churn/credit risk depends on whether top-5 are >40% of rent or <30%. *Unverified.*
- **Specific identity of the AA-rated Charlotte 200 MW tenant** (Microsoft, Meta, Oracle, Apple, and Google all credibly fit "AA-rated hyperscaler"; AWS is technically AA-). Materially changes the read on which hyperscaler is choosing colo over self-build.
- **DLR's exact AI-revenue mix** as a % of total — management quotes 21% of 0–1 MW + interconnect signings as AI [2], but does not split AI vs. non-AI on the >1 MW side.
- **Number of DLR sites supporting >100 kW/rack DLC vs. only the 30–60 kW range**. Press release says "170 sites" but does not disaggregate.
- **Forward weighted-average lease term and CPI escalator profile** on hyperscale deals signed in 2025–26.
- **Specific Rubin Ultra–compatible dev-pipeline allocation** (any disclosure on 300 kW+ rack capacity in the 1.2 GW under construction).
- **CapEx mix — what % of the $3.5–4.0B 2026 capex is greenfield AI vs. brownfield retrofit vs. maintenance** — only blended figures are public.
- **YTD 2026 total return** — inferred ~+9–10% from price points but not confirmed against a clean Dec'25 close.
- **DLR's hedge book on power costs** beyond the "90% of utility expense reimbursed by customers, remainder hedged through 2026" comment from the Q1 call [2].

## Sources
[1] https://finance.yahoo.com/quote/DLR/ — retrieved 2026-05-10 — DLR price ($194.54), market cap, fwd P/E, 52-week range
[2] https://www.fool.com/earnings/call-transcripts/2026/04/23/digital-realty-dlr-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1'26 transcript: Charlotte 200 MW inference deal, renewal spreads, capex guide, supply commentary
[3] https://www.globenewswire.com/news-release/2026/04/23/3280372/0/en/Digital-Realty-Reports-First-Quarter-2026-Results.html — retrieved 2026-05-10 — Q1'26 press release: $707M bookings, $1.8B backlog, 1.2 GW under construction at 11.4% yield, 61% pre-leased, $16.5B gross dev pipeline
[4] https://convergedigest.com/digital-realty-hits-record-bookings-as-ai-drives-multi-gigawatt-expansion/ — retrieved 2026-05-10 — Total ~9 GW IT capacity (~3 GW operating, ~6 GW future), 60% in >100 MW blocks
[5] https://www.datacenterfrontier.com/cooling/article/55040948/digital-realty-adds-direct-liquid-cooling-for-high-density-colocation-in-170-data-centers-globally — retrieved 2026-05-10 — 30–150 kW/rack DLC across 170 sites
[6] https://www.datacenterfrontier.com/energy/article/11436951/dominion-resumes-new-connections-but-loudoun-faces-lengthy-power-constraints — retrieved 2026-05-10 — 500 kV Loudoun transmission timing, queue dynamics
[7] https://newsletter.semianalysis.com/p/ai-datacenter-energy-dilemma-race — retrieved 2026-05-10 — Global critical IT 49→96 GW by 2026, US AI 3→28 GW; rack density mismatch problem
[8] https://www.fusionww.com/insights/blog/inside-the-ai-bottleneck-cowos-hbm-and-2-3nm-capacity-constraints-through-2027 — retrieved 2026-05-10 — CoWoS/HBM oversubscription through 2026; NVIDIA 800–850K wafers booked
[9] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — GE Vernova 80 GW backlog, sold out through 2030 by YE'26; 5–8 yr lead times
[10] https://www.sec.gov/Archives/edgar/data/1297996/000110465926015365/dlr-20251231x10k.htm — retrieved 2026-05-10 — DLR 10-K FY25: 310 data centers, 57.6M sq ft, 232K cross-connects, ~9.7M sq ft under construction, >3,500 MW developable land
[11] https://www.prnewswire.com/news-releases/equinix-agrees-to-form-greater-than-15b-jv-to-expand-hyperscale-data-centers-in-the-us-and-support-growing-ai-and-cloud-innovation-302263523.html — retrieved 2026-05-10 — Equinix $15B xScale JV with GIC/CPP for 1.5+ GW US
[12] https://epoch.ai/blog/openai-stargate-where-the-us-sites-stand — retrieved 2026-05-10 — Stargate Abilene 0.3 GW operating, 1.2 GW total by mid-2026; Microsoft picking up adjacent Crusoe 900 MW
[13] https://newsletter.semianalysis.com/p/amd-advancing-ai-mi350x-and-mi400-ualoe72-mi500-ual256 — retrieved 2026-05-10 — AMD MI400 H2'26 on N2, OpenAI 6 GW anchor; MI355X parity with B200 on Llama-3-70B FP8
[14] https://www.fool.com/investing/2026/04/21/meta-is-spending-48-billion-with-coreweave-nebius/ — retrieved 2026-05-10 — Meta-CoreWeave/Nebius $48B; CoreWeave 850 MW→1.7 GW path; Nebius 2.5 GW contracted target
[15] https://www.globaldatacenterhub.com/p/the-retrofit-problem-why-legacy-data — retrieved 2026-05-10 — Stranded asset / retrofit cost $1–8M/MW for AI workloads
[16] https://www.datacenterfrontier.com/energy/article/33000252/digital-realty-well-deliver-on-our-power-commitments-in-northern-virginia — retrieved 2026-05-10 — Loudoun 1,000 acres / 575 dev / 600 MW operating / 50 MW/yr roll
[17] https://www.prnewswire.com/news-releases/hut-8-commercializes-first-phase-of-1-gw-beacon-point-ai-data-center-campus-with-15-year-352-mw-it-lease-with-base-term-contract-value-of-9-8-billion-302763484.html — retrieved 2026-05-10 — Industry comp: 15-yr triple-net hyperscale AI lease w/ 3% escalator
[18] https://www.datacenterdynamics.com/en/news/nvidias-rubin-ultra-nvl576-rack-expected-to-be-600kw-coming-second-half-of-2027/ — retrieved 2026-05-10 — Rubin Ultra Kyber 600 kW racks, H2'27, full immersion-class cooling
[19] https://www.blackstone.com/news/press/digital-realty-and-blackstone-announce-7-billion-hyperscale-data-center-development-joint-venture/ — retrieved 2026-05-10 — DLR/Blackstone $7B JV, 80/20, 500 MW IT load across Frankfurt/Paris/NoVA
[20] https://www.globenewswire.com/news-release/2026/02/05/3233437/0/en/Digital-Realty-Reports-Fourth-Quarter-2025-Results.html — retrieved 2026-05-10 — $18.4B total debt, 4.9× net debt / Adj. EBITDA, $857M Q4'25 Adj. EBITDA, 4.5× FCC
[21] https://www.marketbeat.com/stocks/NYSE/DLR/forecast/ — retrieved 2026-05-10 — 22-analyst Buy consensus, $210.50 mean PT, 52-wk high $208.14
[22] https://www.marketbeat.com/stocks/NYSE/DLR/short-interest/ — retrieved 2026-05-10 — 10.0M shares short, 3.89% of float
[23] https://investor.digitalrealty.com/news-releases/news-release-details/digital-realty-announces-final-close-325-billion-us-hyperscale — retrieved 2026-05-10 — $3.25B US Hyperscale Fund final close, March 2026
[24] https://landvalues.acres.com/part-4-interconnection-queues-stalling-data-center-growth — retrieved 2026-05-10 — Interconnection queues: <2 yrs (2008) → ~5 yrs today, CA >9 yrs
[25] https://www.datacenterdynamics.com/en/news/iron-mountain-accelerates-in-madrid-mad-2-to-arrive-with-10-mw-in-2026-and-mad-3-in-2027/ — retrieved 2026-05-10 — IRM 488 MW operating, 400 MW pipeline
[26] https://dgtlinfra.com/top-data-center-companies/ — retrieved 2026-05-10 — Aligned ~2,000 MW, Vantage ~1,500 MW + 2.5 GW announced, QTS ~9.35M sq ft
[27] https://www.utilitydive.com/news/pjm-rtep-transmission-expansion-plan-dominion-nextera-exelon/812311/ — retrieved 2026-05-10 — PJM $11.8B RTEP transmission expansion