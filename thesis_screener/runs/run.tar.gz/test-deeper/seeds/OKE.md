# OKE — ONEOK Inc.

## Where this sits in the AI stack

ONEOK is a US natural-gas and NGL midstream operator — gathering, processing, NGL fractionation, and pipeline transportation. It is **not** in the AI compute stack at all. It sits at the **fuel layer feeding the power layer that feeds the data-center layer**: associated/dry gas from the Permian, Bakken, Mid-Continent, and (post-EnLink, Jan 2025) Louisiana basins, moved to the Gulf Coast (LNG export), to Mont Belvieu (NGL fractionation), and — incrementally — to gas-fired power generation that increasingly serves AI data centers. Exposure to AI is **derivative through gas-burn for electricity**, not contracted hyperscaler revenue.

## Snapshot

- **Price:** $85.16 (2026-05-08 close) [3]
- **Market cap / EV:** $53.65B / ~$87.13B [3]
- **52-week range:** $64.02 – $95.30 [3]
- **Forward P/E (FY26 mgmt EPS $5.53):** 12.9–14.4× [1][3]
- **EV / NTM EBITDA:** ~10.6× ($87.1B EV / $8.25B FY26 mid-guide) [1][3]
- **EV / NTM revenue:** ~2.2× — *low signal for midstream; EV/EBITDA is the relevant multiple*
- **Consensus 12-mo PT:** ~$92 (range $74–$104); implied ~+8% [3]
- **YTD total return (2026):** +1.14%; peaked ~+15% late-April then pulled back on Q1 EPS miss [3]
- **Short interest (% float):** ~3.8–4.1% [3]
- **Dividend yield:** 5.0% ($4.28 annualized) [3]
- **Implied DCF coverage:** ~1.6× ($5.53 EPS / $4.28 div); ONEOK does not publish a formal MLP-style coverage ratio post-2017 simplification [1]

## Moat — what it is physically made of

ONEOK's moat is **not** intellectual property, software, or brand. It is geological, regulatory, and contractual. Decomposed:

**1. Mont Belvieu NGL fractionation complex (the crown jewel).** Six fractionators — MB-1 through MB-6, with MB-6 commissioned 2025 — totaling roughly 1.0 MMbpd of fractionation capacity, plus salt-dome NGL storage exploiting Texas Gulf Coast salt geology that is not replicable elsewhere on the US coast. To replicate Mont Belvieu, a competitor would need: (i) salt-dome geology (geographically constrained to ~3 sites globally), (ii) 5–7 years of FERC and state permitting, (iii) $5–10B greenfield capex, (iv) producer-side NGL feedstock dedication, and (v) a pipeline web feeding it. Targa is the only meaningful peer at Mont Belvieu; everyone else is sub-scale. **Durability: very high (multi-decade).** [3][31][32]

**2. NGL pipeline highways into Mont Belvieu.** Bakken NGL Pipeline (240 Mbpd, 540 mi), Sterling I/II/III and Arbuckle I/II from Mid-Continent, Texas Express, and the West Texas LPG line. These are the dedicated rails feeding fraction-3 capacity. Producers dedicate NGL volumes under multi-year agreements; switching a Bakken producer's NGL routing requires building a new line — not credibly possible. [4][31]

**3. Bakken associated-gas processing.** ONEOK is the largest gatherer/processor in the Williston Basin (~1.7 Bcf/d gas processing post-EnLink + organic). Bakken associated gas is captive — producers can't economically truck gas, so the gatherer has structural pricing power as long as Bakken oil is being produced. **Risk:** Bakken is mature; production has plateaued. Multi-decade durability but no growth tailwind. [4]

**4. Magellan refined-products + crude system (acquired Sep 2023).** 9,800 mi common-carrier system across 15 states; Sun Belt Connector greenfield to Phoenix (200 Mbpd, ISD mid-2029). Tariff-rate FERC-regulated assets with rate-base-style returns. Adjacent to AI thesis only because Phoenix is a data-center corridor — but this is liquid fuels, not power-burn gas. [4][30]

**5. EnLink Louisiana assets (closed Jan 2025).** 3,100 mi gas transmission, 11 Bcf storage, 710 MMcf/d processing, ~4 Bcf/d gas-pipe capacity, 220 Mbpd NGL fractionation in Louisiana. This is the **most thesis-relevant new asset**: it sits at Henry Hub and feeds Sabine Pass / Plaquemines / Golden Pass LNG plus the Entergy load center near Meta's Hyperion campus. Run-rate synergies >$500M by YE25 (Magellan + EnLink combined). [5][2]

**6. Permian gathering + Eiger Express egress.** 15% interest in Eiger Express (450 mi 48-in, expanded to 3.7 Bcf/d, ISD mid-2028) and 15% in Matterhorn JV — both partnered with WhiteWater/MPLX/Enbridge. These are takeaway lines from oversupplied Waha to Katy demand and Gulf Coast LNG. Critical context: Permian gas is currently **structurally oversupplied** — Waha basis traded negative for a record stretch in Q1–Q2 2026 [23] — so these takeaway pipes have pricing power *because* the wellhead has none. [6][28]

**7. Long-term contracts.** ~90% fee-based revenue; bulk under multi-year MVCs / take-or-pay with investment-grade counterparties. Contract durability is high but renewal risk concentrates around 2030+. [4]

**Honest moat assessment.** ONEOK's moat is real, geological, and durable on the timescales midstream investors care about (15–30 years). What it is *not* is a moat in the **specific corridor** that matters most for AI data centers: PJM/Northern Virginia. That corridor is owned by Williams via Transco. ONEOK has zero meaningful interstate gas pipe east of the Mississippi. Calling OKE an "AI moat" stock conflates two facts: (a) ONEOK has a deep structural midstream moat, and (b) some incremental gas demand comes from data centers. Both true; the second does not flow exclusively through the first.

## AI buildout bottleneck map

Stack-ranked binding constraints over the next 24 months, with ONEOK's relationship to each:

| # | Bottleneck | Hard data | OKE's role |
|---|---|---|---|
| 1 | **Heavy-duty F/H-class gas turbines** | GE Vernova backlog 100 GW post-Q1 2026, ~3-yr lead, slots gone through 2029 [11]; Siemens Energy €146B backlog into 2029–30, 65% of YTD orders DC-bound [12]; Mitsubishi sold out into 2028 [13] | **Indifferent** — does not relieve. Slower turbine delivery slows the pace at which gas demand actually materializes |
| 2 | **Switchgear + large transformers** | 45–80 wk lead; high-spec ~3 yr [20] | Indifferent |
| 3 | **EPC labor / electricians** | Shortage ~439k construction workers; Brad Smith called electricians the "#1 problem" Mar 2026 [21]; US DC under-construction capacity *fell 5.7% in 2025* — first contraction since 2020 [22] | Indifferent |
| 4 | **Grid interconnect** | PJM Cycle 1: 811 projects / 220 GW queue, COD likely early-2030s [14]; ERCOT large-load queue ~380 GW, only **2,168 MW energized trailing 12 months** [15]; FERC June 2026 deadline to rewrite co-location rules [16] | Indifferent — but BTM gas plants (which OKE *can* serve) bypass the queue, and the trend is toward BTM (~25% of >500 MW DC sites by 2030 vs ~1% today) |
| 5 | **CoWoS-L advanced packaging** | TSMC ~130–150 kwpm by YE26; NVIDIA ~60% (~510k wafers CoWoS-L) [17][18] | Indifferent |
| 6 | **HBM4 supply** | SK hynix ~62% share, ~70% of NVIDIA HBM4 [19]; Samsung 16-Hi yield ~10% | Indifferent |
| 7 | **Optical / 1.6T transceivers / CPO** | NVIDIA $4B Mar 2026 split commitment to Coherent + Lumentum for 200G/lane EMLs [18] | Indifferent |
| 8 | **Liquid cooling >100 kW/rack** | 40% liquid penetration by YE26; market $8B → $30B by 2033 | Indifferent |
| 9 | **Lateral gas pipelines + compression to BTM plants** | ~80–100 MMcf/d firm needed per 500 MW site; new laterals + compression off interstate trunks | **Direct beneficiary** — gathering/processing/lateral build-out is OKE's day job |
| 10 | **Long-haul gas takeaway** | Eiger Express 2.5 Bcf/d mid-2028, Blackcomb Oct 2026, GCX expansion Q2 2026 | **Direct beneficiary via Eiger / Matterhorn JVs** |
| 11 | **Wellhead gas supply** | Permian 27.6 Bcf/d 2025, ~29 Bcf/d 2026; Waha negative for record stretch Q1–Q2 2026 [7][23] | **Not binding.** Wellhead is oversupplied; benefit accrues to takeaway, not production |

The binding constraint is downstream of gas, not gas itself. ONEOK monetizes the gas-delivery sub-bottleneck — real and contracted (10-yr take-or-pay on Eiger) — but does not relieve the dominant constraints. **It is a beneficiary, not a marginal unblocker.**

## Competitive teardown

The four meaningful US gas-midstream peers, ranked by direct AI-data-center contract evidence rather than narrative:

**Williams (WMB) — owns the corridor that matters most.** Transco is *the* pipe into PJM-East and Loudoun County. Q1 2026 disclosed pipeline of named DC projects: Power Express expanded to 950 MMcf/d (Station 165 → Northern Virginia, ISD 2030); Atlas (164 MMcf/d, 13-yr); Neo Power Project (682 MW, 12.5-yr, $2.3B, 2H 2028); Southside Reliability (423 Mdth/d). Six DC projects in development. Trades **~13–14× EV/EBITDA, ~3.4% yield** [25]. WMB's Transco is replacement-cost-irreplicable in the Northeast. **OKE has no answer here.**

**Kinder Morgan (KMI) — owns the Southeast.** Disclosed >10 Bcf/d of new gas-fired power demand exposure + 3 Bcf/d LNG demand. Three FID'd projects (~$5B KMI share) explicitly aimed at Southeast DC load: South System Expansion 4 (+1.3 Bcf/d MS/AL/GA/SC), Mississippi Crossing, and **$1.8B Trident** (2 Bcf/d Katy → Port Arthur). EBITDA guide ~$8.7B; ~10.9× / 4% yield [24]. KMI captures Atlanta and Carolinas DC clusters that OKE cannot reach.

**Energy Transfer (ET) — owns the first marquee BTM precedent.** **CloudBurst agreement, 2025**: Oasis Pipeline supplies up to 450 MMBtu/d (~0.45 Bcf/d), 10-yr term, ~1.2 GW BTM to a San Marcos, TX AI campus, Phase 1 Q4 2026 [26]. ET trades ~9–10×, ~7% yield. The first signed hyperscaler-adjacent BTM gas contract is theirs, not OKE's.

**Targa (TRGP) — direct Permian/NGL comp.** Q1 2026 EBITDA $1.4B (+19% YoY); five new Permian processing plants (1.4 Bcf/d incremental); ~12× EV/EBITDA, ~2% yield. Faster organic Permian growth, narrower business mix. OKE wins on scale (~2× EBITDA), Bakken franchise, and Mont Belvieu lead.

**Honest scorecard for OKE.**
*Disadvantages:* (i) zero PJM/Northern Virginia exposure — the single largest structural gap; (ii) Q1 2026 disclosed only "advanced discussions" with DCs in OK/TX, no signed BTM contract analogous to ET–CloudBurst [1]; (iii) Stargate Abilene draws gas from **Atmos Pipeline-Texas, not OKE** [10]; Crusoe's 4.5 GW gas microgrid does not list ONEOK as supplier [9]; Meta Hyperion likewise. The marquee deals named someone else's pipe.
*Underappreciated edges:* (i) Bakken associated-gas captivity — peers can't replicate; (ii) Mont Belvieu NGL stack at scale (MB-6 just online; MPLX "wellhead-to-water" JV) — the purest beneficiary of NGL exports, an AI-adjacent thesis via petchem/ethane; (iii) Mid-Con/SPP gathering near OK/TX panhandle — well-positioned for the second wave of DC siting (OKC, Tulsa, Abilene); (iv) valuation: ~10.6× EV/EBITDA and 5.0% yield versus WMB's ~13×/3.4%.

## Bull case — technical

For OKE to materially outperform, the following technical chain must hold:

1. **BTM gas-fired generation continues to win share** because PJM/ERCOT interconnect queues and the turbine backlog make grid-tied generation impossible at the speed hyperscalers need. Crusoe/Meta/Fermi precedent suggests >25% of >500 MW DC sites BTM by 2030 vs ~1% today [9]. BTM siting is dictated by where firm gas + cheap land + permitting permissiveness intersect — i.e., Permian, Mid-Con, North Dakota, Louisiana — **OKE's footprint, not Northern Virginia**.
2. **Permian takeaway remains constrained even as new pipes build out.** Eiger (mid-2028) and Blackcomb (Oct 2026) absorb existing oversupply but Permian gas growth keeps Waha tight relative to Henry Hub, sustaining tariff-style economics on takeaway. OKE captures via 15% Eiger + 15% Matterhorn [6].
3. **NGL exports continue compounding** (US ethane/propane export terminals are the binding constraint, not fractionation; but Mont Belvieu is the necessary feeder). Mont Belvieu fractionation runs hot, MB-6 absorbs supply, OKE wins on volume + tariff [32].
4. **OKE signs at least one named hyperscaler/BTM-developer agreement** in the next 4 quarters, validating the "advanced discussions" management language [1] and re-rating the multiple toward WMB/KMI's 12–13× EV/EBITDA from today's 10.6×.
5. **Capital discipline holds** — $2.7–3.2B FY26 capex envelope unchanged; incremental DC contracts come *on top of* the existing growth plan, not as a replacement [1].

**Base rate context.** Pipeline assets are among the most durable moats in any industry — 50–100 year asset lives, FERC-protected ROW that is functionally irreplicable east of the Mississippi (see Mountain Valley, Constitution, PennEast as cautionary tales for new entrants). When a midstream moat *does* erode, it erodes geologically slowly: by basin depletion or by demand destruction (industrial electrification). The base rate of a pipeline moat being disrupted in <10 years is ~zero. The risk to OKE specifically is *geographic mis-positioning*, not moat erosion.

**Financial outcome if the chain holds.** OKE compounds EBITDA mid-to-high single digits, sustains 5% dividend with ~3-4% growth, and re-rates ~150–250 bps closer to WMB. ~25–35% total return over 18–24 months including yield is plausible, with downside protection from the dividend.

## Bear case — technical

The version a short-seller who knows the stack would write:

1. **The "AI gas demand" forecast is overstated by 2–3×.** Headline numbers (3–20 Bcf/d incremental gas demand from DCs by 2030) span an order of magnitude because nobody knows the BTM-vs-grid mix, the renewables/battery substitution rate, or the actual PUE trajectory of next-gen training clusters. EIA's central case is in the lower half of the range [7]. Microsoft cancelled lease capacity in 2025; OpenAI's actual Stargate funding remains contested.
2. **Permian gas oversupply persists.** Waha negative for a record stretch in Q1–Q2 2026 [23] reflects takeaway lagging supply *now*. As Eiger and Blackcomb come on (late-2026 / mid-2028), takeaway gets ahead of supply growth, and Permian gathering/processing economics compress. OKE's Permian assets earn less, not more.
3. **Turbines, switchgear, and electricians push DC COD past 2028.** The bottleneck stack is so backed up that a $2.3B pipeline laid now (e.g., WMB Neo, OKE laterals) could be sitting waiting for turbines and substations to arrive in 2029–30. Pipeline cash flows start when the plant burns gas, not when the pipe is in the ground.
4. **Renewables + nuclear + SMR substitute at the margin.** Vistra's nuclear PPAs with Microsoft (Three Mile Island restart), Constellation's PPA stack, Amazon's SMR investments (X-Energy), Google's geothermal (Fervo), and continued solar+battery price declines all subtract from the **share** of incremental DC load served by gas. Not the *level* but the share — and midstream cash flow is built off the share.
5. **OKE's geographic mis-positioning persists.** Every new named DC pipeline contract goes to WMB (PJM), KMI (Southeast), or ET (Texas BTM). OKE remains in "advanced discussions" through 2026 and signs nothing material. The relative value gap closes by WMB/KMI compounding faster, not OKE re-rating up.
6. **Permian basin maturity and Bakken plateau.** Both basins are mid-to-late cycle. Once Permian gas growth slows (~2028 per most forecasts), the gathering/processing tailwind that has driven OKE's volume growth fades. The fee-based moat is still there, but growth flattens — and 10× EV/EBITDA without growth is not a 10× EV/EBITDA stock.

**Falsifier for the bull case.** If by Q4 2026 ONEOK has not signed a single named hyperscaler / data-center BTM contract, the "advanced discussions" framing is just management narrative. The bull case requires conversion.

## Market view check

At $85.16 with 5.0% dividend, ~10.6× EV/NTM EBITDA, and ~13× forward earnings, OKE is priced **as a high-quality midstream with a growth tailwind** — not as an AI-infrastructure play. The valuation gap to WMB (~13× EBITDA) reflects exactly the geographic and contract-quality gap I described: the market is not paying for an AI premium at OKE because OKE has not earned one. The +8% consensus PT implies modest upside; YTD +1.14% with a peak +15% in late April that round-tripped on the Q1 EPS miss [3] suggests the market is fairly pricing the "advanced discussions" language without giving credit until contracts land. **My read: OKE is approximately fairly valued relative to its own moat and modestly undervalued relative to the AI-power thesis if you believe the thesis materializes broadly across midstream.** It is not mispriced enough to be a high-conviction long on the AI angle alone — the mispricing, if any, is in the relative-value pair against WMB/KMI for investors who already want midstream exposure.

## 90-day falsifiers

Specific, observable, datable:

1. **OKE Q2 2026 earnings (~late July 2026)** — does management convert "advanced discussions" into at least one **named** hyperscaler or BTM-developer contract with disclosed Bcf/d volumes and term? Silence again is bearish for the AI premium thesis.
2. **GE Vernova Q2 2026 (~July 22)** — does the gas-turbine backlog grow above 110 GW or stagnate? Backlog growth → BTM gas burn pushed further out → near-term OKE volume thesis weaker.
3. **ERCOT and PJM Q2 2026 interconnect data** — actual MW energized in trailing 6 months. If ERCOT energizes <1,000 MW for large loads in the period, BTM economics strengthen further (favors gas midstream).
4. **FERC June 2026 ruling on co-location / large-load rules** — outcome materially shifts BTM gas economics. A permissive ruling is bullish gas midstream broadly; a restrictive one (forcing grid backstop charges) is bearish BTM and bearish OKE.
5. **WMB / KMI / ET FID announcements** for additional DC pipeline projects in their Q2 calls. Each marquee deal that goes to a peer is a small relative loss for OKE.
6. **Waha basis** — if Waha basis tightens to single-digit-negative or flips positive by August 2026, takeaway is catching up to supply and Permian gathering economics weaken on the margin.
7. **Hyperscaler Q2 2026 capex commentary** — Microsoft, Meta, Google, Amazon, Oracle. If aggregate guided CY26 capex is cut >10% sequentially, the DC gas-burn forecast is mechanically lower.
8. **TSMC CoWoS allocation update** at June Hot Chips talks / Computex — accelerated CoWoS-L throughput pulls in compute deployment timeline, marginally pulling in gas demand.
9. **EnLink synergy disclosure on Q2 call** — actual run-rate vs the $250–450M three-year target.

## What I could not verify

- **Specific Bcf/d of ONEOK gas currently being delivered to data-center power plants.** Management language is forward-looking ("advanced discussions") and does not quantify existing data-center revenue.
- **Whether "advanced discussions" are PPA-style take-or-pay or transportation-only.** Materially different cash-flow and re-rating implications.
- **Actual EnLink synergy capture vs. the $250–450M three-year target.** Management cites combined Magellan+EnLink "$500M run-rate by YE25" but does not break out EnLink alone.
- **Whether the 5.7% drop in 2025 US DC under-construction capacity is a one-off or trend.** This is the single most consequential under-the-radar number for the entire AI-buildout thesis.
- **Detailed customer dedications/MVCs by basin** — disclosed in aggregate (~90% fee-based) but not by basin or by counterparty class.
- **OKE's actual share of Permian associated-gas processing post-EnLink/Medallion.** Disclosed at "1.7 Bcf/d processing" but Permian-wide processing capacity and OKE share are not uniformly disclosed.
- **Mont Belvieu fractionation utilization and contracted-vs-spot mix.** Critical for NGL-exports thesis but only directional disclosure.
- **Bakken associated-gas growth trajectory beyond 2027.** Production has plateaued; sustaining Bakken volumes depends on completions activity I did not source.

## Sources

[1] [Motley Fool — ONEOK Q1 2026 earnings transcript (Apr 29, 2026)](https://www.fool.com/earnings/call-transcripts/2026/04/29/oneok-oke-q1-2026-earnings-transcript/) — retrieved 2026-05-10 — Q1 results, FY26 raised guide ($8.0–8.5B EBITDA), Norton/Swords DC quotes ("advanced discussions in Oklahoma and Texas")

[2] [Motley Fool — ONEOK Q4 2025 earnings transcript (Feb 24, 2026)](https://www.fool.com/earnings/call-transcripts/2026/02/24/oneok-oke-q4-2025-earnings-call-transcript/) — retrieved 2026-05-10 — first explicit "advanced negotiations with hyperscalers" framing

[3] [stockanalysis.com — OKE quote and statistics](https://stockanalysis.com/stocks/oke/) — retrieved 2026-05-10 — price, market cap, EV, multiples, yield, short interest

[4] [ONEOK September 2025 Investor Presentation (PDF)](https://ir.oneok.com/~/media/Files/O/ONEOK-IR-V3/events-presentation/09-2025-investor-update.pdf) — retrieved 2026-05-10 — basin footprint, processing capacity, NGL pipeline asset detail, fee-based contract mix

[5] [PR Newswire — ONEOK completes EnLink acquisition (Jan 31, 2025)](https://www.prnewswire.com/news-releases/oneok-announces-completion-of-strategic-enlink-midstream-acquisition-302365348.html) — retrieved 2026-05-10 — Louisiana asset additions

[6] [PR Newswire — Eiger Express FID](https://www.prnewswire.com/news-releases/eiger-express-pipeline-reaches-final-investment-decision-to-transport-growing-natural-gas-production-from-the-permian-basin-to-the-gulf-coast-region-302537206.html) — retrieved 2026-05-10 — JV partners, capacity, ISD

[7] [EIA April 2026 Short-Term Energy Outlook (PDF)](https://www.eia.gov/outlooks/steo/pdf/steo_full.pdf) — retrieved 2026-05-10 — Permian production, LNG export trajectory, gas-burn forecasts

[8] [East Daley — Data Centers could add 6 Bcf/d to gas demand](https://eastdaley.com/the-burner-tip/data-centers-could-add-6-bcf-d-to-gas-demand-eda-forecast) — retrieved 2026-05-10 — base-case 6 Bcf/d incremental DC gas demand by 2030

[9] [Data Center Frontier — Crusoe 4.5 GW gas Abilene](https://www.datacenterfrontier.com/hyperscale/article/55276169/crusoe-adds-45-gw-natural-gas-to-fuel-ai-expands-abilene-data-center-to-12-gw) — retrieved 2026-05-10 — Stargate Abilene gas plant scope; OKE not listed as supplier

[10] [Data Center Dynamics — Stargate Abilene 360.5 MW gas plant filing](https://www.datacenterdynamics.com/en/news/natural-gas-plant-planned-for-stargate-ai-data-center-campus-report/) — retrieved 2026-05-10 — gas drawn from Atmos Pipeline-Texas, not OKE

[11] [Utility Dive — GE Vernova gas turbine backlog hits 100 GW](https://www.utilitydive.com/news/ge-vernova-gas-turbine-backlog-hits-100-gw-as-prices-rise/818332/) — retrieved 2026-05-10 — backlog growth, lead-time commentary

[12] [Enlit — Siemens Energy record gas turbine orders](https://www.enlit.world/library/siemens-energy-boasts-record-gas-turbine-orders-in-response-to-demand-boom) — retrieved 2026-05-10 — €146B backlog, DC share

[13] [Utility Dive — Mitsubishi gas turbine capacity expansion](https://www.utilitydive.com/news/mitsubishi-gas-turbine-manufacturing-capacity-expansion-supply-demand/759371/) — retrieved 2026-05-10 — sold out into 2028, doubling capacity

[14] [PJM Inside Lines — 811 projects / 220 GW reformed queue](https://insidelines.pjm.com/over-800-new-generation-projects-seek-to-connect-under-pjms-reformed-process/) — retrieved 2026-05-10 — interconnect queue and timeline

[15] [Latitude Media — ERCOT large-load queue quadruples](https://www.latitudemedia.com/news/ercots-large-load-queue-has-nearly-quadrupled-in-a-single-year/) — retrieved 2026-05-10 — queue size and energization rate

[16] [Power Magazine — FERC June 2026 deadline on large-load rules](https://www.powermag.com/ferc-sets-june-deadline-to-rewrite-large-load-grid-rules-for-ai-era-power-demand/) — retrieved 2026-05-10 — co-location regulatory pivot

[17] [Astute Group — NVIDIA 60% CoWoS share (Morgan Stanley)](https://www.astutegroup.com/news/industrial/advanced-packaging-demand-soars-nvidia-secures-60-of-cowos-capacity/) — retrieved 2026-05-10 — TSMC capacity, NVIDIA allocation

[18] [SemiAnalysis — The Great AI Silicon Shortage](https://newsletter.semianalysis.com/p/the-great-ai-silicon-shortage) — retrieved 2026-05-10 — CoWoS-L bottleneck framing; CPO supply chain

[19] [TrendForce — SK hynix ~2/3 of NVIDIA HBM4 allocation](https://www.trendforce.com/news/2026/01/28/news-sk-hynix-reportedly-to-supply-about-two-thirds-of-nvidia-hbm4-samsung-targets-early-delivery/) — retrieved 2026-05-10 — HBM share

[20] [Power Magazine — Transformer / switchgear shortage 2026](https://www.powermag.com/transformers-in-2026-shortage-scramble-or-self-inflicted-crisis/) — retrieved 2026-05-10 — lead times

[21] [Fortune — AI DCs and electrician shortage (Brad Smith)](https://fortune.com/2026/03/02/ai-data-centers-electrician-shortage-gen-z-training-careers/) — retrieved 2026-05-10 — Microsoft framing electrician constraint as #1 problem

[22] [Introl — US data center construction first drop since 2020](https://introl.com/blog/us-data-center-construction-drop-first-since-2020) — retrieved 2026-05-10 — 5.7% under-construction decline 2025

[23] [Pipeline & Gas Journal — Waha negative for record stretch April 2026](https://pgjonline.com/news/2026/april/permian-constraints-keep-waha-gas-prices-negative-for-record-stretch-as-us-markets-weaken) — retrieved 2026-05-10 — Permian takeaway constraint and basis

[24] [Motley Fool — Kinder Morgan Q1 2026 transcript](https://www.fool.com/earnings/call-transcripts/2026/04/22/kinder-morgan-kmi-q1-2026-earnings-transcript/) — retrieved 2026-05-10 — Trident, SSE4, Mississippi Crossing, 10 Bcf/d new gas-fired demand exposure

[25] [Motley Fool — Williams Q1 2026 transcript](https://www.fool.com/earnings/call-transcripts/2026/05/05/williams-wmb-q1-2026-earnings-transcript/) — retrieved 2026-05-10 — Power Express, Atlas, Neo, Southside DC project stack

[26] [Energy Transfer / CloudBurst PR](https://ir.energytransfer.com/news-releases/news-release-details/energy-transfer-and-cloudburst-sign-agreement-natural-gas-supply) — retrieved 2026-05-10 — first marquee BTM hyperscaler-adjacent gas contract (1.2 GW, 10-yr)

[27] [NGI — EQT 4.4 GW PA AI campus deal](https://naturalgasintel.com/news/eqt-snags-two-natural-gas-supply-contracts-including-for-massive-44-gw-ai-campus-in-pennsylvania/) — retrieved 2026-05-10 — Appalachian E&P direct-to-DC supply

[28] [PR Newswire — Eiger Express expansion to 3.7 Bcf/d](https://www.prnewswire.com/news-releases/eiger-express-pipeline-capacity-expansion-302624158.html) — retrieved 2026-05-10 — capacity expansion

[30] [RBN Energy — ONEOK Sun Belt Connector to Phoenix](https://rbnenergy.com/daily-posts/blog/oneok-launches-open-season-proposed-refined-products-pipeline-phoenix) — retrieved 2026-05-10 — Phoenix corridor (refined products, not gas)

[31] [Hart Energy — ONEOK/MPLX Permian NGL "wellhead-to-water" JV](https://www.hartenergy.com/exclusives/oneok-mplxs-wellhead-water-deal-dominates-permian-ngl-race-212567) — retrieved 2026-05-10 — Mont Belvieu / NGL export economics

[32] [CME Group — Mont Belvieu surges in significance amid record US NGL exports](https://www.cmegroup.com/openmarkets/energy/2026/Mont-Belvieu-Surges-in-Significance-Amid-Record-US-NGL-Exports.html) — retrieved 2026-05-10 — NGL export thesis context