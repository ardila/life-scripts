# CMC — Commercial Metals Company (NYSE: CMC)

## Where this sits in the AI stack
CMC physically sells **rebar (concrete reinforcement) and merchant bar** produced at four electric-arc-furnace (EAF) "micro mills" in the U.S. plus a Polish mill, fabricated downstream into cut-and-bent assemblies, and — since December 2025 — **precast concrete products** via the $1.84B Foley + CP&P acquisitions [21][8][3]. In the AI stack, this sits **two physical layers below silicon**: rebar reinforces the foundations, slabs and walls of the buildings that house the racks. CMC does not touch silicon, packaging, networking, cooling fluid, or runtime software — its AI exposure is mediated entirely through hyperscale data-center *construction* in its Mid-Atlantic and South-Central footprint [3][7]. This is a domestic-tariff-protected commodity producer with a real but indirect AI tailwind, not a technology supplier.

## Snapshot
- **Price:** $70.52 (2026-05-08 close) [2]
- **Market cap:** $7.87B [1]
- **52-week range:** $45.49 – $84.87 [2]
- **Forward P/E:** 10.9× (on FY consensus EPS ~$6.50) [1]
- **EV / TTM revenue:** 1.31× ($10.97B EV / $8.01B revenue) [1]
- **Consensus 12-month price target:** ~$80 (≈ +13% from spot; range $69–$92 across 10–20 analysts) [public.com][marketbeat]
- **YTD total return:** n/a — could not source clean YTD figure with confidence; stock is mid-range vs. its 52-week band [2]
- **Short interest (% of float):** 5.83% [1]
- **Dividend yield:** 1.13% [1]
- **Net debt / EBITDA:** ~2.7× pro-forma post-Foley/CP&P, target <2.0× within 18 months [21]

## Moat — what it is physically made of
The "moat" here is **not technological**. CMC has no proprietary kernel library, no patented packaging process, no fabric. Decomposing it honestly:

1. **Geography (durable, ~5–10 yr).** CMC's mill and fabrication footprint is densest in the Mid-Atlantic (especially Virginia/Carolinas) and South-Central U.S. (Texas, Oklahoma, Arkansas). These overlap directly with "Data Center Alley" (Loudoun County, ~70% of global IP traffic) and the new Texas/Georgia hyperscale corridors [3][7]. Rebar has a **delivered-cost radius of ~250–500 miles** because freight on a low-value-density commodity erodes the margin — an Indiana mill cannot economically serve a Northern Virginia foundation pour. This is a real moat but one any competitor with mills in the same states (Nucor, Gerdau, Steel Dynamics, Cascade Steel) shares.

2. **Vertical integration into fabrication (durable, structural).** ~60% of CMC's rebar tonnage is sold through its own fab shops, where bars are cut, bent, tagged and delivered to the jobsite in install-ready bundles [17]. Fabrication is labor-intensive, low-margin (~mid-single-digit EBITDA on standalone) and **the actual scarce input** — skilled rodbusters, project schedulers, and BIM-integrated fab software. This is where CMC's "downstream bid volume" leading indicator comes from [3]. Replication cost: low capital, high labor/relational; meaningful but not exclusive.

3. **Tariff wall (policy-dependent, 1–5 yr).** April 6, 2026 Section 232 imposed a flat **50% tariff on full customs value** for steel articles in HTS Ch. 72/73, including rebar [9]. Department of Commerce preliminary antidumping/CVD on rebar from Bulgaria (~50%) up to Algeria (~200%) provides ~5-year enforcement window subject to final determinations [3]. This is real and substantial but **policy is the moat, not the company** — a future administration can roll either back.

4. **Capital intensity at the asset (durable).** Four Danieli MIDA QLP micro mills (TX, AZ, AZ-2, WV) at $300M–$450M each represent ~$1.5B+ in modern, scrap-flexible, low-emission EAF capacity not easily greenfielded [19]. The Arizona-2 mill is the world's first MIDA capable of producing both rebar *and* merchant sections in continuous endless-cast mode at 500ktpy [19]. The technology isn't proprietary to CMC — Danieli sells it to anyone — but the build cycle is 3–4 years.

5. **Precast platform (recent, untested).** Post-Foley, CMC is the **#3 U.S. precast operator** with 35 facilities across 14 states [21]. Precast is more spec-driven than rebar — modular utility vaults, transformer pads, dry-utility structures used "heavily in data center construction" per management [3]. This is the only piece of the moat with a genuine product-mix story tied to AI; it is also unproven (closed Dec 2025).

There is **no software moat, no developer ecosystem, no training-platform lock-in**. Calling this an "AI infrastructure name" is a marketing frame; the underlying business is electric-arc steelmaking with policy-protected pricing.

## AI buildout bottleneck map
Ranking the actual gating constraints over the next 24 months and where CMC sits on each:

| Bottleneck | Severity | CMC role |
|---|---|---|
| **High-voltage transformers / grid-tie** | Severe — 120–210 wk lead times, prices +79%; LPTs >100 MVA the binding constraint [techinvestments.io] | Indifferent — does not produce |
| **Gas turbines (behind-the-meter power)** | Severe — GE Vernova backlog $163B, slots sold out into 2030 [Power-Eng][11] | Indifferent — but precast utility structures may catch some site-power adjacent spend [3] |
| **CoWoS-L advanced packaging** | Severe — Nvidia booked ~60% of TSMC's 2026 wafer-equivalent CoWoS allocation; oversubscribed through 2026 [10] | Indifferent |
| **HBM3e supply** | Severe — Micron supplying ~½–⅔ of demand; ~3× wafer intensity vs. DDR5 [10] | Indifferent |
| **Liquid cooling at >100 kW/rack** | Tightening — GB200 racks at 120 kW driving CDU/manifold demand | Indifferent |
| **Electrical contractor / skilled trades** | Tightening — particularly in data-center metros | **Adjacent** — competes for same labor pool for rebar install crews |
| **Rebar / structural steel supply** | **Not binding** — North American capacity additions are "manageable at current levels" per CMC mgmt itself [3]; rebar market growth guided to "1–3%" [3] | **Beneficiary, not constraint owner** |
| **Cement / concrete** | Tightening regionally; ~1Mt cement needed for U.S. data centers by 2028 per WEF [13] | **Direct supplier via precast** |

The honest read: CMC is a *beneficiary* of AI capex flowing through to construction, but it is not the binding constraint. The buildout is gated by power and silicon, not foundations. If transformer/turbine slots stretch, **rebar demand could be backlog-bound for years even if AI capex commitments stay strong** — but the implied volume growth still doesn't make CMC a constraint owner. The company itself has stated rebar supply/demand is "in a relatively balanced place" [3].

## Competitive teardown
**Nucor (NUE).** The most important competitor and the one frequently confused with CMC. Nucor claims it supplies **>95% of the steel products used in data center construction** [Nucor case study][6] — but this is structural steel (beams, joists, decking, pre-engineered buildings), not rebar. Nucor's CEO described data-center demand as "white hot" with backlog +40% YoY [4][5]. On rebar specifically, Nucor and CMC are roughly co-leading the U.S. market [17]. **Already at parity on rebar pricing power** — June 2025 saw NUE/CMC/Gerdau jointly announce a $60/ton increase, and a further $150–200/ton step-up in early 2026 stuck [16][3]. Nucor has the broader AI-construction franchise (the building itself); CMC has rebar density in the right zip codes.

**Steel Dynamics (STLD).** ~4.6Mt long-products capacity, supplies beams/structurals/rebar to the same end markets; Q4 2025 backlog +38% YoY through Oct 2026 [STLD][20]. Like Nucor, more diversified into structurals than CMC — STLD also has a flat-rolled (sheet) franchise CMC lacks entirely.

**Gerdau Long Steel North America.** Joined the June 2025 price increase with NUE/CMC, signaling stable oligopolistic discipline among the four U.S. rebar producers [16]. Brazilian-parent, slightly less domestic-tariff-protected.

**Substitution risk: FRP rebar.** Glass-fiber-reinforced polymer rebar is gaining specification share in data centers specifically because of its **non-magnetic, RF-transparent properties** (relevant for high-frequency signal integrity near racks and for hospitals/MRI rooms) [12]. Per industry sources, FRP carries 30–40% upfront cost premium but 25–30% lower 50-year TCO [12]. Adoption is small today but the workload-specific case for data centers is genuine, not generic. This is an axis worth watching — it is the only place where AI workload characteristics could *physically* push demand away from steel rebar.

**Imports.** With Section 232 at 50% on full customs value plus rebar-specific AD/CVD of 50–200% on key origins, imports are a non-factor for the next 1–3 years barring a policy reversal [9][3].

The competitive picture: CMC is one of three to four credible domestic rebar/long-products oligopolists with disciplined pricing behavior. It has **no structural advantage over Nucor or STLD** other than geographic mix. Nucor in particular has the cleaner AI-construction story because of structural steel.

## Bull case — technical
For CMC to materially outperform from $70.52, the following technical conditions need to hold:

1. **AI data-center construction sustains 25%+ unit growth into 2027.** Nucor's 30% YoY square-footage forecast for 2026 is the right reference rate [4][5]. This requires hyperscaler capex commitments to translate into actual permitted, financed, ground-broken builds despite power constraints.
2. **Power bottleneck does not collapse the construction pipeline.** If GE Vernova turbines and grid transformers throttle starts, rebar demand is *backlog* but not pourings. Bull case requires power to lag-not-block: behind-the-meter gas, brownfield co-location, distributed UPS — keeping starts up even with grid tie-ins delayed.
3. **Tariff wall holds through 2027.** Section 232 50% + rebar AD/CVD must survive litigation and stay enforced. This is the single biggest input to domestic pricing power.
4. **Precast integration delivers >$30M synergies and pulls AI-spec content.** Foley/CP&P need to demonstrably win utility-vault and dry-utility-structure work tied to data-center sites [3]. The pivot from "we make rebar" to "we make data-center site-construction packages" needs to show in segment EBITDA growth.
5. **West Virginia mill ramps cleanly in June 2026.** 500ktpy of new rebar capacity into a Mid-Atlantic market within trucking distance of Loudoun County [19].

**Base rate caution.** Damodaran's framework on cyclicals is unambiguous: **a steel P/E of 6–8× is fair at the cycle peak; 11–15× is fair at the trough** [15]. Deep cyclicals routinely take 40–60% drawdowns when cycles roll over [Damodaran][15]. The current 10.9× forward suggests the market is treating this as *mid-cycle*, not peak. The bull thesis depends on AI being a **multi-year secular construction supercycle that breaks the historical 5-year commodity cadence** — possible (the 1996–2011 super-cycle ran 15 years on China industrialization) but the inference is doing heavy lifting.

If all of the above holds: $5.5–7B incremental construction TAM over 24 months → CMC capturing high-single-digit share → forward EPS $7+ → multiple holds at 12× → **$84–90 stock**. That is roughly the high end of the analyst range.

## Bear case — technical
A short-seller who understands the stack would write:

1. **Rebar is not a constrained input — by management's own admission.** "Supply and demand in a relatively balanced place... North American capacity increases are entering the market" [3]. Guided rebar market growth: **1–3%** [3]. Compare to the bull narrative of 30% data-center growth: the implication is that data centers are a small share of total rebar demand, with the rest (residential, infrastructure, commercial non-data-center) growing slowly or flat. The AI tailwind is a *mix* story dilution-bounded by the rest of construction.

2. **Q2 FY2026 missed EPS** [18]. Downstream bid volumes "remained at levels consistent with recent quarters" — i.e., **flat, not accelerating**, despite the "red hot" framing [3]. The EBITDA jump (+114% YoY) was driven heavily by the Foley/CP&P contributions ($40.3M EBITDA on $145M revenue [3]) — so two-thirds of growth is acquired EBITDA, not organic.

3. **The acquisition was levering INTO peak cycle earnings.** Net debt / EBITDA went to ~2.7× to fund a $1.84B precast deal at the same moment management is calling data-center demand "red hot" — i.e., paying near-peak multiples on near-peak EBITDA [21]. This is the textbook commodity-company mistake. If steel margins compress, the leverage is on a smaller base.

4. **Nucor has the better data-center franchise.** Their "95% of data-center steel" framing is structural steel — the building itself, joists, decking — not rebar. The actual marquee AI-construction supplier is Nucor; CMC is the picks-and-shovels-of-picks-and-shovels [6]. If you wanted unit-level AI steel exposure, NUE > STLD > CMC.

5. **FRP substitution is a real long-tail risk specifically in data centers** because of EMI/RF-transparency advantages [12]. Adoption is small now but the fundamental physics case for AI/data centers is clean.

6. **Power constraints could collapse the construction pipeline.** GE Vernova's 2030-out turbine slots and 5-year transformer lead times mean projects can be *announced* without being *built* [11][techinvestments.io]. Hyperscaler capex announcements ≠ rebar pourings.

7. **Tariff reversal risk.** A future administration unwinding Section 232 or losing AD/CVD final determinations would compress domestic pricing power within quarters [9].

8. **Cycle math.** At 10.9× forward, you are paying mid-cycle multiples. Historical cyclical bear cases see 40–60% drawdowns [15]. If steel volumes flatten and metal margins compress 20%, FY2027 EPS could revert to $4–4.50 → at a trough multiple of 14× → **$55–65 stock**. The tail is wider on the downside.

## Market view check
At $70.52, ~10.9× forward EPS, 1.3× EV/Sales, 10.4× EV/EBITDA, with a consensus PT around $80, the market is treating CMC as a **mid-cycle commodity name with an AI sweetener**, not as a structural growth name. That looks roughly fair given the technical reality: real demand tailwind from data-center construction in the right geographies, but no proprietary technology, no constraint ownership, levered acquisition timing, and a competitor (Nucor) with a cleaner thesis. The market is implicitly assuming the AI cycle elongates the commodity cycle rather than amplifies the eventual rollover; **this is the assumption to interrogate**. If you believe the AI buildout is a 7–10 year super-cycle (rather than 3–4), CMC is reasonably priced and re-rates at $85–95. If you believe the standard 5-year commodity cadence holds, the multiple compresses to 6–8× FY27 trough EPS and the stock is exposed.

## 90-day falsifiers
- **CMC fiscal Q3 2026 earnings (~late June 2026):** Downstream bid volume Y/Y change is the cleanest tell. >+5% supports bull; flat-to-negative supports bear given AI narrative [3].
- **West Virginia mill startup (June 2026):** First production date, ramp curve, and any commissioning delays. Slip beyond Q3 calendar = execution risk realized [19].
- **Nucor / Steel Dynamics Q2 calendar earnings (July 2026):** Are competitors growing faster than CMC on data-center-exposed segments? Compare YoY backlog growth and structural-steel order intake.
- **Final DOC antidumping/CVD determinations on rebar imports (mid-2026):** Final rates ≥80% of preliminary supports bull; meaningful reductions or carve-outs supports bear [3].
- **Section 232 implementation rulings (post April 6, 2026):** Customs enforcement intensity, derivative-product classifications, and any tariff exclusions granted [9].
- **Rebar spot pricing trajectory:** The recent $150–200/ton increase needs to *stick* through Q3. If service-center inventories rebuild faster than data-center pours absorb, pricing rolls back.
- **Hyperscaler Q1/Q2 2026 capex commentary:** Microsoft, Meta, Google, Amazon — sequential capex guide changes >10% would update the underlying demand signal.
- **GE Vernova / Eaton / Vertiv order books:** These are *upstream* of CMC by 6–12 months. Order softening at the power-equipment layer telegraphs construction softening at the rebar layer.

## What I could not verify
- **Exact % of CMC revenue from data-center construction.** Management cites strength but does not disaggregate. My read is mid-to-high single digits with rapid growth, but this is inference, not disclosure [3].
- **Tons of rebar per MW of AI data-center capacity.** Public sources cite "up to 20,000 tons of steel per hyperscale facility" [13] but conflate structural and reinforcing steel; no clean per-MW rebar coefficient was sourceable.
- **CMC's contracted backlog with any specific named hyperscaler.** No disclosure; competitive sensitivity expected.
- **FRP rebar share of data-center spec today.** Anecdotal evidence of growing adoption [12] but no quantified share or trajectory.
- **CMC's clean YTD 2026 total return as of 2026-05-08.** Could not pin a precise figure with confidence — sources show price level but not opening-of-year benchmark consistently.
- **Synergy realization timeline for Foley/CP&P beyond management's $25–30M Y3 target.** Untested; deal closed Dec 2025 [21].
- **Whether CMC's precast utility-structure SKUs are currently spec'd into named data-center projects** versus general-purpose municipal/utility work.

## Sources
[1] https://stockanalysis.com/stocks/cmc/statistics/ — retrieved 2026-05-10 — current valuation, EV, P/E, short interest, dividend, beta, market cap as of 2026-05-08 close.
[2] https://finance.yahoo.com/quote/CMC/ — retrieved 2026-05-10 — price ($70.52), 52-week range, recent close.
[3] https://www.insidermonkey.com/blog/commercial-metals-company-nysecmc-q2-2026-earnings-call-transcript-1726214/ — retrieved 2026-05-10 — Q2 FY2026 transcript: data-center "red hot" framing, Mid-Atlantic/South Central positioning, downstream bid volumes flat, rebar supply/demand "balanced," 1–3% growth guide, AD/CVD detail, precast EBITDA, WV mill timing.
[4] https://www.steelmarketupdate.com/2025/10/31/nucor-targets-white-hot-data-center-boom/ — retrieved 2026-05-10 — Nucor 30% data-center sq-ft growth forecast 2026, "white hot" demand, "tsunami of earnings power."
[5] https://www.constructiondive.com/news/nucor-q3-2025-earnings-data-center-buildouts/804149/ — retrieved 2026-05-10 — Nucor Q3 2025 results, data-center buildout thesis.
[6] https://nucor.com/madeforgood/data-center-case-study — retrieved 2026-05-10 — Nucor's claim of supplying >95% of data-center steel products.
[7] https://www.argusmedia.com/en/news-and-insights/latest-market-news/2806536-data-centers-drive-long-steel-demand-cmc — retrieved 2026-05-10 — CMC management on data-center demand driver, geographic positioning.
[8] https://www.prnewswire.com/news-releases/commercial-metals-completes-acquisition-of-concrete-pipe--precast-llc-302629532.html — retrieved 2026-05-10 — CP&P acquisition close.
[9] https://www.whitecase.com/insight-alert/united-states-modifies-steel-aluminum-and-copper-section-232-tariffs — retrieved 2026-05-10 — April 6, 2026 Section 232 50% on full customs value; HTS 72/73 coverage.
[10] https://www.fusionww.com/insights/blog/inside-the-ai-bottleneck-cowos-hbm-and-2-3nm-capacity-constraints-through-2027 — retrieved 2026-05-10 — CoWoS-L oversubscription, Nvidia 60%+ of TSMC 2026 capacity, HBM3e supply gap.
[11] https://www.power-eng.com/gas/turbines/data-centers-drive-record-surge-in-ge-vernova-power-equipment-orders-as-turbine-slots-tighten-through-2030/ — retrieved 2026-05-10 — GE Vernova $163B backlog, gas-turbine slots into 2030.
[12] https://composite-tech.com/2025/11/05/why-frp-rebar-is-replacing-steel-in-u-s-infrastructure-projects/ — retrieved 2026-05-10 — FRP rebar adoption rationale: non-magnetic, RF-transparent, data-center fit.
[13] https://www.weforum.org/stories/2025/12/securing-data-centre-materials/ — retrieved 2026-05-10 — material-intensity of data centers, ~1Mt cement to 2028, 60–75 t minerals/MW.
[14] https://spectrum.ieee.org/5gw-data-center — retrieved 2026-05-10 — 5GW campus engineering challenges, structural-load implications.
[15] https://pages.stern.nyu.edu/~adamodar/pdfiles/papers/commodity.pdf — retrieved 2026-05-10 — Damodaran framework on valuing cyclicals; P/E of 6 at peak vs 15 at trough; 40–60% peak-to-trough drawdowns.
[16] (industry coverage of June 2025 NUE/CMC/Gerdau $60/ton rebar increase, also covered in [3]) — retrieved 2026-05-10 — oligopolistic pricing discipline among U.S. rebar producers.
[17] https://www.mordorintelligence.com/industry-reports/steel-rebar-market — retrieved 2026-05-10 — U.S. rebar market structure, CMC/Nucor/STLD positions, fab-shop integration economics.
[18] https://www.investing.com/news/transcripts/earnings-call-transcript-commercial-metals-q2-2026-misses-eps-forecasts-93CH-4583067 — retrieved 2026-05-10 — Q2 FY2026 EPS miss vs. consensus.
[19] https://www.danieli.com/en/news-media/news/cmc-orders-its-fourth-danieli-mida-qlp-minimill_37_798.htm — retrieved 2026-05-10 — Berkeley County WV 4th MIDA mill specs, 500ktpy capacity.
[20] https://lpg.steeldynamics.com/ — retrieved 2026-05-10 — STLD long-products ~4.6Mt capacity; product overlap with CMC.
[21] https://dallasinnovates.com/concrete-mega-deal-irvings-commercial-metals-to-acquire-foley-products-co-for-nearly-2-billion/ — retrieved 2026-05-10 — Foley $1.84B acquisition; #3 U.S. precast platform; 35 facilities, 14 states; 2.7× pro-forma leverage; <2.0× target in 18 months.
[22] https://ir.cmc.com/cmc-reports-first-quarter-of-fiscal-2026-results/ — retrieved 2026-05-10 — Q1 FY2026 net earnings $177.3M, $1.58/sh; precast outlook tied to Mid-Atlantic/SE data-center demand.