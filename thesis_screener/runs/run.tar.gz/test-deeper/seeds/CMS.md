# CMS — CMS Energy Corporation (NYSE: CMS)

## Where this sits in the AI stack
The power layer — specifically, a vertically-integrated regulated electric utility (Consumers Energy) serving Michigan's Lower Peninsula, plus a smaller natural gas LDC business. CMS does not touch silicon, packaging, networking, cooling hardware, or any compute software. It sells regulated kWh to whoever sites load inside its service territory. For AI, the relevant business is bulk grid power delivery to hyperscale and colocation data center campuses on 15-year, take-or-pay contracts under a newly approved large-load tariff [6][7]. Workload-agnostic — training, inference, and offline batch all look the same to a substation.

## Snapshot
- **Price:** $72.61 (2026-05-08 close) [4]
- **Market cap:** $22.43B [4]
- **52-week range:** $67.71 – $80.36 [4]
- **Forward P/E:** 18.2× on FY26 adj. EPS guidance midpoint of $3.865 [4][3]
- **EV / NTM revenue:** n/a — not the right metric for a regulated utility; rate-base growth (10.5% CAGR to 2030) and P/B are what drive valuation [3]
- **Consensus 12-month price target:** ~$80.69–$81.50 (implied +11–12% from price) [3][11]
- **YTD total return:** ‑1.1% price (≈ +0.4% including dividend, rough) [4]
- **Short interest:** 2.84% of float [5]
- **Dividend yield:** 3.14% ($2.28 annualized; 20th consecutive annual raise) [3][4]

## Moat — what it is physically made of
Forget the CUDA-style framing. A utility moat is not software or talent — it is **regulatory** and **physical**, and the two are entangled. Decompose:

1. **State-granted franchise.** Consumers Energy holds an exclusive certificate to distribute electricity in its Lower Peninsula territory. Michigan caps retail open access ("Electric Choice") at 10% of utility load, and those slots have been fully subscribed for years. A hyperscaler that sites inside CMS's territory cannot legally buy retail power from anyone else; it can only (a) take service from CMS, or (b) build behind-the-meter generation. This is the bedrock layer of the moat and is, in practice, unreplicable on any normal investment horizon.
2. **Physical interconnect and ROW.** Distribution wires, substations, the 138/345 kV transmission interface to MISO. Even a BTM project still needs CMS interconnection for redundancy unless it goes fully off-grid (rare for hyperscalers who need 99.999% uptime).
3. **Generation portfolio.** Owned: Covert (1,176 MW combined cycle gas, acquired June 2023) [8], Zeeland, Karn 3/4, plus wind/solar. Planned: two new gas plants totaling 1.5 GW — Karn (Bay County, 500 MW) and Thetford (Genesee County, 1,000 MW) — both targeting in-service 2031 [8].
4. **Regulatory cost-recovery framework, with a new AI-specific weapon.** In November 2025, the MPSC approved Consumers Energy's new large-load tariff (Rate GPD) — Michigan's first — applying to any customer ≥100 MW (or aggregated 100 MW with ≥20 MW sites under common ownership). Headline terms: **15-year contract, 80% minimum demand take-or-pay**, and explicit ratepayer protection so non-DC customers don't subsidize DC infrastructure [6][7]. This is the single most important structural element in the AI thesis. It does two things: (i) externalizes demand risk back onto the hyperscaler, (ii) makes BTM bypass economically painful since the 80% floor is owed regardless.
5. **Siting / permitting expertise.** Townships, MDEQ permitting, MPSC certificate-of-need — utility relationships with these counterparties are decades-deep. Hyperscalers learned this the hard way in Saline Township, where DTE's $7B Stargate approval drew sustained local opposition [10].

**Durability per component:** (1) and (2) are 20+ year moats absent a state-legislative shock. (4) is freshly cemented and has been litigated by ratepayer advocates and survived; the precedent now exists [6]. (3) is generic — anyone can build generation, the bottleneck is turbines (see below). (5) is meaningful but not unique to CMS.

**What this moat is not:** it is not a technology moat. It can be eroded only by regulatory action (Michigan legislature lifting the retail choice cap or carving out an AI exemption) or by economic substitution (BTM build-out scales faster than the take-or-pay penalty). Neither is imminent, both are tail risks.

## AI buildout bottleneck map

| Bottleneck | Status (2026) | CMS posture |
|---|---|---|
| **GE Vernova heavy-frame gas turbines** | 80 GW backlog; sold out through 2029, likely through 2030 by end-2026; lead times 3–7 yrs [9] | Beneficiary if turbines already ordered for Karn/Thetford (2031 ISD implies orders placed); exposed if not |
| **MISO interconnection queue** | 2025-cycle projects won't reach GIA until ~2029; Michigan in MISO Zone 7 [12] | Advantaged — new capacity is on brownfield CMS sites with existing interconnection rights |
| **Lower Peninsula HV transmission** | Limited imports across the Straits and from PJM; constrained [12] | Exposed — load growth without local generation forces transmission upgrades that hit ratepayers |
| **Palisades nuclear restart (800 MW)** | Owned by Holtec, not CMS; restart delayed to early/mid 2026, still uncertain [13] | Exposed customer / potential offtaker — not operator. Upside if it runs; no direct ownership economics |
| **Holtec SMR-300 (two units, 340 MW each) at Palisades site** | NRC license application filed Jan 2026 [13] | Indirect beneficiary — extra firm carbon-free capacity in territory in mid-2030s, no equity stake disclosed |
| **CoWoS-L / HBM3e / optical / liquid cooling >100kW** | Compute-stack bottlenecks | Indifferent — does not affect electron delivery |
| **Electrical contractor / switchgear lead times** | 12–18 month switchgear, tight contractor labor | Indirect — affects timeline but cost flows through to customer under Rate GPD |

The net: CMS is well-positioned on the bottlenecks that matter for its layer (generation siting + interconnection) and indifferent to compute-stack bottlenecks. The one structural risk is gas turbine slippage — if GE Vernova pushes Karn/Thetford ISD from 2031 to 2032/33, CMS may have load it cannot serve, and that load will look for BTM solutions.

## Competitive teardown
The competitive landscape splits along two axes: (A) other ways to serve Michigan load, and (B) other ways for AI capital to flow that don't involve a Michigan regulated utility at all.

**A. Same-territory alternatives:**
- **DTE Energy (southeast Michigan).** Not a head-to-head competitor — service territories don't overlap. DTE got Stargate (1.4 GW for OpenAI/Oracle, $7B, Saline Township) because it sat in DTE territory [10]. DTE has disclosed ~7 GW total data center pipeline, ~3 GW advanced [10]. The relevant comparison is not "who wins the contract" but "which utility's load-growth trajectory the market is pricing more aggressively." DTE got its tariff approved Dec 2025; CMS got its tariff approved Nov 2025 [6][7]. Roughly parity.
- **MISO-region IPPs (Vistra, NRG, Constellation).** Don't have meaningful Lower Peninsula generation. Could in theory build, but the same MISO queue + turbine constraints apply, plus they'd need a willing offtaker outside the franchise utility — currently structurally hard in Michigan.

**B. Bypass routes (the real threat axis):**
- **Behind-the-meter natural gas.** A hyperscaler can in principle build its own gas plant on-site and bypass CMS retail. The 80% take-or-pay tariff was specifically designed to make this expensive. Lead time for non-prioritized gas turbines is now 3–7 years [9], comparable to a utility build; the bypass route has no clear speed advantage anymore.
- **Behind-the-meter / co-located nuclear (Talen-Amazon, Constellation-Microsoft, Vistra-Meta model).** Has scaled in PJM where the Susquehanna, TMI, and Comanche Peak deals stack to ~5+ GW [14]. FERC's Dec 2025 unanimous order directed PJM to establish colocation rules with three new transmission service options [14]. Critically, **this is a PJM ruling; MISO has not adopted it**, and Michigan has no operating nuclear plant inside CMS's service territory that a hyperscaler could colocate to. Palisades is the candidate but it's Holtec-owned and the restart is unproven [13]. So the Talen-style precedent does not transplant cleanly to Michigan in the next 24 months.
- **State legislative bypass.** Michigan legislature could lift the 10% retail choice cap or carve out AI loads. This is the single biggest non-financial risk; I see no evidence it is being seriously contemplated, but Saline Township-style local political opposition could push the other way and either tighten the screws on utilities (rate-case-unfriendly) or open up BTM pathways.

**Honest parity check:** On the axis of "regulatory certainty + pre-approved cost recovery for AI load," CMS, DTE, AEP (Ohio), Dominion (Virginia), Entergy (Louisiana), and Southern (Georgia) all have working frameworks now. CMS is not uniquely advantaged here — it's a participant in a broad cycle. What is moderately distinctive is the **early November 2025 tariff approval** with explicit 80% take-or-pay, which is a tighter customer lock-in than several peer states' Q1 2026 rulings.

## Bull case — technical
For CMS to outperform the utility median over 12–24 months, the following technical conditions need to hold:

1. **Pipeline-to-contract conversion.** The 9 GW pipeline is the headline number; on Q1 2026 the company described "1–2 GW in final-stage negotiations, 4–5 GW in advanced discussions" [1]. Bull case: at least 2 GW signs to firm contracts in the next 12 months. Even 1 GW at typical hyperscale load factor (~70%) is ~6 TWh/year — meaningful against ~38 TWh annual electric sales.
2. **Turbine deliveries hold.** Karn (500 MW) and Thetford (1,000 MW) ISD-2031 implies GE Vernova orders are placed; needs to stay on schedule. Bull = no slip beyond H1 2031.
3. **Rate-case constructiveness.** The $24B five-year capex plan supports the 10.5% rate-base CAGR [3]; that math only works if MPSC keeps approving recovery. Bull = no major disallowance through 2027.
4. **BTM remains a PJM phenomenon.** No precedent-setting BTM colocation deal closes in Michigan or broader MISO that materially undercuts the regulated-utility offering.
5. **Palisades and Holtec SMR optionality.** Restart succeeds in 2026 and provides 800 MW firm carbon-free in territory, making CMS's offering more attractive to ESG-sensitive hyperscalers without CMS bearing the build risk.

Connect to financials: 6–8% guided LTGR [3] re-rates toward the high end (7.5–8%) with multiple expansion from 18× to ~20× (Dominion-like) → ~$85–90 in 12 months, +17–24% total return.

**Base rate caveat.** Regulated utility "moats" are extremely durable in the franchise-renewal sense (50+ year half-life on territory rights) but mediocre on multiple expansion — historically utilities trade in 14–18× and re-rate only during structural demand-growth episodes. The 1995–2000 capex cycle (gas turbines for the dot-com era) saw utility P/Es expand modestly then mean-revert; the 2010s renewables cycle was lower-growth. The AI cycle is plausibly bigger than either, but **base rate for utility multiple expansion of >15% sustained is low** — call it ~25% over rolling 3-year windows historically.

## Bear case — technical
The honest short thesis a hardware-literate person would write:

1. **The pipeline is mostly LOIs, not contracts.** "Final-stage negotiations" is utility-speak that has historically converted at 30–50% within 18 months. The 9 GW number anchors expectations that are unlikely to be hit if AI capex moderates. The Q1 2026 transcript language was deliberately vague on what is signed [1].
2. **Take-or-pay is a ceiling, not just a floor.** 80% take-or-pay means CMS gets 80% revenue if usage falls — but the hyperscaler also won't sign for more than its committed-need plus some buffer, so the **15-year contract size is the cap**, and any AI capex pullback shows up as smaller signed nameplate, not lower utilization on big contracts.
3. **Saline-style opposition spreads.** Local opposition to DTE/Stargate has elevated political risk around big data-center rate-cases statewide [10]. Even if MPSC stays constructive, the *speed* of rate recovery could slow. Equity issuance (~$700M/year ATM in 2026) [3] combined with delayed rate-base recognition = dilution headwind.
4. **Gas turbine slip.** If GE Vernova pushes Karn/Thetford from 2031 to 2032+ [9], CMS misses the load window. Hyperscalers don't wait — they go BTM.
5. **FERC PJM precedent jumps to MISO.** The Dec 2025 FERC ruling on PJM colocation [14] is widely expected to be litigated up to MISO equivalents in 2026–27. If MISO adopts even a watered-down version, the BTM bypass option becomes credible inside Michigan within the bear's 24-month window.
6. **Palisades restart fails or further delays.** This removes the carbon-free baseload story and may push ESG-sensitive hyperscalers to BTM nuclear/SMR in PJM territory instead [13].
7. **Multiple compression.** Even if EPS grows 7%, the stock could de-rate to 16× if AI utility enthusiasm fades, putting it at $62.

## Market view check
At $72.61, 18.2× forward EPS [4], CMS trades roughly at the high-growth regulated-utility median — a ~10–15% premium to a "vanilla" Midwest utility (think pre-AI Ameren or Evergy at ~15–16×) and a modest discount to Dominion or AEP (which carry direct hyperscaler-state premia). YTD ‑1.1% [4] vs. the broader utility index modestly positive suggests the market has already partially priced *some* AI optionality but is no longer extrapolating linearly — the trade has cooled from Q1 2025 peaks.

What the market is implicitly believing: ~25–40% pipeline conversion (the implied excess over the rate-base growth that would be delivered without AI). That is below the company's optimistic framing but above the bear's "this is mostly LOIs" base rate. My read: the price is roughly fair given current information, with positive skew if Q2/Q3 brings >1 GW of signed contracts and negative skew if turbine or regulatory news disappoints. The market is **not** mispricing CMS for a sophisticated read of the technical stack; it's priced about where a careful read would put it. This is not a screaming long; it is a moderately attractive long with asymmetric event-driven upside in the next 90–180 days.

## 90-day falsifiers
1. **Q2 2026 earnings call (~late July 2026).** Listen for the **delta between "pipeline" and "signed contracts"** — specifically a number for GW under firm contract under Rate GPD. Any conversion >1.5 GW total = bull confirm. Any silence or hedged language = bear confirm.
2. **MPSC IRP filing (mid-2026).** The new IRP is the formal vehicle for the load-growth assumption [3]. If total 2031 generation additions land at the previously disclosed 1.5 GW gas + 13 GW renewables/storage [2] with no upward revision, demand growth confidence is weaker than the narrative suggests.
3. **GE Vernova Q2/Q3 2026 disclosures on heavy-frame turbine delivery schedules.** Any slip language (CEO commentary "we are tight on 2030–2031") that could affect Karn/Thetford ISD.
4. **Any MISO ruling or FERC action extending the PJM Dec 2025 colocation framework [14] to MISO.** Single most important regulatory event.
5. **Hyperscaler Q2 2026 capex prints (META, MSFT, GOOG, AMZN).** A coordinated >10% sequential capex cut would invalidate the demand premise across all AI-utility names, CMS included.
6. **Palisades restart status updates from Holtec / NRC** — concrete commercial operation date, or another delay [13].
7. **Michigan legislative session activity** on retail choice cap — any bill to expand the 10% cap would materially weaken the franchise component of the moat.

## What I could not verify
- The **identity** of the 1 GW hyperscaler contract publicly referenced — CMS has not disclosed; likely one of Microsoft, Meta, Amazon, Google given pipeline geography, but unconfirmed.
- The **signed vs. LOI breakdown** of the 9 GW pipeline. Management language in Q1 2026 was deliberately vague; insider monkey paraphrase suggests "one finalized" — could be a single ~1 GW deal or aggregated [1].
- Whether GE Vernova orders for Karn / Thetford are actually placed and slotted in the 2029–2030 production window, or are still pending — material to ISD risk.
- **Detailed cost-of-service terms** under Rate GPD (the $/MWh demand and energy charges); only structural terms (100 MW threshold, 15-yr, 80% take-or-pay) are public [6][7].
- **EV/NTM revenue** — not a standard utility disclosure; analyst services compute it inconsistently because of regulated revenue recognition. P/B (~2.4×) and EV/EBITDA (~11.5×) are more reliable comps and I'd want to verify those against latest 10-Q before relying on them.
- Whether Palisades 800 MW restart electricity is contracted to CMS, to a hyperscaler directly, or to MISO market — the Holtec disclosures I saw don't specify the offtake structure post-restart [13].
- **Specific large-load tariff revenue accretion mechanics** — how the 80% take-or-pay flows into CMS EPS (margin treatment, demand-charge vs. energy-charge split) was not in the materials I reviewed.

## Sources
[1] https://www.insidermonkey.com/blog/cms-energy-corporation-nysecms-q1-2026-earnings-call-transcript-1749931/ — retrieved 2026-05-10 — Q1 2026 transcript, established 9 GW pipeline and "final stage / advanced discussions" language.
[2] https://www.utilitydive.com/news/consumers-energy-campbell-large-load-earnings/805778/ — retrieved 2026-05-10 — $13B+ renewables/distribution plan, generation mix.
[3] https://seekingalpha.com/news/4548333-cms-energy-raises-2026-eps-guidance-to-3_83-3_90-as-24b-investment-plan-advances — retrieved 2026-05-10 — $3.83–$3.90 EPS guidance, $24B 5-yr plan, 10.5% rate-base CAGR, 6–8% LTGR, $700M ATM, $0.40 equity / $ capex ratio.
[4] https://stockanalysis.com/stocks/cms/ — retrieved 2026-05-10 — price $72.61, market cap $22.43B, forward P/E 18.21, 52-wk range, YTD -1.06%, dividend yield 3.14%, shares 308.92M.
[5] https://www.benzinga.com/insights/short-sellers/25/05/45609015/looking-into-cms-energys-recent-short-interest — retrieved 2026-05-10 — short interest 2.84% of float.
[6] https://www.michigan.gov/mpsc/commission/news-releases/2025/11/06/mpsc-approves-terms-of-service-between-consumers-energy-and-data-centers — retrieved 2026-05-10 — MPSC Nov 2025 order, Rate GPD, 100 MW threshold, 15-year, 80% take-or-pay.
[7] https://www.stocktitan.net/news/CMS/consumers-energy-defends-customer-protections-for-data-centers-bvv12gvt5nns.html — retrieved 2026-05-10 — corroborating detail on 100 MW tariff terms and customer-protection structure.
[8] https://www.crainsgrandrapids.com/news/energy/consumers-energy-to-seek-approval-for-2-natural-gas-plants-amid-data-center-proposals/ — retrieved 2026-05-10 — Karn 500 MW + Thetford 1,000 MW planned 2031; Covert 1,176 MW acquired 2023.
[9] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — GE Vernova 80 GW backlog, sold out to 2029–30, lead times 3–7 yrs, production ramp to 20 GW by mid-2026.
[10] https://bridgemi.com/michigan-environment-watch/michigan-regulators-approve-contract-for-michigans-first-hyperscale-data-center/ — retrieved 2026-05-10 — DTE/Stargate 1.4 GW Saline Township, $7B, OpenAI/Oracle/Related; local opposition.
[11] https://www.fool.com/earnings/call-transcripts/2026/04/28/cms-cms-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q1 2026 transcript corroboration, hyperscaler negotiations.
[12] https://cdn.misoenergy.org/20251209%20System%20Planning%20Committee%20of%20the%20BOD%20Item%2005%20Resource%20Adequacy%20and%20Generator%20Interconnection%20Queue%20Update730302.pdf — retrieved 2026-05-10 — MISO queue status, 2025-cycle GIA timing ~2029.
[13] https://www.ans.org/news/2026-04-02/article-7901/holtec-hits-milestones-in-palisades-restart-new-reactor-projects/ — retrieved 2026-05-10 — Palisades 800 MW restart status, Holtec SMR-300 license application Jan 2026.
[14] https://introl.com/blog/ferc-pjm-colocation-ruling-data-center-power-plant-guide-2025 — retrieved 2026-05-10 — FERC Dec 18 2025 unanimous order on PJM colocation, three new transmission service options, BTM reforms.