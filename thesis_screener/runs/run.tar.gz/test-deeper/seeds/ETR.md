# ETR — Entergy Corporation

## Where this sits in the AI stack
Entergy is a vertically integrated, state-regulated electric utility serving ~3M customers across Louisiana, Mississippi, Arkansas, southeast Texas, and New Orleans, within the MISO South footprint [1][2]. In the AI stack, ETR sits at the **electrons-to-the-substation** layer: it owns the generation fleet (~24 GW total, including ~5.4 GW of nuclear at Grand Gulf, Waterford 3, River Bend, and ANO 1/2 [3]), the high-voltage transmission, and the distribution wires that physically deliver power to hyperscaler load centers — most notably Meta's Hyperion campus in Richland Parish, LA, and AWS's three Mississippi campuses [4][5]. It does not touch silicon, packaging, optics, or software; it is the upstream substrate that the entire training/inference workload runs on top of, in a region with cheap gas (Haynesville/Permian) and tax-favorable hyperscaler economics.

## Snapshot
- **Price:** $111.59 (2026-05-08 close) [6]
- **Market cap:** $47.0B [6]
- **52-week range:** $79.40 – $118.23 [7]
- **Forward P/E:** 23.6× (on 2026 mid-point of management's reaffirmed adj. EPS guidance) [6][8]
- **EV / NTM revenue:** ~5.3× ($74.6B EV on ~$14B NTM revenue, growing from $12.95B FY25 at 8.5% retail CAGR) [9][10]
- **Consensus 12-month price target:** ~$121 (range $105–$135; Scotia raised to $129 on 2026-04-30, UBS to $135 on Meta-driven 2029 EPS hike) [11]
- **YTD total return:** ~+33% (inferred from $111.59 vs. ~$84 12/31/25 close implied by 90-day +24.5% and 1-yr +46.4% TSR) [12] — **inference, not directly sourced**
- **Short interest (% of float):** 3.7% (16.8M shares as of 3/31/26, +28.9% MoM) [11]
- **Dividend yield:** 2.3% ($2.56 annualized) [7]

## Moat — what it is physically made of
Calling this a "moat" the way one would describe CUDA is a category error, and an honest dossier should say so. Entergy's defensibility decomposes into five physically distinct components, each with different durability:

**1. State-granted service-territory monopoly (durable, 50+ year base rate).** The Louisiana, Mississippi, Arkansas, and Texas PSCs grant Entergy's operating subsidiaries exclusive certificates of public convenience and necessity over defined geographies. A hyperscaler wanting grid power in Richland Parish has exactly one counterparty. The historical base rate for franchise revocation in the U.S. since 1935 is effectively zero. **Most durable element.**

**2. Existing generation fleet and right-of-way (durable, 30–60 year asset life).** ~5.4 GW of nuclear (Grand Gulf 1,443 MW BWR; Waterford 3 1,152 MW PWR, +40 MW uprate fall 2026; River Bend 967 MW BWR; ANO 1/2 ~1,800 MW PWR combined [3]), plus a large legacy gas fleet, plus transmission ROWs across four states that cannot be re-permitted in under a decade. The cooling-water siting (Mississippi River, Atchafalaya, Red River) is itself a moat — closed-loop water rights for new thermal generation in the U.S. are now a binding constraint that ETR was grandfathered into.

**3. Locked-in turbine and transformer slots (durable for 5–7 years).** GE Vernova's gas-turbine backlog stretched to ~80 GW by end-2025 and will be sold out through 2030 by end-2026, with installed costs doubling from ~$1,000/kW to $2,000–2,500/kW in 15 months [13]. Large power transformer lead times sit at 128 weeks (GSUs 144 weeks), with a Wood Mackenzie-modeled 30% shortfall persisting [14]. Entergy has already committed orders against its $57B four-year plan; **a competing utility starting today cannot deliver Meta-class capacity before 2031**. This is the single most underappreciated technical component of the moat and the one most analogous to TSMC CoWoS-L allocation in the GPU stack.

**4. The "Fair Share Plus" regulatory framework (durable conditional on PSC composition).** This is the load-side innovation. Under the framework approved by the LPSC and acknowledged by MS/AR PSCs, hyperscalers pay 100% of incremental generation/transmission cost-of-service plus an allocated share of embedded fixed costs, backed by parent-company guarantees and explicit early-termination penalties [15][16]. Meta is paying 100% of the three 2.2 GW combined-cycle plants for Hyperion; the deal structure produces ~$5B in projected residential bill savings over 20 years [4][16]. The regulatory technology — long-term contracts with credit support sufficient to offset stranded-asset risk — is the actual financial moat. It is **less durable than #1 and #2** because it depends on (a) PSC composition and (b) hyperscaler credit quality holding for 20 years.

**5. Brand/scale (weakest).** Honestly described, this is just the fact that ETR is the largest contiguous generator in MISO South with existing relationships. It would not survive a credible behind-the-meter alternative.

What this is **not**: ETR has no proprietary technology, no patent moat, no software ecosystem, no kernel libraries, no developer base. The decomposition matters because the durable parts (1, 2, 3) cannot be eroded on a sub-decade timeline, while the parts visible to a sell-side analyst (the EPS line) depend on parts (4) and (5).

## AI buildout bottleneck map
The actual physical gating constraints on the AI buildout over the next 24 months, with ETR's position on each:

| Constraint | State of bottleneck | ETR's position |
|---|---|---|
| **Gas turbine slots (CCGT 7HA/9HA-class)** | Sold out through 2029; GE Vernova capacity at 20 GW/yr Q3 2026 → 24 GW/yr 2028 [13] | **Beneficiary** — orders placed, slots secured for Meta build |
| **Large power transformers / GSUs** | 30% shortfall, 128–144 wk lead times [14] | **Exposed customer** — partially mitigated by early ordering |
| **High-voltage transmission (500 kV)** | 240 miles required for Hyperion alone [4] | **Builder/owner** — capex earns rate-base return |
| **Power generation capacity (MISO South reserve margin)** | MISO 2026 South Load Pocket Risk Assessment underway [17] | **Supplier** — 7–12 GW data-center backlog beyond Meta [10] |
| **Cooling water rights** | Binding in TX, AZ; available in LA/MS along river corridors | **Beneficiary** — legacy thermal water rights |
| **Skilled electrical contractor labor (linemen, substation)** | Quoted as a primary delay vector by Bloom Energy 2026 survey (time-to-power +1.5–2 yrs) [18] | **Exposed**, partially mitigated by IBEW relationships |
| **Advanced packaging (CoWoS-L), HBM3e/HBM4** | Severe constraint at the silicon layer | **Indifferent** — one step removed |
| **Kernel/compiler talent** | NVIDIA-controlled | **Indifferent** |
| **Frontier training data** | Plateau debate | **Indifferent** |

The asymmetry to read: ETR is a beneficiary or owner on the constraints upstream of the GPU socket, indifferent to constraints inside or downstream of it. This is the structural reason a regulated utility — with no AI IP — is being repriced as AI infrastructure.

## Competitive teardown
The relevant competitive frame is **not** other utilities racing to serve the same Meta load (geography is fixed — Meta picked Richland Parish). It's whether the hyperscaler choice of vertically-integrated utility vs. alternatives erodes over time.

**Dominion Energy (D) — PJM/Virginia.** Has signed nearly 48.5 GW of data center commitments and raised five-year capex ~30% to $64.7B [19]. Has the largest absolute exposure but PJM transmission queues are notoriously congested; Virginia's residential opposition is more organized than Louisiana's. On a per-GW basis, ETR's contracted economics are competitive.

**Southern Company (SO) — Georgia.** 50 GW potential large-load pipeline, ~40 GW in Georgia, anchored by Vogtle 3/4 (new nuclear) [20]. Strongest nuclear position; Plant Vogtle's cost overruns have left SO with a regulatory hangover that ETR does not carry. Direct competitor for Mississippi-adjacent Georgia load.

**NextEra (NEE) — Florida + national renewables.** Restarting Duane Arnold (615 MW BWR) for Google, contracted for 15 GW of data-center build by 2035 [21]. Different model — combines regulated FPL utility with merchant renewables/storage. NEE's PPA structure puts more development risk on its balance sheet.

**Constellation (CEG) and Vistra (VST) — merchant nuclear.** CEG's TMI Unit 1 restart (835 MW, 2027 in-service) for Microsoft and VST's Comanche Peak 20-yr PPA represent the **highest-margin** competitive structure (existing nuclear at frontier electricity prices, no rate-base ROE cap) [22]. These are not direct ETR competitors — they're the alternative the market is comparing ETR against on multiple, and **on EV/EBITDA both trade at meaningful premiums** because they capture upside without LPSC ROE caps.

**Behind-the-meter (BTM) — the actual existential threat.** 46 data centers totaling 56 GW are now operating BTM gas generation [23]; some hyperscalers are using mobile aero-derivative turbines and even ship engines to bypass utility time-to-power. If Meta could have BTM'd Hyperion at acceptable cost, ETR would not have gotten the deal. The 243-week turbine lead times for non-utility buyers and the LPSC's willingness to fast-track gas plants are what kept this in the utility channel. **This is the bear-case competitor, not Dominion.**

**Axis where ETR has parity or advantage:** (a) regulatory recovery certainty (LPSC's 4-1 fast-track vote [24]); (b) cheap Haynesville gas at the burner tip; (c) cooling water siting; (d) explicit cost-sharing framework that has muted residential opposition relative to Dominion in Virginia.

**Axis where ETR is at parity or worse:** (a) ROE cap of ~10% vs. merchant unit-economics for CEG/VST; (b) no nuclear restart optionality (its nuclear fleet is operating, with only Waterford uprate adding 40 MW); (c) hurricane exposure (no other major utility has Gulf Coast Cat 4+ recurrence).

## Bull case — technical
For ETR to outperform from $111.59, four technical conditions need to hold over 24–36 months:

1. **Hyperscaler training capex sustains or grows.** Meta's 2027–2030 capex needs to remain consistent with Hyperion's 2 GW phase-1 → 5+ GW total scaling; this requires frontier-model training compute demand to continue absorbing GPUs at frontier price/performance. Falsifier: if pre-training scaling laws clearly plateau and inference shifts on-prem/edge, the marginal data center in MISO South is the one that gets cancelled.
2. **Gas remains the dispatchable choice over BTM.** Meta and AWS continue to find utility-scale CCGT with rate-based cost recovery cheaper than 8 GW+ of BTM turbines, especially as 2030+ EPA emissions rules and CCS mandates favor utility-scale solutions over distributed BTM. ETR's Energy Transfer 20-yr firm gas transport contract (250,000 MMBtu/day, 2028–2048 [25]) locks in fuel.
3. **LPSC and MS PSC remain accommodating.** The 4-1 fast-track precedent on Hyperion holds; the 7–12 GW backlog beyond Meta converts into approved capex at ~10% ROE [10]. The Fair Share Plus framework survives Earthjustice/AAE/UCS challenges [26].
4. **Turbine and transformer slots translate into EPS.** $57B four-year plan executes within budget; the 8.5% retail sales CAGR and 16% industrial CAGR translate to the $6.40 2029 EPS target [8][10] without significant cost overruns.

Connection to financial outcome: At $6.40 2029 EPS and a 18× exit multiple (in line with high-growth regulated utilities), the math produces ~$115 by 2028, plus ~$8 of cumulative dividends — roughly a 12–14% IRR. Bull case requires multiple expansion to ~20× on 2029 EPS, which would imply ~$128 exit + dividends = ~16% IRR.

**Base rate caveat:** Historical base rate for U.S. regulated utility regulatory regimes being disrupted is very low (closest precedent: Texas deregulation 1999, which did not disrupt incumbents' physical assets, only their merchant exposure). But the base rate for **demand forecasts at the top of a capex cycle being right** is also low — utility 10-year load forecasts have a documented bias to overshoot at peaks (1970s nuclear, 2000s natural gas).

## Bear case — technical
A short-seller who understood the stack would write this:

1. **Meta's four-year walk-away option is structurally underpriced.** Earthjustice's filing alleges Meta's financing deal allows the company to walk in four years, while the gas plants have 30-year lives [26]. If Meta cancels Hyperion in 2029 (e.g., training scaling laws plateau, or Meta deprioritizes vs. inference-on-device), ETR ends up with 2.2–5.2 GW of stranded CCGT capacity, with cost recovery going to either ratepayers (politically toxic) or shareholders (~$8B impairment risk). The "Fair Share Plus" framework's parent guarantees and termination penalties may not be sufficient to cover the full 30-year asset life. **This is the single biggest non-obvious risk.**
2. **Behind-the-meter improves rapidly.** Aero-derivative gas turbines (LM6000, LM2500+), reciprocating engines (Wartsila, Caterpillar 9.5 MW units), and on-site fuel cells (Bloom SOFC) are scaling. If Microsoft, Google, or OpenAI demonstrate a 1 GW BTM campus that comes online faster than ETR's 2028 utility-scale timeline, the next hyperscaler RFP routes around the utility. Note that 56 GW of BTM is already deployed [23].
3. **Pre-training compute demand decouples from data center sq-footage.** If inference-time compute (test-time reasoning, agentic workloads) becomes a larger fraction of the workload than training, the geographic distribution of compute shifts toward edge/metro deployments — Northern Virginia, Dallas, Phoenix — and the marginal data center is **not** in Richland Parish.
4. **Hurricane / storm cost recovery becomes politically unviable.** ETR has used securitization to spread 2020/2021/Ida costs over 15-year LURC bonds [27], but a Cat 4+ direct hit on the new $14B+ Hyperion infrastructure during 2027–2031 could push storm-rider charges past political tolerance — especially if residential bills are already absorbing FAC pass-through on higher gas prices.
5. **LPSC composition is electoral.** Louisiana commissioners are elected. A populist swing — particularly given AAE/UCS framing of "tech giants subsidized by residential ratepayers" [26] — could reverse Fair Share Plus terms or impose denial-of-recovery on future plants. The 4-1 vote already shows one dissenter [24].

Bear-case math: If 2029 EPS comes in at $5.40 (downside of $1.00 from the $6.40 target on Meta walk-away or BTM share-loss) and multiple compresses to 15× on stranded-asset overhang, the implied stock is ~$81 — back to the 52-week low.

## Market view check
At $111.59, ETR trades at ~24× forward EPS and ~5.3× EV/NTM revenue — both well above its 10-year median (~16× forward P/E for regulated utilities) and above the regulated-utility peer median EV/EBITDA of ~10.3× (ETR ~12.4×) [9]. The market is pricing ETR as a structural AI-infrastructure name rather than a defensive yield utility — the 2.3% dividend yield is now below the 10-yr Treasury, which is historically anomalous for ETR. Consensus PT $121 implies ~9% upside, but the dispersion ($105–$135) is wider than typical for utilities, indicating disagreement specifically on Meta-deal NPV and BTM displacement risk. **The market is implicitly assuming the $6.40 2029 EPS target is achieved with high probability and the gas-asset stranding risk is small.** A technically-informed view should weight the stranding risk higher than the consensus appears to — the dossier finds the bull case credible but the bear case is more credible than the multiple suggests, with the asymmetry concentrated in the Meta four-year walk-away clause.

## 90-day falsifiers
Specific, checkable events between May 2026 and August 2026 that would update the thesis:

1. **LPSC ruling on Hyperion Phase 2 transmission (the 500-kV expansion).** A delayed or conditioned approval, or any LPSC reopener on Fair Share Plus terms, would weaken the regulatory-moat thesis. Check LPSC docket filings monthly.
2. **Meta Q2 2026 earnings (late July).** If Meta cuts 2026 capex guidance by >10% sequentially, or de-emphasizes Hyperion timeline on the call, the bear thesis on the four-year walk-away strengthens materially.
3. **GE Vernova Q2 earnings and slot-reservation update.** If GE Vernova's slot reservations cross ~65 GW (vs. 56 GW in Q1 2026 [13]), the turbine-slot moat for ETR strengthens (existing orders become more valuable); if GE flags any delivery slippage on ETR-allocated 7HA frames, the EPS-execution thesis weakens.
4. **ETR Q2 2026 earnings (late July/early August).** Watch (a) whether additional data-center MOUs from the 7–12 GW backlog convert to filed regulatory cases; (b) any update on Waterford 3 +40 MW uprate completion (fall 2026); (c) equity issuance pacing — management said no new equity needed until late 2027 [10], so any acceleration is a negative signal.
5. **2026 Atlantic hurricane season (June 1 onward).** A Cat 3+ direct hit on Louisiana coastal generation or transmission triggers a securitization filing within ~6 months; track NOAA seasonal outlook and storm tracks.
6. **Behind-the-meter announcement from a hyperscaler in MISO South footprint.** Specifically watch for AWS, OpenAI/Stargate, or xAI announcing a 500+ MW BTM gas campus in LA/MS/AR/TX-SE that bypasses ETR. This is the highest-impact 90-day bear catalyst.
7. **AAE/UCS/Earthjustice ruling on Meta financing probe.** LPSC declined to open the probe once [26]; a re-filing or successful appeal would be a meaningful negative.

## What I could not verify
- **YTD total return (~+33%)** is inferred from reported 90-day (+24.5%) and 1-yr TSR (+46.4%) data points and an estimated 12/31/25 close near $84; I did not find a directly published YTD figure.
- **Exact CCGT installed-cost ETR is paying for the Hyperion plants.** The $1,000 → $2,000–2,500/kW range is industry-wide [13]; ETR-specific cost numbers were not in public filings I could access.
- **Specific turbine OEM(s) ETR has contracted for the three Richland Parish CCGT units.** Press releases reference "combined-cycle combustion turbine" without naming GE Vernova vs. Mitsubishi vs. Siemens Energy. The supplier choice materially affects delivery timing.
- **Meta's contractual termination penalty quantum.** Earthjustice characterizes it as a four-year walk-away [26]; Entergy characterizes it as fully covered by parent guarantee and termination penalty [15]. The actual netted exposure is the single most important number for the bear case and is not in the public record I found.
- **MISO South 2030 reserve margin under the 7–12 GW backlog scenario.** MISO is conducting a 2026 South Load Pocket Risk Assessment [17], but the public output is not yet available.
- **ETR's specific large-power-transformer order book status and delivery schedule.** I could only verify industry-wide constraints, not Entergy-specific.
- **Whether ETR has signed any SMR (X-energy, NuScale, Holtec SMR-300) LOI or MOU.** The Landry administration in Louisiana has publicly favored expanding nuclear [28], but no Entergy SMR partnership announcement was found in my searches.
- **Detailed Fair Share Plus contractual structure** for AWS Mississippi vs. Meta — the seven core principles are public, but specific collateral/termination terms by counterparty are not.

## Sources
[1] https://www.entergy.com/datacenters — retrieved 2026-05-10 — ETR's data-center customer overview, 2.3M customers across LA/MS/AR.
[2] https://insight.factset.com/entergy-in-a-new-era-of-data-center-driven-load-growth — retrieved 2026-05-10 — FactSet overview of ETR's MISO South service territory and data-center exposure.
[3] https://www.entergy.com/nuclear — retrieved 2026-05-10 — Grand Gulf 1,443 MW, Waterford 3 1,152 MW (+40 MW uprate fall 2026), River Bend 967 MW, ANO 1/2.
[4] https://www.enr.com/articles/62766-27b-meta-data-center-pushes-louisiana-toward-massive-power-expansion — retrieved 2026-05-10 — $27B Meta Hyperion, 7 plants/5.2 GW gas, 240 mi 500-kV transmission.
[5] https://www.entergy.com/blog/aws-good-for-mississippi-great-for-entergy-customers — retrieved 2026-05-10 — AWS Madison County and Warren County MS data centers.
[6] https://stockanalysis.com/stocks/etr/statistics/ — retrieved 2026-05-10 — Price $111.59, market cap $47.03B, forward P/E 23.59.
[7] https://www.wallstreetzen.com/stocks/us/nyse/etr/dividends — retrieved 2026-05-10 — 52-week range, dividend $2.56 annualized.
[8] https://finance.biggo.com/news/US_ETR_2026-04-29 — retrieved 2026-05-10 — 2029 adj. EPS target raised by $0.50 to $6.40; $14B capex increase from Meta deal.
[9] https://www.gurufocus.com/term/enterprise-value-to-ebitda/ETR — retrieved 2026-05-10 — EV $74.6B, EV/EBITDA 12.37, industry median 10.27.
[10] https://www.fool.com/earnings/call-transcripts/2026/04/29/entergy-etr-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q1 2026 transcript: 8.5% retail/16% industrial CAGR, $57B 4-yr capex, $6.6B equity need, 7–12 GW data-center backlog, no new equity until late 2027.
[11] https://www.themarketsdaily.com/2026/04/16/short-interest-in-entergy-corporation-nyseetr-increases-by-28-9.html — retrieved 2026-05-10 — Short interest 16.8M shares, 3.7% of float; analyst PT consensus and Scotia/UBS upgrades.
[12] https://simplywall.st/stocks/us/utilities/nyse-etr/entergy — retrieved 2026-05-10 — 1-yr TSR 46.43%, 30-day +12.18%, 90-day +24.54%; basis for YTD inference.
[13] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — GE Vernova 80 GW backlog through 2029, capacity 20 GW Q3 2026 → 24 GW 2028; installed costs $2,000–2,500/kW.
[14] https://www.woodmac.com/press-releases/power-transformers-and-distribution-transformers-will-face-supply-deficits-of-30-and-10-in-2025/ — retrieved 2026-05-10 — 30% LPT shortfall, 128-wk LPT and 144-wk GSU lead times.
[15] https://www.entergy.com/news/5b-in-customer-savings-delivered-by-data-center-agreements-issues-fair-share-plus-pledge — retrieved 2026-05-10 — Fair Share Plus seven principles, parent guarantees, termination penalties; $5B customer savings.
[16] https://www.entergy.com/news/entergy-louisiana-announces-a-new-agreement-with-meta-that-will-deliver-an-additional-2b-in-customer-savings — retrieved 2026-05-10 — Second Meta agreement, +$2B customer savings, 20-yr term.
[17] https://southernrenewable.org/news-updates/why-misos-2026-grid-analysis-matters-to-louisiana — retrieved 2026-05-10 — MISO 2026 South Load Pocket Risk Assessment.
[18] https://www.spglobal.com/market-intelligence/en/news-insights/articles/2025/10/data-center-developers-turn-to-distributed-behind-the-meter-power-94174247 — retrieved 2026-05-10 — Bloom Energy 2026 survey: time-to-power +1.5–2 yrs delay; BTM rise.
[19] https://www.fool.com/investing/2026/01/04/could-utility-stocks-be-the-next-big-ai-winners/ — retrieved 2026-05-10 — Dominion 48.5 GW signed, $64.7B 5-yr capex.
[20] https://www.fool.com/investing/2025/12/07/10-energy-stocks-to-buy-right-now/ — retrieved 2026-05-10 — Southern Co. 50 GW pipeline, 40 GW in Georgia.
[21] https://stocktwits.com/news-articles/markets/equity/top-5-us-utility-stocks-by-market-value/cLepYSUREHR — retrieved 2026-05-10 — NEE Duane Arnold restart for Google, 15 GW build by 2035.
[22] https://www.etftrends.com/disruptive-technology-content-hub/data-centers-embracing-nuclear-smrs-ai-needs/ — retrieved 2026-05-10 — Constellation TMI Unit 1 restart for Microsoft; Vistra Comanche Peak PPA.
[23] https://grist.org/energy/data-centers-natural-gas-methane-behind-the-meter/ — retrieved 2026-05-10 — 46 BTM data centers, 56 GW; 243-wk turbine lead times for non-utility buyers.
[24] https://www.wbrz.com/news/entergy-asking-psc-to-fast-track-proposed-billions-in-energy-investments-to-power-meta-data-center/ — retrieved 2026-05-10 — LPSC 4-1 fast-track vote.
[25] https://www.entergy.com/news/entergy-louisiana-and-energy-transfer-sign-agreement-that-supports-reliable-affordable-energy-and-economic-growth-in-north-louisiana — retrieved 2026-05-10 — 20-yr ET firm gas transport, 250,000 MMBtu/day, 2028–2048.
[26] https://earthjustice.org/press/2026/louisiana-regulators-asked-to-investigate-shady-meta-financing-deal-that-could-leave-households-paying-for-tech-giants-electricity — retrieved 2026-05-10 — AAE/UCS/Earthjustice opposition; Meta 4-year walk-away allegation; gas-plant 30-year life mismatch.
[27] https://www.entergy.com/stormcenter/innovative-financing-method-helps-ease-impact-storm-costs — retrieved 2026-05-10 — LURC securitization mechanism, 15-yr amortization, 2020/2021/Ida cost recovery.
[28] https://www.nola.com/news/business/jeff-landry-entergy-want-more-nuclear-power-in-louisiana-heres-why/article_4fb58253-589e-438e-ad81-637f5debda1e.html — retrieved 2026-05-10 — Louisiana governor and Entergy stated intent to expand nuclear; no specific SMR partnership confirmed.