# PANW — Palo Alto Networks, Inc.

## Where this sits in the AI stack
PANW is **not** an AI infrastructure provider. It is an enterprise cybersecurity software/appliance vendor whose AI exposure is two-sided: (i) using ML/LLMs to drive its own detection and SOC automation products (Cortex XSIAM, Precision AI), and (ii) selling a new control plane — Prisma AIRS, the Portkey AI gateway (announced 30 Apr 2026), and CyberArk's identity vault (closed 11 Feb 2026) — to secure the AI workloads that *other* people build [1][2][3][4][5]. It sits at the **software / control-plane / data-collection layer** above the silicon — adjacent to AI capex rather than levered to it. The thesis is therefore about whether enterprises consolidate security spend onto a single platform during the AI buildout, not whether AI training scales.

## Snapshot

- **Price:** $207.88 (2026-05-08 close; 2026-05-10 is a Sunday) [6]
- **Market cap:** ~$169.6B [7] (share count reflects the ~112M-share issuance for CyberArk on 11 Feb 2026 [4][8])
- **52-week range:** all-time-high close $221.38 (28 Oct 2025) [9]; 52-week low not confidently sourced — see "What I could not verify"
- **Forward P/E:** ~46× on FY26 non-GAAP EPS guidance (mid-point ~$4.50 implied; Yahoo lists 45.6× as of Mar 2026, 54.4× on a different basis) [10]
- **EV / NTM revenue:** ~11.3× (NTM); 14.3× LTM — ~58% above PANW's own 10-yr median of 9.1× [10]
- **Consensus 12-month price target:** $213–217 (~+3–4%); BTIG $216, Wells Fargo $235 (raised May 2026) [11][9]
- **YTD total return:** ~-0.1% (flat) [9]
- **Short interest (% of float):** 3.2% on one feed, 6.5% on another — discrepancy unresolved; both are unremarkable [7]
- **NGS ARR (proxy for "real" growth):** $6.33B Q2 FY26, +33% YoY (+28% organic, +$200M from Chronosphere) [12][13]
- **RPO:** $16.0B (+23% YoY); cRPO $7.1B (+18%) [14]
- **Net retention among platformized customers:** 119%; ~1,550 platformized accounts vs. ~85,000 total customers (1.8% penetration) [13][2]

## Moat — what it is physically made of

Decomposed by layer, with honest durability scoring:

**1. PAN-OS single-pass parallel processing (SP3) + FE400 ASIC (Strata / NGFW).** Packets are decoded once and App-ID, User-ID, threat inspection, and content scanning hang off that pass [15][16]. The PA-7500 ships PANW's custom **FE400** silicon for line-rate inspection [16]. This is real engineering — ~17 years of incremental work — but the durability is finite: **Fortinet's NP7+SP5 ASIC delivers ~164 Gbps firewall throughput vs. PANW's ~7.9 Gbps in NSS lab tests at comparable price points, with ~7× lower power draw** [17]. PANW wins on integrated software stack and traffic understanding; Fortinet wins on raw silicon $/Gbps. **Durability: medium-high in deep-inspection use cases, medium-low in commodity perimeter.**

**2. Cortex XDL (Extended Data Lake) + Precision AI corpus.** PANW ingests ~8 PB/day of telemetry across ~85,000 customers; that data trains the detection models behind XSIAM [1][2]. The bet is a classic data-network-effect: more telemetry → better models → more wins → more telemetry. **The empirical evidence is mixed.** XSIAM SIEM mindshare actually **fell** from 2.7% to 1.8% in the year to April 2026; Splunk fell from 9.2% to 7.0% in the same window [18]. CrowdStrike leads SIEM mindshare at 11.1% vs. XSIAM at 5.0% on PeerSpot [19]. The QRadar SaaS book PANW acquired from IBM is a forced-migration accelerator, not organic share-take [18]. **Durability: low-medium; the data advantage is real but has not translated into market position.**

**3. CyberArk vault + machine/AI identity (closed 11 Feb 2026, $25B in cash + stock).** This is the most defensible technical asset PANW now owns. The CyberArk vault has ~25 years of hardened credential-rotation engineering, deep AD/Entra/SAML/SCIM integrations, and is the de-facto PAM standard at most Fortune 500s [3][4]. Machine-identity volumes are growing 10–20× human-identity volumes as agentic AI deploys (Portkey claims trillions of tokens/month already routed via API keys that need rotation, scoping, and audit) [5]. **Durability: high.** This is the closest PANW has to a true installed-base moat — switching costs are operational (every privileged session, secret, and break-glass workflow) and audit-driven.

**4. Prisma SASE (Prisma Access + Prisma Access Browser).** ~$1.5B ARR, ~40% YoY growth, #3 in SASE / #2 in SSE behind Zscaler [20][2]. Differentiation is consistency with the on-prem firewall data plane (same App-ID, same policy), which matters for hybrid enterprises. Zscaler leads pure cloud-proxy SSE with 34% share to PANW's mid-teens [20]. **Durability: medium; benefits from the cross-sell into existing NGFW accounts but does not displace Zscaler in greenfield.**

**5. Prisma AIRS 1.0/2.0/3.0 + Portkey gateway (pending close in FY26 Q4).** Five pillars — model scanning (from Protect AI), AI posture management, AI red-teaming, runtime firewall for prompts, AI-agent security — wrapped by Portkey's AI gateway control plane [21][22][5]. Customer count was >100 at Q2 FY26 [13]. **This is real product, not vapor**, but the category is 18 months old; there is no incumbent yet and no proof Prisma AIRS' inspection of LLM traffic adds material value beyond what hyperscalers will provide natively (Microsoft Foundry, AWS Bedrock Guardrails, GCP Model Armor). **Durability: unknown; bet quality is the right question.**

**6. Platformization economics.** 119% NRR among platformized accounts vs. low-single-digit churn [13]. Crucially: only 1.8% of PANW's customer base is "platformized" by their own definition [2][13]. Most of the bull case rests on that ratio rising. This is a sales-motion advantage, not a technical moat — and it is what a sell-side note would call a moat. **Durability: depends entirely on the sales execution, not on technology.**

Net: the **real** technical moats are (a) CyberArk's vault/PAM tech, (b) the FE400/PAN-OS data-plane integration for the high-end firewall installed base, and (c) the cross-product policy graph that integrates these. The marketed moats — Precision AI, data corpus, XSIAM share — are weaker than the company's investor narrative implies.

## AI buildout bottleneck map

The actual AI capex bottlenecks over the next 24 months and PANW's relationship to each:

| Bottleneck | PANW position |
|---|---|
| Power generation / grid interconnect (gas turbine backlog, transformer lead times) | **Indifferent.** No revenue exposure either way. |
| CoWoS-L advanced packaging at TSMC | **Indifferent.** PANW's own ASIC (FE400) is fabbed but is not on bleeding-edge packaging. |
| HBM3e / HBM4 supply | **Indifferent.** |
| 800G / 1.6T optical interconnect | **Indifferent on production**, but Strata NGFW must inspect higher-throughput east-west traffic in AI clusters — this is a marginal demand pull, not a primary driver. |
| Liquid cooling at >100 kW/rack | **Indifferent.** |
| Kernel / compiler / CUDA talent | **Indifferent.** |
| Training-data quality at frontier | **Indifferent.** |
| **Enterprise AI deployment friction (governance, identity, runtime policy)** | **Direct beneficiary.** Prisma AIRS, Portkey, and CyberArk machine-identity each address a friction the buildout creates. This is where the AI thesis for PANW lives. |
| **SOC headcount shortage as attack surface expands with AI agents** | **Beneficiary** via Cortex XSIAM automation — though this same dynamic is also the *bear case* for per-seat security pricing. |

So PANW is a **derivative bet** on the AI buildout: it benefits if enterprise AI deployment is widespread and noisy, suffers (slightly) if it stalls, and is unaffected by the silicon/packaging/power gating items themselves. Sell-side framing of PANW as "AI tailwind" stock conflates two things — model-training capex and enterprise application deployment. PANW is exposed to the second, not the first.

## Competitive teardown

**Microsoft (Defender + Sentinel + Entra, bundled in M365 E5).** Single most serious competitor. E5 ships Defender XDR and Sentinel SIEM for ~$3–5.20 per user per month effectively-included pricing [23]. Detection quality gap to CrowdStrike/PANW has narrowed substantially. **What is already true:** Microsoft is winning XDR in accounts standardized on M365. **What would have to be true for them to take share from PANW:** Sentinel's data lake matures (KQL-native, expensive ingestion today) and Defender extends credibly to non-Windows endpoints. **Timeline:** already happening in mid-market; PANW's defense is the high-end and regulated verticals.

**CrowdStrike (Falcon + Next-Gen SIEM, Charlotte AI).** Best-funded direct competitor. Falcon leads SIEM mindshare 11.1% to PANW's 5.0% [19]. Single lightweight agent, cloud-native deployment is genuinely simpler than Cortex's [19]. **What is already true:** parity-or-better in EDR; CrowdStrike has a faster product velocity and cleaner architecture for greenfield. **What PANW has that CRWD does not:** firewall data plane, identity (post-CyberArk), and a 14-year channel relationship with network teams. **Where CRWD takes share:** SOC modernization deals where the customer rips and replaces Splunk and does not already have a PANW firewall footprint.

**Google + Wiz ($32B, closed Mar 2025).** A cloud-bundled CNAPP threat. Wiz dominates cloud security UX/posture for cloud-native shops [24]. **What is already true:** Wiz wins greenfield cloud security at multi-cloud SaaS companies. **What PANW has:** stronger runtime + endpoint that Wiz historically lacked; RBC has explicitly called this PANW's edge over Wiz [24]. **What changes:** if Wiz's runtime engineering accelerates under Google's resources, PANW's Prisma Cloud loses its remaining differentiation by ~2027.

**Cisco + Splunk ($28B, closed 2024; XDR ↔ Splunk ES bidirectional integration shown at Cisco Live EMEA 2026).** Closest analog to PANW's own platform play — network + SIEM combined under one roof [25][26]. Cisco has the network installed base PANW does not. PANW has the better security product. The integration is real but Cisco's execution against frontier security has historically been slow. **What would have to be true:** Cisco-Splunk ships a credible XSIAM competitor with a unified data model in 2026, not 2028.

**Fortinet.** The real threat on the **NGFW silicon** axis. NP7+SP5 ASICs deliver ~7× the firewall throughput per dollar and ~7× lower power than PANW-class boxes in like-for-like SKUs [17]. PANW's defense is policy depth and the App-ID / threat-prevention stack — but Fortinet has closed that gap meaningfully in the last 3 years. **Already true:** Fortinet wins on price/performance in mid-market and for high-throughput east-west use cases.

**Zscaler.** Wins SASE/SSE on pure cloud-proxy architecture for fully-remote enterprises [20]. PANW wins on hybrid where a physical firewall already exists. Status quo holds.

**Hyperscaler-native AI security (Bedrock Guardrails, Model Armor, Foundry Content Safety).** The structural risk to Prisma AIRS. If hyperscalers ship "good-enough" prompt-injection and data-loss controls bundled into the inference endpoint, AIRS becomes an audit overlay rather than a budget line. Microsoft Foundry has already integrated Prisma AIRS [27] — which can be read either as validation *or* as the first step toward absorbing the function.

## Bull case — technical

**Base rate.** Enterprise security incumbency is unusually sticky relative to other software categories: SIEM displacement cycles run 5–10 years (Splunk → modern stacks is still in progress), PAM vendor changes are rare (CyberArk has held its position for ~25 years), and NGFW vendors rotate slowly because firewall policies are operational artifacts that nobody wants to migrate. The base rate of a top-3 enterprise security incumbent being displaced in any 5-year window is well under 30%. This favors the incumbent thesis.

**Technical conditions required for outperformance:**
1. **Platformization ratio rises from 1.8% → 5%+** over 24 months. NGS ARR continues compounding ~25%+ organic. NRR among platformized accounts stays ≥115%. This is the only number that matters.
2. **CyberArk integration closes the identity-to-runtime loop within 12 months.** A unified policy graph between machine identity (CyberArk), AI agent gateway (Portkey), runtime inspection (Prisma AIRS), and SOC (XSIAM) is a real platform other vendors cannot easily replicate end-to-end.
3. **Microsoft does not converge to feature parity at the high end.** PANW retains the F500 and regulated/government accounts where Microsoft bundle leverage is weakest.
4. **AI agent deployments require runtime governance.** If enterprises deploy 10⁴–10⁶ agents per company and each needs identity scoping + token-level audit + traffic inspection, PANW captures a non-trivial slice of a new $5–10B TAM (inference-time cost is real bull case here).
5. **Fortinet does not extend from price-performance leadership into deep-inspection / policy-depth use cases.**

**Financial translation:** ~25% organic NGS ARR growth, $11.3B → ~$16B revenue by FY28, non-GAAP operating margin expanding ~150–200 bps/yr toward 32%. That supports a 12–14× EV/sales multiple defensibly, implying ~$240–270 over 24 months if execution holds.

## Bear case — technical

**Symmetric technical conditions for the moat to erode:**

1. **The 1.8% platformization ratio is the ceiling, not the floor.** CISOs say they prefer single-vendor platforms in surveys [28] but historically buy best-of-breed when it matters. If platformization growth stalls at 2,500–3,000 accounts, NGS ARR growth decelerates faster than consensus models, and the multiple compresses.
2. **Microsoft E5 bundling wins net-new in the bottom half of the Fortune 1000.** Microsoft's marginal cost of including Defender/Sentinel is near zero; PANW's marginal cost of selling a parallel stack is meaningful CAC. This is the classic platform-bundle vs. point-product dynamic that has killed standalone enterprise software for 25 years (BMC, CA, Symantec, McAfee — the precedents are not flattering).
3. **Cortex XSIAM mindshare loss is real, not noise.** Going from 2.7% to 1.8% in 12 months [18] while marketing the product as flagship is a warning sign — not because Splunk is winning (it is also losing) but because CrowdStrike Falcon Next-Gen SIEM and Sentinel are dividing the pie XSIAM was supposed to capture.
4. **AI runtime security gets absorbed by the hyperscalers.** If Bedrock/Foundry/Model Armor provide ~80% of what Prisma AIRS does inside the inference endpoint, AIRS becomes a compliance overlay sold at compliance-overlay margins. The Microsoft Foundry integration [27] could be either validation or the leading edge of commoditization.
5. **$50B+ of M&A in 18 months (CyberArk $25B, Protect AI, Chronosphere, Portkey, prior Talon/Dig/IBM-QRadar-SaaS) creates integration drag.** PANW has revised FY26 EPS down on integration cost [9]. CyberArk alone added ~112M shares (~14% dilution) [4][8]. The platformization narrative depends on these stitching together cleanly — there is no historical case of any security vendor integrating that much that quickly without margin damage.
6. **Fortinet keeps grinding on silicon economics.** Each successive ASIC generation widens the gap on throughput-per-dollar. PANW's defense — software depth — matters less for east-west AI cluster traffic where simple high-throughput filtering wins.
7. **Hyperscalers + Wiz/Google make CNAPP a feature, not a product.** Prisma Cloud revenue exposure here.

**Financial translation:** if NGS organic growth decelerates from 28% to ~18% by FY27 while integration costs persist, FY27 EPS misses by 8–12%, multiple compresses to 9× EV/sales, stock trades $150–170.

## Market view check

PANW trades at ~11.3× NTM EV/revenue and ~46× forward P/E for ~15% revenue growth (~22% reported with M&A) and ~30% non-GAAP operating margin [10][13][12]. This is meaningfully **above the software industry median** but at a slight **discount to CrowdStrike** on EV/revenue despite similar growth. Consensus PT of ~$215 vs. spot $208 prices in essentially no upside; the buy-side appears to view the next 90–180 days as a hold for the CyberArk integration milestone, not an accumulation window. The market is implicitly believing:
- The 119% NRR / platformization story holds.
- CyberArk integrates cleanly enough that FY27 dilution flips to accretion.
- The AI security TAM is a real new revenue layer rather than a marketing slide.

Where the buy-side narrative looks **vulnerable**: the actual platformization base (1.8% of customers) is small enough that the bull case is more a sales forecast than a moat. Where it looks **understated**: the CyberArk identity asset is genuinely defensible technical infrastructure and consensus largely treats it as a normal SaaS bolt-on. Fair view: the stock is roughly fairly valued for the median outcome; the asymmetry is moderately positive only if you believe CyberArk-led identity is structurally the right hub of an AI-era security platform.

## 90-day falsifiers

1. **Q3 FY26 print (3 Jun 2026):** NGS ARR organic growth — if **organic** (ex-Chronosphere, ex-CyberArk) falls below ~25%, the platformization thesis takes a real hit.
2. **Platformized customer count:** if it does not reach ~1,700+ from 1,550, the customer-consolidation flywheel has stalled.
3. **CyberArk dis-synergy disclosure:** any guidance toward standalone CyberArk ARR decelerating below ~15% growth (its pre-deal run rate) signals customer disruption in the largest asset PANW owns.
4. **Portkey close (announced 30 Apr 2026):** if the deal slips beyond FY26 Q4, or if MFN/customer-portability terms leak, the AI-agent control-plane narrative weakens [5].
5. **Microsoft Build 2026 (May 2026 already underway):** any Microsoft announcement that bundles Sentinel + Defender + Entra into an "AI security" SKU at a price point that undercuts Prisma AIRS by >50% directly attacks the AIRS thesis.
6. **AWS re:Inforce (Jun 2026) and Google Cloud Next:** if Bedrock Guardrails / Model Armor get red-team feature parity with Prisma AIRS, AIRS moves to compliance overlay.
7. **MLPerf-equivalent independent AI red-teaming benchmark:** if any neutral third-party assessment shows Prisma AIRS detection rates within 10% of hyperscaler-native guardrails, AIRS pricing power compresses.
8. **MITRE ATT&CK Evaluation Round 7 results:** any deterioration in Cortex XDR/XSIAM detection vs. CRWD/Microsoft would erode the marketing claim of detection leadership [19].
9. **Wells Fargo $235 PT (May 2026) materializing in fund flows:** if the highest sell-side bull does not show up in fund-position disclosures over Q2, sentiment is shallower than the headline targets suggest.

## What I could not verify

- **Confirmed 52-week low.** Sources cite the $221.38 high (28 Oct 2025) but a clean intraday/closing 52-wk low number was not in the returned text. Inferred to be ~$165–175 from the down-leg into early 2026, but not citable with confidence.
- **Exact short interest.** Two feeds cite 3.18% and 6.49%; the gap is unresolved — likely a date difference (pre/post CyberArk-deal arbs unwinding) [7].
- **Forward P/E precise denominator.** Different feeds use different non-GAAP EPS bases (45.6× vs. 54.4×) — I cited the range rather than picking one.
- **Prisma AIRS revenue contribution.** PANW only discloses customer count (>100 at Q2 FY26) and bundles it with software firewall growth [13]. No standalone ARR is public.
- **Portkey acquisition price.** "$700M-class" reported by The New Stack [5], not officially confirmed.
- **CyberArk standalone ARR run-rate post-close.** Disclosed pre-deal, not yet re-disclosed under PANW segment reporting.
- **Specific FE400 ASIC node and packaging.** PANW has not disclosed fab or process node for the FE400 [16].
- **MITRE Round 6 detection-rate methodology relative to CrowdStrike's absence from that round.** Cortex's "100% technique-level" claim is real but is against a participant set CRWD opted out of [19].
- **Net-new Cortex XSIAM logos vs. QRadar-SaaS forced migrations.** PANW reports XSIAM growth in aggregate; the organic vs. IBM-migration split is not disclosed [18].

## Sources

[1] https://www.paloaltonetworks.com/company/press/2024/palo-alto-networks-unveils-enhanced-flexibility-and-customization-with-cortex-xsiam--the-precision-ai-powered-soc-platform — retrieved 2026-05-10 — XSIAM Cortex Extended Data Lake architecture; AI-driven SecOps unification.
[2] https://www.paloaltonetworks.com/cyberpedia/what-is-precision-ai — retrieved 2026-05-10 — Precision AI architecture (deep learning + ML + GenAI), 8 PB/day, 85,000 customers.
[3] https://www.paloaltonetworks.com/company/press/2026/palo-alto-networks-completes-acquisition-of-cyberark-to-secure-the-ai-era — retrieved 2026-05-10 — CyberArk deal close 11 Feb 2026; identity as core pillar.
[4] https://delmorganco.com/palo-alto-networks-acquisition-of-cyberark/ — retrieved 2026-05-10 — $25B CyberArk transaction value.
[5] https://thenewstack.io/palo-alto-portkey-ai-gateway/ — retrieved 2026-05-10 — Portkey "$700M-class" AI gateway acquisition, trillions of tokens/month.
[6] https://finance.yahoo.com/quote/PANW/ — retrieved 2026-05-10 — PANW closing price $207.88 on 2026-05-08.
[7] https://stockanalysis.com/stocks/panw/statistics/ — retrieved 2026-05-10 — market cap, short interest discrepancy across feeds.
[8] https://investors.paloaltonetworks.com/news-releases/news-release-details/palo-alto-networks-reports-fiscal-second-quarter-2026-financial — retrieved 2026-05-10 — Q2 FY26 share count guidance 812–817M fully diluted post-CyberArk.
[9] https://www.tradingview.com/news/gurufocus:178a4342c094b:0-palo-alto-networks-the-selloff-creates-an-opportunity-in-the-ai-era/ — retrieved 2026-05-10 — ATH $221.38 (28 Oct 2025); EPS guidance revision; Wells Fargo $235 / BTIG $216 PT raises May 2026.
[10] https://www.gurufocus.com/term/enterprise-value-to-revenue/PANW — retrieved 2026-05-10 — EV/Revenue 14.3× LTM, 58% above 10-yr median; forward P/E references.
[11] https://www.marketbeat.com/stocks/NASDAQ/PANW/forecast/ — retrieved 2026-05-10 — 36-analyst consensus PT $213–217, mostly Buy.
[12] https://futurumgroup.com/insights/palo-alto-networks-q2-fy-2026-arr-accelerates-as-platform-strategy-scales/ — retrieved 2026-05-10 — Q2 FY26 NGS ARR $6.33B, +33%; non-GAAP operating margin 30%+ third quarter running.
[13] https://www.insidermonkey.com/blog/palo-alto-networks-inc-nasdaqpanw-q2-2026-earnings-call-transcript-1698082/ — retrieved 2026-05-10 — Q2 FY26 transcript: 1,550 platformized customers, 119% NRR, organic NGS +28%, Chronosphere +$200M ARR, Prisma AIRS >100 customers.
[14] https://www.stocktitan.net/news/PANW/palo-alto-networks-reports-fiscal-second-quarter-2026-financial-sv1iwethy9km.html — retrieved 2026-05-10 — RPO $16.0B (+23%), cRPO $7.1B (+18%); revenue $2.594B.
[15] https://www.paloaltonetworks.com/resources/whitepapers/single-pass-parallel-processing-architecture — retrieved 2026-05-10 — SP3 architecture: single decode pass; App-ID, User-ID, threat inspection in parallel.
[16] https://www.paloaltonetworks.com/network-security/hardware-firewall-innovations — retrieved 2026-05-10 — FE400 custom ASIC in PA-7500.
[17] https://www.stocktitan.net/news/FTNT/fortinet-expands-hybrid-mesh-firewall-portfolio-with-forti-gate-puavyitf6xyv.html — retrieved 2026-05-10 — FortiGate 700G: 164 Gbps firewall, 26 Gbps threat prevention, NP7+SP5 ASICs, ~7× lower power vs. PANW/Cisco/Check Point.
[18] https://www.peerspot.com/products/comparisons/cortex-xsiam_vs_splunk-enterprise-security — retrieved 2026-05-10 — XSIAM SIEM mindshare 2.7%→1.8% YoY (April 2026); Splunk 9.2%→7.0%; QRadar-SaaS migration deal context.
[19] https://www.peerspot.com/products/comparisons/cortex-xsiam_vs_crowdstrike-falcon — retrieved 2026-05-10 — Falcon 11.1% vs. XSIAM 5.0% SIEM mindshare; agent simplicity gap; MITRE Round 6 caveat.
[20] https://www.delloro.com/news/top-six-sase-vendors-own-72-percent-of-2-4-b-3q-2024-market/ — retrieved 2026-05-10 — SASE market shares: Zscaler 21%, top-6 = 72%; SSE: Zscaler 34%, PANW #2.
[21] https://www.paloaltonetworks.com/prisma/prisma-ai-runtime-security — retrieved 2026-05-10 — Prisma AIRS 5-pillar architecture: model security, posture mgmt, red-teaming, runtime, agent security.
[22] https://www.paloaltonetworks.com/company/press/2025/palo-alto-networks-completes-acquisition-of-protect-ai — retrieved 2026-05-10 — Protect AI close in 2025; model scanning + AI red-teaming feeds Prisma AIRS.
[23] https://heimdalsecurity.com/blog/microsoft-vs-palo-alto/ — retrieved 2026-05-10 — Microsoft Defender bundling at $3–5.20/user/month inside M365 E3/E5; share-taking dynamic vs. PANW.
[24] https://techcrunch.com/2026/03/11/google-completes-32b-acquisition-of-wiz/ — retrieved 2026-05-10 — Google-Wiz $32B close; PANW's runtime/endpoint edge per RBC.
[25] https://blogs.cisco.com/security/innovating-the-soc — retrieved 2026-05-10 — Cisco XDR ↔ Splunk ES bidirectional integration Cisco Live EMEA 2026.
[26] https://www.explainerds.net/splunk-the-28-billion-bet-that-finally-gives-cisco-a-data-operating-system/ — retrieved 2026-05-10 — Cisco-Splunk $28B; data operating system framing.
[27] https://www.paloaltonetworks.com/blog/2025/11/prisma-airs-integrates-azure-ai-foundry/ — retrieved 2026-05-10 — Prisma AIRS integrated with Microsoft Foundry — validation but also potential commoditization vector.
[28] https://www.wiz.io/reports/ciso-security-budget-benchmark-2026 — retrieved 2026-05-10 — 64% of CISOs would buy single-vendor platform from scratch; 58% run >25 tools; consolidation pressure macro.