I have enough material. Writing the dossier now.

# INTU — Intuit Inc.

## Where this sits in the AI stack
Intuit operates at the **application/workflow layer**, not the silicon, fabric, or training stack. The company sells SaaS in tax (TurboTax, ProConnect), accounting (QuickBooks, Intuit Enterprise Suite), credit/lending (Credit Karma), and marketing (Mailchimp) [3][16]. Its AI exposure is as a **buyer** of frontier inference (Claude on AWS Bedrock; GPT on Azure; Gemini on GCP; Llama/Mistral as alternates) and as the owner of a domain-specific orchestration layer — "GenOS" — sitting between those general-purpose LLMs and ~100M consumer/SMB users [2][9][13]. The workloads are inference, not training: high-fanout, latency-sensitive, seasonally-spiked (44M tax returns in a ~10-week window) [13], with a small share of compute used for fine-tuning custom "Financial LLMs" on de-identified transaction data [13].

## Snapshot
- **Price:** $396.31 (2026-05-08 close) [21]
- **Market cap:** ~$110.3B [1]
- **52-week range:** $342.11 – $813.70 [10]
- **Forward P/E:** ~15.3–17.1× on FY26 non-GAAP EPS guide of $22.98–$23.18 [6][8]
- **EV / NTM revenue:** ~5.9× on FY26 revenue guide of $20.997–$21.186B [6][8]
- **Consensus 12-month price target:** $590 (median, range $425–$916), implying ~+49% [10]
- **YTD total return:** ~-40% [17]
- **Short interest (% of float):** 2.97% (7.24M shares) [11]

## Moat — what it is physically made of
The moat is **not silicon, kernels, or fabric**. Decomposing into durable components:

**(1) Regulated workflow lock-in (highest durability).** TurboTax is not a "form generator" — it is a continuously-updated mapping between 50 state tax codes, IRS forms, deduction rules, and a few hundred million prior-year filings stored on Intuit's servers. The barrier is not the code; it is the annual regulatory ingest and the prior-year return import that retains customers. The Free File Alliance erosion is instructive: Intuit and H&R Block spent a combined $103M lobbying since 2003, and $7M in 2025 alone, to kill the IRS Direct File program — which is suspended for the 2026 filing season [4]. That this much annual maintenance lobbying is required is itself the moat: a public-option competitor cannot exist as long as Intuit can afford the lobby.

**(2) Proprietary financial data corpus (high durability).** Intuit holds billions of categorized bank transactions, multi-year SMB GL data, and prior-year tax returns linked to demographic data via Credit Karma [12]. Its custom "Intuit Financial LLMs" — supervised-fine-tuned on this anonymized corpus — claim 90% accuracy on transaction categorization with 50% lower latency than off-the-shelf frontier models on the same task [13]. In January 2026, accounting agents categorized 237M transactions, >50% of all transactions categorized that month inside the platform [3]. This is a data-network effect, not a model effect: any competitor needs labeled, time-series, high-cardinality financial data, which is held by banks (regulated) and Intuit (incumbent).

**(3) Distribution + accountant ecosystem (moderate durability).** ~50,000 certified QuickBooks ProAdvisors in the US [12]; QuickBooks holds 62.23% of US accounting-software market share vs. Xero 8.9% and Sage 10.3% [5]. ProAdvisors retain clients on QB because their workflow tooling (ProConnect, Lacerte) integrates directly. This is the same playbook as Bloomberg terminals: train the practitioner on the tool.

**(4) GenOS as software substrate (low-to-moderate, contested).** Architecturally: GenStudio (dev env), GenRuntime (orchestration/routing), GenUX (component library), and an "LLM Leaderboard" that benchmarks new model releases on Intuit-specific eval sets to choose model-per-use-case [2][9]. Anthropic Claude is invoked via Bedrock with provisioned throughput; OpenAI via Azure [9][13]. This is competent enterprise plumbing — not a moat. Any well-funded SaaS incumbent (Salesforce Einstein, ServiceNow Now Assist) has the equivalent. **Inference: GenOS is a productivity layer for Intuit engineers, not a customer-visible barrier to entry.**

**(5) Brand / distribution at consumer end (moderate, eroding).** "TurboTax" is the household verb. But verbs erode in agent-mediated worlds — see section below.

Base rate context: Application-layer moats erode slowly when (a) workflows are regulated, (b) data is exclusive, and (c) switching imposes data-migration cost. They erode quickly when the **interface** between user and workflow changes — see Craigslist→specialized apps, retail→Amazon, taxis→Uber. The Anthropic partnership (Feb 2026) is Intuit's bet that the interface change ends with Intuit-as-tool-in-Claude rather than Intuit-as-bypassed [14].

## AI buildout bottleneck map
Intuit is **a consumer**, not a supplier, of AI buildout. Mapping the gating constraints:

- **HBM / CoWoS-L / GPUs:** Indifferent-to-exposed. Intuit doesn't own GPUs; it buys inference through Bedrock/Azure on roughly volume-committed multi-year contracts [9][13]. Cost-of-goods is exposed to frontier inference pricing. Per-token Claude/GPT pricing has fallen ~5–10× over 24 months, which is net positive for Intuit gross margin, but the unit volume per task is rising as agents replace single-shot prompts (multi-turn reasoning, retrieval, tool calls). Net direction: ambiguous.
- **Power / grid interconnect / liquid cooling:** Indifferent. Intuit's compute is hyperscaler-leased — those constraints are AWS/Azure/Google's problem and are priced into Bedrock SKUs.
- **Optical interconnect / NCCL fabric:** Indifferent.
- **Kernel/compiler talent:** Indifferent. Intuit's AI hiring is in MLOps, eval, prompt engineering, agent design — not CUDA/Triton.
- **Frontier model capability:** **Beneficiary.** Better/cheaper Claude and GPT make Intuit's product better at zero incremental capex. This is a long-only argument for buying Intuit if you think frontier capability keeps advancing.
- **Training data quality at the frontier:** **Exclusive supplier in its niche.** Frontier labs lack the granular labeled financial-transaction corpus Intuit has accumulated since QuickBooks 1992. If Anthropic/OpenAI want financial-domain accuracy without violating bank data agreements, they license or partner — which is the read on the Feb 2026 Anthropic deal [14].
- **The actual binding constraint for Intuit:** **Distribution surface area in an agent-mediated world.** If users stop typing "turbotax.com" and start typing "Claude, file my taxes," Intuit needs to be the financial back-end Claude calls. The Anthropic partnership is the explicit play for that slot [14]. The risk: Claude (or ChatGPT) calls Intuit as one of many fungible APIs and disintermediates the brand.

## Competitive teardown
**H&R Block (HRB):** Direct overlap on consumer tax. Lobbying-aligned with Intuit on Direct File; technical AI capability is meaningfully behind. Has retail footprint (8,000+ offices) Intuit lacks, which matters in the LMI segment. Not a near-term share threat in DIY online — Intuit has been gaining share there for a decade — but a useful price floor and a hedge against agentic disintermediation (offices still exist).

**Xero (XRO.AX):** Strong in UK, AU, NZ. ~8.9% global share vs. QB ~62% [5]; effectively zero penetration in the US market, where 86% of QB customers reside [5]. The technical product is competitive; the moat differential is the US accountant/ProAdvisor network. Not a 24-month threat to QB US.

**Sage / NetSuite / FreshBooks / Wave:** Sage 50 holds ~10% but is the legacy desktop product losing share to cloud [5]. NetSuite is Oracle-owned, plays in the mid-market where Intuit Enterprise Suite is the new entrant. Wave/FreshBooks are micro-business; not a competitor to Intuit's monetized base.

**The actual new competitor — agentic horizontal AI (Anthropic, OpenAI, Google):** The technical axis here is **interface displacement**, not feature parity. Claude Cowork (released Feb 2026) demonstrated end-to-end browser control and multi-step task execution that, in principle, could orchestrate any web-based tax or accounting tool without the user ever seeing it [17][18]. This is what triggered Intuit's 11–16% drawdown in February [17]. Intuit's response: partner with Anthropic so Claude calls Intuit APIs natively rather than browser-driving the UI [14]. Outcome unclear. If horizontal agents commoditize "interface to financial tasks," Intuit becomes infrastructure — still a real business, but with weaker pricing power.

**IRS / regulated free option:** Direct File suspended for 2026 [4]. A future administration could revive it. This is the lowest-multiple, highest-tail-risk competitor: it doesn't have to be technically excellent, it just has to be free. Track political probability.

## Bull case — technical
The technical conditions for outperformance:

1. **Frontier inference unit economics continue to deflate** (token cost halving every ~12 months on a quality-adjusted basis). Intuit's COGS for AI features falls faster than its pricing, expanding margin while it monetizes "Intuit Assist" and agents [15]. ~3M customers used agents in Q2 with 85% repeat engagement [3] — the consumption-pricing experiment ($0 for first N uses, then meter) gives Intuit a path to per-seat AND per-token revenue [15].

2. **Financial-domain accuracy is data-bound, not parameter-bound.** Intuit's Financial LLMs and golden-set evals stay measurably ahead of off-the-shelf frontier on transaction categorization and tax reasoning. Frontier models hit a ceiling without licensed banking data. The Anthropic partnership formalizes Intuit as the financial-cognition layer for Claude rather than competitor [14].

3. **Regulatory moat holds.** Direct File stays dead through the 2027 filing season; tax code complexity continues to compound; small business compliance burden continues to grow. Intuit captures the regulatory deltas as recurring upgrade revenue.

4. **Agent-mediated discovery rewards proprietary data, not UI.** As consumers and SMBs use horizontal agents (Claude, ChatGPT), the agents call the API with the best data and the most reliable execution. Intuit wins that auction in financial use cases [14].

Base rate caveat: Software application moats have historically been robust through prior platform shifts (PC→web, web→mobile) — Intuit survived both and gained share each time. The agentic shift is, however, more analogous to the search-engine-as-aggregator shift than to mobile (which mostly preserved app-level brand). Historical base rate for incumbent application survival through a true interface shift: ~50%, with strong correlation to depth of proprietary data and regulatory entanglement. Intuit scores high on both.

Financial connect: At a $396 price, ~16× FY26 EPS, the stock prices in roughly zero terminal value beyond mid-teens earnings growth for ~4 years. If the technical conditions above hold and FY27/28 revenue growth stays in the low-teens with operating leverage, fair value clears $600 (matching consensus median PT [10]).

## Bear case — technical
The honest short version:

1. **Per-seat pricing dies for QuickBooks before consumption pricing matures.** SMBs use Claude/ChatGPT as the primary interface, run AI bookkeeping inside the agent, and use Intuit only for the regulated filing step. QB-Online ARPU compresses faster than agent ARPU grows. The "consumption monetization" CEO Balazs describes [15] is still in test — not at scale — and SMBs are notoriously price-sensitive on incremental token bills.

2. **TurboTax Live is the giveaway.** Intuit reported TurboTax Live +47% in FY25 and +51% in Q1 FY26 [3][16] — i.e., the growing piece is the **human-expert-assisted** tier. That growth is consistent with the bear thesis: pure-software DIY tax filing is being commoditized by AI, and the only premiumization path is humans-in-loop. Margins on humans are structurally lower than on software.

3. **Custom Financial LLM advantage is overstated.** "90% transaction categorization accuracy, 50% lower latency" [13] is benchmarked against general-purpose LLMs on Intuit's eval, not against fine-tuned competitors on shared benchmarks. Anthropic and OpenAI can both fine-tune on financial data with bank partnerships (Plaid, Stripe). The data advantage may be 12–24 months, not durable.

4. **The Anthropic partnership is a Faustian bargain.** "TurboTax in Claude" [14] means Anthropic owns the customer relationship and Intuit becomes a back-end. Anthropic captures the brand affinity, the upsell surface area, the cross-sell. Intuit's customer acquisition cost via Claude is zero in the short run and infinite in the long run if Anthropic builds or partners with a substitute.

5. **The valuation has already de-rated and could de-rate further.** INTU fell from $813.70 to $396.31 [10][21] — a ~51% drawdown from peak — and is still 16× forward EPS. ServiceNow-style multiple compression to 12× on slowing growth implies low-$300s. If Q3 (reporting May 20) prints slowing live-engagement metrics, the stock has more room down.

Falsifier the bear has to monitor: if Intuit's consumption-pricing experiment scales to >5% of QB Online revenue by end of FY26, the per-seat death narrative breaks.

## Market view check
Consensus is bullish — 29 buys, 5 holds, 0 sells, median PT $590 [10]. The 32-analyst price-target spread of $425–$916 is unusually wide for a $110B mega-cap, which is itself the signal: analysts disagree on the **technical** thesis (will agents disintermediate?), not on the financial trajectory (which is well-guided). At 16× forward EPS, INTU now trades at a discount to its 5-year average (~30×) and to its software peer set (median ~25× per MS comp data), implying the market is pricing meaningful terminal value erosion from AI disintermediation. My read: the market is correctly identifying the risk but possibly mispricing the probability — the Anthropic partnership and the data moat are real, and the regulatory entrenchment is underappreciated by the same analysts focused on SaaS multiples. The asymmetry is moderately favorable, with the key qualifier being that the bear thesis is **not** ridiculous and one needs to size accordingly.

## 90-day falsifiers
1. **Q3 FY26 earnings (May 20, 2026):** Watch QuickBooks Online net-paid-customer additions sequential, TurboTax Live attach rate, and any disclosure of consumption-revenue dollars. Guide raise = bullish; reaffirmation only = neutral; weakness in QB net adds = bear-confirming [19][20].
2. **TurboTax 2026 tax-season completion data (Q4 FY26 release in August):** Total returns filed YoY. >2% growth = brand intact; flat-to-down = agents are taking share.
3. **Anthropic / OpenAI fine-tuned financial model release on a shared public benchmark:** If a frontier model reaches within 5% of Intuit Financial LLM accuracy on a published transaction-categorization benchmark, the data moat shrinks materially.
4. **Direct File political signal:** Any Senate hearing or appropriations rider reviving Direct File. Currently extremely low probability under current administration; watch for Democratic primary positioning.
5. **AWS/Azure/Google Bedrock pricing announcements:** Token-cost halvings for Claude or GPT support the bull's COGS-tailwind argument. Capacity-allocation tightness (e.g., provisioned-throughput price hikes) would compress Intuit margins.
6. **Claude Cowork adoption metrics:** If Anthropic discloses a usage milestone showing autonomous-agent task completion of financial workflows >10M monthly, multiple compression resumes regardless of Intuit's partnership status.

## What I could not verify
- Intuit's specific dollar spend on third-party LLM inference (OpenAI/Anthropic/AWS). The Anthropic case-study PDF [9] was not text-extractable in this session; the multi-year commit terms are opaque.
- The Intuit Financial LLM's parameter count, base architecture, and which open-weights model it was fine-tuned from (if any). Press releases describe outcomes, not architecture.
- Independent (non-Intuit-published) benchmarks of Intuit Financial LLMs vs. fine-tuned Claude/GPT on the same financial tasks. The 90% / 50%-latency numbers are vendor-self-reported [13].
- Exact terms of the Anthropic partnership — is it preferred-vendor, exclusive, or revenue-share on Intuit-in-Claude usage? Press releases do not disclose.
- Whether the consumption-pricing experiment has scaled materially. CFO Brew piece [15] is a CTO interview, not a disclosed financial metric.
- The Stratechery analyst take on Intuit specifically — no Intuit-focused piece surfaced in search, only adjacent SaaS-disruption posts [18].
- Exact YTD return — sourced as ">40%" by IndexBox and Trefis; mechanical calculation from a Jan 2 close not directly confirmed.
- Whether ProAdvisor / accountant churn has changed under AI pressure — no current data.

## Sources
[1] https://capital.com/en-int/markets/shares/intuit-inc-share-price-1/market-cap — retrieved 2026-05-10 — INTU market cap May 2026 ~$108–112.5B
[2] https://investors.intuit.com/news-events/press-releases/detail/1272/intuit-rapidly-advances-genos-to-accelerate-development-of-agentic-ai-experiences-at-scale — retrieved 2026-05-10 — GenOS architecture components (GenStudio, GenRuntime, GenUX)
[3] https://www.fool.com/earnings/call-transcripts/2026/02/26/intuit-intu-q2-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q2 FY26 transcript: 3M agent users, 237M transactions in Jan, 85% repeat
[4] https://www.opensecrets.org/news/2026/04/intuit-and-hr-block-set-lobbying-records — retrieved 2026-05-10 — $103M Intuit+HRB lobbying since 2003 to kill Direct File
[5] https://electroiq.com/stats/quickbooks-statistics/ — retrieved 2026-05-10 — QB 62.23% accounting share, Xero 8.9%, US-only 86%
[6] https://www.gurufocus.com/term/forward-pe-ratio/INTU — retrieved 2026-05-10 — Forward P/E ~15.30 as of April 2026
[7] https://multiples.vc/public-comps/intuit-valuation-multiples — retrieved 2026-05-10 — INTU EV/Rev ~5.9× Apr 2026
[8] https://seekingalpha.com/news/4558402-intuit-reaffirms-12-13-percent-revenue-growth-guidance-for-2026 — retrieved 2026-05-10 — FY26 guide $20.997–21.186B revenue, EPS $22.98–23.18
[9] https://www.intuit.com/blog/innovative-thinking/tech-innovation/ai-principles-openai-anthropic-partnerships/ — retrieved 2026-05-10 — GenOS uses Claude/Bedrock, GPT/Azure, multi-region
[10] https://public.com/stocks/intu/forecast-price-target — retrieved 2026-05-10 — 32-analyst consensus, median PT $590, range $425–$916; 52-wk $342.11–$813.70
[11] https://www.marketbeat.com/stocks/NASDAQ/INTU/short-interest/ — retrieved 2026-05-10 — Short interest 7.24M shares, 2.97% of float
[12] https://accountants.intuit.com/taxprocenter/practice-management/a-deep-dive-into-intuit-accountant-suite/ — retrieved 2026-05-10 — ProAdvisor program, 50,000+ certified, ProConnect/QBOA integration
[13] https://venturebeat.com/ai/how-intuit-built-custom-financial-llms-that-cut-latency-50-while-boosting — retrieved 2026-05-10 — Intuit Financial LLM 90% accuracy, 50% latency cut, 44M tax returns
[14] https://investors.intuit.com/news-events/press-releases/detail/1305/intuit-and-anthropic-partner — retrieved 2026-05-10 — Anthropic partnership Feb 24 2026, Claude Agent SDK, TurboTax/QB in Claude
[15] https://www.cfobrew.com/stories/2026/04/14/intuit-cto-alex-balazs-saas-pocalypse — retrieved 2026-05-10 — Balazs on UI/workflow disruption, freemium-then-meter pricing
[16] https://investors.intuit.com/news-events/press-releases/detail/1266/intuit-reports-strong-fourth-quarter-and-full-year-fiscal-2025-results — retrieved 2026-05-10 — FY25: $18.8B revenue +16%, TurboTax Live +47%, Credit Karma $2.3B +32%
[17] https://markets.financialcontent.com/stocks/article/marketminute-2026-2-6-anthropics-claude-cowork-release-triggers-285-billion-saaspocalypse — retrieved 2026-05-10 — Claude Cowork release, $285B wipeout, INTU -11–16%
[18] https://stratechery.com/2026/agents-over-bubbles/ — retrieved 2026-05-10 — Thompson on horizontal vs. app-bound agents
[19] https://www.stocktitan.net/news/INTU/intuit-to-announce-third-quarter-fiscal-year-2026-results-on-may-f73d7p6pqqx3.html — retrieved 2026-05-10 — Q3 FY26 reporting May 20, 2026
[20] https://www.thestockobserver.com/2026/02/26/intuit-nasdaqintu-updates-q3-2026-earnings-guidance.html — retrieved 2026-05-10 — Q3 guide ~10% rev growth, non-GAAP EPS $12.45–12.51
[21] https://finance.yahoo.com/quote/INTU/ — retrieved 2026-05-10 — INTU $396.31 close May 8, 2026