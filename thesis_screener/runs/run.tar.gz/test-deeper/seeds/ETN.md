# ETN — Eaton Corporation plc

## Where this sits in the AI stack
Eaton sells the **electrical infrastructure between the utility substation and the GPU rack** — medium-voltage switchgear, busways, low-voltage distribution, uninterruptible power supplies, and (via the March 2026 $9.5B Boyd Thermal acquisition) liquid cooling CDUs and cold plates [4][7]. It does not sell silicon, networking, or software. It sits *upstream* of NVIDIA on the power side: every gigawatt of AI compute requires roughly $80–120M of Eaton-class electrical content, with lead times now longer than the GPUs themselves. The relevant workload is **frontier-scale training and high-density inference clusters** (50–250 kW/rack today, 1 MW/rack on the NVIDIA Rubin/Kyber roadmap for 2027) [11].

## Snapshot
- **Price:** $401.51 (2026-05-08 close) [1]
- **Market cap:** $163.4B [1]
- **52-week range:** $231.85 – $435.43 [13]
- **Forward P/E:** 31.5× (on FY26 consensus EPS ~$13.30; company guide $13.05–$13.50) [3][9][12]
- **EV / NTM revenue:** ~5.4× (EV ≈ $173B incl. Boyd financing; NTM rev ~$32B inferred from Q1 $7.45B run-rate plus organic 10% and Boyd contribution) [2][6]
- **Consensus 12-month price target:** $417 median / $402 average — roughly flat to current price [9]
- **YTD total return:** +35% (vs. S&P ~flat YTD) [13]
- **Short interest (% of float):** n/a — not consistently reported in retrieved sources; historically <2% on Eaton [14]
- **Dividend yield:** 1.1% ($4.40 annualized) [12]

## Moat — what it is physically made of
The "Eaton moat" is not a brand. Decomposed:

**1. Switchgear manufacturing capacity (the durable piece).** Medium-voltage switchgear lead times sit at ~52+ weeks; large substation transformers at >160 weeks, up from ~140 in 2023 [5]. Eaton has committed >$1.5B in capacity expansions since 2023 — a new $30M / 370,000 sq ft Omaha gas-insulated and air-insulated MV switchgear plant comes online H1 2027 [16], among 12 factory ramp-ups management is funding in 2026 [17][18]. This is not a moat of know-how — switchgear technology is well-understood — it is a moat of *finished, certified, in-production lines*. A new entrant cannot stand up UL/IEEE-certified arc-resistant MV switchgear capacity in under 3-4 years, and hyperscalers will not de-risk a $5B campus on an unqualified supplier.

**2. Hyperscaler and utility qualification lists.** Eaton, Schneider, Vertiv, ABB, and Siemens are the qualified vendors on essentially every Tier 1 hyperscaler and IOU spec sheet. Displacement requires multi-year qualification, factory audits, and field reliability data. This is closer to an aerospace-supplier moat than a semiconductor moat.

**3. NVIDIA "grid-to-chip" reference design partnership.** Eaton co-developed the **Beam Rubin DSX** platform with NVIDIA, integrated into the Vera Rubin DSX AI Factory reference design and Omniverse DSX blueprint, with digital twins of Eaton hardware in OpenUSD format [7]. *Important caveat:* ABB, Vertiv, Hitachi, and Schneider are also NVIDIA 800 VDC ecosystem partners [11][19][20]. This is a *credentialing* event, not an exclusive franchise. Inference: useful for marketing and design-in, but does not create lock-in at the component level.

**4. Solid-state transformer (SST) lead.** Eaton is piloting ~10 medium-voltage SST projects with hyperscalers, with shipments targeted late 2027/early 2028 [4][21]. SSTs replace traditional iron-core grid transformers with SiC-based power electronics, achieve ~99% efficiency, and compress site interconnect timelines [21][22]. This is the one place where Eaton has a genuine technology lead vs. legacy peers — but Amperesand (ex-ABB/GE/Siemens engineers) and ABB itself are credible challengers, and the technology is patent-fragmented across silicon carbide vendors (Wolfspeed, Infineon). Durability of this lead: probably 18–36 months, not a decade.

**5. Boyd Thermal — bought, not built.** Eaton paid $9.5B (22.5× 2026E EBITDA) for Boyd's liquid-cooling business to enter the same TAM Vertiv has owned [10][15]. This closes a portfolio gap but does *not* create a moat against Vertiv, which had a 109% YoY backlog increase to $15B and dominant share in CDUs and rear-door heat exchangers [23][24].

**Honest assessment:** The durable moat is #1 + #2 — physical switchgear capacity and decades-deep customer qualifications. Everything else is contestable. The Eaton bull case at 31× forward P/E requires the market to believe #3, #4, and #5 are also moats. They are not.

## AI buildout bottleneck map
The actual gating constraints on AI data center delivery over the next 24 months, with Eaton's position:

| Bottleneck | State of constraint | Eaton position |
|---|---|---|
| Grid interconnect / utility capacity | 92% of DC operators cite this as #1 barrier (Schneider 2025 survey); ~half of planned 2026 US AI DCs canceled or delayed [5][25] | **Exposed customer** (slows shipments) but also **supplier** (SSTs compress interconnect time) |
| Large power transformers | 160+ wk lead times, up from 140 wk in 2023 [5] | **Supplier / beneficiary** — Eaton MV/LV transformers in this queue |
| Gas turbines | GE Vernova 80GW backlog into 2029; Mitsubishi/Siemens Energy slots booked through 2028 [26][27] | **Indirect beneficiary** — every turbine delivery needs switchgear |
| MV switchgear | ~52 wk lead times, the chokepoint inside the DC fence [5][16] | **Direct beneficiary, market leader along with Schneider/ABB** |
| Liquid cooling (>50kW/rack) | Vertiv shipping 200kW+ CDUs; Schneider RD110/111 for GB300; Eaton via Boyd entering | **Late entrant** (post-Boyd) |
| Electrical contractor labor | Multi-year shortage of high-voltage electricians | **Indifferent** (the customer's problem) |
| CoWoS-L packaging | TSMC capacity 35K→130K WPM by EOY26; NVIDIA secures 60% [28] | **Indifferent** — upstream of Eaton's box |
| HBM3e/HBM4 yield | Severely constrained | **Indifferent** |
| Optical interconnect | Constrained, but secondary | **Indifferent** |

Eaton sits in the *most* constrained physical layer (electrical), but is exposed to the worst constraint (grid interconnect) on the demand side. This is why management talks about "12 years of data center backlog at 2025 build rates" [4] — the ~228 GW figure is the *industry pipeline*, not Eaton's order book. Eaton's actual electrical backlog is $14.5B, total backlog $22.8B with 68% deliverable within 12 months and book-to-bill 1.2× [2][4].

## Competitive teardown

**Vertiv (VRT).** The most direct AI-pureplay peer. Q4 2025 organic orders +252% YoY, $15B backlog, 2.9× book-to-bill, 2026 guide of $13.25–13.75B revenue [23][24]. Vertiv has the lead in **direct-to-chip liquid cooling at the rack level** (Liebert XDU 200kW+, CoolChip CDUs working with NVIDIA cold plates) [19][24]. Eaton is *behind* here — the Boyd acquisition is the catch-up move. On *power*, Vertiv plays UPS and PDU but has less MV switchgear depth than Eaton. **What has to be true for Vertiv to take more share:** continued faster cadence on liquid-cooling product cycles and deeper hyperscaler design wins. Already happening on the cooling side.

**Schneider Electric (SU.PA).** The global #1 in data center power broadly. EcoStruxure platform; co-developed NVIDIA reference designs RD110/RD111 for GB300 NVL72 at 142 kW/rack [19]. Stronger international footprint, comparable US presence. **What has to be true:** Schneider already has parity-or-better on most axes; the share question is execution and capacity. Schneider's European manufacturing exposes it to electrical steel and Chinese tariff dynamics more than Eaton's heavily US-onshored footprint [5][16].

**ABB.** Strong in modular MV power and HVDC. Co-named NVIDIA 800 VDC ecosystem partner [11][20]. Less depth in US hyperscaler accounts than Eaton/Schneider. **What has to be true:** ABB wins the SST race outright via its semiconductor power-electronics depth — a credible but not yet visible scenario.

**Siemens Energy / GE Vernova.** Adjacent — they sell upstream (turbines, large transformers). Not direct competitors in the data center fence, but their lead times constrain Eaton's customers.

**Honest read on share:** The big four (Schneider, Eaton, Vertiv, ABB) collectively hold ~40–60% depending on the segment cut [8]. None are losing share to disruption; they are *gaining together* because the TAM is doubling. The competitive question is not market share but *capacity allocation* — and Eaton has been most aggressive on US capex.

## Bull case — technical

For ETN to outperform from $400 over 18 months, this technical sequence has to hold:

1. **Hyperscaler capex maintained or growing through 2026–27.** Microsoft, Meta, Google, Amazon collective capex >$400B/yr through 2027 — currently the signal is intact and Q1 2026 guidance was raised, not cut.

2. **Grid bottleneck remains binding.** Each year that grid interconnect stays at 4-7 year wait times, Eaton's behind-the-meter and SST products become more valuable. **Base rate on infrastructure displacement:** physical electrical equipment moats are highly durable — the CPU→GPU transition took ~15 years even with a clear performance gap. There is no analog displacement threat to medium-voltage switchgear in any meaningful horizon.

3. **800 VDC architecture rolls out on NVIDIA's published 2027 Rubin Ultra timeline** [11], and Eaton's reference-design integration translates to design-in wins at 30%+ ASP uplift over 54 VDC content.

4. **SST commercialization succeeds on Eaton's pilot timeline** (late 2027 shipments) before ABB/Amperesand scale. Each successful hyperscaler SST deployment is worth $20–40M of content per site at margins materially above Eaton corporate average.

5. **Boyd integration recovers the $9.5B acquisition multiple** — 22.5× EBITDA is rich and only justifies itself if Boyd grows >25% per year for 5+ years on the back of liquid cooling proliferation.

Financial translation: if Electrical Americas margins recover to the 30% target by 2028 (from 25.6% Q1 trough on factory ramp costs [3]) and revenue compounds at 10–12% organically through 2028, EPS reaches ~$17–18 by 2027 vs. consensus $15.42 [12]. At a 25× multiple (de-rating from current 31× as growth normalizes), that is $425–450 — modest upside, not a multi-bagger.

## Bear case — technical

What a short-seller who understands the stack would write:

1. **The 240% Q1 order growth is the cycle peak, not the run-rate.** Book-to-bill of 1.2 is healthy but well off Vertiv's 2.9×; on a 2-year stack, comparisons get brutal in 2H26. Hyperscaler 2024–25 over-ordering on electrical gear (because lead times are 1+ year) is now embedded in Eaton's backlog. **Falsifier we are watching:** sequential order growth in Q2/Q3.

2. **The 228 GW "industry pipeline" is being marketed as backlog.** Half of planned 2026 US AI DCs are already canceled or delayed [5][25]. If even a third of the announced pipeline doesn't get built (because of grid, water, permitting, or AI demand softening), Eaton's *future* order growth stalls even if current backlog ships fine.

3. **Margin trough is real but the recovery is uncertain.** Electrical Americas margins fell 440 bp YoY to 25.6% on factory ramp costs [3]. Management asserts these are "temporary" and targets 30% by 2030, but 12 simultaneous factory ramps + tariff-volatile electrical steel + 20%+ copper price moves [5] creates execution risk that isn't in the multiple.

4. **31× forward P/E is a tech multiple on an industrial business cycle.** Eaton historically traded 18–22× forward as an industrial diversified. The current multiple requires the market to treat AI infrastructure exposure as durable as semis. Recent comparable: industrial cycle re-rating in late-2018 reversed in 2019 even before COVID.

5. **800 VDC adoption could *reduce* Eaton's per-rack ASP, not increase it.** SSTs eliminate stages of conversion. If hyperscalers consolidate on SST + direct DC, traditional UPS content (Eaton's strength) shrinks per MW. The ecosystem partnership matters less if the underlying box count drops.

6. **Boyd Thermal is overpaid catch-up M&A in a market where Vertiv has the technology and customer lead.** 22.5× EBITDA at a cycle peak is the kind of multiple that takes 7+ years to earn out — and only if the cooling market grows as forecast.

7. **NVIDIA partnership is a credential, not a moat.** ABB, Schneider, Vertiv, Hitachi all sit on the same Vera Rubin / Omniverse DSX reference design [11][19][20]. The relationship does not lock customers to Eaton at the component level.

## Market view check
The market is pricing Eaton at 31.5× forward EPS, ~5.4× NTM revenue, with a +35% YTD return [13]. Consensus 12-month price target ($401–417) is essentially at the current price [9] — meaning the sell-side already believes the AI thesis is priced in. The implied view: Eaton is a structural beneficiary of a 10+ year buildout, deserves a tech-adjacent multiple, and the Boyd acquisition was strategically sound. **The market is right about the demand and wrong about the moat.** Demand will likely outrun bears for 2-4 more quarters; the moat is shallower than a 31× multiple implies. Eaton is correctly identified as exposed, but the franchise quality is industrial (~22× historical), not semiconductor-platform (~30×+). Net: the stock can grind higher into 2026 on order momentum but the multiple is the asymmetric risk.

## 90-day falsifiers
- **Q2 2026 earnings (early August):** Sequential data center order growth. A deceleration below ~+30% sequential, or *any* sequential decline, materially undermines the supercycle narrative.
- **Electrical Americas margin recovery:** Management guided +150 bp Q1→Q2 [3]. Miss = factory ramps not absorbing as fast as claimed.
- **GE Vernova Q2 results (late July):** Turbine slot/backlog book — directionally tells you how durable downstream electrical demand is.
- **Hyperscaler Q2 capex guides (MSFT/META/GOOG/AMZN late July):** A >10% sequential cut to FY26 capex by any one of the four is a serious red flag; a synchronized cut is thesis-breaking.
- **NVIDIA GTC fall 2026 + 800 VDC product launches:** Eaton's 800 VDC architecture ships H2 2026 [4][11]. Watch for either (a) co-launch announcements naming Eaton as primary on specific hyperscaler sites, or (b) ABB/Vertiv winning the same slots.
- **AMD MI400 / Instinct ramp data:** If MI400 takes >15% of training share in 2H26, NVIDIA-specific Eaton design-ins lose some leverage (though AMD racks also need MV switchgear — neutral on Eaton's core, negative on the partnership-premium).
- **PJM / ERCOT interconnect queue movements:** Any signal of accelerated queue reform that meaningfully shortens grid hookup times would *reduce* Eaton's SST option value.

## What I could not verify
- Eaton's specific US switchgear market share by sub-segment (numerous sources cite the top 4–5 collectively at 40–62% but discrete shares were not consistently sourced).
- Exact short interest % of float (sources track it but the specific current figure was not directly retrievable).
- Whether the NVIDIA "Beam Rubin DSX" naming implies any exclusivity or first-call positioning relative to ABB/Vertiv/Schneider — appears to be a non-exclusive ecosystem credential, but Eaton press releases have used promotional framing.
- Whether the 228 GW data center pipeline figure includes all Eaton-addressable projects or is a self-selected subset.
- Granular MLPerf-style benchmark equivalent for power infrastructure — there is no independent benchmarking body for switchgear/UPS efficiency at hyperscale comparable to MLPerf, which makes vendor claims hard to falsify externally.
- The unit economics of Boyd Thermal at hyperscaler scale, since pre-acquisition financials were limited to Boyd Corp's broader (now-divested) holding-co disclosures.
- Eaton's specific tariff exposure on Chinese electrical-steel-content components vs. competitors — sources confirm the industry is exposed but vendor-specific breakdowns were not available.
- Whether the "10 SST pilot projects" Eaton cites are funded purchase orders or non-binding letters of intent.

## Sources
[1] https://meyka.com/blog/etn-eaton-earnings-beat-q2-2026-results-exceed-expectations-0605/ — retrieved 2026-05-10 — Eaton current price $401.51 (May 9), market cap $163.45B
[2] https://www.businesswire.com/news/home/20260504450402/en/Eaton-Reports-Record-First-Quarter-2026-Results — retrieved 2026-05-10 — Q1 2026 record; raised organic guide to 10%
[3] https://www.investing.com/news/company-news/eaton-q1-2026-slides-record-orders-offset-by-margin-pressure-93CH-4660339 — retrieved 2026-05-10 — Q1 segment margins, Electrical Americas margin trough at 25.6%, segment-level revenues and guidance
[4] https://www.fool.com/earnings/call-transcripts/2026/05/05/eaton-etn-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q1 transcript: 240% data center order growth, 228 GW industry backlog, SST pilots, Boyd Thermal financials, 800 VDC timing
[5] https://tech-insider.org/us-ai-data-center-delays-cancellations-7gw-capacity-crisis-2026/ — retrieved 2026-05-10 — Switchgear lead times, transformer lead times >160 wk, 50% of US AI DC plans canceled/delayed
[6] https://www.eaton.com/content/dam/eaton/company/investor-relations/quarterly-earnings/filings/2026/q1/q1-2026-analyst-presentation.pdf — retrieved 2026-05-10 — Eaton Q1 2026 analyst slide deck
[7] https://www.eaton.com/us/en-us/company/news-insights/news-releases/2026/eaton-collaborates-with-nvidia-to-unveil-its-beam-rubin-dsx-platform.html — retrieved 2026-05-10 — Eaton Beam Rubin DSX platform launch with NVIDIA at GTC 2026; $7T data center buildout TAM cited
[8] https://www.marketsandmarkets.com/ResearchInsight/data-center-power-market.asp — retrieved 2026-05-10 — Big four (Schneider, Vertiv, Eaton, ABB) collectively ~41–43% global DC power share
[9] https://stockanalysis.com/stocks/etn/forecast/ — retrieved 2026-05-10 — Analyst consensus rating "Buy", median PT $417, average PT $401.95
[10] https://www.datacenterdynamics.com/en/news/eaton-acquires-boyd-thermal-for-95bn-to-further-liquid-cooling-portfolio/ — retrieved 2026-05-10 — Boyd Thermal $9.5B price, 22.5x 2026E EBITDA, $1.7B revenue
[11] https://developer.nvidia.com/blog/nvidia-800-v-hvdc-architecture-will-power-the-next-generation-of-ai-factories/ — retrieved 2026-05-10 — NVIDIA 800 VDC technical architecture, Rubin Ultra/Kyber 1 MW racks, 2027 rollout
[12] https://www.gurufocus.com/term/forward-pe-ratio/ETN — retrieved 2026-05-10 — Forward P/E 31.45 as of April 28, 2026; FY26/27 consensus EPS
[13] https://www.financecharts.com/stocks/ETN/performance/total-return — retrieved 2026-05-10 — YTD return ~35%, 52-week range
[14] https://fintel.io/ss/us/etn — retrieved 2026-05-10 — Short interest tracking page (specific figure not retrievable in snippet)
[15] https://www.bloomberg.com/news/articles/2025-11-03/eaton-to-buy-boyd-thermal-for-9-5-billion — retrieved 2026-05-10 — Boyd Thermal deal announcement, strategic rationale
[16] https://www.businesswire.com/news/home/20260408952863/en/Eaton-Expands-Operations-in-Nebraska — retrieved 2026-05-10 — Omaha switchgear plant $30M, 370k sq ft, online H1 2027
[17] https://seekingalpha.com/news/4546501-eaton-outlines-2026-organic-growth-of-7-percent-9-percent-and-targets-30-percent-electrical — retrieved 2026-05-10 — 12 new factory ramps, 30% Electrical Americas margin target
[18] https://www.renewableenergyworld.com/power-grid/eaton-increases-us-made-medium-voltage-switchgear-production-to-help-meet-data-center-demand/ — retrieved 2026-05-10 — Eaton >$1.5B in mfg capex since 2023
[19] https://blog.se.com/datacenter/2026/01/06/how-liquid-cooling-reference-designs-optimize-ai-data-center-deployments/ — retrieved 2026-05-10 — Schneider RD110/RD111 for GB300 NVL72 at 142 kW/rack
[20] https://www.datacenterfrontier.com/energy/article/55323139/preparing-for-800-vdc-data-centers-abb-eaton-support-nvidias-ai-infrastructure-evolution — retrieved 2026-05-10 — ABB, Eaton, Vertiv all named in NVIDIA 800 VDC ecosystem
[21] https://www.powermag.com/the-solid-state-shift-reinventing-the-transformer-for-modern-grids/ — retrieved 2026-05-10 — SST technology, 97.5–99% efficiency, Eaton MV-SST development
[22] https://www.wolfspeed.com/knowledge-center/article/powering-ai-with-reliable-silicon-carbide-based-solid-state-transformers/ — retrieved 2026-05-10 — SiC-based SSTs for AI data centers
[23] https://seekingalpha.com/article/4890719-vertiv-holdings-the-15-billion-backlog-liquid-cooling-dominance-and-the-ai-infrastructure-trade — retrieved 2026-05-10 — Vertiv $15B backlog, 2.9× book-to-bill, 252% organic order growth
[24] https://introl.com/blog/vertiv-schneider-eaton-cooling-solutions-comparison-ai-data-centers — retrieved 2026-05-10 — Vertiv Liebert XDU 200kW+ CDUs, comparative cooling capabilities
[25] https://www.woodmac.com/news/opinion/mind-the-gap-tackling-supply-chain-challenges-in-the-electric-td-sector/ — retrieved 2026-05-10 — T&D supply chain constraints, electrical steel pricing
[26] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — GE Vernova 80GW gas turbine backlog into 2029
[27] https://www.bloomberg.com/features/2025-bottlenecks-gas-turbines/ — retrieved 2026-05-10 — Siemens Energy/Mitsubishi gas turbine slots booked through 2028
[28] https://www.astutegroup.com/news/industrial/advanced-packaging-demand-soars-nvidia-secures-60-of-cowos-capacity/ — retrieved 2026-05-10 — NVIDIA ~60% CoWoS allocation 2026; TSMC capacity expansion 35K→130K WPM