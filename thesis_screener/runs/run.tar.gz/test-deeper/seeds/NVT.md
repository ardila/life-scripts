# NVT — nVent Electric plc

## Where this sits in the AI stack
nVent sells physical electromechanical infrastructure that wraps around the rack — not silicon, not software. Its "white space" products go inside or beside the AI rack: coolant distribution units (CDUs), rear-door heat exchangers (RDHX), direct-to-chip cold-plate manifolds, busways, PDUs, and Hoffman/Schroff enclosures. Its "gray space" products (~20% of data-center mix vs ~80% white space) go in the substation, switchroom, and outside-plant area: engineered control buildings via Trachte, switchgear and bus systems via the acquired Avail Electrical Products Group, and ERIFLEX copper flexible busbar for low-voltage power distribution. The relevant workload is high-density training and inference racks at ≥100 kW/rack — Blackwell NVL72, GB300, and the next-cycle Vera Rubin platforms that have no air-cooled variant [1][6][8][12].

## Snapshot
- **Price:** ~$170 (2026-05-10 close; intraday range $166.25–$174.18) [1]
- **Market cap:** ~$27.5B [1]
- **52-week range:** $59.57 – $174.18 [10][1]
- **Forward P/E:** ~38× on FY26 guided adj. EPS midpoint of $4.50 (raised from $4.075 at year-start) [4][14]; GuruFocus reports 33.9× on consensus that pre-dates the Q1 print
- **EV / NTM revenue:** ~5.5–6× on ~$5B NTM revenue (FY26 guide implies ~$4.85B reported, ~26–28% growth) [4]
- **Consensus 12-month price target:** in flux post-earnings; pre-Q1 mean was ~$140, post-Q1 cluster from raised PTs is $180–$200 (RBC, Evercore ISI, Goldman, UBS at $200, Barclays, Keybanc, Roth at $185) [1][16]
- **YTD total return:** ~+35–45% (33.65% as of late April; further rally on the Q1 print May 1) [17]
- **Short interest (% of float):** 2.0%, ~1.3 days to cover — no short conviction [13]

## Moat — what it is physically made of
Be honest: this is not a CUDA-class moat, and pretending otherwise is the analyst's trap on this name. nVent's moat is the *mechanical* version of a moat — narrower, shallower, and built from physical and channel components, not software switching costs.

Decomposed:

1. **Brand and installed base in enclosures.** Hoffman (North America) and Schroff (Europe/global) are the de-facto reference brands for industrial and IT enclosures. When a hyperscaler bid drops, Hoffman/Schroff is on the spec list by default. This is genuine — but it is a *channel* and *qualification* moat, not a technology moat. Durability: medium (decades of inertia, but specifiable around).

2. **Liquid cooling engineering depth, organically developed.** nVent's own framing in the Q1 call is informative: "Our liquid cooling capability was developed organically, starting pre–data centers in industrial and medical applications" [11]. That heritage in process-cooling (pumps, manifolds, heat exchangers, leak-detection, dielectric coolant compatibility) is real engineering capital. They also claim CDU roadmaps "out to 2030 with some chip manufacturers" [11], implying co-design relationships. Durability: medium. The physics (flow rate, pressure drop, approach temperature) are not proprietary — a competent ME team can replicate.

3. **Project Deschutes 5 compliance.** Google open-sourced the 2 MW, 80 psi, 3 °C ATD CDU specification via OCP in 2025 [3]. nVent is named alongside Delta, Stulz, Boyd, CoolerMaster, Envicool, Nidec, and Vertiv as building Deschutes-compliant CDUs [3][7]. **This is the opposite of a moat.** The reference design exists precisely to commoditize the CDU. Being one of 7+ named suppliers means margin pressure, not pricing power. The hyperscaler did the IP work and is buying contract manufacturing of a known design.

4. **Manufacturing capacity and lead time.** New Blaine, MN facility online, Q1 capex up 70% YoY to $36M, FY26 capex ~$130M [11]. In a market where the binding constraint is *throughput, not design*, ramped capacity is a real near-term moat — but it's a moat that closes as competitors finish their own capex.

5. **Bundling across white + gray space.** Trachte ($695M, July 2024) gives modular E-houses and engineered control buildings; Avail EPG ($980M, May 2025) adds switchgear and bus systems; ERIFLEX gives flexible busbar [2][9]. The pitch is one-vendor procurement across mechanical and electrical infrastructure for a campus. Durability: medium. Bundling is reversible by a sophisticated buyer, and hyperscalers are sophisticated buyers.

6. **Patents and IP.** Not a meaningful source of moat in this category. Hyperscalers and OCP open-source most of the relevant rack/CDU geometry. nVent has product-level patents on Flexibar construction and specific enclosure features but nothing that prevents Schneider/Vertiv/Eaton from competing on adjacent designs.

Summary: nVent's moat is "manufacturing scale + channel + bundling + qualified-vendor status," not technology. That's a 60–70 % gross-margin-impossible market, not an 80%-margin software market. The financials confirm this: gross margin is 36% and declined ~290 bps YoY in Q1 [8]. This is industrial economics, not platform economics.

## AI buildout bottleneck map
The 24-month bottleneck list, with NVT positioning:

- **CoWoS-L advanced packaging.** TSMC scaling from ~35k → 130k wpm by end-2026; HBM3E fully allocated through 2026 [15]. *NVT: indifferent.* No exposure on either side.
- **HBM supply (SK Hynix, Micron, Samsung).** Sold out through 2026 [15]. *NVT: indifferent.*
- **Heavy-duty gas turbine supply (GE Vernova, Siemens Energy, Mitsubishi Power).** GEV order book ~80 GW vs 20 GW/yr output; new orders deliver 2030+ [18]. *NVT: indirect beneficiary* — turbine scarcity drives onsite-gen build-out, which drives Trachte E-house demand and Avail EPG switchgear demand.
- **HV transformers and switchgear.** 5-year lead times [18]. *NVT: direct beneficiary* via the Avail EPG acquisition — switchgear and bus systems sit precisely on this bottleneck. This is the most under-discussed reason to own NVT and probably the most durable.
- **Liquid cooling at >100 kW/rack.** GB200 NVL72 is 120 kW; the rack ships with manifolds pre-plumbed and no air-cooled variant [6][5]. *NVT: supplier.* Direct exposure; competitive (see below) but real.
- **Grid interconnect queues.** Years. *NVT: indifferent* on interconnect itself, beneficiary downstream of behind-the-meter solutions.
- **Electrical contractor capacity.** A real constraint. *NVT: indifferent*, but Trachte's modular pre-fab approach reduces field labor — this is its actual value proposition.
- **Optical / scale-out networking, kernel/compiler talent, frontier training data.** *NVT: indifferent.*

Read: NVT is a "picks-and-shovels" name for the *power and cooling* slice, with secondary exposure to the *grid-side electrical* slice through M&A. It has zero exposure to silicon/packaging/HBM, which is both a strength (insulated from those cycles) and a weakness (no exposure to where the real scarcity rents are).

## Competitive teardown
- **Vertiv (VRT).** The dominant comparable. FY26 guide $13.5–14.0B revenue, ~$12.5–15B backlog (vs NVT $2.6B), 11.3% liquid cooling share leader [5][10]. Vertiv has full-stack integration (UPS, switchgear, thermal, CDUs, BMS) and deeper relationships with the largest hyperscalers. On CDU technology, Vertiv builds Deschutes-compliant units alongside nVent — *they have parity here* [3]. NVT's edge is RDHX retrofit (passive RDHX Pro at 44–68 kW [19]) and Hoffman/Schroff enclosure incumbency. Vertiv's edge is everything else. For a portfolio that already owns VRT, NVT is overlapping exposure, not a complement.
- **Schneider Electric (SU.PA).** Bought Motivair October 2024 for ~$850M [5], plugging the prior CDU gap. Schneider's EcoStruxure DCIM, APC PDU/UPS install base, and global service footprint dwarf NVT's. The threat: Schneider can win the full-campus integration bid in a way NVT structurally cannot.
- **CoolIT Systems** and **Motivair (now Schneider).** Pure-play DLC cold plate / CDU specialists. CoolIT has the deepest history shipping cold plates on NVIDIA reference designs going back to HGX H100. They lack gray-space products.
- **Boyd Corporation.** Showcasing Google's 2 MW Deschutes CDU at OCP 2025 [3]. Privately held; meaningful threat in CDU specifically.
- **Delta Electronics (2308.TW).** Deschutes-compliant CDU [3]; also large in power shelves and PSUs. Asia-strong, building Western channel.
- **Rittal (privately held, Friedhelm Loh).** Schroff's traditional German enclosure competitor; deeply embedded in European hyperscaler procurement.
- **Stulz, Munters, Trane, Modine (Airedale).** Established thermal/chiller vendors moving up-stack into rack and row.
- **Hyperscaler internalization.** The most underrated competitor. Project Deschutes is not "Google partnering with vendors" — it is *Google specifying the CDU itself and shopping it to contract manufacturers*. As that pattern spreads (Meta's ORv3 HPR work is similar [7]), the value migrates from the branded vendor to the lowest-cost qualified manufacturer. NVT today benefits from being qualified; in 3 years it competes with Envicool, Nidec, and Delta on contract-manufacturing economics.
- **Chinese entrants (Envicool, Inspur cooling, etc.).** Significant cost gap. Currently kept out of US hyperscaler builds by procurement preference and security review, but a real swing factor outside the US.

Verdict: NVT does not lead any axis except RDHX retrofit and enclosure incumbency. It is a credible second/third source in CDU and a credible first source in modular E-houses post-Trachte. The "best AI cooling play" framing some sell-side names use is wrong — Vertiv is. NVT is the *diversified industrial* AI cooling play, and the bull case has to rest on that diversification + valuation, not technology leadership.

## Bull case — technical
The technical preconditions for NVT to outperform from here:

1. **NVL72 / Vera Rubin volumes scale as guided.** Rubin requires 45 °C warm-water DLC; air cooling is genuinely impossible at the Rubin thermal density [12]. Every Rubin rack shipped is a CDU + manifold + RDHX retrofit pull. This is a physics-mandated demand pull, not a preference pull.
2. **Project Deschutes commoditization is *slower* than it appears.** Even with the open spec, qualifying a new CDU manufacturer at a hyperscaler takes ~12–18 months of thermal qualification, leak-rate testing, and field-service integration. NVT's first-mover qualification position is therefore worth 4–6 quarters of pricing protection.
3. **Switchgear/E-house lead-time scarcity persists.** Avail EPG + Trachte ride a 5-year switchgear lead-time bottleneck [18] that does not unwind without years of capacity build. This is the most durable part of the moat.
4. **Multi-product bundling wins at the colocation/neo-cloud tier**, where customers (CoreWeave, Crusoe, multitenants) lack hyperscaler engineering depth and prefer one-throat-to-choke procurement [11].
5. **Base rate on displacement is favorable here.** Industrial-mechanical incumbents in adjacent categories — Rittal, Eaton, Schneider — have held share for decades through multiple compute cycles (mainframe → distributed → cloud → AI). Compare ICE→EV (15+ years, still incomplete) or on-prem→cloud (>10 years). The "hyperscaler internalization" risk is real but slow; it took Google 12 years to publish Deschutes after they began designing custom hardware.

Financial translation: FY26 guide $4.50 EPS, FY27 plausible $5.50–6.00 given backlog visibility into 2027 [11]. At 28× (industrial median is 21× [4], so this still embeds a premium), $5.75 → ~$160. At 35× → ~$200. The bull case is "premium multiple sustains because durable secular pull," not "multiple expands further."

## Bear case — technical
The honest short-seller version:

1. **CDU is commoditizing in real time.** Dell'Oro publicly flagged the CDU space as "saturated" [20]. With 7+ named Deschutes-compliant vendors [3], the asymptote is contract-manufacturing margins, not specialty thermal-engineering margins. The 290 bps Q1 gross margin compression [8] may not be a transient mix issue but a leading indicator. The earnings-call attribution to "copper inflation" is convenient — it could equally reflect early CDU price competition.
2. **The "white space" 80/20 mix is misleading.** White space is exactly where commoditization is fastest, because OCP and hyperscalers have actively standardized those interfaces. The 20% gray space (engineered buildings, switchgear) is where the *real* moat lives, but it is also where the M&A premium was paid (Trachte 12.5× EBITDA-ish, Avail EPG ~12.5× [9]). Bull cases that conflate the high-growth white-space line with the high-moat gray-space line are pricing both at gray-space multiples.
3. **Hyperscaler capex elasticity to AI ROI.** $700B aggregate hyperscaler capex in 2026, ~75% AI-related [16]. The question is not whether the buildout is happening — it is. The question is whether 50%+ revenue growth rates at NVT survive a moderation in capex from "panic-mode" to "ROI-discipline" mode. Microsoft already attributed $25B of FY26 capex to *component inflation, not capacity* [16] — a sign of softening discipline that can reverse fast.
4. **The hyperscaler customer is a monopsonist.** Estimated ~30% of NVT revenue is data centers [10], and within that, a handful of hyperscalers drive the marginal order. If one of them dual-sources a major CDU contract to Boyd or Delta in 2027, NVT's growth rate compresses sharply.
5. **Valuation already prices a 5-year run.** ~38× FY26 EPS for an industrial with 36% gross margins and a partly-acquired growth profile is unusually demanding. Compare Vertiv (~30× FY26) which has a more defensible competitive position. The relative trade is sell NVT / buy VRT for anyone who needs to own the theme.
6. **Onsite generation shift could compress the gray-space pull-through.** If hyperscalers go to gas-turbine onsite (OpenAI/Oracle 2.3 GW Texas precedent [18]), the substation switchgear bottleneck partially bypasses the utility grid — which is good for Avail EPG (still need MV gear) but neutral-to-negative for the broader thesis of "utility-side scarcity drives Trachte forever."
7. **Base rate caveat.** Industrial AI plays in past cycles (telecom 1999 fiber buildout, dot-com server boom) saw 50–70 % drawdowns when capex cycles turned, even when underlying technology adoption continued. Mechanical infrastructure rerates fast.

## Market view check
At ~$170 and ~38× forward EPS, NVT is priced as a high-quality industrial growth story with secular AI exposure — not a peak-of-cycle commodity industrial. The market is implicitly saying: liquid cooling penetration will continue to compound, NVT keeps its qualified-vendor share, gray-space lead times stay elongated through 2027, and gross-margin pressure is transient. That can all be right — but at this multiple, the market is *not* discounting any of the bear-case paths (commoditization, hyperscaler dual-sourcing, capex moderation) meaningfully. The fair-value range under a "moat holds, growth continues" scenario is ~$160–200 (post-earnings PT cluster sits inside this). Under a "CDU commoditizes faster than expected + capex moderates" scenario, the multiple compresses to ~25× on ~$5.50 → ~$140. Skew is roughly symmetric, with the convexity favoring the downside because consensus has already mark-up'd into the bull case.

## 90-day falsifiers
- **Q2 2026 print (early August):** Does data-center backlog grow sequentially from $2.6B [11], or flatten? Sequential flat-to-down backlog is the cleanest bear signal.
- **Q2 2026 gross margin:** Did the 290 bps Q1 compression [8] reverse? Bull case requires gross margin to stabilize ≥36%. Another 100+ bps decline = early CDU commoditization confirmation.
- **Hyperscaler capex updates (Q2 prints in late July):** Microsoft, Meta, Google, Amazon. >10% sequential cut to any one of them's CY26 capex guide is a material thesis hit. Continued raises (Meta already raised to $125–145B [16]) extend the runway.
- **Vertiv Q2 print:** If VRT raises FY26 again from $14B, and Boyd/Schneider/Delta publish CDU win counts, watch whether NVT's share is being held or eroded among the named Deschutes vendors.
- **New competitor Deschutes-compliant CDU certifications:** Any additional Asian entrant (Inspur, Foxconn) qualifying at a US hyperscaler is a direct margin signal.
- **Vera Rubin pull-in or push-out from NVIDIA:** A push-out into late 2027 would slow the 45 °C DLC demand inflection [12].
- **Trachte/Avail EPG segment-level disclosure:** Watch whether nVent breaks out "infrastructure" sub-revenue or backlog — currently only the consolidated $2.6B is public. Better disclosure would help bulls; continued opacity is a bear tell.
- **Insider selling above the post-earnings window:** Management exercised in a ~$170 stock when 12 months ago it was $80 is worth tracking.

## What I could not verify
- The exact % of FY26 revenue from data centers (third-party estimates cluster at ~30%, but nVent does not break this out cleanly in segment disclosure) [10].
- The exact customer concentration — what % is hyperscalers vs neo-clouds vs colos. The "wide range of customers from hyperscalers to neo-clouds and multitenants" language [11] is deliberately non-specific.
- Whether NVT's CDU is shipping in production at a top-3 US hyperscaler or only being qualified. Public statements describe wins, demos, and Deschutes-compliance, not deployment counts.
- The economics of the Siemens / nVent 100-MW NVIDIA reference architecture announced December 2025 [12] — whether this is a marketing partnership or a binding allocation/preferred-supplier arrangement.
- Detailed cold-plate IP position vs. CoolIT, Asetek, Jetcool. nVent's cold-plate claims appear lighter than its CDU and RDHX claims.
- Granular gross-margin attribution between copper inflation, mix, and price/competitive pressure in Q1 — management's explanation is plausible but not falsifiable from the disclosure.
- Real share inside the Deschutes-compliant vendor pool. Being "named" is not the same as having dominant share.
- Whether the May 10, 2026 close was exactly $169.89 or moved within the reported $166.25–$174.18 intraday range. I treated it as ~$170.

## Sources
[1] https://finance.yahoo.com/quote/NVT/ — retrieved 2026-05-10 — NVT price ~$169.89, intraday range $166.25–$174.18, market cap ~$27.5B
[2] https://investors.nvent.com/press-releases/press-release-details/2024/nVent-Completes-Acquisition-of-Trachte/default.aspx — retrieved 2026-05-10 — Trachte acquisition $695M, modular E-houses for data centers and grid
[3] https://www.opencompute.org/products/736/vertiv-coolchip-cdu-project-deschutes-5 — retrieved 2026-05-10 — Project Deschutes 5 specification: 2 MW, 3 °C ATD, 80 psi; vendors include nVent, Vertiv, Delta, Stulz, Boyd, Nidec
[4] https://www.gurufocus.com/term/forward-pe-ratio/NVT — retrieved 2026-05-10 — NVT forward P/E and industry comparison
[5] https://www.grandviewresearch.com/industry-analysis/data-center-liquid-cooling-market-report — retrieved 2026-05-10 — Liquid cooling market sizing, Vertiv 11.3% share, top-5 vendor list, Schneider–Motivair acquisition
[6] https://www.nvidia.com/en-us/data-center/gb200-nvl72/ + https://tonecooling.com/nvidia-gb200-nvl72-cooling-requirements/ — retrieved 2026-05-10 — GB200 NVL72 120 kW/rack, mandatory liquid, CDU sizing 150–200 kW, flow 750–800 LPM
[7] https://ocp-all.groups.io/g/OCP-RackandPower/attachment/910/2/6529%20-%20Metas%20ORv3%20HPR%20Next%20Ecosystem%20Solution.pdf — retrieved 2026-05-10 — Meta ORv3 HPR Next rack and power architecture
[8] https://www.stocktitan.net/sec-filings/NVT/10-q-n-vent-electric-plc-quarterly-earnings-report-9960e77f3f72.html — retrieved 2026-05-10 — NVT Q1 2026 10-Q: revenue $1.242B (+53.5%), gross margin 35.9% (-290 bps), Systems Protection RoS 22.7%, Electrical Connections margin compression
[9] https://investors.nvent.com/press-releases/press-release-details/2025/nVent-Completes-Acquisition-of-the-Electrical-Products-Group-Business-of-Avail-Infrastructure-Solutions — retrieved 2026-05-10 — Avail EPG closed for $979.6M, switchgear and bus systems
[10] https://stockanalysis.com/stocks/nvt/ + https://www.kavout.com/market-lens/why-is-nvent-electric-a-key-player-in-the-ai-data-center-boom — retrieved 2026-05-10 — 52-week range $59.57–$167.37, ~30% data-center exposure estimate
[11] https://www.fool.com/earnings/call-transcripts/2026/05/01/nvent-nvt-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q1 2026 call quotes: "organically...pre–data centers in industrial and medical," CDU roadmap "out to 2030," 80/20 white/gray, $2.6B backlog, $36M Q1 capex, customer mix
[12] https://blogs.nvidia.com/blog/gigawatt-ai-factories-ocp-vera-rubin/ + https://www.nvidia.com/en-us/on-demand/session/gtc26-ex82328/ — retrieved 2026-05-10 — Siemens/nVent 100-MW NVIDIA reference, Vera Rubin 45 °C warm-water DLC, GTC 2026 nVent session
[13] https://www.marketbeat.com/stocks/NYSE/NVT/short-interest/ — retrieved 2026-05-10 — Short interest 2.02% of float, 1.27 days to cover
[14] https://www.tikr.com/blog/nvent-electric-q1-2026-earnings-revenue-surges-53-on-ai-data-center-demand — retrieved 2026-05-10 — FY26 guide raised: 26–28% reported sales growth, adj. EPS $4.45–4.55
[15] https://info.fusionww.com/blog/inside-the-ai-bottleneck-cowos-hbm-and-2-3nm-capacity-constraints-through-2027 — retrieved 2026-05-10 — CoWoS scaling 35k→130k wpm, HBM3E fully allocated through 2026, NVIDIA ~60% of CoWoS output
[16] https://www.cnbc.com/2026/02/06/google-microsoft-meta-amazon-ai-cash.html + https://futurumgroup.com/insights/ai-capex-2026-the-690b-infrastructure-sprint/ — retrieved 2026-05-10 — 2026 hyperscaler capex: AMZN $200B, GOOGL $175–185B, META $115–145B, MSFT ~$120B+; $80B Azure power-constrained backlog; ~75% AI mix; Microsoft $25B inflation attribution; post-earnings PT raises (UBS $200, Roth $185)
[17] https://www.financecharts.com/stocks/NVT/performance — retrieved 2026-05-10 — NVT YTD return ~33.65% as of late April 2026 (pre-Q1 print)
[18] https://newsletter.semianalysis.com/p/how-ai-labs-are-solving-the-power + https://www.primary.vc/articles/the-gas-turbine-bottleneck-reshaping-energy-infrastructure-ex8qe — retrieved 2026-05-10 — Heavy-duty turbines GEV/Siemens/Mitsubishi sold out through 2029–2030, HV switchgear 5-year lead times, onsite gen growing to 27% by 2030, OpenAI/Oracle 2.3 GW Texas plant
[19] https://www.nvent.com/en-us/data-solutions/rear-door-heat-exchangers + https://schroff.nvent.com/en-us/solutions/schroff/applications/data-center-cooling — retrieved 2026-05-10 — RDHX Pro 44 kW @ 24 °C, 68 kW @ 14 °C; Schroff DLC and hybrid cooling to 100 kW/rack
[20] https://www.delloro.com/market-at-the-boiling-point-is-the-cdu-space-becoming-saturated/ — retrieved 2026-05-10 — Dell'Oro analysis on CDU vendor saturation