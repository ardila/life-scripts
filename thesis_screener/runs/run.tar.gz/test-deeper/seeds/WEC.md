All research complete. Writing the dossier now.

# WEC — WEC Energy Group, Inc.

## Where this sits in the AI stack
WEC is a regulated electric and natural gas holding company operating at the **physical power-delivery layer** of the AI stack — the layer beneath silicon, packaging, networking, and software. Its operating subsidiaries (We Energies, Wisconsin Public Service) hold exclusive franchise rights to generate and distribute electricity in eastern Wisconsin, the corridor where Microsoft's "Fairwater" GPU training cluster (~3.3 GW peak by late 2027) and the Vantage/Oracle/OpenAI "Stargate Lighthouse" inference complex (~1.3 GW initial, 3.5 GW long-term) are being energized [4][7][9]. Through a 60% stake in American Transmission Co. (ATC), WEC also owns the 138/345 kV backbone connecting those sites to MISO. WEC sells electrons, transmission rights, and natural gas — not GPUs, optics, or software. The relevant workload exposure is **frontier training (Microsoft) plus large-scale inference (OpenAI/Oracle Stargate)**, both characterized by ~85–95% capacity factor, near-flat load shape, and 15+ year facility lifecycles [16].

## Snapshot
- **Price:** $111.66 (2026-05-08 close, last full trading day before report date) [1]
- **Market cap:** $36.4B [1]
- **52-week range:** $100.61 – $119.62 (ATH $118.78 close 2026-04-09) [1]
- **Forward P/E:** 19.9× on FY26 mgmt guide $5.51–$5.61 (midpoint $5.60) [1][3]
- **EV / NTM revenue:** ~4.3× ($44.9B EV / ~$10.35B NTM rev) — note utilities are valued on P/E, dividend yield, price/rate base, not EV/sales [1]
- **Consensus 12-month price target:** $122.13 (+9.4%); rating consensus "Hold" (1 Strong Buy / 8 Buy / 9 Hold / 1 Sell) [2]
- **YTD 2026 total return:** ~+23% [1]
- **Short interest:** 4.52% of float; days-to-cover 9.0 [2]
- **Dividend yield:** 3.41% ($3.81 annualized; 23rd consecutive annual increase, raised 6.7% Jan 2026) [4]
- **5-yr capex plan:** $37.5B 2026–2030 (+$8.5B vs. prior plan, +$1B since Microsoft Jan-2026 expansion) [3][7]
- **EPS CAGR guide:** 7–8% through 2030, upper half from 2028 [3][5]
- **Authorized ROE (WI electric):** 9.80% (PSCW Dec 2024 order); ATC FERC formula 10.48% [13][20]

## Moat — what it is physically made of
WEC's moat is not technological — it is **structural and regulatory**, with a hard physical-asset substrate. Decompose:

**(1) State-granted monopoly franchise.** Wisconsin Public Service Commission grants We Energies and WPS exclusive right to serve electric load in defined service territory. A hyperscaler that wants grid-connected power in Racine or Ozaukee County has exactly one regulated counterparty. Durability: very high — franchise structure dates to early-1900s utility law and has survived every prior deregulation push. Erosion path is narrow (state-by-state retail choice legislation) and absent in Wisconsin.

**(2) Very Large Customer (VLC) tariff (final order April 24, 2026).** The PSC restructured WEC's proposal in ways that *strengthen* shareholder protection: large-load customers must fund **100% of resources built to serve them**; eligibility threshold dropped from 500 MW to 100 MW; **15-year minimum initial term** acts as take-or-pay; explicit transmission-cost-shift protection [12]. This tariff is more protective than equivalent structures in Virginia (where the SCC just imposed a separate data-center rate class on Dominion and trimmed its rate request ~30% [14]) and Ohio (where AEP Ohio is in continuous ESP litigation). Durability: high while PSCW composition holds.

**(3) Generation already PSC-approved and partially under construction.** Oak Creek 1,200 MW combined-cycle (site work began Aug 2025, in-service Fall 2027–Summer 2028); Paris RICE 130 MW (in-service Aug 2026); ~$730M in newly approved solar+storage; Oak Creek coal extension through 2026 [10][11]. Critically, these projects already have **GE Vernova/MHI turbine slot reservations** locked in — a genuine moat in 2026 because new orders today face 2030+ delivery [21][22].

**(4) ATC transmission backbone (60% owned).** ATC has $2.6–$3.0B of data-center-driven transmission projects approved or in PSC review: $625M Microsoft-driving line (approved May 2025), ~$1.4–1.6B for the Vantage/Port Washington complex, $191M Beaver Dam line for Meta (which sits in Alliant's territory but the transmission revenue still accrues to ATC) [13]. FERC formula rate = real-time cost recovery, ~10.48% ROE.

**(5) Capex execution capability.** $37.5B over 5 years requires sustained execution: 6,300+ MW new generation, transmission, distribution upgrades. WEC has built ~3 GW of generation in the prior decade without major regulatory disallowance — a genuine track record advantage relative to merchant developers and even some IOU peers.

What is **not** a moat: there is no technological IP, no software stack, no manufacturing know-how. WEC is a regulated capital allocator with a turbine slot reservation list and a friendly PSC. That should temper any "tech-style" valuation premium.

## AI buildout bottleneck map
- **Gas turbines (HA/F-class):** GE Vernova backlog 100 GW Q1 2026, expects to be sold out through 2030 by year-end; Siemens Energy ~5-yr lead time; MHI 2028–2030 [21][22]. **WEC = beneficiary** — already has Oak Creek slots booked. New orders today face the same wall every IPP and competing utility faces.
- **MISO interconnection queue:** ~242 GW pending; new clusters projected at 1–2 years vs. prior 6 [23]. **WEC = constraint owner via ATC** — owns transmission, can prioritize own generation interconnects within MISO process.
- **Behind-the-meter (BTM) gas:** Crusoe-GEV deal for 29× LM2500XPRESS aeroderivatives (~1 GW); ExxonMobil/NextEra marketing 1 GW BTM hyperscaler site Q1 2026; forecast >25% of new >500 MW DCs BTM by 2030 vs. ~1% today [25][26]. **WEC = exposed customer** — this is the most credible technical bypass risk.
- **Nuclear restarts/SMRs:** Three Mile Island (Constellation/Microsoft, ~2027–2028 restart), Palisades (Holtec, slipped — no firm date as of April 2026), Duane Arnold (NextEra/Google, ~2029); SMRs at scale 2031–2035 [27][28][29]. **WEC = indifferent near-term** (Wisconsin nuclear is Point Beach owned by NextEra), **exposed long-term** if hyperscalers redirect to nuclear-anchored sites in PJM/CAISO.
- **HBM/CoWoS, optical, kernels:** **WEC = indifferent.** These constrain customer GPU deployment timing, which could delay (but not cancel) load energization at Mt. Pleasant.
- **Power generation EPC labor/electrical contractors:** Industry-wide constraint; WEC has long-standing relationships with regional EPCs (e.g., M.A. Mortenson). Not a competitive disadvantage.
- **Equity dilution / cost of capital:** $900M–$1.1B equity issuance in 2026 alone [3]. WEC's WACC is among the lowest in the IPP/utility universe given regulated cash flows, but at the margin every $1B of new equity is a 2.7% dilution. **WEC = self-imposed constraint.**

## Competitive teardown
**Three distinct competitive vectors:**

**(A) Other regulated IOUs competing for the same hyperscaler dollars (cross-territory).** Hyperscalers choose location partly on power availability. WEC's competitive set on the next siting decision is not other Wisconsin utilities — it's Dominion (Virginia), AEP Ohio, Duke Carolinas, Southern (Georgia), Entergy (Louisiana/Mississippi). On absolute MW: AEP claims 63 GW total contracted with ~22 GW data-center-specific by 2030; Duke 7.6 GW pipeline; Southern 10 GW contracted/75 GW pipeline; Dominion ~50 GW NoVA-driven capex plan [15][17][18]. WEC's 3.9 GW firm + 4–5 GW pipeline is meaningful but **smaller in absolute terms**. WEC's edge is **relative density**: 3.9 GW on a ~7 GW peak system implies ~45% sales growth, the highest in the regulated peer set, plus a more constructive PSC than VA/OH.

**(B) IPPs winning hyperscaler PPAs that bypass utility load entirely.** Talen-AWS Susquehanna (1.92 GW nuclear), Vistra ~3.8 GW (AWS+Meta), Constellation TMI/Microsoft (835 MW). These deals **subtract from utility load growth nationally** but do not directly affect WEC because Wisconsin lacks a co-locatable nuclear or large merchant gas asset. The risk is indirect: if hyperscalers establish that BTM/co-located is operationally and politically easier, future Wisconsin RFPs may bypass We Energies. PJM's recent FERC clearance of nuclear co-location is the precedent to watch.

**(C) Behind-the-meter generation (the real technical substitution risk).** GE Vernova's LM2500XPRESS aeroderivative is a fast-deploy (~12-month delivery) packaged solution; Crusoe and Exxon/NextEra are productizing this. If the Oak Creek 1,200 MW CCGT slips or proves more expensive than utility-side modeling assumed, the next 1+ GW of Wisconsin hyperscaler load could go BTM. Mitigant: **BTM cannot replicate the 100 MW–scale interconnect into MISO at large diversity** — frequency support, voltage stability, and N-1 reliability for a multi-GW campus still require utility wires [25].

## Bull case — technical
The bull case requires four conditions to hold:
1. **Microsoft Fairwater Phase 2 + Vantage Stargate construction stays on schedule.** Phase 1 energizes mid-2026; Vantage 1st building late 2027 [9]. CEO Lauber confirmed biweekly site reviews and "no slippage" on Q1 2026 call [8]. Microsoft Jan 2026 announced *additional* 15 buildings / $13.3B [7], dramatically de-risking Phase 2 doubt that hit the stock in early 2025.
2. **At least one more large-load contract signed in 2026.** Lauber telegraphed an additional announcement on Q3 2026 call [8]. Cloverleaf's adjacent ~1 GW Port Washington campus is the obvious candidate. Each incremental GW = ~$5–7B of incremental rate-base capex earning ~9.8% authorized ROE.
3. **VLC tariff holds.** The April 2026 PSC order is structurally protective; only adverse legal challenge or major PSC composition change would erode it [12].
4. **Gas turbine slot scarcity persists.** Continued GE Vernova sold-out signaling makes WEC's already-booked Oak Creek slots a real option-value moat [21].

**Base rate caution:** historical U.S. peak-load growth forecasts have repeatedly overshot (1990s telecom, mid-2000s "demand surge"). However, the *contracted* portion of WEC's pipeline (3.9 GW with executed VLC contracts) is materially more solid than aggregate hyperscaler interconnection requests, which utilities themselves discount ~30–40% [24]. **Financial outcome:** EPS lands toward the top of 7–8% band ($8.00 by 2030 vs. $5.60 base); modest multiple expansion to 22–23× yields a low-double-digit annual TSR including the 3.4% dividend.

## Bear case — technical
Symmetric, written by a short-seller who reads MISO queue minutes:
1. **Microsoft pauses Phase 2 again.** Microsoft already paused Phase 2 (Areas 2/3A) in Jan 2025 for "design reevaluation" before resuming Aug 2025 [7]. A repeat pause — or shift of training workloads to inference (lower-density, more flexible siting) — would invalidate the 2.6 GW figure. The Jan 2026 expansion announcement reduces but does not eliminate this risk.
2. **BTM substitution accelerates faster than the 25%-by-2030 base case.** If Crusoe-style modular gas + Exxon-style on-site CCGT economics improve, Vantage-equivalent future RFPs go BTM and WEC's projected 4–5 GW pipeline does not contract. The bear evidence to watch: any *new* Wisconsin DC announcement in 2026–2027 that does *not* sign a VLC tariff with We Energies.
3. **Phantom demand realization.** EPRI data shows utilities discount their own queues by 30–40%; if Wisconsin hyperscaler contracts are similarly inflated, the 3.9 GW number is realistically 2.5–3.0 GW [24]. WEC's 100% cost-coverage VLC tariff partially mitigates (stranded asset is the customer's cost, not ratepayers') but EPS growth still misses.
4. **PSC composition shifts adverse.** 2024 Wisconsin elections produced a more progressive PSC; the April 2026 order leaned consumer-protective. A 2027 rate case denial of full cost recovery on Oak Creek or transmission could compress ROE earned vs. authorized.
5. **Equity dilution drag.** $900M–$1.1B in 2026 plus likely repeat in 2027–2028 = ~7–10% cumulative share count growth. Even if rate base grows 8–9%, per-share EPS growth is 5–7% — at the low end of guidance.
6. **Nuclear/SMR competition.** If TMI restart proves operationally smooth (2027) and 2–3 more PJM nuclear restarts follow, hyperscaler capex shifts toward nuclear-anchored sites and away from gas-anchored MISO sites by 2028–2030.

**Base rate:** regulated utility moats erode slowly (decades, not years) — see slow death of vertically integrated utilities in deregulated states post-1996. But **load-growth bull theses** historically realize at 50–70% of forecast (telecom 2000s, EV-driven utility demand 2010s).

## Market view check
At $111.66, WEC trades at 19.9× FY26 EPS — a clear premium to the regulated utility median ~15× and approximately in line with AEP (21×) and Southern (~21×), below NextEra (~23×). The premium reflects: (i) the cleanest, named-counterparty data-center growth story among mid-cap regulated utilities; (ii) constructive PSC; (iii) 7–8% EPS CAGR vs. 5–7% for D/DUK/SO; (iv) defensive 3.4% yield with 23-year increase streak. Market is pricing a **base-case outcome**: 7–8% EPS CAGR delivered cleanly, no Microsoft pullback, VLC tariff intact. Market does **not** appear to price (a) BTM substitution accelerating, (b) Phase 2 re-pause, or (c) phantom-demand correction. The +9% consensus PT implies the sell side sees limited near-term upside at current levels. **The technical bottleneck reality (turbine slots booked, transmission approved) is a real edge — but at 20× forward, much of it is in the price.** Asymmetric upside requires the second-data-center catalyst Lauber telegraphed for Q3 2026.

## 90-day falsifiers (through ~Aug 2026)
- **Q2 2026 earnings (early Aug):** Does WEC reaffirm the $5.51–$5.61 FY26 range? Any change in rate-base CAGR or capex plan? Any commentary on Microsoft Phase 2 timing or Vantage construction milestones?
- **Microsoft Mt. Pleasant Phase 1 energization:** Confirmed operational in mid-2026 per company statements — observable through PSC interconnection filings and Microsoft regional disclosures.
- **Cloverleaf/Vantage transmission line PSC decision (expected Fall 2026):** Approval would unlock the next leg of capex.
- **Vantage 1st-building construction milestones:** Visible via Port Washington permit filings and on-site progress (drone footage circulates on local news).
- **Any new VLC tariff signing announcement:** Lauber telegraphed Q3 2026 [8]. A new named hyperscaler customer would be the single largest catalyst.
- **GE Vernova / MHI Q2 backlog disclosure:** If turbine sold-out window extends *past* 2030, WEC's already-booked Oak Creek slots become more valuable.
- **MISO LRZ 2 (Wisconsin) auction results:** capacity prices indicate scarcity rent realization.
- **Wisconsin PSC rate case docket activity:** WEC filed for 2027/28 rates April 2026; intervenor testimony in Q3 will signal regulatory posture.
- **Any hyperscaler announcement of a BTM gas project on a Wisconsin-adjacent site:** Crusoe, Exxon, or a new entrant choosing BTM near a WEC-served market would be a credible bear data point.
- **Microsoft capex commentary at quarterly earnings (Jul 2026):** Any cut >10% sequential in total AI infrastructure spend, or specific deferral language about Wisconsin, would invalidate the load-growth thesis.

## What I could not verify
- **Exact contracted MW vs. signed-but-flexible vs. pipeline split** — WEC's segmentation in earnings materials uses 5-year-plan inclusion as the firm marker, but the underlying VLC contracts are not public. The 3.9 GW "firm" number relies on company assertion.
- **GE Vernova/MHI specific slot allocations to WEC** — the existence of Oak Creek slot reservations is implied by the project being under construction with PSC approval, but I could not source exact OEM-WEC commercial terms.
- **Microsoft's actual GPU deployment timing at Fairwater** — Microsoft has not publicly disclosed which GB200/GB300/MI400-class hardware is deployed in which building or when. This affects load energization shape (training workloads ramp fully when GPUs are racked, not when buildings are powered).
- **VLC tariff resilience to legal challenge** — the April 24, 2026 PSC order could face appeals from intervenors (WI Industrial Energy Group, Citizens Utility Board); I did not find clarity on appeal status.
- **Realistic BTM substitution penetration rate in MISO-North specifically** — national forecasts (>25% of new >500 MW DCs by 2030) may not apply uniformly; Wisconsin's lack of stranded gas reserves and cold-climate cooling efficiency may discourage BTM relative to Texas/Wyoming.
- **WEC's true marginal cost of capital at $1B+ annual equity issuance cadence** — depends on rate environment and any future at-the-market offering structure.

## Sources
[1] https://stockanalysis.com/stocks/wec/ — retrieved 2026-05-10 — closing price $111.66 (May 8 2026), market cap, 52-week range, forward P/E
[2] https://www.marketbeat.com/stocks/NYSE/WEC/ — retrieved 2026-05-10 — consensus price target $122.13, short interest, analyst ratings breakdown
[3] https://www.fool.com/earnings/call-transcripts/2026/05/05/wec-wec-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q1 2026 transcript: EPS $2.45, FY26 guide $5.51–$5.61, 7–8% LT EPS CAGR
[4] https://investor.wecenergygroup.com/investors/news-releases/press-release-details/2026/WEC-Energy-Group-raises-quarterly-dividend-by-6-7-percent/default.aspx — retrieved 2026-05-10 — 23rd consecutive dividend increase, 6.7% raise, $0.9525 quarterly
[5] https://seekingalpha.com/news/4548271-wec-energy-outlines-37_5b-capital-plan-and-7minus-8-percent-annual-eps-growth-through-2030-as — retrieved 2026-05-10 — $37.5B 2026–2030 capex, 7–8% EPS growth
[6] https://www.spglobal.com/market-intelligence/en/news-insights/articles/2025/10/wec-increases-capital-spending-plan-by-8-5b-to-support-data-center-growth-94475101 — retrieved 2026-05-10 — capex plan increased $8.5B for data centers
[7] https://racinecountyeye.com/2026/01/20/microsoft-13b-expand-mount-pleasant/ + https://blogs.microsoft.com/on-the-issues/2025/09/18/made-in-wisconsin-the-worlds-most-powerful-ai-datacenter/ — retrieved 2026-05-10 — Microsoft Fairwater details, $13.3B Jan 2026 expansion, 15 new buildings
[8] https://urbanmilwaukee.com/2026/05/07/we-energies-ceo-says-another-data-center-announcement-is-coming/ — retrieved 2026-05-10 — Lauber telegraphs additional DC announcement on Q3 2026 call; biweekly construction reviews
[9] https://www.datacenterdynamics.com/en/news/openai-oracle-and-vantage-plan-stargate-wisconsin-data-center-expected-to-be-close-to-a-gigawatt/ + https://vantage-dc.com/data-center-locations/north-america/port-washington-wisconsin — retrieved 2026-05-10 — Vantage Port Washington 902 MW initial / 3.5 GW long-term Stargate site
[10] https://www.powermag.com/regulators-approve-plans-for-two-new-gas-fired-plants-in-wisconsin/ — retrieved 2026-05-10 — Oak Creek 1,200 MW CCGT and Paris 130 MW RICE plant PSC approval
[11] https://biztimes.com/we-energies-plans-2-billion-in-natural-gas-power-projects-in-oak-creek-paris/ — retrieved 2026-05-10 — $2B gas project capex split, in-service dates
[12] https://psc.wi.gov/Documents/PressReleases/04.24.2026PressRelease.PDF + https://www.datacenterknowledge.com/business/psc-tightens-data-center-tariff-rules-in-wisconsin — retrieved 2026-05-10 — VLC tariff April 24 2026: 100% cost recovery, 100 MW threshold, 15-year minimum
[13] https://www.wisbusiness.com/2026/data-center-critics-alarmed-by-atcs-plans-to-add-2b-in-transmission-infrastructure/ + https://www.oasis.oati.com/woa/docs/ATC/ATCdocs/budget.html — retrieved 2026-05-10 — ATC $2.6–3.0B project pipeline, 10.48% FERC ROE
[14] https://insideclimatenews.org/news/07012026/virginia-regulators-approve-new-dominion-rates/ — retrieved 2026-05-10 — Virginia SCC trims Dominion request, imposes data-center rate class
[15] https://www.prnewswire.com/news-releases/aep-reports-first-quarter-2026-earnings-reaffirms-guidance-and-increases-five-year-capital-plan-302762002.html — retrieved 2026-05-10 — AEP $78B capex, 63 GW total contracted load
[16] https://www.ramboll.com/en-us/insights/decarbonise-for-net-zero/100-kw-per-rack-data-centers-evolution-power-density + https://www.deloitte.com/us/en/insights/industry/technology/technology-media-and-telecom-predictions/2025/genai-power-consumption-creates-need-for-more-sustainable-data-centers.html — retrieved 2026-05-10 — AI training rack load shape, ~85–95% capacity factor, liquid cooling implications
[17] https://www.utilitydive.com/news/southern-company-record-electricity-sales-data-center-earnings/819081/ — retrieved 2026-05-10 — Southern 10 GW contracted, 75 GW pipeline
[18] https://www.msn.com/en-us/money/companies/duke-energy-reaffirms-6-55-6-80-2026-eps-range-targets-top-half-5-7-growth-from-2028-as-esas-reach-7-6-gw/ar-AA22scC3 — retrieved 2026-05-10 — Duke 7.6 GW pipeline, 5–7% EPS guide
[19] https://www.investing.com/news/company-news/dominion-energy-q4-2025-slides-65b-capital-plan-targets-data-center-boom-93CH-4519537 — retrieved 2026-05-10 — Dominion $50B NoVA capex plan, 11.9% Virginia rate base growth
[20] https://cubwi.org/psc-approves-even-higher-costs-for-struggling-we-energies-wps-customers/ — retrieved 2026-05-10 — PSC Wisconsin 9.80% authorized ROE, Dec 2024
[21] https://www.utilitydive.com/news/ge-vernova-gas-turbine-backlog-hits-100-gw-as-prices-rise/818332/ — retrieved 2026-05-10 — GE Vernova 100 GW backlog, sold out through 2030 by YE 2026
[22] https://www.bloomberg.com/features/2025-bottlenecks-gas-turbines/ — retrieved 2026-05-10 — Siemens 5-yr lead time, MHI 2028–2030 deliveries
[23] https://cdn.misoenergy.org/06_2025-09-16_SPC_Open_Long%20Term%20Resource%20Adequacy%20%20Interconnection%20Queue%20Update_FINAL717559.pdf — retrieved 2026-05-10 — MISO ~242 GW pending interconnection studies
[24] https://powering-intelligence.epri.com/load-growth.html + https://www.utilitydive.com/news/a-fraction-of-proposed-data-centers-will-get-built-utilities-are-wising-up/748214/ — retrieved 2026-05-10 — utility self-discount of queue ~30–40%, phantom demand framework
[25] https://www.power-eng.com/gas/turbines/data-centers-drive-record-surge-in-ge-vernova-power-equipment-orders-as-turbine-slots-tighten-through-2030/ + https://logisticsviewpoints.com/2025/12/17/from-microgrids-to-hypergrids-the-unprecedented-power-demands-of-data-centers-combined-with-the-deep-pockets-of-the-hyperscalers-building-them-are-creating-a-new-grid-architecture-that-scales-the-m/ — retrieved 2026-05-10 — Crusoe-GEV LM2500XPRESS deal, BTM penetration forecast >25% by 2030
[26] https://www.cnbc.com/2025/12/08/nextera-exxon-develop-gigawatt-data-center-for-hyperscaler.html — retrieved 2026-05-10 — Exxon/NextEra 1 GW BTM hyperscaler site Q1 2026
[27] https://www.utilitydive.com/news/constellation-three-mile-island-nuclear-power-plant-microsoft-data-center-ppa/727652/ + https://www.datacenterdynamics.com/en/news/three-mile-island-nuclear-plant-restart-ahead-of-schedule-in-boon-to-microsofts-ai-ambitions-report/ — retrieved 2026-05-10 — TMI/Crane 835 MW restart timeline, Microsoft 20-yr PPA
[28] https://www.michiganpublic.org/environment-climate-change/2025-12-17/palisades-nuclear-plant-restart-plans-pushed-back-to-early-2026 + https://www.ans.org/news/2026-04-02/article-7901/holtec-hits-milestones-in-palisades-restart-new-reactor-projects/ — retrieved 2026-05-10 — Palisades restart slipping past early 2026
[29] https://nuclearinnovationalliance.org/sites/default/files/2025-06/NIA%20AR%20Timeline%20-%20June%202025%20v2.pdf — retrieved 2026-05-10 — SMR commercial deployment consensus 2031–2035