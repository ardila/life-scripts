# LII — Lennox International Inc.

## Where this sits in the AI stack

Almost nowhere. LII is a North American HVAC OEM — ~67% residential (Home Comfort Solutions / HCS), ~33% commercial (Building Climate Solutions / BCS), with ~75% of sales tied to the **replacement** cycle for furnaces, AC condensers, heat pumps, and light-commercial rooftop units (RTUs) for retail/restaurants/schools.[1][3] Its only data-center surface area is **LFB Group** (formerly Lennox EMEA), which spun out as a standalone European business in April 2025 and sells CRAH, fan-wall units (FWUs, 100–1,000 kW), close-control units, dry coolers and a CDU line under the "ApX" brand — all in EMEA, all air-side or hybrid, with no NVIDIA reference-architecture wins or hyperscale anchor disclosed.[5][7][8] Critically, **LII has no announced direct-to-chip liquid-cooling product for the North American hyperscale market**, no presence in the GB200 NVL72 reference build, and the DC cooling business is currently immaterial to the consolidated P&L (the parent does not even break it out as a segment).[6][10] The honest framing: this is a U.S. housing/light-commercial replacement compounder with a small optionality stub in European data-center air cooling — not an AI-infrastructure name.

## Snapshot

- **Price:** $521.25 (2026-05-09 close)[2]
- **Market cap:** ~$18.1B (≈34.8M shares out)[2][11]
- **52-week range:** $434.06 – $689.44[2]
- **Forward P/E:** 25.7× on FY26 consensus EPS ~$24.29 (vs. company guide $23.50–$25.00)[4]
- **EV / NTM revenue:** ~3.3× (NTM revenue ~$5.6B on the raised "~8%" 2026 growth guide off a $5.2B 2025 base; modest net debt, EV ~$19B — inference from disclosed metrics)[9][11]
- **Consensus 12-month price target:** ~$545 median / $575 mean, implied +4.5% to +10.3% from spot[4]
- **YTD total return:** approximately flat / -2% (was -1.8% in late March 2026)[14]
- **Short interest:** 5.9% of float, 7.74 days to cover[11]

## Moat — what it is physically made of

The moat is HVAC-distribution, not AI-infrastructure. Decomposed:

1. **Dealer/distribution network.** Lennox runs a hybrid model: a captive **Lennox Stores** company-owned distribution arm (~250+ locations in North America) plus the independent **Lennox Premier Dealer** channel. In residential, LII is one of very few OEMs that controls its own two-step distribution end-to-end. This shortens the lead time from factory to job-site versus competitors using independent two-step distributors, and meaningfully lowers SKU stranding during refrigerant transitions. Durability: **high** within North America, near-zero outside it. Not replicable in <5–7 years even with capital — it's installed-base inertia.
2. **Manufacturing footprint.** Saltillo (Mexico) is the principal residential facility; Stuttgart (Arkansas) handles commercial RTUs; Marshalltown (Iowa) handles furnaces; Tifton (Georgia) supports residential AC. The Mexican footprint is a structural cost advantage on furnaces/coils but the **tariff exposure is the headline risk** — every 10% tariff on Mexican HVAC components creates ~150–250 bps of gross-margin pressure unless re-priced (LII passed a ~10% list price hike effective Feb 16, 2026, partly to cover this).[13] Durability: medium; cost advantage is replicable by competitors with capital, but rebuild time is 24–36 months.
3. **R-454B (A2L) refrigerant redesign.** The 2025–2026 phase-out of R-410A forced every OEM to re-engineer cabinets, coils, controls, and integrate refrigerant detection sensors (RDS). LII shipped 100% R-454B residential by mid-2025.[13] This is a **transient** moat: it lifts ASPs 5–10% but every major (Carrier, Trane, Daikin, Goodman/Rheem) is making the same transition, so the pricing umbrella narrows over 2026–2027. Durability: low (~12–24 months as inventory normalizes).
4. **Commercial heat-pump RTU certification.** Lennox was the **first OEM** to complete DOE's Commercial Building HVAC Technology Challenge lab validation for cold-climate heat-pump RTUs (15–25 ton class).[12] This is a real technical lead — sub-zero-Fahrenheit operation on a packaged unit is non-trivial — but the moat is shallow (~24 months until Carrier/Trane catch up).
5. **DC cooling IP via LFB Group.** Sixty years of mechanical/precision-cooling experience and a 100+ engineer team in EMEA.[7][8] However, the ApX FWU and CRAH portfolio competes against Vertiv Liebert, Stulz, Munters, Schneider Uniflair, and Airedale (Modine) in air/hybrid topologies — none of which solve the >100 kW/rack direct-to-chip problem that GB200/MI355 actually require.[15][16]

**What LII does *not* have:** any patented liquid-coolant chemistry; any tier-1 hyperscale anchor disclosed; CDU validation against NVIDIA reference designs (Vertiv has this); software (DCIM/BMS) of consequence; long-term hyperscale capacity contracts of the type Vertiv has disclosed; >$1B in deferred DC backlog.

## AI buildout bottleneck map

Bottlenecks for the 2026–2027 AI buildout, mapped to LII's position:

- **Power generation / grid interconnect.** Largest physical bottleneck — gas-turbine backlogs (GE Vernova, Siemens Energy, Mitsubishi) stretch into 2028; PJM/ERCOT interconnect queues remain multi-year. **LII: indifferent.** Does not sell prime-power equipment.
- **CoWoS-L advanced packaging at TSMC.** Constrains Blackwell/Rubin GPU output. **LII: indifferent.**
- **HBM3e / HBM4 yield (SK hynix, Micron, Samsung).** Constrains GPU output. **LII: indifferent.**
- **Optical interconnect (CPO, 800G/1.6T transceivers).** Constrains scale-out networking. **LII: indifferent.**
- **Liquid cooling at >100 kW/rack.** Direct beneficiary list: Vertiv, Modine (Airedale), Boyd, CoolIT, JetCool, Asetek, nVent (CoolLoop), Schneider/Motivair. **LII: not on this list in North America.** LFB has an ApX CDU but no disclosed reference design or major win.[6][7]
- **Electrical contracting capacity (switchgear, UPS, busway).** Direct beneficiary: Vertiv, Eaton, nVent, Schneider, Atkore, Hubbell. **LII: indifferent** (does not sell electrical infrastructure).
- **Air-side rejection (>100 kW/rack residual sensible load, plus 100% air for inference racks).** The one place LII could plausibly compete: facility-level air handlers, dry coolers, evaporative cooling for hot-aisle containment. LFB ApX participates here in EMEA. **In North America, this is Munters / Vertiv / Modine / STULZ territory.** LII has effectively no install base.
- **Light-commercial RTU demand spillover from DC peripheral facilities** (office/admin buildings adjacent to campuses, edge sites). **LII: marginal beneficiary** — but this is rounding error against the residential cycle.

The map is the punchline: LII is **indifferent or absent** on every meaningful AI-buildout bottleneck. The market's -16% LTM derate (vs. Nasdaq +23%) is the price discovery confirming this.[14]

## Competitive teardown

Two distinct competitive fights, neither of which has a meaningful AI angle:

**Fight 1 — North American residential HVAC (the real business).** Competitors: Carrier (CARR, Bryant/Payne/ICP brands), Trane Technologies (TT, American Standard), Daikin (Goodman/Amana), Rheem, Bosch. Axes: refrigerant transition execution (LII = ahead, shipped R-454B clean), heat-pump portfolio (LII = competitive, not leading vs. Daikin), inverter compressor cost (Daikin's structural advantage from vertical integration), dealer loyalty (LII = strong in independent channel), price/mix (LII = premium-mid, vs. Daikin/Goodman undercutting on value). Outcome: LII holds share in replacement but loses incremental new-construction share to Daikin/Goodman due to inverter cost curve.

**Fight 2 — Data center cooling (where LII is *not* a meaningful participant).** Real fight is among:
- **Vertiv (VRT):** Co-developed the GB200 NVL72 reference cooling architecture with NVIDIA; multi-year hyperscale framework agreements; the de facto incumbent on direct-to-chip CDU + manifold + rear-door HX integration. Trades on AI capex; ~9–10× EV/sales.[15][16]
- **Modine (MOD):** Airedale brand; precision-air and chiller plant; guides 50–70% YoY DC growth.[15]
- **nVent (NVT):** Acquired Trachte and ECM; CoolLoop liquid-cooling distribution; rack-level integration.
- **Schneider Electric:** Uniflair (precision), Motivair (liquid via acquisition); dead-heat with Vertiv in DCPI globally.[15]
- **Carrier, Trane, JCI:** Chiller-plant scale (1+ MW air-cooled and water-cooled chillers) — these companies *do* benefit from data center build-out at the campus-chilled-water-plant layer. **TT spent $150M opening 12 hubs in Jan 2026 specifically targeting DC corridors.**[16] **JCI signed a 10-yr/$200M hyperscale uptime deal in Nov 2025.**[16] **CARR earmarked $450M to expand its Monterrey chiller plant in Jan 2026.**[16] LII has announced no comparable commitment.
- **Daikin:** Unveiled DC cooling line at AHR 2026.[16] Has VRV and chiller scale globally.
- **Munters, STULZ:** Precision specialists.

For LII to take meaningful share in Fight 2, it would need (i) a North American DC cooling business unit announcement, (ii) a tier-1 hyperscale anchor, (iii) a validated CDU or rear-door HX product against NVIDIA reference designs. **None of these are visible in 2026 disclosures.** The LFB Group is a stand-alone EMEA story and management has not signaled North American expansion on calls.[6][10]

## Bull case — technical

For LII to outperform from $521, the following must hold:

1. **Residential replacement cycle re-accelerates in H2 2026.** Average North American HVAC age >12 years; deferred replacement from the high-mortgage-rate window (2022–2025) creates pent-up demand. The thesis requires existing-home turnover and homeowner equity withdrawals to normalize. *Watch:* MBA refinance index, NAR existing-home sales.
2. **A2L pricing umbrella holds through 2027.** The 5–10% ASP lift from R-454B equipment plus the Feb 2026 10% list-price action must not fully reverse as channel inventory normalizes.[13] Trane/Carrier discipline matters more than Lennox's own.
3. **Commercial RTU strength sustains.** BCS organic +26% in Q1 2026 with 300 bps margin expansion is the strongest data point in the bull narrative.[9] Drivers: emergency replacement on aging stock, national accounts (QSR/retail re-fleeting), DOE-validated cold-climate heat-pump RTU adoption.[12] If BCS can grow 15%+ for two more years, it changes the consolidated growth algorithm.
4. **LFB Group becomes a real DC line and re-rates the multiple.** The optionality is non-zero given the 60-year mechanical heritage and the European hyperscale build-out (Microsoft, AWS, OVH, Stack expansion). If LII discloses a tier-1 anchor or quantified DC backlog on a 2026 print, it forces a re-rate.
5. **Mexico tariff exposure is contained.** No incremental Section 232 / Section 301 action on HVAC components.

**Base rate on technology displacement at this stage of the cycle:** Established HVAC OEMs have lost share to new entrants on a 10–20 year arc, not a 1–3 year arc. CARR/TT/LII have collectively held >40% of the U.S. unitary market for two decades despite multiple Asian entrants. The displacement risk is real but slow. Bull case targets ~$650 (28× ~$23 forward EPS plus modest DC optionality) = ~25% upside on a 12-month horizon.

## Bear case — technical

The honest short-seller's argument:

1. **The setup is "good company, wrong sector at the wrong time."** Investor dollars in 2026 are crowding into AI-infrastructure beneficiaries (VRT +>100% LTM cohort); generalist names without an AI hook get derated. LII has already lost 16% LTM vs. Nasdaq +23%[14] and there is no catalyst to break the de-rating without an AI hook.
2. **A2L pricing umbrella collapses faster than expected.** Distributor pre-buy of R-410A inventory in late 2024/early 2025 is now working through the channel; once it clears, channel inventory normalizes and ASP gains compress. Q1 2026 already saw $50M of factory under-absorption as Lennox cut production 30%.[9] If that re-occurs in Q3/Q4, EPS is at risk.
3. **Heat-pump cycle disappoints.** The Inflation Reduction Act 25C credits have driven heat-pump mix higher, but if IRA credits are weakened by Congress in 2026/27 the unit mix flattens and Lennox's premium positioning hurts vs. Daikin/Goodman value brands.
4. **Mexico tariff event.** 25% tariff on Mexican HVAC components would compress GMs ~300+ bps before pricing offsets. Lennox is structurally more exposed than Trane or JCI.
5. **LFB Group remains immaterial.** EMEA DC build-out is real but the share allocated to LFB is competing against incumbent Vertiv/Schneider/Stulz/Munters and the Chinese precision-cooling vendors entering Europe; LII is structurally late.
6. **Commercial backlog burns off.** BCS strength is partly catch-up after pandemic-era underinvestment in commercial fleets; once installed base normalizes, growth reverts to 4–6% from current 26%.

Bear case targets ~$420 (18× ~$23 EPS on a multiple compression scenario) = ~-20% on a 12-month horizon.

## Market view check

At $521 / 25.7× forward EPS / ~3.3× EV/NTM sales, LII trades **roughly in line with its 5-year median multiple and slightly below Carrier and Trane (which trade ~28–30× on richer AI-adjacent narratives at TT/JCI via chiller-plant commentary).** The consensus PT of ~$545[4] implies the Street sees the stock as fairly valued — modest upside on EPS execution but no multiple re-rate. **This is consistent with the technical reality:** LII is a North American HVAC replacement-cycle compounder, not an AI infrastructure beneficiary, and the market is pricing it as such. **The mispricing risk is asymmetric in both directions:** if LII signals a real North American DC cooling push (e.g., an LFB Group spin-out or a tier-1 hyperscale anchor), the multiple re-rates to 30×+; if A2L pricing rolls and Mexico tariffs hit, the multiple compresses to 20×. Spot is the un-bet midpoint.

## 90-day falsifiers

Specific, observable events through August 2026:

- **Lennox Q2 2026 print (late July 2026):** Watch (a) BCS organic growth — does the 26% in Q1 hold or decelerate; (b) factory-absorption commentary — does the $50M Q1 headwind recur; (c) **any** quantitative comment on LFB Group / DC cooling backlog. Silence on DC = bear-case confirming.
- **AHR Expo or Datacenter World North America (mid-2026):** Does Lennox announce a North American DC cooling line, partnership, or anchor customer? Absence = bear-case confirming.
- **R-454B channel inventory updates from HD Supply / Watsco (WSO) earnings:** WSO Q2 print (late July) is the leading indicator on distributor pre-buy unwind.
- **Mexico tariff actions:** Any Section 232 announcement on HVAC components > +10 percentage points compresses LII faster than peers.
- **IRA 25C tax credit fate in 2026 budget reconciliation:** Material change weakens heat-pump pricing umbrella for premium OEMs.
- **Vertiv, Modine, nVent next prints:** If their DC growth decelerates >20% sequentially, the AI cooling cohort de-rates and money may rotate to defensive HVAC names like LII (paradoxically bullish).
- **Hyperscaler capex guidance (META, MSFT, GOOG, AMZN Q2 prints):** If aggregate AI capex guidance is cut >10% sequentially, the cooling cohort de-rates further and LII outperforms on relative basis, but absolute returns are unlikely to be strong.

## What I could not verify

- LFB Group / Apx DCS revenue contribution to LII consolidated — not disclosed as a segment; estimates from third parties are unreliable.[7][8]
- Lennox's actual share of the ~$5–7B North American precision air-cooling market (CRAH/CRAC + close-control). My read is "negligible" but I could not source a precise figure.
- Whether Lennox has any in-progress liquid-cooling product development for North America (no public disclosure; possible internal effort).
- Net debt to derive a precise EV; I inferred ~$1.0–1.5B from prior-year disclosures but did not verify against latest 10-Q.
- Exact composition of "commercial backlog" (national accounts vs. one-off bids vs. DC-adjacent); the BCS +26% organic in Q1 2026 print[9] could include some DC-adjacent installations not broken out.
- The pace at which the LFB Group ApX CDU has actually been deployed at named European hyperscale or colo customers.

## Sources

[1] https://markets.financialcontent.com/stocks/article/finterra-2026-1-22-lennox-international-lii-deep-dive-navigating-the-2026-refrigerant-transition-and-electrification-era — retrieved 2026-05-10 — segment mix (HCS ~67%, BCS ~33%), replacement vs. new construction split (~75/25), 2026 refrigerant transition narrative.
[2] https://finance.yahoo.com/quote/LII/ — retrieved 2026-05-10 — current price ($521.25, 2026-05-09 close), 52-week range $434.06–$689.44.
[3] https://en.wikipedia.org/wiki/Lennox_International — retrieved 2026-05-10 — North American HVAC replacement-focused business description, manufacturing footprint.
[4] https://stockanalysis.com/stocks/lii/forecast/ — retrieved 2026-05-10 — consensus 12-mo PT $545 median / $575 mean, forward P/E 25.7×, FY26 EPS estimate $24.29.
[5] https://www.datacenterdynamics.com/en/news/lennox-expands-into-data-center-cooling/ — retrieved 2026-05-10 — LFB Group / Apx DCS standalone launch and product range.
[6] https://datacentre.solutions/news/68930/lennox-launches-new-business-to-support-data-centre-industry — retrieved 2026-05-10 — LFB Group product portfolio: CRAH, CCU, FWU, CDU, dry coolers; 100+ engineer team, EMEA focus.
[7] https://datacentrenews.uk/story/lfb-group-launches-modular-data-centre-cooling-for-ai-era — retrieved 2026-05-10 — LFB FWU 100–1,000 kW range, AI workload positioning, EMEA-only commercial focus.
[8] https://www.electronics-cooling.com/2025/06/data-centre-solutions-division-from-lfb-group-launches-lennox-branded-fan-wall/ — retrieved 2026-05-10 — LFB transition from Lennox EMEA in April 2025.
[9] https://www.fool.com/earnings/call-transcripts/2026/04/29/lennox-lii-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q1 2026 results: revenue $1.14B, BCS +26% organic, +300 bps margin, HCS -12% organic, $50M factory under-absorption, 30% production cut, guidance raise to ~8% revenue growth.
[10] https://www.gurufocus.com/news/8830972/lennox-international-inc-lii-q1-2026-earnings-call-highlights-strong-revenue-growth-amid-margin-challenges — retrieved 2026-05-10 — corroboration on Q1 details and absence of any DC-segment color in Q&A.
[11] https://www.macroaxis.com/valuation/LII/Lennox-International — retrieved 2026-05-10 — market cap ~$18.1B; 34.8M shares; short interest 5.9% of float, 7.74 days to cover.
[12] https://www.prnewswire.com/news-releases/lennox-is-the-first-hvac-oem-to-complete-the-us-department-of-energys-commercial-building-hvac-technology-challenge-lab-validation-302548090.html — retrieved 2026-05-10 — DOE Cold-Climate Heat Pump RTU 15–25 ton lab validation, first OEM.
[13] https://www.budgetheating.com/blog/upcoming-price-increases-for-lennox-2026-guide/ — retrieved 2026-05-10 — Feb 16, 2026 ~10% list-price increase on residential equipment; R-454B / A2L transition mechanics and cost.
[14] https://finance.yahoo.com/markets/stocks/articles/lennox-international-stock-underperforming-nasdaq-061350423.html — retrieved 2026-05-10 — LII -1.8% YTD (late March), LTM -16.3% vs. Nasdaq +23.4%.
[15] https://markets.financialcontent.com/stocks/article/marketminute-2025-12-18-the-new-architect-of-silicon-valley-vertivs-cooling-dominance-propels-stock-toward-2026-highs — retrieved 2026-05-10 — Vertiv co-developed GB200 NVL72 reference cooling architecture; dead-heat with Schneider in DCPI; Modine 50–70% YoY DC growth.
[16] https://www.mordorintelligence.com/industry-reports/commercial-hvac-market — retrieved 2026-05-10 — Trane $150M / 12 hubs (Jan 2026); JCI $200M / 10-yr 15-hyperscale deal (Nov 2025); Carrier $450M Monterrey chiller plant expansion (Jan 2026); Daikin DC cooling launch at AHR 2026.