# BLK — BlackRock, Inc.

## Where this sits in the AI stack
BLK is not a chip, packaging, kernel, or cloud-runtime company. It sits two layers above the silicon, at the **capital-and-real-asset layer** of the AI buildout: (1) it owns and operates Aladdin, the workflow OS for ~$25T of investable assets [2], and (2) through its Global Infrastructure Partners (GIP) arm and the AI Infrastructure Partnership (AIP) co-vehicle with Microsoft, MGX, NVIDIA and xAI, it is aggregating sovereign-and-pension equity to buy hyperscale colocation campuses and the gas/renewable generation behind them [3][4][5]. The pending $40B Aligned Data Centers acquisition (5 GW, 50 campuses) and the €2B ACS development JV (1.7 GW pipeline) are the two physical asset positions [4][6][7]. BLK is the financier, landlord, and analytics provider — not the technologist.

## Snapshot
- **Price:** $1,084.83 (2026-05-08 close) [1][8]
- **Market cap:** ~$176.7B [8]
- **52-week range:** $917.39 – $1,219.94 [8]
- **Forward P/E:** ~20.0× (NTM) — implies consensus NTM EPS ~$54; Zacks FY26 EPS estimate $50.23 [8][9]
- **EV / NTM revenue:** ~6.5× (market cap + small net debt over ~$28B 2026 consensus revenue; caveat: fee-on-AUM model makes this less informative than P/E or P/AUM) [10]
- **Consensus 12-month price target:** $1,275 (StockAnalysis composite of 14 analysts, "Strong Buy"; +17.5% from spot) [8]
- **YTD total return:** +24.2% [8]
- **Short interest (% of float):** 1.26% (2.4 days to cover; ~1.92M shares short as of 2026-04-15) [11]
- **Dividend yield:** 2.11% [8]

## Moat — what it is physically made of
BLK has two functionally distinct moats, of very different durabilities, plus a third that is mostly aspirational at this stage. They should not be conflated.

**1. The Aladdin software moat (real, durable, ~30 years compounded).** Aladdin is a front-to-back portfolio, risk, and operations platform built by an internal organization of ~7,000 people, of whom ~4,000 are engineers, maintaining roughly 100 front-end applications [2]. It is not "a CRM for asset managers"; it is the *system of record* for positions, exposures, and book-of-record accounting at clients managing a meaningful share of global investable wealth. The platform crossed $25T of monitored assets at end-2025 [2], with reported retention near 98% and 2025 technology-services revenue of $2.0B (+24%); annual contract value (ACV) approached $2B entering 2026, +31% YoY (16% organic) [12]. The architectural specifics that matter:
- Cloud-agnostic deployment: primary on Microsoft Azure (Azure Kubernetes Service, Azure SQL hyperscale, Ultra Disk for low-latency risk runs) [13], with an AWS partnership announced December 2025 and GA in H2 2026 [2]. Both hyperscalers compete for hosting share *of Aladdin*; that is the strategic posture of a system clients refuse to leave.
- Aladdin Copilot is a supervised agentic stack on LangChain/LangGraph with GPT-4-family function calling for tool orchestration over hundreds of internal APIs [14]. Implementation choice signals — they bought GPT call-tier rather than train a domain model. The moat is the API surface and the data, not the LLM.
- Preqin (closed March 2025) plus eFront integration extends Aladdin into private markets (deal sourcing, fund accounting, pre/post-investment workflow) on a single data layer [15][16]. This closes Aladdin's structural gap vs. mid-tier competitors (SimCorp One, Bloomberg AIM, MSCI BarraOne) precisely as private-credit and infra-fund AUM is the fastest-growing pool [12].

Switching cost is empirically real: Deutsche Börse paid ~$4.3B for SimCorp in 2023 and combined it with Axioma to *attempt* a European Aladdin alternative; it has gained share at the mid-market but has not displaced Aladdin at any large client [17]. The base rate for displacement of an entrenched front-to-back financial workflow system is poor — Bloomberg Terminal has held its position for 40+ years across multiple credible challenges.

**2. The capital-aggregation moat (real, but less defensible).** GIP (acquired Oct 2024 for $12.5B) plus AIP gives BLK the ability to call sovereign wealth (Kuwait Investment Authority, Temasek, Mubadala via MGX) plus Microsoft as a strategic LP and NVIDIA as technical advisor at $30B equity / $100B debt-inclusive scale [3][4]. That LP roster is genuinely scarce — Brookfield's competing $10B AI infra fund (first-close target early 2026) and Apollo's $40B+ 2025 deployment are credible peers but neither has the same anchor-tenant alignment with Microsoft [18][19]. The defensibility horizon here is 3–5 years; LP relationships move with people, and GIP's founders (Bayo Ogunlesi et al.) are now BLK board members, which is both anchor and key-person risk.

**3. The physical-power-and-grid moat (asserted, not yet proven).** The AIP / NextEra / GE Vernova partnership theoretically gives BLK preferential allocation in a gas-turbine backlog now stretching ~5+ years; GE Vernova orders surged 71% YoY to $18.3B in Q1 2026, with backlog at $163B [20]. NextEra received federal approval in March 2026 for up to 10 GW of new gas generation specifically pitched at AI demand [20][21]. Whether AIP actually has *contractual* turbine slot priority versus paying spot-market premiums is not publicly disclosed — see "What I could not verify."

What BLK does **not** own at the silicon/system layer: no fab, no HBM contract, no CoWoS-L allocation, no NVL72 manufacturing, no NCCL/CUTLASS contribution history, no patents on cold-plate or CDU technology, no fiber, no transformer manufacturing capacity. Tenants in Aligned's halls bring those.

## AI buildout bottleneck map
The actual gating constraints over the next 24 months and where BLK sits:

| Constraint | Status (mid-2026) | BLK's position |
|---|---|---|
| Grid generation / interconnect | ~49 GW US shortfall projected by 2028 (PJM); ~2,300 GW stuck in interconnection queue [22] | **Beneficiary via AIP/NextEra/GE Vernova partnership; owner of permitted brownfield power at Aligned campuses** |
| Gas turbine slots | GE Vernova backlog ~5+ years; orders +71% YoY [20] | **Indirect beneficiary** (AIP supply-chain access claim is partially verified) |
| CoWoS-L / advanced packaging | TSMC capacity tight through 2026, easing in 2027 | **Indifferent** (not in this layer) |
| HBM3e / HBM4 | Samsung yield gap closing; SK hynix dominant | **Indifferent** |
| Optical interconnect (800G/1.6T) | Tight; Coherent/Lumentum capacity-constrained | **Indifferent** |
| Liquid cooling at >100kW/rack | >50% of new hyperscale builds are liquid-cooled from day one [23] | **Beneficiary** — Aligned's DeltaFlow direct-to-chip system is shipped in current builds [24] |
| Electrical contractor / switchgear | Lead times 50–100+ weeks for medium-voltage switchgear | **Exposed** (capex inflation hits AIP IRRs) |
| Kernel/compiler talent | Severely constrained at frontier labs | **Indifferent** |
| Frontier training data | Rights / quality plateau under scrutiny | **Indifferent** |

The dossier's central technical observation: BLK is concentrated on the **two bottlenecks that look most likely to bind** (power, permitted land/cooling) and absent from the bottlenecks where the supply curve is improving (packaging, HBM). That is a deliberate placement.

## Competitive teardown
BLK has different competitors at each of its three layers:

- **Aladdin vs. SimCorp One (Deutsche Börse / Axioma) and Bloomberg AIM/PORT:** SimCorp One is the only credible front-to-back enterprise alternative for >$100B AUM clients; it has won mid-tier mandates in Europe but no public displacement of Aladdin at megacap clients [17]. Bloomberg AIM/PORT is stronger on fixed-income trading workflow but weaker on operations and book-of-record. **MSCI's risk analytics** (Barra, RiskMetrics) compete on risk models specifically but not the full stack. Aladdin's Preqin-eFront integration eliminates the most credible attack vector (private markets data) [15][16]. Time-to-parity for a green-field competitor is realistically 8–12 person-years per major module × ~30 modules — call it a decade for a well-funded entrant, longer with the data-network gap.
- **AIP vs. Brookfield AI Infrastructure Fund, KKR Digital Infrastructure, Apollo, Stonepeak:** Brookfield is the closest peer with Nvidia as backer and a $10B target for early-2026 first close [18]. KKR has ~$34B already deployed in digital infrastructure across 23 investments [19]. Apollo deployed $40B+ in 2025 including the Stream Data Centers majority and $3.5B into Valor/xAI [19]. **AIP's structural advantage** is Microsoft as both anchor LP and visible counterparty for compute take-or-pay — a configuration none of the others has at the same scale. Each of these competitors can win individual deals; none can replicate the full BLK + GIP + Microsoft + MGX + NVIDIA stack.
- **Aligned (post-close) vs. Equinix, Digital Realty, CoreWeave, Crusoe, Stargate JV:** Aligned is mid-tier among independent colos by absolute capacity (5 GW vs. Equinix's much larger but lower-density footprint). The differentiation is liquid cooling at scale and proximity to AIP power partnerships [24]. Hyperscaler self-build (the Stargate model — OpenAI/Oracle/SoftBank, plus Meta's Hyperion, Google's own builds) is the most credible long-term competitive threat: it converts third-party colo from "demand sink" to "marginal demand."
- **Asset management core (iShares, multi-asset):** Vanguard, State Street, Fidelity, Invesco. iShares posted record Q1 2026 inflows of $132B [25]. Pricing pressure is structural but volume more than offsets — this is the cash-cow funding the AI infrastructure pivot, not the alpha story.

## Bull case — technical
**The technical conditions:** (i) Frontier model scaling continues to favor concentrated training campuses with >100 MW contiguous load (this is what Aligned's footprint is shaped for); (ii) inference workloads grow into the same physical footprint rather than dispersing to edge — i.e., reasoning models keep needing >>100 GB HBM working sets that a smartphone can't hold; (iii) US grid interconnect stays the binding constraint into 2028 (current PJM and ERCOT data points say it does); (iv) Aladdin's tech-services growth holds 20%+ as private-markets data integration drives ACV expansion at clients pre-existing contract renewal cycles; (v) sovereign capital continues to deploy through US-domiciled fund structures rather than direct (this is a regulatory/political bet).

**Connection to financial outcome:** AIP at full $30B equity drawn, generating ~1.0% management fees + 20% carry over a typical infra-fund 12-year life, would contribute meaningful but not transformational EPS to a $176B-cap business. The alpha is the *multiple re-rating* if the market accepts that Aladdin + private markets is now >25% of revenue and growing 20%+ — that is software-like growth on a financial-services chassis, and would justify a forward P/E in the high-20s rather than the current ~20× [8][12].

**Base rate caveat:** Platform-shift base rates are mixed. CPU→GPU at the silicon layer happened in 8 years (NVIDIA's CUDA seed work started 2006; AlexNet 2012; production dominance by ~2017). On-prem→cloud took ~15 years. Workflow software displacement (Bloomberg, Aladdin class) takes 30+ years and usually doesn't complete. BLK is exposed primarily to the slow-displacement side of the base rate.

## Bear case — technical
**The technical conditions:** (i) **Frontier scaling laws plateau.** If GPT-5/Claude 5/Gemini-3-class models do not deliver step-function improvements over current frontier, marginal demand for the next 50 GW of training capacity collapses and Aligned's $40B EV (which prices in stabilized hyperscale lease economics) is impaired — this is the single fattest-tail risk in the thesis. The Q3 2026 hyperscaler capex prints are the leading indicator. (ii) **Inference becomes radically more efficient.** FP4/FP2 quantization, mixture-of-experts sparsity, speculative decoding, and photonic interconnect reduce $/token by 10× — per-GW data center revenue compresses correspondingly. (iii) **Hyperscaler self-build wins.** If Microsoft builds Stargate-class capacity directly via OpenAI/Oracle and reduces its colo dependence, Aligned's tenant pipeline weakens. Note: Microsoft is *both* a Stargate participant and an AIP LP — an unstable equilibrium. (iv) **Aladdin tech-services growth decelerates** below 15%. The 22% Q1 2026 growth is partly the Preqin acquisition lap; organic growth is 16% [12], and the comparison gets harder. (v) **Real-rate environment turns.** Levered infrastructure IRRs degrade non-linearly above 2.5% real; a fund raising at $30B equity → $100B with debt is exposed. (vi) **Aligned tenant concentration.** Public disclosure does not break out tenants; if 60%+ of NOI comes from one or two hyperscalers, the deal economics are bond-like with equity-fund fees.

**Base rate caveat:** Infrastructure private-equity funds raised in late-cycle conditions have historically delivered IRRs ~300 bps below their target. AI infrastructure may be different. It also may not be.

## Market view check
At ~$1,085 / ~20× forward earnings on FY26 consensus ~$54 EPS [8][9], BLK trades at a meaningful premium to traditional asset-manager peers (T. Rowe, Franklin, Invesco trade 10–14×) and a discount to financial-data-and-software peers (MSCI ~30×, S&P Global ~28×, Moody's ~32×). The implied market view: BLK is being credited for the Aladdin/private-markets/infrastructure pivot but has not been re-rated to a software multiple. Consensus PT $1,275 (+17%) [8] and Strong Buy rating with only 1.26% short interest [11] indicate **broad bull positioning**. The thesis disagreement worth holding: the market price is consistent with continued execution but has not priced a discontinuous re-rating. Either the bull thesis (multiple expansion to 25–28× as tech-services >25% of revenue) or the bear thesis (frontier-scaling plateau impairing Aligned/AIP equity) would move the price meaningfully off this trajectory; the consensus midpoint assumes neither.

## 90-day falsifiers
- **Q2 2026 earnings (mid-July):** Tech-services growth must remain ≥20% YoY and ACV growth ≥25%; below 15% would invalidate the software re-rating thesis.
- **Aligned acquisition close (deadline H1 2026):** Any slip past July, or material remedy demanded by US/EU antitrust, signals a more complicated regulatory environment for AIP's pipeline.
- **AIP next-deal announcement:** Absence of a follow-on platform deal in Q2/Q3 means deployment pace is below the $30B-fund schedule, weakening the "AIP becomes a quarterly EPS contributor" narrative.
- **Hyperscaler Q2 capex (late July):** Microsoft, Meta, Google, Amazon. If any guides Q3 capex down >10% sequentially, AIP demand-side assumption weakens.
- **NVIDIA Q2 earnings (late August):** Hyperscaler comments on Blackwell/Rubin demand and any FP4 inference disclosures change the Aligned per-GW economics.
- **Brookfield AI Infrastructure Fund first close:** If >$15B vs. $10B target, indicates LP demand saturation that prices new AIP tranches up.
- **PJM 2026 capacity auction results (June/July):** Higher clearing prices = stronger AIP/Aligned thesis; capacity glut = weaker.

## What I could not verify
- **Aligned's tenant concentration and lease structure.** Public filings do not disclose top-tenant share, lease tenor distribution, or whether power costs are pass-through vs. fixed. This is the largest single uncertainty in the AIP thesis.
- **AIP's actual capital commitments vs. targets.** The $30B is a target; commitments breakdown by LP is not disclosed beyond named sovereigns.
- **AIP's contractual turbine slot priority** with GE Vernova vs. paying market-clearing premium for slots. The press releases use the word "collaborate" — that is a soft commitment.
- **Aladdin gross retention vs. net retention** decomposition. BLK reports growth, not churn; the 98% number circulating is widely cited but not in BLK's primary disclosures.
- **Aladdin Copilot adoption** by external clients (vs. internal use). LangChain/LangGraph implementation is from third-party engineering blogs, not BLK [14].
- **GIP/AIP carry economics** on the AI infra fund. Standard infra is 1.0–1.5% management + 8% pref + 20% carry; AIP-specific terms not public.
- **Forward P/E precision.** Sources reconcile to 20× ± 1× depending on whether NTM rolls into FY27; consensus EPS estimates dispersion is meaningful (Q4 print will tighten).

## Sources
[1] https://finance.yahoo.com/quote/BLK/ — retrieved 2026-05-10 — BLK price data
[2] https://businesstats.com/blackrock-aladdin-platform/ — retrieved 2026-05-10 — Aladdin AUM ($25T), engineering org size, AWS partnership announcement
[3] https://www.blackrock.com/corporate/newsroom/press-releases/article/corporate-one/press-releases/ai-infrastructure-partnership — retrieved 2026-05-10 — AIP partnership composition, anchor LPs, capital target
[4] https://www.global-infra.com/news/ai-infrastructure-partnership-aip-mgx-and-blackrocks-global-infrastructure-partners-gip-to-acquire-all-equity-in-aligned-data-centers/ — retrieved 2026-05-10 — Aligned acquisition $40B EV, 5 GW capacity, 50 campuses, H1 2026 close
[5] https://ir.blackrock.com/news-and-events/press-releases/press-releases-details/2025/BlackRock-Global-Infrastructure-Partners-Microsoft-and-MGX-Welcome-NVIDIA-and-xAI-to-the-AI-Infrastructure-Partnership-to-Drive-Investment-in-Data-Centers-and-Enabling-Infrastructure/default.aspx — retrieved 2026-05-10 — NVIDIA/xAI joining AIP, NVIDIA technical advisor role
[6] https://www.datacenterdynamics.com/en/news/acs-and-blackrocks-gip-form-2bn-data-center-development-jv/ — retrieved 2026-05-10 — ACS/GIP €2B JV, 1.7 GW pipeline
[7] https://www.datacenterfrontier.com/hyperscale/article/55323360/blackrock-led-consortium-to-acquire-aligned-data-centers-in-40-billion-ai-infrastructure-deal — retrieved 2026-05-10 — Aligned deal commentary
[8] https://stockanalysis.com/stocks/blk/ — retrieved 2026-05-10 — BLK price $1,084.83, 52w range, FY25 revenue $24.22B, fwd P/E 19.99, PT $1,275, YTD +24.2%, dividend yield 2.11%
[9] https://www.zacks.com/stock/quote/BLK/detailed-earning-estimates — retrieved 2026-05-10 — Zacks FY26 EPS estimate $50.23
[10] https://www.stocktitan.net/sec-filings/BLK/10-k-black-rock-inc-files-annual-report-d280a370171b.html — retrieved 2026-05-10 — BLK FY25 10-K revenue and segment data
[11] https://www.marketbeat.com/stocks/NYSE/BLK/short-interest/ — retrieved 2026-05-10 — Short interest 1.26%, 2.4 days to cover, ~1.92M shares (Apr 15 2026)
[12] https://markets.financialcontent.com/stocks/article/marketminute-2026-4-14-blackrocks-q1-2026-earnings-a-masterclass-in-the-solutions-era-of-asset-management — retrieved 2026-05-10 — Tech services 2025 revenue $2.0B (+24%); ACV +31% (16% organic); >20% revenue mix target
[13] https://www.microsoft.com/en/customers/story/25275-blackrock-financial-management-azure-ultra-disk-storage — retrieved 2026-05-10 — Aladdin on Azure Ultra Disk and Kubernetes Service
[14] https://www.zenml.io/llmops-database/agentic-ai-architecture-for-investment-management-platform — retrieved 2026-05-10 — Aladdin Copilot LangChain/LangGraph + GPT-4 function-calling architecture
[15] https://ir.blackrock.com/news-and-events/press-releases/press-releases-details/2025/BlackRock-Establishes-Preeminent-Private-Markets-Technology-and-Data-Provider-with-Close-of-Preqin-Acquisition/default.aspx — retrieved 2026-05-10 — Preqin acquisition close March 2025
[16] https://www.businesswire.com/news/home/20260205430047/en/BlackRock-Aladdin-Drives-Private-Markets-Transparency-By-Unifying-Pre--and-Post-Investment-Tech-On-A-Single-Platform — retrieved 2026-05-10 — Preqin/eFront/Aladdin private-markets workflow
[17] https://www.limina.com/blackrock-aladdin-vs-simcorp — retrieved 2026-05-10 — SimCorp competitive positioning; Deutsche Börse acquisition for ~$4.3B
[18] https://www.datacenterdynamics.com/en/news/brookfield-launches-100bn-ai-infrastructure-fund-secures-nvidia-and-kia-as-backers/ — retrieved 2026-05-10 — Brookfield AI infra fund target, NVIDIA/KIA backing
[19] https://www.pehub.com/apollo-blackstone-kkr-and-others-are-investing-heavily-in-data-center-infrastructure-healthcare-education-attracts-private-equity/ — retrieved 2026-05-10 — Apollo $40B+ deployed, KKR ~$34B in 23 investments, sector M&A scale
[20] https://intellectia.ai/blog/ge-vernova-stock-analysis-2026 — retrieved 2026-05-10 — GE Vernova Q1 2026 orders $18.3B, backlog $163B, raised guidance
[21] https://markets.financialcontent.com/stocks/article/marketminute-2026-3-23-nextera-energy-ignites-golden-age-with-historic-10-gw-natural-gas-expansion-to-power-ai-surge — retrieved 2026-05-10 — NextEra 10 GW natural gas approval, March 2026
[22] https://www.datacenterfrontier.com/energy/article/55363740/the-gigawatt-bottleneck-power-constraints-define-ai-data-center-growth — retrieved 2026-05-10 — PJM 49 GW shortfall projection; 2,300 GW interconnection queue
[23] https://www.datacenters.com/news/cooling-the-future-how-colocation-sites-are-adapting-for-liquid-and-immersion — retrieved 2026-05-10 — >50% of new hyperscale builds liquid-cooled
[24] https://aligneddc.com/hyperscale-and-build-to-scale-campus/ — retrieved 2026-05-10 — Aligned 5 GW, DeltaFlow liquid cooling, hyperscale partnerships
[25] https://www.investing.com/news/company-news/blackrock-q1-2026-slides-eps-beats-on-record-flows-13-organic-growth-93CH-4612994 — retrieved 2026-05-10 — Q1 2026 results: AUM $13.89T, $130B net inflows, $132B iShares record, adj revenue $6.7B (+27%)