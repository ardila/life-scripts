# CVX — Chevron Corporation

## Where this sits in the AI stack
CVX is an integrated oil-and-gas major, not an "AI infrastructure" name in the silicon/software sense. Its only real AI exposure is at the **power layer**: it is converting stranded Permian associated gas into behind-the-meter (BTM) electrons sold to hyperscalers. The flagship vehicle is a JV with Engine No. 1 and GE Vernova to build up to 4 GW of co-located gas-fired generation, with a $7 B West Texas (Pecos) campus that, as of April 2026, is in exclusive negotiations with Microsoft as anchor tenant — initial 2.5 GW expandable to 5 GW, FID targeted H1 2026, in-service late 2027 [2][3][7][20]. The other ~85% of CVX's enterprise value is upstream oil/gas (Permian, Gulf, Tengiz, Australia LNG, and post-July-2025 a 30% non-operating stake in Stabroek/Guyana via the closed Hess deal) and refining [8]. So CVX is a hydrocarbon producer that has identified that AI's binding constraint — power, not chips — happens to monetize the molecules it already extracts.

## Snapshot
- **Price:** $181.62 (close 2026-05-08; markets closed 5/9–5/10) [1]
- **Market cap:** $359.1 B (1.98 B shares × $181.62) [1]
- **52-week range:** $133.77 – $214.71 [1]
- **Forward P/E:** 11.4× (on FY26 consensus EPS ≈ $15.92) [1]
- **EV / NTM revenue:** ≈ 2.0× (EV ~$385 B incl. ~$25 B net debt post-Hess; NTM revenue ~$185 B run-rate) [1][8] — *inferred from disclosed mkt cap, debt, and TTM revenue $185.7 B*
- **Consensus 12-month price target:** $209 (42 analysts; +15% from spot); range across major aggregators $193.55–$216.90 [5][16]
- **Dividend:** $7.12/share, 3.92% yield (paid quarterly) [1]
- **YTD total return:** ≈ +12% (was +22.5% at early-March peak before drawdown from $214 high; current $181.62) [16] — *YTD inferred from peak/trough data, not directly cited*
- **Short interest (% of float):** 1.01% (April 15, 2026 report); 1.6 days to cover [13]

## Moat — what it is physically made of
The "moat" for CVX-as-AI-power is a **stack of separately-durable physical claims**, not one thing. Decomposed:

1. **Permian acreage and associated gas.** CVX produced 1.03 MMboe/d in the Permian in Q1 2026 [9]. Associated gas (the gas that comes up with the oil whether you want it or not) is so over-supplied that the Waha hub printed *negative* prices for a record 25+ consecutive days in March 2026, hitting -$9.75/MMBtu intraday and -$5.69/MMBtu for June 2026 forward [11]. Co-located gas-to-power converts molecules with a $0–negative spot value into electrons sold at hyperscaler power rates; one independent analysis estimates a value uplift of >$3,000 per Mcf at typical PPA pricing vs. the wellhead [22]. **Durability: high** — the takeaway constraint relaxes with the Blackcomb pipeline (Oct 2026) and ~11 Bcf/d of Permian capacity additions through 2028 [11], but the geographic + ownership advantage persists as long as CVX produces oil there.

2. **Slot reservations on seven GE Vernova 7HA gas turbines** (≈448 MW each in combined-cycle), secured 2025 under an accelerated delivery agreement, deliveries beginning late 2026 [2][3]. This is the load-bearing technical moat: GE Vernova ended 2025 with an 80 GW backlog, expects to be sold out through 2030 by end-2026, and ~20–33% of its current contract book is data-center-tied [4]. Siemens Energy and Mitsubishi Heavy backlogs likewise extend to 2030 [4][5]. A new entrant cannot buy a 7HA-class turbine today for delivery before 2029–2030. **Durability: high for ~3 years**, then erodes as OEM capacity expansions land (Siemens scaling 48→70-80 units/yr by 2026; Mitsubishi doubling). The window CVX has *secured* is the window in which the AI capex super-cycle is actually happening.

3. **Hyperscaler anchor (Microsoft exclusivity).** April 1, 2026 announcement: Chevron and Microsoft entered exclusivity to make MSFT anchor tenant of the 2.5 GW Pecos campus, scaling to 5 GW [3][7]. This is materially different from the cluttered list of MOUs other producers have. **Durability: medium** — exclusivity ≠ definitive PPA; the actual contract is not signed and FID is still pending [7].

4. **Capital depth and balance sheet.** $18–19 B 2026 capex budget, $2.5–3 B/quarter buyback range, A-rated balance sheet [7]. The $7 B Pecos plant alone would consume the project-finance capacity of most independents; CVX can self-fund. **Durability: high** as long as oil prices stay above ~$55 Brent.

5. **CCS / lower-carbon optionality** (Quest in Canada; Bayou Bend with Talos/Equinor on the Gulf). Carbon capture on combustion exhaust at >90% capture rate is technically harder than capture on a gas-processing stream (lower CO₂ partial pressure), but it lets the JV market gas+CCS power as ESG-eligible to hyperscalers with net-zero pledges [2]. **Durability: contested** — CCS economics depend on 45Q tax credits; political risk.

6. **Stabroek/Guyana (post-Hess, July 2025).** 30% non-operating stake in a >11 Bbbl resource, $1 B/yr expected synergies [8]. Not relevant to the AI thesis directly, but it is the reason CVX's *cash generation* for the rest of the decade is structurally higher and is what funds 1–5.

What is **not** a moat: brand, "ESG", or "AI strategy". The moat is the specific collision of (Permian gas + secured turbines + hyperscaler anchor) — each component has competitors but the integrated stack does not.

## AI buildout bottleneck map
| Bottleneck (next 24 mo.) | CVX position |
|---|---|
| **Power generation capacity** (gas turbines sold out into 2030 [4][5]) | **Beneficiary / supplier** — has 7× 7HA slots reserved [2] |
| **Grid interconnection** (PJM queue >8 yrs; ERCOT rules in flux) [17] | **Beneficiary** — BTM co-location bypasses grid interconnect entirely [3][6] |
| **Permian gas takeaway** (Waha negative pricing) [11] | **Beneficiary** — converts stranded gas to power on-site |
| **Combined-cycle plant cost inflation** (+66% since 2023, +195% turbines vs. 2019) [9][10] | **Exposed** — but slot reservation likely locked older pricing; FID not yet final |
| **Electrical EPC / contractor capacity** | **Exposed** — same labor pool as XOM/OXY/utilities |
| **CoWoS-L, HBM3e, NVLink/NCCL, optical, >100 kW liquid cooling, kernel talent** | **Indifferent** — none of CVX's business |
| **Training data, scaling-law plateau** | **Indifferent** in direction; **exposed** in magnitude (if AI capex disappoints, demand for new gas plants disappears) |
| **SMR / nuclear competition** (Kairos-Google ~2030; AP300 early-2030s; Vogtle-class first-of-kind risks) [19] | **Time-limited beneficiary** — gas is the *only* multi-GW BTM solution that scales before 2030 |

The single most important fact for the thesis: **gas turbines and grid interconnects are the binding constraints on US AI capacity through ~2028, and CVX already holds positions in both via OEM slot reservations and BTM co-location**.

## Competitive teardown
On the specific axis of **multi-GW behind-the-meter gas-to-data-center**, CVX is competing against:

- **ExxonMobil (XOM):** Announced a 1.5 GW BTM gas plant for data centers and a 1.2 GW MOU with NextEra (Dec 2025) [12]. Comparable strategy, broader CCS pitch, no disclosed turbine slot reservations of comparable scale, no anchor hyperscaler at exclusivity stage. **CVX leads on contracted progress; XOM leads on CCS narrative**. XOM tends to move slower on FIDs.
- **Occidental (OXY):** BTM gas + DAC story; one disclosed 2 GW project ("Horizon" AI data center, Texas) [14]. Smaller scale, more leveraged balance sheet, DAC economics highly dependent on 45Q. Not in same weight class.
- **EQT:** Gas supplier, not power developer. Locked in 800 MMcf/d to the converted 2.7 GW Bruce Mansfield (Shippingport) and 4.4 GW Homer City (Pennsylvania) [14]. **Owns Marcellus molecules, not Permian** — closer to PJM load, no Permian-style stranded-gas arbitrage. Pure-play upside if you want the molecule, but no integrated power asset.
- **Energy Transfer (ET) / midstream:** Sells the molecule, takes a tariff, no equity in the power. Lower beta to the thesis.
- **NextEra, Vistra, Constellation (regulated/IPP utilities):** Own the existing fleet (and in Constellation's case, restarting TMI for Microsoft). Compete *for* the hyperscaler PPA, not on molecule supply. Constellation has nuclear and is the natural partner for hyperscalers wanting clean baseload; gas-with-CCS is the alternative.
- **GE Vernova (GEV):** Not a competitor; the supplier. CVX's slot reservation is GEV's revenue.

The honest read: **XOM is doing the same thing**, the same way, and is not behind on capability — only on disclosure-cycle progress. By end-2026, both will likely have one major hyperscaler-anchored project under construction. The differentiation is execution speed and the depth of in-basin gas integration in the Permian, where CVX is the #1 producer; XOM (Pioneer-acquired) is #2 and similarly positioned.

The competitive *threat to the entire thesis* is not another oil major — it is **SMRs landing in 2029–2031** in volume that would obviate gas BTM. Westinghouse AP300 (built on the AP1000 supply chain that produced Vogtle 3/4) is the only SMR using a licensed reactor design and has the most credible early-2030s timeline [19]. Kairos-Google targets first unit 2030 [19]. Multi-unit deployments unlikely before 2032. So gas has roughly a 5-year window of indispensability.

## Bull case — technical
Conditions that need to hold:
1. **Hyperscaler power demand stays at projected trajectory** (2.5 Bcf/d data-center gas demand by end-2026, 3–6 Bcf/d S&P forecast / 10–12 Bcf/d midstream-bull case by 2030 [9]).
2. **Gas turbine bottleneck does not loosen materially before 2028** — current OEM capacity expansions land 2027+, and demand backlogs already extend to 2030 [4][5].
3. **FERC's December 2025 colocation ruling and ERCOT's rulemaking remain BTM-friendly** [17]. ERCOT decisions land late 2026 — falsifier window.
4. **CVX-Microsoft definitive PPA signs by end-2026** at terms consistent with a ~15% utility-style equity return on the $7 B project.
5. **Permian gas pricing remains soft enough** that the molecule-to-electron arbitrage is preserved (negative Waha pricing is bullish for the JV's input cost; relief in late 2026 reduces but does not eliminate the spread).
6. **SMR commercial operation slips past 2030** — the historical base rate on first-of-a-kind nuclear delivery is ~3–5 years late vs. nameplate timeline (Vogtle 3/4 was ~7 years late). High prior probability.

If all of these hold, the data-center-power business goes from optionality to a discrete reportable segment. Math: 4 GW × ~$1 B EBITDA/GW (utility-style economics) × 8–10× EBITDA multiple = $32–40 B of segment value, ~10–11% of current market cap, plus a re-rating of the upstream multiple as Permian gas finds a structural in-basin buyer. The plausible re-rating is from ~11.4× forward P/E to ~13–14×, layered on top of growing earnings — a $230–250 stock over 18–24 months.

**Base-rate caveat:** Oil majors entering adjacent businesses underperform expectations historically (Shell/BP renewables, XOM lithium). However, gas-fired power generation is *not* an adjacent business — CVX already operates ~3 GW of own-use cogeneration. So the adjacency penalty applies less than it would to, say, a hydrogen pivot.

## Bear case — technical
What a short-seller who knows the stack would write:

1. **The data-center power story is ~15% of equity value at ceiling, and is being asked to carry the multiple for the whole company.** Even if 4 GW is built and earns $4 B EBITDA, that is ~7% of CVX's TTM EBITDA. The base business is $50–60 oil-leveraged, not AI-leveraged.
2. **Hyperscaler capex is correlated and reflexive.** If Microsoft's FY27 capex guide cuts by >10% sequentially or anchor PPA terms erode, every gas plant under planning gets repriced. Two of the four 4 GW JV plants are speculative slot reservations without anchor demand.
3. **The 7HA slot reservation is a contractual asset, not a piece of equipment in a yard.** Deliveries begin late 2026 [2]. If CVX walks away, GEV resells the slots — cancellation cost is bounded; so is the upside if CVX cannot site/permit fast enough.
4. **Permian gas oversupply ends.** Blackcomb (Oct 2026) and ~11 Bcf/d of new takeaway through 2028 [11] arbitrage the negative Waha price away. The "free gas" thesis has a sunset on it.
5. **Behind-the-meter regulation tightens.** FERC's PJM ruling went the right way for BTM in Dec 2025, but ERCOT's track is still pending and the politics around hyperscalers paying *less* than residential ratepayers for grid-equivalent service is escalating. A reversal is non-zero probability [17].
6. **SMRs hit faster than the bear-case-of-the-bear-case allows.** Westinghouse AP300 leverages the Vogtle 3/4 supply chain that *did* eventually deliver — the early-2030s timeline is more credible than typical first-of-kind nuclear [19]. Hyperscalers with net-zero-by-2030 commitments will pay a premium for clean firm power and are *already* signing nuclear restart deals (TMI/Microsoft, Vogtle/AWS-adjacent). Gas + CCS may be a 2027–2030 bridge, not a multi-decade regime.
7. **Oil price.** Most importantly: CVX is still ~70–80% an oil-price stock. WTI < $55 sustained removes 100% of any AI-thesis premium and the Permian volume story (1 MMboe/d through 2040 [9]) compresses.
8. **Capital allocation drift.** Building $7–28 B of power infrastructure at utility-equity returns (10–15%) is *worse* unit economics than CVX's E&P returns at >$60 oil, and *worse* than buybacks at 11× P/E. The bear thesis is that the AI pivot is a margin-dilutive misallocation dressed up as a growth story.

## Market view check
At $181.62, 11.4× forward P/E, EV/NTM revenue ≈ 2.0×, the stock prices Chevron as a mature integrated oil major with steady volume growth from Hess/Stabroek. The data-center power business is **not yet meaningfully in the multiple** — sell-side targets cluster at $193–217 and are driven by oil price assumptions and Hess accretion, not AI [16]. The market appears to view the data-center pivot as either (a) too small to matter at the consolidated level, (b) too execution-dependent to underwrite before FID, or (c) optionality already captured in the modest premium to oil-major peers. The technical reality says (a) and (b) are partially right — the project is too small *today* — but the slot reservation, Microsoft exclusivity, and Permian gas arbitrage create a credible path where 4 GW becomes 10+ GW and the segment becomes worth re-rating. **You are not paying for that path.** That asymmetry is the actual reason to own it. If you only believe the consensus oil-major view, the stock is fairly priced and is a 4% dividend with low single-digit return potential.

## 90-day falsifiers
- **FID on the Pecos/Microsoft project** by end-Q3 2026 (CVX guided H1 2026 on the Q1 call [7]). Slip past Q3 = thesis weakens materially.
- **Definitive PPA terms** disclosed: PPA price, tenor (15+ yr expected), capacity charge structure, who owns the gas supply contract.
- **Microsoft Q4 2026 capex guide** (calendar Q3 reporting, late July). >10% sequential cut to AI/data-center capex = direct hit to the 4 GW pipeline.
- **GE Vernova Q2 2026 backlog disclosure** — if backlog breaches 100 GW or sells through 2031, the slot-reservation moat strengthens; if cancellations rise, weakens.
- **ERCOT BTM rulemaking** — final rules expected late 2026; first signals in next 90 days. Adverse ruling on cost allocation would re-price the Pecos economics.
- **Waha basis** — if it returns positive earlier than Oct 2026 (e.g., Blackcomb commissioning ahead of schedule), the molecule arbitrage shrinks faster than expected.
- **A second hyperscaler signing** (Meta/AWS/Google) at one of the other JV sites — would confirm the model scales beyond a single MSFT deal.
- **Q2 earnings call (early Aug 2026)**: any specific dollar guidance on power-segment EBITDA or required equity capital would be the first quantification.

## What I could not verify
- **The exact equity split** in the Engine No. 1 / Chevron / GE Vernova JV — never publicly disclosed [21].
- **Whether the 7HA slot reservations are firm commitments or include cancellation rights**; GE Vernova's "slot reservation agreements" are typically deposits with milestone-gated step-ups, but specific terms not disclosed.
- **CVX's actual gas supply price** to the JV (transfer pricing) — material to JV economics but a related-party transaction not broken out.
- **Whether MSFT's "exclusivity" is single-site or applies across the JV's 4 GW pipeline** — Fortune/Bloomberg coverage suggests single-site (Pecos) only [3][7].
- **NTM revenue consensus** — used TTM as proxy; Street consensus revenue figures dispersed widely due to oil-price assumption variance.
- **Forward EPS of $15.92** is implied from the 11.4× forward P/E and current price; the precise consensus number was not directly retrieved.
- **CCS economics on the Pecos project specifically** — whether CCS is in the base case or an option add-on; press releases describe it as an option [2].
- **Capex per GW for the JV** — $7 B for 2.5 GW implies $2,800/kW, consistent with the 2025 industry average $2,157/kW + uplift for accelerated schedule and BTM premium [9], but not directly disclosed.
- **CVX's all-in own-use power generation capacity** today — referenced only as "decades of expertise" in JV materials [2].

## Sources
[1] https://stockanalysis.com/stocks/cvx/ — retrieved 2026-05-10 — current price ($181.62), market cap ($359.1 B), forward P/E (11.4×), 52-week range, dividend, beta, shares outstanding, TTM revenue and EPS.
[2] https://www.chevron.com/newsroom/2025/q1/power-solutions-for-us-data-centers — retrieved 2026-05-10 — Chevron / Engine No. 1 / GE Vernova JV announcement, 4 GW target, 7× 7HA turbines, 2027 in-service, CCS optionality.
[3] https://fortune.com/2026/04/01/microsoft-chevron-exclusivity-powering-west-texas-data-center-complex/ — retrieved 2026-05-10 — Microsoft-Chevron exclusivity, 2.5 GW expandable to 5 GW, Pecos site, $7 B project cost.
[4] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — GE Vernova 80 GW backlog, sold-out-through-2030 outlook, ~20–33% data-center-tied.
[5] https://www.bloomberg.com/features/2025-bottlenecks-gas-turbines/ — retrieved 2026-05-10 — Siemens Energy / Mitsubishi gas turbine backlog into 2030.
[6] https://www.gevernova.com/gas-power/resources/articles/2025/meeting-data-center-demand-with-chevron — retrieved 2026-05-10 — technical detail on 7HA deployment in BTM configuration, deliveries late 2026.
[7] https://www.fool.com/earnings/call-transcripts/2026/05/01/chevron-cvx-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1 2026 earnings call: $18–19 B capex, $2.5–3 B/quarter buyback, FID timing on Pecos, Microsoft exclusivity confirmation.
[8] https://www.chevron.com/newsroom/2025/q3/chevron-completes-acquisition-of-hess-corporation — retrieved 2026-05-10 — Hess deal closed July 18, 2025, $53 B, 30% Stabroek interest, $1 B annual synergies.
[9] https://techcrunch.com/2026/04/27/data-center-demand-drives-66-surge-in-natural-gas-power-plant-costs/ — retrieved 2026-05-10 — combined-cycle plant cost from $1,500 → $2,157/kW (+66%), turbines +195% vs. 2019, data-center gas demand 0.8 → 2.5 Bcf/d by end-2026.
[10] https://www.americanactionforum.org/insight/ai-data-center-power-surge-shifting-trends-toward-natural-gas/ — retrieved 2026-05-10 — gas planned-capacity share rose 11.1% → 18.1% (2024–2026); 71% surge in non-renewable additions.
[11] https://pgjonline.com/news/2026/april/permian-constraints-keep-waha-gas-prices-negative-for-record-stretch-as-us-markets-weaken — retrieved 2026-05-10 — Waha negative for record 25+ days, -$5.69/MMBtu June fwd, Blackcomb relief Oct 2026, +11 Bcf/d capacity by 2028.
[12] https://www.datacenterdynamics.com/en/news/exxonmobil-plots-natural-gas-power-plant-to-exclusively-power-data-centers/ — retrieved 2026-05-10 — XOM 1.5 GW gas plant + 1.2 GW NextEra MOU for data centers.
[13] https://www.marketbeat.com/stocks/NYSE/CVX/short-interest/ — retrieved 2026-05-10 — short interest 1.01% of float (April 15, 2026), 1.6 days to cover.
[14] https://naturalgasintel.com/news/eqt-snags-two-natural-gas-supply-contracts-including-for-massive-44-gw-ai-campus-in-pennsylvania/ — retrieved 2026-05-10 — EQT's PA data-center gas-supply deals (Bruce Mansfield/Shippingport, Homer City 4.4 GW); also context on OXY Horizon 2 GW.
[15] https://eastdaley.com/the-burner-tip/chevron-plans-data-center-power-complex-in-permian-supporting-new-basin-demand — retrieved 2026-05-10 — gas-consumption implication of multi-GW Permian plant; 1.03 MMboe/d Q1 2026 production; FID timeline.
[16] https://blog.mexc.com/finance/cvx-stock-price-prediction-2026/ — retrieved 2026-05-10 — 42-analyst average PT $209; alternative aggregator targets $193.55 / $214.96 / $216.90; YTD performance context.
[17] https://introl.com/blog/ferc-pjm-colocation-ruling-data-center-power-plant-guide-2025 — retrieved 2026-05-10 — FERC Dec 2025 colocation ruling, PJM 8+ year interconnect queue, ERCOT rulemaking pending late 2026.
[18] https://www.chevron.com/newsroom/2025/q3/built-on-legacy-driven-by-discipline-chevrons-permian-advantage-explained — retrieved 2026-05-10 — Chevron Permian acreage and 1 MMboe/d-through-2040 plateau target.
[19] https://oilprice.com/Alternative-Energy/Nuclear-Power/SMRs-Explained-Real-World-Economics-Fuel-Bottlenecks-and-the-Race-to-Scale.html — retrieved 2026-05-10 — SMR commercial timeline 2028–2030 earliest, Kairos-Google 2030, Westinghouse AP300 early-2030s leveraging Vogtle supply chain.
[20] https://www.datacenterfrontier.com/energy/article/55264592/chevron-ge-vernova-engine-no1-join-race-to-co-locate-natural-gas-plants-for-us-data-centers — retrieved 2026-05-10 — JV co-location strategy, project geography (South/Midwest/West), BTM rationale.
[21] https://engine1.com/wp-content/uploads/2025/01/2025-0127_FINAL-PRESS-RELEASE_EN1_CVX_GE_.pdf — retrieved 2026-05-10 — official JV press release; equity-split details not disclosed.
[22] https://novilabs.com/blog/turning-gas-to-gold-over-3000-of-value-per-mcf-why-chevron-is-building-a-power-plant-in-the-permian/ — retrieved 2026-05-10 — independent analysis of value uplift on Permian gas via on-site power conversion.