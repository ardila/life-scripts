I have both research bundles. Composing the dossier now.

# NOC — Northrop Grumman Corporation

## Where this sits in the AI stack

NOC is not a member of the AI infrastructure stack in any meaningful sense — it sells no silicon, no packaging, no HBM, no networking, no datacenter power, and no training/inference software. It is the United States' **strategic-deterrence systems integrator**: sole prime on the B-21 Raider stealth bomber, sole prime on the LGM-35A Sentinel ICBM and ground segment, co-prime on classified NRO satellite constellations, and one of two surviving large-scale solid-rocket-motor (SRM) producers. AI-adjacent revenue — IBCS battle management with embedded decision-support automation, MQ-4C Triton autonomous maritime ISR, the Manta Ray XLUUV, the self-funded YFQ-48A "Project Talon" collaborative combat aircraft, the Lumberjack one-way-attack drone integrated with Project Maven, and on-orbit missile-warning processing — is real but a 5–10% slice of a ~$42B revenue base [12]. The thesis is **stealth, silos, and SRMs**, with autonomy as optionality.

## Snapshot

- **Price:** $549.52 (2026-05-08 close) [1]
- **Market cap:** ~$78.1B [2]
- **52-week range:** $453.01 – $774.00 [3]
- **Forward P/E:** ~19.9× on FY26 company-guided MTM-adjusted EPS midpoint of $27.65 ($27.40–$27.90) [4][5]
- **EV/NTM revenue:** ~2.0× (EV ~$88.9B / FY26 sales midpoint $43.75B) [4][5]
- **Consensus 12-month price target:** ~$732 (implied +33% from price) [8]
- **YTD total return (2026):** ~+22% — peaked at ~$735 (+29%) in mid-March before pulling back ~25% on FCF/backlog concerns [9][11]
- **Short interest (% of float):** ~1.1% — well below the 3.2% defense-peer average [10]

## Moat — what it is physically made of

This is not a CUDA-style developer-ecosystem moat, nor a TSMC-style process-node moat. It is **federally-conferred sole-source positions stacked on top of capital, clearances, and proprietary chemistry that take >5 years and a Title III determination to recreate**. Decomposed by component:

1. **Stealth/low-observable IP and process knowledge** — durable, very high. Decades of classified work (Tacit Blue → B-2 → YF-23 → B-21 → multiple classified programs). The B-21 reportedly uses **structurally-integrated radar-absorbent materials** rather than the maintenance-intensive coatings of the B-2, durable enough for austere shelters. This is genuine proprietary tech — not government furnished — and is the closest analog NOC has to a "TSMC node lead." Replicating it requires another decade of classified flight test, which only Lockheed's Skunk Works has the parallel capability to even attempt.

2. **Plant 42, Palmdale (Sites 3 and 4)** — capital + clearance moat. The only currently-cleared production facility on Earth building current-gen US stealth bombers. At least six B-21 airframes are in build to full production standard with first deliveries to Edwards AFB in 2026 [36]. NOC is committing **$2.5B of company capital** (capex raised to $1.85B for 2026 alone, from $1.65B) to lift the production rate ~25% [7][14]. That capex *is* the moat: nobody else has a cleared bay, a tooled production line, and a workforce certified to build a current-generation stealth bomber.

3. **Sole-source on B-21 and Sentinel through ~2050+** — federal-procurement structure. B-21 fleet target 100 (under review for expansion) [13]; Sentinel restructured post-Nunn-McCurdy with Milestone B targeted end-2026 and IOC "early 2030s" [18]. These are 50-year life-cycle programs. The flip side: B-21 LRIP-1 through LRIP-5 are **fixed-price**, which is why NOC took a $1.56B pre-tax charge in Q4 2023 and is planning Aeronautics at "zero profitability" through LRIP. Margin is back-loaded to full-rate production.

4. **Solid rocket motor capacity at Promontory and Magna, UT** — capital + safety/clearance duopoly. With Aerojet Rocketdyne folded into L3Harris, NOC is now one of two large-scale US SRM primes. NOC is **doubling output from ~13,000 motors/yr (2024) to ~25,000/yr by 2029**, with new mix/cast buildings at Promontory and 3× GEM-63 capacity at Magna [24]. Every Sentinel, GBI, NGI, Standard Missile, GMLRS, and most space launch boosters depends on this base. Standing up a new entrant (Ursa Major, X-Bow) at scale in ammonium-perchlorate composite propellants is realistically a 5–8 year project under the safest assumptions about NEPA, OSHA Class 1.1 explosives permitting, and qualification.

5. **Cleared workforce** — talent moat, eroding at the margin. Tens of thousands of engineers cleared to TS/SCI plus Special Access Program (SAP) read-ins. Anduril, Palantir, Shield AI, and SpaceX/Starshield are now competing for the same talent pool, but at a much smaller absolute scale; NOC's incumbent SAP density is hard to match in <10 years.

6. **$95.6B backlog (Q1 2026), 2.3× annual revenue** [5] — not a moat per se, but visible revenue tail.

7. **Silo civil engineering on Sentinel** — underappreciated. The Air Force determined the 50-year-old Minuteman III silos and copper cabling are unsalvageable; Sentinel requires ~450 dug-out silos plus thousands of miles of new fiber and new launch control centers across MT/ND/WY/CO/NE [39]. NOC is the prime, including for the civil works — and a prototype silo broke ground at Promontory on 2026-02-13 [20]. This is the bulk of the cost growth and likely the bulk of the program value, though USAF has not published a clean split — see "What I could not verify."

**What is not a moat:** brand (defense buyers do not care), software ecosystem (no significant developer surface), or pricing power (USG is a monopsony). The moat is regulatory-conferred sole-source × capital × clearances × proprietary chemistry — and is durable specifically *because* it is so heavily regulated, not in spite of it.

## AI buildout bottleneck map

NOC is largely **indifferent** to the canonical AI buildout bottlenecks — HBM3e supply, CoWoS-L allocation, 800G optics, 130-kW liquid cooling, kernel talent, training data quality. It buys some AI compute for IBCS analytics, Maven feeds, and on-orbit processing, but is not a supplier-side or constraint-owner-side player in the AI stack.

The relevant analog is the **defense industrial base buildout** for the FY26+ NDAA topline of **$890.6B** [34] and the Trump administration's "Golden Dome for America" missile-defense initiative. There the bottleneck map is:

| Bottleneck | NOC role | Direction |
|---|---|---|
| Solid rocket motor capacity | One of two primes | **Beneficiary** (doubling capacity) [24] |
| Stealth/RAM production | De facto monopoly on bombers | **Beneficiary** |
| Cleared (SAP) engineers | Large incumbent | Beneficiary, eroding at margin |
| Silo civil engineering | Sentinel prime | **Beneficiary** [39] |
| HALE/MALE drone payloads | Triton/Manta Ray | Mixed (Triton loss April 9 2026) [38] |
| Battle-management software | IBCS sole prime, FRP since Nov 2025 | **Beneficiary** [25] |
| Space-based interceptors | Among 12 awardees in $3.2B Golden Dome OTA round | Beneficiary [23] |
| Continuing-resolution / appropriations cadence | Cost-plus dev programs slowed by CRs | **Exposed** |
| Hyperscaler-style AI compute | None | Indifferent |
| HBM, CoWoS, optics | None | Indifferent |

The honest reading: NOC sits next to the AI bottleneck map, not inside it.

## Competitive teardown

Program-by-program rather than at the conglomerate level:

- **B-21 (stealth bomber)**: no current competitor. LMT Skunk Works is the only entity with the latent capability; absent a re-compete, NOC owns it through ~2050+. Pratt & Whitney supplies the (classified) engine; BAE/Collins/Spirit/GKN at Tier-1.
- **Sentinel ICBM**: sole prime since Boeing dropped out of the original GBSD competition in 2019. The credible "competitive" risk is not a re-compete but a **partial descope** — peeling silo civil engineering off to Bechtel/Fluor/Kiewit, leaving NOC with the missile only. This would be a meaningful value transfer.
- **Next Generation Interceptor (NGI)**: **NOC lost to Lockheed Martin in April 2024** — sole prime down-select, ~$17B contract value [21]. NOC retained only the Modified Ballistic Re-Entry Vehicle (MBRV-11) target role. This is a real franchise loss from Ground-Based Midcourse Defense, where NOC was previously co-prime.
- **CCA Increment 1 (Collaborative Combat Aircraft)**: **NOC lost in April 2024 to Anduril and General Atomics** — first time in ~30 years that a new entrant (Anduril, founded 2017) won a major USAF combat-aircraft program over the legacy primes. NOC's response is the **self-funded YFQ-48A "Project Talon"** unveiled Dec 2025 by Scaled Composites: ~50% fewer parts, 1,000 lb lighter, 30% faster to produce than its losing Increment 1 design, first flight targeted late 2026 [30][31]. NOC is back in the bid pool for CCA Increment 2.
- **F-35 sensors**: retains AN/APG-81 radar; **lost the AAQ-37 DAS to RTX in 2018** for Lot 15 onward [26]. However, in March 2026 USAF issued a sole-source notice to NOC for APG-81 + DAS sustainment/modernization software because the underlying data is NOC-proprietary [27] — a defensive position but real.
- **IBCS (Army IAMD battle management)**: sole prime, in Full-Rate Production since Nov 2025; new 175,500 sq ft EPIC facility in Madison, AL with capacity for 96 Engagement Operations Centers and 192 IFCN relays per year, with embedded AI/automation for decision support [25]. Edge competitors: Anduril Lattice (different scope), RTX (legacy IAMD), LMT (THAAD).
- **Classified space (NRO)**: co-prime with SpaceX on the proliferated LEO constellation; awarded $764M for SDA Tracking Layer Tranche 3 (18 sats) Dec 2025 [22]. Competitive risk: SpaceX **Starshield** (~183+ sats launched as of April 2025) is structurally taking share at the constellation level over the 5–10 year horizon.
- **Munitions**: AARGM-ER on a Navy "**strategic pause**" with FY27 procurement nearly zeroed pending technical fixes — IOC slipped from Q4 2024 to Q4 2026 [28]. SiAW: NOC delivered first round, F-16 separation test Dec 2025, but USAF is actively soliciting a **second source** [29].

Pattern: NOC is **losing some incremental competitions (CCA-1, NGI, DAS, AARGM-ER pause)** while holding the deeply-moated sole-source crown jewels (B-21, Sentinel, IBCS, SRM). The base rate for defense-prime displacement is on the order of decades — the top-5 US primes today (LMT, RTX, BA, GD, NOC) are essentially the same set as in the late 1990s, just more concentrated by merger. Anduril's CCA-1 win is the first prime-level disruption signal in ~30 years; it is a data point, not yet a trend.

## Bull case — technical

Conditions that need to hold:

1. **B-21 production scales to ~10/yr** without further fixed-price loss provisions. Q1 2026 had no B-21 charge — Aeronautics margin recovered to 9.3%, vs. compressed levels in 2024–2025 [5]. The $2.5B company-funded capex commitment is the test: if the LRIP-3+ lots come in at or below the $13.8B 5-lot envelope (down from $19.1B in 2023 — a 28% improvement), the franchise is cleared to harvest decades of full-rate production margin and 50+ years of sustainment.
2. **Sentinel restructure stabilizes** at end-2026 Milestone B [18] without further Nunn-McCurdy breach. NOC is on cost-plus EMD so it is largely insulated from cost growth itself; the political risk is descope, not contractual exposure.
3. **Golden Dome materializes** as architecture, not just executive order. WH cost estimate $175B; CBO $831B; AEI $3.6T. Even at the low end, NOC captures via IBCS (battle management), SRM (interceptors), space sensors (SDA Tranche 3+), and the $3.2B space-based interceptor OTA pool [23].
4. **SRM capacity coming online 2026–2029 generates pricing power** as DoD demand for Sentinel, GBI, Patriot, GMLRS, AARGM, SM-3/6, and HIMARS reloads exceeds the duopoly's combined output.
5. **Project Talon recovers some of the autonomy franchise** at CCA Increment 2 or Navy CCA.

Base rate context: defense-prime moats erode in **decades, not years**. The CPU→GPU transition took ~15 years from initial CUDA release to dominant share; cloud took ~12 years from EC2 launch to majority of new enterprise compute. Equivalent-magnitude transitions in defense (nuclear-deterrence prime turnover, stealth-aircraft prime turnover) historically take 30+ years and require either a generational technology shift or an acquisition. The closest current analog — Anduril at CCA-1 — is one program over one increment. Bull case is consistent with how the cycle has actually unfolded historically.

Financial outcome: at current ~20× FY26 EPS and ~2× EV/sales, even a modest re-rate to peer-average defense multiples (RTX/LMT trade ~22–25× fwd) on +5% organic growth and Aeronautics margin normalization to ~11% delivers the consensus +33% to ~$730 over 12 months [8].

## Bear case — technical

Conditions a credible short-seller who understands the stack would emphasize:

1. **B-21 LRIP fixed-price charges recur**. The $1.56B Q4 2023 hit was not the last word: LRIP-3, -4, -5 are still fixed-price, and the 25% rate increase imposes execution risk on a workforce already stretched by Sentinel and IBCS scale-up. Any new B-21 forward-loss provision in Q2 or Q3 2026 would compress Aeronautics back below 8% margin.
2. **Sentinel partially descoped or split**. The cost growth is overwhelmingly in command-and-launch / civil engineering [19][39] — exactly the scope that could be carved out to civil-engineering primes (Bechtel, Fluor) under DOGE-style cost discipline, transferring meaningful value off NOC's plate.
3. **Anduril/Palantir/SpaceX continue cumulative share gains**. Anduril already won CCA-1 and is competitive at IBCS-edge; Palantir owns Maven (NOC contributes Lumberjack feeds, not the platform) [33]; SpaceX Starshield is encroaching on classified satellite share. None of these individually breaks NOC, but the **pattern of incremental losses** signals erosion of the cleared-talent and software moats specifically.
4. **B-21 production target capped at 100 airframes** rather than expanded. Hegseth's $50B/yr internal reshuffle to 17 priority areas favors strategic/missile/space programs in aggregate but specifically de-emphasizes manned platforms in some readings [35][40].
5. **Triton vulnerability**. The April 9, 2026 MQ-4C loss over the Strait of Hormuz [38] — if attributable to adversary action rather than mechanical — would re-open the post-2019 question of HALE survivability in A2/AD environments. This is a small program in revenue but a credibility hit on NOC's autonomy story.
6. **Backlog has been flat YoY at ~$95.6B** despite record awards activity [5][11], and Q1 2026 burned $1.8B in free cash flow. The market's ~25% drawdown from March highs suggests the bear case is being partially priced in already.

## Market view check

At $549.52 the stock trades at ~20× FY26 EPS, ~2× EV/sales, with consensus PT ~$732 implying +33% upside and short interest of just ~1.1% of float [1][4][8][10]. Sell-side is overwhelmingly Buy-rated (20B/14H/1S at TipRanks). Multiple is in line with defense-peer average; the recent ~25% drawdown from the March $774 peak appears driven by FCF burn ($1.8B Q1 use) and flat-YoY backlog rather than any thesis-changing program development. The market view I infer: long-term beneficiary of strategic-deterrence rebuild and Golden Dome, with near-term skepticism on B-21 execution and cash conversion. I think the market is approximately right on direction but is not yet pricing the optionality of (a) Sentinel coming in at the restructured cost baseline rather than breaching again, (b) Golden Dome architecture decisions in summer 2026 favoring IBCS/SRM/space-based interceptors, or (c) Project Talon re-opening the autonomy franchise. Conversely, the market is underweighting the silo-descope risk on Sentinel.

## 90-day falsifiers

Specific events in May–August 2026:

- **Q2 2026 earnings ~July 21**: consensus EPS ~$6.82 [37]. **Falsifier:** any new B-21 forward-loss provision >$200M reverses the Q1 Aeronautics-margin-recovery thesis. **Falsifier:** FY26 EPS guidance lowered below $27.40.
- **Sentinel Milestone B telegraph**: USAF has indicated end-2026 timing [18]. Any pre-announcement of a *second* Nunn-McCurdy-style breach or scope reduction in summer 2026 would be a major bear catalyst.
- **Project Talon (YFQ-48A) first flight**: targeted ~9 months after Dec 2025 unveil, so ~Sep 2026 — slip into 2027 would damage the autonomy-franchise-recovery narrative [30].
- **Golden Dome architecture decisions**: additional OTAs / down-select from the 12-firm $3.2B pool in summer 2026 [23]. NOC capture share is the question.
- **Triton loss attribution**: if a USN/USAF investigation report attributes the April 9 loss to adversary kinetic action rather than mechanical failure, expect program review.
- **AARGM-ER pause resolution**: Navy IOC was slipped to Q4 2026 [28]. Either IOC achieved on schedule or a formal program restructure decision is likely within 90 days.
- **FY27 budget rollout** from White House — first concrete signal of whether the strategic/missile/space priority reshuffle survives a second budget cycle.
- **DOGE / Hegseth cost-cut announcements**: gross cuts so far ~$5–6B against an $890.6B topline are immaterial [40], but any specific program named for descope would matter.

## What I could not verify

- B-21 LRIP-2 contract size, value, or specific cost performance — classified.
- Exact silo-vs-missile cost split in Sentinel's $140.9B revised baseline — USAF has not published; the revised cost estimate is due end-2026.
- B-21 Tier-1 supplier specifics (engine designation, mission systems vendors, RAM chemistry partners) — substantially classified.
- Cause of the MQ-4C Triton loss on April 9, 2026 (mechanical vs. adversary action).
- NOC's specific capture rate within the 12-firm $3.2B Golden Dome OTA pool.
- Whether the $1.85B 2026 capex guide fully covers all B-21 production-rate-increase tooling, or whether the multi-year company-funded $2.5B understates the eventual ask.
- Multi-year FCF impact of the company-funded B-21 production acceleration — guided at $200M of the $2.5B in 2026 only.
- Whether the F-35 sustainment sole-source notice to NOC results in a meaningful long-term revenue stream or a one-time bridge.

## Sources

[1] https://finance.yahoo.com/quote/NOC/ — retrieved 2026-05-10 — NOC closing price $549.52 on 2026-05-08
[2] https://companiesmarketcap.com/northrop-grumman/marketcap/ — retrieved 2026-05-10 — Market cap ~$78.07B
[3] https://www.wallstreetzen.com/stocks/us/nyse/noc/stock-forecast — retrieved 2026-05-10 — 52-week range $453.01–$774.00
[4] https://www.gurufocus.com/term/forward-pe-ratio/NOC — retrieved 2026-05-10 — Forward P/E and EV
[5] https://www.stocktitan.net/sec-filings/NOC/8-k-northrop-grumman-corp-de-reports-material-event-db72cf83cac8.html — retrieved 2026-05-10 — Q1 2026 8-K with EPS $6.14, revenue $9.88B, $95.6B backlog, FY26 guidance reaffirmed
[6] https://www.investing.com/news/transcripts/earnings-call-transcript-northrop-grumman-beats-q1-2026-forecasts-stock-dips-93CH-4626711 — retrieved 2026-05-10 — Q1 2026 earnings call detail and segment commentary
[7] https://seekingalpha.com/news/4577346-northrop-grumman-reaffirms-43_5b-44b-2026-sales-outlook-while-lifting-2026-capex-to-1_85b-for — retrieved 2026-05-10 — FY26 sales/capex update; capex raised to $1.85B for B-21
[8] https://www.tipranks.com/stocks/noc/forecast — retrieved 2026-05-10 — Consensus PT ~$732, Buy rating breakdown
[9] https://247wallst.com/investing/2026/03/12/northrop-grumman-shares-up-28-ytd-with-its-biggest-upside-not-yet-in-guidance/ — retrieved 2026-05-10 — YTD performance trajectory
[10] https://www.marketbeat.com/stocks/NYSE/NOC/short-interest/ — retrieved 2026-05-10 — Short interest ~1.1% of float
[11] https://www.signalbloom.ai/news/NOC/northrop-grummans-q1-eps-surges-85-but-cash-burn-and-stagnant-backlog-raise-flags — retrieved 2026-05-10 — Q1 cash burn and flat backlog analysis
[12] https://bullfincher.io/companies/northrop-grumman-corporation/revenue-by-segment — retrieved 2026-05-10 — FY25 revenue by segment ($41.95B total)
[13] https://www.airandspaceforces.com/contract-expand-b-21-production-march/ — retrieved 2026-05-10 — B-21 25% production rate increase agreement
[14] https://breakingdefense.com/2026/04/northrop-to-invest-2-5b-to-hasten-b-21-production/ — retrieved 2026-05-10 — $2.5B NOC company-funded B-21 capex
[15] https://www.airandspaceforces.com/northrop-sentinel-b-21-acceleration/ — retrieved 2026-05-10 — Sentinel "back to work" post-restructure
[16] https://theaviationist.com/2024/11/12/the-b-21s-price-is-decreasing/ — retrieved 2026-05-10 — B-21 5-lot envelope $19.1B → $13.8B
[17] https://www.airandspaceforces.com/sentinel-icbm-pentagon-review-result-cost/ — retrieved 2026-05-10 — Sentinel Nunn-McCurdy review certification, $140.9B program cost
[18] https://breakingdefense.com/2026/02/exclusive-sentinel-icbm-to-clear-key-review-this-year-go-operational-in-early-2030s/ — retrieved 2026-05-10 — Sentinel Milestone B end-2026, IOC early 2030s
[19] https://www.defensenews.com/industry/2024/03/28/northrop-says-air-force-design-changes-drove-higher-sentinel-icbm-cost/ — retrieved 2026-05-10 — Sentinel ground segment as cost driver
[20] https://www.aerotime.aero/articles/northrop-grumman-us-air-force-begin-sentinel-icbm-silo-prototyping-in-utah — retrieved 2026-05-10 — Promontory silo prototype groundbreaking 2026-02-13
[21] https://breakingdefense.com/2024/04/lockheed-wins-competition-to-build-next-gen-interceptor/ — retrieved 2026-05-10 — LMT wins NGI April 2024
[22] https://www.airandspaceforces.com/sda-tranche-3-new-missile-tracking-defense-satellites/ — retrieved 2026-05-10 — SDA Tracking Layer Tranche 3 award
[23] https://spacenews.com/space-force-awards-up-to-3-2-billion-for-golden-dome-interceptor-prototypes/ — retrieved 2026-05-10 — Golden Dome 12-firm $3.2B OTA pool
[24] https://insidedefense.com/share/224275 — retrieved 2026-05-10 — SRM capacity 13k → 25k by 2029
[25] https://www.defensedaily.com/northrop-grumman-eyes-quadrupling-ibcs-production-maps-out-more-mobility-and-adding-ai/army/ — retrieved 2026-05-10 — IBCS production scale-up and AI integration
[26] https://www.defensenews.com/air/2018/06/13/raytheon-beats-out-northrop-to-provide-key-f-35-system/ — retrieved 2026-05-10 — DAS lost to RTX 2018
[27] https://defence-blog.com/u-s-air-force-initiates-f-35-sensor-sustainment-support-contract/ — retrieved 2026-05-10 — F-35 APG-81/DAS sustainment sole source to NOC
[28] https://www.navalnews.com/event-news/sea-air-space-2026/2026/04/u-s-navys-new-anti-radar-missile-to-suffer-strategic-pause/ — retrieved 2026-05-10 — AARGM-ER strategic pause
[29] https://www.airandspaceforces.com/air-force-seeks-more-companies-stand-in-attack-weapon/ — retrieved 2026-05-10 — SiAW second source sought
[30] https://breakingdefense.com/2025/12/project-talon-northrop-unveils-new-loyal-wingman-drone-design/ — retrieved 2026-05-10 — Project Talon unveil Dec 2025
[31] https://www.airandspaceforces.com/northrop-grumman-project-talon-cca/ — retrieved 2026-05-10 — YFQ-48A designation and CCA next-round bid
[32] https://defensescoop.com/2026/04/01/army-tests-lumberjack-drone-maven-smart-system/ — retrieved 2026-05-10 — Lumberjack/Maven integration
[33] https://defensescoop.com/2026/04/03/palantir-maven-feinberg-directive/ — retrieved 2026-05-10 — Palantir as Maven prime
[34] https://www.cfr.org/articles/congress-approves-2026-us-defense-bill — retrieved 2026-05-10 — FY26 NDAA $890.6B enacted
[35] https://www.heritage.org/defense/report/the-fy-2026-ndaa — retrieved 2026-05-10 — Hegseth $50B/yr reshuffle to 17 priority areas
[36] https://www.airandspaceforces.com/weapons/b-21/ — retrieved 2026-05-10 — Six B-21 airframes in production, Edwards delivery 2026
[37] https://www.marketbeat.com/stocks/NYSE/NOC/earnings/ — retrieved 2026-05-10 — Q2 2026 consensus EPS ~$6.82
[38] https://news.northropgrumman.com/triton/unmatched-maritime-surveillance-what-you-need-to-know-about-the-mq-4c-triton — retrieved 2026-05-10 — MQ-4C Triton program reference
[39] https://www.airandspaceforces.com/air-force-significantly-change-sentinel-silos/ — retrieved 2026-05-10 — Sentinel silo civil engineering scope
[40] https://www.newsweek.com/doge-cuts-pete-hegseth-dod-contracts-2058508 — retrieved 2026-05-10 — DOGE gross cut totals vs. NDAA topline