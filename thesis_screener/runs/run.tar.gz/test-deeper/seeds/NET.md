I have enough material. Writing the dossier now.

# NET — Cloudflare, Inc.

## Where this sits in the AI stack
Cloudflare operates a global L3/L4/L7 anycast network with ~330 PoPs, a JavaScript/WASM serverless runtime (Workers, built on V8 isolates), object storage (R2), a vector database (Vectorize), a managed RAG pipeline (AutoRAG), a model gateway (AI Gateway), and a small, geographically distributed GPU fleet running its own Rust inference engine (Infire) serving open-weight models (Workers AI) [4][6][9][13]. Its primary AI workload is **low-latency inference, agent orchestration, RAG retrieval, and ingress/egress control** — not frontier training. It is a **network/edge runtime** layer, not a silicon, packaging, HBM, or hyperscaler training-cluster play.

## Snapshot
- **Price:** $195.69 (2026-05-08 close) [1]
- **Market cap:** ~$68.9B [1]
- **52-week range:** $130.20 – $260.00 [17]
- **Forward P/E:** 172× (on FY2026 consensus EPS ~$1.19–1.20 non-GAAP) [2][18]
- **EV / NTM revenue:** ~28× (multiples.vc snapshot, early May 2026); my own calc using $68B EV / ~$3.0B NTM revenue ≈ ~22–23× — discrepancy likely a TTM-vs-NTM definition issue [19]
- **Consensus 12-month price target:** $231–$237 (~+18% implied) [18]
- **YTD total return:** +30.3% [17]
- **Short interest (% of float):** 2.41% (8.52M shares) [17]

## Moat — what it is physically made of
The moat is **not** Workers AI's GPU fleet, which is negligible versus hyperscaler builds. It is the bundle effect of three layers, each with different durability:

**1. Anycast network (most durable).** ~330 PoPs interconnected with >500 Tbps external capacity, peering relationships in 100+ countries, and the operational expertise to run BGP, DDoS mitigation, and TLS termination at internet scale [9]. Replicating this at parity is a 7–10 year, multi-billion-dollar capex effort with diminishing returns — Fastly (~150 PoPs) and Akamai (CDN-era footprint, but legacy) have both failed to displace it. The 1.1.1.1 resolver and being the front door for ~20% of internet domains compounds peering leverage.

**2. Workers runtime (medium durability).** V8 isolates give <5ms cold starts at ~2MB base memory overhead vs. ~30–50MB for containers — enabling 10–20× tenant density per node [13]. The control plane (Durable Objects with embedded SQLite, no separate KV layer; cross-process Storage Relay Service), R2's zero-egress pricing, and the cohesive AI bundle (Workers + AI Gateway + Vectorize + R2 + AutoRAG, all one API key away) is genuine software lock-in [7][8][16]. AWS Lambda@Edge and Vercel/Deno Deploy compete here but lack the storage primitives co-located with compute.

**3. Inference stack and developer surface (least durable).** Infire — Rust-based, JIT-compiles CUDA PTX kernels per model, paged KV cache, disaggregated prefill/decode, fine-grained CUDA graphs reducing CPU overhead 82%, ~7% faster than vLLM on H100 NVL [4][5]. This is engineering excellence but **not a moat**: vLLM, SGLang, TensorRT-LLM, and Modular's MAX all converge fast on similar techniques. Pay Per Crawl, AI Crawl Control, and the position-of-incumbency in front of publishers' content (~1B 402 responses/day already) is a more durable advantage — if AI labs need licensed training data, Cloudflare is structurally positioned to broker [14].

What it is **not**: it is not CUDA, not NVLink, not HBM, not CoWoS. There are no semiconductor IP, advanced-packaging contracts, or HBM supply allocations to defend. The "AI moat" is software + network position, not physics.

## AI buildout bottleneck map
- **Power generation & grid interconnect** — Indifferent / mildly negative. Cloudflare's PoPs are sub-megawatt urban colos. They cannot site 100kW+/rack racks of GB200 NVL72 in most of their footprint, which structurally caps their share of frontier inference. They benefit if inference shifts to smaller models at the edge; they are exposed if it stays in hyperscale clusters.
- **Advanced packaging (CoWoS-L) & HBM3e/HBM4 supply** — Indifferent. Cloudflare is a small NVIDIA Hopper customer (likely thousands, not hundreds of thousands of GPUs — they do not disclose, and their entire network capex is ~14–15% of $2.8B revenue, i.e. ~$420M/year for *all* infrastructure, vs. Meta's $70B+ AI capex) [2][20]. They have neither HBM allocation leverage nor CoWoS exposure.
- **Optical interconnect** — Beneficiary on transit/peering side; not exposed to 800G/1.6T training-cluster optics.
- **Liquid cooling at >100kW/rack** — Negative exposure. Cloudflare's edge sites are air-cooled. This is why their inference strategy is "Hopper + efficient software" not "Blackwell + NVL".
- **Kernel/compiler talent** — Beneficiary. Infire team, V8 internals, and the Workers runtime require scarce talent; they have it.
- **Training data licensing** — **Constraint owner, uniquely.** Pay Per Crawl puts Cloudflare in the toll-booth seat between publishers and AI crawlers. This is the most underappreciated structural position in the dossier [14].
- **The "agentic web"** — Beneficiary. As agents become the dominant client (Cloudflare cites internal AI usage up 600% in the quarter [3]), Cloudflare's identity (Access), bot management, browser rendering, and MCP-server infrastructure becomes the de-facto agent runtime layer. They are a Linux Foundation Agentic AI Foundation platinum member alongside AWS, Google, Microsoft [15].

## Competitive teardown
- **Hyperscalers (AWS/Azure/GCP).** AWS Wavelength + Local Zones extend EC2 to ~30 edge metros; this is the most credible threat to Cloudflare's *edge* story, but the developer experience is materially worse (provisioned capacity, IAM tax, no R2-style egress pricing) [22]. Azure Front Door + AKS at edge is enterprise-bundled but technically lagging. On the **bundle**: a customer already on AWS pays no S3→CloudFront egress, which is structurally cheaper than Cloudflare for native AWS workloads. Cloudflare wins on multi-cloud, anti-lock-in, and developer ergonomics; loses on within-AWS workloads.
- **Fastly (FSLY).** Real edge-compute competitor (Compute@Edge on WebAssembly), AI Accelerator does semantic LLM caching. Tighter developer focus, but ~10–15% of Cloudflare's PoP count and weaker enterprise security suite. Stock has run hard on AI narrative (cited +233% YTD by one source [10]); revenue base remains small.
- **Akamai (AKAM).** Inference Cloud with NVIDIA Blackwell deployment in 2026 [10]. Enterprise reliability advantage; loses on developer surface and modern runtime. The interesting wrinkle: Akamai is actually buying *more* GPUs than Cloudflare per dollar of revenue, which means if heavyweight edge inference becomes the workload, Akamai catches up faster than the developer narrative suggests.
- **Vercel / Deno Deploy / Modal / Replicate.** Compete on Workers runtime layer, not network. Modal in particular is the modern inference-platform competitor (better DX for ML engineers, real autoscaling). Cloudflare's advantage is being co-located with the customer's existing DNS/CDN/WAF.
- **NVIDIA + neoclouds (CoreWeave, Lambda, Crusoe).** Different layer — these are training/large-batch inference. Cloudflare is complementary, not competitive, except that NVIDIA's DGX Cloud and Nemo Microservices push them up the stack.

The competitive axis that matters: **does inference go to where the data is (edge) or does data go to where the inference is (hyperscaler)?** Frontier reasoning models with KV-cache-heavy serving favor centralized; agent orchestration, RAG retrieval, voice, real-time multimodal favor edge. The truth is split — and Cloudflare's bet is that the *orchestration layer* (agents calling tools, gateway routing to many models, caching) lives at the edge even if the frontier model itself runs in Hopper Lake, Oregon.

## Bull case — technical
For NET to outperform from here, several technical conditions need to hold:

1. **Agent traffic compounds.** Agent traffic (which Cloudflare claims grew 600% in one quarter [3]) becomes a meaningful and recurring share of internet requests, and that traffic *prefers* edge mediation for latency-sensitive tool calls. Base rate: developer-platform shifts (mobile, cloud) took 5–10 years to fully transition; agent platforms appear to be moving faster (Anthropic released MCP late 2024, dominant standard 18 months later [15]).
2. **The "model gateway" wins over single-vendor lock-in.** AI Gateway's value (caching, retries, observability, unified billing across 70+ models from 12+ providers) only matters in a multi-model world. If GPT-5/Claude/Gemini converge to a few labs with proprietary SDKs, AI Gateway is just a thin proxy. If the open-model ecosystem (Llama 4, Kimi K2.5, DeepSeek) thrives, AI Gateway is the de-facto routing layer.
3. **Pay Per Crawl gets adopted.** Cloudflare becomes the default toll booth between publishers and AI labs. Even capturing 1% of an emerging multi-billion-dollar data-licensing market — at near-zero marginal cost given existing infra — is material.
4. **Workers AI's Hopper-centric efficiency holds.** Infire's PTX-level optimization for Hopper means Cloudflare can serve open models at *competitive cost* without buying Blackwell. If the open-model frontier stays within Hopper-servable parameter counts (up to ~70B dense, ~300B sparse MoE) for 2–3 more years, Cloudflare's capital-light approach is the right one.
5. **The 20% layoff is not a demand signal but an operating-leverage one.** Cloudflare claims its own AI usage replaces headcount [2][3]; if this proves out, FCF margins expand toward 20% by 2027.

Financial connection: revenue compounds at 28%+ for two more years, FCF margin scales to mid-teens (from 13% Q1) [2], and the stock holds a 25–30× NTM EV/Revenue multiple — i.e., flat to up ~20%.

Base rate caveat: historical edge-vs-hyperscaler bets favor hyperscalers in the cloud era. The contra-base-rate is mobile, where edge (telco + Apple/Google) decisively won over cloud-only. Which analogy applies depends on whether agent latency budgets are tens of milliseconds (edge wins) or hundreds (hyperscaler is fine).

## Bear case — technical
The bear thesis is not "AI demand slows." It is:

1. **Frontier inference stays centralized and dominates revenue.** Reasoning models (o3-style chain-of-thought) generate 10–100× more tokens per query and benefit enormously from KV-cache reuse and large-batch serving — exactly what NVL72 in a hyperscaler region delivers and what air-cooled edge PoPs cannot. If 80% of AI inference dollars flow to long-context reasoning workloads, edge inference is a small market and Workers AI revenue stays a rounding error.
2. **Open-source inference engines commoditize Infire.** vLLM, SGLang, TensorRT-LLM, and increasingly hardware-vendor stacks (AMD ROCm, AWS Neuron) erase the 7% Infire advantage on a 6–12 month cadence [4]. Engineering excellence here is not a moat.
3. **Hyperscalers ship credible Workers-equivalents.** Lambda SnapStart, AWS App Runner, Azure Container Apps continue to close the developer-experience gap. If AWS launches a true V8-isolate runtime co-located with S3 + Bedrock + DynamoDB, Cloudflare's developer-platform thesis loses its anchor. The 28x EV/revenue multiple does not survive a credible Lambda Workers-killer.
4. **CDN core erodes.** CDN mindshare reportedly dropped from 22.2% to 17.5% in one year — cited [24]; this is a single source and I would want to verify in independent network-share data before treating as gospel, but if directionally true, it indicates the legacy revenue base is leaking.
5. **Pay Per Crawl fails as a market.** AI labs simply don't pay — they either negotiate direct deals with the biggest publishers (NYT, Reddit, Stack Overflow) or scrape via residential proxies that bypass Cloudflare. The 402-response volume Cloudflare cites is *blocked* traffic, not *paid* traffic. The conversion from "block" to "monetize" is unproven.
6. **The 20% layoff is a tell, not a triumph.** Companies cut headcount when growth no longer covers the cost base. The narrative "AI made us more efficient" reads better than "we hired ahead of demand" but the latter may be closer to truth. Watch DBNR — already down 2pp QoQ to 118% [19].

Financial connection: revenue decelerates to 20% by mid-2027, multiple compresses to 12–15× NTM (in line with AKAM/FSLY-adjusted-for-growth), stock to $130–150 (i.e., a 25–35% drawdown back to the 52-week low).

## Market view check
NET trades at ~28× NTM revenue (or ~22–23× on my own EV calc) and 172× forward P/E. Consensus PT implies +18%. The market is pricing in (a) continued 28%+ growth through 2027, (b) FCF margin scaling toward 20%, and (c) a structural seat at the "agentic web" table that justifies a multiple ~5× the broader software median. This is consistent with the technical bull case but allows zero room for the bear scenario where edge inference is a small market and CDN/security commoditizes. **The multiple is the bet.** The technical reality I read — Cloudflare has a real, defensible position in the agent-orchestration and content-toll layers, but does *not* have a defensible position in frontier inference economics — argues for a multiple closer to 18–22× rather than 28× until the agentic-web revenue narrative converts from "usage growth" to "ARR growth." Net: price feels modestly stretched, not egregiously mispriced. Short interest at 2.4% reflects the market's view that this is not a popular short despite the valuation.

## 90-day falsifiers
- **Q2 2026 print (early August):** DBNR — if it sustains 118%+ or rises, bull thesis intact. If it drops below 115%, bear case validated. Also watch the *gross* margin trajectory: if Workers AI scales as guided, gross margin should *not* drop, because Infire keeps utilization high — a >100bps GM compression would falsify the efficient-inference story.
- **AWS re:Inforce / AWS Summit New York (June/July 2026):** Specifically watch for an AWS announcement of a V8-isolate-style Lambda variant or an "AWS AI Gateway" routing layer. Either would compress NET's multiple.
- **Hyperscaler Q2 capex guidance (late July):** If aggregate hyperscaler capex 2026 is revised below the current ~$600B consensus by >10%, the AI-tailwind narrative compresses for everyone — NET is high-beta to this.
- **Pay Per Crawl monetization disclosure:** Cloudflare has not yet disclosed *paid* (vs. blocked) crawl volume. Any disclosure that converts the 1B/day 402 responses to a dollar figure — even a tiny one — would be a thesis-defining data point.
- **MLPerf Inference v5.0 (expected July 2026):** Independent submissions of Hopper-class vs. Blackwell-class on agentic workloads (TTFT-sensitive, low batch). If Hopper holds within 1.5× of Blackwell on cost-per-token for sub-70B models, Cloudflare's "don't need Blackwell at the edge" argument stands. If Blackwell crushes by >3×, the edge inference economic gap widens against NET.
- **Convertible note maturity (Aug 15, 2026):** The $1.125B 0% 2026 notes mature in 90 days [20]. Cash on hand covers ($4.16B). But watch for any refinancing — a new convert at a worse strike would dilute and signal balance-sheet stress.

## What I could not verify
- Cloudflare's actual GPU count and dollar-value of NVIDIA hardware on its books. They do not disclose; my inference is "thousands of Hoppers" based on $420M/year total network capex and the breadth of the 100+-city Workers AI rollout, but this is a guess.
- Whether the "17.5% CDN mindshare, down from 22.2%" data point [24] reflects real share loss or methodology noise (it is single-sourced from a comparison-site survey, not an authoritative measurement like Datanyze or Cisco's Visual Networking Index).
- Pay Per Crawl actual paid volume vs. blocked volume — undisclosed.
- The specific Anthropic relationship dollar amount; AI Gateway lists Anthropic as a provider [15] but I could not source a contracted revenue figure.
- The Infire vs. TensorRT-LLM comparison. Cloudflare benchmarks Infire vs. vLLM 0.10.0 only [4]; against NVIDIA's own TensorRT-LLM (the actual state-of-the-art on Hopper), the comparison is undisclosed and the 7% advantage may invert.
- Workers/Workers AI revenue contribution to total revenue. Cloudflare bundles developer platform revenue inside its application services line; standalone Workers ARR is not broken out.

## Sources
[1] https://capital.com/en-int/markets/shares/cloudflare-inc-share-price/market-cap — retrieved 2026-05-10 — price ($195.69 on May 8) and market cap (~$68.9B).
[2] https://www.cloudflare.com/press/press-releases/2026/cloudflare-announces-first-quarter-2026-financial-results/ — retrieved 2026-05-10 — Q1 2026 revenue $639.8M (+34% YoY), FCF $84.1M, 2026 guidance $2.805–2.813B, $1.19–1.20 non-GAAP EPS.
[3] https://www.fool.com/earnings/call-transcripts/2026/05/07/cloudflare-net-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Matthew Prince Q1 2026 call: 600% internal AI usage growth, 20% layoff, agentic AI commentary.
[4] https://blog.cloudflare.com/cloudflares-most-efficient-ai-inference-engine/ — retrieved 2026-05-10 — Infire engine technical detail: Rust, PTX kernels, paged KV cache, 82% CPU overhead reduction, 7% faster than vLLM 0.10.0 on H100 NVL.
[5] https://www.infoq.com/news/2026/05/cloudflare-llm-infrastructure/ — retrieved 2026-05-10 — InfoQ deep dive on Infire architecture and disaggregated prefill/decode.
[6] https://blog.cloudflare.com/workers-ai/ — retrieved 2026-05-10 — Workers AI serverless GPU inference overview.
[7] https://developers.cloudflare.com/ai-gateway/ — retrieved 2026-05-10 — AI Gateway provider list, unified billing for 70+ models.
[8] https://blog.cloudflare.com/introducing-autorag-on-cloudflare/ — retrieved 2026-05-10 — AutoRAG architecture: R2 + Vectorize + Workers AI integration.
[9] https://www.digitalapplied.com/blog/cloudflare-containers-dockerized-workloads-edge-330-cities — retrieved 2026-05-10 — 330+ city PoP count and 500 Tbps capacity.
[10] https://www.futuriom.com/articles/news/why-fastlys-stock-is-suddenly-on-fire/2026/04 — retrieved 2026-05-10 — Fastly/Akamai competitive landscape; FSLY YTD; Akamai Blackwell Inference Cloud.
[11] https://newsletter.semianalysis.com/p/nvidia-the-inference-kingdom-expands — retrieved 2026-05-10 — SemiAnalysis on B200 cost-per-token vs. H200 and inference economics shift.
[12] https://zylos.ai/research/2026-04-13-inference-economics-ai-agent-compute-markets — retrieved 2026-05-10 — Geographic distribution of inference workloads as latency-driven requirement.
[13] https://developers.cloudflare.com/workers/reference/security-model/ — retrieved 2026-05-10 — V8 isolate security model, <5ms cold start, 2MB overhead.
[14] https://blog.cloudflare.com/introducing-pay-per-crawl/ — retrieved 2026-05-10 — Pay Per Crawl mechanism; 402 status code, 1B/day blocked responses.
[15] https://blog.cloudflare.com/agents-week-in-review/ — retrieved 2026-05-10 — Cloudflare Agents Week 2026 product launches; MCP standardization.
[16] https://developers.cloudflare.com/r2/pricing/ — retrieved 2026-05-10 — R2 zero-egress pricing model.
[17] https://stockanalysis.com/stocks/net/statistics/ — retrieved 2026-05-10 — 52-week range $130.20–$260.00, YTD return +30.25%, short interest 2.41%.
[18] https://www.marketbeat.com/stocks/NYSE/NET/forecast/ — retrieved 2026-05-10 — Consensus PT $231.85–$236.72, 25–31 analysts Buy.
[19] https://www.investing.com/news/company-news/cloudflare-q1-2026-slides-34-revenue-growth-large-customer-base-surges-93CH-4671018 — retrieved 2026-05-10 — DBNR 118% (down 2pp QoQ); $100K+ customers 4,416; large customers 72% of revenue.
[20] https://www.stocktitan.net/sec-filings/NET/10-q-cloudflare-inc-quarterly-earnings-report-580158f0de78.html — retrieved 2026-05-10 — Balance sheet: $4.16B cash vs $3.29B convertibles; 2026 notes mature Aug 15, 2026.
[21] https://www.cnbc.com/2026/05/07/cloudflare-net-q1-2026-stock-earnings-layoffs.html — retrieved 2026-05-10 — 1,100 employee (~20%) layoff, $140–150M charges in Q2/Q3 2026.
[22] https://aws.amazon.com/wavelength/ — retrieved 2026-05-10 — AWS Wavelength edge ML inference offering.
[23] https://netrality.com/blog/high-density-colocation-ai-gpu-infrastructure/ — retrieved 2026-05-10 — Edge data center power constraints; standard colo 3–5 kW/rack vs. AI ~25–44 kW/rack.
[24] https://dataresearchtools.com/cdn-market-share-2026/ — retrieved 2026-05-10 — Cloudflare CDN mindshare 17.5% (down from 22.2%); single-source caveat applies.
[25] https://www.gurufocus.com/term/forward-pe-ratio/NET — retrieved 2026-05-10 — Forward P/E 172.19; software industry median ~18.6.