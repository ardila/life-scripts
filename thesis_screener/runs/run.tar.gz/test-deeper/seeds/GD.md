# GD — General Dynamics Corporation

## Where this sits in the AI stack
GD is not, in any literal sense, an AI infrastructure company. It is a four-segment defense and aerospace prime — Marine Systems (Electric Boat: Columbia and Virginia class nuclear submarines), Combat Systems (M1 Abrams, Stryker, ammunition), Aerospace (Gulfstream ultra-long-range business jets), and Technologies (Mission Systems + GDIT federal IT). Its only AI-stack exposure is at the **systems-integrator / federal-workload layer**: GDIT ($1.5B STRATCOM and $396M SOCOM IT modernization deals embed AI/ML into government data and migrate it onto JWCC hyperscaler clouds [6][7]), and Mission Systems integrates third-party silicon into C5ISR edge nodes. GD designs no silicon, owns no model weights, builds no training cluster, ships no kernel library. Treating GD as "AI infrastructure" is a misread; treating it as a defense-industrial / sovereign-platform play with secondary AI workflow exposure is correct.

## Snapshot
- **Price:** $346.53 (2026-05-08 close) [1]
- **Market cap:** $93.7B [1]
- **52-week range:** $267.39 – $369.70 [2]
- **Forward P/E:** ~21.0× on FY2026 EPS guidance midpoint $16.50 [5]
- **EV / NTM revenue:** ~1.7× (≈$95B EV / consensus ~$56B FY26 revenue — implied from 10% growth on FY25 base; *inference, not directly cited*)
- **Consensus 12-month price target:** ~$367–$374 (≈+6–8% from current); high $444 / low $327 [15][24]
- **YTD total return:** ~+1.6% (modest; stock spiked ~12% in early-May post-Q1) [1]
- **Short interest (% of float):** 1.06% — below peer median 3.10% [17]

## Moat — what it is physically made of
GD's moat is not software. It is **welded steel, certified workforce, and sovereign-only customer access**. Decomposed:

1. **Naval nuclear monopoly (most durable).** Only two yards in the United States can build nuclear-powered submarines: GD's Electric Boat (Groton, CT and Quonset Point, RI) and HII Newport News. They co-build Virginia class and split Columbia class. The constraint isn't IP — it's the closed loop of Naval Reactors S8G/S9G reactor compartment fabrication, NAVSEA-certified weld procedures (HY-80/HY-100 hull steel), Q-clearance workforce, and the multi-decade SUBSAFE quality regime. Replicating this would take a decade of capex and security clearance pipeline at minimum. The $15.4B Block VI Columbia modification and the FY24 $17.5B Virginia Block VI funded backlog [12] are 10+ year revenue locks. **Durability: very high (10y+).**

2. **Abrams as the sole U.S. MBT line.** Lima Army Tank Plant (Ohio), operated by GD Land Systems, is the only U.S. facility producing the M1A2 SEPv3/v4. Walking-out a competitor requires the U.S. Army to sole-source a different prime, which has not happened since the Abrams entered service in 1980. NATO trickle-down (Poland 366 M1A2s, Romania co-production [19], ~800 Abrams in Europe by 2027) extends the demand tail. **Durability: high (5–10y), but vulnerable to drone-era doctrine shifts.**

3. **Gulfstream certification stack.** The G700/G800 type certificates [23], the 50-year customer base, and the global service center network (≈30 sites) are real switching costs for HNW/corporate buyers. Bombardier's Global 7500/8000 has parity on speed/range, so this is a duopoly moat, not a monopoly. **Durability: medium (cyclical, sensitive to rates and HNW liquidity).**

4. **GDIT cleared workforce + contract vehicles.** ~30,000 cleared personnel, dozens of GWAC vehicles (Alliant 3, OASIS+, etc.) [from search context]. This is real but **not** unique — Leidos, Booz Allen, CACI, SAIC, Accenture Federal compete on near-identical terms. The "AI" content at GDIT is mostly *integrating* AWS/Azure/Oracle/Google JWCC stacks and Palantir/Anduril software into government data lakes [22]. GDIT is a workflow integrator, not an AI primitive owner. **Durability: medium-low — directly contestable.**

5. **What the moat is NOT.** No CUDA-equivalent. No CoWoS-L allocation. No HBM contracts. No TensorRT/Triton-equivalent toolchain. No frontier model. No silicon. The "4M CUDA developer" analog at GD is "30k cleared engineers," and that pool is shared with five competitors.

## AI buildout bottleneck map
GD is **largely indifferent** to the canonical AI-infra bottleneck list. It is exposed instead to a parallel set of *defense-industrial* bottlenecks that look thematically similar but are physically distinct.

| Bottleneck | GD position |
|---|---|
| Power generation / grid interconnect for hyperscaler datacenters | **Indifferent.** GD does not operate datacenters; GDIT consumes hyperscaler cloud as a customer pass-through. |
| CoWoS-L advanced packaging | **Indifferent.** Zero exposure. |
| HBM3e/HBM4 supply | **Indifferent.** Zero exposure. |
| Optical interconnect / 1.6T pluggables | **Indifferent.** No fabric IP. |
| Liquid cooling >100kW/rack | **Indifferent.** No datacenter buildout. |
| Kernel / compiler talent | **Indifferent.** Not the talent profile GD recruits. |
| **Submarine industrial base — large castings/forgings** | **Constraint owner / exposed.** Only three vendors meet Navy spec for hatches and pressure-hull castings [9][11]. Northrop Grumman flagged eight critical-capability gaps including "very large forgings and castings" [search]. Columbia-1 (District of Columbia) slipped from 2027 to 2028 delivery on turbine and bow component delays [9]. Virginia-class is running ~1.1–1.2 boats/year vs. 2.0 contracted and a 2.2/year AUKUS target [10]. |
| **Cleared / Q-cleared shipyard workforce** | **Constraint owner.** Generational retirement + COVID-era attrition. EB hired aggressively (Quonset expansion) but training-to-productive cycle is 3–5 years for nuclear-grade welding. |
| **155mm/120mm propellant and shell capacity** | **Beneficiary.** GD-OTS is one of three U.S. shell-body producers; Romania co-production [19] indicates EU buy-in. |
| **Federal cloud / AI workload migration** | **Beneficiary, secondary.** GDIT captures integration revenue but does not own the underlying compute. Margin-thin (Technologies segment Q1 op margin 9.4% vs. corp avg 11.4%). |

**Key takeaway:** The "Pentagon AI buildout" thesis routes around GD into Palantir (software), Anduril (autonomy), Microsoft/AWS/Google/Oracle (compute), and NVIDIA (silicon). GD captures only the integrator share and is structurally a price-taker on the underlying AI stack [16][20].

## Competitive teardown

**Marine Systems (Electric Boat).** Sole competitor: HII Newport News. Not a market-share fight — they're co-prime on Columbia, split Virginia. Threat is *industrial base failure* (HII's ~16-month delays propagate through joint modules), not displacement. No new entrant possible on a 10y horizon. GD has parity-or-better on Columbia execution; HII has the bow/aft component bottleneck. **GD better-positioned.**

**Combat Systems.** Abrams: no domestic challenger. Stryker: BAE's AMPV is adjacent but not substitute. Real threat is **doctrinal**, not competitive — if Ukraine's drone/loitering-munition lessons cause the Army to deprioritize heavy armor, the Lima line throughput compresses regardless of who runs it. Watch ATGM/FPV-drone kill ratios and the Army's FY27 budget allocation between heavy armor and uncrewed systems.

**Gulfstream.** Bombardier Global 7500/8000 has range/speed parity. Dassault Falcon 10X is a credible 2027 entrant. Embraer plays mid-cabin, not ULR. Demand is rate/wealth-cycle driven; Gulfstream's 160-jet 2026 delivery guide is roughly flat YoY [13][14] — supply-chain (Pratt 800, Rolls Pearl 700 engines) is the gating factor, not demand. **Duopoly with Bombardier on the high end.**

**Technologies / GDIT.** Direct competitors: Leidos (~$16B rev), Booz Allen (~$11B), CACI (~$8B), SAIC (~$7B), Accenture Federal, Maximus. GDIT is roughly the #1 federal IT integrator by revenue but has *no software differentiation*. The AI delta is being captured by:
- **Palantir** (Maven, AIP) — owns the decision-support / data-integration layer that GDIT *resells and integrates* [16].
- **Anduril** (Lattice, autonomy stack) — owns edge autonomy for UAS/USV/UGV.
- **Hyperscalers** (JWCC: AWS/Azure/GCP/Oracle, $9B IDIQ through June 2028 [22]) — own the underlying compute.

GDIT's strategic answer is "VIA" — Vision, Innovation and Acceleration — which is mostly upskilling 5,000 employees on AI and partnership integration [8]. This is rational but defensive. **GDIT is not where AI rents accrue.**

## Bull case — technical
For GD to materially outperform, four things need to hold:

1. **Submarine industrial base recovers in line with current trajectory.** Columbia-1 holds 2028 delivery, Virginia rate climbs from 1.2 → 1.6+ boats/year by FY27, AUKUS Pillar I funding accelerates ($175B+ buildout commitment realized as orders, not just authorizations) [10][12]. Backlog visibility extends to ~10 years on Marine Systems alone. This drives Marine Systems revenue from $13B/year toward $17–19B by FY28, at 7–8% margin.
2. **Abrams demand tail extends through European NATO + Australia.** Ukraine-driven inventory rebuild + Romania/Poland/Australia orders sustain Lima utilization above 100 tanks/year through FY30. M30 / SEPv4 export variant unlocks additional ~$20B opportunity.
3. **Gulfstream G700/G800 ramp completes without further FAA/supply hiccups.** 160 deliveries in 2026, 175+ in 2027, with the $22.3B aerospace backlog [13] amortizing into 14–15% margin steady state.
4. **GDIT captures the integrator share of federal AI rollouts** — even at low margin, $14–15B/year of Technologies revenue with steady mid-to-high single digit growth is an annuity.

**Base rate caveat:** Defense primes have a poor history of multiple expansion during AI thematic cycles — the analog is more like Lockheed/Raytheon during the 2010s software/cloud cycle, where defense capital was stranded relative to Big Tech multiples. GD trading at ~21× forward is already at a 5-year valuation peak; the bull case is largely about earnings compounding at 10–12%, not multiple re-rating.

## Bear case — technical
The technically literate bear short:

1. **Submarine schedule slip continues.** Columbia is now 1 year late and tracking another year at risk; District of Columbia has been delayed twice [9][18]. Virginia rate is a chronic miss. Each year of additional slip pushes revenue right and exposes EAC writedowns. The $131B backlog [4] is fixed-price exposed — large-casting and turbine cost inflation eats the margin.
2. **Doctrine shift kills heavy armor.** If FY27/28 budget reallocates heavy armor dollars to uncrewed systems (per Replicator-style initiatives), GD Land Systems revenue contracts. The Ukraine-validated lesson is that a $5,000 FPV drone can mission-kill a $10M Abrams; the Army's tank fleet decision is a real binary.
3. **GDIT loses share to Palantir/Anduril/hyperscaler-direct contracting.** Pentagon's emerging procurement preference (Software Acquisition Pathway, OTAs) routes around traditional integrators. Palantir's FY24 federal revenue grew ~30%+; GDIT grew ~5%. This trend, if it persists, structurally compresses Technologies segment growth from 4–5% toward 0–2%.
4. **Gulfstream cycle risk.** Business jet demand is rate- and wealth-effect-sensitive. If 2H26 sees a HNW liquidity correction (equity drawdown + private credit stress), order intake stalls; the $22B backlog ages and pricing power compresses. G700 had certification delays; G800 ramp could repeat.
5. **Multiple compression.** GD at 21× forward vs. its 10-year median ~17× implies ~20% downside on a re-rating alone if any of (1)–(4) materializes. Short interest at 1.06% [17] suggests the bear case is **not yet priced**.

## Market view check
Stock at $346.53, ~21× FY26 EPS, EV/EBITDA ~17×, ~5% dividend-adjusted FCF yield. Consensus PT $367–$374 implies ~6–8% upside, with the stock having already run +27% over 12 months [1] on the defense-spending thematic. The market is pricing GD as a high-quality defense compounder with backlog visibility and AUKUS optionality — which is largely correct. What the market is **not** doing is paying an AI-infra multiple; the stock trades roughly in line with HII (~17×), Lockheed (~17×), and slightly above Northrop (~19×), reflecting the marginal differentiator of Gulfstream and Marine Systems backlog growth. **The stock looks fairly priced, not mispriced.** If you want defense-industrial exposure with embedded AUKUS/submarine optionality, GD is the cleanest sleeve. If you want AI-infra exposure, this is the wrong ticker — own NVIDIA, Broadcom, TSMC, Vertiv, or the hyperscalers.

## 90-day falsifiers
Specific, observable events through ~August 2026:

- **Q2 2026 earnings (late July).** Watch (a) Marine Systems margin — degradation below 7% signals further EAC charges on Columbia/Virginia; (b) Gulfstream delivery rate — must hold ≥38 in Q2 to track 160 FY guide; (c) Technologies organic growth — sub-3% would confirm GDIT share loss to Palantir/Anduril.
- **Columbia-1 (District of Columbia) milestone disclosure.** Any commentary that 2028 delivery is "at risk" or any new component supplier failure (turbines, bow) would be a material negative.
- **DoD FY27 President's Budget rollout (typically late spring / early summer).** Heavy-armor (Abrams/Stryker) line-item movement; submarine procurement quantity (target: 2 Virginia-class boats funded); 155mm shell capacity expansion appropriations.
- **AUKUS Pillar I implementation order flow.** Look for definitive Australia/UK procurement contracts vs. continued authorization-only language.
- **Gulfstream order book at NBAA-BACE October show.** Net order intake vs. cancellations in 2H26 will validate or break the cycle thesis (just outside 90-day window — flag for next update).
- **GDIT contract awards vs. losses on JWCC task orders >$100M.** Direct read on integrator share.
- **Major shipyard labor action or Q-clearance pipeline disclosure.** EB and Quonset Point workforce attrition is the real bottleneck; any union-related disruption is high-impact.

## What I could not verify
- Exact CoWoS / HBM exposure (verified: zero — but stating "zero" with confidence requires a positive disclosure I did not find).
- Precise GDIT revenue split between AI/ML-tagged contracts vs. legacy IT services. GD reports Technologies segment in aggregate; AI vs. non-AI workload mix is not disclosed.
- Whether GDIT is a prime or sub on specific Palantir-Maven or Anduril-Lattice integrations. Public reporting names Palantir/Anduril; integrator role is often unpublished.
- Current Lima Army Tank Plant production rate (units/year). Public range historically 12–15/month but I could not confirm 2026 actuals.
- Marine Systems backlog by program (Columbia vs. Virginia vs. SSN(X)) — disclosed only in aggregate.
- Real Columbia-class fixed-price-vs-cost-plus mix on Block VI; this drives the EAC-risk magnitude on schedule slip.
- FY26 free cash flow conversion ratio precision; full-year guide stated but not segment-decomposed publicly.

## Sources
[1] https://www.trefis.com/stock/gd/articles/598253/general-dynamics-stock-on-fire-up-12-with-5-day-winning-streak/2026-05-05 — retrieved 2026-05-10 — May-2026 price ($346.53), market cap, recent 12% run.
[2] https://www.wallstreetzen.com/stocks/us/nyse/gd — retrieved 2026-05-10 — 52-week range $267.39–$369.70.
[3] https://investorrelations.gd.com/news/press-release-details/2026/General-Dynamics-Reports-First-Quarter-2026-Financial-Results/default.aspx — retrieved 2026-05-10 — Q1 2026 segment revenue/EPS.
[4] https://www.investing.com/news/company-news/general-dynamics-q1-2026-slides-backlog-surges-48-earnings-top-forecasts-93CH-4645796 — retrieved 2026-05-10 — backlog $131B (+48% YoY), TEC $188B.
[5] https://www.thecerbatgem.com/2026/04/30/general-dynamics-nysegd-issues-fy-2026-earnings-guidance.html — retrieved 2026-05-10 — FY2026 EPS guide $16.45–$16.55.
[6] https://investorrelations.gd.com/news/press-release-details/2025/GDIT-Awarded-1-5-Billion-Enterprise-IT-Modernization-Contract-to-Strengthen-U-S--Strategic-Commands-Operational-Readiness/default.aspx — retrieved 2026-05-10 — STRATCOM $1.5B AI/ML integration contract.
[7] https://virginiabusiness.com/gdit-396m-special-operations-command-contract/ — retrieved 2026-05-10 — SOCOM $396M contract.
[8] https://washingtonexec.com/2026/03/gdits-new-via-strategy-targets-ai-cyber-mission-tech-for-federal-government/ — retrieved 2026-05-10 — GDIT VIA strategy, AI upskilling.
[9] https://news.usni.org/2026/04/29/first-columbia-class-sub-tracking-to-2028-delivery-general-dynamics-says — retrieved 2026-05-10 — Columbia-1 delivery slip to 2028, turbine/bow delays.
[10] https://www.congress.gov/crs-product/RL32418 — retrieved 2026-05-10 — Virginia/AUKUS production rate, casting bottlenecks, 1.2 vs. 2.2 boats/year target.
[11] https://nationalsecurityjournal.org/the-navys-virginia-class-submarine-program-is-falling-apart/ — retrieved 2026-05-10 — chronic schedule and industrial base issues.
[12] https://www.govconwire.com/articles/gdeb-navy-columbia-submarine — retrieved 2026-05-10 — $15.4B Block VI Columbia contract modification.
[13] https://www.aerotime.aero/articles/gulfstream-deliveries-general-dynamics-q1-2026 — retrieved 2026-05-10 — Q1 2026 record 38 Gulfstream deliveries, $22.27B backlog.
[14] https://www.flightglobal.com/airframers/gulfstream-deliveries-to-remain-largely-flat-in-2026/166101.article — retrieved 2026-05-10 — 2026 deliveries flat (~160) on completion bottlenecks.
[15] https://stockanalysis.com/stocks/gd/forecast/ — retrieved 2026-05-10 — analyst price target ranges and consensus.
[16] https://www.defenseone.com/technology/2024/12/are-ai-defense-firms-about-eat-pentagon/401673/ — retrieved 2026-05-10 — Palantir/Anduril/Shield AI consortium and prime threat to integrators.
[17] https://www.benzinga.com/insights/short-sellers/26/02/50828075/what-does-the-market-think-about-general-dynamics-corp — retrieved 2026-05-10 — short interest 1.06% of float vs. peer avg 3.10%.
[18] https://insideinvestigator.org/electric-boat-navy/ — retrieved 2026-05-10 — Electric Boat schedule and budget overruns.
[19] https://www.armyrecognition.com/news/army-news/2025/romania-and-us-launch-partnership-on-abrams-and-155mm-ammunition-supply-chain-resilience — retrieved 2026-05-10 — Romania Abrams/155mm co-production agreement.
[20] https://fed-spend.com/blog/federal-ai-cybersecurity-contract-awards-2026 — retrieved 2026-05-10 — federal AI/cyber/zero-trust award concentration.
[21] https://news.usni.org/2025/10/24/first-columbia-class-sub-60-complete-next-year-pivotal-says-general-dynamics-ceo — retrieved 2026-05-10 — Columbia-1 60% complete as of Oct 2025.
[22] https://www.datacenterdynamics.com/en/news/oracle-and-google-join-microsoft-and-amazon-in-bidding-for-defense-departments-joint-warfighter-cloud-capability/ — retrieved 2026-05-10 — JWCC $9B IDIQ structure and hyperscaler awardees.
[23] https://en.wikipedia.org/wiki/Gulfstream_G650/G700/G800 — retrieved 2026-05-10 — G700/G800 certification timeline and specs.
[24] https://public.com/stocks/gd/forecast-price-target — retrieved 2026-05-10 — analyst rating distribution, $367 average target.