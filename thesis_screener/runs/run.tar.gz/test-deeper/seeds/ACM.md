# ACM — ACM Research, Inc. (NASDAQ: ACMR)

## Where this sits in the AI stack
ACM is a **wafer-fabrication-equipment (WFE) vendor** sitting two layers below the chip itself: it makes the wet-process tools (single-wafer megasonic cleaners, electrochemical-plating systems for Cu pillars/RDLs/TSVs, vertical furnaces, a new PECVD platform, KrF track) that fabs and OSATs use to build leading-edge logic, DRAM, NAND, and — increasingly — HBM stacks and 2.5D/3D advanced packages. It is therefore a **picks-and-shovels** play on the AI buildout, but the picks are sold almost entirely to *Chinese* fabs (YMTC, CXMT, SMIC, HLMC) plus a small but growing position at SK Hynix and an early Intel evaluation [1][3][8]. The relevant workload is the silicon underneath training/inference — specifically the HBM3/HBM3E/HBM4 stacks and the front-end memory and logic that feeds them.

## Snapshot
- **Price:** $59.85 (2026-05-08 close) [4]
- **Market cap:** $3.93B [4]
- **52-week range:** $19.76 – $71.65 [4]
- **Forward P/E:** 22.2× (trailing 45.5×) [4]
- **EV / NTM revenue:** ~2.7× (≈$3.0B EV after ~$924M net cash, on FY26 guide midpoint $1.125B; Finviz's trailing EV/Sales is 3.6×) [4][2]
- **Consensus 12-month price target:** $73.40 (implied +22.6%) [4]
- **YTD total return:** +51.7% [4]
- **Short interest (% of float):** 4.85% [4]

## Moat — what it is physically made of
ACM does not have a CUDA-class moat. What it does have decomposes as follows, each with very different durability:

**1. Patented megasonic IP — moderate durability.** SAPS (Space Alternated Phase Shift) tilts a transducer over a rotating wafer to deliver megasonic energy uniformly even on warped substrates [5]. TEBO (Timely Energized Bubble Oscillation) pulses a 2 MHz signal to generate ~40% smaller cavitation bubbles that don't violently collapse — this is the differentiator on patterned 1Xnm wafers, MEMS, 3D NAND, and via aspect ratios up to 90:1, where conventional megasonics destroy features [5][12]. TEBO is U.S.-patented with ~20 years of remaining protection [12]. ACM holds ~285 patents across the U.S., China, Japan, Korea, Singapore, Taiwan; founder Dr. David Wang holds ~100+ personally and invented stress-free copper polishing [12]. **However** — SemiAnalysis's 2022 teardown noted SAPS is *not* used in leading-edge FinFET at Samsung/Intel/TSMC because of pattern collapse, and TEBO has won at SK Hynix and YMTC for NAND, not at the leading-edge logic frontier [11]. So the IP is real but bounded to memory / lagging-edge logic / 3D structures today.

**2. Customer-process co-development lock-in — durable but narrow.** Wet cleaning recipes are co-tuned with the fab process. Once a tool is qualified on a recipe (12–24 month qual cycle), switching costs are high because the fab has tied yield to that process. ACM has ~40% share of cleaning at YMTC and is the entrenched wet supplier at SMIC, HLMC, CXMT [3][13]. SK Hynix has been a customer since 2011 and was >10% of revenue 2016–2019 [13]. This is the *real* moat on existing installed base — but it is enforced by contract and process fingerprint, not physics.

**3. Domestic-supplier preference under Chinese localization policy — durable while the policy exists.** China's WFE localization rate moved from 23% (mid-2024) to ~35% (mid-2025) and may have crossed 50% by year-end 2025; the policy target is 70% by 2027 [10]. ACM Shanghai is a designated beneficiary of this and is subsidized (raised $630M in a STAR Market private placement in 2025) [9]. This is *not* a technological moat — it is a regulatory one — but it is currently the strongest force pulling revenue to ACM.

**4. Tahoe hybrid SPM architecture — narrow but defensible.** Ultra C Tahoe combines a 25-slot wet bench with nine single-wafer chambers in one tool, cutting sulfuric-acid consumption ~75% (~$500K/yr per tool) at >200 wph [14]. Lam has historically been weak in SPM; this is one of the few segments where ACM competes head-to-head with only SCREEN [11].

**5. Ultra ECP ap (and the new ap-p panel-level horizontal plater) — emerging, not yet a moat.** ECP for Cu pillar, RDL, TSV fill, and now panel-level fan-out (>300 µm pillar height, four-sided sealed dry-contact chuck) is up >3× YoY in Q1 2026 and is the actual growth driver [2][7]. This puts ACM into direct contact with **Lam Research's Sabre 3D** in advanced packaging [11]. The customer wins are real but the install base is too young to call it a moat.

What it is *not*: ACM does not own a process-IP fortress like ASML's EUV, a software-ecosystem moat like NVIDIA, or a manufacturing-relationship moat like TSMC's CoWoS allocation. The "moat" is patents + qualified-supplier inertia + Chinese-state preference. Stack-rank durability: localization policy > qualified-supplier inertia > TEBO patent > Tahoe SPM architecture > ECP (still being built).

## AI buildout bottleneck map
The 24-month gating constraints on AI compute and where ACM sits:

- **Power generation / grid interconnect** — turbine backlogs of 5–7 quarters, gas-turbine-bound. **Indifferent.**
- **CoWoS-L advanced packaging** — TSMC ramping from ~35K wpm (late 2024) to ~130K wpm (end 2026); sold out through 2026; NVIDIA is ~60% of allocation [15]. **Indirect beneficiary** — every CoWoS substrate is preceded by ECP for RDL/Cu pillar and dozens of cleaning steps. ACM's ECP ap-p targets this exactly, but TSMC's wet-process suppliers are SCREEN/TEL/Lam, not ACM. ACM's CoWoS-adjacent revenue is at OSATs and Chinese packaging houses, not Hsinchu.
- **HBM yield (3/3E/4)** — **direct beneficiary.** SK Hynix/Samsung/Micron HBM lines are sold out through 2026 [16]. Each 12-Hi or 16-Hi stack requires ultra-clean TSV bottoms and bond-pad surfaces (90:1 aspect ratios are ACM's TEBO sweet spot) [5]. ACM secured an >RMB 200M HBM packaging order from a leading global memory maker for 1H26 delivery, and is targeting HBM4 16-layer / 2,048 TSV cleaning compatibility in 2026 [6]. CXMT's HBM3 ramp (~60K wpm = 20% of capacity in 2026) is a near-pure ACM beneficiary because incumbents face Chinese export-control friction [17].
- **Optical interconnect / silicon photonics** — **indifferent.**
- **Liquid cooling >100 kW/rack** — **indifferent.**
- **Kernel/compiler talent** — **indifferent.**
- **Chinese WFE localization** — **constraint owner / beneficiary.** ACM is one of four named winners (with Naura, AMEC, Piotech) of China's 70%-by-2027 push [10][3].
- **U.S. export controls** — **exposed.** ACM Shanghai and its Korea sub were added to the BIS Entity List Dec 2024; the parent (ACMR Fremont) was not [8]. This restricts U.S.-origin component flow *into* ACM Shanghai but does not yet ban ACM tools from sale into China.

## Competitive teardown
Single-wafer cleaning is a ~$2.2B/yr global market, with **SCREEN ~40–45% share, TEL #2, Lam meaningful via PUMA/DV-Prime; top 3 = 82%+** [11][18][19]. ACM is a **regional specialist with ~25–30% Chinese wet-clean share and rising**, ~40% at YMTC [3][13].

- **vs. SCREEN Holdings (Japan)** — global incumbent. SCREEN owns the leading-edge FinFET cleaning recipes at TSMC/Samsung/Intel that ACM has *not* penetrated [11]. ACM only competes head-to-head in Chinese fabs and in SPM (where Lam is weak). For ACM to take share at TSMC N2/A14 cleaning, it would need a SAPS/TEBO recipe qualified on a leading-edge logic node — not visible in any 2026 disclosure. **Parity gap remains real on bleeding-edge logic.**
- **vs. Tokyo Electron (Japan)** — similar profile to SCREEN; entrenched at Samsung memory and at logic. Same gap.
- **vs. Lam Research (US)** — Lam's exposure is broader (etch/dep dominant) but its **Sabre 3D ECP** is the direct comp to Ultra ECP ap. Lam has lost share to ACM in Chinese ECP because of localization preference and price; whether Lam loses share at SK Hynix HBM is the live question. Lam's strip/clean lines (PUMA/DV-Prime) underperform SCREEN globally [11].
- **vs. Naura (China)** — *most underrated competitor*. Naura is the broadest Chinese WFE platform (etch/dep/clean/anneal) with the highest R&D intensity and explicit policy backing [10]. If Naura's cleaning matures to TEBO-equivalent particle-removal-efficiency on 3D NAND, ACM's domestic moat narrows fastest from this direction.
- **vs. AMAT (US)** — minor in cleaning specifically.

The honest read: ACM's competitive position is **"specialist with structural Chinese tailwind, niche IP advantage on 3D structures, no leading-edge FinFET parity, vulnerable to a domestic peer (Naura) on its home turf, and a credible second-source threat to Lam in ECP."**

## Bull case — technical
Stock works if these technical conditions hold over 18–36 months: **(a)** HBM4/HBM4E ramps proceed on schedule at SK Hynix, Samsung, Micron and CXMT joins meaningfully — each 16-Hi stack needs more cleaning passes than 12-Hi, and TEBO's high-aspect-ratio cleaning is non-trivially substitutable [5][6][16]; **(b)** China hits its 70%-localization-by-2027 target with ACM holding >30% of *the cleaning slice* of the localized basket [10]; **(c)** the Ultra ECP ap-p panel-level platform wins at one of the major OSAT panel-level fan-out lines, validating the new product family and pulling 2027 revenue to the top of the >$1.5B trajectory implied by management's three-year guidance; **(d)** Tahoe and the new PECVD-SiCN system convert from evaluations to production POs [2][7]; **(e)** the Intel 14A wet-etch evaluation either qualifies (massive validation) or fails politely without becoming a sanctions trigger [20].

**Base rate caveat on platform displacement:** historically, regional specialists have rarely overturned global WFE incumbents — SCREEN/TEL/Lam/AMAT have held >80% of WFE for two decades through multiple node transitions. The only clean precedents for displacement are *enforced* by geopolitics (e.g., AMAT losing China etch share to AMEC after 2019). ACM's bull case relies on exactly that mechanism continuing.

If conditions hold, FY27 revenue tracks $1.4–1.6B; gross margin re-expands toward 47–48% as cleaning mix normalizes back to ~65% (mgmt explicit) [2]; non-GAAP EPS ~$2.40–2.80; at 22× forward = $55–60. **The stock is fair-to-cheap on financials only if you also believe the optionality on Tahoe/PECVD/Intel/HBM4 is largely unpriced.**

## Bear case — technical
Stock breaks if: **(a)** Naura ships a TEBO-class megasonic with comparable PRE on 3D NAND in 2026–27 — Chinese fabs would dual-source for resilience and ACM's installed-base lock-in starts to fray; **(b)** the U.S. moves ACM Shanghai from Entity List to a Treasury SDN-style designation (or BIS upgrades to a foreign-direct-product rule that captures ACM tools), cutting U.S. and allied component supply and freezing Intel/SK Hynix qualification — the entity-list precedent on Dec 2024 makes this 18-month tail risk non-trivial [8][20]; **(c)** Chinese WFE buying decelerates after the digestion phase implied by SEMI's "China contraction in 2025" call [19] — note ACMR's reaffirmed 2026 guide ($1.08–1.175B) is in scope here; **(d)** product-mix-driven gross margin compression (Q1 cleaning was *down* 5.5% YoY while ECP/furnace was up 205% [2]) persists, signaling that the new growth engines are structurally lower-margin and management's 42–48% range slides toward the low end; **(e)** SK Hynix HBM4 cleaning standardizes on SCREEN/TEL only, eliminating the ACM-Korea optionality that the bull case implicitly prices.

The cleanest short-seller framing: **"This is a Chinese state-supported regional consolidator, mispriced as an AI infrastructure compounder. The 2025–2026 revenue surge reflects China's one-time stockpiling cycle ahead of tighter export controls; once that pulls forward, normalized growth is 10–12%, gross margins drift to low-40s on mix, and the 22× forward P/E becomes a 14× reset."** Worth taking seriously.

## Market view check
At $59.85, ACMR trades at ~22× forward EPS and ~2.7× EV/NTM sales on management's reaffirmed $1.125B midpoint [2][4] — *cheaper* than Lam (~25× fwd) or AMAT (~22× fwd) on multiples, *despite* faster growth (25% vs. ~10% for Lam/AMAT). That discount is the China-risk stamp: the market is pricing ~30–40% probability of a discrete export-control or geopolitical event that impairs the franchise within 24 months. If you believe that probability is closer to 15–20% (i.e., U.S. tightens controls but ACM Shanghai continues serving Chinese customers as it has post-Entity-List), the stock is materially mispriced upward; if you believe it's >50% (SDN-style designation comes), it's mispriced downward. The technical reality I described — strong domestic moat, weak global moat, real but narrow IP, structural mix pressure on margins — is **broadly consistent** with the discount but does not justify either extreme.

## 90-day falsifiers
- **Q2 2026 earnings (early Aug)**: Does cleaning grow YoY again, or is the Q1 decline a trend? Does gross margin recover above 47%? Is shipment-revenue gap (which widened in Q1) closing or widening?
- **TSMC and SEMI Q2 China-WFE prints** — if China shipments fall >15% sequentially, the localization tailwind narrative weakens [19].
- **Intel 14A wet-etch evaluation outcome / leak** — any Reuters/Tom's Hardware update that ACM was qualified or de-qualified at Hillsboro is binary [20].
- **CXMT HBM3 mass production confirmation** — if CXMT misses its 60K wpm target for 2026, the highest-growth tier of ACM's HBM exposure delays [17].
- **BIS export-control rule-making (summer 2026)** — any FDPR expansion or new entity additions targeting ACM-served customers (CXMT, YMTC) feeds directly through.
- **ACM Shanghai disclosure of HBM4 16-layer / 2,048 TSV cleaner shipment** — promised "by 2026" [6]; ship vs. slip is a clean read.
- **Naura cleaning PRE benchmark disclosure** at SEMICON China (typically March, but watch H2 conference cadence) — if Naura shows TEBO-equivalent particle removal on 3D NAND, the 90-day shock is large.

## What I could not verify
- ACM's actual share of cleaning *spend* (vs. tools-shipped) at SK Hynix today — sources confirm SK Hynix is a customer since 2011 and was >10% of revenue 2016–2019 but I could not source a current SK Hynix wallet share.
- Whether ACM is qualified on any of SK Hynix's HBM4 lines specifically (sources confirm SK Hynix HBM4 mass-production prep, not ACM's role inside it).
- The status of the Intel 14A wet-etch evaluation past December 2025 (the most recent public reporting).
- Specific CoWoS-adjacent ECP wallet at TSMC OSAT partners — I cannot rule out that ACM ECP ap is in any CoWoS-L supply chain, but I also cannot confirm it.
- Naura's current cleaning-tool PRE benchmarks vs. ACM TEBO — public benchmarks are sparse.
- Precise FY26 EPS consensus — Finviz shows fwd P/E 22.2× implying ~$2.70 EPS, but I did not find a published consensus number to confirm directly.
- The fraction of ACM's 285 patents that are *core* SAPS/TEBO IP vs. peripheral — a patent count is a weak proxy for moat depth.
- Whether the December 2024 Entity List addition of ACM Shanghai has materially affected component lead times in 2026 (management says "minimal" but no third-party verification).

## Sources
[1] https://www.acmr.com/ — retrieved 2026-05-10 — ACM corporate site; product taxonomy (cleaning, ECP, furnace, track, PECVD).
[2] https://www.globenewswire.com/news-release/2026/05/07/3289717/0/en/ACM-Research-Reports-First-Quarter-2026-Results.html — retrieved 2026-05-10 — Q1 2026 revenue $231.3M, GM 46.5%, product-mix breakdown, reaffirmed $1.08–1.175B FY26 guide.
[3] https://newsletter.semianalysis.com/p/acm-research-chinas-most-successful — retrieved 2026-05-10 — SemiAnalysis 2022 deep dive: SAPS vs. Lam/SCREEN, Sabre 3D comp for ECP, SK Hynix and Intel customer wins, "domestic supplier" pricing dynamic.
[4] https://finviz.com/quote.ashx?t=ACMR — retrieved 2026-05-10 — Price $59.85 (5/8/26), market cap $3.93B, 52w range, P/E 45.5×, fwd P/E 22.2×, EV/Sales 3.6×, YTD +51.7%, short 4.85%, PT $73.40.
[5] https://www.acmr.com/tools-and-processes/wet-processing/tebo-technology-systems/ — retrieved 2026-05-10 — TEBO technical: pulsed 2 MHz, ~40% smaller bubbles, 90:1 aspect-ratio TSV, 1Xnm patterned-wafer PRE.
[6] https://www.trendforce.com/news/2025/12/10/news-chinas-acm-reportedly-lands-memory-giant-orders-eyes-hbm4-compatible-cleaning-systems-by-2026/ — retrieved 2026-05-10 — RMB 200M+ HBM order from leading memory maker; HBM4 16-layer / 2,048 TSV cleaning roadmap for 2026.
[7] https://ir.acmr.com/news-releases/news-release-details/acm-research-delivers-first-horizontal-panel-electroplating-tool — retrieved 2026-05-10 — First Ultra ECP ap-p horizontal panel-plating tool; >300 µm pillar capability for fan-out PLP.
[8] https://www.globenewswire.com/news-release/2024/12/11/2995751/0/en/ACM-Research-Comments-on-Updated-U-S-Export-Restrictions.html — retrieved 2026-05-10 — ACM Shanghai + Korea sub on Entity List Dec 2024; ACMR parent not listed; management's "manageable" framing.
[9] https://www.stocktitan.net/news/ACMR/acm-research-s-operating-subsidiary-acm-research-shanghai-announces-fl91ztw18eyc.html — retrieved 2026-05-10 — ACM Shanghai $630M STAR Market private placement; ACMR ownership reduced to 74.5%.
[10] https://www.trendforce.com/news/2026/02/20/news-china-reportedly-ramps-up-chip-tool-push-sets-70-target-by-2027-smee-naura-at-forefront/ — retrieved 2026-05-10 — China WFE localization 23%→35%→~50%; 70%-by-2027 target; Naura/SMEE leadership.
[11] https://semianalysis.com/2024/02/09/hybrid-bonding-process-flow-advanced/ + SemiAnalysis ACMR piece — retrieved 2026-05-10 — Single-wafer clean market structure: SCREEN dominant, top 3 = 82%+; Lam weak in SPM; SAPS not used in leading FinFET.
[12] https://www.stocktitan.net/news/ACMR/acm-research-receives-u-s-patent-for-tebo-megasonic-cleaning-u6bz0n794pnv.html — retrieved 2026-05-10 — TEBO US patent ~20-year horizon; ACM ~285 patents; founder Wang's 100+ personal patents and SFP origin.
[13] https://www.kerrisdalecap.com/investments/acm-research-acmr/ (and 2025-11 update) — retrieved 2026-05-10 — Kerrisdale long thesis: ~40% YMTC cleaning share; SK Hynix history; SMIC/HLMC/CXMT customer roster.
[14] https://www.acmr.com/tools-and-processes/wet-processing/tahoe-cleaning-system/ — retrieved 2026-05-10 — Ultra C Tahoe hybrid bench/single-wafer SPM; 75% chemical reduction; ~$500K/yr sulfuric-acid savings; >200 wph, <6 particles at 26nm.
[15] https://markets.financialcontent.com/wral/article/tokenring-2025-12-26-tsmc-boosts-cowos-capacity-as-nvidia-dominates-advanced-packaging-orders-through-2027 — retrieved 2026-05-10 — TSMC CoWoS 35K→130K wpm by end-2026; sold out through 2026; NVIDIA ~60% allocation share.
[16] https://news.skhynix.com/sk-hynix-completes-worlds-first-hbm4-development-and-readies-mass-production/ — retrieved 2026-05-10 — SK Hynix HBM4 mass-production readiness; HBM3E dominant share; HBM4 ramp 2026.
[17] https://www.techpowerup.com/346207/cxmt-reportedly-plans-to-dedicate-20-of-mass-production-capacity-to-hbm3-line-in-2026 — retrieved 2026-05-10 — CXMT 60K wpm HBM3 in 2026 (~20% of 300K wpm capacity).
[18] https://www.intelmarketresearch.com/single-wafer-clean-machine-market-11801 — retrieved 2026-05-10 — Single-wafer cleaning market $2.17B (2024) → $2.90B (2032); top-3 concentration 82%+.
[19] https://www.semi.org/en/semi-press-release/global-total-semiconductor-equipment-sales-forecast-to-reach-a-record-of-dollar-139-billion-in-2026-semi-reports — retrieved 2026-05-10 — SEMI WFE forecast: $139B in 2026, China #1 market with 2025 contraction.
[20] https://www.tomshardware.com/tech-industry/semiconductors/intel-tests-chipmaking-tools-from-sanctioned-china-focused-tool-maker-report-claims-move-could-raise-political-and-national-security-concerns-firm-was-backed-by-ceo-lip-bu-tans-investment-firm — retrieved 2026-05-10 — Intel 14A wet-etch tool evaluation; Lip-Bu Tan / Walden ACMR investment connection; political risk framing.