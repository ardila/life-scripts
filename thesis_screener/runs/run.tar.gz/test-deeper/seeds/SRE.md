I have enough material. Writing the dossier now.

# SRE — Sempra

## Where this sits in the AI stack
Sempra is a regulated electric and gas utility holding company. It is **not** silicon, networking, or software — it sits at the **power/grid interconnect** layer of the AI stack, the layer that determines whether a GPU cluster can be plugged in at all. The relevant operating asset is **Oncor**, an ~80%-owned regulated transmission-and-distribution-only utility (TDU) covering ~13M Texans across Dallas-Fort Worth, West Texas, and the Permian Basin within ERCOT [1][8]. Oncor owns no generation; it owns wires, substations, and transformers, and recovers cost-of-service revenue under PUCT-approved tariffs. The remaining ~25% of capex sits in SDG&E and SoCalGas (regulated California utilities). Sempra Infrastructure (LNG, Mexico) has been carved down to a 25% retained stake and is in the process of being separated from the AI thesis [11].

## Snapshot
- **Price:** $91.57 (2026-05-09 close) [1]
- **Market cap:** $61.3B (653.3M shares out) [1]
- **52-week range:** $72.56 – $101.04 [12]
- **Forward P/E:** ~17.7× (on FY26 consensus EPS $5.16, midpoint of $4.87–$5.37 guide) [3][13]
- **EV / NTM revenue:** n/a — utilities are valued on regulated rate base / P/E, not revenue multiples; EV/EBITDA ~13× is the relevant comp
- **Consensus 12-month price target:** $102.67 (implied +12%; Moderate Buy, 2 Strong Buy / 8 Buy / 4 Hold) [13]
- **YTD total return:** approximately -2% price (~+0% incl. dividend) [12]
- **Short interest (% of float):** ~1.1–2.1% — low vs. utility peer average of 3.6% [14]
- **Dividend yield:** ~2.9% ($2.63 annualized) [13]
- **2030 EPS outlook:** $6.70–$7.50; 7–9% long-term EPS CAGR target [15]

## Moat — what it is physically made of
Sempra's moat is **not technological**; it is **regulatory + geographic incumbency**. Decompose it:

**1. State-granted geographic monopoly (durable, decades-long).** Oncor is the only TDU permitted to build transmission and distribution wires in its certificated service territory. ERCOT does not have FERC jurisdiction (Texas is an "energy-only" intrastate market), and PUCT does not issue competing transmission CCNs into Oncor's footprint. This is the same regulatory contract that's protected investor-owned utilities for 100+ years.

**2. The "pays-for-itself" capital recovery mechanism.** Under PUCT-approved cost-of-service ratemaking, Oncor earns a regulated return on rate base. The April 2026 rate order set authorized ROE at **9.75% on a 43.5% equity / 56.5% debt structure** and granted a $560M (8.7%) revenue increase, with retroactive surcharge to January 1, 2026 [16]. Crucially, transmission costs in ERCOT are recovered through a **postage-stamp Transmission Cost of Service (TCOS) charge socialized across all retail load** — meaning if a specific hyperscaler cancels but aggregate load grows, the transmission still earns. Management's claim that the plan is "largely indifferent" to whether any single data center materializes [9] is partly true at the transmission layer; less true at the distribution layer where customer-specific tap costs apply. SB6 (signed June 2025) tightens this by imposing financial commitments on large loads >75 MW [17] — a *positive* for Oncor's risk, since the customer carries more of the build-cost speculation.

**3. Physical asset incumbency (the most underappreciated piece).** Oncor owns existing rights-of-way and substations along the I-35 corridor and into the Permian. New transmission build is rights-of-way-limited, not steel-limited; greenfield entrants would face years of routing/condemnation. Oncor was already selected to build a "significant portion" of the **first 765-kV lines ever in Texas** under the $15-17B Permian Basin Reliability Plan approved by PUCT in October 2024, with the 765-kV import-path designation finalized April 2025 [18][19]. 765 kV is a step up from the 345 kV that's been standard in Texas — it carries ~4× the power per circuit at lower line losses, and the *engineering know-how* to design, energize, and protect 765 kV is held by a small number of US utility engineering teams (AEP in PJM, now Oncor/LCRA in ERCOT).

**4. Supply-chain priority access (real but eroding).** Large power transformers and switchgear are now the gating constraint on grid expansion: lead times have moved from 30–60 weeks pre-pandemic to **128 weeks – 5 years**, with prices up 60–80% since 2020 [20][21]. Incumbent utilities like Oncor have decades-long frame contracts with Hitachi Energy, Hyundai Electric, Siemens Energy, GE Prolec etc. that give them slot priority over new market entrants. This is genuine — but not infinite; if a hyperscaler signs a direct long-term frame contract for transformers (Meta has reportedly done this), they bypass utility prioritization.

**What this moat is NOT:** It's not a "tech moat" in any CUDA-equivalent sense. There is no software switching cost, no developer ecosystem, no kernel library. The durability is **legal + topological** — the rights to build wires in specific geography under cost-of-service ratemaking.

## AI buildout bottleneck map
The 24-month gating constraints on US AI buildout, and where SRE sits on each:

- **Grid interconnect / large-load queue management.** ERCOT's large-load queue is ~226 GW, ~77% data centers, vs. a 2023 record peak of 85.5 GW [22][23]. Oncor's share alone is 271 GW of data-center requests across 416 active LC&I requests as of Q1 2026 [9][24]. Oncor submitted **122 GW of large-load forecast to ERCOT's 2026 RTP** vs. its current 31 GW peak load — a 4× expansion [25]. **SRE position: prime beneficiary**, since interconnection requires Oncor wires. SB6 means the *customer* posts financial commitments, not Oncor.
- **Large power transformers and HV switchgear.** Lead times 2–5 years; ~30% supply deficit projected for 2025–2026 [21][26]. **SRE position: constraint-exposed but supply-prioritized** via incumbent OEM relationships; Oncor will still build slower than queue demand wants, which makes the queue extend further out (good for visibility, not for near-term revenue).
- **Gas turbine availability for new generation.** GE Vernova backlog hit **100 GW in Q1 2026, sold out through 2029 with only ~10 GW remaining in 2029–2030 combined** [27][28]. **SRE position: indifferent at the holding-company level** — Oncor is wires-only. This bottleneck instead benefits Vistra, Constellation, NRG (IPP generation in ERCOT). It is *also a customer-side risk* for Sempra: if data centers cannot procure firm power, they don't sign the interconnect agreement, the queue is paper, and 271 GW shrinks to whatever can be physically generated.
- **Texas water and cooling siting.** Less constraining than power for Texas data centers (most use closed-loop / dry-cooler designs at >100 kW/rack), but Permian water is genuinely scarce. **Indifferent.**
- **Permitting / FERC interconnect timing.** ERCOT's intrastate status is an *advantage* vs. PJM/MISO/CAISO where FERC controls queues. DOE's October 2025 directive to FERC to accelerate large-load interconnection [29] and FERC's December 2025 PJM co-location order [30] do not bind ERCOT. Texas SB6 produces a faster — and more utility-friendly — regulatory glide path than the FERC system. **SRE position: beneficiary of regulatory regime arbitrage.**
- **Wildfire liability (California).** SDG&E sits inside AB 1054's $21B insurance pool (4.3% share) [31]. Tail risk exists but is structurally smaller than PCG/EIX given San Diego's lower fuel-load geography. **SRE position: exposed but smallest of the three IOUs.**

## Competitive teardown
The relevant axis is **"who captures the AI dollar inside ERCOT,"** because that is where SRE's incremental growth lives. The competitive frame here is *not* SRE vs. another TDU — there is no competing TDU in Oncor's footprint. It is **regulated wires (Sempra/Oncor, AEP Texas) vs. competitive generation (Vistra, Constellation, NRG, Talen, NextEra)** for share of AI capex dollars and investor mindshare.

| Axis | SRE/Oncor | Vistra (VST) | Constellation (CEG) | NextEra (NEE) | AEP Texas |
|---|---|---|---|---|---|
| What they sell to hyperscalers | T&D capacity (regulated) | Firm dispatchable MWh (merchant) | Nuclear baseload MWh (merchant) | Renewables + storage PPA | T&D capacity (regulated) |
| Upside ceiling | Capped at allowed ROE × rate base | Uncapped — merchant pricing | Uncapped — but pricing already inked | PPA-linked | Capped at allowed ROE |
| Downside floor | High — regulatory contract | Low — ERCOT price collapse + curtailment | Medium — long-dated PPAs | Medium | High |
| Recent deal evidence | $560M rate case granted Apr 2026; selected for 765-kV [16][18] | 2,609 MW Meta nuclear PPA; 1,200 MW Comanche Peak PPA [32] | $16.4B Calpine acquisition closed Jan 2026, 60 GW combined fleet [33] | Duane Arnold restart with Alphabet [33] | Permian build participation |
| Where they already lose the axis | Cannot capture merchant upside above ROE | Carries hedging/basis risk; no monopoly | Co-location structure under FERC scrutiny | Generation-side, exposed to PPA price compression | Smaller footprint than Oncor |

**Honest reading:** On the *technical* "AI-power" axis where prices and margins re-rate dramatically with scarcity, **Vistra and Constellation have structurally higher beta**. SRE captures the same demand, but the regulated structure caps the upside at allowed ROE × rate base growth — i.e., 11% rate base CAGR translating to a 7–9% EPS CAGR [15]. The trade-off is downside protection: if AI capex pulls back, Vistra's merchant margin compresses far faster than Oncor's TCOS.

There is **no credible scenario in which a competitor displaces Oncor inside its certificated territory** — the moat is not under attack technologically. It is under attack only **financially**: at current multiples, the question is whether you would rather own capped 8% growth at 17.7× forward, or uncapped 20%+ near-term EPS at 22–28× forward (Vistra/Constellation).

## Bull case — technical
For SRE to outperform from here you need:

1. **The ERCOT queue partially converts.** Not 271 GW — but even 25% conversion of the data-center queue (~70 GW) is well above the 11% rate-base CAGR currently underwritten. The Stargate Abilene site is already operational and scaling toward 1 GW [34][35], which is *proof* the load isn't 100% paper. **Base rate check:** utility load forecasts during the dot-com period overshot by ~30%; during industrial electrification, undershot by ~20%. AI is unprecedented in pace, but the directional cue from existing under-construction sites (12 GW of US data centers in active construction in 2026 [21]) makes this *not* a strawman.
2. **Transformer/turbine constraints persist 18+ months.** This is *bullish* for Oncor's allowed rate base because the gating constraint shifts further into Oncor's vertical (wires + substations), letting Oncor file successive rate cases with rolling capex. Lead times currently extending suggest this is structurally locked in [21][27].
3. **SB6 reforms protect Oncor's downside.** Required financial commitments from large loads >75 MW [17] mean the speculation risk sits on the data-center side, not Oncor's. This was not true 12 months ago.
4. **The Infrastructure carve-out simplifies the story.** After the KKR/CPPIB $10B transaction closes (expected Q2–Q3 2026) [11][36], Sempra becomes ~95% regulated by 2030 [15] — a cleaner re-rate vehicle for utility-dedicated capital pools.
5. **Permian 765-kV build executes on schedule.** First-mover 765-kV in ERCOT generates a $13–17B capex bucket Oncor is positioned to win a large share of [18].

Financial outcome: 11% rate base growth × 9.75% allowed ROE × Oncor 80% ownership delivers a ~9% EPS CAGR (the high end of guidance). At a ~17–18× forward P/E on $7+ 2030 EPS = $125-130 in three years, or ~12% IRR including dividend. That's not a Vistra-style 3-bagger but it is alpha vs. utility index (XLU ~6% 3-year IRR).

**Base rate on utility moat displacement:** essentially 0% over rolling 5-year windows in the last 40 years. State-granted franchise monopolies don't get disrupted by technology; they get disrupted by political acts (Texas deregulation 1999, California restructuring 1996), and those acts cleaved generation, not T&D. T&D incumbency has never been broken in a major US market.

## Bear case — technical
The honest short-side stack:

1. **The 271 GW data-center queue is mostly fake.** Hyperscalers file duplicative interconnect requests across multiple TDUs and ISOs to optionality-shop. SB6's disclosure requirement [17] confirms regulators believe this is happening. **If real conversion is <10%, Oncor's 122 GW load forecast collapses to <40 GW and the incremental $9B "upside capex" disappears.** This is the central bear point.
2. **Gas turbine constraint binds first.** If the 100 GW GE Vernova backlog [27] cannot be delivered before 2030, ERCOT cannot generate enough firm power to actually energize the GPU clusters, even with wires built. Oncor builds the transmission, the load doesn't show, but the transmission still gets paid (socialized recovery). However, the *incremental rate case* depends on PUCT continuing to approve speculative build — under a less utility-friendly future PUCT, that approval is reversible.
3. **PUCT regulatory backlash.** Texas retail electricity rates have risen meaningfully; Oncor's $560M rate increase is being passed through to consumer bills [16]. If consumer rates rise faster than wage growth into 2027–28, political pressure could tighten allowed ROE (10 bps → 30 bps headwind) or force cost allocation onto data-center customers (margin-neutral but slows growth). This is the dominant risk to the regulated-utility re-rate thesis.
4. **California is a drag, not just a floor.** SDG&E AB 1054 exposure exists, GRC outcomes have compressed allowed ROE relative to historical, and SoCalGas is in long-term terminal decline as electrification advances. ~$23.5B going into California is *defensive* capex, not growth capex [15].
5. **Multiple compression.** If the market re-rates utilities lower as long-rates rise (or rotates back to merchant generators on AI conviction), 17.7× forward P/E goes to 14–15×. That alone is a 15–20% drawdown before earnings even rolls. Utilities have a 25-year regression line of trading at ~16× and SRE is currently at the upper end.
6. **Behind-the-meter / co-location bypass.** SB6 [17] and PJM FERC December 2025 order [30] both make co-location viable. Stargate Abilene is reportedly partly behind-the-meter. If hyperscalers solve their own power problem with gas turbines on-site, they bypass the TDU entirely. Oncor's *transmission* moat survives (still need export/import); its *distribution* growth doesn't. This is the most underappreciated structural risk.

## Market view check
At $91.57 / ~17.7× forward, SRE trades at a modest premium to the regulated-utility composite (~16×) and a clear discount to the AI-themed merchant generators (Vistra ~26×, Constellation ~28×). The consensus PT of $102.67 implies +12% over 12 months, consistent with management's own 7–9% EPS CAGR plus dividend yield. **The market is paying you for ~9% growth that is unusually high-confidence for a utility** (because rate base growth is contractually mechanical at allowed ROE), with optionality on the +$9B incremental capex bucket if the data-center queue converts. The market is *not* pricing the Vistra-style scenario where SRE gets a merchant uplift — and it shouldn't, because the regulatory structure prevents it. The pricing looks roughly fair: cheaper than it should be if you believe ERCOT queue conversion >40%; expensive if you believe <15%.

## 90-day falsifiers
- **Q2 2026 Oncor earnings (early August).** Look for: data-center queue update (currently 271 GW); change in CapEx pacing (currently $9B 2026); commentary on transformer delivery slippage. If queue *grows* >285 GW, bull thesis intact; if queue *shrinks* >10% sequentially, hyperscaler optionality-shopping is being exposed.
- **PUCT SB6 final adoption dockets.** Multiple final adoptions on financial commitment, curtailment, and co-location are scheduled for 2026 [17]. A rule that imposes *too much* financial commitment on data centers could cool conversion; a permissive rule on co-location could enable BTM bypass.
- **ERCOT 2026 Regional Transmission Plan approval timing.** Oncor's 122 GW filing was submitted April 1, 2026 [9]. PUCT approval (or rejection of portions) of incremental 765-kV scope determines the $9B upside bucket.
- **GE Vernova Q2 2026 results (late July).** Confirmation that 2029 backlog is sold out and 2031 reservations are accelerating tells you AI-generation demand is real and persistent — which by extension validates Oncor's load forecast.
- **Closing of the KKR/CPPIB Sempra Infrastructure transaction.** Expected Q2–Q3 2026 [11]; any delay or repricing materially affects the regulated re-rate narrative.
- **Hyperscaler capex Q2 2026 prints (Microsoft/Meta/Google/Amazon, late July/early August).** Any sequential capex *cut* >10% from a hyperscaler tells you the Oncor queue is more paper than real; sustained or rising prints validate the thesis.

## What I could not verify
- The **exact ownership split of Oncor** between Sempra (~80%), Texas Transmission Investment LLC, and Oncor Management Investment LLC — I am working off standard disclosed structure but did not pull the most recent 10-Q minority-interest line.
- **What fraction of the 271 GW Oncor queue represents the same data-center customer filing duplicatively** across multiple TDUs — this is precisely the question SB6's disclosure rule is designed to answer and 2026 dockets will reveal.
- **Sempra Infrastructure pro forma deconsolidation accounting** — whether Sempra retains pro-rata earnings recognition at 25% or moves to equity-method; this affects 2027 EPS guidance interpretability.
- **Specific transformer slot allocation** between Oncor, Vistra, and hyperscalers from Hitachi Energy / Siemens Energy frame contracts. I have the macro shortage data but not contract-specific priority.
- **Oncor's allowed ROE durability under a 2027–28 PUCT recomposition** — Texas commissioner appointments are politically driven and the current 9.75% is at the favorable end historically.
- **Permian 765-kV construction schedule and Oncor's specific awarded share** of the $13–17B plan — Oncor said "significant portion" without giving a percentage [18].

## Sources
[1] https://finance.yahoo.com/quote/SRE/ — retrieved 2026-05-10 — current price $91.57, shares out 653.3M, market cap $61.3B
[2] https://www.stocktitan.net/news/SRE/sempra-reports-first-quarter-2026-ln578aw85u65.html — retrieved 2026-05-10 — Q1 2026 results, $1.51 adjusted EPS, FY26 guide affirmed
[3] https://www.dailypolitical.com/2026/05/09/sempra-energy-nysesre-issues-fy-2026-earnings-guidance.html — retrieved 2026-05-10 — FY26 EPS guide $4.87-$5.37, FY27 $5.10-$5.70
[8] https://www.utilitydive.com/news/oncor-sempra-interconnection-texas-data-center-earnings/757262/ — retrieved 2026-05-10 — Oncor 200 GW interconnection requests
[9] https://www.fool.com/earnings/call-transcripts/2026/05/07/sempra-sre-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1 2026 earnings call transcript with management Q&A on data center demand, "indifferent" claim, 122 GW RTP filing
[10] https://www.datacenterdynamics.com/en/news/texas-utility-oncor-reports-186gw-of-interconnection-requests-from-data-centers/ — retrieved 2026-05-10 — Oncor 186 GW data-center interconnection request earlier disclosure
[11] https://www.investing.com/news/stock-market-news/utility-sempra-to-sell-stake-in-infrastructure-platforms-for-10-billion-4251209 — retrieved 2026-05-10 — KKR/CPPIB $10B 45% stake purchase; Port Arthur Phase 2 FID
[12] https://www.financecharts.com/stocks/SRE/summary/price — retrieved 2026-05-10 — 52-week range $72.56-$101.04, YTD ~-2%
[13] https://www.marketbeat.com/stocks/NYSE/SRE/ — retrieved 2026-05-10 — consensus PT $102.67, Moderate Buy, dividend $2.63 annualized, P/E 31× trailing
[14] https://fintel.io/ss/us/sre — retrieved 2026-05-10 — short interest 1.1-2.1% of float
[15] https://seekingalpha.com/news/4558360-sempra-outlines-65b-capital-plan-and-11-percent-rate-base-cagr-through-2030 — retrieved 2026-05-10 — $65B capex, 11% rate base CAGR ($57B→$97B), 95% regulated mix by 2030, 7-9% EPS CAGR, 2030 EPS $6.70-$7.50
[16] https://www.stocktitan.net/sec-filings/SRE/8-k-sempra-reports-material-event-8128ae5cd7df.html — retrieved 2026-05-10 — Oncor rate case April 17, 2026 final order: 9.75% ROE, 43.5% equity, $560M revenue increase
[17] https://www.mcguirewoods.com/client-resources/alerts/2025/7/texas-senate-bill-6-significantly-expands-regulatory-oversight-over-large-loads-in-ercot/ — retrieved 2026-05-10 — SB6 75 MW threshold, curtailment, financial commitment, disclosure rules
[18] https://www.utilitydive.com/news/texas-regulators-approve-permian-basin-reliability-plan/728269/ — retrieved 2026-05-10 — PUCT approval of Permian Basin Reliability Plan, 765 kV designation, $13-17B scope
[19] https://epeconsulting.com/epe-intelligence/news/latest-updates-to-ercots-milestone-765-kv-permian-reliability-plan — retrieved 2026-05-10 — 765 kV first in Texas; technical context vs. 345 kV
[20] https://www.powermag.com/transformers-in-2026-shortage-scramble-or-self-inflicted-crisis/ — retrieved 2026-05-10 — large power transformer 5-year lead times
[21] https://www.industrialsage.com/power-transformer-lead-times-us-grid-shortage/ — retrieved 2026-05-10 — 128-week lead times, 60-80% price increases, half of 2026 US data center builds at risk
[22] https://www.utilitydive.com/news/ercots-large-load-queue-jumped-almost-300-last-year-official/808820/ — retrieved 2026-05-10 — ERCOT queue 226 GW, ~4× growth, 77% data centers
[23] https://www.latitudemedia.com/news/ercots-large-load-queue-has-nearly-quadrupled-in-a-single-year/ — retrieved 2026-05-10 — ERCOT queue ~360,000 MW prospective load
[24] https://www.morningstar.com/news/pr-newswire/20260507da53459/oncor-reports-first-quarter-2026-results — retrieved 2026-05-10 — Oncor Q1 2026: 697 active LC&I requests, 271 GW data center
[25] https://www.oncor.com/content/oncorwww/wire/en/home/newsroom/ONCOR-REPORTS-2025-RESULTS---ANNOUNCES--47-5-BILLION-2026-2030-BASE-CAPITAL-PLAN.html — retrieved 2026-05-10 — Oncor $47.5B 2026-2030 base capex, $9B 2026 alone, 122 GW load forecast
[26] https://www.woodmac.com/press-releases/power-transformers-and-distribution-transformers-will-face-supply-deficits-of-30-and-10-in-2025/ — retrieved 2026-05-10 — 30% power transformer / 10% distribution transformer deficits
[27] https://www.utilitydive.com/news/ge-vernova-gas-turbine-backlog-hits-100-gw-as-prices-rise/818332/ — retrieved 2026-05-10 — GE Vernova 100 GW backlog Q1 2026, sold out 2029-2030
[28] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — 80 GW backlog year-end 2025, 20 GW annualized output by Q3 2026
[29] https://www.whitecase.com/insight-alert/doe-directs-ferc-accelerate-interconnection-data-centers — retrieved 2026-05-10 — DOE October 2025 directive to FERC for accelerated large-load rulemaking
[30] https://www.bakerbotts.com/thought-leadership/publications/2025/december/ferc-issues-order-providing-guidance-for-co-locating-power-plants-with-data-centers-within-pjm — retrieved 2026-05-10 — FERC December 2025 PJM co-location order; BTM netting threshold change
[31] https://www.singletonschreiber.com/theblog/how-does-ab-1054-work-blog — retrieved 2026-05-10 — AB 1054 $21B wildfire fund, SDG&E 4.3% share
[32] https://www.power-eng.com/nuclear/vistra-secures-long-term-nuclear-ppa-from-comanche-peak-nuclear-plant/ — retrieved 2026-05-10 — Vistra 1,200 MW Comanche Peak PPA, 20-year
[33] https://markets.financialcontent.com/stocks/article/marketminute-2026-3-10-constellation-energy-finalizes-164-billion-calpine-acquisition-solidifying-lead-in-ai-data-center-power-race — retrieved 2026-05-10 — Constellation $16.4B Calpine close Jan 2026, 60 GW combined; NextEra Duane Arnold/Alphabet
[34] https://openai.com/index/five-new-stargate-sites/ — retrieved 2026-05-10 — Stargate ~7 GW planned, $400B over 3 years
[35] https://www.cnbc.com/2025/09/23/openai-first-data-center-in-500-billion-stargate-project-up-in-texas.html — retrieved 2026-05-10 — Stargate Abilene operational, scaling to 1 GW
[36] https://www.sempra.com/newsroom/press-releases/sempra-announces-strategic-transactions-advancing-goal-building-leading-us — retrieved 2026-05-10 — Sempra strategic transactions PR