I have enough material. Drafting the dossier now.

```
# COHR — Coherent Corp.

## Where this sits in the AI stack
Coherent is a vertically integrated optical components and module maker for the **scale-out and (emerging) scale-up fabric** of AI data centers. Its in-scope content is the physical light path: indium phosphide (InP) **EML and CW DFB lasers**, **silicon photonics** PICs, VCSELs, **800G/1.6T pluggable optical transceivers**, and — increasingly — **external laser source (ELS) modules and detachable optical sub-assemblies for NVIDIA's Quantum-X (InfiniBand) and Spectrum-X (Ethernet) co-packaged-optics (CPO) switches** [1][2]. It does not make GPUs, ASICs, HBM, or switch silicon. It sits one layer below Broadcom/Marvell DSPs and one layer above the optical fiber itself, and its workload is **the every-rack, every-GPU east-west traffic** of training and large-batch inference clusters — i.e., bandwidth that scales linearly with GPU count, not with model size [3][4].

## Snapshot
- **Price:** $335.26 (2026-05-08 close) [5]
- **Market cap:** ~$62.5B [5][6]
- **52-week range:** $69.87 – $364.80 [5]
- **Forward P/E:** 43.6× (on FY26 consensus EPS ≈ $5.48) [7][8]
- **EV / NTM revenue:** ~7.5× (inference: market cap ~$62.5B + small net debt of ~$1B given $3B cash and 0.5× net leverage [9], divided by NTM revenue ~$8.5B derived from Q4 FY26 guide of $1.91–2.05B with continued double-digit sequential growth [9][10])
- **Consensus 12-month price target:** $334 median (~flat; high $455, low $170) [7]
- **YTD total return:** +72.8% (through early May 2026) [5]
- **Short interest (% of float):** 3.34% / 6.54M shares [8]

## Moat — what it is physically made of
The moat is **not brand and not switching cost** the way CUDA is. It is a stacked set of materials-science, capital, and qualification gates:

1. **6-inch InP wafer fab capacity.** EMLs and CW lasers are grown on InP, not silicon. Coherent operates the **world's first 6-inch InP-scalable fabs** in Sherman, TX (Finisar legacy plant) and Järfälla, Sweden; a third site in Zurich begins production in early 2027 [11][12]. The 6-inch transition delivers **~4× wafer area** and roughly **half the per-device cost** vs. legacy 3-inch — at yields already exceeding 3-inch lines [9][10]. Coherent is **doubling internal InP output by end of CY26 (one quarter ahead of plan)** and targeting **>2× again by end of CY27** [10]. There are only a handful of companies in the world (Coherent, Lumentum, Mitsubishi, Sumitomo, Broadcom) with InP epi+fab at production volume [13][3].
2. **Vertical integration on InP-based content.** Coherent owns the InP material, the laser chip, the EML, the SiPh PIC (made in partnership), the TEC, the isolator, the fiber attach, and the module assembly [2][3]. This matters because at 1.6T/200G-per-lane, **module yield is dominated by laser chip parametric yield and assembly tolerances** — internal sourcing buffers gross margin from merchant supplier scarcity premia. Q3 FY26 non-GAAP GM was 39.6%, up 105 bps YoY, with management citing internal-sourcing ratio as a primary driver [9][10].
3. **NVIDIA strategic lock-in.** The March 2, 2026 deal gives NVIDIA a $2B equity stake plus a multi-year purchase commitment "extending through end of decade" specifically for CPO components: **high-power CW laser, ELS module, fiber-attach unit, isolators, and TECs** [1][14][10]. This is technical-product-specific and capacity-priority, not generic supplier framework — i.e., it makes COHR a de-facto qualified second source alongside Lumentum on Quantum-X/Spectrum-X.
4. **Hyperscaler LTAs.** Backlog now extends into CY28, with LTAs to end of decade, containing **upfront customer investment + supply commitment + minimum demand commitment** [10]. This is harder to dislodge than spot purchase orders because the customer has paid for capacity.
5. **What is NOT a moat.** Module assembly itself — Coherent loses share here to Innolight (>50% of NVIDIA 800G modules) and Eoptolink at 20–25% lower price points [4][13][15]. Also: **Coherent is NOT the share leader in 200G/lane EML chips — Lumentum is**, holding 50–60% global share and reportedly the only one shipping 200G EMLs in volume today [3][13][16]. COHR's chip-level position is "credible second" with rapid catch-up via the 6-inch ramp, not undisputed leader.

**Durability assessment by component (inference, qualitative):**
- InP fab capacity & yield: **durable 3–5 years**. CapEx + epi recipe + customer qual cycles take years to replicate.
- NVIDIA CPO content: **durable 2–3 years**, then renegotiable.
- Module assembly: **eroding now**. Already lost majority share to Chinese OEMs at 800G [4].
- 200G EML parity vs. Lumentum: **2026 race**. If COHR's 6-inch ramp delivers parametric performance, it equalizes; if not, Lumentum keeps the price-makers position on 1.6T lanes.

## AI buildout bottleneck map
Specific gating constraints over the next ~24 months and COHR's position relative to each:

| Bottleneck | COHR position |
|---|---|
| **CoWoS-L advanced packaging** (TSMC capacity scaling 35K→130K wpm by end-2026; NVIDIA owns >70% allocation) [17][18] | **Indifferent** — does not consume CoWoS. Benefits indirectly if more GPUs ship. |
| **HBM3e/HBM4 supply** (fully allocated through 2026 across SK Hynix/Samsung/Micron) [17] | **Indifferent**. |
| **Optical transceiver supply at 800G/1.6T** (24M units 2025 → ~63M 2026 forecast for ≥800G; book-to-bill at lead vendors >4× during recent quarters) [13][19] | **Direct beneficiary / constraint owner.** Backlog into CY28; pricing optimization underway. |
| **InP epi wafer + EML chip supply** (5 vendors globally; Lumentum under-shipping demand by 25–30%) [13][16] | **Constraint owner.** Doubling internal capacity ahead of schedule [10]. |
| **External Laser Source modules for CPO** (Quantum-X uses 18 ELS to feed 144×800G ports — ~4× fewer lasers than legacy pluggable) [20][21] | **Sole or co-sole supplier**; this is the explicit subject of the NVIDIA $2B deal [1]. |
| **DSP silicon for pluggables** (Marvell Ara X/Ara T; Broadcom; potential LPO/LRO bypass) [22][23] | **Customer of**, not supplier; pricing power held by Marvell/Broadcom. |
| **Power generation / grid interconnect / 100kW+ rack cooling** | **Indifferent** — COHR doesn't sell here (industrial laser systems do not address datacenter cooling at meaningful scale). |
| **Kernel/compiler talent** | **Indifferent.** |

**Net:** COHR sits on **three of the binding bottlenecks** (transceiver capacity, InP/EML supply, CPO laser content) at a moment when CoWoS/HBM bottlenecks force NVIDIA to extract maximum performance per packaged GPU — which means more bandwidth per GPU, which means more transceivers per GPU.

## Competitive teardown

**Lumentum (LITE).** The most important comp. **Already at parity-or-ahead on EML chip technology** — sole-volume 200G/lane EML supplier in 2025–2026, 50–60% share [3][13][16]. Also chosen by NVIDIA for ELS in Spectrum-X [2]. The technical question is **chip vs. integrated module**: Lumentum wins on chip-level merchant pricing power; Coherent wins on vertical capture (chip → module → system value) and on InP wafer fab footprint, where Coherent is **ahead on the 6-inch transition** [11][12]. Both received $2B from NVIDIA on the same day for related-but-distinct content [1][24].

**Innolight + Eoptolink (private Chinese).** Module-level price competitors. Combined ~60% of NVIDIA 800G procurement; Innolight ~50% of NVIDIA 1.6T modules at launch [4][13]. Their structural vulnerability: **they buy lasers from Coherent / Lumentum / Mitsubishi / Broadcom and DSPs from Marvell/Broadcom**. Tariff and country-of-origin exposure has pushed manufacturing to Thailand/Vietnam/Mexico but design and supply chain remain China-anchored [15]. They take module share but do **not displace** COHR in the laser layer.

**Marvell (MRVL).** Adjacent. Owns the **DSP layer (Ara X 1.6T, Ara T retimer)** [22] and acquired **Celestial AI for $3.25–5.5B for "Photonic Fabric" CPO scale-up technology**, targeting first major revenue from **Amazon Trainium 4** [23][25]. This is the credible threat vector: if hyperscaler scale-up CPO converges on Marvell+Celestial's optical interposer architecture **instead of** the NVIDIA-Coherent-Lumentum ELS-fed switch CPO architecture, COHR's CPO TAM (mgmt cites $15B incremental [10]) compresses. Timeline: Celestial AI revenue ramp targeted for **2027–2028** [23][25].

**Broadcom (AVGO).** DSPs + Bailly CPO platform; competes for the DSP and switch-CPO design wins. Has its own InP capability via prior acquisitions. Less of a direct module competitor than Marvell; more of a switch-ecosystem competitor.

**Cisco/Acacia, Juniper/OpenLight (ex-Aurrion), Intel SiPh.** Niche or de-prioritized; not material near-term [26].

**What would have to be true for a competitor to take meaningful share:**
- *Lumentum scales 6-inch InP faster than COHR and locks NVIDIA into single-source ELS contracts.* Possible; LITE has the lead in 200G EMLs but COHR is ahead on wafer-size transition.
- *Marvell-Celestial's photonic-fabric CPO becomes the de-facto scale-up standard on Trainium/MI400/TPU-class accelerators.* Possible by 2028 but unproven at scale.
- *LPO/LRO eliminates the DSP from 1.6T modules sufficiently to compress module ASPs by 30%+.* Industry analysts forecast ~1/3 of intra-DC 800G in LPO/hybrid by 2026–27 [27]; this is more of a Marvell/Broadcom DSP risk than a COHR laser-chip risk. **Lasers and InP are needed regardless of DSP architecture.**

## Bull case — technical
1. **The InP/laser layer is the binding constraint of the optical buildout.** It is harder to add InP wafer capacity than to add module assembly. COHR is one of only a handful of integrated InP-to-module players, and the only one ahead on the 6-inch wafer-size transition with operating fabs in three geographies [11][12].
2. **1.6T transitions in 2H26/2027 are higher-content-per-port than 800G** (ASP roughly 2× per lane; eight 200G lanes per 1.6T port) [16], expanding revenue without proportional unit volume risk.
3. **Scale-up CPO becomes a second growth leg in 2H27**. Mgmt expects scale-out CPO ramp to begin 2H26 and scale-up CPO ramp 2H27 [10]. The NVIDIA roadmap (NVLink8 CPO in 2028, Kyber NVL1152 with direct optical scale-up) [28][29] adds optical content to a layer that today is copper, structurally expanding TAM.
4. **Pricing optimization + 6-inch yield + LTA mix** drives non-GAAP gross margin from 39.6% to mgmt's >42% Investor Day target by FY28 [9][10]; operating leverage on the Datacom mix (75% of Q3 FY26 revenue, growing 40%+ YoY) [10] flows through to EPS.

**Base rate caveat on technology displacement:** Optical interconnect supplier displacement has historically been **slow** — 5–10 years for incumbent dislodging. JDSU/Lumentum, Finisar/COHR, Cisco/Acacia have remained in the top supplier set for >20 years; Chinese module makers have taken module-assembly share but **have not yet displaced US/Japan in laser chips after a decade of trying**. Bull case rests on this base rate holding, *plus* the InP capacity expansion being delivered on the stated curve.

**Financial implication (sanity check, not thesis):** If revenue compounds ~25–30% over FY26–FY28 to ~$11–12B and GM reaches 42%+ with 25% non-GAAP opex/sales, non-GAAP operating margin ~17% → ~$2B operating income → ~$11–13 non-GAAP EPS by FY28 (back-of-envelope inference). At today's ~44× forward, that's a meaningful price uplift; at 25× ($275–325), the stock approximately holds.

## Bear case — technical
1. **Lumentum keeps the 200G EML chip lead through 2026** and signs preferential capacity allocations with Innolight/Eoptolink that route around COHR at the chip level. COHR's module business still depends on its own EMLs being parametrically competitive at high lane rates; if Sherman/Sweden 6-inch ramps slip on yield, COHR is buying merchant chips from a competitor.
2. **CPO architecture diverges from the NVIDIA-Coherent ELS-feeding-CW model.** If hyperscalers (especially AWS Trainium 4 with Marvell+Celestial AI) and Google TPU adopt **integrated on-die laser** or non-InP CPO architectures (Marvell Celestial AI's Photonic Fabric uses silicon photonics with potentially different laser sourcing) [23][25], COHR's $15B-TAM claim contracts.
3. **LPO/LRO arrives faster than expected and is paired with cheaper laser specs** — i.e., the industry decides 1.6T can be done with lower-grade EMLs because DSP loss is removed from the budget. This would compress laser ASPs in exactly the segment COHR is investing into.
4. **Hyperscaler capex digestion.** Optical content scales with GPU deployment, not training-token demand. If 2027 capex grows 0–10% vs. 2026 (vs. consensus modeling 30%+), COHR's 38–40%+ datacom YoY growth collapses to teens. The book-to-bill >4× and 2028 backlog [13][10] is a leading indicator but **orders can be deferred faster than they were booked** — Cisco/Acacia 2022, Lumentum 2023 are precedents.
5. **InP is a strategic chokepoint, which invites direct government and customer intervention.** Hyperscalers can co-invest in second/third sources (as DENSO and Mitsubishi did on COHR's SiC business [30]), and Chinese state-backed InP fabs are a 5–7 year threat to the strategic premium.
6. **Valuation reset.** At ~7.5× EV/NTM revenue and ~44× forward P/E, the stock prices in continued 25–30% growth and margin expansion to >42%. Any of the above outcomes — particularly an EML chip share loss to Lumentum or a CPO architecture pivot — produces both an estimate cut *and* a multiple compression. Optical names have historically traded 4–8× revenue at maturity (Lumentum has spent most of its history in this band); current multiple is at the high end of historical comps.

## Market view check
Consensus 12-month median PT of $334 is **functionally a hold-at-spot** [7], reflecting that the sell side has caught up to the AI-optics narrative and is now extrapolating known quarters forward — not pricing a regime shift. The 44× forward / 7.5× EV/sales is not a CUDA-tier moat multiple; it is a "premium specialty hardware in a buildout cycle" multiple. **The market is pricing the bull case for FY27 and a continuation in FY28**, which the technical setup (backlog to 2028, InP capacity ahead of schedule, NVIDIA equity tie-up) plausibly supports — *but the market is NOT pricing scale-up CPO disruption risk from Marvell-Celestial or laser-chip share loss to Lumentum*. The actionable disagreement, if there is one, is that the right cross-check is COHR vs. LITE relative valuation, not COHR vs. the index.

## 90-day falsifiers
- **Q4 FY26 print (early August 2026):** Revenue outside the $1.91–2.05B guide [9] or Q4 non-GAAP GM outside 39–41% guide [9] would update the GM-trajectory thesis materially.
- **Coherent FY27 framework / Investor Day commentary (likely August earnings):** Whether 6-inch InP doubling lands in CY26 as guided [10]; if slipped, the chip-supply moat is weaker than stated.
- **NVIDIA datacenter revenue print and CY26 capex commentary (late August):** A sequential deceleration in hyperscaler optical procurement or any disclosure of dual-sourcing language away from the COHR/LITE pair on Quantum-X/Spectrum-X.
- **Lumentum F3Q26 print and 200G EML shipment commentary** — specifically whether 200G EML units crossed the ~25% mix threshold by year-end CY26 [16]. If LITE accelerates faster, it reinforces the bear-case "LITE keeps the chip-layer lead."
- **OFC 2026 follow-ups, GTC fall keynote, Hot Chips presentations** for any new CPO architecture announcements — particularly from AWS/Trainium 4, Google TPU, or AMD MI400 — that route around the NVIDIA ELS-fed model.
- **Innolight / Eoptolink 1.6T tape-out and ramp updates**: confirms or denies the rate at which Chinese modules absorb 1.6T share at NVIDIA, which sets COHR's module ASPs.
- **Celestial AI / Marvell Photonic Fabric customer-disclosed milestones** (especially anything from AWS on Trainium 4 silicon-photonic scale-up).

## What I could not verify
- COHR's precise NVIDIA revenue concentration as a percentage of FY26 revenue. NVIDIA's own disclosures aggregate to "four 10%+ direct customers" without naming COHR's mirror exposure [31].
- COHR's market share of 200G/lane EML production in CY26 specifically — public sources give Lumentum 50–60% and list COHR among the five-vendor set but do not segment COHR vs. Mitsubishi/Sumitomo/Broadcom precisely [3][13].
- The split of the $15B CPO TAM management cites [10] between scale-out (Quantum-X / Spectrum-X switches, 2026–2027) and scale-up (NVLink-CPO, 2028+).
- The actual gross margin difference between EML-based and SiPh-based 1.6T modules — management states "same ballpark" [10] but did not quantify.
- Whether the NVIDIA $2B equity stake comes with board observation, IP-sharing, or right-of-first-refusal provisions beyond what was publicly described [1][14].
- Coherent's order book seasonality and any cancellation flexibility within the LTAs — terms summarized as "upfront customer investment + supply commitment + minimum demand commitment" [10] but not quantified.
- Exact December 31, 2025 closing price (and therefore exact YTD return). The +72.8% YTD figure [5] is from a secondary aggregator and not the issuer.
- Sherman, TX fab production-yield specifics at 6-inch on 200G EML structures (as opposed to 100G).

## Sources
[1] https://nvidianews.nvidia.com/news/nvidia-and-coherent-announce-strategic-partnership-to-develop-optics-technology-to-scale-next-generation-data-center-architecture — retrieved 2026-05-10 — NVIDIA's official announcement of the $2B equity investment + multi-year purchase commitment with Coherent for CPO/laser content.
[2] https://nvidianews.nvidia.com/news/nvidia-spectrum-x-co-packaged-optics-networking-switches-ai-factories — retrieved 2026-05-10 — Quantum-X / Spectrum-X CPO architecture; 18 ELS feeding 144×800G ports; lists Coherent and Lumentum as suppliers.
[3] https://exoswan.com/photonics-stocks/ — retrieved 2026-05-10 — EML supplier set (Lumentum, Coherent, Mitsubishi, Sumitomo, Broadcom); Lumentum 50–60% share at 200G/lane.
[4] https://ip-fiber.com/blogs/news/nvidia-orders-surge-innolight-and-eoptolink-dominate-60-of-800g-sfp-optical-modules-supply — retrieved 2026-05-10 — Innolight+Eoptolink ~60% of NVIDIA 800G modules; Western share split.
[5] https://stockanalysis.com/stocks/cohr/ — retrieved 2026-05-10 — Price $335.26 (May 8, 2026); YTD +72.8%; 1Y +381%; 52-week range $69.87–$364.80.
[6] https://www.gurufocus.com/term/mktcap/COHR — retrieved 2026-05-10 — Market cap ~$65.59B (alternative source); cross-check.
[7] https://public.com/stocks/cohr/forecast-price-target — retrieved 2026-05-10 — Median analyst PT $334; high $455; low $170.
[8] https://www.gurufocus.com/term/forward-pe-ratio/COHR — retrieved 2026-05-10 — Forward P/E 43.61 (May 4, 2026).
[9] https://www.coherent.com/news/press-releases/third-quarter-fiscal-year-2026-results — retrieved 2026-05-10 — Q3 FY26 print: $1.81B revenue, 39.6% non-GAAP GM, Q4 guide $1.91–2.05B / 39–41% GM; $3B cash; 0.5× leverage; $2B NVIDIA investment landed.
[10] https://www.fool.com/earnings/call-transcripts/2026/05/06/coherent-cohr-q3-2026-earnings-transcript/ — retrieved 2026-05-10 — Management transcript: 6-inch InP doubling (ahead of plan); CPO content list (CW laser, ELS, fiber-attach, isolators, TECs); scale-out CPO 2H26 / scale-up CPO 2H27; $15B incremental CPO TAM; backlog to 2028 and LTAs to end of decade; 42%+ GM Investor Day target.
[11] https://www.coherent.com/news/press-releases/worlds-first-6-inch-inp-scalable-wafer-fabs-paving-the-way-for-the-next-generation-of-lasers-for-ai-transceivers-and-6g-wireless-networks — retrieved 2026-05-10 — World's first 6-inch InP fabs in Sherman, TX and Järfälla, Sweden; 4× capacity and 60% die-cost reduction.
[12] https://optics.org/news/15/12/13 — retrieved 2026-05-10 — $33M CHIPS Act preliminary terms for Sherman, TX InP fab (formerly Finisar/TI plant).
[13] https://mlq.ai/research/optical-networking/ — retrieved 2026-05-10 — Combined view of the optical-networking landscape, including Lumentum's 50–60% 200G EML share, Western 800G module share split, Coherent's ~40% Western module share.
[14] https://www.cnbc.com/2026/03/02/nvidia-investment-coherent-lumentum.html — retrieved 2026-05-10 — $4B combined NVIDIA equity investment in Coherent and Lumentum.
[15] https://iamfabian.substack.com/p/pluggables-power-and-geopolitics — retrieved 2026-05-10 — Chinese module-maker tariff exposure, Thailand/Vietnam/Mexico relocation, dependence on US laser+DSP supply.
[16] https://markets.financialcontent.com/stocks/article/finterra-2026-3-26-the-light-engine-of-ai-a-deep-dive-into-lumentum-holdings-lite-and-the-16t-revolution — retrieved 2026-05-10 — Lumentum 200G EML detail: ~5% of units in F2Q26 → ~25% by year-end CY26; under-shipping demand by 25–30%; capacity allocated through CY27.
[17] https://info.fusionww.com/blog/inside-the-ai-bottleneck-cowos-hbm-and-2-3nm-capacity-constraints-through-2027 — retrieved 2026-05-10 — CoWoS/HBM bottleneck framing; TSMC CoWoS 35K→130K wpm by end-2026.
[18] https://www.trendforce.com/news/2025/12/08/news-tsmcs-cowos-l-s-reportedly-fully-booked-osat-partners-step-up-with-ases-cowop-in-focus/ — retrieved 2026-05-10 — CoWoS-L fully booked; OSAT partner workarounds.
[19] https://cignal.ai/2025/05/800gbe-optics-shipments-to-grow-60-in-2025/ — retrieved 2026-05-10 — 800G shipments forecast +60% in 2025; ≥800G units 24M→63M from 2025 to 2026.
[20] https://developer.nvidia.com/blog/how-industry-collaboration-fosters-nvidia-co-packaged-optics/ — retrieved 2026-05-10 — NVIDIA technical blog on CPO architecture and ELS approach (4× fewer lasers vs. pluggable).
[21] https://www.viksnewsletter.com/p/why-cpo-uses-external-lasers — retrieved 2026-05-10 — Engineering rationale for external (not integrated) laser sourcing in CPO.
[22] https://www.marvell.com/company/newsroom/marvell-1-6t-optical-dsp-ai-data-center-connectivity.html — retrieved 2026-05-10 — Marvell Ara X (1.6T DSP) and Ara T (TRO/retimer); 1.6T DSP platform portfolio.
[23] https://photoncap.net/p/copper-wall-age-of-light-dissecting — retrieved 2026-05-10 — Marvell Celestial AI acquisition framing; $3.25–5.5B; targeted $1B run-rate by end CY28; Trainium 4 scale-up.
[24] https://mlq.ai/news/nvidia-commits-2-billion-investment-and-purchase-deal-to-lumentum-for-ai-optics-expansion/ — retrieved 2026-05-10 — Parallel $2B NVIDIA-Lumentum deal context.
[25] https://newsletter.semianalysis.com/p/co-packaged-optics-cpo-book-scaling — retrieved 2026-05-10 — SemiAnalysis CPO technical framing (DSP elimination, lower-power SerDes, >50% energy reduction).
[26] https://www.marvell.com/blogs/silicon-photonics-comes-of-age.html — retrieved 2026-05-10 — Marvell's own narrative on silicon-photonics maturity and coherent module decade.
[27] https://semiengineering.com/linear-pluggable-optics-save-energy-in-data-centers/ — retrieved 2026-05-10 — LPO forecast: ~1/3 of intra-DC 800G in LPO/hybrid by 2026–27.
[28] https://www.hpcwire.com/2026/03/17/huang-shares-nvidia-roadmap-showing-more-chips-nvl1152-scale-up-cpo/ — retrieved 2026-05-10 — NVIDIA GTC 2026 roadmap: NVLink8 CPO (2028), Kyber NVL1152, scale-up direct optical.
[29] https://www.theregister.com/on-prem/2026/04/05/nvidia-embraces-optical-scale-up-as-copper-reaches-limits/5225238 — retrieved 2026-05-10 — Optical scale-up replacing copper at the rack level.
[30] https://www.coherent.com/news/press-releases/coherents-silicon-carbide-semiconductor-business-completes-1-billion-in-investments-from-denso-and-mitsubishi-electric — retrieved 2026-05-10 — DENSO + Mitsubishi Electric $1B each-side investment for 12.5%/12.5%/75% ownership of SiC subsidiary (precedent for strategic co-investor model).
[31] https://www.datacenterdynamics.com/en/news/two-unnamed-customers-accounted-for-almost-40-of-nvidias-q2-2026-revenue/ — retrieved 2026-05-10 — NVIDIA customer-concentration disclosures; mirror exposure for COHR not directly disclosed.
```