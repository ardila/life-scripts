# VMC — Vulcan Materials Company

## Where this sits in the AI stack
Vulcan is the largest US producer of construction aggregates — crushed stone, sand, gravel — with adjacent ready-mix concrete, asphalt, and specialty cement businesses [1][8]. In the AI buildout, it occupies the **physical site layer beneath everything else**: the foundation pads, structural concrete, sub-base under switchgear yards, asphalt for staging, and roadbed for utility access at hyperscale data center campuses and the gas-turbine / substation projects feeding them. It is upstream of the building shell and entirely orthogonal to silicon, packaging, networking, and the software stack. It is a "picks-and-shovels-of-the-picks-and-shovels" name, not a frontier-AI exposure.

## Snapshot
- **Price:** ~$298 (last verified May 1, 2026 close $297.32; May 4 quote $288.13; precise May 8 close not directly captured) [9][10]
- **Market cap:** ~$37.9–$38.8B [1]
- **52-week range:** $252.35 – $331.09 [3]
- **Forward P/E:** ~30.1× (FY26 consensus) [3]
- **EV / NTM revenue:** ~5.0× (inference: $40B EV ÷ ~$8.0B FY26E revenue, given $7.94B TTM and 1–3% volume + 4–6% price guide [2][6])
- **EV / NTM EBITDA:** ~17.8× on TTM, ~16× on FY26E $2.4–$2.6B guide [3][6]
- **Consensus 12-month price target:** $323.50 average / $315.50 median; high $365 (Truist Feb-2026), low $198 [11]; implied +~9% from spot
- **YTD total return:** +2.2% [12]
- **Short interest (% of float):** ~3.9% (Mar-31 settlement, +24.7% sequentially); 3.4-day cover [13]
- **Dividend:** $0.52/qtr declared May 8, 2026 (~0.7% forward yield) [12]

## Moat — what it is physically made of
Honest version: Vulcan's moat is **geology, geography, and zoning law** — not technology. Decomposing it:

1. **Haul-cost economics** (durable, the biggest piece). Aggregates are heavy and low-value-density: trucked haul cost is ~$0.12–0.15 per ton-mile [4], while pit-gate price is roughly $11–$16/ton in business-friendly states. Transport is **50–70% of delivered cost** [4]. Past ~30–50 miles, freight kills the deal. This creates a *local quasi-monopoly* per quarry — far stickier than CUDA, because no software port can move physical rock cheaply. This is why aggregates is the only commodity layer of construction where consolidation has *raised* per-ton economics rather than competed it away (VMC cash gross profit/ton +45% since 2022, to $11.38 trailing) [5][7].

2. **Permitted reserves stockpile** (durable, ~30+ year horizon). 16.6B tons of permitted reserves across 425 sites in 23 states [7]. New quarry permits in Sun Belt MSAs are taking *years* and facing organized local opposition [4]. Replacement cost of the reserve base in current zoning regimes is materially above book — this is the "unbuildable second time" asset.

3. **Geographic concentration in the right metros** (durable). Footprint covers 35 of the 50 fastest-growing US MSAs [5], and management states **70% of data center sq ft planned or under construction sits in Vulcan markets** with **60% of all large public/private projects within 50 miles of a Vulcan facility** [3][14]. This is a non-replicable asset because the relevant land was zoned and permitted decades ago.

4. **Process Intelligence operating system** (the only "tech" piece, modest moat). Vulcan's PI deployment now covers ~75% of production tons; PI-enabled plants showed <1% YoY unit cash cost growth in 2025 vs 2.6% at non-PI plants [7]. This is real but not unique — Martin Marietta has analogous "SOAR" operating discipline. Worth maybe 50–100 bps of margin spread, not a structural moat.

5. **What is NOT a moat:** brand, IP, switching costs, network effects. Customers (DOTs, GCs like DPR/Turner/Holder doing data center work, ready-mix producers) will substitute the nearest competing pit if it's cheaper delivered. The moat is *spatial*, not relational.

**Person-years to replicate:** essentially infinite in the metros that matter — you cannot un-zone Northern Virginia, central Texas, or the Atlanta metro to permit a new 30-hectare quarry today at any reasonable cost. That is the real barrier. (Inference based on permit-cost data [4] and base-rate of zero major greenfield US urban quarry permits granted in the top-20 MSAs in the last decade — could not directly verify the latter.)

## AI buildout bottleneck map
The binding constraints on AI capacity through 2027 are, in order of severity:

1. **High-voltage transformers and switchgear** — pre-2020 lead time 24–30 months; today **5 years** [15]. *VMC: indifferent.* Aggregates are not gating; they follow the project once power is allocated.
2. **Gas turbines** — GE Vernova backlog $163B, slots sold through 2030 by year-end 2026 [15][16]. *VMC: small beneficiary.* Each new gas plant feeding a data-center campus needs concrete pads, access roads, switchyard sub-base. Management explicitly said on the Q1 call they have "begun really booking some energy projects" [3]. Probably worth low-single-digit percent of incremental volume — not transformative.
3. **CoWoS-L / HBM3e / 4nm wafer** — separate stack entirely. *VMC: indifferent.*
4. **Liquid cooling capacity at >100kW/rack** — capex follows the building shell. *VMC: indifferent.*
5. **Permitting + grid interconnect** — the *real* governor on US data center timing. *VMC: ambiguous.* If interconnect queues slip 12–24 months, the *timing* of VMC's data-center volume slips with them, but the cumulative tonnage doesn't disappear.
6. **Concrete and aggregates supply** — **not currently a bottleneck.** ACA projects ~247K mt of cement for hyperscalers in 2025, ~1M mt cumulative through 2028 [17]. That is <1% of US cement demand and well within capacity. Lead times are tied to compliance/spec rather than supply [17]. *VMC: this is honestly bearish for any "scarcity" thesis.* Aggregates are a beneficiary of *volume growth*, not a constrained input that can extract rents.

**Net read:** VMC sits in the easy-to-serve layer of the buildout. It captures pricing power from local oligopoly, *not* from being the binding constraint. The data-center talk on the calls is real volume but not a re-rating event by itself — base aggregates demand from IIJA-funded highway work and Sun Belt residential is still the bigger driver of the 1–3% volume guide [2][6].

## Competitive teardown
- **Martin Marietta (MLM)** — closest comp. Q1 2026: revenue $1.36B (+17%), aggregates shipments 43.9M tons (+12% organic 7.2%), EBITDA $364M [18]. MLM has a more concentrated SOAR-megaregion footprint (Sun Belt + Atlantic seaboard) and historically *higher* per-ton margins; VMC has more total tons. Both reaffirmed FY26 EBITDA midpoint near $2.4B [6][18]. On data-center axis: similar exposure — both quote the same 65–70% in-market data center figure under different framings. *Parity, not displacement.* The two operate as a stable duopoly in many MSAs and tend to price together.
- **CRH plc** — diversified Irish-listed multinational, more cement/products mix, US aggregates much more fragmented. Just acquired Eco Material Technologies ($2.1B, SCMs) and North American Aggregates [19]. Threat: roll-up of fringe pits could pressure VMC's M&A pipeline (VMC says 350M-ton acquisition target inventory [5]). Not a direct displacement risk.
- **Eagle Materials (EXP)** — heartland/Sun Belt cement and gypsum focus; competitor in cement adjacency, not aggregates head-to-head.
- **Summit Materials (SUM)** — being acquired/ has been acquired into Quikrete-related transactions; was a fragmented consolidator, now reshaped. Less of a competitive threat post-restructuring (could not verify current corporate status precisely).
- **Amrize (Holcim US spinoff, 2025)** — top-five US position in cement, aggregates, ready-mix [20]. Genuine new competitor for hyperscaler accounts in 2026+.
- **Local/regional pits** — the real competitive friction in any given MSA. Mostly private. Pricing is mostly disciplined because everyone needs to amortize stranded reserves.

The competitive question is *not* "who takes share from VMC." Aggregates share is set by who owns the closest pit. The question is whether MLM or Amrize bid up bolt-on M&A multiples, eroding VMC's per-ton accretion math on the path to $20/ton.

## Bull case — technical
For VMC to materially outperform from here, the following technical conditions need to hold:

1. **AI data center buildout sustains through 2028 at announced pace.** ~650M sq ft announced/under construction [3]; if even ~60% gets built and Vulcan markets capture ~70%, that's ~270M sq ft × roughly 50× concrete intensity vs multifamily [17] — sizable but quantifying tons precisely is hard (could not source a clean tons-of-aggregate-per-MW or per-sq-ft figure for hyperscale; the 600,000-ton single-Meta-facility datapoint [5] is the best anchor).
2. **Quote-to-shipment compression holds.** Management says data center jobs are converting in 2–3 months vs historical 6 months [3]. This pulls revenue forward and lifts utilization, dropping incremental tons to ~70%+ contribution margin given fixed-cost leverage of pits.
3. **Power-sector ancillary demand kicks in.** New gas-turbine plants and substations need concrete pads and aggregates-intensive site work. With GE Vernova running ~20–24 GW/yr of turbine output by 2028 [15], the ancillary aggregates pull is meaningful even at modest tons-per-MW.
4. **$11→$20/ton path executes.** Investor Day target implies $4.5–5B EBITDA on 260–270M tons (vs 2025: 227M tons) [5][7]. Hitting this requires (a) PI deployment to 90%+ of tons, (b) continued 4–6% pricing through 2028, (c) M&A adding ~30M tons of accretive volume. The 45% per-ton GP gain since 2022 is evidence the operating model works [7].
5. **Base rate check.** Aggregates is one of the slowest-eroding moats in the industrial economy — the closest historical analog (cement majors over 1995–2020) shows zero successful technical displacement, only consolidation cycles. Unlike CPU→GPU, there is no substitute technology. Asphalt-rubber, recycled aggregates, and 3D-printed concrete have been "5 years away" for 25 years. Confidence that the *moat* survives is very high; the variable is *how much volume* AI adds.

Financial outcome: if FY28 EBITDA reaches ~$3.5B (midway to $4.5B target) and the multiple holds at ~17×, EV ~$60B vs current ~$40B → ~50% upside over 24–36 months, plus dividend. Modest re-rating from data-center narrative could push higher.

## Bear case — technical
The version a thoughtful short would write:

1. **Aggregates are not the bottleneck — the multiple is overpaying for narrative.** 30× forward P/E and 17–18× EBITDA on a single-digit-volume-growth, mid-single-digit-pricing business is rich for what is structurally a GDP+ industrial. The data center attribution is being used to justify a multiple that wasn't there in 2019. If the AI narrative cools — even just the *premium* portion — multiple compression to 13–14× EBITDA implies ~25% downside before any earnings change.
2. **Data center percent-of-revenue is small.** Aggregates demand is dominated by public infrastructure (IIJA-funded DOT work, ~30–40% of tons) and traditional non-res / residential. Data centers are likely <10% of tons even in 2028 (inference; could not source a clean breakout). The narrative is leveraged but the *math* doesn't transform the model.
3. **Power constraints cap data-center starts.** 5-year transformer lead times [15] and gas-turbine sellouts [16] mean announced sq-ft will not be built on the announced schedule. If 30–40% of announced campuses slip 18+ months, VMC's data-center tailwind in 2026–2027 is thinner than bulls model.
4. **Pricing power is partly a one-shot reset.** The $11→$20/ton path assumes 4–6% pricing compounds through 2028. Mid-2020s saw catch-up pricing after a decade of flat real prices. The forward path is closer to inflation+1–2%, not the 8–10% nominal pricing of 2022–2024 [5]. Sell-side is extrapolating a peak.
5. **M&A multiples have re-rated.** With CRH, Amrize, MLM, and private equity all chasing the same bolt-ons, accretive deals get harder. The 350M-ton "pipeline" can be acquired, but possibly not at multiples that compound EPS.
6. **Cyclical risk.** Residential and private non-res construction are interest-rate-sensitive. A 2026–2027 macro slowdown, even with public infrastructure stable, dents the high-margin residential/light-commercial mix. Aggregates EBITDA fell 25–30% peak-to-trough in 2008–2010 [base rate, not separately sourced].
7. **No software, no IP, no AI optionality.** This stock should not be in a portfolio because of what it does for AI; it should be in a portfolio because it's a great industrial. Investors framing it as "AI infrastructure" risk paying an AI-infrastructure multiple for a cement-cycle business.

## Market view check
At ~$298 and ~30× forward EPS / ~17× EBITDA, the market is pricing VMC as roughly 60% high-quality industrial compounder, 40% data-center-narrative beneficiary. Consensus PT $323 is ~9% above spot — not stretched, but not a screaming bargain either. The price is *consistent* with the technical reality if you believe (a) the $11→$20/ton path partly executes by 2028, and (b) data-center volumes provide a sustained 1–2 pp lift to base volume growth. The price is *inconsistent* if you believe data centers are a 2026–2027 pull-forward that fades as power constraints bind and the multiple has to revert to 13–14× EBITDA. My read: roughly fairly valued; the asymmetry is modestly to the downside in the next 12 months because the multiple is at the high end of historical range and the AI-narrative premium is the marginal buyer.

## 90-day falsifiers
Specific events that would update the thesis between now and ~Aug 10, 2026:
- **Q2 2026 earnings (late-July).** Two checks: (i) freight-adjusted aggregates pricing at top end of 4–6% range as guided [3]; (ii) management raises FY26 EBITDA guide above $2.6B high-end. Either miss is a bearish update.
- **Hyperscaler Q2 capex prints (Microsoft, Meta, Alphabet, Amazon late-July).** A sequential cut of >10% in CY26 capex from any two of the four is a material negative for the data-center-tailwind story [inference on threshold].
- **PJM / ERCOT interconnect queue actions.** Any large data center campus delay >12 months announced in Northern Virginia, Atlanta, or central Texas — direct read on whether power gates VMC volume.
- **MLM Q2 print (early August).** If MLM pricing decelerates while VMC pricing holds, evidence VMC's PI-driven cost edge is real. Convergent results = the duopoly is doing duopoly things.
- **GE Vernova / Eaton / Siemens Energy backlog updates.** If transformer/turbine lead times extend further, that's bearish for *near-term* VMC data-center volume but bullish for ancillary energy-project tonnage in 2027.
- **Any meaningful aggregates M&A announcement** (CRH, Amrize, VMC itself). Multiple paid is a direct read on bolt-on accretion economics underlying the $20/ton path.

## What I could not verify
- Precise May 8, 2026 closing price (sources gave May 1 $297.32 and May 4 $288.13; used ~$298 as approximation [9][10]).
- A clean tons-of-aggregate-per-MW or per-square-foot figure for hyperscale data centers — only have the single Meta-600,000-ton anchor [5] and ACA cement totals [17]. Without this, the data-center revenue contribution to VMC is harder to size precisely than I would like.
- Data-center % of VMC's 2025 or 2026E revenue — management gives footprint exposure ("70% of sq ft in our markets") but not a cleanly disclosed revenue contribution figure.
- Current corporate status of Summit Materials post-Quikrete-related restructuring.
- Direct evidence on how the duopoly with MLM behaves in specific data-center markets (Loudoun County, North Texas, central Phoenix) — likely disciplined but not separately verified.
- Bernstein, Morgan Stanley, and Goldman analyst-level price targets (only Truist $360 was specifically captured [11]).
- Cyclical drawdown depth for VMC specifically in 2008–2010 (used industry recollection, not directly sourced).

## Sources
[1] https://finance.yahoo.com/quote/VMC/ — retrieved 2026-05-10 — current quote, market cap, summary metrics
[2] https://www.investing.com/news/company-news/vulcan-materials-q1-2026-slides-aggregates-volume-pricing-drive-growth-93CH-4646164 — retrieved 2026-05-10 — Q1 2026 results: $1.76B revenue +7%, aggregates +5%, pricing +4%, EBITDA $447M, FY guide reaffirmed
[3] https://www.fool.com/earnings/call-transcripts/2026/04/29/vulcan-materials-vmc-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — management quotes on data center exposure, 60%-within-50-miles, 650M sq ft announced, energy project bookings, 2-3 month quote-to-shipment
[4] https://latestcost.com/aggregate-cost-per-ton-united-states/ and https://www.burgex.com/2026/04/09/quarry-permitting-zoning-support/ — retrieved 2026-05-10 — aggregates haul economics, transport 50-70% of delivered cost, $0.12-0.15/ton-mile, regional pricing $11-25/ton, permitting friction
[5] https://www.tikr.com/blog/from-11-to-20-per-ton-what-vulcan-materials-investor-day-revealed-for-2026 — retrieved 2026-05-10 — Investor Day details: $20/ton target, $4.5-5B EBITDA implication, 260-270M ton volume base, Process Intelligence at 75% of production, 350M-ton M&A pipeline, single Meta facility = 600K tons
[6] https://www.prnewswire.com/news-releases/vulcan-reports-first-quarter-2026-results-302756293.html — retrieved 2026-05-10 — official Q1 2026 release: FY26 EBITDA guide $2.4-$2.6B, volume +1-3%, pricing +4-6%
[7] https://www.stocktitan.net/sec-filings/VMC/8-k-vulcan-materials-co-reports-material-event-5d0d280f00da.html — retrieved 2026-05-10 — 16.6B tons permitted reserves, 425 ops/23 states, 227M tons 2025, 45% per-ton GP gain since 2022, PI cost-control evidence
[8] https://www.vulcanmaterials.com/news-and-events/press-releases/2026/vulcan-materials-to-outline-new-growth-and-profitability-targets-at-2026-investor-day — retrieved 2026-05-10 — company corporate framing
[9] https://stockanalysis.com/stocks/vmc/statistics/ — retrieved 2026-05-10 — forward P/E ~30, 52-week range $252-$331, EV/EBITDA 17.87, TTM revenue $7.94B
[10] https://public.com/stocks/vmc/market-cap — retrieved 2026-05-10 — recent price points around $288-$297 first week of May 2026
[11] https://public.com/stocks/vmc/forecast-price-target and https://finance.yahoo.com/news/truist-raises-price-target-vulcan-032938375.html — retrieved 2026-05-10 — consensus PT ~$315-$323; Truist $360 (Buy) Feb 2026
[12] https://www.prnewswire.com/news-releases/vulcan-declares-quarterly-dividend-on-common-stock-302767276.html — retrieved 2026-05-10 — May 8 2026 dividend declaration $0.52/qtr; YTD +2.2% return
[13] https://www.themarketsdaily.com/2026/04/18/short-interest-in-vulcan-materials-company-nysevmc-increases-by-24-7.html — retrieved 2026-05-10 — short interest 5.09M shares, ~3.9% of float, +24.7% sequentially
[14] https://marketwise.com/investing/ai-infrastructure-investment-the-hidden-boom-in-construction-materials/ — retrieved 2026-05-10 — 70% of data center sq ft in Vulcan markets framing
[15] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ and https://www.primary.vc/articles/the-gas-turbine-bottleneck-reshaping-energy-infrastructure-ex8qe — retrieved 2026-05-10 — gas turbine and HV transformer bottleneck data, lead times 5 years
[16] https://www.power-eng.com/gas/turbines/data-centers-drive-record-surge-in-ge-vernova-power-equipment-orders-as-turbine-slots-tighten-through-2030/ — retrieved 2026-05-10 — GE Vernova backlog $163B, turbines sold through 2030, 20-24 GW/yr capacity
[17] https://mi.cement.org/PDF/Data_Center_Cement_Consumption.pdf and https://www.spglobal.com/energy/en/news-research/latest-news/fertilizers/062625-us-data-center-expansion-drives-significant-rise-in-cement-demand-aca — retrieved 2026-05-10 — ACA cement demand for data centers (~247K mt 2025, ~1M mt cumulative to 2028), data centers use ~50× concrete of multifamily
[18] https://www.fool.com/earnings/call-transcripts/2026/04/30/martin-marietta-mlm-q1-2026-earnings-transcript/ and https://www.stocktitan.net/news/MLM/martin-marietta-reports-first-quarter-2026-ukg1h85nu8al.html — retrieved 2026-05-10 — MLM Q1 2026: $1.36B revenue +17%, EBITDA $364M, organic agg +7.2%, 43.9M tons, FY26 EBITDA midpoint $2.43B
[19] https://www.crh.com/media/press-releases/2025/crh-completes-2-1b-acquisition-of-eco-material-technologies/ and https://www.investing.com/news/company-news/crh-expands-aggregates-business-with-north-american-aggregates-acquisition-93CH-4411375 — retrieved 2026-05-10 — CRH Eco Material $2.1B and North American Aggregates acquisitions
[20] https://concreteproducts.com/index.php/2024/04/02/wall-street-awaits-holcim-us-lafarge-canada-spin-off-from-swiss-parent/ — retrieved 2026-05-10 — Holcim US/Lafarge Canada spinoff (Amrize) creating new top-five US competitor