# AMD — Advanced Micro Devices, Inc.

## Where this sits in the AI stack
AMD sells silicon and, increasingly, integrated rack-scale systems at three layers: (1) the GPU accelerator (Instinct MI300X/MI325X shipping, MI350X/MI355X ramping, MI400/MI450 in 2H26) for training and inference; (2) the host CPU (EPYC Turin shipping, Venice on TSMC N2 in 2H26) that pairs with both its own and NVIDIA's accelerators; and (3) the system layer — rack design (Helios), DPU/NIC (Pensando Pollara 400G, Vulcano 800G), and the ROCm software stack [1][2][8][16]. Functionally, AMD is the only credible merchant alternative to NVIDIA across CPU + GPU + DPU + rack, but its competitive position is sharpest on **inference of small-to-medium models** where memory capacity matters more than all-to-all interconnect bandwidth, and weakest on **multi-node frontier training** where NVLink/NVL72-class scale-up is the binding constraint [3][11].

## Snapshot

- **Price:** $455.19 (2026-05-08 close) [4]
- **Market cap:** ~$742B [4]
- **52-week range:** $106.98 – $456.25 [4]
- **Forward P/E:** ~63× on FY26 consensus [4]
- **EV / NTM revenue:** ~14–15× (EV ~$734B against an inferred NTM revenue of ~$48–52B based on Q1 actual $10.3B and Q2 guide $11.2B ±$0.3B) [4][14] — note: inferred, not directly sourced
- **Consensus 12-month price target:** ~$443 (range $250–$625 across 35 analysts; recent post-Q1 upgrades clustered $450–$525) [5]
- **YTD total return:** approximately +130% to +200% inferred — from March 31 the stock has risen +123.76% through 2026-05-08 alone; explicit YTD figure not directly sourced [4]
- **Short interest (% of float):** 2.19% (35.65M shares) [4]

## Moat — what it is physically made of

AMD's moat is composite, weaker than NVIDIA's on software, but real and growing on hardware and systems. Decomposing:

**1. CPU franchise (durable, high-margin).** EPYC reached ~29–34% server CPU revenue share by Q4 2025, up from <1% in 2017 [6]. Zen 5 "Turin" scales to 192 cores; Zen 6 "Venice" on TSMC N2 ramps in 2H26 to 256 cores [6][17]. This is the closest thing AMD has to a CUDA-equivalent moat: every AI rack needs host CPUs for orchestration, and AMD's chiplet+IFOP architecture has compounded a multi-year process advantage over Intel that survived even Intel 18A. Lisa Su's $120B server CPU TAM-by-2030 estimate (doubled from $60B prior) hinges on this [7]. Durability: **high** — Intel's recovery requires both node parity and architecture parity simultaneously, and ARM server share remains stuck in the low double digits.

**2. Advanced packaging allocation.** AMD holds ~11% of TSMC CoWoS allocation in 2026 versus NVIDIA's ~60% [8][9]. Translating CoWoS wafers to delivered GPUs at ~30 packages per wafer and ~130k wafer/mo total capacity by late 2026, AMD's share supports on the order of 4–5M GPU-equivalents/year — sufficient to meet announced OpenAI/Meta 6 GW each commitments only if allocation expands. This is **a binding physical constraint**, not a moat — AMD competes for the same CoWoS-L lines, the same HBM4 stacks, the same Pensando/Marvell SerDes, and the same ZT Systems-style integration labor as everyone else.

**3. HBM supply qualification.** AMD has qualified Samsung's HBM4 (where NVIDIA has not), Micron HBM3e and HBM4 16-Hi, and SK Hynix HBM3e 12Hi on MI350 [10]. The MI355X carries 288GB HBM3e (vs B200's 180GB), and MI400 carries 432GB HBM4 — a structural memory-capacity advantage for inference of mixture-of-experts and long-context models where KV cache size dominates [3][11]. Durability: **medium** — NVIDIA can match in one product cycle; the advantage is timing, not architecture.

**4. ZT Systems engineering acquisition.** AMD retained ~1,000 system-design engineers and divested manufacturing to Sanmina for $3B [13][26]. The actual moat here is *not* manufacturing — it is the rack-integration domain expertise that lets AMD ship "Helios" as a coherent product rather than a bag of components. NVIDIA had this since Mellanox/in-house DGX; AMD bought it. Durability: **medium-high** — replicating ~1,000 EE/ME/thermal/firmware engineers in a hyperscale rack context is a 2–3 year, $1B+ undertaking even with capital.

**5. ROCm software stack — the weakest link.** SemiAnalysis is unambiguous: AMD's RCCL is "a carbon copy fork of NCCL" and is the bottleneck on multi-node performance; ROCm 7 claims 3.5× over ROCm 6 on inference but still trails CUDA on disaggregated prefill, wide expert parallelism, and FP4 kernels [11]. CUDA has 6M developers, 600+ libraries, 40M+ toolkit downloads, and ~20 years of accumulated kernel optimizations [15]. HIP can port the bulk of CUDA code with <5% rewrite, but specialized kernels (TensorRT-LLM, Transformer Engine, cuDNN-attention) require dedicated rewrites. Durability: **low-medium** — this is the moat to watch erode (in AMD's favor) over the next 24 months as PyTorch 2.6+ first-class ROCm support, vLLM upstream optimization, and hyperscaler in-house kernel teams (Meta, Microsoft) accelerate parity [12]. Hardware is increasingly commoditized by these abstractions, which is the point.

**6. Networking IP via Pensando + UALink.** Vulcano 800G NIC qualifies for MI400 in 2H26; supports both UALink and Ultra Ethernet [16][27]. UALink 200G 1.0 spec (March 2025) supports up to 1,024 accelerators per pod at 200 Gbps/lane, with AMD/Intel/Broadcom/Meta/Microsoft/Google as consortium board [19][20]. **Critical nuance**: MI400's "UALoE72" is actually "UALink over Ethernet" — a rebrand of Infinity Fabric over Ethernet using Broadcom Tomahawk 6 switches, not native UALink silicon [3]. Native UALink silicon won't ship in volume until late 2026/2027. So this moat is *forward-looking and consortium-dependent*; today, NVLink 5 still delivers 1.8 TB/s per GPU vs UALink 1.0's 800 Gb/s [19].

**Net moat assessment:** AMD has assembled the *components* of a credible #2 platform — CPU dominance, HBM-rich GPU, rack engineering, NIC, open interconnect consortium — but the integration layer (ROCm + RCCL + collective comms tuning + kernel libraries) is 12–24 months behind NVIDIA. The moat is real but porous, and depends on hyperscaler subsidization of the software gap (Meta, OpenAI, Microsoft all internally investing in ROCm).

## AI buildout bottleneck map

The actual 2026–2027 gating constraints, with AMD's posture against each:

| Bottleneck | Status | AMD posture |
|---|---|---|
| **Grid interconnect / transformers** | ~7 GW shortfall vs 12–16 GW committed for 2026; PJM queue backlog >2,600 GW, 5-yr waits [21] | Indifferent — affects all merchant silicon equally |
| **TSMC CoWoS-L** | ~130k wafers/mo by late 2026, NVIDIA reserved ~60%, AMD ~11% [8][9] | **Exposed customer** — capped allocation is the hardest cap on AMD's revenue |
| **HBM4 supply** | SK Hynix dominant (62% share); Samsung qualified at AMD; Micron capacity sold out for 2026 [10][22] | **Beneficiary** — qualified Samsung as a second source faster than NVIDIA did |
| **TSMC N2** | 40k wpm late 2025 → 100k 2026 → 200k 2027; Apple monopolizes early; Venice EPYC + MI450 compute die both on N2 [17] | Exposed customer — late entry behind Apple, dependent on 2027 expansion |
| **Liquid cooling at >100 kW/rack** | MI355X is 1,400W; Helios racks ~150 kW range [3] | Supplier-agnostic — ZT integration helps but cooling vendors are independent |
| **ROCm kernel/compiler talent** | RCCL underdeveloped, FP4 lagging, wideEP missing [11] | **Constraint owner** — AMD's internal hiring and Silo AI integration are the rate-limiter |
| **Optical interconnect (CPO, 800G+)** | Ultra Ethernet ramp 2026–2027; CPO at Broadcom/Marvell | Beneficiary via Pensando Vulcano 800G in 2026 [16] |
| **Frontier training data** | Mostly NVIDIA-side concern; affects training capex demand | Indirect exposure — slower frontier scaling could shift mix toward inference, where AMD is stronger |

The two binding upstream constraints for AMD specifically are **CoWoS-L allocation** and **internal software engineering throughput**. Power constrains the whole industry symmetrically.

## Competitive teardown

**vs. NVIDIA Blackwell (B200/GB200 NVL72) — shipping now.** On *single-node FP4 inference*, MI355X delivers within 10–20% of B200 throughput on Llama-class models with 33% lower TCO for self-owned clusters and 1.2–1.3× higher throughput on some vLLM workloads — driven by 288GB vs 180GB HBM [3][23][29]. On *rack-scale frontier inference*, MI355X loses badly: 18× slower than GB200 NVL72 on all-to-all collective ops because MI355X tops out at an 8-GPU coherent scale-up domain via mesh XGMI vs NVL72's 72-GPU all-to-all NVLink fabric [3]. The MI355X is "competitive with HGX B200 for small-to-medium model inferencing but it will not be competitive against the GB200 NVL72" for large frontier reasoning models [3]. SemiAnalysis InferenceMAX shows MI355X beating B200 at high throughputs but GB200 still cheapest for top-end workloads [29].

**vs. NVIDIA Vera Rubin (VR200 NVL144) — 2H26.** VR200: 50 PFLOPS FP4, 288GB HBM4, 22 TB/s, 336B transistors on N3P, NVL144 rack-scale [24]. MI455X (in Helios): 40 PFLOPS FP4 per GPU, 432GB HBM4, 19.6 TB/s, 72 GPUs per rack [1][2]. **AMD has more memory per GPU (1.5×) and more memory per rack; NVIDIA has higher per-GPU FP4 throughput (25% higher) and a denser scale-up domain (NVL144 vs 72)**. The MI500 UAL256 is AMD's response, slated for late 2027 with native UALink at 256 chips [3]. Critical timing point: SemiAnalysis flags that mass production for MI455X UALoE72 may slip to Q2 2027, while NVIDIA Rubin is on schedule for 2H26 [25]. **This 6–9 month gap is the single most important competitive variable.**

**vs. Broadcom + Google TPU.** Broadcom signed a long-term TPU design contract through 2031; Google TPU shipments projected at 4.3M units in 2026, growing to 35M by 2028 [30]. Counterpoint puts Broadcom at 60% of custom AI silicon share by 2027 [30]. Custom ASIC growth is 45% in 2026 vs 16% GPU growth — a real competitive concern but **mostly substitutes for NVIDIA share inside hyperscalers, not for AMD's merchant share** at non-hyperscale buyers (Oracle, sovereign clouds, OpenAI's compute outside Google). Google's TPU does not threaten AMD's OpenAI/Meta/Oracle/Microsoft positions directly.

**vs. AWS Trainium2/Inferentia, Microsoft Maia, Meta MTIA.** These are real but lagging on training capability; primarily used for first-party inference of well-known workloads. Meta's 6 GW AMD deal explicitly signals that AMD remains complementary to (not replaced by) MTIA. The risk is **Meta and Microsoft using AMD as bridge silicon while internal ASICs catch up** — a multi-year tailwind that could compress in 2028–2029.

**vs. Intel Gaudi 3 / Falcon Shores.** Not competitive. Intel exited rack-scale GPU competition for AI training; Falcon Shores reduced to a development vehicle. Intel risk to AMD now lives entirely in EPYC vs Xeon, not in AI accelerators.

## Bull case — technical

The bull case requires four conjunctions:

1. **MI455X ships on schedule in 2H26 at competitive perf/watt vs VR200** — within 15% on rack-level FP4 inference per dollar. The first 1 GW of OpenAI MI450 begins deployment 2H26 per the 8-K filing [18][14].
2. **ROCm 7+ closes the kernel gap on FP4/wideEP/disaggregated prefill within 12 months**, validated by InferenceMAX showing AMD within 10% of Blackwell-class TCO across the workload mix [11][29]. Hyperscaler kernel teams (Meta, Microsoft, OpenAI) co-developing kernels accelerates this; SemiAnalysis explicitly states "Speed is the moat" and AMD's chips can be competitive *if* software speeds up [11].
3. **CoWoS allocation expands from 11% to 15%+ by 2027** as TSMC ramps 150k wafers/mo, alongside meaningful TSMC N2 access for MI500 [9][17].
4. **Hyperscaler capex stays >$650B in 2026 with merchant silicon retaining ≥50% of accelerator share** — i.e., custom ASICs don't displace merchant GPUs faster than expected [21].

**Base rate context:** When the #2 merchant player in a rapidly growing platform reaches technical parity (or near-parity) on most axes with the #1, share gains historically run 3–5 percentage points per year over 5–7 years (cf. AMD's own server CPU trajectory 2017–2025 — 1% to 34%, ~4 pp/yr [6]; AMD's PC client trajectory 2016–2024). If AMD reaches 20–25% accelerator share by 2028 (vs ~12% today by some estimates [26]), at a $400–500B accelerator TAM, AMD AI revenue alone is $80–125B — far above current consensus. The technical predicate is parity; the business predicate is dual-sourcing pressure from hyperscalers who don't want NVIDIA monopoly pricing on inference.

## Bear case — technical

A short-seller who reads the stack would write:

1. **The ROCm gap is structural, not catch-uppable in 24 months.** RCCL is a NCCL fork; AMD has no equivalent to NVSHMEM, no FP4 kernel parity, no production-grade Triton-equivalent backend, and the engineering org sized to close it (Silo AI ~300 people + internal teams) is an order of magnitude smaller than NVIDIA's CUDA + DGX SW org. SemiAnalysis flags FP4 fixes "wouldn't occur until after the Chinese New Year as the majority of related engineers are based in China" — operational warning sign [11].

2. **Rack-scale is the workload that actually grows.** Frontier-model inference (reasoning, agentic, long-context) requires NVL72-class all-to-all bandwidth. MI355X loses 18× on collectives; MI455X UALoE72 uses Ethernet (not native UALink silicon), giving up the latency/lossless advantage; mass production may slip to Q2 2027 [3][25]. By the time MI455X is volume, NVIDIA is shipping Rubin Ultra (announced for 2027) and the gap re-opens.

3. **CoWoS allocation is a hard cap, not a target.** NVIDIA's ~60% reservation through 2027 means AMD physically cannot grow accelerator share past ~15% even if it sells everything it can build [8][9]. Stock pricing in 25%+ share is pricing in capacity AMD does not have.

4. **The OpenAI/Meta warrants are dilutive at the prices the bull case requires.** Combined 320M shares warranted at $0.01 strike = ~20% dilution at full vest [14]. At the $600 final-tranche price, OpenAI's 160M shares = $96B value — paid by existing shareholders. Bull case multiples must be discounted by ~17–20% dilution.

5. **Custom ASICs accelerate (45% in 2026) and compress merchant share faster than expected.** If TPU/Trainium take 35–40% of hyperscaler internal inference by 2028, the merchant accelerator TAM shrinks materially, and AMD's wins are concentrated in Oracle + sovereigns + tier-2 — a smaller pond than the bull case requires [30].

6. **Forward P/E ~63× and EV/NTM revenue ~14–15× already discount near-perfect execution.** At these multiples, any 2027 production slip, any software benchmark slip vs Rubin, any hyperscaler capex cut prints a 30%+ drawdown without any actual moat erosion.

## Market view check

At ~$455 (May 8 close), AMD trades at ~63× forward EPS and ~14–15× EV/NTM revenue, with a market cap of $742B — having more than doubled from $203 on March 31 and roughly 4× off the 52-week low of $107 [4]. Consensus PT is ~$443, implying analysts now see negligible upside; post-earnings upgrades to $500–525 are catching up to spot, not leading [5]. The market is apparently pricing **execution on MI450/Helios in 2H26 plus 20–25% accelerator share trajectory through 2028, plus zero ROCm-stack stumbles**. That is consistent with the bull case described above — i.e., the market is *already* paying for the technical scenario where AMD reaches inference parity with Blackwell-class racks. **The asymmetry is no longer cheap**: the upside requires a clean win on MI455X *and* meaningful software closure, while the downside includes both technical slips and warrant dilution. This is no longer a misunderstood-moat thesis; it's an execution-on-schedule thesis at a high multiple. A sell-side analyst writing "AI tailwind, raise PT to $525" is paying for outcomes that, on the technical reading, are roughly 60% probable — which doesn't justify another leg up from here without new information.

## 90-day falsifiers

Specific, observable updates between now and ~2026-08-08:

- **AMD Q2 2026 earnings (early August):** Data center segment >$6.5B and Q3 guide >$12.5B would confirm OpenAI/Meta deployments are pulling forward; <$6B or Q3 guide <$11.5B is a meaningful negative.
- **MLPerf Training v5.2 / Inference v6.1 submissions (mid-Q3):** MI355X submissions on frontier reasoning workloads (DeepSeek R1-class, OpenAI o-series equivalents) reaching within 15% of GB200 NVL72 perf-per-dollar would falsify the rack-scale bear case; failing to do so confirms it.
- **First MI450 deployment confirmation at OpenAI (per 8-K, 1 GW in 2H26):** Any slip past Q4 2026 — flagged by either AMD on the Q2 call or by OpenAI/Microsoft capex commentary — is a direct hit to the bull case [18].
- **NVIDIA GTC Fall / Rubin shipping milestone:** Confirmation Rubin VR200 NVL144 reaches first customer in 2H26 on schedule resets the competitive timing clock; any slip is a tailwind for MI400.
- **TSMC Q2 2026 earnings commentary on 2027 CoWoS allocation by customer:** Any directional signal that AMD's allocation grows from ~11% toward 15% is a meaningful positive; any signal that NVIDIA share grows toward 65–70% is negative.
- **Hyperscaler capex revisions on Q2 calls (MSFT, META, GOOGL, AMZN, ORCL):** Aggregate 2026 capex guide change of >±$30B materially moves the AMD revenue trajectory.
- **ROCm 7.5 / vLLM upstream merge of MI355X-optimized FP4 kernels and disaggregated prefill:** Independent benchmark posts (SemiAnalysis InferenceMAX cadence) showing AMD closing >50% of the FP4 gap to B200 within the quarter is a direct refutation of the software bear case [11].
- **Samsung HBM4 yield / qualification status updates:** AMD's second-source HBM4 advantage erodes if Samsung yields slip or if NVIDIA qualifies Samsung in parallel.

## What I could not verify

- Exact AMD share of TSMC CoWoS-L specifically (vs total CoWoS) in 2026–2027 — sources state ~11% overall but the L-variant allocation is undisclosed.
- AMD's actual cost-per-MI355X-package and resulting gross margin on data center accelerators (AMD doesn't disclose segment-level gross margin).
- The technical specifics of "UALoE72" — whether it offers true memory-semantic load/store across 72 GPUs or merely high-bandwidth messaging; SemiAnalysis describes it as "Infinity Fabric over Ethernet" but the wire protocol details are not public [3].
- ROCm developer count — AMD does not disclose; CUDA's 6M is from NVIDIA's 10-K [15]. ROCm is "a small fraction" per third-party sources but no firm number exists.
- Real-world OpenAI MI450 deployment plan — the 8-K confirms 1 GW initial deployment 2H26 but the actual data center site, ZT/Sanmina rack delivery cadence, and inference-vs-training mix are not public.
- AMD's 2026 NTM revenue consensus — derived by inference from Q1 actual + Q2 guide; the explicit consensus figure was not directly sourced.
- AMD's exact YTD 2026 total return — sourced data shows +123.76% from March 31 only; year-start price not confirmed.
- The fraction of MI450/Helios revenue that flows back to OpenAI/Meta as warrant share value vs incremental cash to AMD — depends on stock-price-target tranche timing.

## Sources

[1] https://www.tomshardware.com/tech-industry/artificial-intelligence/amd-touts-instinct-mi430x-mi440x-and-mi455x-ai-accelerators-and-helios-rack-scale-ai-architecture-at-ces — retrieved 2026-05-10 — Helios rack specs: 72 MI455X, 31 TB HBM4, 1.4 PB/s, 2.9 FP4 exaFLOPS
[2] https://www.nextplatform.com/compute/2026/02/23/amd-says-helios-racks-and-mi400-series-gpus-on-track-for-2h-2026/4092199 — retrieved 2026-05-10 — MI400 timing and architecture detail
[3] https://newsletter.semianalysis.com/p/amd-advancing-ai-mi350x-and-mi400-ualoe72-mi500-ual256 — retrieved 2026-05-10 — RCCL is NCCL fork; MI355X 18× slower than GB200 NVL72 on all-to-all; UALoE72 is rebranded IF-over-Ethernet using Broadcom Tomahawk 6
[4] https://stockanalysis.com/stocks/amd/statistics/ — retrieved 2026-05-10 — Price $455.19, market cap $742B, 52-wk range, short interest 2.19%
[5] https://www.marketbeat.com/stocks/NASDAQ/AMD/forecast/ — retrieved 2026-05-10 — Consensus PT ~$443, range $250–$625, recent Bernstein $525
[6] https://www.kad8.com/news/amd-hits-record-x86-market-share-in-q4-2025/ — retrieved 2026-05-10 — EPYC share trajectory 1% (2017) to ~29–34% (Q4 2025)
[7] https://www.benzinga.com/markets/tech/26/05/52311020/amd-lisa-su-ai-server-cpu-boom-120bn-revenue-opportunity — retrieved 2026-05-10 — $120B server CPU TAM-by-2030, doubled from $60B
[8] https://wccftech.com/nvidia-alone-has-tsmc-advanced-packaging-lines-booked-for-several-years-ahead/ — retrieved 2026-05-10 — NVIDIA ~60% CoWoS, AMD ~11% in 2026
[9] https://www.digitimes.com/news/a20251210PD218/tsmc-cowos-capacity-nvidia-equipment.html — retrieved 2026-05-10 — TSMC CoWoS expansion to 130k wpm by late 2026
[10] https://techstock01.substack.com/p/sk-hynix-and-micron-hbm4-qualification — retrieved 2026-05-10 — Samsung qualified at AMD on HBM4, not NVIDIA; AMD using Samsung HBM3e on MI350
[11] https://newsletter.semianalysis.com/p/amd-2-0-new-sense-of-urgency-mi450x-chance-to-beat-nvidia-nvidias-new-moat — retrieved 2026-05-10 — MI355X lags on disaggregated prefill, wideEP, FP4; "Speed is the moat"
[12] https://www.thundercompute.com/blog/rocm-vs-cuda-gpu-computing — retrieved 2026-05-10 — ROCm closing CUDA gap to ~10–30% in many workloads; PyTorch first-class
[13] https://www.eetimes.com/amd-takes-a-systems-approach-to-ai-with-zt-acquisition/ — retrieved 2026-05-10 — ZT Systems 1,000+ engineers retained, Sanmina manufacturing divest
[14] https://ir.amd.com/news-events/press-releases/detail/1260/amd-and-openai-announce-strategic-partnership-to-deploy-6-gigawatts-of-amd-gpus — retrieved 2026-05-10 — OpenAI 6 GW deal, MI450 first 1 GW 2H26, warrant terms
[15] https://s201.q4cdn.com/141608511/files/doc_financials/2025/q4/177440d5-3b32-4185-8cc8-95500a9dc783.pdf — retrieved 2026-05-10 — NVIDIA 10-K: 5.9M+ developers; 40M+ CUDA toolkit downloads
[16] https://www.servethehome.com/amd-vulcano-800g-nic-coming-as-amd-outlines-its-ualink-and-uec-scale-plans/ — retrieved 2026-05-10 — Vulcano 800G NIC qualifies for MI400, supports UALink + UEC
[17] https://www.tomshardware.com/pc-components/cpus/amds-first-2nm-chip-is-out-of-the-fab-epyc-venice-fabbed-on-tsmc-n2-node — retrieved 2026-05-10 — Venice on N2, 256-core Zen 6; TSMC N2 capacity ramp 40k→100k→200k wpm
[18] https://ir.amd.com/financial-information/sec-filings/content/0001193125-25-230895/d28189d8k.htm — retrieved 2026-05-10 — 8-K filing on OpenAI warrant: 160M shares, $0.01 strike, milestones to $600 price target
[19] https://www.tomshardware.com/tech-industry/ualink-has-nvidias-nvlink-in-the-crosshairs-final-specs-support-up-to-1-024-gpus-with-200-gt-s-bandwidth — retrieved 2026-05-10 — UALink 200G 1.0 specs: 1,024 GPUs, 200 Gbps/lane vs NVLink 5 at 1.8 TB/s/GPU
[20] https://www.sdxcentral.com/news/ualink-consortium-releases-200g-10-specification-for-ai-accelerator-interconnects/ — retrieved 2026-05-10 — UALink consortium membership: AMD, Intel, Meta, HPE, AWS, Astera, Cisco, Google, Microsoft
[21] https://introl.com/blog/hyperscaler-capex-690-billion-microsoft-azure-power-bottleneck-2026 — retrieved 2026-05-10 — Hyperscaler capex $650B+ in 2025-26; 7 GW power shortfall in 2026; transformer lead times 5 yr
[22] https://www.astutegroup.com/news/general/sk-hynix-holds-62-of-hbm-micron-overtakes-samsung-2026-battle-pivots-to-hbm4/ — retrieved 2026-05-10 — SK Hynix 62% HBM share; HBM4 supply landscape
[23] https://www.tomshardware.com/pc-components/gpus/amd-announces-mi350x-and-mi355x-ai-gpus-claims-up-to-4x-generational-gain-up-to-35x-faster-inference-performance — retrieved 2026-05-10 — MI350X/MI355X specs; 288GB HBM3e
[24] https://developer.nvidia.com/blog/inside-the-nvidia-rubin-platform-six-new-chips-one-ai-supercomputer/ — retrieved 2026-05-10 — VR200 spec: 50 PFLOPS FP4, 288GB HBM4, 22 TB/s, 336B transistors
[25] https://newsletter.semianalysis.com/p/inferencex-v2-nvidia-blackwell-vs — retrieved 2026-05-10 — MI455X UALoE72 mass production may slip to Q2 2027
[26] https://markets.financialcontent.com/siliconvalley.com/article/marketminute-2026-2-5-amds-49-billion-bet-on-zt-systems-pays-off-the-new-front-in-the-ai-infrastructure-war — retrieved 2026-05-10 — ZT Systems integration outcomes; ~12% AMD AI accelerator share claim
[27] https://www.amd.com/en/blogs/2026/next-gen-networking-transport-for-large-scale-ai-training.html — retrieved 2026-05-10 — Pensando MRC, Vulcano 800G qualification for MI400
[28] https://ir.amd.com/news-events/press-releases/detail/1284/amd-reports-first-quarter-2026-financial-results — retrieved 2026-05-10 — Q1 2026 revenue $10.3B, data center $5.8B (+57% YoY), Q2 guide $11.2B
[29] https://newsletter.semianalysis.com/p/amd-vs-nvidia-inference-benchmark-who-wins-performance-cost-per-million-tokens — retrieved 2026-05-10 — InferenceMAX cost-per-token comparisons; MI355X 3× cheaper than MI325X
[30] https://oplexa.com/broadcom-google-tpu-deal-2026/ — retrieved 2026-05-10 — Broadcom-Google TPU contract through 2031; custom ASIC growth 45% in 2026 vs GPU 16%; Broadcom 60% custom AI silicon share by 2027