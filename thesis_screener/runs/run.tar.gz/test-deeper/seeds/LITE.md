# LITE — Lumentum Holdings Inc.

## Where this sits in the AI stack
Lumentum is a vertically integrated **indium-phosphide (InP) photonics** house. It owns its own InP wafer fabs (San Jose / Rose Orchard Way; Sagamihara and Takao in Japan; Caswell in UK; new Greensboro NC ramp targeted mid-2028) and ships at three layers of the AI optical stack: (1) the **discrete light source**: 200G/lane Electro-absorption Modulated Lasers (EMLs) for pluggable transceivers, Continuous-Wave (CW) DFB lasers for silicon-photonics modules, and Ultra-High-Power (UHP) lasers for External Laser Source (ELS) modules used by NVIDIA's Spectrum-X / Quantum-X co-packaged optics; (2) **transceiver modules** at 800G / 1.6T (post-Cloud Light acquisition, 2023, $750M); (3) **MEMS-based Optical Circuit Switches (OCS)** for top-of-fabric scale-up. It also retains a meaningful telecom presence (980nm EDFA pump lasers, narrow-linewidth lasers used in coherent ZR/ZR+). The workload it serves is the **scale-out and emerging scale-up fabric** of frontier-training and inference AI factories, not the GPU package itself. [1][2][3][4][5][6]

## Snapshot

- **Price:** $903.80 (close 2026-05-08) [7][8]
- **Market cap:** ~$64.8B [7]
- **52-week range:** $63.98 – $1,021.00 [8]
- **Forward P/E:** ~49–57× on calendar-NTM EPS; ~62× on FY27 (Jun-2027) consensus EPS of $14.55, ~119× on FY26 EPS of $7.60 [7][8][9]
- **EV / NTM revenue:** ~14× (per Stockanalysis); on FY27 consensus revenue of $4.71B and EV ≈ $61.6B (mkt cap less $3.17B net cash post-NVIDIA equity), ~13× [7][9][10]
- **Consensus 12-month price target:** $1,025–$1,130 (JPM at $1,130, Daily Political composite $1,025); implied +13–25% from spot [11][12]
- **YTD total return:** +145% (per Finviz; +158% per other sources) [8]
- **Short interest (% of float):** 12.54% (April-15 settlement) [13]

## Moat — what it is physically made of
Lumentum's moat is concentrated in **InP epitaxy and high-volume EML/DFB process integration**, not in software, brand, or scale-of-balance-sheet. Decomposed:

1. **200G/lane EML laser chip.** This is the only piece of silicon in the system that can drive a 1.6T pluggable transceiver lane today. Citi (Mar-2026) puts Lumentum at ~80% volume share with Coherent ~20%; Mitsubishi, Sumitomo, and Broadcom EMLs are reportedly in a ~15-month qualification cycle and not at volume in 1.6T modules. [3][14] The technical difficulty is not the laser cavity but the **200G NRZ / 100Gbaud PAM4 modulation bandwidth at sub-1pJ/bit power and operating temperatures up to 75–85°C** in a transceiver — these require specific MQW (multi-quantum-well) absorption-region designs and on-die thermal management that are process-locked to Lumentum's San Jose 3"/4" InP line and Sagamihara-Takao 3" lines. Reproducing these at parity requires multi-year epi recipe iteration plus AEC-Q-grade reliability data. **Durability:** ~2–3 years before second sources have credible volume. This is a real but **time-bound** moat. [3][6][14]

2. **CW DFB and UHP ULPL lasers for SiPh / CPO ELS.** When you move from pluggables to co-packaged optics, the EML inside the module is replaced by an **external CW laser** feeding a SiPh modulator. NVIDIA's Spectrum-X Photonics and Quantum-X Photonics name **Lumentum and Coherent** as ecosystem partners providing the high-power CW lasers for the detachable ELS modules (Furukawa is the third). [15][16] This means CPO **does not destroy Lumentum's TAM** — it shifts laser content per port from EML → CW/ULPL, and per-port laser content actually rises because CPO ELS units feed many SiPh modulators per laser. The same InP epi platform is leveraged. [17]

3. **MEMS Optical Circuit Switch (R64, R300).** A different physics — electrostatically actuated tilting mirror arrays — but high-margin and structurally moaty: Google built its own MEMS-OCS internally (Apollo, in production for years), and Lumentum's pitch is the only **merchant** alternative for non-Google hyperscalers. Management has flagged a >$400M OCS backlog shipping H2 CY26. The moat here is not the mirror itself but the closed-loop alignment, fiber-array packaging, and reliability data that have already been productionized. **Durability:** moderate; competitors are MEMS specialists who have not built optical-grade alignment yields at production scale. [18][9]

4. **Cloud Light transceiver platform.** Acquired Nov-2023 for $750M; >50% of CL revenue was already 800G at acquisition. This is **module assembly**, where margins are thinner and the moat is much weaker — Innolight, Eoptolink, Hisense, Accelink compete aggressively. Lumentum's edge is captive lasers (vertical integration) and Hong Kong/Thailand manufacturing automation, but this layer is not where the franchise is durable. [19][20]

5. **Telecom EDFA pumps and narrow-linewidth lasers.** 980nm pump lasers up 80% YoY in Q3 FY26, narrow-linewidth assemblies up >120% YoY for nine consecutive quarters — this is the long-haul ZR/ZR+ and submarine cable market, currently strong because hyperscalers are building data-center interconnect (DCI) capacity. Real franchise, modest growth multiplier. [1]

**What the moat is not.** It is **not** a software ecosystem (no CUDA-equivalent), **not** patents that block — InP EML patents are largely expired or cross-licensed across the legacy JDSU/Finisar/Mitsubishi/NTT lineage. The defensibility is **process knowledge + fab capacity + qualification time**, all of which decay against committed competitor capex.

## AI buildout bottleneck map
Mapping the 24-month gating constraints, with LITE's position on each:

- **CoWoS-L advanced packaging** at TSMC: oversubscribed through 2026, NVIDIA holds ~60% of total CoWoS allocation. [21] **LITE position: indirect customer-exposed.** If CoWoS yields slip on Rubin Ultra (already cut from 4-die to 2-die), GPU shipments slip → optics demand slips one quarter behind.
- **HBM3e/HBM4 yield:** SK Hynix, Samsung, Micron — not LITE-relevant directly, but constrains GPU shipments. **LITE position: indifferent / second-order.**
- **200G/lane EMLs:** management says supply lags demand by **>30%**; lead times beyond 2027. [1][14] **LITE position: constraint owner / primary beneficiary.** This is the part of the bottleneck map LITE *is*.
- **Optical interconnect supply (transceivers and CW/UHP lasers):** TrendForce projects 800G+ unit shipments rising 24M (2025) → ~63M (2026), 2.6×. [2] **LITE position: beneficiary; partial constraint owner via laser-chip captivity.**
- **CW lasers for CPO ELS:** new constraint emerging as Spectrum-X Photonics ramps H2-2026. **LITE position: named NVIDIA ecosystem partner alongside Coherent and Furukawa.** [15][16]
- **Liquid cooling at >100kW/rack and grid interconnect:** real bottlenecks for AI factory commissioning, but **LITE indifferent** — these throttle when AI factories light up, but not what LITE specifically sells into.
- **DSP / DSP-less analog (LPO) talent and silicon:** Marvell and Broadcom DSPs/LPO drivers are gating for 1.6T module ramps. **LITE position: exposed customer** — they buy DSPs from Marvell/Broadcom for Cloud Light modules, and LPO architectures *reduce* DSP content while preserving laser content (a slight positive).
- **Kernel/compiler talent:** N/A. LITE is not a software franchise.
- **Electrical contractor / turbine / interconnect queue capacity:** not LITE-specific.

The crisp summary: LITE owns the **most specific, most provable** bottleneck (200G EML, CW UHP for CPO) on the bottleneck map, but is **downstream-exposed** to the more upstream bottlenecks (CoWoS, HBM, GPU yield) — if Rubin slips, EML demand timing slips with it.

## Competitive teardown

**Coherent (COHR)** — the closest substitute. Same vertical-integration model (InP fab, transceiver assembly, telecom). Coherent's Q3 FY26 commentary: doubling InP output capacity by next quarter, doubling again by end-2027; ramping both EML and SiPh-based 1.6T transceivers at "ballpark" same gross margin; **200G VCSEL** development (a different topology — VCSELs are cheaper and lower-power than EMLs but historically capped at shorter reach) progressing for some CPO/NPO use cases. [22] On the technical axes: roughly at parity on SiPh/CPO laser supply (NVIDIA gave them the same $2B), but **Coherent trails Lumentum at 200G EML volume by ~4× per Citi**, and Coherent has more diversified non-AI exposure (industrial lasers from the legacy II-VI side). The case for Coherent over LITE is broader gross-margin expansion runway and lower starting valuation; the case for LITE over Coherent is purer EML mix and OCS optionality.

**Marvell (MRVL) and Broadcom (AVGO)** — *not* primary EML competitors, but **adjacent threats**. Both are pushing **LPO chipsets** (Marvell's 200G/lane TIA + driver in GA; Broadcom's 3nm Taurus DSP) that would push Cloud Light–style assemblies toward DSP-less designs. [23] At 1.6T per lane, **pure LPO faces >30W thermal headroom problems**, and the consensus next step is LRO (Linear Receive Optics, half-DSP) rather than full LPO — meaning DSP content is not zero but is squeezed. Net for LITE: laser content protected, transceiver-module margin pressured.

**Mitsubishi Electric, Sumitomo Electric** — historic InP/EML players. Both have 200G EML samples but, per the 15-month qualification window, are not in volume in 1.6T modules in 2026. They are the **most credible second-source threat** by 2027–2028. The Japanese InP supply chain is real and will catch up; the question is timing.

**Broadcom photonics (Sian/Aeolus)** — Broadcom announced its own EMLs and 200G PAM4 silicon. Volume exposure is unclear and tied to Broadcom's own ASIC/optics co-design programs (Tomahawk Ultra, Jericho4). Not yet a 2026 share-shifter.

**NVIDIA's own SiPh / CPO** — the long-term existential question. NVIDIA's Spectrum-X Photonics integrates the SiPh engine into the switch ASIC, meaning the **pluggable transceiver disappears for that switch port**. But NVIDIA still needs an external CW laser → LITE is named partner. The risk is *timing* of how fast CPO replaces pluggables in the scale-out fabric (Spectrum-X) and scale-up fabric (Quantum-X). LightCounting frames this as "the first step in a long journey" and pluggable optics will coexist for many years; the financial outcome depends on whether the transceiver TAM is hollowed out faster than the CW-laser TAM expands. [24][25]

**Internal hyperscaler programs** — Google's MEMS-OCS internally; Meta-led OCP optical efforts; Microsoft has been quiet but is rumored to be exploring CPO partnerships. Risk: an Amazon/Microsoft equivalent of Google Apollo would compress LITE's OCS opportunity below the $400M+ backlog narrative.

**Base rate on technology displacement.** In analogous platform shifts — DRAM ASIC at 1Gb (Korea/Japan caught up in 3–5 years), HBM (SK Hynix held lead 2014–2024 = decade), CoWoS (TSMC lead persists 7+ years), CUDA (>15 years and counting) — the **process-locked, qualification-gated moats compress in 24–48 months once second-source capex is committed**. NVIDIA's $4B equity injection accelerates capex at LITE/Coherent but also signals to Mitsubishi/Sumitomo/Broadcom that the prize is large enough to fund their own 200G ramps. Two-year base case for second sources is reasonable; calling it permanent is unsupported by history.

## Bull case — technical
- **200G EML undersupply persists through CY27.** Mitsubishi/Sumitomo/Broadcom 200G qualifications slip past CY27 due to MQW-process maturity issues, leaving LITE+Coherent as the only volume sources. EML ASPs continue to absorb double-digit price increases with no end-customer pushback because the 1.6T module is gating $50K+ GPUs. [14]
- **CPO ramp on schedule, additive, not substitutive.** NVIDIA Spectrum-X Photonics ships H2-26 in volume. Each CPO switch consumes 6+ ELS modules with ULPL lasers; Lumentum's San Jose UHP capacity is the named source. CPO removes pluggable transceivers from the inter-leaf layer but LITE keeps the laser content, while the broader 800G/1.6T pluggable TAM continues to grow at the leaf-to-spine layer. [15][16][26]
- **OCS adoption broadens beyond Google.** Meta and Microsoft begin pulling on Lumentum R-series OCS at ~70%+ gross margin for scale-up fabrics in Rubin Ultra and post-Rubin clusters; the >$400M backlog narrative shows up as bookings beats in Q1–Q2 FY27. [9][18]
- **Vertical integration captures Cloud Light margin.** As LITE ramps captive 200G EMLs into Cloud Light 1.6T modules at scale, transceiver gross margin expands 300–500 bps versus competitors who buy EMLs on the merchant market.
- **Bottleneck map upstream clears (CoWoS-L doubles to 150K wafers in 2026), so LITE is *not* downstream-throttled.** [21]

If each holds, FY27 EPS lands at or above $14.55 consensus; FY28 reaches the management-floated $30 EPS scenario; the stock at 30–40× FY28 = $900–$1,200 with no multiple expansion.

**Base-rate caveat.** In the 24-month tail of a process-locked moat in a hyper-cyclical capex industry, the modal outcome is *partial* erosion (second source gets 20–30% share), not permanence. The bull case requires the displacement clock to run slower than history says.

## Bear case — technical
- **Mitsubishi or Sumitomo qualifies a 200G EML at one or two top-3 module makers (Innolight, Eoptolink) by mid-CY27.** Even 20% volume share from a credible second source breaks the pricing power; ASPs compress 15–25% as buyers dual-source. [14]
- **CPO timing surprises in either direction and both hurt.** If Spectrum-X CPO ramps fast (NVIDIA scales millions of GPUs on Quantum-X), Cloud Light pluggable revenue (~25–30% of revenue) decelerates faster than ULPL/CW expands. If CPO ramps slowly (yield issues on the SiPh/laser interface — fiber attach, alignment, ELS reliability remain hard), the multibillion NVIDIA purchase commitments slip and the laser-content uplift is deferred. The middle case is best for LITE; the tails are worse.
- **LPO/LRO compresses transceiver gross margin.** If 1.6T LPO/LRO solves thermals (Marvell + Broadcom both in market), pluggable module GM goes from ~25% to ~18%; Cloud Light becomes a low-quality revenue stream. [23][27]
- **OCS demand stays Google-only.** Meta and Microsoft prefer all-electrical InfiniBand-style scale-up; the $400M backlog is a one-customer story; OCS revenue plateaus at <$300M annualized.
- **NVIDIA captures laser supply economics by 2028.** The $2B equity stake plus capacity rights structure may give NVIDIA a most-favored-customer pricing mechanism on UHP lasers; LITE's CPO-era gross margin is below the EML-era margin even on higher revenue.
- **InP wafer/epi capacity comes online faster than demand at the next-next node (400G/lane).** Industry has historically over-supplied transitions when capex is forced by hyperscalers; 400G/lane (3.2T modules) timing in CY28 may collide with Coherent's 2× InP doubling and Mitsubishi/Sumitomo capex.
- **Industrial & Consumer (legacy 3D-sensing VCSEL for Apple) drag continues.** Already -45% YoY, this is now <15% of revenue but the absolute revenue base loss is still real. [28]

## Market view check
At $903.80 the market is paying ~62× FY27 (Jun-27) consensus EPS of $14.55, ~13–14× FY27 EV/sales, with a +145% YTD ramp on Q3 FY26 90% YoY revenue growth and the NVIDIA $2B strategic deal. Consensus PT $1,025–$1,130 implies +13–25%. Short interest at 12.5% of float is heavy and suggests a real two-sided debate. **The market is implicitly underwriting that the EML moat persists at >70% margin contribution through CY28 *and* that CPO ELS revenue substitutes/exceeds any pluggable-transceiver disintermediation.** That is a credible base case but not the *modal* technology-displacement outcome on a 24–36 month base rate. The price is not obviously wrong, but it is pricing the bull tail; it is not a margin-of-safety entry. A pullback to $700–$750 (≈50× FY27, ≈11× EV/sales) would be a price more consistent with a balanced technical thesis.

## 90-day falsifiers
- **NVIDIA Q2-CY26 earnings (~late-August 2026):** any delay disclosed for Spectrum-X Photonics volume shipment beyond H2-CY26, or commentary that copper-only Rubin scale-up is sufficient through 2027. Bearish for the CPO/ULPL upside.
- **Coherent fiscal Q4 2026 earnings (~mid-August):** if Coherent's InP-doubling progress is *ahead* of schedule and reports 200G EML volumes within 30% of Lumentum, share-shift narrative accelerates.
- **MLPerf Inference v5.1 / OFC fall workshop (Sep 2026):** any independent submission showing Mitsubishi or Sumitomo 200G EML qualified into a top-3 module-maker reference design. This is the cleanest single falsifier.
- **Lumentum Q4 FY26 earnings (mid-August 2026):** EML lead-time guidance — if the ">30% supply-demand imbalance" narrows to "in line by mid-CY27," that is a tell that second source is closer than the bull case requires; conversely if lead times push further out, it confirms the moat duration.
- **NVIDIA / Meta / Microsoft public comments on OCS in scale-out fabric:** any Meta/Microsoft adoption announcement of merchant MEMS-OCS would validate the OCS bull case beyond the Google-only narrative.
- **TrendForce / LightCounting monthly module pricing data:** double-digit 200G EML ASP increases continuing into Q3 CY26 confirms pricing power; any rollover is a leading indicator of second-source qualification.
- **Hyperscaler CY26 capex revisions:** if Q2 CY26 earnings (~late-July through August) show >10% sequential cuts to AWS/Azure/GCP capex guidance, the demand assumption breaks and LITE's >50× multiple is exposed.

## What I could not verify
- The specific **MQW design / epitaxy recipe lead time** Mitsubishi / Sumitomo / Broadcom face on 200G EMLs. The "15-month qualification" number is sourced to Citi but I could not confirm independently against EML-specific reliability protocols (Telcordia GR-468 / hyperscaler internal qual matrices).
- **Per-port CW/UHP laser content uplift** in NVIDIA Quantum-X vs. equivalent pluggable-based scale-up (i.e., $/laser content per port). NVIDIA disclosed engine architecture but per-unit laser revenue is not public.
- The **exact share** of Q3 FY26 revenue tied directly to NVIDIA vs. NVIDIA-attached hyperscalers vs. Arista/Cisco/Juniper switch OEMs. Management says >60% of revenue is "AI/cloud" but does not break out NVIDIA concentration risk explicitly.
- **OCS competitive landscape beyond Google.** Whether Meta, Microsoft, AWS are in active OCS pilots with LITE specifically — only inferred from "$400M+ backlog" commentary, customer mix is undisclosed.
- Whether the rumored **Coherent 200G VCSEL** for CPO/NPO is technologically credible at the data rates and reach required, or is more demo than productionizable.
- **Forward P/E** numbers vary widely across data sources (49× Finviz vs 57× Stockanalysis vs ~62× on FY27 EPS) due to fiscal-year vs calendar-year vs TTM blends — I have given the range, but no single figure is canonical.
- The **Rubin Ultra yield issue** (4-die → 2-die) was sourced to second-hand reporting; the actual technical root cause (CoWoS-L bridge stitching vs. HBM stack mechanical) is not publicly confirmed.

## Sources
[1] https://www.fool.com/earnings/call-transcripts/2026/05/06/lumentum-lite-q3-2026-earnings-transcript/ — retrieved 2026-05-10 — Lumentum Q3 FY26 transcript: $808M revenue +90% YoY, EML units 2× YoY, supply-demand imbalance >30%, NVIDIA $2B in cash on balance sheet, narrow-linewidth +120% YoY, 980nm pump +80% YoY.
[2] https://www.communicationstoday.co.in/over-800g-optical-transceiver-shipments-to-soar-2-6x-by-2026/ — retrieved 2026-05-10 — TrendForce 800G+ unit shipments 24M (2025) → 63M (2026), 2.6× growth.
[3] https://www.lumentum.com/en/blog/emls-unsung-heroes-powering-ais-digital-arteries — retrieved 2026-05-10 — LITE EML role in 800G/1.6T optics; 200G/lane positioning.
[4] https://www.lumentum.com/en/products/data-center/cw-lasers/cw-lasers-sipho-transceivers — retrieved 2026-05-10 — CW DFB lasers for SiPh transceivers built on shared InP DFB platform.
[5] https://www.lumentum.com/en/products/external-laser-source-els-module-ultra-high-power-laser — retrieved 2026-05-10 — LITE ELS UHP module for CPO with detachable optical connector.
[6] https://www.semiconductor-today.com/news_items/2026/mar/lumentum-260326.shtml — retrieved 2026-05-10 — Greensboro NC InP fab announcement, mid-2028 ramp target.
[7] https://stockanalysis.com/stocks/lite/statistics/ — retrieved 2026-05-10 — LITE close $903.80 (May-08-2026), market cap $64.80B, forward P/E 57.07, EV/sales 14.29.
[8] https://finviz.com/quote.ashx?t=LITE — retrieved 2026-05-10 — LITE 52-week range $63.98–$1,021.00, YTD +145.20%, 1Y +1,276%, fwd P/E 49.21, consensus PT $1,102.
[9] https://www.tickerreport.com/banking-finance/13415536/lumentum-fy2027-eps-forecast-boosted-by-northland-securities.html — retrieved 2026-05-10 — Normalized EPS FY25 $2.06 → FY26 $7.60 → FY27 $14.55; revenue $2.91B FY26 → $4.71B FY27; OCS backlog >$400M H2-CY26.
[10] https://seekingalpha.com/news/4586526-lumentum-anticipates-960m-1_01b-q4-fy2026-revenue-while-targeting-2b-quarterly-revenue-goal — retrieved 2026-05-10 — Q4 FY26 guide $960M-$1.01B; $2B/qtr 24-month target.
[11] https://www.dailypolitical.com/2026/05/09/lumentum-nasdaqlite-price-target-raised-to-1130-00.html — retrieved 2026-05-10 — JPM raises PT to $1,130, Overweight.
[12] https://public.com/stocks/lite/forecast-price-target — retrieved 2026-05-10 — average analyst PT $1,024.72; 13 buy, 5 hold, 0 sell.
[13] https://www.marketbeat.com/stocks/NASDAQ/LITE/short-interest/ — retrieved 2026-05-10 — Short interest 12.54% of float (Apr-15-2026 settlement), down from 16.1% prior month.
[14] https://www.trendforce.com/presscenter/news/20251208-12823.html — retrieved 2026-05-10 — NVIDIA EML supply lock-in extending lead times beyond 2027; second-source qualification slip; pricing/allocation pressure.
[15] https://nvidianews.nvidia.com/news/nvidia-spectrum-x-co-packaged-optics-networking-switches-ai-factories — retrieved 2026-05-10 — Spectrum-X Photonics CPO architecture; 102.4 Tb/s; 128 ports × 800G; Quantum-X 115 Tb/s, 144 × 800G.
[16] https://www.semiconductor-today.com/news_items/2025/mar/lumentum-180325.shtml — retrieved 2026-05-10 — LITE named NVIDIA SiPh ecosystem partner for AI networking.
[17] https://www.viksnewsletter.com/p/why-cpo-uses-external-lasers — retrieved 2026-05-10 — Rationale for ELS over integrated lasers in CPO: thermal isolation and serviceability.
[18] https://gazettabyte.com/lumentums-optical-circuit-switch-for-ai-data-centres/ — retrieved 2026-05-10 — LITE R-series MEMS OCS architecture and Google Apollo internal-MEMS context.
[19] https://www.businesswire.com/news/home/20231030099888/en/Lumentum-to-Acquire-Cloud-Light-to-Accelerate-Data-Center-Speed-and-Scalability — retrieved 2026-05-10 — Cloud Light $750M acquisition, >50% revenue from 800G modules.
[20] https://convergedigest.com/lumentum-revenue-soars-90-as-ai-data-center-optics-drive-record-quarter/ — retrieved 2026-05-10 — Q3 FY26 segment mix: components 66%, systems 34%; AI/cloud >60% of revenue.
[21] https://wccftech.com/nvidia-alone-has-tsmc-advanced-packaging-lines-booked-for-several-years-ahead/ — retrieved 2026-05-10 — NVIDIA ~60% CoWoS allocation through 2026; 595K wafers booked; CoWoS-L oversubscribed.
[22] https://www.fool.com/earnings/call-transcripts/2026/05/06/coherent-cohr-q3-2026-earnings-transcript/ — retrieved 2026-05-10 — Coherent Q3 FY26: $1.81B rev, doubling InP capacity by next quarter, 200G VCSEL development, EML+SiPh 1.6T parallel ramps.
[23] https://www.marvell.com/company/newsroom/marvell-introduces-1-6-tbps-lpo-chipset.html — retrieved 2026-05-10 — Marvell 200G/lane TIA + driver chipset for 800G/1.6T LPO.
[24] https://www.lightcounting.com/research-note/march-2025-nvidias-cpo-is-the-first-step-in-a-long-journey-395 — retrieved 2026-05-10 — LightCounting framing CPO as long-tail transition, pluggables coexist.
[25] https://blog.apnic.net/2025/05/07/co-packaged-optics-a-deep-dive/ — retrieved 2026-05-10 — CPO architecture deep-dive; ELS rationale; thermal/yield constraints.
[26] https://newsletter.semianalysis.com/p/co-packaged-optics-cpo-book-scaling — retrieved 2026-05-10 — SemiAnalysis CPO scaling and adoption curve; named partners.
[27] https://eps.ieee.org/wp-content/uploads/2026/03/Linear-Pluggable-Optics_V2-UPDATED.pdf — retrieved 2026-05-10 — IEEE PHO-TC LPO overview: 1.6T LPO power constraints (>30W) and LRO emergence.
[28] https://markets.financialcontent.com/stocks/article/finterra-2026-4-7-the-light-engine-of-ai-a-comprehensive-deep-dive-into-lumentum-holdings-lite — retrieved 2026-05-10 — Industrial & Consumer -45% YoY; Apple multi-source dynamics; segment mix Cloud & Networking 88% of FY25 revenue.