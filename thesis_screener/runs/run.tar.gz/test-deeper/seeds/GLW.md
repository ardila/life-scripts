# GLW — Corning Incorporated

## Where this sits in the AI stack
Corning sits at the **physical-layer interconnect** of the AI buildout: it draws the silica optical fiber, manufactures the cabled assemblies, and increasingly the connectors (MTP/MPO and its denser MMC) that carry traffic both **inside** AI factories (rack-to-rack scale-out, soon scale-up over photonics) and **between** them (DCI / metro). It is not a transceiver, switch ASIC, or optics-packaging vendor — its product is the glass and the cable assemblies that surround it. The relevant workload is **distributed training and large-scale inference** on multi-thousand-GPU fabrics, where every GPU pair is fiber-connected through MPO/MMC trunks because copper has run out of reach above ~3m at 800G/1.6T per lane. Corning also has secondary AI exposure via Hemlock Semiconductor (hyper-pure polysilicon, now in the new "Solar" segment) and a much smaller display/specialty glass franchise [1][2][3].

## Snapshot
- **Price:** $186.94 (2026-05-08 close; $182.40 prior close 2026-05-07) [4]
- **Market cap:** ~$160.5B [5]
- **52-week range:** $46.34 – $198.25 [6]
- **Forward P/E:** 52.3× (on FY26 consensus) [5]
- **EV / NTM revenue:** ~8.5× — inferred from ~$160.5B mcap + ~$5B net debt vs. ~$19.5B NTM sales (Q2 guide $4.6B run-rated) [5][7]
- **Consensus 12-month price target:** ~$172 (MarketBeat consensus); recent sell-side raises Citi $225, UBS $223, Oppenheimer $210 — the consensus is stale relative to spot [5][8]
- **YTD total return:** +83% to +102% (depending on May date) [6]
- **Short interest (% of float):** n/a — could not source a clean April/May 2026 reading; historical run-rate is low single digits but unverified post-NVIDIA deal

## Moat — what it is physically made of
Calling Corning's moat "scale" is wrong. It is **five distinct layers**, each of which a competitor would need to replicate:

**1. Outside Vapor Deposition (OVD) preform process and the proprietary furnaces.** Corning invented OVD in the 1970s and has continuously patented improvements (e.g., WO2004014812A1, US7441417B2, US20040244426A1) on burner geometry, soot deposition rate, and consolidation furnace design [9]. A preform is grown to parts-per-**billion** contaminant levels [10] — closer to a CVD reactor than a commodity glass process. Corning self-builds the furnaces; it does not buy them off the shelf. Capex floor for a credible new preform line is ≥$50M, plus ~18–24 months to qualify yields [11]. This is the deepest layer.

**2. Specific AI-era fiber geometries.** SMF-28 **Contour** moves cladding+coating OD from 250µm down to ~190µm with G.657.A1 bend resilience, yielding **40% lower cross-sectional area and ~54% lighter** cable for a given count [12]. Combined with **Rollable Ribbon** (12 fibers tacked at intervals rather than fully bonded), Corning achieves up to **6,912 fibers in a 29mm-OD cable** that fits a 1.5"–2" duct [13]. For hyperscalers facing the constraint that AI campuses need ~10× more fiber than legacy DCs [14], duct/conduit density is what determines whether new builds are even possible without redigging — not price per kilometer.

**3. Connector density (MMC).** Corning's MMC connector packs ~3× the fibers per ferrule of a traditional MPO at roughly half the footprint [15]. At 1.6T per port and 100Tb/s+ switch radixes (NVIDIA Spectrum-6800: 512 × 800G [16]), fiber-pair count per rack explodes and connector real estate becomes the hard ceiling.

**4. Multi-year capacity-reservation contracts.** Lumen reserved **10% of Corning's global fiber capacity** for 2024–25 [17]. Meta then committed up to **$6B over multiple years** with the Hickory NC plant as anchor [18]. NVIDIA followed in May 2026 with $500M of pre-funded warrants for 3M shares plus warrants for an additional 15M shares at a $180 strike — gross value up to ~$3.2B — alongside three new fiber/optical-connectivity factories in NC and TX [19][20]. Q1 2026 disclosed **two more unnamed hyperscaler deals "similar in size and duration" to the Meta agreement** [21]. Once a hyperscaler dedicates a multi-year fiber purchase order against a Corning-anchored facility, switching costs are physical, not just contractual — the cable plant is qualified to a specific fiber vendor's loss/PMD/bend profile.

**5. Vertical integration through cable, connectivity, and now Microsoft's hollow-core IP.** Most fiber competitors stop at the cable. Corning extends to connectivity and field-installed solutions — and, critically, in 2026 became Microsoft's lead manufacturing partner (with Heraeus) for the **DNANF (Double-Nested Antiresonant Nodeless Fiber)** hollow-core platform, working from the Hickory, NC site [22]. This is the moat layer most likely to be misread: HCF is the textbook "displacing" technology, but Corning has been pulled inside the disruptor's tent rather than left outside it.

Honest assessment of durability: layers 1 and 2 are durable on a 5–7 year horizon (process know-how + patents + qualified part-numbers in customer BOMs). Layer 3 (MMC) is durable for 2–3 years until rivals catch up — connectors are easier to copy than glass. Layer 4 is contractually durable through ~2028–2030 but does **not** guarantee share at re-bid. Layer 5 is the bet — if Microsoft's HCF IP becomes the industry reference design, Corning's manufacturing partnership is enormously valuable; if Prysmian's Relativity-Networks line in Eindhoven [23] or YOFC's HollowBand (claimed 0.04 dB/km at MWC 2026 [24]) ships at parity volume sooner, the manufacturing partnership is just one of several second-source options.

## AI buildout bottleneck map
What is actually gating the next 24 months of frontier AI buildout, and where Corning sits:

- **Power generation / grid interconnect.** Gas turbine backlogs at GE Vernova / Siemens Energy / Mitsubishi stretch ~5 years; U.S. interconnection queues now average ~5 years; ~30% of new DC capacity in 2026 is BYOP [25]. **Corning: indifferent / mildly exposed** — DCs cannot light fiber they cannot power. This is the upstream gate on Corning's TAM realization.
- **Advanced packaging (TSMC CoWoS-L/-S).** Capacity ramping ~35K wpm (late-2024) → ~130K wpm (end-2026); fully booked through 2026; NVIDIA holds >60% allocation [26]. **Corning: indifferent** — it does not ship into the package. (A **possible** future exposure via glass core substrates exists; Intel and Samsung are leading, with Corning's name appearing far less than AGC, SCHOTT, or Samsung Electro-Mechanics in glass-core substrate roadmaps. Mass adoption is 2027–2030 [27]. **Treat as optionality, not thesis.**)
- **HBM3e/HBM4 supply.** Allocated through 2026 [26]. **Corning: indifferent.**
- **Optical interconnect supply (fiber, cable, connectors, transceivers).** Corning + Prysmian + YOFC = >40% of preform [28]; Fujikura up ~160% in 2025 on optics demand [29]. AI DCs need ~10× the fiber of legacy DCs [14]. Co-packaged optics in NVIDIA Quantum-X (early 2026) and Spectrum-X Photonics (H2 2026) **increases** fiber count per switch even as it removes pluggable transceivers, because every CPO port still terminates in fiber [30]. **Corning: prime beneficiary and one of the constraint owners.**
- **Liquid cooling at >100kW/rack.** Vertiv, CoolIT, BoydCorp, Asetek. **Corning: indifferent.**
- **Hyper-pure polysilicon (semi-grade).** Hemlock Semiconductor. Tight market. **Corning: supplier (Solar segment +80% YoY in Q1 2026)** [21][3]. Secondary, but real.
- **Kernel/compiler/distributed-systems talent.** **Corning: indifferent.**

Net: Corning is on the right side of the **fiber/connector** bottleneck, neutral or upstream-exposed elsewhere.

## Competitive teardown
- **Prysmian (Italy).** True peer in preform/draw scale and now the manufacturing arm for **Relativity Networks' HCF** at Eindhoven [23]. Has historically won submarine and density-leading cable specs. Axis where Prysmian is at parity *today*: standard SMF preform output, submarine. Axis where Corning leads: AI-DC-specific small-OD fibers (Contour) and connectivity portfolio. Axis to watch: HCF — Prysmian/Relativity vs. Microsoft/Corning is effectively a two-track HCF race.
- **YOFC (China).** ~12% global cable share, 300M core-km/yr capacity [31]. Cost leader; export-restricted in Western hyperscaler BOMs by tariff and procurement preference but ships heavily to non-aligned markets and Tier-2 cloud. **HollowBand HCF claim of 0.04 dB/km (MWC 2026)** [24] is a credible technical signal — if it is independently reproduced, the assumption that HCF is a Western duopoly is wrong.
- **Sumitomo Electric / Fujikura (Japan).** Strong in submarine (Sumitomo: ~40% submarine market) and in **6,912-fiber rollable ribbon** (Sumitomo has its own design) [32]. Fujikura ships ~75% of fiber output as exports including to Alphabet [29]. Direct head-to-head with Corning at Western hyperscalers on standard SMF.
- **Heraeus (Germany).** Co-manufacturer with Corning of Microsoft DNANF [22]. Not a finished-cable competitor — preform/specialty glass — but if Microsoft chooses to dual-source DNANF cabling, Heraeus could split the value over time.
- **CommScope, AFL, Belden.** Connectivity / cable assembly competitors. None match Corning vertical depth into the fiber itself; they assemble around it.
- **STL Tech, Hengtong (China/India).** Volume preform; less relevant to Western hyperscaler AI-DC SKUs.

For a competitor to *take share at the AI-DC SKUs* (small-OD bend-insensitive single-mode + ultra-high-count rollable ribbon + MMC-class connectors), they need to (a) match Contour-class fiber geometry in volume, (b) ship a connector at MMC density, and (c) qualify into hyperscaler BOMs that are now multi-year contracted. Prysmian and Sumitomo can plausibly do (a) and (b); none of them can do (c) on Meta or NVIDIA's already-signed footprint without those contracts re-opening. Prysmian's HCF play is the cleanest path to leapfrogging rather than catching up.

## Bull case — technical
The technical conditions that need to hold:
1. **800G/1.6T per-lane scale-out continues to require fiber, not copper.** Already true at >3m reach; intensifies as XPUs scale up in 2026–2028.
2. **CPO (NVIDIA Quantum-X / Spectrum-X Photonics) ramps as planned in 2026.** CPO removes pluggable transceiver volume but **increases external fiber count per switch ASIC** because more lanes become optical natively [30] — a net positive for Corning's fiber and MMC connector volumes.
3. **Hollow-core fiber adoption is gradient, not step-function, and Corning is on the manufacturing side of Microsoft's variant.** Microsoft's Q1 2026 disclosure: 1,280 km live HCF in Azure, 0.091 dB/km loss [22]. If HCF takes 5–10% of Microsoft DCI by 2028 and Corning manufactures it, GLW captures the disruption rather than absorbing it.
4. **The two unnamed hyperscaler agreements convert in 2026.** Adding up to ~$12B in multi-year contracted backlog to the existing Meta and NVIDIA structures.
5. **Hemlock polysilicon stays tight,** giving Solar segment a multi-year tailwind orthogonal to fiber.

Base rate check: when capital intensity is high, the underlying physics is mature, and the incumbent vertically integrates from raw material through finished assembly, displacement is slow. Corning has held meaningful fiber share since the mid-1970s — ~50 years — through every prior optical technology transition (multimode→single-mode, 1310→1550nm, OS1→OS2, copper-replaces in DCI). That is an unusually strong base rate. The closest analog where it failed (display glass losing position to Asian rivals) was a case of **not vertically integrating** to the panel maker; the AI-DC contracts are the opposite — Corning is being pulled down the stack into Meta's and NVIDIA's BOMs.

If those conditions hold, the company hits its $40B annualized run-rate target by end-2030 [33], with Photonics contributing $10B+ of incremental revenue [33], and ~22% operating margin sustains. That implies ~$8B+ net income by 2030 — at $160B mcap, ~20× exit P/E, justifiable at the bull-case growth rate.

## Bear case — technical
Symmetric, written as a short-seller who reads the stack:
1. **AI capex digestion in 2026–2027.** A single quarter of >10% sequential hyperscaler capex guidance cut would reset growth assumptions on a stock at 52× forward earnings. Optical Communications is now ~38% of revenue and growing fastest [7]; the multiple compresses fast if growth rate decelerates from ~36% YoY toward 15–20%.
2. **HCF adopts faster and Prysmian/Relativity wins second-source position at AWS.** "AWS wants more hollow-core fiber than it can get" [34] is consistent with a multi-vendor, supply-constrained market; if Prysmian's Eindhoven line ramps before Corning/Hickory and AWS qualifies on Relativity's variant, Corning is leapfrogged at one major hyperscaler. YOFC's HollowBand at 0.04 dB/km, if independently confirmed, makes the threat global.
3. **CPO causes a near-term *connector* mix shift.** While CPO grows fiber count, it changes the MTP/MPO part numbers and breakout topologies. Hyperscalers may use the CPO transition as the natural cut-over to re-bid connectivity contracts, putting MMC's premium pricing at risk.
4. **NVIDIA's $3.2B is a warrant structure, not contracted purchase.** The $500M is funded; the additional ~$2.7B is a *right* to acquire equity at $180 — value to Corning depends entirely on share price. The market reaction (+12% on May 6) priced in $3.2B as if it were committed capex by NVIDIA. A more careful read: NVIDIA gets cheap upside on Corning and a preferred-supplier relationship, while the actual factory build is funded mostly by Corning [19][20].
5. **The base rate of customer-anchored capex.** Prior multi-year, customer-anchored fiber buildouts (e.g., the 1999–2001 telecom fiber boom) have demonstrated that "reserved capacity" can become unfilled when end-demand softens. The 1.6× preform expansion at Hickory + 3 NVIDIA-anchored plants is the largest fiber capex cycle in Corning history; if pull-through softens by even 20%, fixed-cost absorption hits margin hard.
6. **Glass core substrates in advanced packaging.** Corning's name is *not* prominent in published roadmaps at Intel, Samsung, TSMC CoPoS [27][35]. If glass substrates are where the next decade of structural glass demand lives and Corning is not at-bat, the bull narrative on "Corning = AI infrastructure glass" is misframed.

## Market view check
At ~$187 and 52× forward earnings the stock is no longer cheap on any near-term metric, but the multiple is consistent with the company's own stated trajectory: **$20B run-rate end-2026, $30B end-2028, $40B end-2030 with margins expanding** [33]. The market is pricing the bull case roughly in line with management's targets — the disagreement is whether those targets are credible. Sell-side consensus PT (~$172) is **below** spot, which means the actual marginal buyer at $187 is ahead of consensus, leaning on the May 5 investor-day Springboard upgrade and the NVIDIA deal headline rather than the slower analyst model updates [8][33]. The implicit assumption in the price: the optical communications growth rate stays >25% through 2027, and HCF is additive rather than substitutive. Both are plausible but not derisked. This is a price that requires the bull case to keep delivering quarter-by-quarter — there is no margin of safety on a multi-quarter capex pause.

## 90-day falsifiers
Things you can actually check between now and ~August 2026:
- **Q2 2026 earnings (late July).** Did Optical Communications grow ≥30% YoY again? Did the company name the two unnamed hyperscaler customers? Q2 guide was $4.6B revenue, EPS $0.73–$0.77 [33] — anything below the low end is a thesis hit.
- **Hyperscaler Q2 capex commentary** (Microsoft, Meta, Alphabet, Amazon late-July, NVIDIA late-Aug). >10% sequential cut at any of the three biggest fiber buyers (MSFT, META, GOOGL) is a falsifier.
- **NVIDIA Quantum-X commercial availability** — was it actually shipping to customers in Q1/Q2 as guided? Any slip past Q3 changes near-term fiber pull-through.
- **Independent loss measurements on YOFC HollowBand and Microsoft DNANF.** Public OFC/ECOC papers or third-party deployment numbers reproducing the 0.04 dB/km (YOFC) or 0.091 dB/km (Microsoft) claims at production volume.
- **Corning factory groundbreaking dates** at the three NVIDIA-anchored sites in NC/TX. Slips of >2 quarters indicate the headline number is softer than presented.
- **Meta and other hyperscaler 10-Q disclosures** on contracted commitments to Corning that match the announced $6B and "similar size" agreements.

## What I could not verify
- **Current short interest (% of float)** — could not source a clean April/May 2026 reading.
- **Whether Corning has a meaningful share of the *glass core substrate* market for advanced packaging.** Corning's name is conspicuously absent from public Intel/Samsung/TSMC roadmaps, but absence-of-evidence is not evidence-of-absence and Corning's CEO has alluded to "Glass Innovations" in segment-naming.
- **Customer concentration disclosure.** Meta + NVIDIA + Lumen + 2 unnamed hyperscalers likely represent >40% of Optical Communications revenue at run-rate, but the 10-Q has not yet broken this out at granularity I could cite.
- **Yields and unit economics on Microsoft DNANF at Hickory.** "Operationalize Microsoft IP" implies a manufacturing-services/royalty model for Corning, not a take-or-pay; the gross margin profile vs. standard SMF cabling is unknown.
- **Net debt and EV** — the EV/NTM revenue figure is back-of-envelope; I did not pull the May 2026 balance sheet.
- **YOFC HollowBand 0.04 dB/km claim** has been asserted at MWC but not independently reproduced in peer-reviewed measurement that I could find.

## Sources
[1] https://www.corning.com/optical-communications/worldwide/en/home/the-signal-network-blog/data-centers-and-artificial-intelligence.html — retrieved 2026-05-10 — Corning's framing of AI DC fiber demand (~10× legacy)
[2] https://www.corning.com/worldwide/en/the-progress-report/crystal-clear/optical-fiber-makes-artificial-intelligence-possible — retrieved 2026-05-10 — Corning Gen-AI fiber product positioning
[3] https://www.businesswire.com/news/home/20260427020032/en/Corning-Announces-Strong-First-Quarter-2026-Financial-Results-1 — retrieved 2026-05-10 — Q1 2026 segment reorganization (Glass Innovations + Solar)
[4] https://www.tradingkey.com/news/market-movers/261848514-market-movers-glw-20260501 — retrieved 2026-05-10 — May 2026 GLW price levels
[5] https://www.gurufocus.com/term/forward-pe-ratio/GLW — retrieved 2026-05-10 — Forward P/E and market cap 5/2026
[6] https://stockanalysis.com/stocks/glw/ — retrieved 2026-05-10 — 52-week range and YTD return
[7] https://www.spglobal.com/market-intelligence/en/news-insights/research/2025/10/cornings-optical-segment-set-for-39percent-growth-in-2025-amid-ai-infrastructure-boom — retrieved 2026-05-10 — Optical segment 2025 size and share of total
[8] https://www.marketbeat.com/stocks/NYSE/GLW/forecast/ — retrieved 2026-05-10 — Consensus PT and analyst raises
[9] https://patents.google.com/patent/WO2004014812A1/en — retrieved 2026-05-10 — Sample OVD process patents
[10] https://www.corning.com/optical-communications/worldwide/en/home/products/fiber/manufacturing-excellence.html — retrieved 2026-05-10 — OVD process; ppb purity
[11] https://www.gminsights.com/industry-analysis/fiber-optic-preform-market — retrieved 2026-05-10 — Preform manufacturing entry capex (~$50M+)
[12] https://csmedia.corning.com/optical-communications/cala/en/home/products/fiber/optical-fiber-products/smf-28-contour-fiber.html — retrieved 2026-05-10 — SMF-28 Contour 190µm, 40% smaller area
[13] https://www.flukenetworks.com/blog/cabling-chronicles/6912-fiber-cable-now-thats-testing — retrieved 2026-05-10 — 6,912-fiber rollable-ribbon cable, conduit fit
[14] https://news.lumen.com/2024-08-01-Corning-and-Lumen-Reach-Supply-Agreement-on-Next-Generation-Fiber-Optic-Cable-to-Support-Data-Center-AI-Demands — retrieved 2026-05-10 — 10× fiber claim and Lumen capacity reservation
[15] https://www.corning.com/data-center/worldwide/en/home/solutions/mmc-connectors.html — retrieved 2026-05-10 — MMC vs MPO density (~3×)
[16] https://nvidianews.nvidia.com/news/nvidia-spectrum-x-co-packaged-optics-networking-switches-ai-factories — retrieved 2026-05-10 — NVIDIA Spectrum-X / Quantum-X port counts
[17] https://www.datacenterfrontier.com/design/article/55130320/lumen-reserves-10-of-corning-fiber-optic-cable-production-to-support-ai-in-the-data-center — retrieved 2026-05-10 — Lumen 10% capacity reservation
[18] https://about.fb.com/news/2026/01/meta-6-billion-agreement-corning-support-us-manufacturing/ — retrieved 2026-05-10 — Meta up to $6B agreement
[19] https://nvidianews.nvidia.com/news/nvidia-and-corning-announce-long-term-partnership-to-strengthen-us-manufacturing-for-ai-infrastructure — retrieved 2026-05-10 — NVIDIA-Corning partnership announcement
[20] https://www.bloomberg.com/news/articles/2026-05-06/nvidia-buys-500-million-of-rights-for-stock-in-corning — retrieved 2026-05-10 — Warrant structure: $500M funded + 15M shares at $180 strike
[21] https://finance.biggo.com/news/US_GLW_2026-04-28 — retrieved 2026-05-10 — Q1 2026 call: 2 additional hyperscaler "Meta-sized" deals
[22] https://techcommunity.microsoft.com/blog/azurenetworkingblog/microsoft-azure-scales-hollow-core-fiber-hcf-production-through-outsourced-manuf/4455953 — retrieved 2026-05-10 — Microsoft DNANF, Corning + Heraeus manufacturing, 1,280 km deployed, 0.091 dB/km
[23] https://www.datacenterdynamics.com/en/news/relativity-networks-strikes-hollow-core-fiber-production-partnership-with-prysmian/ — retrieved 2026-05-10 — Prysmian / Relativity HCF Eindhoven
[24] https://en.yofc.com/ — retrieved 2026-05-10 — YOFC HollowBand HCF MWC 2026 claim (0.04 dB/km)
[25] https://newsletter.semianalysis.com/p/how-ai-labs-are-solving-the-power — retrieved 2026-05-10 — Power, turbine backlog, BYOP shift
[26] https://markets.financialcontent.com/wral/article/tokenring-2026-1-1-the-great-packaging-pivot-how-tsmc-is-doubling-cowos-capacity-to-break-the-ai-supply-bottleneck-through-2026 — retrieved 2026-05-10 — CoWoS ramp 35K→130K wpm; NVIDIA 60% allocation
[27] https://www.trendforce.com/news/2026/04/13/news-tsmc-advances-panel-level-packaging-copos-pilot-line-reportedly-set-for-june-completion-2028-29-ramp-eyed/ — retrieved 2026-05-10 — TSMC CoPoS / glass-substrate timeline 2028–29
[28] https://www.snsinsider.com/reports/fiber-optic-preform-market-9063 — retrieved 2026-05-10 — Top-3 preform share >40%; market structure
[29] https://www.fastbull.com/news-detail/fujikura-surges-160-in-2025-as-ai-data-4350901_0 — retrieved 2026-05-10 — Fujikura +160% in 2025 on AI fiber demand
[30] https://developer.nvidia.com/blog/scaling-ai-factories-with-co-packaged-optics-for-better-power-efficiency/ — retrieved 2026-05-10 — NVIDIA CPO architecture, fiber implications
[31] https://en.yofc.com/list/240.html — retrieved 2026-05-10 — YOFC capacity ~300M core-km, ~12% global cable share
[32] https://sumitomoelectric.com/sites/default/files/2022-04/download_documents/E94-15.pdf — retrieved 2026-05-10 — Sumitomo small-diameter 6,912-fiber rollable ribbon
[33] https://www.businesswire.com/news/home/20260505616158/en/Corning-Upgrades-and-Extends-Springboard-Plan-Outlines-New-Phase-of-Accelerating-Growth — retrieved 2026-05-10 — Springboard upgrade: $20B/$30B/$40B run-rate by 2026/28/30; Photonics MAP $10B by 2030
[34] https://www.fierce-network.com/cloud/aws-wants-more-hollow-core-fiber-it-can-get — retrieved 2026-05-10 — AWS HCF demand exceeds supply
[35] https://wccftech.com/intel-backed-glass-substrates-tech-will-be-commercilization-ready-within-three-years/ — retrieved 2026-05-10 — Glass-core substrate roadmap; Corning not prominent