# BKNG — Booking Holdings Inc.

## Where this sits in the AI stack
BKNG operates at the **application / distribution layer** — the very top of the stack — and is best understood as an *AI consumer*, not a producer. Physically, it runs an online travel marketplace (Booking.com, Priceline, Agoda, Kayak, OpenTable, Rentalcars) on standard cloud and on-prem CPU/GPU fleets, with a learned-ranking and demand-prediction stack tuned over two decades on transactional data, plus a high-throughput experimentation platform [9][10]. It buys frontier inference (primarily OpenAI's API for the AI Trip Planner, built in ~10 weeks) rather than training frontier models itself [21][1]. So almost none of the technical questions that matter for NVIDIA, AVGO, ANET, or VRT — CoWoS-L allocation, HBM3e binning, scale-up fabric, 132 kW racks — are first-order for BKNG. The first-order technical questions are at the *workload they are an application of*: real-time inference for retrieval/ranking, agentic-commerce protocol support (MCP, ACP), and whether LLM-mediated discovery disintermediates the booking funnel.

## Snapshot
- **Price:** $165.90 (May 8, 2026 close; May 10 is Sunday) [a]
- **Market cap:** ~$128.6B [a]
- **52-week range:** $150.62 – $233.58 [a]
- **Forward P/E:** ~18.0× FY consensus EPS [b]
- **EV / NTM revenue:** ~5.0–5.4× (EV ~$154B [29] / consensus FY26 revenue ~$29–30B; using TTM ~$27.7B gives ~5.6×) [29]
- **Consensus 12-mo PT:** ~$232–234 (35-analyst avg), implied +~40% upside [b][12]
- **YTD total return:** -1.3% (post-split adjusted; 25-for-1 split executed April 2, 2026) [a][23]
- **Short interest (% of float):** n/a — could not retrieve a current % directly; historically <2% (low for a mega-cap consumer name; flagged as unverified)

[a] composite of Yahoo Finance / Stockanalysis / 24/7 Wall St on the split [23]; [b] Stockanalysis / Marketscreener / Marketbeat [12].

## Moat — what it is physically made of
The "moat" is **not** silicon, kernels, or compiler depth. It decomposes into four real components, each with a different durability:

1. **Supply graph density (most durable).** ~31M total accommodation listings, including ~7M vacation rentals — the largest single global supply graph for paid lodging, materially larger than Vrbo (~2.2M) and broader than Airbnb's ~8M (which skews vacation-rental) [search]. The non-trivial part is *connectivity*: hundreds of thousands of independent and chain hotels are integrated via channel managers (SiteMinder, Cloudbeds, etc.) that BKNG took 25+ years to onboard. A new entrant cannot replicate this in <5 years even with infinite capital, because the gating step is human contracting and PMS integration per property. Genuinely defensible.

2. **The experimentation engine (durable, copyable in principle).** Booking.com runs ~1,000 concurrent A/B tests, with deployment to 75 countries / 43 languages in under an hour, sequential testing with always-valid p-values, SRM alarms, and self-serve experiment authoring [9][10]. Two decades of tested-and-shipped UI/ranking decisions are encoded in the live product. A competitor can build the platform; they cannot recover the lost-experiment knowledge corpus. Engineering blogs put the ranking platform on continuous interleaving plus A/B [9]. This is a *compounding* asset roughly analogous to what Google search ranking is — and notably, it is the substrate on which any agentic "trip planner" must run, because LLMs are demonstrably bad at hard combinatorial planning (state-of-the-art LLMs solve real-world planning at <4% feasibility without external solvers [arXiv 2404.11891]).

3. **Loyalty and direct-mix flywheel (medium durability, contested).** Direct channel mix is in the **mid-60s%**, app bookings exceed 50% of room nights, Genius Lvl 2/3 share is high-50s%, and loyalty-driven bookings exceed 30% of gross bookings [from Q4 2025 / Q1 2026 commentary]. Each percentage point of direct mix is a percentage point less paid to Google. This is real but is exactly the asset most exposed to agentic discovery (see Bear case).

4. **Brand / habit (least durable but underrated).** BKNG spent ~$7B+/year on marketing in 2024–25 [search], compounding "Booking.com" as a verb in Europe specifically. Brands survive distribution shifts (Amazon survived mobile; Netflix survived smart TVs) when they own the supply.

What is *not* part of the moat: any proprietary foundation model, any kernel/compiler advantage, any hardware contract. Their AI Trip Planner is a thin layer (10 weeks of work) over OpenAI [1][21]. If OpenAI doubled API prices tomorrow, BKNG would be inconvenienced, not impaired.

## AI buildout bottleneck map
BKNG sits at the application layer, so for almost every physical bottleneck it is **indifferent or a marginal inference customer**:

- **Power generation / grid interconnect:** indifferent. Their compute is a rounding error vs. a hyperscaler training run.
- **CoWoS-L / HBM3e supply / advanced packaging:** indifferent.
- **Optical interconnect / scale-up fabric:** indifferent.
- **>100 kW liquid-cooled racks:** indifferent.
- **Frontier inference cost (per-token economics):** **moderately exposed customer.** AI Trip Planner and agentic customer-service throughput depend on per-token costs continuing to decline. So far this has been a tailwind — costs are falling ~3–4× per year on equivalent capability — and Agoda has reported double-digit % YoY reduction in customer-service cost per booking from AI automation [1].
- **Agentic-commerce protocol standards (MCP, Agentic Commerce Protocol):** **strategic dependency.** This is the bottleneck that actually matters for BKNG. They are a pilot partner in OpenAI's "Apps in ChatGPT" via MCP [3][8] and a partner in Google AI Mode hotel/flight booking [15]. Whether the protocol standardizes around routing the *booking* back to OTAs (BKNG's preferred outcome — and OpenAI's announced posture as of March 2026 [2][18]) vs. the LLM provider closing the loop directly is the single most important technical-policy variable for the next 36 months.
- **Kernel/compiler talent:** indifferent. They need ML platform talent and search-ranking talent, which they have. They do not need CUDA kernel writers.

Net: BKNG is structurally insulated from the *physical* AI buildout but acutely exposed to the *protocol layer* of how agentic commerce gets standardized.

## Competitive teardown
The relevant competitive matrix is *not* "BKNG vs. EXPE on ad spend" — that's the sell-side note. It's a 3-axis fight:

- **Axis 1 — Other OTAs (EXPE, ABNB, TCOM/Trip.com).** On supply density, BKNG leads in EU hotels and is roughly at parity with Trip.com in APAC. On vacation rentals, ABNB still leads in mind-share and supply quality; BKNG has the listings count but weaker host tooling. EXPE's Q1 2026 commentary acknowledges AI as both reward and risk and has rolled out OpenAI integration plus Microsoft Copilot Actions — i.e., they're racing BKNG on the same agentic-distribution play [search]. **Honest read:** BKNG is ahead on direct mix and loyalty, behind ABNB on the alternative-accommodations narrative, and at parity with EXPE on AI integrations. No technical axis where BKNG is being lapped today.

- **Axis 2 — LLM providers (OpenAI, Google, Anthropic, Perplexity).** This is where the existential-sounding articles live. The empirical state, as of May 2026: OpenAI in March 2026 explicitly **walked back** in-ChatGPT checkout and is positioning ChatGPT as discovery, sending the booking to third-party apps [2][18]. Google AI Mode is integrating **with** BKNG/EXPE/Marriott rather than disintermediating them [15]. Skift summarized this as "ChatGPT can inspire the trip but OTAs still close the sale" [26]. The evidence for full disintermediation, *as of today*, is weaker than the narrative.

- **Axis 3 — Direct-booking enablement (DirectBooker, RateGain TravelOS MCP, Sabre+PayPal+MindTrip Q2 2026 pipeline).** This is the underrated threat. RateGain shipped the first MCP-enabled booking engine in late 2025 and DirectBooker has agreements with five of the top-10 hotel chains for in-ChatGPT/in-Claude direct booking [search]. Hotel chains have wanted to bypass OTAs for 20 years — they have failed because they cannot do customer acquisition. If LLM agents become the acquisition channel and route around BKNG to chain.com, the OTA take rate is structurally pressured. **This is the thesis worth tracking, not the LLM-front-end thesis.**

## Bull case — technical
For BKNG to outperform consensus over 24 months, four conditions need to hold, in roughly descending importance:

1. **Agentic-commerce protocols stabilize on a "discovery → OTA closes the sale" topology** rather than "LLM closes the sale at chain.com." OpenAI's March 2026 walkback [2][18] is a strong leading indicator that fulfillment complexity (cancellation policies, payment fraud, multi-leg pricing, regulatory KYC for travel) is hard enough that LLM providers don't want to own it. Base rate: when a regulated, low-margin, high-fraud workflow is offered to a horizontal platform, the horizontal platform almost always declines (see: why Stripe exists, why Google Travel never owned the booking flow).
2. **The supply graph remains the binding constraint.** As long as ChatGPT/Gemini agents need to query *someone's* index of 31M live-availability rooms with <500ms latency and authoritative pricing, BKNG's connectivity layer is rented, not displaced. This is plausible for 3–5 years; chain.com aggregation is not realistic at that depth.
3. **Connected Trip attach compounds.** High-20% YoY growth in multi-component transactions, flights gross bookings $16.8B in 2025 (+37%) — if attach reaches 20%+ of bookings (vs. low-double-digits today [1]), revenue per traveler steps up materially without proportional marketing spend. The flywheel is mathematically real because once a customer books a flight in-app, they don't re-Google for a hotel.
4. **Inference cost continues to decline ~3–4×/yr,** turning AI customer-service automation into a structural margin lever (Agoda already reports double-digit % cost-per-booking reduction [1]).

If 1–4 hold, the financial outcome is roughly: room-night growth in mid-to-high single digits, take-rate stable at ~10.3%, EBITDA margin grinding from 36.9% (2025) toward 40%, and the multiple re-rating from 18× forward P/E back toward its 10-year median 22×.

**Base rate caveat:** the prior platform-shift base rate for application-layer incumbents with strong supply network effects is *favorable*. In e-commerce, AMZN survived mobile; in streaming, NFLX survived smart-TV operating systems; in maps, Google Maps survived voice assistants. The displacement cases (AltaVista→Google, Yahoo→Google) involved *worse product*, not better distribution.

## Bear case — technical
A serious short thesis (not the strawman "AI will kill OTAs") is:

1. **The Google traffic top-of-funnel actually deteriorates faster than direct-mix conversion can offset it.** Zero-click search is now 69% of all queries (from 34% in 2017) [search]. Travel publishers have reported 50–70% traffic declines from AI Overviews. BKNG's direct mix is mid-60s%, meaning ~35% of bookings still depend on paid search and meta. If that channel halves over 24 months, marketing spend efficiency falls before loyalty/app can fill the gap. Q1 2026 already showed marketing up to ~$2.1B from $1.8B Q1 2025 — that is a real, observable margin headwind.
2. **The direct-booking MCP route succeeds.** If RateGain TravelOS, DirectBooker, and Sabre+PayPal+MindTrip's Q2 2026 pipeline give chain hotels a credible path to fulfill bookings inside ChatGPT/Claude/Gemini at zero OTA commission [24][25], BKNG's take rate compresses on the high-margin chain inventory and is left with the long tail of independents (which is most of the supply, but lower-yield). This is the version where the moat erodes from the *supply* side, not the demand side.
3. **Agentic discovery shifts attention away from app downloads.** The current direct flywheel (mid-50s% app share) depends on travelers having Booking.com installed. Generation Z first-trip behavior is increasingly "ask ChatGPT" rather than "open Booking app." If app installs slow, the flywheel inverts.
4. **The AI Trip Planner is a 10-week wrapper over OpenAI** [1][21] — there is no proprietary AI moat. If OpenAI/Google build a comparable trip-planning UX with their own supply integrations (which Google AI Mode is already partially doing [15]), BKNG's "AI" differentiation is performative.

The shape of the bear case is: revenue growth decelerates from low-teens to mid-single-digits over 2026–28, take-rate compresses 50–100 bps, and the 18× forward P/E de-rates toward 14× as the terminal-value question gets reopened.

## Market view check
At $165.90 (post-split), 18× forward P/E vs. a 10-year median ~22×, EV/EBITDA 16.7× vs. 10-year median ~18.7× [29], and consensus PT ~$232 implying +40%, the market is pricing **moderate skepticism** — not capitulation. The setup is consistent with "AI scare trade" framing [19][22]: financials are fine (Q1 2026 beat, +16% revenue, +20% EBITDA in 2025 [4][6]) but the multiple has compressed because of agentic-disintermediation overhang. The market appears to believe the bear case has ~30–40% probability and is sizing for it. The question is whether you think it's higher or lower than that. My read of the protocol-layer evidence (OpenAI checkout walkback [2], Google AI Mode partnership rather than displacement [15]) is that the implied probability is too high — but not so much that the dossier should be confident. The honest stance is "the multiple is interesting if you believe agentic checkout standardizes around OTAs, expensive if you don't."

## 90-day falsifiers
Concrete events to watch through ~August 2026:

1. **Q2 2026 earnings (late July / early August):** marketing spend % of revenue. If it grows >50 bps YoY *again*, the SEM-erosion thesis is confirming. If it flattens, direct mix is absorbing it.
2. **Disclosed AI Trip Planner / Apps-in-ChatGPT booking volume.** Any quantified metric (bookings sourced, conversion rate) on the earnings call would update the disintermediation thesis materially. Silence is bearish.
3. **DirectBooker / RateGain TravelOS booking volume disclosures.** If any top-10 hotel chain publishes a >5% direct-via-AI booking share by mid-2026, the bear case strengthens hard.
4. **Google AI Mode rollout: hotel-booking placements.** Whether AI Mode SERP places a "Book on Booking.com" CTA above or below the fold — observable directly via search.
5. **OpenAI re-introduces in-ChatGPT checkout for travel.** The March 2026 walkback [2][18] is the keystone of the bull case; reversal would be a thesis-breaker.
6. **EXPE Q2 2026 commentary on AI search traffic.** They have been more candid than BKNG about Google headwinds; their disclosures are a leading indicator.
7. **Hyperscaler capex commentary** for inference: a meaningful inference-capacity glut would cut BKNG's frontier-inference unit costs faster, widening the AI-customer-service margin lever.

## What I could not verify
- Current short interest as a % of float (sources existed but did not surface a current number in retrieved excerpts).
- Whether BKNG fine-tunes its own ranking-aware LLM internally or relies entirely on third-party APIs — public materials suggest the latter for the consumer-facing AI Trip Planner [21], but internal CS/ops automation may use different stacks.
- Exact 2026 Google ad spend dollars (most recent disclosed share data is 2019–21).
- Hotel-chain commission elasticity if agentic direct-booking becomes a 5%+ channel — there is no public dataset.
- The actual conversion lift of AI Trip Planner vs. the legacy search funnel; the company has been deliberately vague.
- Whether BKNG owns any GPUs or rents 100% — likely majority rented inference, but not confirmed.
- Specific contractual terms with OpenAI for "Apps in ChatGPT" routing (revenue share, exclusivity, latency SLAs).

## Sources
[1] https://www.pymnts.com/earnings/2026/booking-holdings-ai-assistants-slash-costs-and-boost-bookings/ — retrieved 2026-05-10 — Q1 2026 earnings color: Connected Trip high-20s growth, Agoda CS cost reduction, AI assistants.
[2] https://skift.com/2026/03/05/openai-chatgpt-checkout-walkback/ — retrieved 2026-05-10 — OpenAI deferring transactions to third-party apps; positive for OTAs.
[3] https://openai.com/index/introducing-apps-in-chatgpt/ — retrieved 2026-05-10 — Apps in ChatGPT launch (Oct 2025), MCP-based, Booking and Expedia as pilots.
[4] https://s201.q4cdn.com/865305287/files/doc_financials/2026/q1/Q1-2026-BKNG-Earnings-Release.pdf — retrieved 2026-05-10 — Q1 2026 financial results primary source.
[5] https://news.booking.com/bookingcom-debuts-agentic-ai-innovations-adding-to-its-robust-suite-of-genai-tools-for-customers/ — retrieved 2026-05-10 — Smart Messenger / Auto-Reply agentic AI for partner comms; 73% partner satisfaction lift.
[6] https://www.macrotrends.net/stocks/charts/BKNG/booking-holdings/revenue — retrieved 2026-05-10 — 2025 revenue $26.917B (+13.4% YoY).
[7] https://stockanalysis.com/stocks/bkng/forecast/ — retrieved 2026-05-10 — Consensus PT ~$234.42, Buy rating.
[8] https://www.phocuswire.com/openai-chatgpt-apps-expedia-booking-tripadvisor — retrieved 2026-05-10 — ChatGPT apps with Expedia, Booking, Tripadvisor.
[9] https://medium.com/booking-com-development/the-engineering-behind-booking-coms-ranking-platform-a-system-overview-2fb222003ca6 — retrieved 2026-05-10 — Ranking platform architecture, continuous interleaving + A/B.
[10] https://absmartly.com/blog/i-helped-build-the-experimentation-engine-at-booking-com-here-s-what-i-learned — retrieved 2026-05-10 — ~1000 concurrent experiments, mSPRT/always-valid p-values, deploy in <1hr to 75 countries/43 languages.
[11] https://stockanalysis.com/stocks/bkng/ — retrieved 2026-05-10 — Price/market cap reference and overview.
[12] https://www.marketbeat.com/stocks/NASDAQ/BKNG/forecast/ — retrieved 2026-05-10 — 35-analyst consensus PT, 18× forward P/E.
[13] https://www.cnbc.com/2025/05/16/ai-travel-agents-planning-future-trip-far-beyond-assistant-status.html — retrieved 2026-05-10 — AI travel agent disintermediation framing.
[14] https://research.skift.com/reports/ai-google-and-the-shift-from-keywords-to-context-in-travel/ — retrieved 2026-05-10 — Search context shift in travel.
[15] https://www.travelweekly.com/Travel-News/Travel-Technology/Hotel-and-flight-bookings-coming-to-Google-AI-Mode — retrieved 2026-05-10 — Google AI Mode integrates Booking, Expedia, Marriott rather than displacing.
[16] https://nomadlawyer.org/google-travel-positions-ai-overviews-may-2026 — retrieved 2026-05-10 — May 2026 SERP/AI Overview shift in travel.
[17] https://www.hospitalitynet.org/opinion/4132144/is-ai-search-killing-the-hotel-website — retrieved 2026-05-10 — AI search impact on hotel direct sites.
[18] https://www.phocuswire.com/news/technology/openai-chatgpt-instant-checkout-travel-intermediaries — retrieved 2026-05-10 — OpenAI's pullback from instant checkout in travel.
[19] https://markets.financialcontent.com/stocks/article/marketminute-2026-2-18-booking-holdings-q4-2025-earnings-navigating-the-ai-scare-trade-and-a-shifting-global-market — retrieved 2026-05-10 — "AI scare trade" frame on multiple compression.
[20] https://www.phocuswire.com/news/online/booking-holdings-earnings-q1-2026 — retrieved 2026-05-10 — Booking's ecosystem AI strategy, Q1 2026 commentary.
[21] https://openai.com/index/booking-com/ — retrieved 2026-05-10 — Booking.com x OpenAI partnership case study; AI Trip Planner built in ~10 weeks.
[22] https://www.businessofapps.com/data/booking-statistics/ — retrieved 2026-05-10 — Booking.com listing/property statistics.
[23] https://247wallst.com/investing/2026/03/31/a-4000-stock-is-about-to-become-affordable-inside-bookings-historic-split/ — retrieved 2026-05-10 — 25-for-1 stock split April 2, 2026.
[24] https://otelciro.com/en/news/chatgpt-hotel-bookings-0-commission-era-2026 — retrieved 2026-05-10 — Direct-booking via ChatGPT with no OTA commission.
[25] https://www.insidehs.com/ais-new-gatekeepers-hijacking-the-future-of-travel/ — retrieved 2026-05-10 — Bear-case framing on AI gatekeepers and direct-booker challengers.
[26] https://www.altexsoft.com/travel-industry-news/chatgpt-can-inspire-the-trip-but-otas-still-close-the-sale/ — retrieved 2026-05-10 — OTAs still own the booking close.
[27] https://skift.com/2025/07/18/openai-launches-chatgpt-agent-mode-what-it-could-mean-for-the-travel-industry/ — retrieved 2026-05-10 — ChatGPT agent mode implications for travel.
[28] https://www.hospitalitynet.org/news/4132086/agentic-hospitalitys-travelos-mcp-chatgpt-app-is-putting-brands-not-intermediaries-at-the-center-of-ai-bookings — retrieved 2026-05-10 — RateGain TravelOS MCP launch, hotel-direct via AI.
[29] https://www.gurufocus.com/term/enterprise-value-to-ebitda/BKNG — retrieved 2026-05-10 — EV $154.13B, EV/EBITDA 16.72×, 10-year median 18.74×.
[30] arXiv:2404.11891 — retrieved 2026-05-10 — LLMs solve <4% of real-world planning problems without external solvers; technical basis for "BKNG's combinatorial backend is a moat" claim.