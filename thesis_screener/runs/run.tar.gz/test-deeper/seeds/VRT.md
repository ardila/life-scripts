Now I have what I need. Drafting the dossier.

# VRT — Vertiv Holdings Co

## Where this sits in the AI stack
Vertiv physically sells the **non-silicon plumbing of an AI factory**: the medium-voltage switchgear, modular UPS, lithium BESS, overhead busway, rack PDUs, in-row CDUs, cold plates, manifolds, rear-door heat exchangers, chillers, and the prefab modular enclosures that hold it all — plus the field services to commission, flush, fill, and maintain those liquid loops. The relevant workload is **frontier training and large-scale rack-scale inference**: 130–142 kW NVL72-class racks today, sized toward 600 kW Kyber and 1 MW Rubin-class racks in 2027, where the workload's TDP per rack is high enough that air cooling and 54 VDC busbars stop being physically feasible.[1][2][3][4]

## Snapshot
- **Price:** $340.60 (2026-05-10)[5]
- **Market cap:** $130.6B[5]
- **52-week range:** $92.13 – $359.80[6]
- **Forward P/E:** ~52.6× (on FY26 adj. EPS guide midpoint $6.35)[7][8]
- **EV / NTM revenue:** ~9.5× (EV ≈ $130.6B mkt cap + $2.9B debt − $2.5B cash ≈ $131B; NTM rev guide midpoint $13.75B)[7][9]
- **Consensus 12-month price target:** $272.83 (implied **−19.8%** from spot; 18 analysts, "Buy" rating — note: the average target sits *below* the current price, which is unusual)[10]
- **YTD total return:** ~+103% (closed 2025 in the ~$165 area after the Q4 print rally; through May 1 reported +103%)[11][12]
- **Short interest (% of float):** 3.5% (~13.4M shares)[13]

Other relevant: Q1'26 net leverage 0.2×, $5.0B liquidity, IG-rated (Moody's Baa3 / S&P BBB- since Feb 2026), $2.1B inaugural senior unsecured notes issued March 2026.[9] Backlog: ~$12.45B at March 31, 2026 (+81% y/y); Q4'25 organic book-to-bill ~2.9×.[14][15]

## Moat — what it is physically made of
Vertiv's moat is **not** any single product. None of the discrete components — a CDU, a UPS, a busway — is patent-protected enough to be uncopiable. The moat is the **integration of a grid-to-chip BoM that has been pre-certified into NVIDIA's reference architecture for each successive rack generation**, plus the services and installed base that close the loop. Decomposed:

1. **NVIDIA reference-design co-development.** Vertiv co-published the 7 MW GB200 NVL72 reference architecture in Oct 2024 and the 142 kW GB300 NVL72 follow-on in June 2025, and unveiled an 800 VDC MGX reference architecture in 2026 aligned to Kyber/Rubin Ultra (576 GPUs/rack, productionizing in 2027).[1][2][16] Schneider has competing GB300 reference designs at the same density; Eaton does not.[17] This is a *narrow* moat — NVIDIA explicitly maintains "longtime collaborators Schneider, Siemens and Vertiv" — but inclusion in the certified BoM is a multi-month engineering relationship that resets each generation.[16] **Durability: medium.** Resets every 12–18 months.
2. **End-to-end "grid-to-chip" portfolio under one cage code.** PowerBoard MV/LV switchgear → Trinergy UPS (97.1% double-conversion, up to 99% in Dynamic Online) → DynaFlex Li-ion BESS → Powerbar iMPB / double-stack busway (2000–2500A) → Liebert XDU CDUs → cold plates / rear-door HX → Liebert CW / AFC chillers, packaged as MegaMod CoolChip / PowerNexus prefabs that claim 50% faster TTM and ~40% less footprint vs. stick-built.[18][19][20][21] Eaton just bought *into* this picture by acquiring Boyd Thermal in March 2026 for $9.5B (22.5× '26 EBITDA); Vertiv built it organically + CoolTera (Dec 2023, CDU IP) + PurgeRite (Dec 2025, $1.0B + $250M earn-out, fluid flushing/purging services).[22][23][24] **Durability: high** on the integration claim; **low** on any single sub-component.
3. **CoolTera CDU IP.** Brought CDU and SFN (secondary fluid network) design in-house in late 2023 — the same period Schneider partnered, then acquired Motivair (75% in 2025).[23][25] Without that asset, Vertiv would be sourcing CDUs from CoolIT (now being acquired by Ecolab for $4.75B at 29× NTM EBITDA — a scarcity-value print on this very capability).[26]
4. **PurgeRite + services attach.** Service ran ~$386M in Q1'25 (~19% of revenue) at ~42% gross margin vs. ~35% on product.[27][28] PurgeRite specifically does the dirty work of debris flushing, gas purging, and biocidal fill — which is *not* commoditized because contamination in a multi-loop NVL72 SFN can void compute uptime SLAs and Tier-IV warranties. This is sticky in the same way that Rockwell/Atlas Copco aftermarket is sticky.[28]
5. **Manufacturing capacity that scaled ahead of the wave.** Q1'26 call disclosed accelerated capex into manufacturing/services/engineering capacity, with the back-half ramp contingent on that capacity coming online.[29][14] This is a *time-not-IP* moat: lead times on competing capacity are 18–24 months.
6. **Liebert installed base.** ~30+ years of precision cooling deployments. Vertiv reportedly holds ~23% global precision-cooling share, virtually tied with Schneider in DCPI overall (separated by ~0.1 pt per Dell'Oro).[30][31]

**What it is not:** It is not a software platform like CUDA, and it is not an IP fortress like ASML EUV. It is industrial integration + reference-design seat + services. That is a real moat, but it is the kind of moat that gets eroded by a $9.5B Boyd Thermal acquisition, not one that disappears overnight.

## AI buildout bottleneck map
Twenty-four-month gating constraints, with VRT's position on each:

| Bottleneck | State (2026) | VRT position |
|---|---|---|
| **Grid interconnect / transformers** | HV transformer lead times 36–60 months; ~7 GW of US 2026 data center capacity delayed/cancelled out of ~12–16 GW announced.[32][33] | **Adjacent supplier, indirect beneficiary.** VRT sells MV/LV switchgear (PowerBoard) and on-site power (UPS, BESS, prefab) that compensates for utility delays, but does *not* sell the long-lead utility transformer itself. |
| **CoWoS-L** | Fully booked through 2026; TSMC scaling from ~75–80k wpm to 130k wpm by end-2026; NVDA ~50% of allocation.[34][35] | **Constraint owner of nothing here — pure customer-of-customer exposure.** If CoWoS-L slips, Blackwell/Rubin slip, racks slip, VRT shipments slip. |
| **HBM3e / HBM4** | SK Hynix 2026 fully allocated; HBM4 transition late 2026.[34] | Same: indirect downstream exposure. |
| **Liquid cooling capacity (CDUs, cold plates, manifolds)** | Liquid cooling market ~$6B → ~$27B by 2035 (18% CAGR); D2C is ~65% of liquid mix and the dominant 2026 architecture.[36][37] | **Direct supplier, beneficiary.** Vertiv, Schneider/Motivair, Eaton/Boyd, CoolIT/Ecolab, Daikin/Chilldyne, Rittal, Stulz, Asetek, JetCool, nVent are the supply-constrained roster. |
| **>100 kW/rack liquid plumbing services** | NVL72 = 132 kW today; GB300 = 142 kW; Kyber Rubin Ultra projected ~600 kW; 1 MW racks coming on 800 VDC.[2][3] | **Direct beneficiary** — PurgeRite + Vertiv services is one of the few hyperscaler-qualified loop-commissioning operations at scale. |
| **800 VDC power architecture** | NVIDIA committed to 800 VDC for Kyber / Vera Rubin (2027); ~20 ecosystem partners; eliminates 200kg copper busbars per rack.[2][16][38] | **Co-development partner** — VRT's 800 VDC portfolio targets H2'26 release. |
| **Electrical/mech contractor capacity in the US** | Skilled-labor shortage on data center MEP install. | **Beneficiary** — prefab MegaMod CoolChip explicitly factors out site labor. |
| **Optical interconnect / co-packaged optics** | Tight, but a Marvell/Coherent/Lumentum/Foxconn story. | **Indifferent.** Not VRT's layer. |
| **Frontier training data quality / RLHF / synthetic data** | Algorithmic, not physical. | **Indifferent.** |

VRT sits in the middle of the *physical-infrastructure* bottlenecks, with positive exposure to roughly every one that matters except CoWoS itself. The single biggest macro lever is whether the **grid interconnect bottleneck** is a tailwind (forces prefab + on-site BESS) or headwind (cancels data center starts entirely).

## Competitive teardown
On the **DCPI integrated-systems axis**, four meaningful competitors with very different shapes:

1. **Schneider Electric (EPA: SU).** The other half of the Dell'Oro DCPI duopoly. Larger overall (~$34B revenue, but DC cooling is ~15% of mix; diluted exposure) and structurally similar grid-to-chip portfolio.[30] Motivair acquisition (75% stake, ~$850M, 2024 with majority in 2025) gives them a credible 2.5 MW CDU and the AI HPC reference for direct-to-chip.[39][25] **Where Schneider has parity or better: GB300 reference architecture, brand depth in EMEA, mission-critical software (EcoStruxure).** Where VRT leads: services pure-play attach in North America, integrated prefab modular at speed. *Already at parity on most technical axes.*
2. **Eaton (NYSE: ETN).** Was historically "chip-to-grid" missing the chip end. **Closed Boyd Thermal $9.5B March 12, 2026** — $1.7B Boyd '26 revenue, $1.5B of that liquid cooling.[22] Eaton Q1'26 reported datacenter orders **+240% y/y**, backlog $22.8B.[15] **Where Eaton has parity: power distribution and now liquid cooling within ~12 months once integration is done.** Where Eaton lags: NVIDIA reference-design seat for GB300/Kyber is currently with VRT and Schneider, not Eaton; integration risk on a $9.5B Boyd acquisition is real. *Catching up; 12-18 month lag.*
3. **Ecolab / CoolIT (NYSE: ECL).** Ecolab acquiring CoolIT for $4.75B, closing Q3'26 at 29× NTM EBITDA — a *valuation print* establishing the scarcity premium on pure-play liquid cooling IP.[26] CoolIT is NVIDIA's other major qualified CDU partner. Ecolab is a water-treatment company; the bet is fluids+chemistry, not integrated power+cooling. **Will be a direct CDU/cold plate competitor; not an integrated systems competitor.**
4. **Chinese vendors: Envicool, Huawei, Yimikang, Dayuan Pumps.** Envicool's modular CDUs deliver in <4 weeks vs. Western multi-month lead times — but a quarter-on-quarter profit collapse (-82% Q1'26) hit the stock for the daily limit, suggesting either massive domestic overcapacity or commoditization in progress.[40] *Tail risk to the cooling moat 2027+, immaterial near-term in the US/EU.* China is also restricted from selling into NVIDIA-platform US/EU hyperscaler builds for national-security reasons.

**Smaller / niche:** Rittal, Stulz, Asetek, JetCool (Flex-owned), Iceotope, LiquidStack, nVent, Daikin (acquired Chilldyne in 2025–26 round). None of these has the integrated grid-to-chip portfolio.

The honest read: in 24 months you have **three** broad-line integrated competitors (VRT, Schneider, Eaton). That is more crowded than the bull narrative suggests, but the market is also large enough — DCPI projected to >$80B by 2030 per Dell'Oro — that three winners is consistent with VRT compounding at 25%+ for another 2–3 years.[41]

## Bull case — technical
The bull case is **physical** and rests on five conditions, in roughly descending order of importance:

1. **Rack density continues to compound.** GB200 (130 kW) → GB300 (142 kW) → Vera Rubin → Rubin Ultra Kyber (~600 kW) → 1 MW racks on 800 VDC.[2][3][16] Every step doubles the **bill-of-materials per MW** for cooling and power conversion vs. the prior generation, because each step forces more sophisticated CDUs, more secondary loop plumbing, and more local power-stage conversion. This is the single most important variable.
2. **NVIDIA reference-architecture seat is renewed for each generation.** VRT must remain co-developer on Rubin and Rubin Ultra, not just GB300. Current 800 VDC MGX co-development through GTC 2026 suggests this is on track.[3][16]
3. **The grid bottleneck doesn't choke shipments.** If 7 GW of US capacity slips into 2027–28, VRT's backlog is *deferred* (not lost) and the customer mix shifts to prefab modular and gas-on-site builds — both of which favor VRT's MegaMod and Trinergy/DynaFlex line.[32][20]
4. **Services attach scales with installed base.** PurgeRite + Vertiv services compounding at ~25%+ at ~42% gross margin would lift through-cycle group margin past 22% and de-rate the cyclicality.[27][28]
5. **The China cooling overhang stays domestic.** Envicool / Huawei do not enter US/EU hyperscaler builds in volume.[40]

**Base rate on technology displacement at this stage of a cycle:** in the analogous CPU-to-GPU pivot (2017–2024), the *physical-infrastructure* layer winners (Schneider/APC, Eaton, Vertiv pre-IPO) compounded revenue mid-teens for nearly the entire cycle without share loss, because the constraint shifted *with* the platform — air to liquid, 480V to medium-voltage, 12V to 54V to 800V — and the integrators with reference-design seats kept absorbing the new layer. The structurally analogous case is **not** "Cisco 1999" — Cisco's moat was protocol and IP-stack lock-in that collapsed when the network architecture re-optimized for cloud. VRT's moat is *mechanical and electrical* — water, copper, semiconductor power stages, fluid services — and those don't dematerialize. Closer analog: Rockwell Automation through the 2010s industrial software cycle. Multiple compression is the larger risk than revenue compression.

Financial outcome: if 2026 revenue hits the $14B high end and 2027 organic growth holds at 25%+ on backlog conversion, $17–18B revenue and ~22% adj. OM gets you to ~$8–9 in 2027 adj. EPS. At 40× — a notch below the current 52× — that is ~$340 stock. **The bull case justifies *holding* at $340, not getting you to $500.**

## Bear case — technical
The bear case a short who understands the stack would write:

1. **The moat is integration, not IP, and three integrators are now in.** Eaton+Boyd, Schneider+Motivair, and Ecolab+CoolIT have all paid scarcity-premium prices for liquid cooling assets in the last 12 months. The strategic message of those prints is *anyone* will pay 22–29× EBITDA to own a credible CDU. That collapses the long-run scarcity rent VRT enjoys today.[22][25][26]
2. **Concentration risk is real and the 90s-CSCO bear-case is "hyperscalers go captive."** Meta/MSFT/AWS are channel-checked at ~45–50% of revenue.[42] Microsoft and Meta both employ teams designing custom racks; Google has its own thermal team for TPU pods. Loss of one $500–700M customer relationship would compress revenue 5–7% and the multiple by 20–30%. The Microsoft Maia, Google TPU, Meta MTIA, Amazon Trainium custom-rack roadmaps explicitly disintermediate the NVIDIA reference architecture VRT keys on.
3. **Rack density doesn't compound in the way the bull case requires.** If Rubin Ultra Kyber slips to 2028 or if hyperscalers buy GB300-class racks for two or three more years rather than racing to 1 MW, the per-MW cooling BoM growth slows from "compound" to "linear." Inference workloads in particular do not need 600 kW racks — they need cheap FLOPs and memory bandwidth on 132–200 kW racks. The Kyber transition is a *training* bet.
4. **AMD MI400 + Broadcom Tomahawk Ultra + custom silicon shifts share off NVIDIA reference architecture.** If 30%+ of 2027 hyperscaler racks are not NVIDIA-reference (custom silicon, AMD UALink-based scale-up), VRT's reference-seat advantage collapses to ~70% of TAM. The neutrality VRT claims (it sells into AMD/Intel/custom racks too) is real but the engineering co-development edge is NVIDIA-specific.
5. **Valuation.** 52× forward P/E and 9–10× NTM revenue for an industrial. Consensus PT $272 sits **below** spot — i.e., even the sell-side that has been chasing this name all year is no longer underwriting the price.[10] The math of going from 52× to 30× P/E over 24 months (a perfectly defensible compression as growth normalizes from 30% to 18%) wipes ~40% of the equity even if EPS doubles. *Multiple compression, not earnings compression, is the bear case.*
6. **Tariffs and Section 232.** Steel, aluminum, copper passthroughs are non-trivial for a heavy-metal industrial. Management has called them "manageable" and price/cost positive through Q1'26[43] — but this is a y/y headwind to gross margin that has to be actively offset every quarter.
7. **Chinese commoditization.** Even if China stays domestic, the existence of Envicool / Yimikang sub-$30M CDU lines puts a long-run price ceiling on the category. Envicool's 82% Q1'26 profit collapse is *information* about where CDU pricing eventually lands.[40]

## Market view check
Spot $340.60 against the $272 consensus PT is a striking inversion: the stock has run ~100% YTD past the sell-side's own bullish targets, which is what happens when the marginal buyer is no longer the analyst-driven institutional flow but **AI-momentum capital plus the S&P 500 inclusion bid** (effective March 23, 2026).[12] At 9.5× NTM revenue and 52× forward earnings, the market is pricing in:
- Backlog converts cleanly (the $15B backlog is real, but ~$5B is FY27+).[14]
- Margin expansion to 22–23% adj. OM through 2027.
- VRT keeps its NVIDIA reference-architecture seat for Rubin and Rubin Ultra.
- Eaton/Schneider/Ecolab do *not* compress liquid cooling pricing.

What the market is **probably** under-modeling, in our view: the **multiple compression mechanic itself**. The closest precedent — Schneider's data center business going from cyclical-industrial (10–14× P/E) to AI-momentum (~30×) and back — took ~3 years through the 2000–2003 cycle. VRT trading at 52× has no margin of safety against any one of (a) hyperscaler capex tone shift, (b) one missed reference-architecture cycle, (c) tariff escalation, (d) China rotating from indifferent to credible. Technically the business is real; **valuation embeds none of the credible downside paths.**

## 90-day falsifiers
Specific, observable events on or before mid-August 2026:

1. **Q2'26 VRT earnings (late July 2026).** Look for: book-to-bill (>2× confirms; <1.5× concerns); back-half capacity ramp commentary; *organic* Americas growth (slowing from Q1's +44% materially would matter); any disclosure of customer concentration shift; explicit mention of NVIDIA Rubin reference architecture progression.
2. **Hyperscaler Q2 capex tone — MSFT, META, GOOGL, AMZN, ORCL late July / early August.** If aggregate FY26 capex guide is cut by **>5% sequentially**, that is the canonical falsifier. AWS+28%, Google+63%, MSFT $190B is the current run-rate.[15]
3. **Eaton Q2'26 results (early August).** Eaton's data center order growth was +240% in Q1 — if that decelerates to <100% in Q2, it signals either market deceleration *or* VRT taking share. Order book disclosure here is the cleanest comp.
4. **Ecolab–CoolIT deal close, Q3'26 target.** If it closes early and ECL announces an aggressive expansion plan for CoolIT, that is bearish for VRT pricing power.
5. **NVIDIA Q2 earnings + GTC content (June/July).** Any update on Rubin timing, Kyber readiness for 2027, or ecosystem-partner roster shifts. Vertiv being conspicuously *absent* from a major NVIDIA stage announcement would be a meaningful negative tell.
6. **China cooling stocks (Envicool, Yimikang, Dayuan).** Continued or steeper profit collapse in Q2 reports is *bullish* for VRT (domestic Chinese overcapacity stays domestic); a sudden rebound on export wins would be bearish.
7. **Section 232 tariff developments on copper / aluminum.** A widening or narrowing on the May 2026 framework directly hits VRT cost structure.[44]
8. **VRT free cash flow conversion.** Q1'26 was 153% y/y growth in OCF, $653M FCF.[9] Working-capital absorption from the backlog build is a real risk; a single Q of negative FCF would change the IG-rating tone.

## What I could not verify
- **Exact hyperscaler-by-hyperscaler revenue share for VRT.** Channel-check estimates put Meta+MSFT+AWS at 45–50% of revenue, but VRT does not disclose by customer in 10-Q/10-K. The estimate is third-party.[42]
- **NVIDIA's allocation of reference-architecture co-development hours by partner** — i.e., whether VRT or Schneider has the deeper engineering relationship at the Rubin Ultra stage. Both have published GB300 designs; both are named as Vera Rubin partners. The relative depth is unverifiable without internal NVIDIA visibility.
- **Quantitative customer-by-customer competitive win/loss data versus Eaton (post-Boyd) or Schneider (post-Motivair).** Public won/lost announcements (CoreWeave on Switch via Vertiv[3]) are anecdotal, not systematic.
- **Backlog quality decomposition** (firm vs. soft orders, indexed vs. fixed-price, take-or-pay). VRT discloses headline backlog but not these splits.
- **The actual margin uplift from PurgeRite within the services line** — disclosed at acquisition as accretive but not yet broken out post-close.[24]
- **Whether any of the named in-house hyperscaler thermal teams (MSFT/META/GOOG) have *displaced* third-party CDU/cold-plate buys in 2025–26 production builds**, or remain experimental.
- **The exact 2025 ending stock close** I would have used to compute YTD return — I sourced "+103% YTD as of May 1, 2026" but did not verify against a clean 12/31/25 print.[11][12]

## Sources
[1] https://www.vertiv.com/en-emea/about/news-and-insights/news-releases/vertiv-codevelops-with-nvidia-complete-power-and-cooling-blueprint-for--nvidia-gb200-nvl72-platform/ — retrieved 2026-05-10 — Vertiv/NVIDIA Oct 2024 co-developed 7MW GB200 NVL72 reference architecture.
[2] https://developer.nvidia.com/blog/nvidia-800-v-hvdc-architecture-will-power-the-next-generation-of-ai-factories/ — retrieved 2026-05-10 — NVIDIA technical blog on 800 VDC, 1 MW racks, copper savings, Kyber/Rubin Ultra 2027 timing.
[3] https://www.vertiv.com/en-asia/about/news-and-insights/news-releases/vertiv-develops-energy-efficient-cooling-and-power-reference-architecture-for-the-nvidia-gb300-nvl72/ — retrieved 2026-05-10 — Vertiv GB300 NVL72 142kW reference, Switch/CoreWeave deployment.
[4] https://introl.com/blog/gb200-nvl72-deployment-72-gpu-liquid-cooled — retrieved 2026-05-10 — NVL72 hardware/cooling deployment details (132 kW, 72 GPUs, D2C).
[5] https://finance.yahoo.com/quote/VRT/ — retrieved 2026-05-10 — VRT price $340.60 close 2026-05-10, market cap $130.56B.
[6] https://www.macrotrends.net/stocks/charts/VRT/vertiv-holdings/stock-price-history — retrieved 2026-05-10 — 52-week range $92.13–$359.80; all-time high close $358.92 on 2026-05-06.
[7] https://www.gurufocus.com/term/forward-pe-ratio/VRT — retrieved 2026-05-10 — Forward P/E 52.64 as of 2026-05-10.
[8] https://investors.vertiv.com/news/news-details/2026/Vertiv-Reports-Strong-First-Quarter-with-Diluted-EPS-Growth-of-136-Adjusted-Diluted-EPS-Growth-of-83-Raises-Full-Year-Guidance/default.aspx — retrieved 2026-05-10 — FY26 adj. EPS guide $6.30–$6.40; revenue guide $13.5–$14.0B; Q1 results.
[9] https://www.prnewswire.com/news-releases/vertiv-reports-strong-first-quarter-with-diluted-eps-growth-of-136-adjusted-diluted-eps-growth-of-83-raises-full-year-guidance-302750110.html — retrieved 2026-05-10 — Q1 cash, debt, leverage (0.2× net), $5.0B liquidity, $2.1B notes, IG rating.
[10] https://stockanalysis.com/stocks/vrt/forecast/ — retrieved 2026-05-10 — 18-analyst consensus PT $272.83, implied −19.75%; range $112–$414.
[11] https://www.tikr.com/blog/vertiv-stock-is-up-57-ytd-in-2026-can-it-still-deliver-10-annual-returns — retrieved 2026-05-10 — YTD performance reference.
[12] https://247wallst.com/investing/2026/05/01/arm-marvell-or-vertiv-which-ai-infrastructure-stock-crushed-it-in-april/ — retrieved 2026-05-10 — "+103% YTD" through May 1, 2026; S&P 500 inclusion March 23, 2026.
[13] https://www.marketbeat.com/stocks/NYSE/VRT/short-interest/ — retrieved 2026-05-10 — Short interest 13.41M shares, 3.49–3.52% of float.
[14] https://techjacksolutions.com/ai-brief/vertiv-raises-2026-guidance-to-14b-as-ai-data-center-backlog/ — retrieved 2026-05-10 — Backlog $12.45B at 3/31/26 +81% y/y; some sources reference $15B figure.
[15] https://alcapitaladvisory.com/research/intelligence/ai-infrastructure.html — retrieved 2026-05-10 — Eaton Q1'26 revenue $7.45B (+17%), datacenter orders +240%, backlog $22.8B; hyperscaler capex ~$725B 2026.
[16] https://blogs.nvidia.com/blog/gigawatt-ai-factories-ocp-vera-rubin/ — retrieved 2026-05-10 — NVIDIA "longtime collaborators Schneider, Siemens and Vertiv"; 20+ ecosystem partners; Vera Rubin/Kyber.
[17] https://www.se.com/ww/en/about-us/newsroom/news/press-releases/schneider-electric-announces-new-reference-designs-featuring-integrated-power-management-and-liquid-cooling-controls-supporting-nvidia-mission-control-and-nvidia-gb300-nvl72-68ca8fdd5e6c6f9d3a096133/ — retrieved 2026-05-10 — Schneider GB300 NVL72 reference design.
[18] https://www.vertiv.com/en-us/products-catalog/critical-power/uninterruptible-power-supplies-ups/vertiv-trinergy/ — retrieved 2026-05-10 — Trinergy UPS spec: 97.1%/99% efficiency, 1500/2000/2500 kVA.
[19] https://www.vertiv.com/en-us/about/news-and-insights/corporate-news/2026/vertiv-announces-scalable-high-capacity-double-stack-busway-system-that-preserves-white-space-for-growing-ai-data-center-demands/ — retrieved 2026-05-10 — Powerbar double-stack 2000A UL / 2500A IEC.
[20] https://www.vertiv.com/en-us/products-catalog/facilities-enclosures-and-racks/integrated-solutions/vertiv-megamod-coolchip/ — retrieved 2026-05-10 — MegaMod CoolChip prefab: 50% faster deployment.
[21] https://www.vertiv.com/en-us/products-catalog/facilities-enclosures-and-racks/integrated-solutions/vertiv-powernexus/ — retrieved 2026-05-10 — PowerNexus: Trinergy + PowerBoard integrated, 70% faster install.
[22] https://www.datacenterdynamics.com/en/news/eaton-acquires-boyd-thermal-for-95bn-to-further-liquid-cooling-portfolio/ — retrieved 2026-05-10 — Eaton/Boyd Thermal $9.5B at 22.5× '26 EBITDA, closed March 12, 2026; $1.7B Boyd '26 revenue ($1.5B liquid cooling).
[23] https://www.datacenterdynamics.com/en/news/vertiv-acquires-data-center-liquid-cooling-company-cooltera/ — retrieved 2026-05-10 — Vertiv/CoolTera acquisition Dec 2023, CDU IP/SFN/manifolds.
[24] https://www.vertiv.com/en-emea/about/news-and-insights/news-releases/vertiv-completes-acquisition-of-purgerite-expanding-leadership-in-liquid-cooling-services/ — retrieved 2026-05-10 — PurgeRite acquisition $1.0B + $250M earn-out, closed Dec 4, 2025.
[25] https://www.datacenterdynamics.com/en/news/schneider-electric-and-motivair-unveil-first-joint-liquid-cooling-portfolio/ — retrieved 2026-05-10 — Schneider/Motivair joint portfolio launch.
[26] https://www.datacenterdynamics.com/en/news/ecolab-to-pay-475bn-for-liquid-cooling-specialist-coolit/ — retrieved 2026-05-10 — Ecolab/CoolIT $4.75B at 29× NTM EBITDA, Q3'26 close, $550M CoolIT NTM revenue.
[27] https://stockstory.org/us/stocks/nyse/vrt/news/earnings-call/vrt-q3-cy2025-deep-dive-ai-data-center-momentum-and-results-tariff-headwinds-remain — retrieved 2026-05-10 — Services as ~19% of revenue; tariff context.
[28] https://www.beyondspx.com/quote/VRT/news/vertiv-completes-1-billion-acquisition-of-purgerite-to-expand-liquidcooling-services — retrieved 2026-05-10 — Services GM ~42% vs product ~35%; aftermarket margin analog (Rockwell/Atlas Copco).
[29] https://www.fool.com/earnings/call-transcripts/2026/04/22/vertiv-vrt-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1'26 earnings call with Albertazzi on capacity, tariffs, EMEA bookings, back-half ramp.
[30] https://www.delloro.com/news/data-center-physical-infrastructure-market-reaches-10-9-billion-in-4q-2025-up-20-percent-y-y/ — retrieved 2026-05-10 — Dell'Oro: Schneider/Vertiv tied at top of DCPI; 4Q'25 market $10.9B, +20% y/y.
[31] https://introl.com/blog/vertiv-schneider-eaton-cooling-solutions-comparison-ai-data-centers — retrieved 2026-05-10 — Vertiv ~23% precision cooling share; competitive shape vs. Schneider/Eaton.
[32] https://tech-insider.org/us-ai-data-center-delays-cancellations-7gw-capacity-crisis-2026/ — retrieved 2026-05-10 — ~7 GW of US 2026 data center capacity delayed/cancelled.
[33] https://www.powermag.com/transformers-in-2026-shortage-scramble-or-self-inflicted-crisis/ — retrieved 2026-05-10 — Transformer lead times 36–60 months.
[34] https://newsletter.semianalysis.com/p/ai-capacity-constraints-cowos-and — retrieved 2026-05-10 — CoWoS / HBM capacity constraints, hyperscaler allocations.
[35] https://markets.financialcontent.com/wral/article/tokenring-2026-2-2-the-cowos-crunch-why-tsmcs-specialized-packaging-remains-the-ai-industrys-ultimate-bottleneck — retrieved 2026-05-10 — TSMC CoWoS expansion plan to 130k wpm; NVDA ~50% allocation.
[36] https://www.gminsights.com/industry-analysis/data-center-liquid-cooling-market — retrieved 2026-05-10 — Liquid cooling market $6B → $27.1B by 2035, 18.2% CAGR.
[37] https://www.adamsilvaconsulting.com/insights/data-center-cooling-economics-2026 — retrieved 2026-05-10 — D2C ~65% of liquid cooling market 2026; rack density 27 kW avg (+69% y/y).
[38] https://www.vertiv.com/en-in/about/news-and-insights/news-releases/vertiv-accelerates-ai-infrastructure-evolution-in-alignment-with-nvidia-800-vdc-power-architecture-announcement/ — retrieved 2026-05-10 — Vertiv 800 VDC portfolio H2'26 release; Kyber/Rubin Ultra alignment.
[39] https://www.channelinsider.com/ai/emerging-tech/motivair-ai-factories-cooling-solution/ — retrieved 2026-05-10 — Motivair/Schneider 2.5 MW CDU launch for AI factories.
[40] https://www.bloomberg.com/news/articles/2026-04-21/data-center-cooling-stocks-sink-in-china-on-competition-concerns — retrieved 2026-05-10 — Envicool −82% Q1 profit, hit daily limit; China commoditization concerns.
[41] https://www.delloro.com/news/data-center-physical-infrastructure-market-to-surpass-80-billion-by-2030/ — retrieved 2026-05-10 — Dell'Oro DCPI >$80B by 2030.
[42] https://www.optionstradingreport.com/2026/05/vertiv-holdings-vrt-the-ai-infrastructure-play-no-one-talks-about/ — retrieved 2026-05-10 — Channel-check estimate: Meta/MSFT/AWS = 45–50% of revenue; potential $500–700M customer-loss scenario.
[43] https://www.themarketsdaily.com/2026/04/24/vertiv-q1-earnings-call-highlights.html — retrieved 2026-05-10 — Tariff/Section 232 management commentary, price/cost positive 2026.
[44] https://www.ghy.com/trade-compliance/us-adjusts-section-232-tariffs-on-aluminum-steel-and-copper-full-customs-value-now-applies/ — retrieved 2026-05-10 — Section 232 tariff framework adjustments on aluminum/steel/copper.