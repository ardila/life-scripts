# SMCI — Super Micro Computer, Inc.

## Where this sits in the AI stack
SMCI is a **systems integrator** at the rack and pod layer. It does not design silicon, fab HBM, write CUDA kernels, lay fiber, or sell software. It takes NVIDIA's GB200/GB300 (and AMD MI355X) compute trays, NVLink/InfiniBand switches it does not own the IP for, third-party CDUs and cold plates, racks/PDUs, and integrates them into pre-validated, liquid-cooled SuperClusters delivered to the white-floor. Workload mix is overwhelmingly **GPU-accelerated training and inference** (>80% of Q3 FY26 revenue is "AI GPU-related platforms" [1]). It is a *thermal and assembly* play layered on top of NVIDIA's silicon roadmap, not a compute play in its own right.

## Snapshot
- **Price:** $35.37 (2026-05-08 close) [2]
- **Market cap:** $21.2B [2]
- **52-week range:** $19.48 – $62.36 [2]
- **Forward P/E:** ~11.8× (FY27 consensus EPS ~$3.00) [3]
- **EV / NTM revenue:** ~0.6× (EV ~$28B against ~$45B NTM revenue guide-implied; uniquely low for an AI-tagged name) [3][1]
- **Consensus 12-month price target:** $36.50 (≈ +3% from spot) [4]
- **YTD total return:** approx –7% (April), partially recovered post-Q3 FY26 print [5]
- **Short interest:** 13.9–14.5% of float [6][3]

## Moat — what it is physically made of
The honest decomposition is that SMCI's moat is **narrow, perishable, and concentrated in two things**: speed-to-market on each NVIDIA generation and the ability to physically deliver liquid-cooled racks at hyperscale volume. Decomposing:

1. **Building-block SKU library + co-design with NVIDIA.** SMCI maintains ~800+ server SKUs (motherboards, chassis, riser/cable kits) that snap onto each new HGX/Grace board within weeks of Jensen's launch slide. This is a *process* asset (BOM library, SI/PI simulation flow, supplier qualifications) accumulated over 30 years under Charles Liang. **Durability: medium** — Dell, HPE and the ODMs have all closed the launch-day gap by 2025; SMCI's "first-to-market" lead on Blackwell was on the order of weeks, not quarters [7][8].

2. **DLC-2 liquid cooling — but only the rack-internal portion.** SMCI markets cold plates covering CPU/GPU/memory/PCIe switches/VRMs (claimed 98% heat capture), in-rack CDUs to 250kW, vertical CDMs, 45°C inlet tolerance, ~50dB noise [9]. The critical caveat: **the high-precision components — particularly the in-row/in-rack Coolant Distribution Unit and quick-disconnects — are dominated by Vertiv**, which holds ~70% volume share on first-wave GB200 NVL72 deployments [10]. SMCI integrates these into a rack-scale bundle; it is not the cooling-IP owner. The IP is in two-phase fluid loops, hose/fitting reliability, and leak telemetry — fields where Vertiv, CoolIT, Boyd, Asetek have decades of patents. **Durability: low-to-medium** as a standalone moat; SMCI's edge is logistical, not metallurgical.

3. **Manufacturing footprint and rack-level assembly.** ~6,000 high-end racks/month capacity across San Jose, Taiwan, Netherlands, Malaysia; ~4M sq ft Bay Area expansion announced April 2026 [11][12]. Useful for TAA-compliant U.S. government work (Rubin variant disclosed Q4 2025 [13]) but capital-intensive and *replicable* — Dell, Foxconn (Mexico/Houston), Quanta and Wiwynn have all stood up rack integration lines for GB200 in the same window.

4. **DCBBS + SuperCloud Composer software.** A 2025-launched "data center as building blocks" bundle (rack, CDU, networking, software, services) backed by a Redfish-based composability layer with Kubernetes/Elastic telemetry [14][15]. CEO claimed software revenue ~$46M in Q3 FY26 and DCBBS could be "25%+ of profit in coming years" [1]. Reality check: $46M against $10.2B revenue is rounding; SuperCloud Composer is BMC-and-firmware orchestration, not a Run:AI / Slurm / xCAT-class scheduler or a model-serving runtime. **Durability: weak** as a competitive moat.

5. **Customer relationships in the Tier-2 cloud / sovereign-AI tier.** CoreWeave was ~22% of SMCI revenue from Q3 2023–Q3 2024 [16]; "Customer G" 31% of revenue in Q2 FY25 [17]; in Q3 FY26 a single OEM/DC customer was 27% and an enterprise customer 10% [1]. The $20B DataVolt/Saudi Arabia partnership announced May 2025 [18] is multi-year, lumpy, and politically contingent. **Durability: contractual but with no switching cost** — every one of these customers can dual-source from Dell or buy direct from Foxconn/Quanta tomorrow.

**Inference (not in primary sources): the only structurally non-replicable asset is Liang's personal relationship with Jensen Huang and Liang's willingness to ship at sub-Dell margins.** Both are real, neither is on the balance sheet.

## AI buildout bottleneck map
Over the next 24 months, the binding constraints — and SMCI's exposure to each — are:

- **CoWoS-L advanced packaging.** NVIDIA has booked ~60% of TSMC's CoWoS capacity through 2026, ~510k CoWoS-L wafers; TSMC ramping to ~150k wafers/month by end-2026 (~4× late-2024) [19][20]. SMCI is a **downstream beneficiary** of more packages but has **zero leverage**; allocation is decided in Hsinchu and Santa Clara. If CoWoS-L slips, SMCI's revenue slips with it.
- **HBM3e/HBM4.** Sold out through 2026 across SK Hynix, Micron, Samsung; ~20% price hike for 2026 deliveries [21][22]. **Indifferent-to-exposed**: more HBM = more GPUs to integrate, but HBM cost is passed through to SMCI's BOM at flat margin, compressing gross margin in absolute terms.
- **Optical interconnect (800G/1.6T transceivers, EML lasers).** McKinsey projects 800G underbuilt 40-60% through 2027; Lumentum is the sole-volume supplier of 200G-per-lane EMLs needed for 1.6T; NVIDIA committed $4B combined to Coherent + Lumentum March 2026 [23]. SMCI **resells** optics it does not manufacture — pure pass-through.
- **Liquid cooling at >100kW/rack.** GB200 NVL72 mandatory liquid cooled at 120kW/rack; Vera Rubin NVL144 higher [24]. This is *the* SMCI thesis-relevant bottleneck; SMCI is a **mid-stream supplier** but Vertiv owns the highest-margin sub-assembly.
- **Grid power & gas turbines.** GE Vernova / Siemens / MHI heavy-frame turbine slots sold through 2027–28; PJM 2026–27 capacity cleared at $329/MW-day vs $28.92 two years prior [25][26]; ERCOT seeing 186GW of interconnect requests [27]. SMCI is **indifferent** — it ships racks; if power slips, customers cancel orders. Q3 FY26 already saw "customer site readiness delays including data center construction, power infrastructure, and cooling buildout at customer facilities" [1] — i.e., the bottleneck is *already* hitting SMCI's revenue recognition.
- **Electrical contractor / mechanical trades for >50MW liquid-cooled halls.** No public data; **inference, not verified.** Likely a real 12-month constraint on customer deployments and therefore on SMCI revenue timing.
- **Kernel/compiler talent.** Constraint on NVIDIA, AMD, hyperscaler training teams. SMCI **indifferent** — no compiler IP.

## Competitive teardown
The contest is on **four axes**, and SMCI is losing on at least two:

| Axis | SMCI | Dell | HPE | Taiwan ODMs (Foxconn/Quanta/Wiwynn) |
|---|---|---|---|---|
| Launch-day SKU availability on new NVIDIA gen | Strong — historic edge | Now parity (XE9712 shipped to CoreWeave at launch) [28][7] | Lagging | Strong (they *build* for NVIDIA's reference design) |
| Hyperscaler direct relationships | Weak — sells through Tier-2 and sovereign | Strong (Meta, Microsoft, xAI partial) | Weak | **Dominant** — Foxconn 40%, Quanta 30% of NVL72 builds [29] |
| Enterprise/govt channel | Weak | **Dominant** — global services arm | Strong | None |
| Rack-scale liquid cooling integration | Strong (DLC-2, 250kW CDU) | Strong (250kW air + 750kW DLC in Integrated Rack 7000) [28] | Improving | Building rapidly |
| Software/services attach | Token (~0.5% of rev) | Real (services >$20B run-rate) | Real (GreenLake) | None |

Two concrete data points reframe the narrative. (1) **IDC Q4 2025**: Dell 10% server-revenue share, SMCI 9% — Dell took the lead [30]. (2) **NVIDIA actively re-routed orders away from SMCI during the 2024 accounting episode** and broadened ODM procurement authority for components [31][32]. The lesson: NVIDIA treats SMCI as **fungible** with Foxconn/Quanta on assembly. The reason Foxconn isn't a US-listed competitor in investors' minds is share-class structure, not technical capability.

Dell already has parity on rack-scale liquid GB200, an order-of-magnitude larger enterprise channel, and a $43B AI backlog entering FY27 (vs SMCI's "record high" but undisclosed backlog) [33][1]. For SMCI to recover share Dell would have to *stop* executing, which is not the base rate for Dell post-2023.

## Bull case — technical
For SMCI to materially outperform from here, **all** of the following need to hold simultaneously:

1. **Rack-scale, liquid-cooled SKUs remain the unit of sale through Rubin** (NVL144 in 2026, post-Rubin Ultra in 2027), and the launch-day-to-volume window for each generation stays ~3–6 months. SMCI's brand value is "first to ship rev-A racks at volume." Base rate for displacement of an *integrator-grade* incumbent at this stage of a buildout: in past CapEx super-cycles (PC OEMs, telecom equipment, hyperscale server gen 1), the incumbent kept share for ~2–4 product generations before ODM disintermediation began in earnest. NVL72 → Rubin Ultra is generations 1–3.
2. **DCBBS lands** — i.e., customers buy SMCI's full data-center-as-product bundle at >15% gross margin, lifting blended margins back toward the mid-teens. Q3 FY26's 10.1% non-GAAP GM (vs 6.4% Q2) supports the directional thesis but not the magnitude [1].
3. **Sovereign AI ($20B DataVolt, follow-on UAE/Saudi/India deals) ramps on schedule**, becoming the third leg alongside hyperscaler and enterprise [18]. This is where SMCI has a structural advantage over Dell (less geopolitically loaded brand, willingness to localize manufacturing in Memphis-style facilities [34]).
4. **AMD MI355X attach grows.** SMCI is one of the few integrators shipping 10U air-cooled and 4U liquid-cooled MI355X platforms at volume [35]; if AMD takes even 15% of training/inference share, SMCI's value as a *vendor-agnostic* integrator increases.

Financial connection: at ~12× forward EPS with 13-14% short interest, even modest margin recovery (say, sustained 11-12% GM through FY27) on $45–50B revenue produces $5+ EPS and supports $60–80 price. The setup is asymmetric *if and only if* the technical conditions above hold.

## Bear case — technical
1. **Rack-scale integration is being commoditized in real time.** Gross margin track: mid-teens 2023 → 11.1% FY25 → 6.4% Q2 FY26 → 10.1% Q3 FY26 → 8.2-8.4% guided Q4 FY26 [36][1]. This is the signature of a *pass-through* business where the AI value is captured upstream (NVIDIA: 77.6% GM on Blackwell [36]) and downstream (the GPU operator). The integrator is left with assembly fees that erode each generation. The 5-year base rate for hardware integrators in a winner-takes-most platform shift (Compaq/Gateway in the PC build-out, Sun in the dot-com era): margin compression of 300–500bps over 3 years, ending in single digits and never recovering.
2. **NVIDIA holds the pen.** NVIDIA has demonstrated willingness to divert orders away from SMCI [31] and to centralize NVL72 assembly with Foxconn/Wistron/Quanta [32]. Vera Rubin reference platforms are already designed for ODM-direct fulfillment. SMCI's "first-to-market" claim depends on NVIDIA granting reference-design access; that access is not contractual.
3. **Working capital is screaming.** Q3 FY26: operating cash flow –$6.6B (vs –$24M Q2); inventory $11.1B; cash conversion cycle blew from 54 to 106 days; net debt rose from $787M to $7.5B in one quarter; new $1.8B Taiwan credit facility [1]. This is the pattern of a company **buying GPU inventory ahead of revenue recognition that may slip** — either because customer sites aren't ready (their explanation) or because of weakening sell-through. Either way, the balance sheet is being levered at exactly the moment margins are thinnest. Free-cash-flow yield is *negative* despite the optically low P/E.
4. **DOJ probe overhang.** Company says it is not a target [1], but the special-committee investigation, EY auditor resignation, and 18 months of restated/delayed filings [37] mean DOJ resolution is a binary headline risk. Hyperscalers and U.S. government customers de-risk dual-sourcing during such overhangs by definition.
5. **Customer concentration is structurally worse than reported.** Top two customers ~37% of revenue in Q3 FY26; if "Customer G" or CoreWeave's spend rotates to Dell (already happening on XE9712) or to direct Foxconn shipments, the comp gets ugly fast.

## Market view check
The market is pricing SMCI as an **AI-tagged commodity hardware integrator with credibility damage**: ~12× forward EPS, ~0.6× EV/sales, 14% short. This is roughly consistent with treating SMCI as Dell-with-a-discount-for-governance-risk, *not* as a moated AI infrastructure name. My read of the technical reality says that valuation framework is **directionally correct**. The thesis differentiation is therefore narrow: either you believe (a) DCBBS and sovereign AI re-rate the multiple to mid-teens on durable margins, in which case the stock works; or (b) the integrator layer is the wrong layer to own in this cycle (NVIDIA, Vertiv, the HBM trio, the optical names captured the rents). My technical analysis tilts (b), with (a) as a tradeable but not investable rally vehicle. The 14% short and high beta create a recurring squeeze pattern, but that's a trade, not a thesis.

## 90-day falsifiers
- **Q4 FY26 print (mid-Aug 2026):** Did revenue land ≥$11B and gross margin hold ≥8.2%? Did the 10-Q file on time without restatement? Did operating cash flow turn positive? Negative on any of these breaks the recovery narrative.
- **CoWoS-L allocation reports for H2 2026:** If TSMC's 150k/month CoWoS ramp slips (DigiTimes monitors quarterly), Rubin volumes slip, SMCI revenue slips.
- **Vera Rubin NVL144 sampling disclosures.** SMCI claims first-to-market [13][24]; verifiable by independent ServeTheHome / SemiAnalysis teardowns or hyperscaler announcement of "first NVL144 cluster on Supermicro hardware."
- **Customer A / Customer G disclosure in next 10-Q.** Concentration moving above 35% for any single customer is a red flag; falling below 20% (broader base) supports the bull case.
- **Dell Q2 FY27 print (late Aug 2026).** If Dell's AI server revenue >$10B in a quarter and backlog stays >$40B, SMCI's share-gain narrative is dead.
- **Any DOJ resolution (settlement, declination, or charges).** Binary.
- **NVIDIA GTC fall 2026 partner slides.** Whether SMCI is in the top tier of "Vera Rubin launch partners" alongside Dell/Foxconn or relegated to second screen.
- **Gas-turbine and CDU delivery data points** (GE Vernova, Vertiv backlog commentary). Marginal weakness in either pushes out customer site-readiness and pushes SMCI revenue right again.

## What I could not verify
- Exact CoWoS-L wafer allocation **at the substrate-package level** between Blackwell, Blackwell Ultra, Rubin, and Rubin Ultra — public estimates aggregate.
- Specific identity of "Customer G" (31% of Q2 FY25 revenue [17]); CoreWeave is plausible but unconfirmed in SEC filings I could access remotely.
- Whether SMCI's DLC-2 cold-plate IP is owned, licensed (e.g., from CoolIT/Asetek), or a hybrid. Filings reference cooling partnerships (Fujitsu, Nidec) [38] but not exclusive IP.
- True software revenue mix inside the reported $46M — how much is SuperCloud Composer license vs services attach vs warranty extensions.
- Dell vs SMCI **rack** unit shipments on GB200 NVL72 specifically (IDC tracks server revenue, not NVL72 racks). Estimates from press exist but I would not stake the thesis on them.
- The actual capacity utilization of the 6,000 rack/month figure — if true utilization is materially below 50%, fixed-cost absorption issues compound the margin story.
- Whether DataVolt $20B is firm purchase orders or an MOU framework. Press language was partnership-style, not bookings-style [18].
- Quality of the new BDO audit. EY's resignation is a fact; whether BDO's prior-year reaudit produced any quiet adjustments was not disclosed in detail accessible to me [37].

## Sources
[1] https://www.fool.com/earnings/call-transcripts/2026/05/05/super-micro-smci-q3-2026-earnings-transcript/ — retrieved 2026-05-10 — Q3 FY26 transcript: $10.2B revenue, 10.1% GM, customer mix (27%+10%), $11.1B inventory, -$6.6B OCF, capacity 6,000 racks/mo.
[2] https://finance.yahoo.com/quote/SMCI/ — retrieved 2026-05-10 — $35.37 close 2026-05-08, $21.2B market cap, 52-wk $19.48–$62.36.
[3] https://stockanalysis.com/stocks/smci/statistics/ — retrieved 2026-05-10 — Forward P/E 11.8×, EV/Revenue 0.86×, short interest 14.45%.
[4] https://www.marketbeat.com/stocks/NASDAQ/SMCI/forecast/ — retrieved 2026-05-10 — Consensus PT ~$36.50–36.75, neutral rating.
[5] https://247wallst.com/investing/2026/05/01/dell-super-micro-or-hpe-which-ai-server-stock-crushed-it-in-april/ — retrieved 2026-05-10 — YTD 2026: SMCI –7%, Dell +67%, HPE +20%.
[6] https://www.marketbeat.com/stocks/NASDAQ/SMCI/short-interest/ — retrieved 2026-05-10 — 83.19M shares short, 13.85% of float.
[7] https://www.tomshardware.com/tech-industry/artificial-intelligence/dell-reaches-milestone-with-industrys-first-enterprise-ready-nvidia-blackwell-poweredge-xe9712-server-racks — retrieved 2026-05-10 — Dell shipped first "enterprise-ready" GB200 NVL72 racks.
[8] https://www.storagereview.com/news/coreweave-unveils-first-dell-xe9712-gb200-nvl-72-system — retrieved 2026-05-10 — CoreWeave's first Dell XE9712 deployment.
[9] https://www.supermicro.com/en/pressreleases/supermicros-dlc-2-next-generation-direct-liquid-cooling-solutions-aims-reduce-data — retrieved 2026-05-10 — DLC-2 specs: 250kW in-rack CDU, 45°C inlet, 98% heat capture, 40% power savings.
[10] https://deepfundamental.substack.com/p/deep-dive-liquid-cooling — retrieved 2026-05-10 — Vertiv 70% of first-batch GB200 NVL72 cooling volume.
[11] https://www.prnewswire.com/news-releases/supermicro-adds-largest-silicon-valley-campus---new-dcbbs-facility-to-advance-the-delivery-of-next-generation-ai-data-centers-302753486.html — retrieved 2026-05-10 — April 2026 32.8-acre/714k sq ft DCBBS campus.
[12] https://www.supermicro.com/en/pressreleases/supermicro-expands-global-manufacturing-footprint-increasing-worldwide-rack-scale — retrieved 2026-05-10 — 5,000 rack/month global capacity.
[13] https://www.prnewswire.com/news-releases/supermicro-expands-collaboration-with-nvidia-and-strengthens-compliance-data-integrity-and-quality-of-us-based-manufacturing-of-ai-infrastructure-solutions-optimized-for-government-applications-302597210.html — retrieved 2026-05-10 — TAA-compliant Vera Rubin NVL144/CPX in 2026.
[14] https://www.supermicro.com/en/pressreleases/supermicros-revolutionary-data-center-building-block-solutionsr-dcbbs-simplify — retrieved 2026-05-10 — DCBBS bundle: 200kW–1.8MW CDUs, full data-center-from-one-vendor.
[15] https://www.supermicro.com/white_paper/white_paper_SuperCloud-Composer.pdf — retrieved 2026-05-10 — SuperCloud Composer Redfish-based composability stack, Kubernetes/Elastic telemetry.
[16] https://x.com/Beth_Kindig/status/1832407478748778950 — retrieved 2026-05-10 — CoreWeave ~22% of SMCI revenue Q3'23–Q3'24.
[17] https://wccftech.com/super-micro-computer-smci-has-revealed-a-new-customer-g-responsible-for-31-percent-of-its-revenue-in-fiscal-q225/ — retrieved 2026-05-10 — "Customer G" 31% of Q2 FY25 revenue.
[18] https://ir.supermicro.com/news/news-details/2025/Supermicro-Announces-Strategic-Partnership-with-DataVolt/default.aspx — retrieved 2026-05-10 — $20B multi-year DataVolt/Saudi partnership.
[19] https://www.astutegroup.com/news/industrial/advanced-packaging-demand-soars-nvidia-secures-60-of-cowos-capacity/ — retrieved 2026-05-10 — NVIDIA ~60% of CoWoS capacity, 510k CoWoS-L wafers 2026.
[20] https://markets.financialcontent.com/stocks/article/tokenring-2026-1-23-the-great-packaging-surge-tsmc-targets-150000-cowos-wafers-to-fuel-nvidias-rubin-revolution — retrieved 2026-05-10 — TSMC 150k/month CoWoS by end-2026, ~4× late 2024.
[21] https://www.digitimes.com/news/a20251224PD225/hbm3e-samsung-2026-sk-hynix-hbm4.html — retrieved 2026-05-10 — HBM3e ~20% price hike for 2026; supply sold out.
[22] https://www.astutegroup.com/news/general/sk-hynix-holds-62-of-hbm-micron-overtakes-samsung-2026-battle-pivots-to-hbm4/ — retrieved 2026-05-10 — HBM share: Hynix 62%, Micron 21%, Samsung 17%; HBM4 transition.
[23] https://www.genaitech.net/p/nvidias-4b-cpo-bet-scaleout-first — retrieved 2026-05-10 — NVIDIA $4B Coherent+Lumentum; 1.6T/EML shortfall 40-60% through 2027.
[24] https://ir.supermicro.com/news/news-details/2026/Supermicro-Announces-Support-for-Upcoming-NVIDIA-Vera-Rubin-NVL72-HGX-Rubin-NVL8-and-Expanded-Rack-Scale-Manufacturing-Capacity-for-Liquid-Cooled-AI-Solutions/default.aspx — retrieved 2026-05-10 — Vera Rubin NVL72/NVL144 SMCI support announcement.
[25] https://medium.com/@escher-capital/the-5-year-turbine-wait-is-the-real-ai-energy-story-old-turbines-will-increase-demand-30-as-e9720116b86b — retrieved 2026-05-10 — Heavy-frame turbine 5-7 yr backlog; GE Vernova 2026-27 sold out.
[26] https://www.canarymedia.com/articles/data-centers/pjm-record-capacity-costs-rising-bills — retrieved 2026-05-10 — PJM 2026-27 capacity at $329/MW-day vs $28.92 two years prior.
[27] https://modoenergy.com/research/en/ercot-data-center-buildout-projection-load-forecast-senate-bill-six-gas-turbine-shortage — retrieved 2026-05-10 — Oncor 186GW of ERCOT interconnect requests; ERCOT 35GW DC peak by 2035.
[28] https://www.tweaktown.com/news/101177/dell-poweredge-xe9712-nvidia-gb200-nvl72-based-ai-gpu-cluster-for-llm-training-inference/index.html — retrieved 2026-05-10 — Dell XE9712 250kW air + 750kW DLC capacity.
[29] https://www.tweaktown.com/news/98852/nvidias-new-gb200-ai-servers-led-by-foxconn-with-40-and-quanta-30-ships-in-q3-2024/index.html — retrieved 2026-05-10 — Foxconn 40%, Quanta 30% of GB200 NVL72 assembly.
[30] https://www.networkworld.com/article/4147841/idc-dell-leads-server-market-driven-by-ai-infrastructure-needs.html — retrieved 2026-05-10 — IDC Q4 2025: Dell 10% / SMCI 9% / HPE+Lenovo lower; total $125B.
[31] https://wccftech.com/nvidia-starts-diverting-orders-away-from-super-micro-computer-smci-as-a-potential-delisting-and-doj-investigation-loom-large/ — retrieved 2026-05-10 — NVIDIA diverted orders from SMCI during 2024 scandal.
[32] https://www.digitimes.com/news/a20251113PD201/nvidia-ai-server-odm-foxconn-production.html — retrieved 2026-05-10 — NVIDIA centralizing assembly with Foxconn/Wistron/Quanta.
[33] https://carboncredits.com/dells-ai-server-boom-powers-record-earnings-and-a-net-zero-push/ — retrieved 2026-05-10 — Dell $25B FY26 AI shipments; $43B backlog entering FY27.
[34] https://www.tomshardware.com/tech-industry/artificial-intelligence/supermicro-to-help-musk-scale-xai-supercomputer-to-a-million-gpus-supermicro-will-set-up-local-operations-in-memphis-to-facilitate-operations — retrieved 2026-05-10 — SMCI Memphis presence for xAI 1M-GPU scale.
[35] https://www.supermicro.com/en/pressreleases/supermicro-expands-its-portfolio-performance-and-efficiency-driven-air-cooled-ai — retrieved 2026-05-10 — SMCI 10U air-cooled MI355X; 4U liquid-cooled MI355X.
[36] https://www.ainvest.com/news/super-micro-computer-gross-margin-decline-signals-high-risk-investment-ai-driven-world-2509/ — retrieved 2026-05-10 — Margin compression: mid-teens 2023 → 11.1% FY25 → 6.4% Q2 FY26; Blackwell GM 77.6%.
[37] https://markets.financialcontent.com/stocks/article/marketminute-2026-1-27-super-micro-computer-smci-regains-nasdaq-compliance-after-high-stakes-accounting-saga-igniting-fresh-market-volatility — retrieved 2026-05-10 — SMCI regained Nasdaq compliance Jan 2026; DOJ probe overhang remains.
[38] https://www.stratviewresearch.com/3624/data-center-liquid-cooling-market.html — retrieved 2026-05-10 — SMCI–Fujitsu–Nidec liquid-cooling partnership context.