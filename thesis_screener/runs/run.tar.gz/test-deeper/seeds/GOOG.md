I have enough to write the dossier. Drafting now.

# GOOG — Alphabet Inc.

## Where this sits in the AI stack
Alphabet is the only Western hyperscaler that is **vertically integrated from accelerator silicon up through the application layer**: it co-designs the TPU ASIC with Broadcom (TSMC N3P, MediaTek/GUC on physical implementation) [1][12], owns the system-level fabric (Inter-Chip Interconnect over a 3D torus stitched by Google's home-built Palomar/Apollo optical circuit switches) [14], operates the data centers, writes the compiler stack (XLA, JAX, Pathways, and now a native TorchTPU PyTorch backend) [15], trains its own frontier models (Gemini 3 Pro, Deep Think) [Gemini-3], and serves them to billions of users via Search/AI Overviews/Gemini app and to outside frontier labs (Anthropic, Meta) via GCP [2][13]. The company is simultaneously a silicon vendor, a cloud landlord, a model provider and a consumer/ad business — a stack shape no other public company has.

## Snapshot
- **Price:** $397.05 (2026-05-08 close; all-time-high close $400.80 same day) [21]
- **Market cap:** ~$4.84T [21]
- **52-week range:** ~$148 – ~$401 (range spans the 2025 mid-summer DOJ-ruling drawdown to the May-26 ATH) [21][24]
- **Forward P/E:** ~27.9× (price ÷ FY26 consensus EPS $14.22, recently revised up from $11.63) [public.com forecast]
- **EV / NTM revenue:** ~9.5–10× (inference; based on ~$485B FY26 consensus revenue and ~$80B net cash; mark as approximate, not directly sourced)
- **Consensus 12-month price target:** ~$391.6 (45-analyst average); **stock now trades through consensus** — implied -1% [public.com]
- **YTD total return:** +24% (per stockanalysis aggregate) [21]
- **Short interest:** ~1.37% of float (~80M sh GOOGL) [marketbeat short interest]

## Moat — what it is physically made of

Alphabet's moat is a stack of **four distinct compounding assets**, only one of which is brand:

**1. The TPU + ICI + OCS system as one machine.** The unit of competition is no longer a chip — it is a 9,216-accelerator Ironwood pod delivering 42.5 FP8 ExaFLOPS, with 1.77 PB of HBM3e, stitched by 9.6 Tb/s ICI links into a 3D torus and reconfigured by Apollo OCS [1][3][14][26]. The OCS layer is the under-appreciated piece: a 136×136 optical switch at 108 W vs. ~3,000 W for an electrical equivalent, deployed in tens of thousands of units over five years [14]. NVIDIA's NVL72 tops out at 72 GPUs in a copper-backplane scale-up domain; Google's scale-up domain is two orders of magnitude larger, and the OCS substrate lets Google route around failed chips/links without re-cabling — a fault-tolerance edge that compounds at the time scale of months-long pretraining runs. SemiAnalysis estimates Ironwood TCO is **~44% below GB200 internally; ~30% below for Anthropic renting via GCP after Google/Broadcom margins; ~52% below GB300 at 40% MFU on a training workload** [1]. That is the moat — not the FLOPs number.

**2. The software stack — and the defection of PyTorch.** The historical knock on TPUs was JAX-only. That barrier collapsed in 2026 with **TorchTPU**, a native PyTorch backend (not the older lazy-tensor PyTorch/XLA) that compiles `torch.compile` graphs through StableHLO directly to TPU binaries with first-class FSDPv2/DTensor/DDP support [15]. This narrows but does not close the CUDA gap: Flash Attention 3, vLLM, HuggingFace pipelines, PEFT and the bulk of inference serving infrastructure remain CUDA-native today [JAX-vs-CUDA search]. Durability assessment: the *training* moat (where Anthropic and Google itself sit) is functionally portable now; the *long-tail inference and research* moat for NVIDIA is still intact. This is a 12–24 month displacement story for training workloads, multi-year for everything else.

**3. Manufacturing relationships locked through 2031.** Broadcom has a Google TPU agreement running through 2031 [10]; the 3.5 GW Anthropic-Google-Broadcom deal from 2027 is contracted [9]; HBM3e is sold out through 2026 across SK Hynix, Micron and Samsung, and Google's allocation is locked via existing offtake [16]. NVIDIA reportedly takes ~60% of TSMC CoWoS-L through 2026 [16] — Google takes most of what's left. **Allocation is the moat behind the moat.** A new entrant cannot simply order more.

**4. Captive demand: own model, own ad inventory, own distribution.** Gemini 3 Pro (released Nov 2025) hit 91.9% GPQA Diamond, 31.1% on ARC-AGI-2 (~2× GPT-5.1's 17.6%), and Google reported AI-response cost fell **30% post-Gemini 3** [Gemini-3]. The Gemini 3-driven inference cost curve directly funds capex, because Search ad revenue grew 19% YoY to $60B in Q1'26 with AI Overviews monetizing better than the legacy 10-blue-links inventory [22][7]. No competitor pairs frontier silicon with billions of monetizable user queries.

What is **not** the moat: Google brand, balance sheet (everyone has one), Sundar.

## AI buildout bottleneck map

| Constraint (next 24 mo) | Status | GOOG position |
|---|---|---|
| HBM3e / HBM4 supply | Sold out through 2026 across SK Hynix, Micron, Samsung [16] | **Beneficiary** — pre-allocated; HBM goes onto its TPUs whether NVIDIA or Google |
| CoWoS-L advanced packaging | TSMC scaling 35K → 130K wpm end-2026; NVIDIA takes ~60% [16] | **Constraint owner / co-allocator** — Broadcom-routed Google volume is second largest after NVIDIA |
| Grid power & interconnect | US DC demand 50→76 GW by 2026; 30% of new builds now on-site generation [17] | **Beneficiary at a disadvantage** — lower W/FLOP and lower W/token than Blackwell, but still gated by same utility queues; has the cash to do behind-the-meter |
| Liquid cooling at >100 kW/rack | Industry-wide; Ironwood pods are dense | **Indifferent** — solved internally for years (TPU v4 was already liquid-cooled) |
| Optical interconnect / OCS | Apollo OCS: >$3B internal deployment, no peer at scale [14] | **Sole owner** of the highest-leverage scale-up technology |
| Kernel/compiler talent | Globally scarce | **Beneficiary** — DeepMind + JAX team + the people who wrote the original XLA |
| Frontier training data | Quality plateau, synthetic data race | **Beneficiary** — YouTube, Search, Books, Maps; uniquely large multimodal corpus |
| Electrical contractor capacity | Tight in PJM, ERCOT, MISO | **Exposed customer** — same constraint as everyone else |

The single largest swing factor: **Google is the only hyperscaler whose accelerator allocation is not gated by NVIDIA's CoWoS-L queue position.** That is a capex decoupling worth quantifying when modeling 2027.

## Competitive teardown

**vs. NVIDIA (Blackwell GB300, Vera Rubin upcoming).** On per-chip peak FP8 FLOPs, Ironwood is roughly at parity to slightly behind GB200 on paper; SemiAnalysis pegs Ironwood at "20–30% faster on paper" *at the system level* once ICI/OCS scale-up is factored in [1]. Blackwell Ultra swept MLPerf Training v5.1 [18] but Google rarely submits to MLPerf, so direct apples-to-apples is sparse — that is itself a thesis-relevant data gap. NVIDIA's untouchable moat remains **single-node inference for the long tail** (cuDNN/CUTLASS/Triton/TensorRT/vLLM stack, ~4M+ CUDA developers, every research paper's first implementation). Where Google takes share: large-scale **training and high-batch inference** for customers whose workloads fit a Gemini/Claude-shape transformer. Where NVIDIA holds: everything else, plus the gravity of the ecosystem.

**vs. AWS Trainium2/3.** AWS has scale (Project Rainier ~500K Trainium2 live, scaling to 1M+ for Anthropic, 5 GW total commitment) [19][20]. But Trainium's NeuronSDK is a weaker compiler story than XLA, the multi-node fabric (EFA over Ethernet) is generations behind ICI+OCS in scale-up bandwidth, and Trainium's third-party adoption outside Anthropic remains limited. AWS wins on cloud distribution and price; loses on system-level training efficiency.

**vs. Microsoft Maia 200.** Maia 200 is **inference-only**, 10 PFLOPS FP4, 750 W, TSMC N3, 216 GB HBM3e [10]. Microsoft openly positions it as a cost-cutting alternative to Nvidia for serving GPT-5.x workloads on Azure. Not a training competitor to TPU. Validates the custom-silicon thesis for Google by extension; not a direct threat.

**vs. AMD MI400/MI455X (Helios rack, Q3 2026).** TSMC N2, 31 TB HBM4 per 72-GPU rack, 1.4 PB/s aggregate bandwidth [11]. AMD has the OpenAI 6 GW deal and Meta 6 GW deal [11][AMD-Meta]. Per-chip and per-rack specs look strong. The gating question is **multi-rack scale-out fabric**: AMD/UALink/Ultra Ethernet vs. Google's OCS+ICI. Helios at 72 GPUs is still a copper scale-up domain like NVL72 — same architectural ceiling. AMD takes the "second source to NVIDIA" trade more than the "Google killer" trade.

**External TPU adoption** (the asymmetric upside): Meta signed a multi-billion dollar TPU **rental** deal in Feb 2026 with optional **purchase** by 2027 for on-prem deployment [13][25], and Google's CFO confirmed Q1'26 TPU hardware sales to select external customers, with material balance-sheet impact in 2027 [25]. **This is the structural break** — TPU becomes a merchant accelerator, not just a captive workload.

## Bull case — technical

The technical conditions for outperformance: (1) Ironwood maintains its ≥30% TCO advantage over Blackwell-class chips through the GB300/Vera Rubin transition — durable because OCS+ICI scale-up is not replicable in 24 months; (2) TorchTPU adoption pulls a meaningful slice of the PyTorch training population off CUDA — even 10% would be a step change in TPU's addressable market; (3) Anthropic's 1M-chip / 1+GW deployment ramps on schedule, demonstrating production-grade training at scale on TPU [2][9]; (4) Meta moves from rental to purchase in 2027, validating TPU as a merchant chip [13]; (5) Gemini's per-token inference cost continues to compress (already -30% with Gemini 3 [22]) so Search ad gross profit absorbs the capex without margin compression. Financial outcome: Cloud sustains 50%+ growth on a $462B backlog [7], operating leverage carries Cloud margin from 32.9% toward NVIDIA-style 40%+, and a TPU merchant business adds a third revenue leg.

**Base rate caveat on displacement:** Platform shifts in compute take longer than bulls expect — CUDA was launched in 2007 and was unchallenged for 15+ years; x86 displaced RISC over a decade; ARM in mobile took even longer. Even if the technical conditions hold, the *market-share* path is years, not quarters. The bull thesis on Google is "best-positioned challenger over a 5-year horizon," not "NVIDIA killer in 2027."

## Bear case — technical

The technical conditions under which the moat erodes:

1. **NVIDIA's Vera Rubin (2026/27) closes the system-level gap.** Rubin Ultra is targeting NVL576-class scale-up domains with co-packaged optics, which would erase the OCS scale-up advantage. If Rubin lands on time and in volume, the 30% TCO gap compresses materially.
2. **CUDA displacement just doesn't happen.** TorchTPU is necessary but not sufficient — Flash Attention 3, vLLM, the PEFT ecosystem, and the long tail of CUDA-only research code remain barriers. If JAX/TorchTPU adoption stays narrow (Anthropic + Google internal + maybe Meta), TPU never becomes a merchant chip at scale and Google is left running its own cloud with its own chips for itself — fine, but not a NVIDIA-grade moat.
3. **AI Overviews cannibalize Search faster than Gemini ads monetize.** Google Network revenue already fell 4% in Q1'26 [google-q1-2026-network-rev]; the question is whether the Search ad cannibalization shows up in 2027 when free-tier Gemini agents intermediate more queries. The 19% Search growth could reverse into a deceleration.
4. **Capex becomes a permanent margin headwind.** $180–190B in 2026, "significantly more" in 2027 [5]. If Cloud demand normalizes and revenue growth slows from 63% to 30%, the 5–6 year depreciation schedule on TPU/server fleet eats Group operating margin.
5. **DOJ remedy escalation.** Mehta declined Chrome divestiture but the DOJ cross-appeal is live [24]. A circuit court reversing on Chrome or mandating choice screens hits the ad-flywheel that funds the entire AI stack. Low probability, very high severity — this is the actual tail risk.
6. **Anthropic concentration.** A meaningful chunk of TPU external demand is one customer. If Anthropic shifts toward Trainium (where they have $100B AWS commitment vs. ~$20-40B GCP) [20] for cost or strategic reasons, the merchant-TPU narrative weakens immediately.

The honest bear is not "Gemini loses to GPT" — it is "TPU never escapes the gravitational pull of being a captive chip, and CUDA wins by being good-enough everywhere."

## Market view check

At ~$397/$4.84T, GOOG trades at ~28× FY26 EPS — a *premium* to its 5-year average but a *discount* to MSFT (~32×) and well below NVDA (~38×). Stock has run *through* the consensus 12-month target ($391.6) [public.com], which is rare and signals analysts are catching up rather than calling overshoot. The market is currently pricing GOOG as: (a) Cloud is durably a 50%+ grower, (b) Search holds despite AI cannibalization, and (c) TPU has merchant optionality. It is **not** pricing in: TPU as a $50B+ standalone hardware franchise by 2028, or a meaningful CUDA defection. My read: price is fair-to-slightly-cheap given the technical reality, but the asymmetric upside is the merchant-TPU optionality that is not in any consensus model. The market is paying for Cloud + Search + a small Gemini option; it is getting a TPU silicon franchise for free.

## 90-day falsifiers

1. **Q2'26 earnings (late July 2026):** Cloud revenue growth — does it sustain ≥55% YoY, and does backlog continue to expand QoQ from $462B? <50% growth or backlog flat would dent the capacity-constrained-demand narrative.
2. **MLPerf Training v6 / Inference v6.x submissions** (typically June and September): Does Google submit Ironwood numbers? Even one credible submission shifts the technical-credibility distribution.
3. **TorchTPU GitHub activity:** Stars, forks, third-party model ports. Look for >5 well-known model repositories adding TPU as a first-class target by Q3 2026.
4. **Meta TPU purchase decision:** A confirmed 2027 on-prem TPU purchase from Meta (vs. continued rental) would lock in the merchant thesis. Silence or a shift toward Trainium/MI400 would weaken it.
5. **CoWoS-L allocation reshuffles:** Watch TSMC commentary on the late-July earnings call. Any reallocation toward Broadcom (i.e., Google) at NVIDIA's expense is a direct read-through.
6. **DOJ appeal milestones:** Oral arguments scheduling at the D.C. Circuit. Date certainty alone moves the stock.
7. **Anthropic disclosed mix shift:** Any quarterly disclosure of training/inference compute split between TPU and Trainium.
8. **Capex revision:** A guide-up at Q2 above the $180–190B range with management saying "still demand-constrained" is bullish; a guide-down is the bear cue.

## What I could not verify

- Independent (i.e., non-Google, non-SemiAnalysis) MLPerf-style benchmarks for Ironwood vs. GB300 at multi-node scale on a frontier-class architecture. SemiAnalysis's TCO numbers are rigorous but proprietary and not externally reproducible.
- Exact Google share of TSMC CoWoS-L allocation (NVIDIA's ~60% is sourced; Google's residual is implied, not stated).
- Gemini 3 Pro training compute (FLOPs, parameter count, dataset size) — Google has not disclosed.
- Precise breakdown of Anthropic's 5-year compute spend across AWS Trainium vs. Google TPU vs. Nvidia — public commitments overlap and one-time announcements double-count.
- Real Meta TPU spend size and timing of any 2027 on-prem purchase — reported but not contracted publicly.
- Forward EV/NTM revenue is computed from approximate net-cash and consensus-revenue figures; treat as indicative.
- True exposure of Cloud revenue to AI training vs. classical workloads — Google does not break this out.
- DOJ appeal calendar precision.

## Sources

[1] https://newsletter.semianalysis.com/p/tpuv7-google-takes-a-swing-at-the — retrieved 2026-05-10 — SemiAnalysis: Ironwood TCO 44%/30%/52% advantages, 400K Anthropic Ironwood + ~$10B Broadcom, 600K via GCP for ~$42B RPO, native PyTorch backend
[2] https://www.anthropic.com/news/expanding-our-use-of-google-cloud-tpus-and-services — retrieved 2026-05-10 — Anthropic confirms up to 1M TPUs, >1 GW capacity, 2026 onset
[3] https://cloud.google.com/blog/products/compute/inside-the-ironwood-tpu-codesigned-ai-stack — retrieved 2026-05-10 — Ironwood codesign architecture
[5] https://www.datacenterdynamics.com/en/news/google-estimates-2026-capex-of-up-to-185bn/ — retrieved 2026-05-10 — Alphabet $180–190B 2026 capex guide
[7] https://www.cnbc.com/2026/04/29/alphabet-googl-q1-2026-earnings.html — retrieved 2026-05-10 — Q1'26 results: Cloud $20B +63%, $462B backlog, $109.9B total revenue
[9] https://www.tomshardware.com/tech-industry/broadcom-expands-anthropic-deal-to-3-5gw-of-google-tpu-capacity-from-2027 — retrieved 2026-05-10 — Anthropic-Broadcom-Google 3.5 GW from 2027; Anthropic ARR past $30B
[10] https://www.tomshardware.com/pc-components/cpus/microsoft-introduces-newest-in-house-ai-chip-maia-200-is-faster-than-other-bespoke-nvidia-competitors-built-on-tsmc-3nm-with-216gb-of-hbm3e — retrieved 2026-05-10 — Maia 200 specs: TSMC N3, 216 GB HBM3e, 10 PFLOPS FP4, 750 W, inference-only
[11] https://www.datacenterdynamics.com/en/news/amd-unveils-full-mi400-product-lineup-claims-mi500-chips-will-deliver-1000x-increase-in-ai-performance/ — retrieved 2026-05-10 — AMD MI400 lineup, Helios rack with 72 GPUs / 31 TB HBM4 / 1.4 PB/s
[12] https://www.jonpeddie.com/news/ironwood-chetyorka-google-broadcom-mediatek-and-tsmc/ — retrieved 2026-05-10 — Four-partner Ironwood supply chain (Google, Broadcom, MediaTek, TSMC), Broadcom contract through 2031
[13] https://www.tomshardware.com/tech-industry/billion-dollar-ai-chip-deal-between-google-and-meta-could-be-on-the-cards-would-involve-renting-google-cloud-tpus-next-year-outright-purchases-in-2027 — retrieved 2026-05-10 — Meta-Google TPU rental Feb 2026, possible 2027 on-prem purchase
[14] https://newsletter.semianalysis.com/p/google-apollo-the-3-billion-game — retrieved 2026-05-10 — Apollo OCS: Palomar 136×136 switch, 108 W vs. 3,000 W EPS, >$3B internal deployment
[15] https://developers.googleblog.com/torchtpu-running-pytorch-natively-on-tpus-at-google-scale/ — retrieved 2026-05-10 — TorchTPU native PyTorch backend, FSDPv2/DTensor support, 2026 roadmap
[16] https://info.fusionww.com/blog/inside-the-ai-bottleneck-cowos-hbm-and-2-3nm-capacity-constraints-through-2027 — retrieved 2026-05-10 — TSMC CoWoS scaling to 130K wpm end-2026, NVIDIA ~60% share, HBM sold out through 2026
[17] https://www.datacenterfrontier.com/energy/article/55363740/the-gigawatt-bottleneck-power-constraints-define-ai-data-center-growth — retrieved 2026-05-10 — US DC demand 50→76 GW by 2026; transmission queue gating
[18] https://blogs.nvidia.com/blog/mlperf-training-benchmark-blackwell-ultra/ — retrieved 2026-05-10 — Blackwell Ultra MLPerf Training v5.1 sweep
[19] https://www.datacenterdynamics.com/en/news/aws-activates-project-rainier-cluster-of-nearly-500000-trainium2-chips/ — retrieved 2026-05-10 — Project Rainier ~500K Trainium2 active, 1M+ for Anthropic
[20] https://www.aboutamazon.com/news/company-news/amazon-invests-additional-5-billion-anthropic-ai — retrieved 2026-05-10 — Amazon-Anthropic expanded deal: $33B equity, 5 GW Trainium capacity
[21] https://stockanalysis.com/stocks/goog/history/ — retrieved 2026-05-10 — GOOG price history including $397.05 May 8 close, $400.80 ATH, ~$148–$401 range, +24% YTD
[22] https://www.forrester.com/blogs/genai-is-rebuilding-search-and-google-is-still-winning-q1-2026-search-revenue-up-19-yoy/ — retrieved 2026-05-10 — Q1'26 Search +19% YoY; AI Overviews monetization
[24] https://www.cnbc.com/2025/09/02/google-antitrust-search-ruling.html — retrieved 2026-05-10 — Mehta declined Chrome divestiture; behavioral remedies; appeals pending
[25] https://www.theregister.com/2026/04/30/alphabet_google_q1_fy26/ — retrieved 2026-05-10 — Pichai confirms TPU hardware sales to select external customers, larger 2027 impact
[26] https://www.trendforce.com/news/2025/11/07/news-google-unveils-7th-gen-tpu-ironwood-with-9216-chip-superpod-taking-aim-at-nvidia/ — retrieved 2026-05-10 — Ironwood 9,216-chip pod / 42.5 FP8 ExaFLOPS spec disclosure
[Gemini-3] https://blog.google/products-and-platforms/products/gemini/gemini-3/ — retrieved 2026-05-10 — Gemini 3 Pro release, 91.9% GPQA Diamond, 31.1% ARC-AGI-2