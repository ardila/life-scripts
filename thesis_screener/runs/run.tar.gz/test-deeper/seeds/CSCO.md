# CSCO — Cisco Systems, Inc.

## Where this sits in the AI stack
Cisco sells **Ethernet switching/routing silicon and systems, coherent pluggable optics, GPU servers, and observability/security software** that wrap the AI back-end (GPU↔GPU and DC↔DC) and front-end (storage/management) networks. The AI-relevant products are: Silicon One G200/G300 switching ASICs in the Nexus 9000 family, the Silicon One P200 deep-buffer routing ASIC in the 8223 router (scale-across between AI sites), Acacia 800G ZR/ZR+ coherent pluggables, UCS C885A/X580p HGX servers, and Splunk's observability/SIEM stack. Cisco does **not** make the GPU, the HBM, the package, the rack, or the kernel libraries — it is a networking/optics/observability layer wrapped around hyperscaler training clusters and enterprise inference deployments [1][2][6][8].

## Snapshot
- **Price:** $96.75 (2026-05-08 close; 2026-05-10 is Sunday) [3]
- **Market cap:** $381.4B [3]
- **52-week range:** $59.44 – $97.02 (trading near 52-wk high) [3]
- **Forward P/E:** ~23.3× on company-guided FY26 (Jul-end) non-GAAP EPS $4.13–$4.17; ~18.4× on FY27 consensus (GuruFocus) [9][13]
- **EV / NTM revenue:** ~5.3× ($327.85B EV / $61.2–$61.7B FY26 guide) [10][13]
- **Consensus 12-month price target:** ~$90 median (38 analysts, range $75–$100) — **implies ~−7% from price**, i.e. Street is mildly negative at current level [9]
- **YTD total return:** +17–21% (varies by source / dividend treatment) [10]
- **Short interest (% of float):** 1.33% (Feb 2026 settlement; ~52.5M shares short) — well below 7.94% peer-group average [11]

## Moat — what it is physically made of
Cisco's moat is **bundled, not single-axis** — and the AI-relevant components are weaker than the legacy enterprise components. Decompose:

**1. Switching silicon (Silicon One). Moderate and improving, but not dominant.** G200 is a 5nm, 51.2 Tbps monolithic ASIC with 512×112G SerDes, configurable 64×800G or 512×100G, with built-in dynamic load balancing, fault isolation and a fully shared on-die buffer designed to compress AI/ML job-completion-time tail latency [1]. P200 is a separate **deep-buffer programmable router chip** at 51.2 Tbps with 64×800G coherent ports and ~20Bpps, engineered for **scale-across** (campus/metro DCI between AI sites), with claimed ~65% lower power than prior gen [4]. Cisco shipped its **one-millionth Silicon One die in Q2 FY26** [12], and G300 (102.4 Tbps class) was announced Feb 2026 [5]. Crucially, **Cisco's switching-silicon market share is ~9.6% (2024) vs Broadcom ~54.6%** — Cisco is a fast-follower, not the incumbent merchant chip [7]. The moat here is *deployed customer trust at MSFT/Meta/Alibaba* — not an architectural advantage Broadcom can't match.

**2. Coherent pluggable optics (Acacia). Strong.** Cisco/Acacia is the merchant-silicon leader in coherent DSPs; >70% of coherent ports today are pluggable, and Acacia's 800G ZR/ZR+ in QSFP-DD/OSFP form factors carry 800GE up to 120 km (ZR) or 1000+ km (ZR+) [14]. As hyperscalers distribute training across multi-site campuses (because no single site can be powered or cooled past ~1 GW), **coherent pluggables for "Metro DCI" become a primary AI capex line** — and Cisco directly benefits regardless of who wins switching silicon. This is the most under-appreciated technical moat.

**3. Routing software/IOS-XR/NX-OS + Nexus Dashboard.** Sticky enterprise switching, but the same operator software running on Spectrum-X silicon (Nexus N9100 with NVIDIA Spectrum-X) tells you Cisco is willing to sell *anyone's* chip under its OS — they're choosing distribution over silicon margin. Defensive but not a moat versus Arista's EOS, which has parity or better at hyperscalers [15].

**4. Splunk + observability.** $28B paid (closed Mar 2024) for ~$4B revenue. The thesis — "every AI deployment generates orders of magnitude more telemetry and needs Splunk + Cisco network-side observability" — is intact but moving slowly: cloud-subscription transition is a **near-term revenue drag**, Security segment was −4% YoY in Q2 FY26 [12][8]. Cisco announced Galileo (AI-agent observability) acquisition in Apr 2026 to plug the agentic-monitoring gap [16].

**5. Enterprise installed base + channel.** The most durable component, irrelevant to AI. Catalyst/Meraki refresh cycle is real; Q2 FY26 networking +21% YoY had double-digit growth in *campus switching, wireless, and enterprise routing*, not just AI [12].

A serious competitor would need ~5–7 person-years of ASIC dev and a chip-house relationship to match G200; Acacia's coherent DSP IP is harder (10+ years and patents); the Splunk+CNAPP+SD-WAN bundle would take a decade to replicate.

## AI buildout bottleneck map
- **Power generation / grid interconnect.** Most acute constraint. Gas-turbine wait times >5 years; transmission lines 7–10 years; CenterPoint reported 700% YoY rise in large-load interconnection requests [17]. Cisco **benefits indirectly**: distributed/metro AI campuses force more long-haul DCI buys (P200 + Acacia 800G ZR+). Cisco's 8223 marketing is explicit on this [4].
- **CoWoS-L advanced packaging.** TSMC 35K→130K wafers/mo by EOY 2026; NVIDIA books ~60%, Broadcom ~15%, Google's TPU consuming most of Broadcom's slot [18]. **Cisco is largely indifferent** — Silicon One is monolithic 5nm switching, doesn't need CoWoS-L the way GPUs/TPUs do. This is rare and underrated: Cisco's AI silicon is *not* gated by the tightest bottleneck.
- **HBM3e/HBM4 supply.** Doesn't apply to switching ASICs. Indifferent.
- **Optical interconnect (LPO, CPO, coherent).** **Beneficiary.** Cisco/Acacia is a top-3 coherent vendor and is in 51.2T CPO field trials with NVIDIA [19].
- **Liquid cooling at >100kW/rack.** Cisco doesn't sell cooling. Indifferent (UCS GPU racks consume cooling but Cisco doesn't make money on it).
- **Electrical contractor capacity.** Indifferent.
- **Kernel/compiler/CUDA talent.** Indifferent — Cisco does not compete in the GPU software stack.
- **Hyperscaler capex concentration.** **Exposed customer.** AI orders in Q2 FY26 = $2.1B, but management has stated this is **"a small number of customers placing large, lumpy orders"** — concentration risk is real [20][12].

The Cisco-specific feature: it sits *adjacent to* the AI buildout's tightest constraint (power/distribution) and *benefits from* the second-tightest (optics), without having its own supply gated by CoWoS-L/HBM. That's a structurally favorable supply position.

## Competitive teardown
**vs. NVIDIA Spectrum-X (the most dangerous competitor on AI back-end Ethernet).** NVIDIA's Spectrum-X switch business hit ~$2.3B Q2 2025, +647% YoY, and ~25.9% share — passing both Cisco and Arista in *datacenter Ethernet revenue* [21][22]. Spectrum-X has reached parity-class performance with InfiniBand (xAI Colossus runs 100K-node single jobs on Spectrum-X) and now has MRC reliable-connection extensions [21][22]. **Where Cisco fights back:** scale-across (P200/8223 long-haul, where NVIDIA has no product), coherent optics (Acacia), and customers who refuse vendor lock-in to NVIDIA (notably Microsoft, which deploys both). **Honest read: NVIDIA already has parity-or-better on AI back-end at scale-up tiers; Cisco's foothold is in scale-across and as a hedge customer.**

**vs. Arista (head-to-head Ethernet AI).** Arista 2025 revenue $9B, +28.6%; targets >$10B 2026 [23][24]. Arista's customer concentration is extreme: Microsoft 26% + Meta 16% = **42% of revenue from two customers** [24]. Arista's edge is a 10+ year head start on EOS/CloudVision software in hyperscaler operations, plus tight Broadcom Tomahawk/Jericho integration. **Where Cisco fights back:** silicon ownership (Arista doesn't make chips), full-stack (servers + observability + security), and the optics business. **On a pure switching axis Arista currently wins at the same accounts; Cisco wins on bundle.**

**vs. Broadcom (merchant silicon).** Tomahawk 5 (51.2T) is parity to G200 on bandwidth; Tomahawk 6 (102.4T, 2025) is ahead of where G300 ships in volume [25][26]. Broadcom has 54.6% switching-silicon share. **Cisco does not beat Broadcom on raw silicon** — its play is owning the system, software, optics, and customer relationship, *and* Broadcom's customers (Arista, Celestica/whitebox) feed competitors.

**vs. Marvell Teralynx, Xsight, Huawei CloudEngine.** Long tail; Huawei is the China-market story Cisco can't address.

The honest competitive truth: **on the new merit axis (AI Ethernet switching ASICs), Cisco is #3–#4. On the bundle axis (silicon + system + optics + observability + security + enterprise distribution), Cisco is unique.** Whether the bundle pricing power survives unbundling pressure from hyperscalers is the central question.

## Bull case — technical
**Required to be true:**
1. AI back-end networking remains predominantly Ethernet (Dell'Oro: Ethernet >2/3 of AI back-end switch sales by Q3 2025 [4][27]) and the UEC 1.0 spec (June 2025) drives multi-vendor adoption rather than NVIDIA-only Spectrum-X [28].
2. Hyperscalers deliberately **dual-source** away from NVIDIA on networking (the explicit MSFT pattern); Cisco gets to keep & expand its 4 hyperscaler design wins as G300 (102.4T) ships in volume late-2026 [5][12].
3. Distributed/metro AI training (forced by power constraints) drives outsized growth in scale-across routing — P200/8223 — and coherent optics (Acacia 800G ZR+) [4][14].
4. UEC 1.0 commoditizes RDMA-over-Ethernet enough that *transport software* stops being NVIDIA-proprietary, eroding Spectrum-X stickiness [28].
5. Splunk integration delivers the cross-sell ("AI requires observability") — currently dragging from cloud-transition headwind, normalizes by FY27.

**Base rate caution.** Networking displacement has happened twice in 25 years: (a) Cisco displaced 3Com/Bay/Wellfleet; (b) Arista displaced Cisco at hyperscalers. Both took ~5–7 years from technical parity to share leadership. **Spectrum-X reached technical parity ~2024**, so by base rates we are mid-cycle — Cisco regaining share would be against the historical grain. The bull case requires Cisco's bundle to do what pure-play silicon couldn't.

**Financial outcome if true:** AI infra revenue compounds from $3B FY26 → $7–10B FY28; networking gross margin expands ~200 bps (mgmt's stated Silicon One contribution by FY29 [12]); EPS could push toward $5+ FY28; multiple holds 22–24×. ~$110–125 in 18–24 months.

## Bear case — technical
**Required to be true:**
1. NVIDIA Spectrum-X consolidates AI back-end Ethernet by virtue of being shipped *in the same rack as the GPU* with one SKU, one driver stack, one support contract. NVIDIA networking annualized run-rate already >$10B [22]. The bundling argument cuts the *other way*.
2. The "lumpy hyperscaler orders" become exactly that — Q3/Q4 FY26 prints a sequential decline as one or two hyperscalers digest. Mgmt has been explicit that orders are "lumpy" and concentrated [20].
3. Broadcom Tomahawk 6 (102.4T, shipping ahead of G300) becomes the default merchant chip at the next refresh — Arista, Celestica, Accton, MSFT custom designs all use it. Cisco gets squeezed *between* NVIDIA above and Broadcom below.
4. Splunk transition stays a drag and the $28B price tag never earns back; Security segment continues to decline (−4% YoY Q2 FY26) [12].
5. UEC actually accelerates *displacement* of vendor-specific stacks rather than helping Cisco — open standards historically commoditize the silicon, not the brand.
6. Enterprise AI inference largely happens on hyperscaler clouds, not on-prem UCS — Hyperfabric AI takes share from Cisco's own enterprise base, not from competitors.

**Falsifier base rate:** the last Cisco re-rating story (security platformization, 2018–2020) underdelivered for 3+ years before Splunk. Multiple compression risk if AI orders disappoint even one quarter is severe given the stock is at the 52-wk high and **consensus PT is below current price**.

**Financial outcome if true:** AI orders growth halves; networking gross margin treads water; EPS lands near guide (~$4.15) but multiple compresses to 16–18× → $66–75. Roughly −20% to −30% from current.

## Market view check
At $96.75 (~52-wk high), 23× FY26 / 18× FY27 EPS, 5.3× EV/sales, with consensus PT at $90, the market is paying a **~50% premium to Cisco's pre-AI multiple** (historically ~13–15× forward) on the thesis that AI orders compound at >50% for several years and Splunk normalizes. Sell-side has it roughly right *as a pure consensus number*: AI is real, but the price already includes it. **Where the consensus may be wrong (in either direction):** (a) it under-prices the **Acacia coherent optics** beneficiary status of distributed AI (bullish optionality the Street treats as a $200M run-rate when it could be a $1B+ AI line), and (b) it under-weights how much of the $5B AI order guide is NVIDIA Spectrum-X resold through Cisco (margin-dilutive) vs. own-silicon Silicon One (margin-accretive) — this mix is undisclosed and material [12][15][14]. The bull case is *not* in consensus; the bear case is *not* in consensus; both technical edges sit outside the price-target distribution.

## 90-day falsifiers
1. **Q3 FY26 earnings May 13, 2026 (3 days from this writing).** Watch (a) AI orders sequential vs. $2.1B Q2 — anything <$1.5B is a serious signal of lumpiness, anything >$2.5B vindicates the bull; (b) Silicon One vs. NVIDIA-resold split if disclosed; (c) gross margin direction in Networking [29].
2. **G300 (102.4T) production volume guidance** — if Cisco signals 2H CY26 volume, it lands roughly when Broadcom Tomahawk 6 is in production (i.e., parity); if it slips to 1H CY27, that's a 6-month gap behind Broadcom.
3. **Microsoft/Meta capex commentary at next earnings.** Concrete sequential declines in network capex specifically would invalidate the order-growth thesis.
4. **NVIDIA Computex / GTC announcement of Spectrum-X1600 (102.4T) timing.** Currently expected 2H 2026 [25]; an early ship undercuts Cisco's G300 window.
5. **Dell'Oro Q1 2026 Ethernet-switch tracker** — confirm whether NVIDIA's share gain (25.9% Q2 2025) accelerates past 30%, which would be terminal for the bull thesis on share gains.
6. **Arista FY26 guide revision** — if Arista raises again on Microsoft/Meta strength while Cisco's hyperscaler orders moderate, the share contest is decided.

## What I could not verify
- The **Silicon One vs. NVIDIA-resold mix** within Cisco's "$3B AI hyperscaler revenue" guide. Margin-critical and undisclosed.
- The **specific hyperscaler identities** beyond MSFT/Meta/Alibaba; mgmt cites "four major hyperscalers with triple-digit growth" without naming all four.
- **Acacia revenue contribution** to AI orders — broken out only as "balanced between Silicon One systems and pluggable optics" for the Q1 $1.3B [20].
- **Splunk net new ARR vs. churn** — only "500 new logos H1 FY26" was disclosed; no clear $-cohort retention number.
- **G300 power-per-bit benchmarks** vs. Broadcom Tomahawk 6 — not yet in independent third-party tests; vendor claims only.
- **MLPerf training/inference results** with Cisco's full-stack Hyperfabric AI vs. NVIDIA-native reference — Cisco publishes UCS+H200 results but not network-fabric-isolated comparisons.
- **Independent data on Silicon One reliability/job-completion-time** vs. Spectrum-X at >32K-GPU scale.

## Sources
[1] https://www.nextplatform.com/2025/05/21/silicon-one-g200-finally-drives-ciscos-ai-networking-business/ — retrieved 2026-05-10 — established G200 deployment momentum, hyperscaler customer base
[2] https://www.cisco.com/c/en/us/solutions/collateral/silicon-one/silicon-one-g200-ds.html — retrieved 2026-05-10 — G200 official spec sheet (51.2 Tbps, 512×112G SerDes, 64×800G config)
[3] https://stockanalysis.com/stocks/csco/ — retrieved 2026-05-10 — current price, market cap, 52-week range
[4] https://blogs.cisco.com/sp/cisco-silicon-one-p200-powers-the-first-51-2t-scale-across-routing-systems — retrieved 2026-05-10 — P200 deep-buffer router specs, 8223 65% lower power
[5] https://newsroom.cisco.com/c/r/newsroom/en/us/a/y2026/m02/cisco-announces-new-silicon-one-g300.html — retrieved 2026-05-10 — G300 announcement Feb 2026, agentic-AI positioning
[6] https://www.cisco.com/c/en/us/products/collateral/data-center-networking/nexus-hyperfabric/hyperfabric-ai-era-ds.html — retrieved 2026-05-10 — Hyperfabric reference architecture
[7] https://www.networkcomputing.com/ai-networking/ai-workloads-spur-competition-in-networking-chips — retrieved 2026-05-10 — Cisco 9.6% switching silicon share vs Broadcom 54.6%
[8] https://www.explainerds.net/splunk-the-28-billion-bet-that-finally-gives-cisco-a-data-operating-system/ — retrieved 2026-05-10 — Splunk strategic rationale, $4B revenue context
[9] https://www.marketbeat.com/stocks/NASDAQ/CSCO/forecast/ — retrieved 2026-05-10 — analyst consensus PT $90 median, range $75-100, EPS estimates
[10] https://www.financecharts.com/stocks/CSCO/performance/total-return — retrieved 2026-05-10 — YTD return, EV $327.85B
[11] https://www.benzinga.com/insights/short-sellers/26/02/50550267/looking-into-cisco-systems-incs-recent-short-interest — retrieved 2026-05-10 — Feb 2026 short interest 1.33% of float, 52.48M shares
[12] https://futurumgroup.com/insights/cisco-q2-fy-2026-earnings-ai-infrastructure-momentum-lifts-results/ — retrieved 2026-05-10 — Q2 FY26 segment breakdown, AI orders $2.1B, RPO $42.9B, 1M Silicon One chips, 200bps margin claim
[13] https://www.gurufocus.com/term/forward-pe-ratio/CSCO — retrieved 2026-05-10 — forward P/E 18.41×
[14] https://www.cisco.com/c/en/us/products/collateral/interfaces-modules/transceiver-modules/qsfp-dd-osfp-800g-zr-zr-plus-coherent-optics.html — retrieved 2026-05-10 — Cisco/Acacia 800G ZR/ZR+ specs, 120km/1000km reach, AI scale-across positioning
[15] https://www.cisco.com/c/en/us/products/collateral/networking/cloud-networking-switches/nexus-9000-switches/ai-networking-dc-nvidia-spectrum-x-so.html — retrieved 2026-05-10 — Cisco N9100 with NVIDIA Spectrum-X silicon co-development
[16] https://www.networkworld.com/article/4156855/cisco-to-acquire-galileo-for-ai-observability.html — retrieved 2026-05-10 — Galileo AI agent observability acquisition Apr 2026
[17] https://www.belfercenter.org/research-analysis/data-centers-texas-virginia-comparison — retrieved 2026-05-10 — Virginia/Texas grid constraints, CenterPoint 700% interconnect surge
[18] https://wccftech.com/nvidia-alone-has-tsmc-advanced-packaging-lines-booked-for-several-years-ahead/ — retrieved 2026-05-10 — TSMC CoWoS allocation NVIDIA 60%, Broadcom 15%
[19] https://www.naddod.com/blog/ofc-2025-recap-key-innovations-driving-optical-networking-forward — retrieved 2026-05-10 — OFC 2025 CPO trials including Cisco/NVIDIA 51.2T
[20] https://futurumgroup.com/insights/cisco-q1-fy-2026-ai-demand-lifts-outlook-and-orders/ — retrieved 2026-05-10 — Q1 FY26 AI orders $1.3B split silicon/optics, hyperscaler concentration
[21] https://www.shashi.co/2026/05/nvidia-said-spectrum-x-was-different.html — retrieved 2026-05-10 — Spectrum-X MRC reliable-connection feature
[22] https://www.digitimes.com/news/a20250930PD246/nvidia-ethernet-switch-market-genai.html — retrieved 2026-05-10 — NVIDIA $2.3B Q2 2025 switch revenue, 25.9% share, surpassing Cisco
[23] https://www.nextplatform.com/2025/02/19/arista-can-ride-ai-up-past-10-billion-in-2026/ — retrieved 2026-05-10 — Arista 2026 $10B target
[24] https://seekingalpha.com/news/4553435-bofa-highlights-microsoft-metas-contribution-to-aristas-2025-revenue — retrieved 2026-05-10 — Arista MSFT 26% + Meta 16% revenue concentration
[25] https://investors.broadcom.com/news-releases/news-release-details/broadcom-announces-tomahawkr-6-davisson-industrys-first-1024 — retrieved 2026-05-10 — Tomahawk 6 102.4T launch
[26] https://www.nextplatform.com/2025/06/03/the-ai-datacenter-is-ravenous-for-102-4-tb-sec-ethernet/ — retrieved 2026-05-10 — Tomahawk 6 timing vs NVIDIA Spectrum-X1600 (2H 2026)
[27] https://www.delloro.com/news/ai-back-end-networks-continue-their-shift-to-ethernet-now-accounting-for-over-two-thirds-of-3q-2025-switch-sales-in-ai-clusters/ — retrieved 2026-05-10 — Ethernet >2/3 of AI back-end Q3 2025 (Dell'Oro)
[28] https://semianalysis.com/2025/06/11/the-new-ai-networks-ultra-ethernet-uec-ualink-vs-broadcom-scale-up-ethernet-sue/ — retrieved 2026-05-10 — UEC 1.0 architecture vs Spectrum-X, scale-up alternatives
[29] https://newsroom.cisco.com/c/r/newsroom/en/us/a/y2026/m05/cisco-schedules-conference-call-for-q3-fiscal-year-2026-financial-results.html — retrieved 2026-05-10 — Q3 FY26 reports May 13, 2026