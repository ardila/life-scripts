# MU — Micron Technology, Inc.

## Where this sits in the AI stack
Micron sits at the **memory** layer: it fabricates DRAM (in 1α/1β/1γ nodes, Hiroshima/Taichung/Boise/Manassas) and 3D NAND, and packages 8-Hi and 12-Hi HBM stacks (24Gb DDR die over a base logic die, TSV-bonded, then handed to TSMC for CoWoS-L co-attach beside the GPU compute die). The AI-relevant SKUs are HBM3e (powering NVIDIA Blackwell/Blackwell Ultra and AMD MI355X), HBM4 (Vera Rubin, MI400), LPDDR5X SOCAMM2 modules co-designed with NVIDIA for the Vera CPU side of the Rubin platform, GDDR7 for inference cards, and DDR5 RDIMMs for host memory [1][2][8][16]. Workload exposure: HBM bandwidth is the binding constraint on FLOPs utilization in attention/MLP kernels at training, and on KV-cache/batch-size economics at inference; SOCAMM2 is the host-side analog for low-power, high-bandwidth CPU memory in disaggregated inference [11][16].

## Snapshot
- **Price:** $746.81 (2026-05-08 close — May 10 is a Sunday) [3]
- **Market cap:** $842.2B [3]
- **52-week range:** $83.36 – $759.50 [3][22]
- **Forward P/E:** 8.1× (on FY26 consensus EPS in the ~$90 area; trailing P/E 35×) [3]
- **EV / NTM revenue:** ~6.5× (annualizing FQ3 guide of $33.5B = ~$134B run-rate; net debt minimal) [4]
- **Consensus 12-month price target:** $482.90 (implied −35%) — clearly stale; analysts have not yet rerated to the post-FQ2 cycle [3]
- **YTD total return:** approximately +90–100% (stock was +68% YTD as of 2026-04-23 at ~$444; +14% on the most recent Friday alone took it to current levels) [22][27]
- **Short interest:** 3.23% of float (36.3M shares; ~1 day to cover) [9]

## Moat — what it is physically made of
The moat decomposes into pieces of very uneven durability. Honest assessment: this is **structural oligopoly + cycle position + one node of process leadership**, not a CUDA-class lock-in.

- **Three-player DRAM oligopoly.** MU + SK Hynix + Samsung = >90% of global DRAM bits [13]. Capex discipline among three rational players is the durable moat; this is a "soft" moat (cooperation, not exclusivity) and it has historically failed during downcycles.
- **1γ (1-gamma) DRAM node, EUV-enabled.** Single-EUV layer at HKMG, +30% bit density vs. 1β, DDR5 to 9.2 GT/s with -20% power, "fastest ramp to mature yield in MU history," majority of bit mix by mid-CY26 [10]. This is the most durable technical asset MU owns in 2026 — node leadership that translates to cost-per-bit and to the LPDDR5X die underlying SOCAMM2.
- **HBM3e qualification footprint.** Qualified into NVIDIA Blackwell/Ultra, AMD MI350/MI355X (12-Hi 36GB), Google TPU. MU's HBM3e is in production volume and **CY26 HBM supply is sold out, with multi-year fixed-price contracts** including upfront customer payments [4][24][26].
- **HBM4 base-die — the moat hole.** MU's internal base die under-ran NVIDIA's late-cycle 11+ Gb/s pin-speed spec; SemiAnalysis cut MU share of Vera Rubin HBM4 first-year supply to **zero**, modelling a 70/30 SK Hynix/Samsung split [12][6][14]. MU disputes this, claiming HVM with 11+ Gb/s and 2.8 TB/s is shipping for Vera Rubin [2], and is redesigning the base die during Q2 CY26 for a Rubin-Ultra/HBM4E re-entry [12]. Either way, the implication is that MU's logic-die capability is a real weakness — which is why HBM4E base die has been **outsourced to TSMC on N3P**, with custom HBM4E targeted for 2027 [15][29]. Outsourcing the base die surrenders some margin and IP control, but is a credible technical fix.
- **Manufacturing footprint expansion.** $7B Singapore HBM advanced-packaging fab (operations begin CY26, meaningful capacity CY27); Powerchip fab acquisition in Taiwan (DRAM start mid-to-late 2027); $24B Singapore NAND addition (start 2H28); Boise/Clay NY US fabs [25][30]. CapEx FY26 >$25B, FY27 to step up >$10B in construction-related spend [4]. This is a real moat component only if the Singapore HBM yield ramps cleanly — a non-trivial assumption given Hynix/Samsung have a multi-year head start in 12-Hi/16-Hi packaging.
- **SOCAMM2 with NVIDIA.** 256GB module on monolithic 32Gb LPDDR5X die, 1γ-on-EUV process, co-designed for Vera Rubin host memory; >2× bandwidth and >75% lower power than RDIMM [11]. Co-design relationships in module form-factors are stickier than commodity DRAM contracts, but NVIDIA has dual-sourced SK Hynix on the same module class [16] — so this is moat *seedling*, not moat.
- **What the moat is not.** Patents do not gate competitors; switching costs at the customer side are essentially zero (NVIDIA validates a SKU and qualifies multiple vendors); developer ecosystem is irrelevant (HBM is below the software stack). Anyone claiming MU has a CUDA-class moat is wrong; MU has a **node + capacity + 3-vendor allocation** moat, which is real but cyclical.

## AI buildout bottleneck map
- **Power generation / grid interconnect.** The hardest binding constraint of the cycle: ~76 GW US data center demand by 2026, 4-year interconnect queues in N. Virginia/Texas, hyperscalers building behind-the-meter gas turbines and signing SMR PPAs [21]. **MU position: indifferent** — sells memory regardless of where the photons come from.
- **CoWoS-L advanced packaging.** TSMC scaling 35K→130K wafers/month by end-CY26; structurally oversubscribed through 2027 [7]. **MU position: supplier whose product is gated by it.** Each Blackwell uses 8 HBM3e stacks, Rubin moves to 8–12 HBM4 stacks, Rubin Ultra to 16. CoWoS-L scarcity = HBM scarcity = MU pricing power, so MU benefits *indirectly* from a constraint it does not own.
- **HBM yield (12-Hi → 16-Hi).** This is where MU is **one of three constraint owners**. SK Hynix has thinned wafers to 30 µm to fit 16 layers within JEDEC stack height [17]; MU is shipping 12-Hi HBM4 36GB with no public 16-Hi roadmap matching that. The 16-Hi transition for Rubin Ultra in 2027 is where MU could re-enter or fall further behind.
- **HBM base-die logic process.** Newly-emerged bottleneck: as HBM transitions to advanced-node base dies (N5/N3P), only the foundries can supply. SK Hynix uses TSMC N5 for HBM4 base die; Samsung does its base die in-house at 4nm; Micron uses **its own DRAM-class base die for HBM4 and is moving to TSMC N3P for HBM4E** [15][29]. **MU position: net consumer of TSMC slot allocation** (a shared dependency with NVIDIA and SK Hynix).
- **Optical interconnect supply** (CPO, 1.6T pluggables): MU **indifferent**.
- **Liquid cooling at >100 kW/rack:** **indifferent**.
- **Kernel/compiler talent:** **indifferent**.
- **Server DDR5 bits.** The under-discussed cycle: server DRAM contract prices +90% QoQ in 1Q26; PC DRAM +100% QoQ; some forecasts revised from +55% to +95% mid-quarter [8]. **MU position: constraint owner**, splitting roughly 1/4 of the world's bits.
- **NAND bits for AI inference SSDs (SLC/QLC/TLC).** Kioxia has declared CY26 NAND output fully committed; Samsung mulling 20–30% NAND price hikes [19]. **MU position: supplier (~13% global NAND share, third-place behind Samsung/Kioxia-SanDisk).** Less levered to AI than DRAM/HBM.

## Competitive teardown
- **SK Hynix — the technical leader.** ~53–62% HBM market share through 2025; UBS models ~70% share of HBM4 for Vera Rubin first ramp [5][6]. First to demo 16-Hi 48GB HBM4 at 11.7 Gb/s using 30 µm wafer thinning [17]; first to ship paid HBM4 samples to NVIDIA in 4Q25 [18]. Already mass-producing 192GB SOCAMM2 for Vera Rubin [16]. **What would have to be true for MU to take share back: SK Hynix yield breaks at 16-Hi**, or NVIDIA forces multi-source for Rubin Ultra in 2H27, or SK Hynix's N5 base-die supply at TSMC gets squeezed by Rubin's own die allocation.
- **Samsung — the recovery story.** 17–35% HBM share depending on quarter; Samsung's 1c node yields recovered to ~50–60% (target 80%); HBM4 finally passing NVIDIA validation in Q1 2026 [13][6]. Samsung has the wafer scale, the foundry leverage (its 4nm base-die in-house), and the willingness to subsidize via the broader chaebol — the most dangerous medium-term competitor on **price**, not technology. Samsung also dominates Google TPU HBM3e (>60% supply) [13] — a customer-segmentation moat MU doesn't have.
- **CXMT (China).** Mass-producing HBM2 ahead of schedule; HBM3 targeted end-CY26; wafer capacity scaling toward 300K/month by 2026 [13]. ~3–4 years behind on HBM (HBM2 vs. HBM4 frontier). Threat axis: **commodity DDR5/LPDDR5 floor in 2027–2028**, not leading-edge HBM. CXMT's IPO at ~$4.2B will signal capex intent.
- **SanDisk + SK Hynix HBF (High-Bandwidth Flash).** The genuine architectural threat to inference HBM. NAND-based, 1.6 TB/s read bandwidth, **8–16× HBM capacity at HBM bandwidth**, fits in HBM4 footprint and stack height. First samples 2H26, first inference devices 1H27 [20]. If HBF works as advertised, large-model inference economics shift toward NAND-style hierarchies and HBM TAM growth flattens earlier than the bull case requires. MU is **not in the HBF consortium** — its NAND scale and CMOS-bonded-to-array tech are weaker than Kioxia/SanDisk's.
- **Kioxia / SanDisk NAND.** 10th-gen 300+ layer 3D NAND in 2026, partnership with NVIDIA on inference-class SSDs targeting ~100× current speeds by 2027 [19]. MU's NAND is structurally smaller and less tied to NVIDIA's AI roadmap.

## Bull case — technical
Conditions that need to hold for the stock to outperform:

1. **HBM3e remains the *de facto* AI memory through 2H26**, because Blackwell + Blackwell Ultra continue to ship in volume and the Vera Rubin ramp is gated by CoWoS-L expansion and Rubin's own TSMC N3 allocation. MU's CY26 HBM is sold out under fixed-price contracts with upfront payments [24][26] — translating directly to FQ3 guide of $33.5B and a quarterly EPS run-rate that drops a forward P/E of 8× to ~5–6× on actuals.
2. **Base-die respin completes Q2 CY26 and re-qualifies MU for Rubin Ultra (2H27) and HBM4E (2027–28)** [12][15]. The TSMC N3P base-die outsource sidesteps MU's logic-die weakness and brings customization revenue at higher gross margin [15].
3. **AMD MI400 dual-sources HBM4** — MU is already validated on MI350/MI355X HBM3e [29]; second-source dynamics typically extend to next-gen.
4. **DRAM cycle holds.** Server DDR5 +90% QoQ holds for 1–2 more quarters; the three-player oligopoly maintains capex discipline (MU $25B FY26, ramping FY27); CXMT's commodity flood arrives no earlier than 2027.
5. **SOCAMM2 becomes a category, not a SKU.** NVIDIA standardizes on SOCAMM2 for all Vera-class CPUs and follow-ons; MU holds dual-sourced position.
6. **HBF doesn't materially displace HBM in the HBM4 generation** — first products 1H27 = too late for Rubin lifecycle.

**Base rate.** Memory upcycles tend to last 6–10 quarters from the trough in pricing. The AI HBM-led cycle began approximately 4Q24–1Q25; by 1Q–2Q 2026 we are quarter 4–5 of 6–10. *Historically, peak-cycle MU multiples compress as forward earnings power gets fully discounted, even while EPS keeps printing.* The 2017–2018 DRAM cycle saw MU EPS triple while the multiple compressed from 8× to 4× and the stock topped out *before* peak earnings. Investors who bought peak-cycle on 8× P/E lost money. The 2026 cycle is structurally different in that HBM contracts are multi-year fixed-price (vs. quarterly spot), which dampens the historic whip — but does not eliminate it.

## Bear case — technical
Symmetric, written by a short-seller who reads SemiAnalysis:

1. **MU is locked out of NVIDIA Rubin HBM4 first ramp**, period. SemiAnalysis cuts MU share to **zero** for 70/30 SK Hynix/Samsung [14][12]. MU's PR claims of "HVM for Vera Rubin" reflect samples and second-tier customers, not Rubin design wins. The 11+ Gb/s base die issue is real and will not be fully fixed until the Q2 CY26 respin lands and re-qualifies, by which time SK Hynix and Samsung have year-of-experience yield advantages on 12-Hi/16-Hi.
2. **Outsourcing HBM4E base die to TSMC N3P is a confession of weakness**, not an upgrade. SK Hynix already does this on N5; Samsung does in-house at 4nm. MU is paying TSMC margin and depending on a TSMC slot whose allocation is controlled by NVIDIA and Apple-class customers. Customization-driven margin uplift will be smaller than headline implies.
3. **HBM is becoming logic-die competitive, not memory-die competitive.** MU is a memory-die company. The shift in moat-relevant skill from process density to base-die architecture, PHY, and logic-stack co-design favors integrated foundry-DRAM partnerships (TSMC + SK Hynix) over MU's standalone model.
4. **Samsung is the price assassin.** Once 1c yields cross 70%, Samsung will use HBM4 to recapture share by undercutting prices — even at zero or negative gross margin — because chaebol economics permit it. MU has no such cushion.
5. **CXMT floods commodity DRAM by 2027–28.** With 300K wafers/month coming online and DDR5 yields already at 80%, by 2H27 server DDR5 ASPs roll over. The +90% QoQ "supercycle" is the leading edge of a classic DRAM whipsaw.
6. **HBF (Sandisk + SK Hynix) cannibalizes inference HBM TAM** in 2027–28, particularly in MoE inference where capacity gates batch size more than bandwidth. MU is not in the consortium and its NAND tech is weaker than Kioxia/SanDisk's [20].
7. **The stock has run +800% off the 52-week low and +90%+ YTD**; the forward P/E of 8× discounts none of the cyclicality. At the 2018 peak MU traded at 4× forward; if 2026 EPS prints $90 and the cycle rolls into 2027, $90 → $40 normalized at 6× = $240 — i.e. -65% from current.
8. **Hyperscaler digestion risk.** A single soft Microsoft/Meta capex print would cascade into DDR5 destocking in 1–2 quarters.

## Market view check
At $747 / $842B cap on FQ3 guide of $33.5B (>$130B annualized) and FQ2 gross margin of 75% (record) [4], implied normalized EPS power is in the $80–100 range — putting forward P/E at 8× and EV/NTM revenue at ~6.5×. **The market is pricing this as peak earnings on a normalizing cycle, not as a structural rerating.** Sell-side consensus PT of $482 confirms this — analysts have not extrapolated the FQ3 guide [3]. The mispricing is asymmetric: if you believe HBM is structurally different from prior DRAM cycles (multi-year contracts, oligopoly discipline, AI demand in front-end of S-curve), the stock is cheap on EPS power. If you believe HBM is just the next DRAM cycle peaking, 8× forward P/E on peak earnings has historically been the *top*, not the bottom. **The cleanest expression of the bull thesis is: do you believe MU re-qualifies into Rubin Ultra and HBM4E and avoids the 2018-style multiple compression?** That is a technical question — base-die respin success and TSMC slot — not a macro one.

## 90-day falsifiers
- **Micron FQ3 FY26 earnings (≈ June 25, 2026):** Actual revenue vs. $33.5B guide; HBM4 customer disclosures; FY27 capex specifics; any commentary on the Q2 base-die respin completion.
- **NVIDIA GTC follow-up disclosures and AMD MI400 launch (June–July 2026):** HBM4 supplier list per platform; if MU is explicitly named on Rubin Ultra or MI400, the SemiAnalysis "zero" call breaks.
- **Samsung HBM4 NVIDIA contract finalization** (reported as imminent in 1Q26 [6]): if Samsung locks 30%+, MU's residual Vera Rubin slot drops further.
- **TrendForce / DRAMeXchange Q2 2026 contract pricing prints (mid-July):** if QoQ DDR5 contract growth decelerates from +90% to <+20%, the cycle has begun rolling.
- **TSMC Q2 2026 earnings (mid-July):** CoWoS-L allocation guidance through 2027 and any color on HBM4E base-die N3P slot allocation to MU.
- **CXMT IPO filing details:** explicit FY26 capex and HBM3 timeline.
- **Hyperscaler Q2 2026 capex prints (Microsoft, Meta, Alphabet — late July):** any sequential cut >10% triggers DRAM destocking and breaks the bull contract-pricing thesis.
- **First public HBF benchmark** from Sandisk/SK Hynix sample units (expected 2H26): if real-world bandwidth + capacity hold up at HBM-class power, the long-tail bear case starts compounding.

## What I could not verify
- **Exact HBM revenue $ for FQ2 2026.** MU stopped breaking it out; analyst estimates run $7–10B/quarter but unsourced.
- **Whether MU has *any* committed HBM4 volume in Vera Rubin first wave.** SemiAnalysis says zero [14]; MU PR implies yes [2]. These are not reconcilable from public sources.
- **1γ DRAM yield numbers.** "Fastest ramp in MU history" is a directional claim, not a number.
- **MU's 16-Hi HBM4 roadmap.** SK Hynix has demoed at 11.7 Gb/s; MU has no public 16-Hi specification.
- **Whether AMD MI400 will use MU HBM4** (only HBM3e on MI355X is confirmed) [29].
- **SOCAMM2 share split between MU and SK Hynix on Vera Rubin** (both are mass-producing).
- **The exact FY26 capex split between US fabs, Singapore, Taiwan Powerchip retrofit, and packaging** — only the >$25B aggregate and >$10B FY27 increment are disclosed [4].
- **Patent-litigation exposure** with Samsung/Hynix in HBM TSV / CoWoS attach.
- **Margin economics of TSMC-fabbed HBM4E base die** vs. MU-internal base die — directional commentary only.

## Sources
[1] https://www.micron.com/products/memory/hbm/hbm3e — retrieved 2026-05-10 — established HBM3e 8-Hi/12-Hi 24Gb die spec on 1β.
[2] https://investors.micron.com/news-releases/news-release-details/micron-high-volume-production-hbm4-designed-nvidia-vera-rubin — retrieved 2026-05-10 — MU's official claim of HVM HBM4 36GB 12-Hi for Vera Rubin at 11+ Gb/s, 2.8 TB/s.
[3] https://stockanalysis.com/stocks/mu/ — retrieved 2026-05-10 — current price $746.81, market cap $842.2B, fwd P/E 8.11×, 52-wk range $83.36–$747.21, dividend $0.60.
[4] https://www.fool.com/earnings/call-transcripts/2026/03/18/micron-mu-q2-2026-earnings-call-transcript/ — retrieved 2026-05-10 — FQ2 26: $23.9B rev (+196% YoY), 75% GM, FQ3 guide $33.5B, FY26 capex >$25B, FY27 +$10B construction; "fulfill 50%–66% of customer demand."
[5] https://www.astutegroup.com/news/general/sk-hynix-holds-62-of-hbm-micron-overtakes-samsung-2026-battle-pivots-to-hbm4/ — retrieved 2026-05-10 — Q2 2025 HBM share: SK Hynix 62%, MU 21%, Samsung 17%.
[6] https://www.trendforce.com/news/2026/02/13/news-nvidia-may-relax-hbm4-specs-as-samsung-and-sk-hynix-reportedly-face-capacity-yield-limits/ — retrieved 2026-05-10 — Samsung 1c yield ~50–60%, NVIDIA spec relaxation discussion, MU 70/30 split with Samsung modeled.
[7] https://www.trendforce.com/news/2025/12/08/news-tsmcs-cowos-l-s-reportedly-fully-booked-osat-partners-step-up-with-ases-cowop-in-focus/ — retrieved 2026-05-10 — CoWoS-L oversubscribed through 2026, OSAT spillover.
[8] https://www.trendforce.com/presscenter/news/20260202-12911.html — retrieved 2026-05-10 — DDR5 server contract +90% QoQ 1Q26, PC DRAM +100% QoQ.
[9] https://www.marketbeat.com/stocks/NASDAQ/MU/short-interest/ — retrieved 2026-05-10 — short interest 36.33M shares, 3.23% of float, ~1 day to cover.
[10] https://www.micron.com/products/memory/1gamma-dram-technology — retrieved 2026-05-10 — 1γ EUV-enabled, +30% bit density vs. 1β, DDR5 to 9.2 GT/s, -20% power; on track to be majority bit mix by mid-CY26.
[11] https://futurumgroup.com/insights/can-microns-modular-memory-upgrade-help-nvidias-cpus-outperform/ — retrieved 2026-05-10 — MU 256GB SOCAMM2 on monolithic 32Gb LPDDR5X, 1γ-on-EUV, NVIDIA Vera co-design.
[12] https://www.semimedia.cc/20648.html — retrieved 2026-05-10 — SemiAnalysis cut of MU Vera Rubin HBM4 share to zero; cause: pin-rate failure on internal base die; Q2 2026 respin planned.
[13] https://cloudnews.tech/cxmt-is-catching-up-closing-the-gap-with-samsung-sk-hynix-and-micron-in-ddr5-and-hbm-memory/ — retrieved 2026-05-10 — CXMT HBM2 in MP, HBM3 by end-2026, capacity to 300K wpm; the three big DRAM makers >90% of global market.
[14] https://x.com/wallstengine/status/2019774471360352728 — retrieved 2026-05-10 — direct SemiAnalysis quote: MU Rubin HBM share = zero, 70/30 SK Hynix/Samsung split.
[15] https://www.tomshardware.com/micron-hands-tsmc-the-keys-to-hbm4e — retrieved 2026-05-10 — MU+TSMC HBM4E base-die partnership on N3P, 2027 production target.
[16] https://videocardz.com/newz/sk-hynix-starts-mass-production-of-192gb-socamm2-for-nvidia-vera-rubin — retrieved 2026-05-10 — SK Hynix 192GB SOCAMM2 in MP for Vera Rubin (dual-source dynamic vs. MU).
[17] https://www.techpowerup.com/344834/sk-hynix-shows-16-layer-48-gb-hbm4-memory-modules-at-ces-2026 — retrieved 2026-05-10 — SK Hynix 16-Hi 48GB HBM4 at 11.7 Gb/s at CES 2026; 30 µm wafer thinning.
[18] https://www.trendforce.com/news/2025/12/16/news-sk-hynix-samsung-reportedly-deliver-paid-hbm4-samples-to-nvidia-ahead-of-1q26-contract-finalization/ — retrieved 2026-05-10 — SK Hynix and Samsung paid samples to NVIDIA, 1Q26 contracts.
[19] https://www.trendforce.com/news/2025/11/13/news-nand-giants-reportedly-cut-output-in-2h25-as-prices-surge-samsung-mulls-20-30-hike-in-2026/ — retrieved 2026-05-10 — Kioxia 2026 NAND output committed; Samsung NAND 20–30% price hike consideration.
[20] https://www.tomshardware.com/tech-industry/sandisk-and-sk-hynix-join-forces-to-standardize-high-bandwidth-flash-memory-a-nand-based-alternative-to-hbm-for-ai-gpus-move-could-enable-8-16x-higher-capacity-compared-to-dram — retrieved 2026-05-10 — HBF spec: 1.6 TB/s, 8–16× HBM capacity, samples 2H26, products 1H27.
[21] https://introl.com/blog/hyperscaler-capex-690-billion-microsoft-azure-power-bottleneck-2026 — retrieved 2026-05-10 — hyperscaler capex ~$690B 2026; structural shift to energy-constrained; ~76 GW US data center demand.
[22] https://247wallst.com/investing/2026/04/23/micron-is-up-68-ytd-as-hbm-demand-explodes-is-the-memory-rally-sustainable/ — retrieved 2026-05-10 — MU +68% YTD as of 2026-04-23 (basis for current YTD estimate after subsequent rally).
[23] https://newsletter.semianalysis.com/p/scaling-the-memory-wall-the-rise-and-roadmap-of-hbm — retrieved 2026-05-10 — SemiAnalysis HBM roadmap reference for technical specs and base-die discussion.
[24] https://seekingalpha.com/article/4881338-micron-technology-hbm-sold-out-for-2026-wall-street-is-still-underpricing — retrieved 2026-05-10 — CY26 HBM supply sold out, multi-year fixed-price contracts.
[25] https://investors.micron.com/news-releases/news-release-details/micron-breaks-ground-new-hbm-advanced-packaging-facility — retrieved 2026-05-10 — Singapore HBM packaging fab groundbreaking, ops CY26.
[26] https://www.ad-hoc-news.de/boerse/news/ueberblick/the-micron-supply-squeeze-that-has-customers-paying-upfront-for-2026/69288262 — retrieved 2026-05-10 — customer upfront payments for 2026 HBM allocation.
[27] https://capital.com/en-int/markets/shares/micron-technology-inc-share-price-1/market-cap — retrieved 2026-05-10 — May 2026 market cap update for cross-check.
[28] https://www.tomshardware.com/pc-components/dram/micron-unveils-ddr5-9200-memory-1g-process-technology-with-euv — retrieved 2026-05-10 — DDR5-9200 on 1γ + EUV.
[29] https://www.trendforce.com/news/2025/06/13/news-unpacking-amds-mi350-powered-by-tsmcs-n3p-with-samsung-micron-as-dual-hbm3e-suppliers/ — retrieved 2026-05-10 — AMD MI350 HBM3e dual-sourced from MU and Samsung.
[30] https://www.cnbc.com/2026/01/27/micron-24-billion-singapore-nand-dram-expansion-ai-memory-shortages.html — retrieved 2026-05-10 — $24B Singapore NAND expansion, production 2H28.