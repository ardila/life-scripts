# FCX — Freeport-McMoRan Inc.

## Where this sits in the AI stack
FCX is a copper, gold and molybdenum miner — it sits at the **raw-feedstock layer** beneath the AI stack, two layers below "compute." Every megawatt of AI capacity routes through transformers, busbars, MV switchgear, generator stators, and rack-scale power distribution that are ~85% refined copper by mass; an industry standard for hyperscale design is **27–33 tonnes of copper per MW of applied IT power** [1][2], and a single Microsoft-class facility of ~80MW in Chicago already consumed ~2,177 t [1]. FCX does not sell into the chip, networking, or software layers; its product is **electrolytic copper cathode** (and concentrate that becomes cathode) priced off the LME, sold to wire, cable, busbar and tube fabricators — i.e., the substrate of the *power* side of AI infrastructure, not the compute side.

## Snapshot
- **Price:** $60.89 (2026-05-06 close) [3]
- **Market cap:** $87.5B [3]
- **52-week range:** $35.15 (2025-09-25) – $70.97 (2026-04-20) [4]
- **Forward P/E:** 22.9× (April 2026 reading; industry median ~12.5×) [5]
- **EV / NTM revenue:** ~4.0–4.2× — EV $105.5B [6] against my own ~$25–26B 2026 revenue estimate (Q1 2026 ran at $6.23B [7] with mgmt guiding 2H volumes ~30% higher than 1H [8]); flagged as inference because no clean consensus sales line was sourceable
- **Consensus 12-month price target:** $68.64 mean / $70.00 median (n=21–30, range $30–$81) — implied +13–15% from spot [9]
- **YTD total return:** n/a — could not source a verified 2025-12-31 close; trailing 52-week move is +112.6% [10], so YTD is materially positive but the exact figure is unverified
- **Short interest:** 1.89% of shares outstanding (27.1M shares; not float-adjusted) [10]

## Moat — what it is physically made of
A miner's moat is not software ecosystem; it is **rock, permits, and operating learning curve**. Decomposed:

1. **Tier-1 ore bodies on >25-year remaining mine life.** Grasberg (Papua, Indonesia) is the world's #2 copper mine and the single largest gold byproduct credit on the planet — the gold credit historically pushes Grasberg's net cash cost *negative* in good price tape. Cerro Verde (Peru) is one of three Tier-1 sulfide concentrators globally. Morenci (Arizona) is the largest copper mine in North America. These are not replicable: greenfield discovery-to-first-pour now takes **15–20 years** under current permitting; global head grades have fallen from 1–2% to <0.7% over a decade and capital intensity has roughly doubled to **$15–20k per annual tonne of capacity** [11]. The moat is "you can't go buy this cheaper anywhere, and you can't build it from scratch in under a presidential cycle." Durable on a 10–20 year horizon.

2. **Permitted operating footprint inside Section 232.** FCX is the largest U.S. copper producer with seven operating mines in Arizona/New Mexico (Morenci, Bagdad, Sierrita, Safford/Lone Star, Tyrone, Chino, plus moly at Henderson/Climax). Trump's August 2025 Section 232 proclamation (50% tariff on semi-finished copper and copper-intensive derivatives, expanded April 2026) [12] does *not* tariff cathode, concentrate, anodes or scrap — it taxes the downstream — but the political signal locks in domestic capacity preference. The U.S.-located reserve base is the part of the moat that is hardest to displace because the binding constraint is permitting, not capital. Durable on a 5–15 year horizon.

3. **Heap-leach operating know-how — a "virtual mine."** FCX's Americas Leach Innovation initiative (proprietary catalysts, partnered with Jetti Resources; additive testing at Morenci with planned heat application to stockpiles) was running at a **300M lb/yr run-rate at <$1.00/lb cash cost in early 2026, with an 800M lb/yr target by 2030** [13]. At ~$6/lb LME and ~$2/lb company-average cash cost, this incremental copper is structurally higher-margin than the rest of the book and uses already-mined waste rock — no new permits, no new tailings dams. This is genuine technical moat: the chemistry and the heap-management telemetry are proprietary, and competitors (Codelco, Antofagasta) are years behind on disclosed scale. Durable on a 3–7 year horizon before competitors catch up.

4. **Bagdad autonomous haulage.** Conversion of Bagdad's haul truck fleet to fully autonomous in 2025 — the first major U.S. mine [14] — is operating-cost moat, not market moat. Worth flagging because it compounds with leach economics on the company's marginal-cost curve.

What is **not** moat: brand, distribution, or "scale" in the chip sense. FCX is a price-taker on LME and Comex; its "scale" matters only insofar as it supports unit-cost leadership at specific assets. Anyone telling you FCX has a software/ecosystem moat is selling something.

## AI buildout bottleneck map
The bottlenecks that actually gate AI capacity expansion over the next 24 months, ranked by how binding they are, with FCX's exposure:

| Constraint | Status | FCX position |
|---|---|---|
| **Grid interconnect / transmission** | DOE 2024 plan implies ~5,000 mi/yr of new high-capacity transmission needed; actual build <1/10 that pace [15]. Cable lead time 2–3 yrs, large power transformer lead time ~4 yrs (doubled since 2021) [16]. | **Direct beneficiary.** Every mile of transmission and every transformer is copper-intensive; this is the most binding non-compute bottleneck. |
| **Advanced packaging (TSMC CoWoS-L)** | Sold out through 2026 across NVDA/AMD/AVGO/Broadcom-ASIC. | **Indifferent.** No exposure; copper is not the gating input here. |
| **HBM3e / HBM4 supply** | SK Hynix / Samsung / Micron capacity-constrained. | **Indifferent.** |
| **Optical interconnect** | Co-packaged optics ramp; CW lasers, TSMC SoIC. | **Indifferent at the optics layer; beneficiary at the rack-power layer.** GB200 NVL72 racks pushed copper cable mass per rack materially higher than Hopper-era racks (NVLink5 backplane is copper, not optical). |
| **Liquid cooling at >100kW/rack** | CDU/manifold supply tight; rear-door HX backlogs. | **Beneficiary.** Cold-plate manifolds, busbar plenums and rack-power backplane all draw copper. |
| **Power generation (gas turbines)** | Aero-derivative + heavy-frame turbine backlogs at GE Vernova / Siemens Energy stretch into 2028+. | **Beneficiary.** Generator stators are copper; FCX sells into transformer/cable customers downstream. |
| **Smelting capacity (TC/RCs)** | 2026 annual benchmark settled at **$0/t** (record low) [17]; Chinese CSPT cutting >10% in 2026 [17]. | **Margin beneficiary as concentrate seller.** Negative TC/RCs mean smelters are losing money to convert FCX's concentrate — the rents accrue upstream to miners. This is a *very* unusual industry condition and is bullish for integrated/concentrate-long miners. |
| **Cu mine supply** | ICSG forecasts a **150kt refined deficit in 2026** [18]; some analysts model 330–600kt [11]; structural decline in head grades. | **Constraint owner.** FCX is one of ~5 entities that can move the curve. |

The under-appreciated point: if you ask "what gates AI capacity expansion?" the chip-supply answer is partly priced in NVDA/AVGO; the **grid-and-power answer is materially less priced** in the equity market and is where FCX sits. Cable and transformer lead times are 4× chip lead times.

## Competitive teardown
FCX is one of five global producers that matter at scale (Codelco, BHP, FCX, Glencore, Southern Copper / Antofagasta in Chile). The competition is not technical at the silicon level; it is geological and contractual.

- **BHP (Escondida + Antamina + Spence + Olympic Dam):** Targeting **1.9–2.0 Mt** total copper for FY26, of which Escondida 1.20–1.275 Mt [19]. On a like-for-like basis, BHP is the biggest single-mine operator (Escondida is on track to surpass *all of Codelco combined* in 2026 [19]) and has the better grade profile right now. **Where BHP is ahead:** unit costs at Escondida in 2025–26, project pipeline (new concentrator submitted for permit) [19]. **Where FCX is ahead:** U.S. operating footprint (Section 232 advantage), heap-leach IP, gold byproduct credit at Grasberg.
- **Codelco:** State-owned Chile, ~1.7 Mt/yr, but production has been *flat-to-down* for several years on grade decline at Chuquicamata/El Teniente; structurally undercapitalized. **Not a credible share-taker** in the next 5 years; if anything they cede ground.
- **Southern Copper (SCCO):** Mexico/Peru, ~1.0 Mt/yr, lowest cash cost in the world, but limited growth optionality given Peruvian permit gridlock at Tía María. Trades at a quality premium.
- **Antofagasta (ANTO LN):** Chile-only, 660–700kt/yr, agreed the **$0/t TC/RC** with Chinese smelters for 2026 [17] which is a *miner-favorable* outcome. Less U.S. exposure than FCX.
- **First Quantum (FM CN):** Cobre Panama remains shut (no clear restart); Zambia Kansanshi/S3 ramping. Not a near-term threat to FCX share.

The competitive axis that matters: **U.S. domiciled, in-permit, brownfield-expandable copper.** On that axis FCX is the largest single name globally — not because of technology, but because of geography. Aluminum substitution (see bear case) is the more interesting competitor than another miner.

## Bull case — technical
Conditions for FCX to outperform from $61:

1. **Grid copper intensity holds.** Aluminum substitutes at ≤30% in trunk transmission and EV chargers but does **not** displace copper in data-center rack power distribution, generator stators, or MV switchgear. (Aluminum is 60–62% as conductive as Cu; usable for >480V trunk runs but loses on space/weight in rack-density and on long-cycle reliability [20].)
2. **AI-driven data-center copper demand reaches ~500–700kt/yr by 2028–30**, against a refined market of ~28 Mt — i.e., ~2% of global demand from AI alone, but the *marginal* tonne sets the price [21][2].
3. **Smelter/concentrate squeeze persists.** TC/RCs at $0 [17] remain durable as Chinese smelter discipline holds and concentrate supply stays tight (Grasberg slow restart, no new Tier-1 startups before 2027).
4. **Grasberg restarts on revised cadence** (phased Q2 2026, ~85% of normal in 2H 2026) with no further fatal incidents [22]. The 9% five-year copper / 7% gold cut to Grasberg's plan [8] is now in numbers; further slippage is what the bear case requires.
5. **Leach run-rate scales toward 800M lb/yr** by 2030 [13], adding ~$3.5–4.0/lb of unit margin at spot and effectively a "virtual mine" without permits.

Connection to financials: FCX has disclosed **~$400M of EBITDA sensitivity per $0.10/lb of copper** [23]. At ~$6.23/lb spot vs. a $4.50/lb consensus assumption a year ago, that is ~$7B of incremental annualized EBITDA versus 2024-vintage models. Even at 22.9× forward P/E [5] (rich vs. the 12.5× sector median [5] and the 7.87× ten-year EV/EBITDA median [6]), the multiple is plausible if the structural-deficit story is underwritten over a 5-year holding period; commodity cyclicals always look "cheap on trough, rich on peak."

**Base rate caveat on technology displacement:** copper has not been displaced as the primary electrical conductor at meaningful scale in 130 years. Aluminum substitution at the *margin* has happened repeatedly (overhead transmission, building wire 1960s–70s — and reversed after the Federal Pacific aluminum-wire fires of the 1970s). The base rate of full displacement of copper at the AI-data-center power layer is ~zero on a 10-year horizon; the base rate of marginal share loss in non-critical applications (overhead lines, low-amp building feeders) is high but already in price.

## Bear case — technical
Written by a short-seller who actually understands the stack:

1. **Grasberg is one ore body and one government.** The September 8, 2025 mud rush killed 7 workers and demonstrated that the block-cave geomechanics are not fully under control [22]. Block-cave operations are inherently coupled — wet material in one drawpoint can propagate. A second incident pushes 2H 2026 below the 85% restored-rate target. PTFI's Indonesian concession was renegotiated to majority Indonesian ownership in 2018 and the 2041 extension is conditional on the Manyar smelter's performance and royalty resets — *a single Jakarta policy cycle can re-rate the asset by 30%.*
2. **Aluminum substitution accelerates** if copper sustains >$6/lb. The conductivity penalty (60–62%) is offset by 70% lower mass [20]; for medium-voltage data-center risers (>480V), the cross-section penalty is space-acceptable. If hyperscalers standardize on aluminum risers and copper-clad-aluminum cabling, you can pull **15–25% of the data-center copper-intensity number out of the demand stack** within 36 months — and the bull thesis collapses to grid + EVs alone.
3. **China demand rolls.** Chinese property and grid stimulus has been the marginal demand engine; if the grid investment cycle peaks in 2026 (which the smelter-cut announcements may already be signaling [17]), the cyclical demand support thins exactly as Grasberg returns and FCX leach scales — i.e., **supply comes back as demand softens**. This is the standard miner trap.
4. **Multiple compression on cycle turn.** EV/EBITDA at 11.74× is **49% above the 10-year median of 7.87×** [6]; a snap to mid-cycle multiple on a copper price retest of $4.50/lb implies a stock in the $35–40s before earnings catch up. The 52-week low of $35.15 [4] in September 2025 (mud-rush week) is the proof the equity can move that fast.
5. **Leach IP is reverse-engineerable.** Catalyst chemistry diffuses; Codelco and Antofagasta have public R&D lines on bioleaching and chloride leaching. If the 800M lb/yr target is competitively replicated by 2030, FCX's structural cost-curve advantage narrows.

## Market view check
At $60.89 with a $105.5B EV [3][6], the market is paying 22.9× forward earnings and ~11.7× EV/EBITDA — **rich vs. the sector median (~12.5× P/E) and vs. FCX's own 10-year EV/EBITDA median of 7.87×** [5][6]. Consensus PT $68.64 / median $70 implies ~+13–15% [9], which is "buy with conviction commensurate with a structural-deficit thesis but acknowledge the multiple isn't trough." The market is roughly **pricing in the structural-deficit story** — what it is *not* fully pricing, in my read, is (a) the differential value of U.S.-located reserves under Section 232 (which is a permanent re-rating event, not a cyclical one) and (b) the option value of leach scaling to 800M lb at <$1/lb cash cost. What the market *is* possibly under-discounting is the binary risk concentration in Grasberg — the 9% production cut already bought is unlikely to be the last revision. **Net view:** the price is roughly fair-to-slightly-cheap if you underwrite the technical thesis on a 5-year hold; it is expensive if you are looking at it on a 12-month tactical window after a 113% trailing rally [10].

## 90-day falsifiers
Specific events through August 2026:

1. **Grasberg phased restart milestone:** mgmt's "Q2 2026 phased / 85% by 2H 2026" target [22]. A press release moving this to 4Q 2026 or 2027 is a material thesis hit.
2. **Q2 2026 earnings (late July 2026):** look for confirmation of (i) leach run-rate ≥300M lb annualized; (ii) cash cost <$1.00/lb on the leach pounds; (iii) any mention of further Grasberg geotechnical surveys. If either (i)/(ii) miss, the "virtual mine" optionality compresses.
3. **Bagdad expansion FID:** management has guided to a potential investment decision *during 2026* on doubling Bagdad concentrator (+200–250M lb/yr) [14]. Sanction = bull confirmation; deferral = capital discipline / signal of price uncertainty.
4. **China CSPT 2026 production cut execution.** If Chinese smelters fail to actually cut output by ≥10%, TC/RCs lift back into positive territory and the concentrate-seller margin tail thins.
5. **Section 232 scope decisions.** Any expansion of the 232 to copper *cathode/concentrate* (currently exempt) [12] would be a significant positive re-rate for U.S.-domiciled production; conversely a USMCA-style carve-out for Chilean/Peruvian inputs is a small negative.
6. **Hyperscaler capex prints (MSFT/META/GOOG/AMZN July 2026 calls).** A sequential cut >10% in aggregate 2H 2026 capex guidance is the single cleanest leading indicator for downstream cable/transformer order pulls (which lead copper demand by 2–4 quarters).
7. **Resolution Copper / Pebble Mine permitting actions.** Any *positive* U.S. permitting news at competing assets erodes part of FCX's domestic-scarcity moat (low probability inside 90 days but worth watching).

## What I could not verify
- **Exact YTD 2026 total return for FCX** — could not source a clean 2025-12-31 close in the search results. Trailing 52-week return is +112.6% [10] but YTD is unstated.
- **EV / NTM revenue with a clean consensus revenue line** — I estimated $25–26B from Q1 run-rate plus Grasberg ramp commentary [7][8]; sell-side consensus revenue was not directly cited in the sources I retrieved.
- **Dividend yield** — one source quotes 1.06% with a $0.08 quarterly base [24]; that arithmetic ($0.32/$60.89 ≈ 0.53%) suggests the source is including the variable performance component, but I could not verify the variable-dividend declaration for 2026 directly.
- **Per-rack copper mass for GB200/NVL72 vs. Hopper** — I asserted (in inference) that NVLink5 backplane copper raises per-rack copper mass; I could not retrieve a clean teardown number in the time available. This is a useful piece of detail that would sharpen the thesis if a SemiAnalysis or ServeTheHome teardown number can be sourced.
- **PTFI 2041 extension royalty/ownership reset terms** referenced as a structural Indonesia risk — I asserted the contour but did not pull the operative paragraph.
- **Granular hyperscaler-disclosed copper PO data** (e.g., Microsoft / Meta cable + transformer purchase orders by quarter) — would meaningfully sharpen the demand-side picture; not retrieved.

## Sources
[1] Copper.org — https://www.copper.org/copperconversations/thought-leadership/us-opper-meet-surging-demand-ai-data-centers.php — retrieved 2026-05-10 — 27 t Cu/MW for Microsoft Chicago facility; per-MW intensity benchmark.
[2] Tom's Hardware (citing Macquarie/Sprott) — https://www.tomshardware.com/tech-industry/why-copper-markets-are-feeling-the-pinch — retrieved 2026-05-10 — 1.1 Mt/yr by 2030; ~3% of global demand from AI; 27–33 t/MW range.
[3] Yahoo Finance / WallStreetZen / StockAnalysis — https://finance.yahoo.com/quote/FCX/ — retrieved 2026-05-10 — FCX $60.89 close 2026-05-06; market cap $87.5B.
[4] Barchart / Morningstar — https://www.barchart.com/stocks/quotes/FCX — retrieved 2026-05-10 — 52-week range $35.15 (2025-09-25) to $70.97 (2026-04-20).
[5] GuruFocus — https://www.gurufocus.com/term/forward-pe-ratio/FCX — retrieved 2026-05-10 — Forward P/E 22.88 (April 2026); industry median 12.47.
[6] StockAnalysis.com — https://stockanalysis.com/stocks/fcx/statistics/ — retrieved 2026-05-10 — EV $105.47B; net debt ~$6.67B; EV/EBITDA 11.74 vs 10-yr median 7.87; TTM EBITDA $8.99B.
[7] Yahoo / Zacks via Yahoo Finance — https://finance.yahoo.com/markets/commodities/articles/fcxs-q1-earnings-revenues-top-171200217.html — retrieved 2026-05-10 — Q1 2026 net income $881M, adj EPS $0.57, revenue $6.23B, copper production 662M lbs (-23.7% YoY).
[8] StockTitan / Mining.com — https://www.stocktitan.net/sec-filings/FCX/10-q-freeport-mcmoran-inc-quarterly-earnings-report-ec0675267366.html — retrieved 2026-05-10 — 2026 guide: 3.1B lbs Cu (revised), 650k oz Au, 90M lbs Mo; 5-yr Grasberg cut 9% Cu / 7% Au; 2H volumes ~30% above 1H.
[9] MarketBeat / StockAnalysis / Public.com — https://www.marketbeat.com/stocks/NYSE/FCX/forecast/ — retrieved 2026-05-10 — Consensus median PT $70.00 (n=30; range $30–$81); mean $68.64 (n=21).
[10] MarketBeat (short interest) and Yahoo (price history) — https://www.marketbeat.com/stocks/NYSE/FCX/short-interest/ — retrieved 2026-05-10 — Short interest 27.12M sh, 1.89%; trailing 52-week return +112.58%.
[11] CruxInvestor / DiscoveryAlert — https://www.cruxinvestor.com/posts/from-surplus-to-scarcity-how-slower-production-growth-is-driving-a-structural-copper-deficit-by-2026 — retrieved 2026-05-10 — Global head grades from 1–2% to <0.7%; capex intensity $15–20k/t; 330–600kt 2026 deficit range.
[12] White & Case / White House Fact Sheet — https://www.whitecase.com/insight-alert/president-trump-orders-50-percent-section-232-tariff-copper-imports — retrieved 2026-05-10 — 50% Section 232 on semi-finished Cu and Cu-intensive derivatives effective 2025-08-01; April 2026 expansion; cathode/concentrate/scrap exempt.
[13] FinancialContent / FCX leach disclosures — https://markets.financialcontent.com/stocks/article/finterra-2026-3-2-the-copper-kingpin-a-deep-dive-into-freeport-mcmorans-future-fcx — retrieved 2026-05-10 — 300M lb/yr leach run-rate at <$1/lb in early 2026; 800M lb/yr 2030 target; Jetti Resources catalyst partnership.
[14] Mining Record / FCX disclosures — https://miningrecord.com/Bagdad-Mining-Complex — retrieved 2026-05-10 — Bagdad expansion 200–250M lb potential; Bagdad fully autonomous haulage 2025; Lone Star expansion 200→300M lb.
[15] DOE National Transmission Planning Study (via CleanEnergyGrid summary) — https://www.cleanenergygrid.org/new-report-reveals-u-s-transmission-buildout-lagging-far-behind-national-needs/ — retrieved 2026-05-10 — ~5,000 mi/yr transmission target vs <1/10 actual build.
[16] IEA "Building the Future Transmission Grid" — https://www.iea.org/reports/building-the-future-transmission-grid/executive-summary — retrieved 2026-05-10 — Cable lead times 2–3 yrs; transformer ~4 yrs; lead times doubled since 2021.
[17] Mining.com / Benchmark Source / Kitco — https://www.mining.com/web/antofagasta-agrees-zero-copper-processing-charges-for-2026-with-chinese-smelter/ — retrieved 2026-05-10 — 2026 annual TC/RC settled at $0/t (record low); CSPT cutting >10% in 2026; ~9.61 Mt 2026 Chinese smelter capacity.
[18] DiscoveryAlert / ICSG references — https://discoveryalert.com.au/copper-supply-deficit-2026-market-dynamics/ — retrieved 2026-05-10 — ICSG 150kt 2026 refined Cu deficit forecast.
[19] BHP / Mining.com / Plusmining — https://www.mining.com/bhp-now-expects-nearly-2m-tonnes-copper-production-after-record-escondida-throughput/ — retrieved 2026-05-10 — BHP FY26 copper 1.9–2.0Mt; Escondida 1.2–1.275 Mt; Escondida tracking to surpass combined Codelco.
[20] DataCenterDynamics / Approved Sheet Metal — https://www.datacenterdynamics.com/en/opinions/busbars-copper-versus-aluminum/ — retrieved 2026-05-10 — Aluminum 60–62% Cu conductivity; 70% lighter; cross-section/space penalty in dense racks; Cu preferred for critical infrastructure.
[21] BHP Insights — https://www.bhp.com/news/bhp-insights/2025/01/why-ai-tools-and-data-centres-are-driving-copper-demand — retrieved 2026-05-10 — Data center Cu demand ~6× growth to 2050 (~3 Mt/yr); ~0.5 Mt/yr today.
[22] Mining.com / Investor.fcx.com / Jakarta Globe — https://www.mining.com/freeport-plans-to-restart-large-scale-production-at-grasberg-in-q2-2026/ — retrieved 2026-05-10 — Sept 8, 2025 mud-rush incident (7 fatalities, ~800kt wet material); Q2 2026 phased restart; ~85% normal rates 2H 2026.
[23] GuruFocus Q1 2026 transcript summary — https://www.gurufocus.com/news/8815349/freeportmcmoran-inc-fcx-q1-2026-earnings-call-highlights-record-copper-prices-and-strategic-growth-plans-amid-operational-challenges — retrieved 2026-05-10 — ~$400M EBITDA sensitivity per $0.10/lb Cu; mgmt color on AI data-center demand offsetting auto/private-construction weakness; Q1 Cu averaged >$5.80/lb, peaked >$6/lb.
[24] Dividend.com / TradingEconomics — https://www.dividend.com/stocks/materials/metals-mining/base-metals/fcx-freeport-mcmoran/ — retrieved 2026-05-10 — Reported yield 1.06% with $0.08 quarterly base as of 2026-05-01 (variable component implied; not independently verified).