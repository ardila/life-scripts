I have sufficient material. Writing the dossier now.

# PCG — PG&E Corporation

## Where this sits in the AI stack
PCG operates the regulated electric and gas utility (Pacific Gas and Electric Company) covering Northern and Central California — including the entire San Francisco Bay Area, San Jose, Silicon Valley, and the Central Valley. In AI-infrastructure terms it owns the lowest layer of the stack: **power generation, the 230 kV/115 kV transmission network, the local distribution grid, ~7,000 miles of high-pressure gas transmission pipeline, and the 2.2 GW Diablo Canyon nuclear plant** [1][8][12]. It does not build chips, racks, or runtimes; it sells the kilowatt-hour and the right-of-way underneath the largest hyperscale AI training and inference clusters being sited in PG&E territory. The relevant workload is **24/7 firm baseload at >50 MW/site at transmission-level voltage (50–230 kV)** — i.e., training campuses and large inference fleets, not edge or retail compute.

## Snapshot
- **Price:** $16.07 (2026-05-08 close) [3]
- **Market cap:** $35.4B [3]
- **52-week range:** $12.97 – $19.16 (high 2026-03-02) [3][13]
- **Forward P/E:** 9.7× (on FY26 core EPS midpoint $1.65) [3][2]
- **EV / NTM revenue:** n/a — utilities are valued on rate-base / P/E and EV/EBITDA; revenue multiples are not the relevant gauge for a fully regulated IOU. P/Rate-base ~0.5× on year-end 2025 rate base of ~$69B [10]
- **Consensus 12-month price target:** $22.19–$23.00 (median, 22 analysts; implied +38–43%) [4]
- **YTD total return:** +8.8% [13]
- **Short interest (% of float):** n/a — could not verify a current figure from a primary source (Fintel returned 403)
- **Dividend yield:** 1.13% ($0.20 annual; reinstated post-bankruptcy at a low coverage) [11]
- **2026 EPS guidance:** $1.64–$1.66 core, fifth straight year of double-digit growth; zero new equity expected through 2030 [2][10]

## Moat — what it is physically made of
The PCG moat is **not technological**; it is the bundle of (a) an exclusive regulated franchise over 70,000 mi² of California served by ~106,000 miles of distribution and ~18,000+ miles of transmission lines, (b) the only nuclear baseload asset west of the Rockies, (c) a 7,000-mile high-pressure gas transmission network sitting under the densest AI demand pocket in the U.S., and (d) a state-codified liability backstop (AB 1054 + SB 254) [1][6][7][12]. Decomposed:

1. **Physical right-of-way & transmission allocation.** A new entrant cannot legally string a 230 kV line into Santa Clara County. CAISO Cluster 14/15 has ~185 GW + 94 GW of projects already queued, and transmission upgrades cost $45–60B over 20 years statewide per Berkeley [5]. PG&E owns the existing ROW and operates under FERC formula rates with ~100% CWIP-in-rate-base treatment for qualifying transmission, so it earns a regulated return (~9.3% ROE, contested up at FERC) on every dollar spent inside its footprint before the line is energized [10]. This is the single most durable component — replication time is measured in decades and is gated by CEQA/NEPA, not capital.
2. **Diablo Canyon (2.2 GW PWR).** NRC 20-year license renewal was approved in early 2026 with CPUC state permits through 2030; this is the only utility-scale dispatchable carbon-free baseload in CAISO [12][2]. At Constellation-comparable PPA economics ($70–95/MWh) this asset alone is worth ~$8–12B of present value to a hyperscaler counterparty if directly contractable, though current law channels its output through bundled retail rates. Cannot be replicated — California has no path to new nuclear builds inside the planning horizon.
3. **Gas transmission as fast-path.** The 7,000-mile high-capacity gas grid lets a hyperscaler hypothetically site behind-the-meter gas turbines along an existing trunk and energize in **18–24 months**, versus a 5-year CAISO electric queue [8]. PG&E's VP of gas engineering is "in active conversations" but no projects have tapped in yet — this is optionality, not booked revenue, and creates a defensible **dual-fuel pitch** competitors in the territory cannot match.
4. **AB 1054 + SB 254 liability framework.** The $21B (now $39B post-SB 254) state wildfire fund, the $4.1B per-event PG&E liability cap, and 2025–2028 wildfire-mitigation-plan-tied safety certificates form a **legal moat** [6][7]. Without this framework, PG&E is uninvestable; with it, Moody's upgraded the credit in early 2026 [6]. This is durable until the legislature unwinds it, which is politically remote while data center revenue is presented as bill-reducing.
5. **Operational execution on undergrounding.** Cost-per-mile is down from $4.0M to $3.1M, targeting $2.5M by end-2026; 1,200+ miles energized underground; 12M customer outage-minutes avoided in 2025 via continuous monitoring [2][9]. This is not a moat in the strict sense — SCE/SDG&E can do this too — but it is the **operational gating item** that lets the rate base grow without OEIS pulling the safety certificate.

What it is *not*: there is no software moat, no CUDA-equivalent, no IP stack. Anyone with capital and a regulatory franchise can in principle do this work. The moat is **geographic monopoly + the time it takes to replicate transmission ROW + the wildfire backstop only the three California IOUs have**.

## AI buildout bottleneck map
Ranked by criticality over the next 24 months, with PCG positioning:

| Bottleneck | PCG position | Specifics |
|---|---|---|
| Grid interconnect / transmission ROW | **Constraint owner & beneficiary** | CAISO queue ≥185 GW backlog [5]; PG&E controls the ROW around Bay Area / Central Valley load |
| Generation capacity (firm dispatchable) | **Supplier** | Diablo Canyon 2.2 GW baseload secured through 2030 [12] |
| Local distribution buildout >100 kW/rack | **Supplier (rate-based)** | $73B 2026–2030 capex plan; ~$20B FERC-regulated [10] |
| Hyperscaler willingness to fund upfront | **Beneficiary** | Rule 30 (interim, July 2025) requires customer to pre-fund infrastructure; rate-base risk shifted to hyperscaler until project lights up [1][14] |
| Behind-the-meter gas turbine bypass | **Exposed** | If hyperscalers bypass the grid with on-site gas/SMR, PCG monetizes only the pipeline tariff, not the kWh |
| HBM3e / CoWoS-L / optical interconnect / kernel talent | **Indifferent** | Utility — does not touch the silicon stack |
| Wildfire reignition risk | **Constraint owner** | AB 1054 caps liability at $4.1B but a >$4.1B event would re-trigger 2018–2019 dynamics [6] |
| California political tolerance of rate increases | **Constraint owner** | Residential rates already a political flashpoint; SB 254 was passed *specifically* to keep transmission costs off the bill [7] |

## Competitive teardown
**Not Broadcom-vs-NVIDIA.** The relevant comp set has three layers:

1. **Other California IOUs (EIX, SRE).** Edison International (EIX/SCE) has $38–41B capex 2026–2030 and ~7% rate-base growth versus PCG's 9% — but SCE's territory does not include the Bay Area / Silicon Valley data center cluster [4]. SCE's wildfire risk is the residual Eaton/Palisades exposure now under AB 1054. SRE owns SDG&E (small, low data-center load) plus Texas's Oncor (the highest-growth utility footprint in the U.S. for AI). **SRE is the only credible "AI utility" that has greater forward-load growth than PCG**, but it pays for that with Texas's deregulated cost structure — Oncor is a wires-only T&D company, not a generation owner, so it does not capture the firm-power scarcity rent. Parity-on-axis: SCE matches PCG on wildfire framework and rate-base growth methodology; nobody matches PCG on Bay Area concentration.
2. **Merchant generators (VST, CEG).** Constellation (CEG) and Vistra (VST) trade at "tech stock" multiples (CEG ~25–30× forward P/E vs PCG at 9.7×) because they sign **bilateral 20-year PPAs at $70–95/MWh** directly with Microsoft, Meta, AWS [15][16]. They have already executed 1.2–2.6 GW deals each. PCG cannot directly compete here because its generation is rate-based, not merchant — its upside is *volumetric* (kWh through the system) and *rate-base* (capex on transmission). The merchant model captures the *scarcity premium* on firm power; the regulated model captures the *volume × allowed ROE*. These are different bets on the same physical reality.
3. **Adjacent California municipals (SVP).** Santa Clara's Silicon Valley Power — a *municipal utility, not PG&E* — has ~100 MW of finished data center capacity sitting idle waiting for grid connections (Digital Realty SJC37, Stack SVY02A) and is investing $450M in grid upgrades through 2028 [13]. SVP's saturation actively pushes new builds **into PCG territory** (the Central Valley sites in Tracy, Sacramento, Stockton). This is a clean PCG tailwind.

For someone to take share from PCG, one of three things must be true: (i) the legislature lets a competitor build inside PCG's franchise — not happening on a 5-year horizon; (ii) hyperscalers go fully behind-the-meter with gas/SMR and skip the grid — currently being blocked by California's gas connection rules but the most credible threat; (iii) California's data center build moves out of state entirely to Texas/Virginia — this is happening at the margin but PCG's pipeline still *grew* from 5.5 → 10 GW in 2025 [1].

## Bull case — technical
The technical conditions that have to hold:
1. **Frontier training/inference demand keeps requiring hyperscale (>50 MW) firm power siting near talent.** Base rate: every prior compute platform shift (mainframe → minicomputer, client-server → cloud) ran 15–20 years before saturating. AI capex cycles are ~3 years in; hyperscaler 2026 capex guides have held through Q1 reports.
2. **The Bay Area remains the AI talent / research cluster.** As long as Anthropic (SF), OpenAI (SF), Google (Mountain View), Meta (Menlo Park), and the GPU-heavy startup density stays put, the **latency and operational** preference for in-territory compute persists. Frontier training does not require sub-ms latency to the office, but **iteration cycles and on-site debugging at multi-billion-parameter scale** still favor proximity.
3. **PCG converts its 4.6 GW final-engineering pipeline to actual energized load.** That 4.6 GW at ~6 MWh/kW/year × ~$120/MWh blended rate is roughly $3.3B incremental annual revenue at full saturation, with ~30–40% flowing to rate-base earnings under the regulated formula [2]. The 9% rate-base CAGR thesis ($69B → $106B by 2030) maps directly to a 9–11% EPS CAGR with zero new equity [10].
4. **AB 1054 / SB 254 framework holds.** A single >$4.1B wildfire event re-triggers existential risk. Underground mileage at $2.5M/mile and the Wildfire Mitigation Plan's continuous monitoring (12M outage-minutes avoided in 2025) reduce ignition probability — but not to zero [2][9].
5. **No competitor takes share on a 5-year horizon** because the regulated franchise is durable.

If all five hold, PCG re-rates from 9.7× to ~14–16× forward (utility median, with growth premium), implying $23–28/share — consistent with the $22.19 consensus and Street high of $27 [4]. Base rate on regulated utility re-rating after credit upgrade + growth narrative: typically 2–3 years to play out, not 12 months.

## Bear case — technical
A short who understands the stack writes this:
1. **Behind-the-meter gas/SMR disintermediates the franchise.** If FERC and CPUC let hyperscalers site Bloom Energy / fuel cell / gas-turbine / SMR generation on-site under a "primary power" interpretation (not just backup), PCG monetizes only a gas tariff and a thin standby charge, **not** the kWh and not the rate-based transmission upgrade. Microsoft, AWS, and Meta are all actively signing on-site or directly-contracted firm power deals [15][16]. The 18–24 month gas pipeline pitch [8] is a *concession* that the electric grid cannot serve the demand in time — it implies PCG's electric franchise is *already* losing the speed competition.
2. **California rate-payer politics breaks the deal.** Residential rates are the highest in the continental U.S. SB 254 was passed *specifically* because the cost shift from data center capex to residential bills was politically untenable [7]. If a Democratic legislature, in 2027 or 2028, caps rate-base growth or shifts more transmission to public financing (via the new I-Bank revolving fund), the allowed-return mechanism that drives PCG's EPS algorithm compresses. The technical fix (SB 254 public-financing of transmission) is itself the bear case — every dollar financed by the state is a dollar that doesn't enter PCG's rate base.
3. **One catastrophic wildfire.** The 2018 Camp Fire was ~$13.5B in liabilities. PG&E was in bankruptcy 4 months later. AB 1054's $4.1B cap helps but is not absolute — exhaustion of the wildfire fund (now $39B) is mathematically possible across multiple events. Climate base rate: California wildfire severity has trended up ~2× per decade since 2000.
4. **Data center demand attrition.** The pipeline already shrank from 10 GW (July 2025) → 9.5 GW (Nov 2025) [8]. The 4.6 GW "final engineering" figure is **not** signed take-or-pay contracts — Rule 30 puts the financial risk on the hyperscaler upfront [14], but it also means the hyperscaler can walk before the lines are built. A 30–40% pipeline cancellation rate is plausible if frontier scaling laws disappoint or inference-efficiency improvements (FP4, MoE, distillation) reduce GW-per-unit-intelligence faster than demand grows.
5. **Diablo Canyon early closure.** The 2030 California permits are not 2045 permits — the federal license is 20 years but state policy controls operation. A Democratic governor or shift in CPUC composition could pull it offline earlier than the NRC license allows.

## Market view check
At $16.07 and 9.7× forward, PCG trades at roughly a **50% discount** to the U.S. regulated electric utility median of ~18–20× forward P/E. The market is apparently still pricing residual wildfire-bankruptcy tail risk and California rate-payer political risk *more heavily* than the data-center-driven rate-base growth — which is the inverse of what merchant-power AI stocks (CEG, VST at 25–30×) are doing. Either the market is right that the regulated model cannot capture the scarcity rent on firm power (consistent with the bear behind-the-meter thesis), or it is mis-weighting the durability of the AB 1054 framework and the 9% rate-base CAGR. **The mispricing is technical, not just sentimental**: it hinges on whether you think regulated kWh-flow-through earns the data-center premium or whether merchant-PPA contract structures capture all of it. My read: PCG should trade ~12–14× — not 20× — but 9.7× is too punitive. The consensus +38% PT [4] is roughly correct in direction; my own model would put fair value at $20–22.

## 90-day falsifiers
- **Q2 2026 earnings (July) data-center pipeline update**: if "final engineering" figure stalls below 5.0 GW or contracts, thesis weakens. If >5.5 GW, accelerates.
- **CPUC Rule 30 final order on cost causation** — expected mid-2026. If the order forces PG&E to bear more transmission cost on the bundled customer (rather than upfront hyperscaler funding), the rate-shock political risk compounds [14].
- **Any wildfire ignition >50,000 acres in PCG territory during the June–September fire season**. A single major ignition pre-October would re-test the AB 1054 cap [6].
- **First named hyperscaler PPA or interconnection agreement disclosure**. Microsoft, AWS, Meta, Google, or Oracle (Stargate) explicitly naming PG&E in a 10-K or press release would be a step-change in narrative.
- **Behind-the-meter gas turbine project announcement in PG&E territory**. If a hyperscaler announces a >100 MW on-site gas plant bypassing PG&E generation, it validates bear case #1 [8].
- **SB-254-style state-financed transmission project competing inside PG&E ROW.** First I-Bank disbursement on a transmission line that PG&E *does not own and operate*.
- **FERC ROE ruling on transmission incentives** (TO21 docket ER26-631, CPUC protested January 2026 [10]). A ROE cut below 9.0% would compress every dollar of the $20B FERC-regulated capex.

## What I could not verify
- Current short interest as % of float (Fintel 403'd, no current SEC/exchange data surfaced from a primary source).
- Whether *any* specific hyperscaler (MSFT, AWS, META, GOOGL, ORCL) has named PG&E in a publicly disclosed PPA or interconnection agreement. Press references talk in aggregate ("hyperscalers", "data center customers") but I could not locate a named-counterparty disclosure.
- Exact MW breakdown of the 4.6 GW final-engineering pipeline by county / hyperscaler / online date.
- Diablo Canyon's actual contribution to PCG earnings under current rate structure (it is rate-based; the merchant value is theoretical).
- The base rate of regulated utility multiple expansion specifically driven by load-growth narratives; I have an impression (typically 2–3 years) but no clean dataset.
- Whether SB 254's I-Bank financing facility is in practice *additive* to PCG capex (PG&E builds, gets reimbursed) or *subtractive* (state competes with PCG). Legal text is ambiguous; the practical answer is 18+ months out.

## Sources
[1] https://investor.pgecorp.com/news-events/press-releases/press-release-details/2025/PGE-Data-Center-Demand-Pipeline-Swells-to-10-Gigawatts-with-Potential-to-Unlock-Billions-in-Benefits-for-California/default.aspx — retrieved 2026-05-10 — 10 GW data center pipeline July 2025, regional breakdown.
[2] https://www.fool.com/earnings/call-transcripts/2026/04/23/pge-pcg-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q1 2026 transcript: 4.6 GW final engineering, $1.64–$1.66 EPS guide, $73B capex unchanged, $5B incremental opportunity, 1,200 miles undergrounded, $0.43 Q1 EPS.
[3] https://stockanalysis.com/stocks/pcg/ — retrieved 2026-05-10 — Price $16.07, market cap $35.4B, 52-week range, forward P/E 9.68, dividend $0.20.
[4] https://public.com/stocks/pcg/forecast-price-target — retrieved 2026-05-10 — 22 analysts, median PT $23, range $19–$27.
[5] https://www.zeroemissiongrid.com/iso-rto-meeting-summaries/caisos-interconnection-queue/ — retrieved 2026-05-10 — CAISO queue scale 185 GW+94 GW+347 GW; $45–60B transmission needed.
[6] https://www.utilitydive.com/news/moodys-upgrades-pge-pacific-gas-credit-wildfire/743811/ — retrieved 2026-05-10 — Moody's early-2026 upgrade; AB 1054 $21B fund; PG&E $4.1B liability cap.
[7] https://www.gtlaw.com/en/insights/2025/10/california-enacts-new-electric-transmission-financing-programs-and-adds-to-its-wildfire-fund — retrieved 2026-05-10 — SB 254 adds $18B to wildfire fund, creates I-Bank transmission financing facility.
[8] https://www.latitudemedia.com/news/how-pge-is-leveraging-its-gas-grid-for-ai-load/ — retrieved 2026-05-10 — 7,000 mile gas grid, 18–24 month hyperscaler pipeline option, VP Austin Hastings comments; pipeline 10→9.5 GW Nov 2025.
[9] https://investor.pgecorp.com/news-events/press-releases/press-release-details/2025/Thousands-of-PGE-Customers-Now-Protected-from-Wildfires-as-1000-Miles-of-Powerlines-are-Energized-and-Underground/default.aspx — retrieved 2026-05-10 — Undergrounding milestone, cost-per-mile trajectory $4M → $3.1M → $2.5M target.
[10] https://www.energycentral.com/energy-biz/post/news-new-pg-e-spending-plan-outlines-73b-of-capex-through-2030-1hFRSNSxzQmjUMh — retrieved 2026-05-10 — $73B capex 2026–2030, rate base $69B → $106B (9% CAGR), $20B FERC-regulated.
[11] https://stockanalysis.com/stocks/pcg/dividend/ — retrieved 2026-05-10 — Dividend yield 1.13%, $0.05 quarterly, $0.20 annual.
[12] https://investor.pgecorp.com/news-events/press-releases/press-release-details/2026/U-S--Nuclear-Regulatory-Commission-Approves-License-Renewal-Application-for-Extended-Operations-of-Diablo-Canyon/default.aspx — retrieved 2026-05-10 — NRC 20-year renewal of Diablo Canyon early 2026.
[13] https://www.tomshardware.com/tech-industry/data-centers-in-nvidias-hometown-sit-idle-as-grid-struggles-to-keep-up — retrieved 2026-05-10 — Santa Clara SVP idle data centers (Digital Realty SJC37, Stack SVY02A), 100 MW capacity unenergized, $450M SVP capex through 2028.
[14] https://www.cpuc.ca.gov/news-and-updates/all-news/cpuc-streamlines-electric-grid-connections-for-high-energy-users-like-data-centers-and-ev-chargers — retrieved 2026-05-10 — CPUC Rule 30 interim approval July 2025; hyperscalers pre-fund infrastructure.
[15] https://enkiai.com/nuclear/microsoft-constellation-ai-data-centers/ — retrieved 2026-05-10 — Microsoft–Constellation 20-yr 837 MW PPA, Crane restart; nuclear PPA LCOE $70–95/MWh.
[16] https://enkiai.com/nuclear/meta-terrapower-oklo-data-centers/ — retrieved 2026-05-10 — Vistra–Meta 2,600+ MW, Vistra–AWS 1,200 MW Comanche Peak 20-yr PPAs; Vistra 2026 EBITDA guide $6.8–7.6B.