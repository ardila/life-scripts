# ABNB — Airbnb, Inc.

## Where this sits in the AI stack
ABNB sits at the **application/marketplace layer** — it is not a beneficiary of the AI buildout in the way an NVIDIA, AVGO, or VRT is, and it sells no silicon, packaging, memory, fabric, or compute capacity. Its technical substrate is a two-sided liquidity network (~8M active listings, ~5M hosts across ~150,000 cities) sitting on top of a search/ranking ML stack (two-tower embedding retrieval, gradient-boosted re-rank), a feature platform (Chronon, sub-10ms serving), a real-time fraud/trust ML pipeline, and an integrated cross-border payments system [1][7][8][12]. AI is a **cost-side accelerant** (customer-support automation, listing quality, search relevance) and a **front-end disintermediation risk** (ChatGPT/Perplexity agents), not a revenue-generative AI-infrastructure exposure. Treating ABNB as an "AI stock" is a category error; treating it as an AI-exposed consumer-internet platform is the correct frame.

## Snapshot
- **Price:** $141.49 (2026-05-08 close) [1]
- **Market cap:** ~$82.5B [2]
- **52-week range:** $110.81 – $147.25 [2]
- **Forward P/E:** ~27× (on FY26 consensus EPS ~$5.05) [3]
- **EV / NTM revenue:** ~5.6× (mkt cap $82.5B less ~$10B net cash ≈ EV $72-73B; NTM consensus revenue ~$13B implied by raised low-to-mid-teens guide off FY25 ~$11.4B) [4][5] — inference from public numbers; not a directly cited consensus figure.
- **Consensus 12-month price target:** ~$149-150 (avg of 28-36 analysts; range includes Oppenheimer $180 outlier); implied ~+6% from price [3][6]
- **YTD total return:** ~-3% [10]
- **Short interest:** 2.43% of float (~14.4M shares) [2]

## Moat — what it is physically made of
The moat is **not** technological; it is **liquidity, brand recall, and accumulated trust infrastructure**, with ML as a defender rather than a creator of the moat. Decomposed:

**1. Two-sided liquidity / supply uniqueness (durable, 8-9/10).** ~8M active listings across 150,000+ cities, of which a meaningful fraction are unique single-family homes and apartments unavailable on hotel-OTA inventory [12]. Booking's alt-accommodation business is at ~430M non-hotel nights (~80-85% of Airbnb's volume) but is dominated by professionally managed apartments and small B&Bs, not the long-tail "live like a local" inventory that defines the Airbnb brand [13]. Replicating this supply is a multi-year, multi-billion-dollar acquisition problem; Vrbo (Expedia) has been trying for 15 years and remains a distant third in unique-stay inventory.

**2. Brand as default verb (durable, 8/10).** "Airbnb" has verb status for non-hotel lodging in English-speaking markets — a marketing moat that materially lowers paid-customer-acquisition cost vs. Booking, which spends >$7B/year on performance marketing [13]. Direct/unpaid traffic mix is the single most important durable economic asset Airbnb owns; it is what allows the take-rate compression in #5 to fund margin expansion rather than starve growth.

**3. ML/search stack (moderately durable, 5/10).** Bighead end-to-end ML platform [7]; Chronon feature platform (Kafka/Spark/Hive/Airflow, sub-10ms serving, open-sourced 2024) [8]; embedding-based retrieval via two-tower contrastive networks with IVF (not HNSW) approximate-nearest-neighbor serving for Homes Search [11]; BiListing bimodal embeddings fusing listing text and photos via LLMs/VLMs (+0.425% NDCB) [9]; map-specific NDCG ranking (since maps account for ~80% of search interactions) [9]. This is **competent industrial-scale ML, not a frontier capability** — Booking, Expedia, and Meituan all run comparable stacks. It defends the listing-recommendation experience; it does not create lock-in. The CUDA-equivalent here doesn't exist.

**4. Trust/payments infrastructure (durable, 7/10).** Real-time risk pipeline runs on every reservation: Java service with parallelized feature generation, asynchronous so it never blocks bookings; hundreds of signals per listing (template messaging detection, duplicate-photo perceptual hashing, host-reputation features) [14][15]. Airbnb absorbs chargebacks rather than passing them to hosts [14] — a capital-and-operations moat that a startup cannot replicate without scale. Cross-border payments are settled in 40+ currencies; this is genuinely hard plumbing competitors underestimate.

**5. Take-rate optionality from fee-structure transition (recent, 6/10).** October 2025 migration of PMS-connected hosts from split-fee (~3% host + 14-16% guest) to a unified 15.5% Host-Only Fee [16]. Cleaner price display, eliminates "fee shock" at checkout (the #1 conversion-killer cited by guests), and gives Airbnb a single take-rate lever instead of a dual one. Q1 2026 results showed cost-per-booking down ~10% YoY [4]; management raised full-year take-rate outlook on the call [13]. This is monetization runway, not a structural moat.

**6. Regulatory navigation capacity (paradoxical moat, 6/10).** NYC (Local Law 18) and Barcelona (10,000 licenses phased out by Nov 2028 under Catalonia Law 11/2025) demonstrate that regulators *can* eliminate STR inventory at will [17][18]. Listings in NYC fell ~70-92% post-enforcement [17]. The paradox: every market where regulation kills the long-tail amateur host *raises* the value of Airbnb's compliance, registration, and government-relations apparatus — because the survivors are professional operators that need Airbnb's distribution and the new hosts cannot enter without navigating bureaucracy that Airbnb already automates. This is the same regulatory-capability moat that has favored Uber over rideshare upstarts.

**What's NOT a moat.** CUDA-equivalents don't exist here. There is no kernel library, no fabric primitive, no manufacturing-allocation contract, no patent thicket. ABNB does not have proprietary silicon, no exclusive HBM supply, no CoWoS allocation. The "switching cost" for a host to also list on Vrbo or Booking is ~30 minutes of work; many hosts already multi-list. The "switching cost" for a guest is one app download. The moat is the **expectation that the other side is there.**

## AI buildout bottleneck map
ABNB has near-zero direct exposure to the AI buildout bottlenecks the user's framework calls out:

- **Power generation / grid interconnect:** Indifferent. ABNB consumes ~tens of MW of cloud compute (AWS-heavy), not hyperscaler-scale. Inference for its AI customer-support agents runs against third-party LLM APIs.
- **CoWoS-L / HBM3e:** Indifferent.
- **Optical interconnect / liquid cooling >100kW/rack:** Indifferent.
- **Kernel/compiler talent:** Indifferent. Their ML talent is recommender-systems and search-ranking — adjacent to but not competitive with the GPU-kernel labor market.
- **Frontier training data:** **Exposed customer (negative).** Airbnb is *training data* for somebody else's travel agent — guests asking ChatGPT "where should I stay in Lisbon" is the precursor to OpenAI/Anthropic/Google capturing the discovery layer. The mitigation is the new CTO Ahmad Al-Dahle (former Meta Llama lead, 16 years at Apple) hired Jan 2026 to build a specialized travel agent natively inside Airbnb rather than ceding the discovery layer [19][20].
- **Inference cost curves:** **Beneficiary.** Q1 2026: ~40% of customer-support contacts resolved without a human, up from ~33% in Q4 2025, contributing to ~10% YoY cost-per-booking reduction [13][20]. As frontier inference costs decline ~4-10× per year (Anthropic and OpenAI public price reductions), ABNB's CX cost line keeps deflating. This is a quiet, structural margin tailwind.

**Net:** ABNB is not on the AI infra map at all on the supply side. On the demand side, it is a marginal beneficiary of cheap inference and a marginal target of agentic disintermediation. Anyone pitching ABNB as an "AI play" is selling you a story.

## Competitive teardown

**Booking Holdings (BKNG) — the actual competitor.** Booking has been pivoting alternative-accommodation supply aggressively and is now at ~430M non-hotel nights, roughly 80-85% of Airbnb's nights volume [13]. **On take rate:** BKNG's effective rate on alt-accom is 15-18% gross commission with paid-placement upside; ABNB has just moved to 15.5% host-only and is signaling rate expansion [13][16]. **On loyalty/repeat:** BKNG's Genius program is meaningfully more developed than Airbnb's nascent rewards. **On unique long-tail homes:** ABNB still dominates; BKNG's alt-accom mix skews to professional apartments. **On marketing efficiency:** ABNB wins decisively — BKNG runs a paid-channel-dependent model. **What would have to be true for BKNG to take share:** Continued progress integrating alt-accom into the BKNG.com hotel funnel where cross-sell economics dominate ABNB's standalone-app model. **Already at parity on:** scale of bookable alt-accom inventory in Europe; payments depth in EMEA. Most underrated competitive risk.

**Vrbo (EXPE).** Mostly relevant only in North American whole-home rentals. Continues to lose share. Not a current threat; could become one if EXPE's One Key wallet program meaningfully connects to a generative-search front-end.

**ChatGPT / Perplexity / Gemini as agentic OTAs — the big technical threat.** Both Perplexity (Selfbook partnership, ~140k hotel inventory) and ChatGPT Agent / Operator now book hotels and flights directly [21][22]. **Crucial nuance from current evidence:** OpenAI's ChatGPT Apps integration partners are Expedia, Booking, and Tripadvisor — the existing OTAs — not direct hotel/host pipes [22]. They're aggregating the aggregators, not bypassing them. If that pattern holds, ABNB needs to be present as an app inside ChatGPT/Gemini and accept reduced direct-relationship economics. If the pattern breaks and agents start crawling and booking individual hosts directly, ABNB's brand-as-verb advantage decays. **What would have to be true to displace ABNB:** Sustained agent volume share (≥10-15% of travel discovery) AND a successful "host-direct" booking protocol — neither has been demonstrated. **Base rate:** discovery-layer platform shifts (Google→ChatGPT etc.) historically have taken 5-10 years to flip share, not 1-2.

**Google (Search / Travel / Maps).** Long-standing channel competitor and infrastructure dependency. Less acute since direct/unpaid traffic dominates ABNB's funnel. If Google's AI Overviews suppress click-through to Airbnb's organic results, that's an ongoing 50-200 bps drag, not an existential one.

**Hotels (HLT, MAR, IHG direct).** Compete for the same demand pool. Re-rating thesis (Oppenheimer's $180 PT, May 2026): hotel ADR strength, World-Cup-2026 catalyst, share rotation back to alt-accom as hotel pricing peaks [6]. Real but cyclical.

## Bull case — technical
For ABNB to outperform, these technical conditions must hold:

1. **Specialized travel agent thesis wins.** Chesky's bet is that a single general-purpose AI agent loses to verticalized agents because travel is a complex, multi-step, trust-dependent transaction with regulatory/payments nuance [20]. If correct, Airbnb's native AI agent (built under Al-Dahle) becomes the natural travel front-end for its 100M+ active users, and ChatGPT-style agents settle into being **referral channels into Airbnb's app** rather than booking destinations. The Q1 2026 result of ~40% CX contact resolution by AI is early proof that the in-app agent works [13].
2. **Cost-per-booking deflation continues.** Q1 2026's ~10% YoY reduction [4] compounds. Frontier LLM inference price/token continues falling ~50-75% annually (Anthropic/OpenAI public price cards). At constant agent-coverage, that flows straight to EBITDA. Plausibly worth 200-400 bps of margin over 24 months.
3. **Take-rate expansion lands without supply revolt.** The 15.5% host-only fee transition completes through 2026 without meaningful host churn. Take rate creeps from ~12-13% blended toward 14-15%. This is roughly worth $1-1.5B annualized revenue at current GBV — pure margin.
4. **Services and Experiences become material.** $250M investment thesis [23]: even at low single-digit attach rate to ~500M nights/year, Services adds $1-2B revenue at structurally higher take rates than core.
5. **Regulatory environment stabilizes.** No additional Tier-1 city follows NYC/Barcelona. Already in the stock.

Base rate on consumer-internet platform displacement at scale: historically slow (Amazon vs. Walmart, Booking vs. Expedia took >10 years even with clear structural advantages). Two-sided liquidity moats erode over years, not quarters. **Financial outcome:** if items 1-3 hold, FY27 EBITDA in the $5-6B range vs. consensus ~$4.5B, multiple expansion to ~30× forward P/E gets you to $175-200.

## Bear case — technical
Symmetric, written by the short-seller who understands the stack:

1. **Agentic disintermediation is the iPhone moment for travel discovery, and ABNB is the BlackBerry.** Two technical observations matter. First, the actual booking action — payment, KYC, dispute resolution — is much easier for an AI agent to execute against a structured OTA API than against a hotel/host PMS. So the agent layer naturally **eats the discovery and recommendation function**, not the transaction function. That function is precisely Airbnb's brand/UX advantage. Second, LLM agents have no preference for "Airbnb" as a brand the way humans do — agents optimize on stated criteria (price, ratings, location, amenities). Brand-as-verb has zero value to an agent. The compounding risk: as Gen-Z migrates discovery to ChatGPT/Gemini, ABNB's direct-traffic advantage becomes paid-traffic dependence — which is BKNG's current cost structure, at scale.
2. **Booking is closing the inventory gap faster than ABNB is closing the loyalty/repeat gap.** BKNG alt-accom at ~80-85% of ABNB's nights and growing; Airbnb loyalty program still nascent [13]. In Europe, where BKNG.com is the default OTA, ABNB's brand premium is already much weaker than in North America.
3. **Regulatory contagion.** NYC went from largest US Airbnb market to nearly zero in 24 months [17]. Barcelona is phasing the entire STR market to zero by Nov 2028 [18]. If even 5-10 additional Tier-1 cities (Paris, Amsterdam, Berlin, Lisbon, Madrid, San Francisco) follow, that's 10-20% of urban GBV at risk. ABNB's mitigation is to shift to non-urban / longer-stay / professional inventory, which is **exactly the inventory profile where BKNG is structurally stronger.**
4. **ML stack is not differentiated.** Two-tower retrieval, BiListing embeddings, gradient-boosted re-rank, IVF-based ANN — all standard industrial ML in 2026. The 0.425% NDCB lift from BiListing [9] is honest, useful, *and tiny.* Anyone with a Chronon-equivalent (and most large marketplaces have one) operates at parity. The new CTO can ship faster but cannot architect a defensible moat in a recommender stack that hundreds of companies operate at similar quality.
5. **Forward multiple already prices the bull case.** 27× FY26 EPS for a low-to-mid-teens grower at peak margins is not cheap. Consensus PT range $144-150 (~+6%) implies the sell-side already sees fair value.

**Financial outcome:** If items 1-3 progress over 24-36 months, deceleration to high-single-digit revenue growth, multiple compression to ~20× forward, ~$100-110 stock.

## Market view check
At $141.49, $82.5B mkt cap, ~27× forward P/E, ~5.6× EV/NTM revenue, the market is pricing ABNB as a **high-quality, structurally advantaged consumer-internet platform** with mid-teens revenue growth and 35%+ EBITDA margin — which is exactly what management is guiding [4][5]. Consensus PT (~$150) implies the market thinks the bull case is broadly correct and partially in the price. The asymmetric mispricing case is **not** valuation: it's whether the **agentic-disintermediation discount** the market is applying (note YTD -3% vs. S&P meaningfully positive in 2026) [10] is too large or too small. If you believe Chesky's verticalized-agent thesis (specialized travel agents inside Airbnb's app beat general-purpose agents on travel), the stock is mildly cheap. If you believe LLM-native agents flatten brand-as-verb advantages over 3-5 years, the stock is expensive. The technical thesis — not the multiple — is doing all the work here.

## 90-day falsifiers
- **Q2 2026 results (early August 2026):** Did cost-per-booking continue declining ≥8% YoY? Did AI CX resolution rate cross 50%? Either would validate the cost-side AI thesis. A reversion to <5% cost decline or flat AI-CX share would be a meaningful negative.
- **Take-rate disclosure for completed PMS-host migration:** management committed to update [16]; observed effective take rate ≥13.5% (vs. low-13s previously) confirms the monetization step-up, anything <13% suggests host pushback / discount offsets.
- **ChatGPT App / Operator partnership announcement:** if Airbnb appears as a first-party ChatGPT App (parallel to Expedia/Booking [22]), it tells you ABNB has chosen the "be present in the agent layer" strategy. Absence past Q3 would suggest negotiating leverage problems.
- **Any new Tier-1 city STR restriction:** Paris and Amsterdam have ongoing legislative pressure; either tightening to NYC-level enforcement would be a material negative on European GBV.
- **Booking Q2 alt-accom growth rate:** if BKNG alt-accom nights grow >25% YoY (vs. ABNB's mid-teens), the share-loss thesis accelerates.
- **Q3 release / fall product event:** Chesky has telegraphed an AI-native search relaunch under Al-Dahle. The credibility of the agent demo (latency, accuracy, end-to-end booking flow) is the single most important qualitative observable.

## What I could not verify
- Engineering headcount at Airbnb (financial reports give R&D dollars but no breakout); could not confirm whether the ML/AI org has been materially expanded under Al-Dahle.
- The exact inference vendor split (OpenAI vs. Anthropic vs. self-hosted open-weights) powering the CX agent and the in-app concierge. Public statements suggest a multi-model approach but specifics are not disclosed.
- Whether the ~40% AI CX resolution number is end-to-end resolution or first-touch deflection (could not source the precise definition); these are very different operating metrics.
- The blended take-rate post Oct 2025 PMS transition — management commentary referenced directional improvement but precise figures are still rolling in.
- Booking Holdings' precise alt-accom take rate vs. ABNB on like-for-like inventory; the 15-18% range is industry estimate, not a BKNG disclosure.
- Whether NYC-style enforcement is realistically replicable in Paris, Amsterdam, or Lisbon at scale, or whether their housing pressures lead to softer registration regimes.
- The specific inventory ANN-index size and serving latency in production at Airbnb — public papers describe the architecture but not current deployment numbers.

## Sources
[1] https://meyka.com/blog/abnb-airbnb-earnings-preview-may-7-2026-0605/ — retrieved 2026-05-10 — established May 8, 2026 close at $141.49.
[2] https://stockanalysis.com/stocks/abnb/statistics/ — retrieved 2026-05-10 — market cap ~$82.5B, 52-week range $110.81–$147.25, short interest 2.43%.
[3] https://stockanalysis.com/stocks/abnb/forecast/ — retrieved 2026-05-10 — consensus PT ~$144-150, forward P/E ~27×, FY26 EPS ~$5.05.
[4] https://news.airbnb.com/airbnb-q1-2026-financial-results/ — retrieved 2026-05-10 — Q1 2026 revenue $2.7B (+18% YoY), GBV $29.2B (+19%), adj. EBITDA $519M (+24%), cost-per-booking down ~10%.
[5] https://seekingalpha.com/news/4589396-airbnb-targets-at-least-35-percent-adjusted-ebitda-margin-as-it-raises-2026-revenue-growth-to — retrieved 2026-05-10 — FY26 guide raised to low-to-mid-teens revenue growth; ≥35% adj. EBITDA margin; Q2 guide $3.54-3.6B (+14-16%).
[6] https://247wallst.com/investing/2026/05/04/oppenheimer-upgrades-airbnb-to-outperform-with-180-price-target-are-hotels-and-the-world-cup-about-to-re-rate-the-stock/ — retrieved 2026-05-10 — Oppenheimer $180 PT, hotel re-rate and World Cup catalysts.
[7] https://aicouncil.com/talks/bighead-airbnbs-end-to-end-machine-learning-platform — retrieved 2026-05-10 — Bighead ML platform architecture and vision.
[8] https://chronon.ai/ + https://github.com/airbnb/chronon — retrieved 2026-05-10 — Chronon feature platform, sub-10ms serving, Kafka/Spark/Hive/Airflow, declarative features for online/offline consistency.
[9] https://airbnb.tech/infrastructure/academic-publications-airbnb-tech-2025-year-in-review/ — retrieved 2026-05-10 — 2025 papers: BiListing bimodal embeddings (+0.425% NDCB), Maps Ranking Optimization (~80% of search interactions touch maps), Beyond Pairwise Learning-To-Rank, Agent-in-the-Loop LLM CX framework.
[10] https://www.gurufocus.com/news/8844153/airbnb-abnb-reports-strong-q1-2026-earnings-with-18-revenue-growth — retrieved 2026-05-10 — YTD ABNB down ~3%; Q1 macro/geopolitical cancellation pressure in EMEA/APAC.
[11] https://medium.com/airbnb-engineering/embedding-based-retrieval-for-airbnb-search-aabebfc85839 — retrieved 2026-05-10 — two-tower contrastive network, IVF chosen over HNSW for ANN serving.
[12] https://sqmagazine.co.uk/airbnb-statistics/ — retrieved 2026-05-10 — ~8M active listings, 5M+ hosts, 150,000+ cities, 220 countries.
[13] https://www.rentalscaleup.com/booking-holdings-vs-airbnb-2026-analysis/ — retrieved 2026-05-10 — BKNG alt-accom ~430M non-hotel nights (~80-85% of ABNB), BKNG commission 15-18%, take-rate dynamics.
[14] https://medium.com/airbnb-engineering/fighting-financial-fraud-with-targeted-friction-82d950d8900e — retrieved 2026-05-10 — Java-based async fraud service, hundreds of risk signals, ABNB absorbs chargebacks.
[15] https://news.airbnb.com/what-were-doing-to-prevent-fake-listing-scams/ — retrieved 2026-05-10 — fake-listing detection: template messaging, duplicate-photo perceptual hashing, host-reputation features.
[16] https://hello.pricelabs.co/blog/airbnb-host-fee-update/ — retrieved 2026-05-10 — Oct 27, 2025 transition of PMS-connected hosts to 15.5% Host-Only Fee.
[17] https://www.steadily.com/blog/airbnb-short-term-rental-laws-regulations-new-york — retrieved 2026-05-10 — NYC Local Law 18: ~70-92% listing reduction post-enforcement; pending Int 0948/1107-2024 in committee.
[18] https://getproofsnap.com/posts/barcelona-airbnb-short-term-rental-ban-2026.html — retrieved 2026-05-10 — ~10,000 Barcelona STR licenses to be phased out by Nov 2028; Spain Constitutional Court March 2025 ruling; Catalonia Law 11/2025 effective Jan 1, 2026.
[19] https://www.cnbc.com/2026/01/14/airbnb-tech-chief-meta-ai.html — retrieved 2026-05-10 — Ahmad Al-Dahle (ex-Meta GenAI/Llama, 16 yrs Apple) hired as CTO Jan 2026.
[20] https://www.rentalscaleup.com/airbnbs-ai-strategy-2026/ — retrieved 2026-05-10 — Q4 2025 strategy shift, ~1/3 CX automation in Q4, "specialized agents" thesis from Chesky.
[21] https://skift.com/2025/03/27/perplexity-now-handles-hotel-bookings-what-our-tests-show/ — retrieved 2026-05-10 — Perplexity/Selfbook ~140k hotel inventory direct booking.
[22] https://www.phocuswire.com/openai-chatgpt-apps-expedia-booking-tripadvisor — retrieved 2026-05-10 — ChatGPT Apps integration partners Expedia/Booking/Tripadvisor — agentic OTAs route through existing aggregators.
[23] https://news.airbnb.com/airbnb-2025-summer-release/ — retrieved 2026-05-10 — Services (10 categories, 260 cities) + Experiences relaunch (650 cities); $250M new-lines-of-business investment in 2025.