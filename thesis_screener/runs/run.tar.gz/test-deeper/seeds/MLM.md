# MLM — Martin Marietta Materials, Inc.

## Where this sits in the AI stack
MLM operates at the layer beneath the layer everyone writes notes about. It does not sell silicon, packaging, optics, runtime, or even electrical equipment. It sells **crushed stone, sand, gravel, asphalt and (residually) concrete** out of ~500 sites in 30 US states [1][9]. In an AI infrastructure context, MLM's product is the literal slab beneath the data hall, the foundation under each gas turbine pad at the new behind-the-meter combined-cycle plants, the base course under every new transmission-line access road, and the substrate of the highway rebuilds that the IIJA still funds. It is a **physical pre-requisite to power-delivered MW**, not part of the compute stack. The relevant workload framing is "site-pad-to-energized-rack lead time," not training vs. inference. Single sites are now multi-hundred-MW campuses [8][20], and each MW carries embedded heavy minerals that have to be sourced inside roughly a 30–50 mile trucking radius of the site for the economics to work [11].

## Snapshot
- **Price:** $597.18 (2026-05-09 close) [2]
- **Market cap:** ~$36.4B (implied at $597 spot vs. recently reported $41.3B at higher prints) [4][2]
- **52-week range:** $442.00 – $710.85 [4]
- **Forward P/E:** 28.5× FY26 consensus [4]
- **EV / NTM EBITDA:** 19.86× (vs. 10-yr median ~16.0×; ~24% premium) [17]
- **EV / NTM revenue:** ~5.4× (inference from $41B EV and $7.0–7.32B 2026 revenue guide [3]) — mark as inferred
- **Consensus 12-month PT:** $694–$702 (≈+16–18% implied) [2][17]
- **YTD total return:** roughly flat to slightly negative; -2.4% as of mid-March [18], snap-back post-Q1 has reduced but not closed the gap (inference)
- **Short interest:** 2.7% of float, declining (-22.8% MoM in February) [18]

## Moat — what it is physically made of
The framework the user provided was designed for software/silicon moats. MLM's moat is none of those. It is, in order of durability:

1. **Geological location relative to demand.** Aggregates are a $20–25/ton product [6] with trucking economics around **$0.18/ton-mile** historically [11]. Beyond roughly 30–50 truck-miles, delivered cost doubles and the load is uneconomic. So the moat is *which specific quarries sit inside the 30-mile catchment of Loudoun County, Phoenix-Goodyear, Dallas-Fort Worth, Atlanta, and the Gulf Coast LNG corridor*. The Quikrete-for-aggregates asset swap (closed Feb 23, 2026: ~20M tons/yr in Virginia, Missouri, Kansas, BC + $450M cash) [5][16] was explicitly designed to concentrate the catchment overlap with NoVA "Data Center Alley" — which itself routes an estimated 70% of global internet traffic [16].
2. **Permitting / NIMBY barrier to new supply.** Aggregates is "perhaps the most regulated industry in the US" [13]: federal (Clean Water Act, MSHA), state (air, water, reclamation), and county (CUP/IUP zoning). Greenfield permitting routinely runs >5 years and is frequently defeated by neighbor opposition [13]. This is the closest analog to a fab-allocation moat anywhere outside semis — and it is harder to short-circuit because there is no "Samsung-of-quarries" sitting on idle capacity. Net new domestic aggregates capacity has been flat-to-down for years; supply growth is almost entirely M&A of family operators [12].
3. **Pricing infrastructure: PrecisIQ.** Proprietary local pricing tool that quotes per-job based on demand elasticity, mix and inventory; expected to be in all sales hands by mid-2026 with upside not yet in guidance [14]. This is closer to airline-style yield management than a tech moat — durable in oligopolistic local markets, modest in absolute earnings impact.
4. **Scale advantage in rail-served aggregates.** A small number of MLM/Vulcan/CRH sites are large enough to load unit trains, which extends the economic delivery radius into the hundreds of miles. Most independent operators cannot match this.
5. **Operational discipline / mix management.** Management has been consistent about "value over volume" — willingness to walk away from volume that compresses ASP [12]. Q1 ASP of $23.70/ton was flat because acquired Central/West volumes carried lower mix, even as organic East/Southwest pricing held [3][14].

Honest decomposition: components 1–2 are the actual moat and they are *more durable than any current AI-stack moat* because they are physical and regulatory rather than software/network-effect. Components 3–5 are real but additive, not load-bearing. A would-be displacer needs to either (a) get a new quarry permitted inside the same 30-mile ring (years, often impossible) or (b) make aggregates ship economically over longer distances (no technology in sight). There is no equivalent of "AMD launches MI400" here.

## AI buildout bottleneck map
The 24-month physical buildout has roughly these gating constraints. MLM's exposure to each:

- **Gas turbine slots (GE Vernova, Siemens Energy, Mitsubishi).** GE Vernova's backlog reached **100 GW in Q1 2026, up from 83 GW at YE2025**, and management expects reservations sold out through 2030 by year-end [7]. Siemens Energy backlog €136B; planning 70–80 heavy-duty units/yr by 2026 vs. ~48 [7]. **MLM position: beneficiary.** Every turbine that does get built sits on an MLM-or-competitor pad and is fed by access roads also built with aggregates. The turbine queue is a forward-demand visibility signal for MLM's heavy-non-res book.
- **Grid interconnect and transmission.** Underdiscussed bottleneck. **MLM position: beneficiary** via highway-adjacent transmission corridor and substation civil work, but smaller absolute tonnage than data center pads.
- **CoWoS-L / HBM3e / HBM4 supply.** **MLM position: indifferent.** No direct exposure.
- **Optical interconnect, 1.6T transceivers.** **MLM position: indifferent.**
- **Liquid cooling at >100kW/rack.** **MLM position: marginally exposed.** Higher rack density actually *reduces* concrete-per-MW slightly, because the building footprint shrinks per unit of compute. Long-run mild headwind to intensity even as absolute MW grows.
- **Power generation siting (gas, geothermal, SMR).** **MLM position: beneficiary** wherever the project is inside an MLM trucking radius. LNG/Gulf Coast is named exposure: 10.6M tons already supplied, 33M tons of potential future LNG-related demand identified by management [14].
- **IIJA reauthorization (expires 2026-09-30).** $350B over 5 yrs; states have committed $261B; FY2026 spending bills rescinded $2.3B (mostly NEVI, core highway intact) [15]. **MLM position: exposed.** Public infrastructure is roughly 35–40% of demand historically; a reauthorization lapse into a CR is a real risk to FY27 volumes.
- **Electrical contractor / skilled trades capacity.** **MLM position: indifferent at the input level**, but tight EC capacity slows the *rate* at which pads get poured and turbines get set, which can stretch out MLM's own demand pulse rather than reduce its size.

Net: MLM sits where the bottlenecks stack physically (concrete-first, then power, then compute). It benefits from delays elsewhere as long as the project queue doesn't get cancelled outright.

## Competitive teardown
There is no "AMD vs. NVIDIA" in this stack. The competitors and the axes:

- **Vulcan Materials (VMC).** The only true national peer in pure-play aggregates. Largely overlapping geographic footprint in TX/CA/FL/Southeast; smaller Mid-Atlantic presence than MLM post-Quikrete. Tie on pricing discipline. **Axis:** local quarry-density. MLM took a clear step ahead in NoVA via the Quikrete swap [5]. To take share back, VMC needs a comparable Virginia/Mid-Atlantic acquisition — there is essentially no greenfield permit path open to either.
- **CRH plc (CRH).** Largest US aggregates and asphalt producer overall [19] but more vertically integrated and more diversified into building products. **Axis:** asphalt + paving services bundling. CRH competes meaningfully on integrated project bids; MLM has largely exited downstream concrete (now 1.2M cu yards, Arizona-only [14]). Not a direct technical threat — different business mix.
- **Heidelberg Materials NA / Holcim US (Amrize, post-spin) / CEMEX.** Cement-heavy. **Axis:** cementitious upstream. MLM essentially de-emphasized cement via the Quikrete swap; this is now Heidelberg/Holcim's fight. Not a direct competitor for MLM's NoVA aggregate tons.
- **Summit Materials (SUM) / Eagle Materials (EXP).** Regional. **Axis:** specific catchments. Eagle is cement/wallboard heavy. Summit is regional aggregates and is now part of Quikrete (private). Not national threats.
- **Recycled aggregates / new substitute materials.** Recycled concrete aggregate (RCA) has slowly grown but remains <10% of total US aggregates consumption; spec-restricted in foundation and pavement structural applications. Not a credible 24-month displacer.

The honest summary: the structural competitive set is roughly stable. MLM is not a stock where "competitor catches up on FP4 in 18 months" is a credible thesis. The risk is volume cyclicality and mix, not market share loss.

## Bull case — technical
For MLM to outperform from $597, the following technical conditions need to hold:

1. **Data center groundbreakings continue at the Q1 cadence.** Q1 2026 saw data-center aggregate shipments +62% YoY [3][14], with ~3.27M tons identified in management's data-center backlog plus 2+M tons projected for 2026 [14]. This requires hyperscaler capex to continue compounding through 2027 — not just be sustained, but continue growing. Base rate caveat: prior cycles (telco fiber 1999–2001, shale Phase 1 2012–2014) showed that physical buildouts driven by single end-market technology pulses can flip quickly when the marginal project NPV breaks. The cycle that matters is the spread between hyperscaler ROIC on AI capex and their cost of capital. The pulse is real, but it is **one demand vertical** — and unlike highway, that vertical can stop on a dime.
2. **Gas-turbine-led power buildout converts MLM's behind-the-meter LNG and gas-fired pipeline (10.6M + 33M tons potential [14]) into actual quarry shipments over 2026–2028.** GE Vernova's 100 GW backlog [7] is the leading indicator; the lag from turbine reservation to concrete pour is ~12–24 months.
3. **IIJA reauthorization passes by Q1 2027 at IIJA-or-greater funding levels**, preserving the 35–40% public-infra demand base.
4. **PrecisIQ pricing tool delivers the unmodeled upside management has flagged for 2027 [14].** This is real but small in absolute earnings; treat as a kicker, not a thesis pillar.
5. **Permitting friction continues to choke off new aggregate supply.** This is the highest-confidence bull condition because the regulatory trajectory has been in MLM's favor for a decade [13].

If all five hold, FY27 EBITDA crosses $2.7–2.9B and the stock can support a low-20s EV/EBITDA on a "physical AI pick-and-shovel" multiple — call it $720–800 territory.

## Bear case — technical
The version a short-seller with a working knowledge of the stack would write:

1. **The data center pulse is concentrated, mix-dilutive, and short-half-life.** Q1 +62% data-center shipments came alongside ASP held flat at $23.70/ton because acquired Central/West tons run lower mix [3]. Hyperscaler campuses are being designed for greater density (200 kW racks, direct-to-chip cooling [10]); concrete per delivered MW is gradually *falling*, not rising, even as absolute MW grows. If hyperscaler ROIC on training capex starts to compress in 2026–2027 — which would show up first as project deferrals on the marginal $2–10B campus — the demand step-down is sharp, because there is no other buyer of the same scale for those specific catchments.
2. **The pricing-discipline narrative reverses on volume shock.** "Value over volume" works when both volume and price are firm. When volume disappoints, oligopolists historically defect to volume. PrecisIQ optimizes within demand; it does not create demand.
3. **IIJA expires 2026-09-30 with no reauthorization, drops to CR levels through FY27** [15]. State DOTs delay lettings. Highway tonnage — MLM's most steady demand — softens into 2027.
4. **Diesel and input cost inflation re-accelerates.** Q1 2026 already absorbed $36M aggregates / $50M companywide diesel headwind [14]. A reversion of WTI to upper-$80s blows another ~50–100bps off margins.
5. **Multiple compression.** EV/EBITDA at 19.9× vs. 16× 10-yr median [17]. If the market re-rates the data-center thesis as cyclical rather than secular, the multiple gives back 20–30% before earnings ever miss.

Base rate: in prior infrastructure pulse-driven multiple re-rates (Caterpillar 2014–2016, steel 2008, US frac sand 2014–2016), peak-to-trough multiple compression on materials suppliers ran 30–50% even when EBITDA only fell 15–25%. The asymmetry on bad demand prints is severe.

## Market view check
At $597, 28.5× forward earnings and 19.9× EV/EBITDA, the market is pricing MLM as a quality compounder with an AI/infrastructure tailwind — but the 17% implied upside to consensus PT [2] and the recent pullback from the $711 high [4] suggest the marginal buyer is no longer paying for a "pure AI" multiple. The disagreement worth taking is this: the **moat** (geological + regulatory) is *more* durable than the market typically credits in materials stocks — closer in character to a CoWoS allocation than to a steel mill. But the **demand mix** is now meaningfully levered to one cyclical end-market (data center capex), and the market may be underestimating how quickly that pulse can soften. Net: priced roughly fairly. Asymmetry is mildly skewed to the downside on a 12-month horizon if you assume the data-center pulse is cycle-like rather than secular; mildly skewed to the upside on a 3–5 year horizon because the moat genuinely compounds.

## 90-day falsifiers
Specific, checkable by ~2026-08-10:

- **Q2 2026 earnings (early August):** Does data-center shipment growth stay >40% YoY? Below 25% is a yellow flag; below 10% is a thesis-breaker.
- **Aggregates organic pricing realization at mid-year price increases**: management guided "toward 4%" [14]. Sub-3% would suggest oligopoly discipline cracking.
- **GE Vernova Q2 backlog update**: backlog must reach >110 GW by year-end; if Q2 prints flat or down, the gas-turbine-led MLM call slips.
- **IIJA reauthorization legislative calendar:** any markup of a surface transportation reauthorization bill in House T&I before recess is a positive signal; absence by August adjournment is a real negative.
- **Hyperscaler 2026 capex guidance revisions** in Q2 reports (Microsoft, Meta, Google, Amazon): aggregate sequential cut >10% would directly hit MLM's data-center pipeline.
- **Quikrete-asset Virginia-region run-rate disclosure** at Q2 or analyst day: management has not yet given a clean NoVA-specific revenue / margin number; first such disclosure resets the AI pick-and-shovel narrative quantitatively.
- **Resolution of New Frontier Materials acquisition** (H2 2026 expected [14]): close, regulatory friction, or price changes.

## What I could not verify
- **Concrete/aggregate intensity per MW of data center.** Public estimates exist for *cement* (~247kt 2025, ~1Mt cumulative through 2028 [10]) but I could not find a credible per-MW aggregates figure. This matters because the bear thesis depends on intensity falling with density, and I cannot quantify the slope.
- **MLM-specific NoVA revenue and EBITDA share** post-Quikrete swap. Management has not broken out Virginia or "Data Center Alley" as a segment.
- **PrecisIQ economic uplift in dollars.** Disclosed only qualitatively; "embedded in current guidance, upside into 2027" [14] is not falsifiable yet.
- **Whether Vulcan has a comparable pricing tool.** Both companies are tight-lipped on pricing-tech specifics.
- **The exact share of MLM's heavy-non-res order book that is hyperscaler-funded vs. colocation/REIT-funded vs. enterprise.** This matters because hyperscaler capex and colo capex have different cyclical drivers.
- **Whether IIJA reauthorization gets done in 2026 vs. slips into a CR.** Genuinely unknowable at this point; depends on the post-election calendar.
- **Q2 to-date freight/diesel run-rate**: management guided $20–25M of the $50M diesel hit weighted to Q2 [14], but I could not verify with intra-quarter freight indices.

## Sources
[1] https://www.martinmarietta.com/facility-locator — retrieved 2026-05-10 — established MLM's site footprint (~500 locations, 30 states + Canada + Caribbean).
[2] https://finance.yahoo.com/quote/MLM/ — retrieved 2026-05-10 — current price $597.18; consensus 12-month PT range and rating composition.
[3] https://www.globenewswire.com/news-release/2026/04/30/3284659/0/en/Martin-Marietta-Reports-First-Quarter-2026-Results.html — retrieved 2026-05-10 — Q1 2026 revenue $1.362B (+17%), aggregates shipments 43.9M tons (+12.4%), ASP $23.70/ton, full-year revenue guide $7.0–7.32B.
[4] https://stockanalysis.com/stocks/mlm/statistics/ — retrieved 2026-05-10 — 52-week range $442–$711, forward P/E 28.52×, market cap reference.
[5] https://ir.martinmarietta.com/news-releases/news-release-details/martin-marietta-and-quikrete-exchange-certain-cement-and — retrieved 2026-05-10 — Quikrete asset exchange terms: ~20M tons/yr aggregates in VA/MO/KS/BC + $450M cash.
[6] https://latestcost.com/aggregate-cost-per-ton-united-states/ — retrieved 2026-05-10 — current US aggregate per-ton price bands.
[7] https://www.utilitydive.com/news/ge-vernova-gas-turbine-backlog-hits-100-gw-as-prices-rise/818332/ — retrieved 2026-05-10 — GE Vernova Q1 2026 backlog 100 GW, slots sold through 2030; Siemens €136B backlog; gas turbine bottleneck quantification.
[8] https://spectrum.ieee.org/5gw-data-center — retrieved 2026-05-10 — multi-hundred-MW campus design, density trends.
[9] https://rockproducts.com/2026/04/30/record-aggregates-tonnage-powers-martin-mariettas-first-quarter/ — retrieved 2026-05-10 — Q1 shipment record context.
[10] https://www.cement.org/2025/06/19/new-industry-report-predicts-u-s-will-need-1million-tons-of-cement-for-ai-infrastructure-by-2028/ — retrieved 2026-05-10 — ACA estimate ~1M tons cement for AI infrastructure through 2028; data center cement intensity ~66% of typical office.
[11] https://aggregatemarkets.com/en/blog/delivery-ordering/aggregate-delivery-cost-per-mile-ton-guide — retrieved 2026-05-10 — trucking economics, $0.18/ton-mile historical reference; effective delivery radius.
[12] https://markets.financialcontent.com/stocks/article/finterra-2026-2-11-concrete-strength-a-deep-dive-into-martin-marietta-materials-mlm-and-the-infrastructure-decade — retrieved 2026-05-10 — oligopoly structure, "value over volume," consolidation of family operators.
[13] https://www.burgex.com/2026/04/09/quarry-permitting-zoning-support/ — retrieved 2026-05-10 — quarry permitting and zoning barriers, NIMBY dynamics.
[14] https://www.fool.com/earnings/call-transcripts/2026/04/30/martin-marietta-mlm-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1 2026 earnings call: data center +62%, warehouse +57%, LNG +20%; LNG pipeline 10.6M supplied + 33M potential; New Frontier acquisition; PrecisIQ rollout; diesel $50M headwind; 4% pricing guide.
[15] https://fundinglandscape.com/answers/infrastructure-iija-funding-2026 — retrieved 2026-05-10 — IIJA expiration 2026-09-30, $2.3B FY26 rescissions, reauthorization status.
[16] https://www.commondreams.org/opinion/data-center-alley-big-tech — retrieved 2026-05-10 — Virginia Data Center Alley traffic share context.
[17] https://www.gurufocus.com/term/enterprise-value-to-ebitda/MLM — retrieved 2026-05-10 — EV/EBITDA 19.86× vs. 10-yr median 16.03×.
[18] https://www.themarketsdaily.com/2026/03/04/martin-marietta-materials-inc-nysemlm-short-interest-update.html — retrieved 2026-05-10 — short interest 2.7% of float, -22.8% MoM February; YTD return reference.
[19] https://www.equipmentworld.com/market-pulse/article/15737444/who-are-the-top-us-construction-aggregates-producers — retrieved 2026-05-10 — US crushed stone producer rankings: Vulcan, CRH, MLM, Heidelberg, Holcim, Cemex, Summit.
[20] https://rockproducts.com/2026/03/16/concrete-conduit-and-code-the-real-foundation-of-the-data-center-boom/ — retrieved 2026-05-10 — multi-year supply agreement structure; integrated aggregate/cement/concrete advantage for data center projects.