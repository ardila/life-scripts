# EXC — Exelon Corporation

## Where this sits in the AI stack
Exelon is a pure-play regulated electric transmission & distribution holding company (post-Constellation/CEG spin in Feb 2022) — six state utilities (ComEd in Northern Illinois, BGE in Central Maryland, PECO in SE Pennsylvania, Pepco in DC, Delmarva, Atlantic City Electric) serving ~10M customers, all inside the PJM Interconnection footprint [17]. In the AI stack, EXC sits at the **grid interconnect / power delivery layer**: it owns no generation and no compute — only the wires, substations, transformers, and the regulated franchise that delivers power from PJM-cleared generators to hyperscaler campuses. Its workload is power delivery for everything from training clusters to inference farms; it is workload- and chip-agnostic.

## Snapshot
- **Price:** ~$44.41 (2026-05-08 close, ~6% off 52-week low) [17]
- **Market cap:** ~$45.3B [17]
- **52-week range:** $41.71 – $50.65 [17]
- **Forward P/E:** 17.2× (on implied FY26 consensus EPS ~$2.58) [21]
- **EV / NTM revenue:** ~3.5× (rough; utility EV/EBITDA at ~11× is the cleaner multiple — revenue includes pass-through transmission and fuel costs that distort cross-sector comparison) — inference from $45B equity + ~$42B debt / ~$25B NTM revenue
- **Consensus 12-month price target:** $49.29 (median, 14 analysts) — +11% from price; high target $51.86 [21]
- **YTD total return:** ~flat to mid-single-digit positive (inference; not directly cited — stock near 52-week low but above year-end 2025 base)
- **Short interest (% of float):** 3.9% [21]

## Moat — what it is physically made of
The moat decomposes into three layers with very different durability.

**1. Regulatory franchise (the dominant moat).** Each of EXC's six utilities is a statutory monopoly in its service territory under state PUC rules + Federal Power Act jurisdiction for interstate transmission. No competitor can string wires to a customer in ComEd's Northern Illinois territory. Base rate on displacement: utility T&D franchises have not been broken in any major US territory since the 1935 PUHCA — call this the most durable moat profile in the entire AI-infrastructure stack. The only meaningful erosion path is **behind-the-meter (BTM) bypass** — customers self-generating onsite to avoid utility delivery. For decades this was negligible for industrial customers (~5% cogen share); AI data centers may be the first new customer class with both the scale and the speed-to-power pressure to make BTM material [8][10].

**2. Physical T&D plant + FERC formula rates on transmission.** Rate base is ~$70B as of FY25, growing 7.9% CAGR to ~$95B+ by FY29 against a $41.7B 4-year capex plan [2]. Mix shift is the more important fact than the headline: transmission is now 39% of capex vs 21% in the prior plan; transmission rate base is guided to grow **16%** through FY29 [2]. The reason this matters technically: FERC-jurisdictional transmission runs on **formula rates** with annual true-ups, allowed ROEs in the 9.80%–11.20% range plus a 50bp RTO adder (MAIT settled at 9.80%; analogous numbers apply across EXC's footprint) [20]. State-PUC-regulated distribution runs on rate cases that can be partially denied — the ICC clipped ComEd's last reconciliation $25M of a $268.5M ask and has held ComEd distribution ROE at 8.905% [15]. So the mix shift from distribution to transmission is also a mix shift from contested rate cases to formulaic earnings.

**3. Interconnection optionality (the new moat the market is still learning to price).** EXC has 18 GW of advanced data center pipeline with ~45% locked in via Transmission Service Agreements (TSAs); broader pipeline including studies is ~47 GW of potential additions [1][19]. The TSAs are the technically interesting piece: they include defined ramp schedules, customer facility readiness obligations, credit obligations, committed revenue contributions, shortfall payments if data-center usage misses commitments, and termination-fee schedules [16]. FERC approved five ComEd TSAs in March 2026 over Illinois AG objection [16]. The effect: rate-base risk on cancelled or under-utilized data centers is shifted to the hyperscaler counterparty, while EXC retains the upside of in-service load. Durability: medium — strongly protective contractually but exposed if FERC's December 2025 co-location order [6] produces PJM rules that let data centers connect directly to generation without buying utility T&D service.

What this moat is **not**: a network-effect moat, a software ecosystem, or a manufacturing-scale moat. The right analog is not NVIDIA-CUDA; it's a toll booth on a road no one else is legally allowed to build, with a federally-regulated toll rate that resets annually.

## AI buildout bottleneck map

| Bottleneck (next 24 months) | EXC position |
|---|---|
| **PJM interconnection queue (large load + generation)** | Beneficiary AND constraint owner. Median project wait ~5yr; data centers up to 12yr [23]. EXC's TSA mechanism lets it effectively ration interconnection slots. |
| **PJM generation capacity adequacy** | Indifferent on revenue (post-CEG spin owns no generation); negatively exposed politically — capacity prices at the FERC cap of $329.17/MW-day for 2026/27 and $333.44 for 2027/28 [4] flow to retail bills with a 12-18mo lag, fueling state-PUC backlash. |
| **High-voltage transmission build (765kV AC, 525kV HVDC)** | Direct beneficiary. PJM's $11.8B 2025 RTEP Window 1 awards: $568M to Exelon subsidiaries plus a 50/50 split with NextEra on a $1.7B 221-mile 765kV line in central PA [7]. |
| **CoWoS-L allocation / HBM / GPUs** | Indifferent. EXC sells power, not silicon. |
| **>100kW/rack liquid cooling** | Indifferent. |
| **Behind-the-meter gas turbines (GE Vernova LM, Mitsubishi H-class, Caterpillar recip)** | **Exposed.** 35 GW BTM forecast by 2030 [8]; 56 GW of BTM projects announced in 2025 alone (~30% of all planned US data center capacity) [10]. Every MW that goes BTM is a MW EXC does not earn a return on. |
| **State PUC affordability politics** | **Exposed.** ICC trimmed ComEd's rate case ~9% and held distribution ROE at 8.905% [15]; Maryland HB 120 would pause new data centers pending co-location legislation [12]; Baltimore City has a 1-year moratorium bill [11]. |
| **Electrical contractor / IBEW labor** | Indifferent (cost pass-through). |

The two binding constraints on the EXC-specific thesis are BTM substitution at the top of the customer stack and affordability politics at the bottom. The middle — FERC-jurisdictional transmission — is the high-conviction earnings driver.

## Competitive teardown
EXC has no direct geographic competitor inside its franchise territories. Competition runs on three other axes.

**vs. Dominion Energy (D, Virginia).** Northern Virginia is roughly 4× the data center concentration of any single Exelon zone [18]; Dominion landed the headline ~$4.8B 525kV HVDC line in the 2025 RTEP, the single largest individual award [7]. Dominion's data-center load is more concentrated and more mature; Exelon's is more diversified across six utilities and earlier in conversion. Dominion is the higher-beta data center utility; EXC is the diversified play.

**vs. AEP.** AEP guides 7-9% EPS growth on $72B 5-year capex vs EXC's 6-8% on $41.7B 4-year capex. AEP's seven transcos have historically delivered 14-17% rate base growth — so on the *transmission* axis AEP is roughly comparable to EXC's 16%. AEP has more regulatory diversity but more rural, lower-growth distribution territory. EXC's edge is being concentrated in tier-1 data center markets (Chicago suburbs, Maryland, SE PA, DC).

**vs. independent power producers (CEG, VST, TLN, NRG).** These are not direct competitors but they are the customer-supply alternative for hyperscalers. The Talen-Amazon Susquehanna case is the canonical precedent: FERC's November 2024 rejection of the BTM interconnection agreement [5] forced a restructure into a $18B / 1.92 GW front-of-the-meter PPA in June 2025 — that outcome routes the power through PJM-dispatched flows and partly into utility-territory T&D, which is net-positive for EXC-type utilities. The December 2025 FERC co-location order [6] partially walks this back by directing PJM to write co-location rules with three new transmission service options. The exact scope of the carveout is the most important regulatory variable on the entire bear case.

**vs. behind-the-meter providers (GE Vernova LM aero-derivative turbines, Mitsubishi MHPS H-class, Caterpillar reciprocating).** This is the actual technical competitor. A 100MW BTM gas turbine campus can be commissioned in roughly 18-30 months vs 5-12 years for utility interconnection in PJM [23]. Trade-offs: BTM lacks built-in grid backup (most customers want a thin interconnection anyway), is gas-price exposed, and faces local air permitting that has shut down BTM projects in several states. But for a hyperscaler with a 24-month go-live window on a frontier-training campus, BTM is often the only feasible answer regardless of utility economics.

On capex efficiency, EXC and peers are roughly comparable ($5B capex per 100bp rate base growth); the differentiation is not "how efficiently you spend" but "where you spend" (FERC transmission vs state distribution) and "what customers you land" (TSA-protected hyperscaler load vs general retail).

## Bull case — technical
Three conditions need to hold:

1. **PJM load growth holds its trajectory.** PJM's 2025 forecast has 35 GW of large-load adjustments 2026-2031 [3]. The base rate against this is bearish — US utility load grew ~0.5% for two decades, so a step to 3%+ is unprecedented. But the supporting evidence is unusually strong: $300B+/yr hyperscaler capex commits, CoWoS-L allocations confirmed for 2026-27, MLPerf-class training runs requiring 100MW+ campuses. If actual load tracks even 70% of forecast, the 7.9% rate base CAGR is durable.

2. **Co-located BTM remains a minority path.** Most published BTM announcements include "subject to permitting" language; historical base rates on infrastructure announcements suggest <40% conversion. If BTM clears under 30% of the 56 GW announced [10], TSA-protected utility-delivered load is the dominant path for the AI buildout.

3. **State PUCs continue to grant 60-70% of rate-case asks.** The ICC has been the toughest regulator in EXC's footprint and is still approving ~90% of the dollar request in reconciliation [15]. Even with state distribution pressure, the mix shift to FERC transmission (39% of capex and rising) insulates consolidated ROE — FERC formula rates do not require a rate case to recover.

Financial bridge: 6-8% EPS CAGR + 3.8% dividend yield = 10-12% total return before any multiple change. Re-rating EXC to a "data center beneficiary" multiple (e.g., 19-20x in line with Dominion/AEP) is another ~15-20% of upside.

## Bear case — technical
The version a credible short would write:

1. **Speed-to-power gates the 18 GW pipeline.** The pipeline assumes hyperscalers wait 5-7yr for interconnection. They will not — Microsoft, Meta, and xAI have already demonstrated they build BTM rather than wait, and 56 GW of BTM was announced in 2025 alone [10]. The "advanced" pipeline is a lagging indicator; by the time the studies convert, some material share will have rerouted to BTM or to faster-interconnect markets (ERCOT, AEP Indiana-Michigan, MISO South). The TSAs lock in cost recovery if a project cancels but do not lock in the rate base if a project diverts to BTM mid-development.

2. **FERC's co-location ruling is a structural shift.** The December 2025 order [6] is being read as protective, but it formally creates three new transmission service options including a co-location pathway. Once PJM writes its compliance rules (deadlines starting January 2026 [6]), hyperscalers have a legal blueprint to interconnect to an existing generator without paying full T&D charges. Asymmetric outcome: utility load that would have flowed through EXC's wires routes around them.

3. **Affordability politics break the rate base flywheel.** PJM capacity prices at the FERC cap [4] flow to retail bills 12-18 months later; peak political pain therefore lands in late 2026 / 2027. Maryland HB 120 [12], Baltimore's moratorium [11], the ICC reconciliation clipping [15], and Exelon spending $460k/quarter on lobbying [14] are early signals. Historically, US utility regulators tolerate 10-15% retail rate increases before significant ROE pushback; PJM-zone bills are tracking to 20%+. Falsifier: any of the three big-state PUCs (Illinois, Maryland, Pennsylvania) opens a generic affordability or ROE docket.

4. **"Re-entering generation" introduces volatility the spin was designed to eliminate.** CEO Calvin Butler has signaled interest in re-entering generation [14]. CEG was spun out specifically because regulated T&D had a better risk-adjusted return profile than merchant generation. Re-entry would re-introduce capacity-price exposure and merchant risk; the very act of signalling it is evidence management is worried about load conversion.

5. **Base rate on platform shifts says BTM lands at 25-40%.** When a customer class with strong economic incentive can credibly self-supply (industrial cogen in the 1990s; on-prem→cloud for IT; ICE→EV for transport), incumbents typically lose 20-40% of segment share over 10-15 years. The 35 GW S&P forecast [8] sits inside that range. EXC's 6-8% EPS CAGR implicitly assumes minimal BTM substitution; the base rate says assume meaningful substitution and cut medium-term rate base accordingly.

## Market view check
At ~$44.41 / 17.2× forward / 3.8% yield, EXC trades roughly in line with the regulated utility group (15-18× forward) and at a discount to data-center-levered utility peers (Dominion ~19×, AEP ~19×, NextEra ~21× — peer multiples are approximate). Consensus PT $49.29 implies ~11% upside. The price is currently pricing EXC as "good utility with some data center exposure" — closer to the bear case than the bull. Where I disagree with consensus: the FERC-jurisdictional transmission segment is being underweighted. 16% rate base growth under a FERC formula rate is a structurally better business than the average utility, and the current consolidated multiple does not distinguish FERC transmission rate base from state distribution rate base. The mispricing, if it exists, is on the *quality* of the rate base growth, not the *quantity*.

## 90-day falsifiers
- **PJM's compliance filing in response to FERC's Dec 2025 co-location order [6].** The treatment of "behind-the-meter eligibility" — specifically whether co-located loads pay full grid charges or a carveout rate — directly sizes EXC's load forecast. Filing deadlines start January 2026; substantive filing likely Q2 2026.
- **Q2 2026 earnings (early August).** Updated 18 GW advanced pipeline number and TSA conversion %. If pipeline shrinks or TSA share stalls below 45%, the rate base assumption breaks.
- **Maryland HB 120 / Baltimore moratorium final disposition** (2026 legislative cycle, end-of-session dates by mid-summer). A pass would dent BGE's pipeline; a fail would re-rate the affordability-risk discount.
- **PJM 2027/2028 base residual auction results** (typically run July–August). Another clear at the cap locks in 2027 retail rate increases and raises political risk.
- **Illinois AG action on ComEd TSA filings or any generic ROE docket at the ICC.** A move from intervening on individual TSAs to opening a generic affordability proceeding would directly pressure distribution ROE.
- **Hyperscaler BTM announcements in EXC territory.** Any 500MW+ BTM project announcement in Northern Illinois (would otherwise be ComEd load) or Maryland (BGE) is a thesis dent and a leading indicator that the pipeline is leaking.

## What I could not verify
- EXC's explicit FY26 EPS guidance midpoint (search confirmed 6-8% long-term EPS growth and the Q1 beat but not a stated $X.XX FY26 range).
- Consolidated net debt and net debt / EBITDA (relevant for the EV/revenue calculation; multiples shown are approximations).
- YTD total return precisely; estimated flat-to-mid-single-digit positive based on proximity to 52-week low.
- The FERC-approved base ROE applicable to each of the six Exelon utilities for transmission service. MAIT was the only one explicitly cited [20]; ComEd, BGE, PECO, Pepco, Delmarva, ACE-specific transmission ROEs were not located in search.
- The territory-level split of the 56 GW announced BTM projects between EXC territory and other PJM zones / other RTOs [10].
- The exact scope of the "three new transmission service options" in the FERC December 2025 order [6] — whether any of them allow bypassing incumbent T&D charges (the PJM compliance filing will resolve this and is the single highest-leverage variable in the entire thesis).
- Whether Calvin Butler's "re-entering generation" comments [14] are aspirational or backed by specific projects / capital allocation.

## Sources
[1] https://www.fool.com/earnings/call-transcripts/2026/05/06/exelon-exc-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1 2026 earnings transcript: 18 GW advanced pipeline, ~45% TSA coverage, $41.7B 4yr capex
[2] https://www.utilitydive.com/news/exelon-transmission-data-center-capex-earnings/812200/ — retrieved 2026-05-10 — capital plan up to $41.3B-$41.7B; transmission share 39% (vs 21% prior); transmission rate base 16% CAGR; 7.9% consolidated rate base
[3] https://www.pjm.com/-/media/DotCom/library/reports-notices/load-forecast/2025-load-report.pdf — retrieved 2026-05-10 — PJM 2025 long-term load forecast; 35 GW large-load adjustments 2026-31
[4] https://www.enelnorthamerica.com/insights/blogs/pjm-2026-2027-capacity-auction-results — retrieved 2026-05-10 — 2026/27 auction cleared at $329.17/MW-day cap; 2027/28 at $333.44
[5] https://www.utilitydive.com/news/ferc-interconnection-isa-talen-amazon-data-center-susquehanna-exelon/731841/ — retrieved 2026-05-10 — FERC Nov 2024 rejection of Talen-Amazon ISA at Susquehanna
[6] https://www.utilitydive.com/news/ferc-pjm-colocation-data-center/808368/ — retrieved 2026-05-10 — FERC Dec 18 2025 order directing PJM to write co-location rules; three new transmission service options; deadlines from January 2026
[7] https://www.utilitydive.com/news/pjm-rtep-transmission-expansion-plan-dominion-nextera-exelon/812311/ — retrieved 2026-05-10 — PJM $11.8B 2025 RTEP awards; Dominion $4.8B HVDC, Exelon subs $568M + NextEra/Exelon 50/50 $1.7B 765kV
[8] https://www.spglobal.com/market-intelligence/en/news-insights/articles/2025/10/data-center-developers-turn-to-distributed-behind-the-meter-power-94174247 — retrieved 2026-05-10 — 35 GW BTM by 2030 forecast
[9] https://www.tomshardware.com/tech-industry/artificial-intelligence/u-s-electricity-grid-stretches-thin-as-data-centers-rush-to-turn-on-onsite-generators-meta-xai-and-other-tech-giants-race-to-solve-ais-insatiable-power-appetite — retrieved 2026-05-10 — Meta, xAI, others deploying onsite generation to bypass utility queue
[10] https://avanzaenergy.substack.com/p/data-centers-are-killing-the-grid — retrieved 2026-05-10 — 56 GW BTM projects announced in 2025 alone (~30% of planned US data center capacity); per S&P Global data
[11] https://www.cbsnews.com/baltimore/news/baltimore-city-data-center-bill-energy-moratorium/ — retrieved 2026-05-10 — Baltimore City Council 1-year data center moratorium bill
[12] https://www.thebanner.com/politics-power/state-government/bge-maryland-data-center-exelon-ONPTWQJLCVFURA45AYA2L4MRMI/ — retrieved 2026-05-10 — Maryland HB 120 / Baltimore Peninsula data center debate
[13] https://www.tikr.com/blog/exelon-stock-is-close-to-its-52-week-low-heres-why-data-center-growth-could-change-the-story — retrieved 2026-05-10 — Exelon near 52-wk low, 15.3× forward P/E (TIKR's calc), ~3.8% yield, ComEd Illinois +19 GW load by 2030
[14] https://www.semafor.com/article/02/17/2026/exelons-controversial-play-for-affordable-electricity — retrieved 2026-05-10 — Calvin Butler on re-entering generation; $60M low-income fund; lobbying spend $460k/quarter
[15] https://www.citizensutilityboard.org/blog/2025/12/18/cub-statement-on-comeds-243m-reconciliation-rate-hike/ — retrieved 2026-05-10 — ICC granted $243M of $268.5M ComEd ask; ROE rulings 8.905% (distribution) and 10.21%/10.75% (other proceedings)
[16] https://www.utilitydive.com/news/ferc-comed-exelon-data-center-service-agreement/814414/ — retrieved 2026-05-10 — FERC Mar 10 2026 approval of five ComEd-data center TSAs; ramp, credit, shortfall, termination terms
[17] https://finance.yahoo.com/quote/EXC/ — retrieved 2026-05-10 — current price ~$44.41, market cap ~$45.3B, 52-week range $41.71–$50.65; Q1 EPS $0.91 vs $0.87 est
[18] https://www.datacenterdynamics.com/en/news/dominion-connected-15-data-centers-totaling-933mw-in-virginia-in-2023-15-more-expected-in-2024/ — retrieved 2026-05-10 — Dominion ~94 data centers / 4+ GW in NoVA; ~26% of total Dominion VA load
[19] https://www.utilitydive.com/news/exelon-data-center-amazon-earnings-maryland/804720/ — retrieved 2026-05-10 — Exelon 18 GW advanced pipeline + 47 GW potential
[20] http://spark.fortnightly.com/fortnightly/transmission-rate-incentives — retrieved 2026-05-10 — FERC base ROEs for PJM transmission owners 9.80% (MAIT) to 11.20% (TrAILCo) + 50bp RTO adder
[21] https://stockanalysis.com/stocks/exc/forecast/ — retrieved 2026-05-10 — 14-analyst consensus PT $49.29; forward P/E 17.22; short interest 3.9%
[22] https://www.utilitydive.com/news/pjm-interconnection-load-forecast-data-centers/809717/ — retrieved 2026-05-10 — PJM trimmed near-term forecast with stricter data center vetting
[23] https://rmi.org/pjms-speed-to-power-problem-and-how-to-fix-it/ — retrieved 2026-05-10 — PJM "speed-to-power" analysis; median ~5yr wait, data centers up to 12yr