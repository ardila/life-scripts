# LMT — Lockheed Martin Corporation

## Where this sits in the AI stack
LMT is **not** an AI-infrastructure company in the silicon/packaging/networking sense the prompt assumes. It is a defense prime that **consumes** AI infrastructure (an on-prem NVIDIA DGX SuperPOD, classified compute, Llama via Meta's national-security carve-out [9]) and **embeds** AI/autonomy into kinetic platforms — Skunk Works tactical autonomy on the X-62A VISTA, Project Carrera flexible-autonomy software, the Vectis Group-5 collaborative combat aircraft, and threat-track ML in PAC-3 and Aegis-integrated missile defense [11][12][14]. The closest thing to a "product" sold into the AI stack is Astris AI, a subsidiary that packages LMT's MLOps stack for ITAR/NIPR/SIPR/JWICS environments [4][5]. Read LMT as a defense conglomerate whose long-term equity story now hinges on whether software-defined warfare erodes the prime model faster than LMT can re-platform itself.

## Snapshot
- **Price:** $506.51 (2026-05-08 close) [1]
- **Market cap:** ~$117B [1] (230.6M shares × $506.51 [27])
- **52-week range:** $410.11 – $692.00 [1]
- **Forward P/E:** ~17.0× on FY26 EPS guide midpoint $29.80 ($29.35–$30.25 reaffirmed Q1) [3][7]
- **EV / NTM revenue:** ~1.7× (EV ≈ $134B on ~$17B net debt; FY26 sales guide $77.5–80.0B) [3][7]
- **Consensus 12-month price target:** ~$602 mean / ~$665 median (range $520–$770), implied +19% to +31% [7]
- **YTD total return:** +~26–29% (LMT among 2026's safe-haven outperformers as European/Asian rearmament accelerates) [16]
- **Short interest (% of float):** n/a — could not verify a current figure; MarketBeat tracks but the value was not retrievable in the search window [15]

## Moat — what it is physically made of
LMT's moat is **not software ecosystem depth** in the CUDA sense. It is a stack of physical, regulatory, and contractual barriers, each of which deserves separate assessment:

1. **F-35 single-source position.** Lockheed is the prime and sole-source manufacturer of the F-35 with a Block 4/TR-3 software baseline that DoD itself describes as not fully achievable until 2031, after a "scaled-down" descope [10]. ~$186B total backlog is dominated by F-35 and missile programs [3]. Switching cost is generational: tooling, ALIS/ODIN sustainment software, JSE simulation, INTEGRITY-178 RTOS on Lockheed-controlled mission computers [21]. Durability: high through 2030, but **Congress is actively trying to pry open the software side** — Section 135 of the Senate NDAA mandates an "open mission systems computing environment" for the F-35 [21]. This is the single biggest structural threat to the moat as currently constituted.

2. **Skunk Works classified pipeline.** The classified aero program that took $1.6B of charges in Q2 2025 [22] is *also* the long-tail engine of NGAD-class follow-on work, the X-62A VISTA tactical-AI experiments, and the Vectis CCA (announced Sept 2025; first flight targeted late-2027 on a 2-year design-to-fly) [12][14]. Skunk Works is genuinely difficult to replicate — clearances, decades of OPSEC-compliant tooling, captive flight-test infrastructure at Helendale/Palmdale. Durability: high, but margin-impaired under fixed-price terms.

3. **Missile production base.** PAC-3 MSE is being scaled from 600 → 2,000 units/year under a 7-year framework with the government, with a $4.7B undefinitized contract action in April 2026 [13]. THAAD remains LMT-prime [8]. Dark Eagle/LRHW production is at >12/yr with a $2.7B contract awarded April 2026 to double to 24/yr [11]. The bottleneck here is **solid rocket motor capacity, energetics, and skilled CNC labor**, not anything AI-related — and LMT does not own the SRM monopoly (Northrop/Aerojet does). Durability: high on missiles where LMT is integrator/seeker; medium on energetics it doesn't own.

4. **Astris AI / AI Factory.** Internally a real asset — NVIDIA DGX SuperPOD on-prem, 30+ consolidated models, 7,000 engineering users, 1B+ tokens/week, RAG and proposal-generation pipelines [6][9]. Externally it is **not** a moat — Palantir's Maven/AIP, Anduril's Lattice, and AWS GovCloud + Bedrock are credible substitutes for the same buyers [17][20]. Astris's edge is regulatory (it can run on JWICS-tier networks because LMT already has the cleared facilities and personnel), not algorithmic. Durability: 3–5 years before commoditization.

5. **Brand / cleared workforce / facility infrastructure.** ~115k employees, a large fraction cleared, occupying SCIFs that are themselves a constrained resource. This is real but is a barrier to *entry into government work*, not a barrier to *displacement once a competitor has entered*. Anduril and Palantir have already crossed that bar.

Honest summary: the moat is real and physical (F-35 lock-in, missile production muscle, Skunk Works), but **none of the components is software-network-effect-shaped** the way NVIDIA's CUDA moat is. Each component decays on a different clock, and the F-35-software clock is the one being attacked right now.

## AI buildout bottleneck map
LMT's exposure to the AI buildout is asymmetric: it is largely **indifferent** to the bottlenecks that matter for hyperscaler capex.

| Bottleneck | LMT position |
|---|---|
| Power generation / grid interconnect | Indifferent. LMT's facility load is rounding error vs hyperscalers. |
| CoWoS-L advanced packaging | Indifferent — buys NVIDIA systems off the shelf [6]. Not allocation-constrained. |
| HBM3e / HBM4 supply | Indifferent (consumer of NVIDIA DGX, not allocator). |
| Optical interconnect / 1.6T pluggables | Indifferent at scale of deployment. |
| Liquid cooling > 100kW/rack | Minor — DGX SuperPOD class, not GB200 NVL72 class [6]. |
| Kernel/compiler talent | Modestly constrained — hard to recruit ML systems engineers into cleared facilities; partly mitigated by Astris's commercial-side hiring channel [4]. |
| Solid rocket motor (SRM) capacity | **Constraint owner / exposed customer.** LMT is integrator on PAC-3, THAAD, LRHW; does not own most propellant [13]. The munitions ramp depends on Northrop and Aerojet Rocketdyne (now L3Harris) propellant lines. |
| GaN T/R modules for radar | Exposed — most production is RTX (Raytheon). |
| Cleared SCIF / ITAR-compliant compute | **Beneficiary.** Astris AI and the AI Factory exploit this directly [4][6]. |
| Classified flight-test ranges (Helendale, Tonopah) | Beneficiary / scarce-resource holder. |

Net: the AI buildout itself is **not** a bullish driver for LMT; the kinetic-munitions supply chain is the gating constraint on its top line, and the binding inputs there are propellant and energetics, not GPUs.

## Competitive teardown
- **Boeing (BA)** — won NGAD/F-47 in March 2025 over LMT's offering [2][22]. Boeing reportedly built a comprehensive digital twin of the F-47 before the prototype existed; this matters because it means Boeing's 6th-gen toolchain is ahead of where LMT was when it lost the down-select [2]. Axis: digital-engineering parity. Boeing already has parity here. Time horizon for LMT to recover NGAD-class share: a decade-plus, conditional on F/A-XX (Navy 6th-gen) outcome.
- **Northrop Grumman (NOC)** — owns B-21 production, owns Sentinel ICBM (now $140.9B program, +81% over baseline) [23], owns most strategic SRM through ATK heritage [13]. NOC competes with LMT on space and missiles; they cooperate on LRHW (Northrop builds the booster, Lockheed integrates) [11]. Axis: strategic deterrent / SRM. NOC is structurally stronger here.
- **RTX (Raytheon)** — direct PAC-3 competitor through Raytheon's own SAM portfolio (LTAMDS replacing the Patriot radar), GaN T/R module dominance, and Tomahawk/SM-6/SM-3 production. Axis: missile defense radars, naval strike. RTX trades at ~27× forward [7] vs LMT at 17× — the market has clearly priced RTX's optionality higher.
- **Anduril** — $20B Army enterprise agreement March 2026 (consolidating 120 prior contracts), YFQ-44 Fury CCA flying since 31 Oct 2025 [17][19]. Axis: software-defined autonomy, CCA. Already has parity-or-better on cost-per-effect for unmanned platforms; Vectis is LMT's late response [12][14], with first flight not until late 2027.
- **Palantir** — $10B Army enterprise deal (Aug 2025), and notably won a battlefield-system prime award over RTX [17]. Axis: data-fusion software at theater scale. LMT's Astris AI is positioned as a *defense-grade* alternative but is selling into the same buyer with a less mature platform [4][5].
- **General Atomics** — YFQ-42 (first flight 27 Aug 2025) is the other CCA designated competitor [18][19]. Targets ~$25–30M unit cost (~⅓ of an advanced fighter) [19]. Axis: CCA at scale.
- **China (J-36 / J-50)** — both 6th-gen prototypes flew in late 2024 / 2025 [25]. Strategic implication for LMT is that pressure on F-47 and CCA timelines will drive *more* DoD demand, not less, but the marginal contract will increasingly go to the fastest-cycle bidder, which historically has not been LMT.

The honest read: on the new-model axes (digital engineering, software-defined autonomy, CCA economics) **competitors already have parity or better.** LMT's competitive strength is on the legacy axes (sustainment, integration, missile production scale-out).

## Bull case — technical
For LMT to outperform from $507, the following technical conditions must hold:

1. **F-35 sustainment captures the long-tail value.** Block 4 truncation actually *helps* the bull case — fewer modernization charges, higher proportion of revenue at higher-margin sustainment rates [3][10]. Q1 2026 already showed a $130M favorable adjustment on F-35 sustainment [3].
2. **Munitions ramp executes.** PAC-3 MSE 600→2,000/yr by 2030 [13] and LRHW doubling to 24/yr [11] need to execute without further fixed-price write-downs. Munitions are inherently shorter-cycle and less politically reversible than aircraft programs.
3. **Golden Dome materializes as a multi-year tailwind.** $17.9B in FY27 budget, "system-of-systems" architecture explicitly anchored on PAC-3, THAAD, Aegis BMD [8]. LMT is prime on THAAD and PAC-3 and a contributor on the architecture studies [8].
4. **AI/autonomy embeds successfully into existing platforms** rather than displacing them. If Vectis flies on schedule (late 2027) [14] and Project Carrera plus the X-62A tactical-AI work [12] convert into incumbency on the larger CCA Increment 2 award, LMT defends the franchise.
5. **Boeing fumbles F-47 EMD.** Base rate on first-flight-in-2028 fighter programs slipping is high (F-35 itself is the canonical example).

Base rate caveat: in past defense-prime displacement attempts (Boeing on tankers, Bell on tiltrotor, SpaceX on launch), the incumbent typically defended its current revenue base for a decade or more even when objectively beaten on the next-generation axis. This argues for *gradual* margin compression, not a cliff. Connecting to financials: that's a "high-teens P/E, MSD revenue growth, MSD–HSD FCF growth, ~3% buyback yield, ~3% dividend yield" world — total return ~10–12% with low beta, which beats the broad market in any drawdown scenario.

## Bear case — technical
Symmetric, the version a software-side short-seller writes:

1. **The F-35 software moat is being legislated open.** Senate NDAA Section 135 [21] is the camel's nose. If avionics, sensors, and mission software become competitively bid, LMT loses a meaningful share of the most profitable part of the F-35 lifecycle (sustainment with embedded software margin). Base rate: Congress, when it actually attaches statutory language with deadlines, tends to win these fights over multi-year horizons.
2. **CCA economics break the platform-prime business model.** YFQ-42 and YFQ-44 unit cost ~$25–30M [19], roughly 1/3 of an F-35A. If the Air Force achieves the 1,000–2,000 unit total program goal at that price [19], the marginal new air-superiority dollar goes to autonomous attritable platforms designed by software-first companies. LMT's response (Vectis) flies in late 2027 [14], two years behind Anduril.
3. **Fixed-price contract risk is structurally rising.** $1.6B in classified-aero charges in Q2 2025 [22], plus Trump-era executive orders pushing fixed-price terms even on developmental work [22]. The DOGE-style cost-discipline regime makes defense primes look more like fixed-price construction contractors than asset-light IP holders.
4. **Software-defined entrants take the data layer.** Palantir already has a battlefield-prime award over RTX [17]; Anduril's Lattice runs as the integration plane in Army programs [17]. If "the OS of warfare" runs on Lattice or AIP, LMT becomes a parts supplier into someone else's stack — exactly the value-chain inversion that happened to PC OEMs after Microsoft/Intel.
5. **NGAD loss is a leading indicator, not a one-off.** Boeing's digital-twin-first approach to F-47 [2] suggests the Air Force is rewarding firms that have already made the digital-engineering transition. LMT's pre-prototype digital pipeline is real but evidently not best-in-class as judged by the customer.
6. **China timing risk runs both ways.** A J-36 IOC before F-47 [25] could either: (a) drive emergency buys of F-35 / F-22 upgrades (bull), or (b) be used by Congress as evidence that the prime model is too slow, accelerating contracts to non-traditionals (bear). Recent contract pattern (Anduril $20B, Palantir $10B) [17] favors (b).

## Market view check
17× forward earnings on a defense prime growing low-single-digit revenue is *cheap relative to RTX (27×) and NOC (~20×)* [7] but consistent with the technical reality: LMT is the prime that **lost** NGAD, **truncated** Block 4, and **took** $1.6B of classified-program charges in 2025, and is now in a period of margin repair under more punitive contracting terms. The 28% YTD bounce reflects the rearmament cycle and Golden Dome optionality, not the durability of the moat. The market appears to be pricing LMT as "high-quality cash compounder, slow-growing, modest moat erosion" — broadly consistent with my reading. Mispricing thesis: if you believe the F-35 software-opening fails to gain practical traction over 3–5 years, and the missile ramp executes, the stock is too cheap. If you believe Anduril/Palantir/Boeing each take a structural slice, today's 17× is appropriate, and there's no edge.

## 90-day falsifiers
Specific events to watch through ~Aug 2026:
- **Q2 2026 earnings (mid-July):** any new charge on the classified aero program (>$300M) or further F-35 delivery degradation versus the 2026 plan.
- **F-47 milestone disclosure** by Boeing/USAF on EMD progress; a slip of >12 months on first flight (2028 → 2029+) would meaningfully reduce LMT's NGAD-loss damage.
- **CCA Increment 2 RFP / down-select** decision — if LMT's Vectis is included in the Increment 2 competition rather than being externally categorized [14], that's a positive signal; if not, the Anduril/GA duopoly hardens.
- **NDAA conference markup** treatment of Section 135 (F-35 open mission systems) — adoption with binding deadlines is bearish; dilution or removal is bullish.
- **PAC-3 MSE rate progression** — quarterly delivery counts vs. the implied path to 2,000/yr by 2030 [13]. A miss in 2026 (i.e., <750 deliveries vs trajectory) signals execution risk on the munitions ramp.
- **Golden Dome architecture decisions** — any prime award (vs. small initial study contracts [8]) that goes to non-LMT (Anduril, Northrop) on a layer LMT considered captive.
- **Astris AI for Government bookings** — first publicly disclosed contract value would be the first hard data on whether Astris is real revenue or marketing [5].
- **F/A-XX (Navy 6th gen) decision** — any restart or down-select where LMT can compete is a free option not in current numbers.

## What I could not verify
- **Current short interest as % of float.** MarketBeat tracks it [15] but the value did not appear in retrievable search content; I avoid stating a number.
- **Specific GPU SKU and cluster size of LMT's DGX SuperPOD** (H100 vs B200 vs GB200), node count, and InfiniBand topology — not publicly disclosed beyond "DGX SuperPOD reference architecture" [6].
- **LMT's CoWoS / HBM exposure**, if any, in any sensor or mission-computer line — likely de minimis but I have no primary source.
- **Astris AI revenue or contract backlog** — no disclosed number, only positioning [4][5].
- **Detailed F-47 vs LMT down-select scoring** — sealed; my read is inferred from public statements about "best overall value" [2].
- **Project Carrera total spend to date** (only the $100M initial figure is public [12]).
- **PAC-3 MSE specific facility capacity by site** (Camden, Troy) — not in retrievable releases [13].
- **Net debt figure used for EV** — derived from recent 10-Q context, not pulled from a current balance sheet snapshot.

## Sources
[1] https://finance.yahoo.com/quote/LMT/ — retrieved 2026-05-10 — LMT close $506.51 on 2026-05-08, 52-week range $410.11–$692.00, market cap $116.78B
[2] https://breakingdefense.com/2025/03/boeing-wins-sixth-gen-fighter-ngad-air-force-lockheed-loss-trump-hegseth/ — retrieved 2026-05-10 — Boeing F-47 NGAD award, "best overall value" rationale, 185+ planned units
[3] https://news.lockheedmartin.com/2026-04-23-Lockheed-Martin-Reports-First-Quarter-2026-Financial-Results — retrieved 2026-05-10 — Q1 2026 results: $18.0B revenue, $6.44 EPS, $186.4B backlog, FY26 guide $77.5–80.0B / $29.35–30.25 EPS / $6.5–6.8B FCF; F-35 sustainment $130M favorable adjustment
[4] https://www.lockheedmartin.com/en-us/news/features/2025/astris-ai-lockheed-martin-trusted-innovation-new-industries.html — retrieved 2026-05-10 — Astris AI subsidiary positioning and MLOps stack
[5] https://news.lockheedmartin.com/2025-12-11-Astris-AI-for-Government-TM-Solutions-to-Accelerate-Secure-AI-Adoption-Across-the-Public-Sector — retrieved 2026-05-10 — Astris AI for Government launch
[6] https://www.nvidia.com/en-us/case-studies/lockheed-martin-ai-factory-with-dgx-superpod/ — retrieved 2026-05-10 — DGX SuperPOD deployment: 30+ models, 7,000 engineers, 1B+ tokens/week, on-prem classified posture
[7] https://stockanalysis.com/stocks/lmt/forecast/ and https://public.com/stocks/lmt/forecast-price-target — retrieved 2026-05-10 — Forward P/E ~17×, consensus PT range $520–$770 with median $665
[8] https://breakingdefense.com/2026/04/golden-dome-out-years-and-lots-of-missiles-details-of-trumps-1-5t-defense-budget-request/ — retrieved 2026-05-10 — Golden Dome $17.9B FY27, integrates THAAD/PAC-3/Aegis/GMD; 405 PAC-3, 62 THAAD interceptors planned
[9] https://techcrunch.com/2024/11/04/meta-says-its-making-its-llama-models-available-for-us-national-security-applications/ — retrieved 2026-05-10 — Meta national-security Llama partnership, LMT named partner
[10] https://www.gao.gov/products/gao-25-107632 and https://www.defensenews.com/air/2025/09/03/pentagon-cuts-back-f-35-upgrades-to-slow-schedule-slips-auditors/ — retrieved 2026-05-10 — Block 4 truncated, completion 2031, $6B over budget; TR-3 instability
[11] https://news.usni.org/2026/04/09/report-to-congress-on-u-s-armys-dark-eagle-hypersonic-weapon and https://www.overtdefense.com/2026/04/27/us-army-awards-2-7-billion-dark-eagle-hypersonic-weapon-contract/ — retrieved 2026-05-10 — Dark Eagle/LRHW first ops fielding 2026, $2.7B production contract April 2026, ramp 12→24/yr, NOC builds booster, LMT integrates
[12] https://www.twz.com/f-35s-speed-racer-drones-to-test-skunk-works-unmanned-teaming-vision and https://news.lockheedmartin.com/2025-12-04-Lockheed-Martin-Skunk-Works-R-Showcases-AI-Driven-Mission-Contingency-Management-on-an-Autonomous-UAV-Demonstration — retrieved 2026-05-10 — Project Carrera $100M autonomy investment; X-62A VISTA tactical AI testing
[13] https://news.lockheedmartin.com/2026-01-06-Lockheed-Martin-and-Department-of-War-Advance-Landmark-Acquisition-Transformation-to-Accelerate-PAC-3-R-MSE-Production and https://news.lockheedmartin.com/2026-04-10 — retrieved 2026-05-10 — PAC-3 MSE scale-up 600→2,000/yr by 2030, $4.7B UCA April 2026
[14] https://news.lockheedmartin.com/2025-09-21-Lockheed-Martin-Vectis-TM-Best-in-CCA-Class-Survivability and https://www.airandspaceforces.com/vectis-lockheed-skunk-works-cca/ — retrieved 2026-05-10 — Vectis Group-5 CCA reveal Sept 2025, target first flight late 2027, design-to-fly two years
[15] https://www.marketbeat.com/stocks/NYSE/LMT/short-interest/ — retrieved 2026-05-10 — short-interest tracking page (specific value not retrievable in returned content)
[16] https://www.tikr.com/blog/lockheed-martin-is-up-26-in-2026-is-lmt-still-worth-buying — retrieved 2026-05-10 — YTD return ~+26% as of early May 2026
[17] https://techcrunch.com/2026/03/14/us-army-announces-contract-with-anduril-worth-up-to-20b/ and https://www.bloomberg.com/graphics/2025-silicon-valley-targets-pentagon-budget/ — retrieved 2026-05-10 — Anduril $20B Army enterprise (March 2026); Palantir $10B Army enterprise (Aug 2025); Palantir prime over RTX
[18] https://theaviationist.com/2025/05/19/general-atomics-yfq-42a-revealed/ — retrieved 2026-05-10 — YFQ-42A General Atomics CCA reveal
[19] https://www.airandspaceforces.com/americas-first-unmanned-fighters-yfq-42-yfq-44/ and https://theaviationist.com/2025/10/31/anduril-yfq-44a-cca-first-flight/ — retrieved 2026-05-10 — YFQ-42A first flight Aug 27 2025, YFQ-44A first flight Oct 31 2025, ~$25–30M unit cost, 1,000–2,000 program goal
[20] https://en.wikipedia.org/wiki/Anduril_Industries — retrieved 2026-05-10 — Lattice platform technical positioning
[21] https://aerospaceglobalnews.com/news/f35-software-congress-lockheed-martin/ — retrieved 2026-05-10 — Senate NDAA Section 135 mandates open mission systems computing environment for F-35
[22] https://breakingdefense.com/2025/07/lockheed-records-1-6b-in-losses-mostly-linked-to-continued-strife-on-classified-aero-program/ and https://www.ainvest.com/news/lockheed-martin-stock-selloff-buying-opportunity-structural-shift-2506/ — retrieved 2026-05-10 — Q2 2025 $1.6B classified-program charge; fixed-price executive-order pressure
[23] https://www.airandspaceforces.com/northrop-sentinel-milestones-program-restructure/ and https://fas.org/publication/the-two-hundred-billion-dollar-boondoggle/ — retrieved 2026-05-10 — Sentinel ICBM cost $140.9B, +81% over baseline; restructure 2026
[24] https://en.wikipedia.org/wiki/Boeing_F-47 — retrieved 2026-05-10 — F-47 first flight 2028 target, Boeing digital twin pre-prototype
[25] https://www.armyrecognition.com/focus-analysis-conflicts/air/aviation-defence-industry-technology/china-accelerates-development-of-sixth-generation-fighters-j-36-j-50-ahead-of-us-next-gen-air-dominance — retrieved 2026-05-10 — J-36 / J-50 prototype flights, pre-2030 Chinese 6th-gen IOC ambition
[26] https://www.lockheedmartin.com/en-us/news/features/2026/AI-Fight-Club-Revolutionizing-AI-Development-for-National-Security.html — retrieved 2026-05-10 — internal AI development capability framing
[27] https://stockanalysis.com/stocks/lmt/ — retrieved 2026-05-10 — share count 230.56M, used to cross-check market cap derivation