# LNG — Cheniere Energy, Inc.

## Where this sits in the AI stack
Cheniere does not sit in the AI stack at all in the sense of silicon, packaging, fabric, or runtime. It sits one layer below the layer below: it is the largest U.S. operator of liquefied-natural-gas export infrastructure, taking Henry Hub-priced pipeline gas, liquefying it via Bechtel-built ConocoPhillips Optimized Cascade and Air Products C3MR midscale trains at Sabine Pass, LA and Corpus Christi, TX, and selling it FOB to Asian and European utilities under 15–20-year SPAs [1][2][8]. Its connection to AI is **second-derivative and contested**: U.S. natural-gas molecules are now the marginal fuel for ~35 GW of behind-the-meter hyperscaler generation expected by 2030 [12], and Cheniere's export tankers and Meta's gas turbines draw from the same Haynesville/Permian production base. The stock is an "AI infrastructure" name only insofar as one believes either (a) U.S. gas demand and Henry Hub pricing power benefits Cheniere's structurally hedged tolling margins, or (b) global LNG demand growth survives a domestic gas demand squeeze.

## Snapshot
- **Price:** $240.11 (2026-05-10 close) [3]
- **Market cap:** ~$52B (calculated from price × est. ~217M shares post-Q1 buyback; flagged as inference) [3][13]
- **52-week range:** $186.20 – $300.89 [3]
- **Forward P/E:** ~12.5× (on 2026 DCF/share guidance midpoint of ~$22 — Cheniere does not give EPS guidance and reported a Q1 GAAP loss from non-cash derivative marks, so EPS-based fwd P/E is misleading; DCF/share is the clean economic metric) [4][13]
- **EV / NTM revenue:** ~3.5× (EV ~$82B / 2026 revenue run-rate ~$23B from Q1 ×4) [3][4][7]
- **Consensus 12-month price target:** $294.87 (Strong Buy, 15-analyst median; +22.8% from price) [14]
- **YTD total return:** approximately −1% to −3% (inference: Q1 earnings reaction was −6.8% premarket from $246, stock had peaked at $300+ and pulled back; not directly verified for full YTD)
- **Short interest (% of float):** 2.16% as of 2026-04-15 (1.5 days to cover) [15]

## Moat — what it is physically made of
The Cheniere moat is **not technology**. Liquefaction is an off-the-shelf process — Optimized Cascade (Sabine Pass), C3MR/AP-X, and SMR variants are licensable from Air Products, Honeywell UOP, and ConocoPhillips, and Bechtel will build for anyone who pays [2][7]. The moat is a stack of **physical, regulatory, and contractual** assets that cannot be replicated on the same timeline:

1. **Brownfield permitting & port infrastructure.** Sabine Pass (LA) and Corpus Christi (TX) hold FERC siting orders from 2010–2015, predating the current 5–7-year FERC/DOE/USACE/USCG review cycle [9]. The Stage 5 expansion at Sabine Pass (Trains 7-9, ~15 mtpa) is going through FERC under brownfield review with draft EIS already issued [9] — a greenfield equivalent (CP2, Rio Grande, Commonwealth) faces full NEPA review, FTA/non-FTA DOE authorization, and litigation exposure. **Permit option value is the single most underappreciated asset.**

2. **Tolling contract structure.** ~85% of nameplate capacity through the mid-2030s is contracted under SPAs paying a **fixed liquefaction fee of $2.25–3.50/MMBtu plus 115% of Henry Hub** as a feedgas pass-through [11][2]. The 115% covers fuel consumed in liquefaction (~10% boil-off plus station fuel). This structurally insulates Cheniere from Henry Hub volatility — a critical point because **AI-driven domestic gas demand is the bear thesis on Henry Hub, but Cheniere is mostly indifferent to the level of HH itself** as long as the JKM/TTF spread covers buyer economics. Weighted-average contract life ~12 years [16]; 95% contracted on a 10-year forward look [11].

3. **Reliability track record vs. Venture Global.** Cheniere has delivered every cargo under SPA since first export in 2016 (no public arbitration losses). Venture Global lost a >$1B arbitration to BP and is being challenged by Shell over Calcasieu Pass cargoes diverted to spot during the 2022 price spike [17][18]. Combined claims against VG were $5.5B [17]. This is not an abstract reputation point — it is **why Equinor (1.75 mtpa from 2H26), JERA (1.0 mtpa from 2029-2050), KOSPO, ENN, PTT and Sinochem signed multi-decade FOB contracts with Cheniere even at higher fixed fees than VG's offered prices** [19][20].

4. **Bechtel relationship.** Bechtel has built every Cheniere train since 2013, ~$13B+ in cumulative EPC contracts, and is contracted for Stage 3 and the FID'd Trains 8&9 ($2.9B for 3+ mtpa, ~$967M/mtpa) [10]. Midscale trains hit substantial completion on schedule (T1 March 2025, T2 August 2025, T3 October 2025, T4 December 2025, T5 March 2026) [8]. Greenfield competitors like Rio Grande and CP2 are using Bechtel too but have to wait their turn behind Cheniere's order book.

5. **IPM upstream supply.** Long-term Integrated Production Marketing agreements with Tourmaline (140 kMMBtu/d, 15 yr) and ARC Resources (multiple 140 kMMBtu/d, 15 yr tranches indexed to JKM-minus rather than HH) [21][22] effectively shift price risk to upstream Canadian/Permian producers in exchange for a guaranteed long-term home for their gas. This is the closest thing to a vertical-integration moat in U.S. LNG.

**Durability assessment.** The brownfield permit moat is durable for 5+ years (the time required for any greenfield competitor to clear FERC + DOE + litigation). The tolling structure is durable as long as global buyers see counterparty diversity as a hedge — Qatar's $2/MMBtu cost edge does not displace Cheniere because Asian and European utilities will not concentrate >50% of supply in any single counterparty. Reliability advantage is durable until Venture Global resolves its arbitration overhang or builds a clean track record on Plaquemines deliveries (2026-2028 will tell us). Bechtel relationship is partial — Bechtel sells to all comers, but Cheniere's order priority is real.

## AI buildout bottleneck map
Cheniere's relationship to the canonical AI bottleneck list is mostly **competitive or indifferent**, not beneficiary, contrary to how some retail analysts frame it:

- **Power generation / grid interconnect.** *Competitor for molecules.* Hyperscalers are pivoting hard to behind-the-meter gas: Meta Hyperion at 7.46 GW, Meta El Paso with 800 mobile mini-turbines, Williams' 200 MW Socrates South for Meta in Ohio [23][24]. Data centers will draw ~0.5 Bcf/d of incremental gas in 2026 vs. LNG export growth of 3.7 Bcf/d [5] — but the ratio inverts toward parity by 2028-2030 as DC behind-the-meter scales to 35 GW [12]. Both pull from the same 120.8 Bcf/d U.S. production base [25].

- **Gas turbines (GE Vernova, Mitsubishi, Siemens Energy).** *Indirect supply-chain competitor.* GE Vernova has 80 GW of backlog stretching to 2029, sold out [26][27]. Cheniere uses gas turbines as compressor drivers in liquefaction (large frame 7/9 class). New Cheniere train builds compete with hyperscaler power plants for the same turbine slots and the same skilled electrical/mechanical contractor labor — pushing greenfield LNG project costs up 60%+ [28]. Brownfield expansions (Cheniere's case) are partially insulated; greenfield competitors (CP2, Rio Grande) feel this hardest.

- **HBM, CoWoS, optical interconnect.** *Indifferent.* No relevance.

- **Cooling.** *Indifferent.* LNG facilities use seawater-cooled mixed refrigerant cycles, unrelated to data center liquid cooling supply chains.

- **Henry Hub feedgas pricing.** *Structurally hedged but optically exposed.* If domestic AI gas demand pulls HH from $3.50 to $5+, Cheniere's tolling margin is unaffected (115% pass-through), but the **JKM/TTF − HH arbitrage compresses for marketing volumes**, which is the unhedged ~15% slice of capacity that drives variable margin. Q1 2026 saw spot LNG margins tighten as HH rose [29].

- **Permitting / FERC bandwidth.** *Beneficiary.* Cheniere's brownfield expansions clear in ~2 years vs. ~5-7 years greenfield. The Trump administration lifted the Biden non-FTA pause in January 2025 [30], unblocking competitor FIDs (CP2, Commonwealth, Rio Grande T4) — net negative for Cheniere's relative position, but expansion option value is now exercisable for Cheniere too.

**Net read: Cheniere is a beneficiary of the gas-as-AI-fuel narrative rhetorically, but a marginal competitor to it operationally.** The bull case requires both LNG export growth AND domestic AI gas growth to be supplied by Haynesville/Permian production rising 2 Bcf/d and 1.2 Bcf/d respectively in 2026 [25]. There is technical room for both, but it is tighter than the consensus view assumes.

## Competitive teardown

| Competitor | Axis of competition | Current evidence | Timeline to parity |
|---|---|---|---|
| **Venture Global (Plaquemines + Calcasieu)** | Capacity scale, modular construction speed | 32-train modular design; planned 58+ mtpa peak across complex; could exceed Cheniere by 2027 [6] | **Already at scale on capacity.** Reliability gap remains — BP arbitration lost Oct 2025, Shell appealing [17][18] |
| **QatarEnergy NFE/NFW (+ Golden Pass JV)** | Unit cost (lower per-mtpa lifting + liquefaction), proximity to Asian buyers | NFE Train 1 starts mid-2026, Qatar to 110 mtpa from 77; targeting 126-160 mtpa by 2027 incl. Golden Pass [31] | **Already has cost parity advantage.** But cannot saturate Atlantic basin demand; complementary not displacing |
| **Sempra (Port Arthur, Cameron)** | Brownfield Gulf Coast, similar tolling structure | Port Arthur Phase 2 with Bechtel EPC | 2-3 years behind Cheniere on expansion clock |
| **NextDecade (Rio Grande)** | Greenfield Texas | Train 4 FID in 2025; first cargo expected 2027 | Inferior balance sheet, no operating history |
| **Behind-the-meter onsite gas (Williams, etc.)** | Direct competition for U.S. gas molecules, not for LNG market | Meta Hyperion 7.46 GW; ~40 GW BTM announced [23][12] | Substitution risk for marginal U.S. gas, not for export contracts |

The honest read on Venture Global: on **capacity** they have already reached parity — Plaquemines Phase 1 and the planned doubling are real molecules. On **reliability** they are at least 24 months behind, and the BP arbitration loss is a documented operational deficiency, not a contract dispute. Long-term buyers price this. On **financing terms**, VG's modular approach delivered Calcasieu Pass at lower $/mtpa but with the side effects now litigated. **For new SPA signings 2026-2028, Cheniere should retain pricing power on the fixed fee component (likely $2.50-3.00/MMBtu) versus VG (likely $1.75-2.25/MMBtu) — and that 50-100bp spread on $/MMBtu is the moat in cash terms.**

The honest read on Qatar: NFE comes online into a market with substantial new U.S. supply already contracted. Qatari LNG is structurally lower-cost (associated gas, vertically integrated, sovereign cost of capital) but oversubscribed by long-term Asian utilities — it does not chase European spot. Cheniere's market is not the same market on a 5-year horizon.

## Bull case — technical
The bull case requires four technical conditions to hold:

1. **U.S. gas production grows fast enough** that Haynesville (+1.2 Bcf/d 2026, +1.6 Bcf/d 2027) and Permian (+2 Bcf/d to 27.8 Bcf/d) [25] can supply both LNG export growth (3.7 Bcf/d incremental 2026) AND data center BTM growth (0.5 Bcf/d 2026 to ~5+ Bcf/d by 2030). The rig-count and takeaway pipeline math works if HH stays in $3.50-5.00 range.

2. **The JKM/TTF − HH spread sustains $4-8/MMBtu** [29], leaving Cheniere's 15% unhedged marketing volume profitable and supporting the marginal SPA price for new contracting (Stage 5, CC Trains 8&9 startups).

3. **Brownfield permit advantage holds** — i.e., Stage 5 FERC final EIS lands late 2026 enabling FID in 2027 [9], CC Trains 8&9 substantially complete by end of 2027 on Bechtel schedule [7][10].

4. **VG and Qatar do not collapse the long-term contract market** — i.e., Asian utilities continue diversifying counterparties rather than concentrating in Qatar at the lowest fee.

If all four hold, run-rate DCF reaches the company's stated $30/share target by 2030 [13]. At 12-15× DCF that's a $360-450 stock — call it a 50-87% upside over 4-5 years before dividends and buybacks.

**Base rate caveat on technology displacement at this stage of the cycle:** Energy infrastructure with 15-year contracts and brownfield permits has historically held its moat through commodity cycles far better than upstream E&P (e.g., midstream MLPs through 2014-2020). Closer analogs: pipeline operators after the shale revolution maintained pricing power despite price volatility. Less applicable: solar/wind manufacturing where Chinese cost dumping displaced incumbents over 5 years. The LNG analog is more pipeline-like than panel-like.

## Bear case — technical
The bear case a sophisticated short would write:

1. **Henry Hub structurally repriced higher by 2027-2028.** As behind-the-meter gas demand scales to 5+ Bcf/d and incremental gas-fired generation comes online faster than Haynesville/Permian can ramp (which requires more Permian gas takeaway pipelines that face FERC delays of their own), HH moves to $5-6 sustained. Cheniere's tolling margin is hedged on contracted volumes, but **115% × HH means Cheniere's customers see their landed cost rise** — and SPAs have force majeure / commercial reasonableness clauses that have been litigated (see VG cases). More importantly, **at HH > $5, the JKM/TTF spread compresses** because Asia/Europe substitute coal or curtail, leaving the marketing tail unprofitable and crushing variable EBITDA.

2. **Capacity glut by 2027-2028.** Qatar +33 mtpa, VG Plaquemines full +27 mtpa, CP2 +20 mtpa, Rio Grande +18 mtpa, Cheniere CC Stage 3 +10 mtpa, Golden Pass +18 mtpa, Cameron +6 mtpa. That's ~130 mtpa added by 2028 against current ~480 mtpa global market — the largest single-window addition in LNG history. Spot prices crash, marginal SPA fees compress, and Cheniere's Stage 5 FID gets delayed past 2027 [9].

3. **Hyperscaler nuclear bypasses gas entirely.** Google-Kairos 500 MW (online 2030), Amazon-X-Energy, Microsoft-Constellation Three Mile Island restart all undermine the "gas is the only fast option" narrative on a 5-year view [32]. SMRs at $6,400-12,700/kW capex are 5-10× gas at $1,290/kW [32], so this is a slow attrition not a quick switch — but it caps the gas demand TAM.

4. **Hyperscaler capex digestion.** If Q3 2026 hyperscaler capex guidance is cut by >10% sequentially, the entire energy/power AI complex compresses multiples.

5. **Insider selling pattern.** EVPs sold $18M+ in late March 2026 [33] — not a thesis-killer but worth noting against the Strong Buy consensus.

The bear case does not require all five — any two of (1)+(2) is sufficient to compress the multiple from 12× DCF to 8× DCF, implying $160-200 fair value.

## Market view check
At $240.11 with consensus PT of $295 (Strong Buy, 21 buys / 2 holds / 0 sells) [14], the market is **pricing Cheniere as a high-quality contracted infrastructure name with mid-cycle multiples**, not as an AI-levered growth name. EV/NTM revenue of ~3.5× and ~12.5× forward DCF are consistent with utility-like infrastructure, not the 20-30× one sees in actual AI-stack names. **The market is implicitly skeptical of the second-derivative AI thesis** — and is correct to be. Cheniere's actual technical reality is "tolling infrastructure with a 15-year contract book and brownfield permit options," not "AI power play." The stock has pulled back ~20% from $300 highs on Q1 derivative-mark optics and capacity-glut anxiety; the technical case for a re-rating to $295 requires Stage 5 FID clarity (late 2026) and confirmed parity slip from VG's reliability issues, neither of which is yet in the price.

The mispricing, if any, is **not in valuation** but in **categorization**: the name is being priced as old-energy infrastructure, when its growth optionality (Stage 5 + CC8&9 + IPM upstream) plus its insulation from Henry Hub volatility makes it closer to a contracted-cash-flow growth name. Fair value is closer to consensus than the current price, but the asymmetry is modest, not dramatic.

## 90-day falsifiers
- **FERC final EIS for Sabine Pass Stage 5** (expected late 2026; any movement on schedule disclosed in next 90 days is material) [9]
- **Q2 2026 earnings** (~early August): watch DCF run-rate, marketing margin tightening, Stage 3 final train commissioning, any update on VG-style derivative mark methodology
- **Qatar NFE Train 1 first cargo** (mid-2026): if delayed, near-term JKM premium holds; if on schedule, marginal SPA pricing pressure begins
- **Henry Hub realized vs. JKM/TTF spread**: track weekly. If HH moves above $4.50 sustained while JKM stays below $11, marketing-volume contribution to Q3 EBITDA cracks
- **Shell appeal ruling on VG arbitration** (NY Supreme Court): a Shell win further damages VG counterparty trust, pushes new SPA pricing toward Cheniere
- **GE Vernova / Siemens Q2 turbine backlog updates**: extension into 2030 implies tighter EPC labor and parts for Cheniere's Stage 5 timeline
- **Hyperscaler Q2 capex guidance** (Microsoft, Meta, Google, Amazon late July/early August): a >10% sequential cut would compress all AI-power names including LNG by association
- **CP2 / Commonwealth construction milestones**: actual progress (or delays) at greenfield competitors changes the 2028 capacity glut math directly

## What I could not verify
- Exact share count post Q1 2026 buybacks (used ~217M as inference from $535M Q1 spend at avg ~$245)
- Precise YTD 2026 total return (sources gave point prices and 1-year change, not Jan 1 base)
- The actual proportion of SPA portfolio with HH-pass-through vs. JKM-indexed IPM vs. fully fixed — likely ~70% HH-linked, ~15-20% JKM-linked, ~10-15% Cheniere Marketing variable, but exact mix not publicly broken out
- Stage 5 expected fixed liquefaction fee on new SPA signings — not yet disclosed
- Whether any Cheniere SPA counterparty has exercised an MAC or commercial reasonableness clause (historically none, but unverified for 2025-2026)
- Quantified GE Vernova frame-7/9 compressor allocation to Cheniere vs. competitors
- Specific U.S. Permian gas takeaway constraints that would force HH discounts to JKM/TTF in 2027-2028 — qualitative consensus but no clean Bcf/d gating numbers
- Whether Cheniere has any direct PPA-style or behind-the-meter relationship with a hyperscaler (no public evidence found, but absence not proof)
- The methodology behind the $5.4B non-cash derivative loss in Q1 2026 GAAP results — IPM agreements appear to be the source but the disclosure detail is buried in 10-Q

## Sources
[1] https://lngir.cheniere.com/company-information — retrieved 2026-05-10 — Cheniere operating overview, Sabine Pass and Corpus Christi as the two facilities
[2] https://liquefiednaturalgas.org/market/pricing/ — retrieved 2026-05-10 — LNG SPA pricing structure benchmarks (HH, TTF, JKM)
[3] https://finance.yahoo.com/quote/LNG/ — retrieved 2026-05-10 — LNG May 10 2026 close $240.11, 52-week range $186.20-$300.89
[4] https://stockanalysis.com/stocks/lng/statistics/ — retrieved 2026-05-10 — Cheniere EV $84.39B, TTM revenue $19.49B, P/E 10.52, EV/Rev 3.3×
[5] https://www.bicmagazine.com/industry/natgas-lng/lng-exports-data-centers-natural-gas/ — retrieved 2026-05-10 — Data centers 0.5 Bcf/d incremental 2026 vs LNG +3.7 Bcf/d
[6] https://naturalgasintel.com/news/venture-global-upscales-plaquemines-lng-expansion-40-as-export-wave-pushes-into-2030s/ — retrieved 2026-05-10 — Plaquemines 32 trains, 58+ mtpa peak; could surpass Cheniere
[7] https://lngir.cheniere.com/news-events/press-releases/detail/321/cheniere-announces-positive-final-investment-decision-on — retrieved 2026-05-10 — CC Trains 8&9 FID at $2.9B for 3+ mtpa
[8] https://oilauthority.com/news/us-lng-exports-record-cheniere-corpus-christi-train-5-stage-4-2026 — retrieved 2026-05-10 — CC Stage 3 train commissioning timeline T1-T5
[9] https://lngprime.com/americas/us-ferc-issues-draft-eis-for-chenieres-sabine-pass-expansion-project/182358/ — retrieved 2026-05-10 — Sabine Pass Stage 5 draft EIS issued; FERC final expected late 2026, FID 2027
[10] https://www.bechtel.com/projects/corpus-christi-liquefaction-project/ — retrieved 2026-05-10 — Bechtel-Cheniere EPC relationship since 2013, ~$13B+ contracts
[11] https://timera-energy.com/blog/breaking-down-us-lng-contract-value/ — retrieved 2026-05-10 — Cheniere fixed liquefaction fee $2.25-3.50/MMBtu plus 115% Henry Hub
[12] https://newsletter.semianalysis.com/p/how-ai-labs-are-solving-the-power — retrieved 2026-05-10 — 35 GW BTM gas generation expected by 2030
[13] https://lngir.cheniere.com/news-events/press-releases/detail/339/cheniere-reports-first-quarter-2026-results-and-raises-full — retrieved 2026-05-10 — Q1 2026 results, raised guidance to $7.25-7.75B EBITDA, $4.75-5.25B DCF, $30/share long-term DCF target
[14] https://stockanalysis.com/stocks/lng/forecast/ — retrieved 2026-05-10 — Consensus PT $294.87, Strong Buy, 21 buy / 2 hold / 0 sell
[15] https://www.marketbeat.com/stocks/NYSE/LNG/short-interest/ — retrieved 2026-05-10 — Short interest 2.16% of float, 1.5 days to cover
[16] https://lngir.cheniere.com/news-events/press-releases/detail/339/ — retrieved 2026-05-10 — 85% contracted through mid-2030s, ~12 yr WAL
[17] https://energynow.com/2025/11/how-bp-won-its-1-billion-plus-case-against-venture-global/ — retrieved 2026-05-10 — BP wins $1B+ arbitration against VG; combined claims $5.5B
[18] https://www.insurancejournal.com/news/east/2025/11/12/847145.htm — retrieved 2026-05-10 — Shell appealing VG arbitration loss in NY Supreme Court
[19] https://lngir.cheniere.com/news-events/press-releases/detail/249/ — retrieved 2026-05-10 — Equinor 1.75 mtpa SPA from 2H 2026
[20] https://lngir.cheniere.com/news-events/press-releases/detail/323/cheniere-and-jera-sign-long-term-lng-sale-and-purchase — retrieved 2026-05-10 — JERA 1.0 mtpa SPA from 2029-2050
[21] https://lngir.cheniere.com/news-events/press-releases/detail/224/cheniere-corpus-christi-stage-iii-and-tourmaline-sign — retrieved 2026-05-10 — Tourmaline 140 kMMBtu/d 15-yr IPM, JKM-indexed
[22] https://lngir.cheniere.com/news-events/press-releases/detail/289/cheniere-announces-long-term-integrated-production — retrieved 2026-05-10 — ARC Resources IPM agreements with Stage 3 and Stage 5
[23] https://www.power-eng.com/onsite-power/onsite-gas-turbines-reciprocating-engines-to-power-meta-data-center/ — retrieved 2026-05-10 — Meta Williams Socrates South 200 MW BTM in Ohio; Meta Hyperion 7.46 GW
[24] https://www.tomshardware.com/tech-industry/artificial-intelligence/u-s-electricity-grid-stretches-thin-as-data-centers-rush-to-turn-on-onsite-generators — retrieved 2026-05-10 — Meta El Paso 800 mobile mini-turbines; xAI etc. BTM expansion
[25] https://www.eia.gov/todayinenergy/detail.php?id=67166 — retrieved 2026-05-10 — US gas production 120.8 Bcf/d 2026, 122.3 Bcf/d 2027; Haynesville +1.2 Bcf/d 2026; Permian to 27.8 Bcf/d
[26] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — GE Vernova 80 GW backlog stretching to 2029
[27] https://www.bloomberg.com/features/2025-bottlenecks-gas-turbines/ — retrieved 2026-05-10 — Mitsubishi/Siemens turbine backlogs past 2029
[28] https://techcrunch.com/2026/04/27/data-center-demand-drives-66-surge-in-natural-gas-power-plant-costs/ — retrieved 2026-05-10 — CCGT power plant costs +66% in 2 years, 23% longer to build
[29] https://www.argusmedia.com/en/news-and-insights/latest-market-news/2762492-us-lng-margins-tighten-on-higher-henry-hub-prices — retrieved 2026-05-10 — US LNG marketing margins tightening on higher HH; spread $4.11/MMBtu vs $5.37/$20.13 prior years
[30] https://lngprime.com/lng-terminals/trump-lifts-pause-on-non-fta-lng-export-approvals/138345/ — retrieved 2026-05-10 — Trump executive order Jan 2025 lifted Biden non-FTA LNG export pause
[31] https://www.lngindustry.com/liquid-natural-gas/22052025/qatarenergy-to-start-nfe-train-by-mid-2026/ — retrieved 2026-05-10 — Qatar NFE first train mid-2026, expansion to 110 mtpa, 126+ mtpa by 2027
[32] https://www.deloitte.com/us/en/insights/industry/power-and-utilities/nuclear-energy-powering-data-centers.html — retrieved 2026-05-10 — SMR capex $6,417-12,681/kW vs gas $1,290/kW; commercial SMRs late 2020s/2030
[33] https://www.tipranks.com/news/insider-trading/cheniere-energy-insiders-quietly-unload-a-massive-chunk-of-stock-insider-trading-news — retrieved 2026-05-10 — Cheniere EVPs sold $18M+ in March 2026 (Markowitz, Feygin, Botta)