# GNRC — Generac Holdings Inc.

## Where this sits in the AI stack
GNRC sells **emergency/standby diesel and natural gas reciprocating generator sets**, almost entirely **outside the IT fence** of an AI data center. It is at the **power-resilience layer**, not at silicon, packaging, networking, or runtime. Within that layer it operates two distinct businesses: (a) residential standby (~half of revenue, weather/outage-cyclical) and (b) C&I, where the new revenue pocket is **2.25–3.25 MW gen-sets** sold as backup power islands to hyperscale and colocation operators (also "drawing-board" 4 MW units). [3][4] Generac does *not* play in scale-up fabric, HBM, CoWoS, or training software — it sells the spinning iron that turns on when the substation fails or, increasingly, when grid interconnect simply hasn't been built yet.

## Snapshot
- **Price:** $269.41 (2026-05-08 close) [7]
- **Market cap:** $15.86B [7]
- **52-week range:** $117.22 – $272.40 (stock is sitting against its 52-week high; +132% over the trailing 52 weeks) [7]
- **Forward P/E:** ~24.3× (vs trailing P/E 84×; the gap reflects expected step-up in data-center C&I earnings) [first-search/Public.com]; one screen marks Forward P/E "n/a" pending consensus refresh [7]
- **EV / TTM revenue:** 3.93× (EV $16.34B on $4.21B TTM revenue; net debt ~$1.04B) [7][24]
- **EV / TTM EBITDA:** ~32× — ~79% above 10-year median of 16.7× [24]
- **Consensus 12-month price target:** $244.63 (implied **−9.2%** from spot); range $197–$305, 17 analyst "Buy" consensus, but stock has overshot the median PT [7]
- **YTD total return:** **+24.5%** (inference from year-end 2025 ~$216 close to $269.41; not directly quoted)
- **Short interest (% of float):** 5.50% [7][8]

## Moat — what it is physically made of
Generac's data-center moat is genuinely narrow and almost entirely **supply-chain access**, not technology. Decomposed:

1. **Baudouin engine access (the actual asymmetry).** The Texas air permit for the Stargate Abilene campus lists 28 backup gen-sets at 2.8 MW each (≈78 MW), all powered by **Baudouin M55** engines — a French brand owned by China's Weichai Group. Baudouin's U.S. data-center distribution funnel is sparse: only **Generac and IGSA Power** (a small Mexican packager, ~2,000 units/yr) are credibly placing them. TD Cowen has characterized Generac as having "exclusive U.S. access" for data-center applications; Generac itself describes "exclusivity in multi-year U.S. engine supply agreements," but the company has declined to disclose the contract scope. [3][5][6] The economic value of this access is **delivery speed**: Hunterbrook's reporting puts Baudouin-equipped Generac sets at ~30-week lead time vs. ~107 weeks for Cat 3500-series / Cummins QSK95. [5] That is the moat. It is a **lead-time arbitrage**, not a technology gap — and Weichai/Baudouin is a single Chinese supplier whose loyalty is contractual and almost certainly renegotiable.

2. **Sussex (WI) capacity ahead of demand.** Generac is scaling Sussex assembly to **>$1B of large-MW gen-set capacity by Q4 2026**, with management openly discussing $2–3B as the next step. Cummins is only just expanding QSK95 output 30% at its Fridley, MN site (announced Feb 2026). For 18–24 months, Generac may be **less capacity-constrained than Cat or Cummins**. [3][20]

3. **Enercon (closed April 1, 2026, $122M).** Bought to internalize **switchgear and gen-set enclosures**, the second-stage packaging step that has been the actual industry bottleneck after the engine itself. This is the lowest-glamour part of the bill of materials and the highest-leverage on lead time. [1][3]

4. **Industrial dealer ownership (30–35%).** Atypical for the industry; gives Generac direct service capability at sites where Cat and Cummins rely on third-party dealer networks. [3] Matters less for hyperscalers (who self-service) than for colo and edge.

What it is **not**: there is no software moat, no proprietary IP on combustion or aftertreatment, no CUDA-equivalent. The Tier 4 aftertreatment packages are vendor-supplied. There is no fabric, no compiler, no kernel — none of the stickier categories of moat that protect NVDA or even AVGO. **Durability assessment:** the Baudouin advantage is real and difficult to replicate inside 18 months, but it is a contractual rather than structural moat. The capacity advantage compresses as Cummins's Fridley expansion and Cat's expanded foundry come online in 2027.

## AI buildout bottleneck map
Mapping GNRC against the actual gating constraints of the next 24 months:

| Bottleneck | 24-mo state | GNRC position |
|---|---|---|
| **HBM3e/HBM4 supply** | SK hynix/Micron capacity-bound | Indifferent |
| **CoWoS-L allocation** | TSMC adding lines; still gated | Indifferent |
| **Optical interconnect (CPO, 1.6T)** | Coherent/Marvell/Lumentum constrained | Indifferent |
| **Liquid cooling at >100 kW/rack** | Vertiv/Boyd ramping CDUs | Indifferent |
| **Grid interconnect queue** | PJM warns 49 GW US generation shortfall by 2028; queues stretch 7+ years [27][29] | **Strong indirect beneficiary** — drives the behind-the-meter pivot |
| **Gas turbine backlog** | GE Vernova 80 GW backlog into 2029; reservations sold through 2030 by end-2026; 5–7-yr wait times [10][11][28] | **Indirect beneficiary** — turbine scarcity pushes hyperscalers toward reciprocating gas/diesel sets at the bridge-power and backup layers |
| **Reciprocating gen-set capacity** | Cat/Cummins backlogs >100 weeks for >2 MW units [5][20] | **Direct beneficiary and supplier** — this is GNRC's exact lane |
| **Switchgear/MV breakers** | ABB/Eaton/Schneider lead times 70+ weeks | Now an internal capability via Enercon [1] |
| **Electrical contractor labor** | Acutely constrained in NoVA, TX, Phoenix | Exposed (deployment-rate risk) |
| **Kernel/compiler talent** | Frontier-lab problem | Indifferent |

The investable insight is in the middle of the table: the grid-interconnect crisis is **forcing the prime-power buildout into the same physical equipment categories Generac sells**. But note: at the **prime-power** layer, the dominant suppliers are GE Vernova aeroderivative turbines and VoltaGrid/INNIO 25 MW reciprocating skids (e.g., VoltaGrid + INNIO 2.3 GW order to Stargate is **prime**, not backup, power [12][13][15]). Generac plays **backup** (~50–60-week life-of-asset reserve role), not prime — a lower MW-per-site share of the wallet but a much larger absolute unit count per site.

## Competitive teardown
Five players control ~63–72% of the data-center gen-set market: **Caterpillar, Cummins, MTU/Rolls-Royce, Generac, Kohler**. [17][18] Caterpillar and Cummins historically own the **>2 MW segment**, where the dollars are. Specific axes:

- **Engine bench depth.** Cat (3500/3516B/C175 series) and Cummins (QSK60/QSK95) have decades of fielded reliability data at >2 MW with hyperscaler approvals; Generac's competitive 2.8 MW unit is built around Baudouin's M55 — newer to North American data-center service. Hyperscaler vendor-approval cycles take 18+ months and **GNRC is in the final stages, not over the line**, on two hyperscalers as of Q1 2026. [3]
- **Lead time.** GNRC's structural advantage — claimed 50–60 weeks against industry 70–90, and ~30 weeks for the Baudouin sets vs. 107+ for Cat/Cummins flagship units. [3][5] This is the **only axis** on which GNRC currently leads on technical merit.
- **Scale of credible delivery.** Cummins Power Systems Q1 2026 revenue $2.0B, +19% YoY, 29.5% EBITDA margin [21][22] — bigger than Generac's *entire* C&I segment ($510M [3]). Cat's record backlog is $63B across the company [23]. Generac targeting "$1B by Q4 2026" puts it **roughly 25% the size of Cummins Power Systems today** even after the planned ramp.
- **Capacity to absorb hyperscaler demand.** Cummins's Fridley expansion (+30% QSK95) arrives in 2027 [20]; Cat is acquiring distribution and adding foundry capacity. Generac's window before parity-on-availability is **2026 through ~Q2 2027**.
- **Behind-the-meter prime power (different category).** VoltaGrid (INNIO Jenbacher gas engines, 25 MW skids) is the most credible prime-power vendor; Stargate's 2.3 GW prime order went to VoltaGrid. [13][15] GE Vernova handled an additional ~1 GW aeroderivative turbine slice. **Generac is not in this category at scale today.** It announced a behind-the-meter partnership with EPC Power, but no comparable order-book disclosure.

The honest read: Generac has a real **18–24-month execution window** on backup at large-MW with Baudouin-driven lead times. After that, Cummins's QSK95 capacity catches up and Cat's distribution arms re-take the high-margin hyperscaler accounts. Generac's task is to **convert pilot relationships into approved-vendor master agreements before the window closes**.

## Bull case — technical
Conditions that have to hold:
1. **Hyperscaler vendor approval closes** for both pilot customers, and the **$600M non-binding NTP from one hyperscaler converts to PO** for 2027 delivery. [3] This is the closest discrete technical milestone with binary outcome.
2. **Cummins's QSK95 expansion slips past Q4 2027.** Industrial capacity adds with that complexity routinely run 6–12 months late; if it does, GNRC's lead-time advantage holds two extra quarters of inflated pricing.
3. **Baudouin supply remains exclusive-enough.** No new U.S. packager wins 2.8 MW Baudouin shelf space at the hyperscalers; Weichai does not redirect M55 allocation to a competing packager.
4. **Switchgear remains the chokepoint** — meaning Enercon delivers asymmetric value.
5. **Behind-the-meter remains additive to backup demand, not a substitute.** Each behind-the-meter prime-power site still needs N+1 emergency standby at ~2–3 MW units. Most permits suggest this is true (Stargate has VoltaGrid prime *and* 28 Baudouin backups [5][15]).
6. **Residential normalizes.** Outage activity rebounds to long-term baseline; +10% residential growth in 2026 management guide is met. [9]

Financial path if all six hold: C&I reaches $2.5B run-rate by 2027 (mgmt target: 10–15% of a $15B large-MW TAM = $1.5–$2.25B at the high end [3]); blended EBITDA margins move from 18% to ~20%; the multiple holds at ~30× EV/EBITDA given the new "AI infrastructure" framing → stock works to $310–$340 range, +15–25% from spot. **Base rate caveat:** specialized hardware suppliers in mid-cycle infrastructure booms (Vertiv 2023, Eaton 2023, Powell 2024) typically see 18–24 months of multiple expansion past peak technical advantage before re-rating. GNRC is at month ~14 of that cycle.

## Bear case — technical
Conditions for the moat to erode or demand to disappoint:
1. **Cummins QSK95 capacity addition lands on schedule (Q2–Q3 2027).** [20] Lead times converge; hyperscalers default to incumbents; Generac wins fewer multi-year master agreements than the $700M backlog implies.
2. **Cat formalizes a competing Baudouin channel.** Cat already has European Baudouin service relationships; if it secures direct U.S. distribution, Generac's lead-time advantage compresses by ~12 months. (I could not confirm a specific December 2025 Cat-Baudouin Europe acquisition — one source referenced it, but it does not appear in primary press release coverage; treat as unverified rumor, not fact.)
3. **The $600M NTP is non-binding** and could be redirected, deferred, or trimmed if the hyperscaler renegotiates. The actual PO has not been received as of Q1 2026. [3]
4. **Prime-power gas plants substitute backup density.** If hyperscalers move to N+0 backup (running spare prime-power capacity as standby), gen-set unit counts per site fall 30–50%. The current Stargate permit doesn't support this yet but the engineering trend points there.
5. **Residential continues to disappoint.** Q4 2025 residential −23% YoY [9]; +10% recovery in 2026 guide assumes a return to baseline outage activity that is weather-dependent and not under management control. Residential is still ~50% of consolidated revenue; even a great C&I year underperforms if residential misses.
6. **Multiple compression on data-center-tinged industrials.** GNRC is trading at ~32× EV/EBITDA against a 10-yr median of ~17× [24] — most of the re-rating is already in. CMI trades at 23× forward P/E with 29.5% Power Systems EBITDA margin and 4× the data-center exposure in absolute dollars [21]; GNRC at parity multiple on a smaller, less-proven business is the obvious short pair.

Bear path: residential stays flat, C&I grows 25% but converts to lower margins as Generac discounts to win hyperscaler approvals, EBITDA misses; multiple compresses to 20× EV/EBITDA; stock to $170–$190, **−30% to −37% from spot**.

## Market view check
GNRC is trading at $269 against a $245 consensus PT — the **stock has run past the sell-side**, which is the cleanest signal that the data-center thesis is fully priced. Forward P/E of ~24× is in line with Cummins (~23×) despite GNRC having (a) smaller absolute data-center exposure, (b) lower Power Systems-equivalent margins (~18–20% vs Cummins's 29.5%), (c) half the company in cyclical residential, and (d) a moat that is contractual (Baudouin) rather than structural (engine IP, dealer network depth, hyperscaler track record). The market is apparently believing that Generac's **lead-time arbitrage converts into multi-year hyperscaler exclusivity** — a bigger claim than the disclosed $600M non-binding NTP and "final stages of vendor approval" actually support. The most defensible view is that GNRC has earned a re-rating but at current price/PT premium, **the asymmetric trade is short GNRC vs. long CMI** (same theme, better moat, better margins, cheaper).

## 90-day falsifiers
- **Q2 2026 earnings (early August 2026):** does C&I backlog cross $1B and does at least one of the two hyperscaler vendor approvals convert to a binding master supply agreement? Either outcome materially repositions the thesis.
- **Conversion of the $600M NTP to firm PO**, disclosed via 8-K or earnings commentary. Non-conversion or downward revision = bear case validated.
- **Cummins QSK95 capacity-expansion update** at CMI Q2 earnings: confirmation of on-schedule Q2 2027 delivery shortens GNRC's window.
- **MLPerf-equivalent for data-center power** doesn't exist, but watch for hyperscaler-disclosed PUE/EUE figures from Stargate Abilene's first operational quarter — would confirm or refute whether the 78 MW of Baudouin backup is genuinely fielded vs. permit-only.
- **Sussex (WI) capacity milestone**: site visits/photos suggesting the $1B-capacity-by-Q4 timeline is slipping.
- **Any 8-K or 13D activity around Weichai/Baudouin** (e.g., Cat or Cummins announcing a direct supply or distribution agreement).
- **PJM capacity auction June 2026 clearing prices** — if they decline materially, behind-the-meter urgency softens and the prime-power buildout pace slows, dragging the backup-power tail with it.

## What I could not verify
- The **specific contractual terms of Generac's Baudouin supply agreement** — duration, exclusivity scope (U.S. only? data-center applications only?), volume commitments, MFN clauses. The Q1 2026 call uses "exclusivity in multi-year U.S. engine supply agreements" without specifying engine make, and Generac has declined to confirm to journalists. [3][5]
- The claim that **Caterpillar acquired Weichai Baudouin's European distribution network for $85M in December 2025** — surfaced in one secondary source but is not present in Cat's primary press releases or Baudouin/Weichai communications I could access. Mark as unverified rumor.
- **Per-site unit economics** for a Generac 2.8 MW Baudouin set delivered to a hyperscaler — ASP, gross margin, install timeline. No primary disclosure.
- **Daihatsu or Mitsubishi role** in Generac's data-center lineup at the >2 MW level. Generac uses Mitsubishi in mobile and some industrial products, but the data-center 2.25–3.25 MW range appears to be Baudouin-centric. Could not independently confirm engine breakdown across SKUs.
- **Whether hyperscalers consider Generac an N+1 substitute for Cat/Cummins or an additive second source.** Sell-side framing assumes substitution; the more conservative read (additive only) would compress Generac's TAM share.
- **Q1 2026 EPS forward-consensus number** for clean Forward P/E math — one source quotes 24.35× implying ~$11 forward EPS, another shows "n/a." [first WebSearch][7]

## Sources
[1] https://www.stocktitan.net/news/GNRC/generac-signs-agreement-to-acquire-enercon-accelerating-growth-in-v2arw4jj50m3.html — retrieved 2026-05-10 — Enercon acquisition and switchgear/data-center context
[2] https://www.themarketsdaily.com/2026/03/28/generac-investor-day-new-segments-data-center-push-and-2028-targets-with-2026-guidance-intact.html — retrieved 2026-05-10 — March 2026 Investor Day backlog and 2028 targets
[3] https://www.fool.com/earnings/call-transcripts/2026/04/29/generac-gnrc-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q1 2026 transcript: $700M backlog, $600M NTP, vendor approval status, "exclusivity in multi-year U.S. engine supply agreements," Sussex capacity, lead-time positioning
[4] https://www.datacenterfrontier.com/energy/article/55281190/generac-sharpens-focus-on-data-center-power-with-scalable-diesel-and-natural-gas-generators — retrieved 2026-05-10 — 2.25–3.25 MW diesel/gas product lineup and lead-time framing
[5] https://hntrbrk.com/generac-stargate/ — retrieved 2026-05-10 — Hunterbrook investigation: 28 Baudouin M55 2.8 MW units in Stargate Abilene permit, ~30 vs 107 week lead time
[6] https://www.tipranks.com/news/the-fly/hunterbrook-says-stargate-running-on-niche-baudouin-generators-tied-to-generac-thefly-news — retrieved 2026-05-10 — secondary confirmation of Hunterbrook findings
[7] https://stockanalysis.com/stocks/gnrc/ — retrieved 2026-05-10 — price $269.41, 52-wk $117.22–$272.40, market cap $15.86B, EV/Rev 3.93, consensus PT $244.63, trailing P/E 84.18
[8] https://www.marketbeat.com/stocks/NYSE/GNRC/short-interest/ — retrieved 2026-05-10 — short interest 5.27–5.50% of float
[9] https://investors.generac.com/news-releases/news-release-details/generac-reports-first-quarter-2026-results — retrieved 2026-05-10 — Q1 2026 press release: residential $552M flat, C&I $510M +28%, raised 2026 guidance
[10] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — GE Vernova 80 GW backlog into 2029
[11] https://www.power-eng.com/gas/turbines/data-centers-drive-record-surge-in-ge-vernova-power-equipment-orders-as-turbine-slots-tighten-through-2030/ — retrieved 2026-05-10 — gas turbine reservations sold to 2030 by end-2026
[12] https://www.spglobal.com/market-intelligence/en/news-insights/articles/2025/10/data-center-developers-turn-to-distributed-behind-the-meter-power-94174247 — retrieved 2026-05-10 — 56 GW behind-the-meter pipeline across 46 data centers
[13] https://www.powermag.com/engine-power-plants-surge-as-data-centers-drive-unprecedented-demand/ — retrieved 2026-05-10 — VoltaGrid 20–25 MW reciprocating skids; INNIO 2.3 GW Stargate prime-power award
[14] https://www.powermag.com/data-centers-are-turning-to-gas-generators-for-prime-power-to-eliminate-long-lead-times-for-grid-connections/ — retrieved 2026-05-10 — bridge-power thesis driving gas reciprocating engine demand
[15] https://www.power-eng.com/onsite-power/onsite-gas-turbines-reciprocating-engines-to-power-meta-data-center/ — retrieved 2026-05-10 — Meta and Stargate onsite gas configuration
[16] https://www.datacenterdynamics.com/en/analysis/welcome-to-gas-land-how-natural-gas-is-powering-the-us-ai-boom/ — retrieved 2026-05-10 — gas-powered AI data-center buildout context
[17] https://www.mordorintelligence.com/industry-reports/data-center-generator-market — retrieved 2026-05-10 — top-5 share Caterpillar/Cummins/MTU/Generac/Kohler ~63–72%, Cat & Cummins dominant >2 MW segment
[18] https://www.businesswire.com/news/home/20240729386893/en/Global-Data-Center-Generator-Market-Outlook-Forecast-2024-2029-with-ABB-Caterpillar-Cummins-Generac-Power-Systems-HITEC-Power-Protection-KOHLER-Rolls-Royce-INNIO-and-Yanmar-Dominating---ResearchAndMarkets.com — retrieved 2026-05-10 — market sizing $10.49B and player set
[19] https://newsletter.semianalysis.com/p/how-ai-labs-are-solving-the-power — retrieved 2026-05-10 — SemiAnalysis Dec 2025 onsite-gas deep dive: gas + battery hybrids, islanded data centers
[20] https://www.cummins.com/generators/qsk95 (plus PowerEng Cummins Fridley coverage) — retrieved 2026-05-10 — QSK95 3.5 MW spec; Fridley $150M expansion for +30% capacity
[21] https://www.stocktitan.net/sec-filings/CMI/8-k-cummins-inc-reports-material-event-6c85f4b4da84.html — retrieved 2026-05-10 — Cummins Q1 2026: Power Systems $2.0B +19%, 29.5% EBITDA margin
[22] https://investor.cummins.com/news/detail/694/cummins-delivered-strong-operating-results-and-returned — retrieved 2026-05-10 — Cummins raises 2026 guidance, data-center demand call-out
[23] https://www.ttnews.com/articles/cummins-caterpillar-data — retrieved 2026-05-10 — UBS: Cat and Cummins generator revenue to nearly double in three years
[24] https://www.gurufocus.com/term/enterprise-value-to-ebitda/GNRC — retrieved 2026-05-10 — GNRC EV/EBITDA 29.93–31.98 vs 10-yr median 16.68
[25] https://www.tikr.com/blog/generac-surges-stock-41-in-2026-heres-why-it-is-set-to-deliver-more-upside — retrieved 2026-05-10 — performance and bull-case narrative
[26] https://rmi.org/pjms-speed-to-power-problem-and-how-to-fix-it/ — retrieved 2026-05-10 — PJM interconnect queue dynamics
[27] https://introl.com/blog/pjm-grid-crisis-6gw-shortfall-data-center-power-2027 — retrieved 2026-05-10 — PJM 6 GW shortfall projection for 2027
[28] https://rbnenergy.com/daily-posts/blog/backlog-natural-gas-turbines-expands-surging-demand-supply-constraints — retrieved 2026-05-10 — turbine wait times 5–7 years across GE/Siemens/Mitsubishi
[29] https://enkiai.com/ai-market-intelligence/us-grid-congestion-2026-pjms-data-center-crisis — retrieved 2026-05-10 — PJM capacity prices and 49 GW shortfall by 2028
[30] https://www.gurufocus.com/news/8643238/generac-gnrc-powers-openais-texas-data-center-with-unique-generators — retrieved 2026-05-10 — Stargate/Baudouin context, secondary
[31] https://grist.org/energy/data-centers-natural-gas-methane-behind-the-meter/ — retrieved 2026-05-10 — behind-the-meter natural-gas data-center context