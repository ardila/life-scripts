I have enough material. Writing the dossier now.

```
# CNP — CenterPoint Energy, Inc.

## Where this sits in the AI stack
CNP is a **wires-and-pipes utility**, not a tech company. In ERCOT (Texas) it
operates **Houston Electric**, a regulated transmission & distribution utility
that owns ~3,700 miles of transmission and ~50,000 miles of distribution serving
2.2M meters in Harris County and the surrounding 5,000 sq mi — and explicitly
**no generation**, since ERCOT's deregulated structure separates wires from
generation [1]. It also runs natural-gas LDCs in Indiana, Minnesota, Ohio, and
Texas, plus a small legacy electric generation & distribution business in
southwest Indiana (ex-Vectren) [1]. Its position in the AI stack is upstream of
silicon entirely: it is one of the **physical-layer bottleneck owners** that
hyperscalers must transit to energize a Houston-area data center. It earns on
rate base × authorized ROE; it does not take commodity power price risk.

## Snapshot
- **Price:** $42.24 (2026-05-07 close) [2]
- **Market cap:** ~$27.9B [3]
- **52-week range:** $35.46 – $44.47 [4]
- **Forward P/E:** 22.1× on FY26 non-GAAP EPS guidance midpoint $1.90 [4][5]
- **EV / NTM revenue:** ~5.3× (EV ~$52B incl. ~$24B net debt vs. NTM revenue ~$9.7B; inferred from FFO/Debt of 12.5% disclosed in Q1'26 call [6] and consensus revenue trajectory)
- **Consensus 12-month price target:** $42.89 (range $38–$47); high outlier Jefferies $49 [7]
- **YTD total return:** ~+15% (inferred from ~$36–37 close at YE25 implied by 52-wk range [4])
- **Short interest (% of float):** n/a — utility names typically <2%, not material; specific figure not located in time

## Moat — what it is physically made of
Calling CNP's moat "regulatory" understates how *physical* it is.

1. **The CCN franchise.** Houston Electric holds an exclusive Certificate of
   Convenience & Necessity for T&D in a defined geographic footprint awarded by
   the PUCT. No competitor can build parallel poles and wires in Harris County;
   even a new entrant would have to overbuild ~50,000 miles of secondary
   distribution at replacement cost (utility plant typically trades at ~1.8–2.2×
   net book value when M&A clears, which itself is a fraction of greenfield
   replacement). This is durable on a 50–100 year cadence: copper and aluminum
   distribution has a service life measured in decades, and the ROW (right of
   way) easements were assembled across 80 years of Houston growth.
2. **Interconnection chokepoint.** Under Texas SB6 (signed June 2025) and the
   PUCT draft rule 16 TAC §25.194 (March 2026), every new ≥75 MW load in ERCOT
   must execute a transmission screening study with the TDU and post security;
   the TDU collects the study fee, controls the milestone schedule, and
   ultimately decides what gets energized when [8][9]. CenterPoint, not the
   hyperscaler, is the **counterparty that has to physically connect them.**
3. **Rate-base monetization mechanism.** Houston Electric's last rate case
   (2024 settlement) set an authorized ROE of **10.30% on a 52.49% equity
   layer** [10]. The Texas system also uses DCRF/TCRF (distribution & transmission
   cost recovery factor) trackers between rate cases, which let CNP earn on new
   capex faster than a traditional rate-case cadence allows. This converts
   spending into earnings with relatively short regulatory lag.
4. **In-flight load contracts as a moat.** Q1'26: "firmly committed" large-load
   pipeline of **12.2 GW** (up from 7.5 GW a quarter earlier), of which 3.2 GW
   is ERCOT-approved and 8 GW is expected to be energized by 2029 [11]. These
   are not vaporware — they require posted security under SB6. The contractual
   pipeline is itself a moat against forecast risk: hyperscalers who walk forfeit
   80% of posted security to the TSP rate base [8].

What is **not** a moat:
- **Engineering excellence.** Hurricane Beryl (July 2024) caused a 2.26M-customer
  outage and an unfavorable PUCT investigative report; CNP withdrew its pending
  rate case and entered the 2024 settlement at a $50M annual revenue *reduction*
  through ~2029 [12][10]. The operational reputation is a liability, not a moat.
- **765 kV inter-regional backbone.** ERCOT's $33B 765 kV STEP plan, including
  the $9.4B Eastern Backbone project, is led primarily by Oncor and AEP Texas;
  CenterPoint is a named participant on the Eastern Backbone but the dominant
  intellectual property and operational experience with 765 kV in North America
  sits at AEP (operates ~2,200 mi of 765 kV across 6 states) [13][14]. CNP
  captures **load-serving** capex from this, but not the headline EHV build.

## AI buildout bottleneck map
Ranking bottlenecks on the 2026–2028 horizon, with CNP's specific exposure:

| Bottleneck | CNP role | Note |
|---|---|---|
| **Gas-turbine slots (GE Vernova HRSG/F-class)** | Indifferent — does not own ERCOT generation | GEV backlog ~80 GW stretching into 2029 [15]; this is the binding constraint on Texas data-center *energization*, but accrues to Vistra, Constellation, NRG, and BTM developers, not CNP |
| **High-voltage transmission (345/765 kV)** | Beneficiary, indirect | $9.4B Eastern Backbone ISD 2030–2032 [13]; CNP participates but Oncor/AEP capture more |
| **Local distribution capacity** | **Direct beneficiary** | CNP's $45.5B (of $65.5B) is electric; "extension cost" recovery from interconnecting loads is a clean rate-base growth lever |
| **Substation transformers, switchgear** | Customer (exposed to supply) | Lead times 18–36 months industry-wide; not a financial constraint but a delivery risk |
| **Cooling/permitting/water** | Indifferent | Hyperscaler problem |
| **ERCOT congestion/curtailment** | Indifferent for revenue, exposed for reliability optics | CNP wires earn whether or not generators clear; reputation risk if grid stresses cause outages |
| **SB6 large-load forecast haircut** | **Exposed** | PUCT/ERCOT have flagged that speculative interconnection requests are 5–10× actual buildout [16][17]; CNP's 12.2 GW is mostly post-SB6 but could still compress |
| **Behind-the-meter co-location** | **Exposed** | SB6 makes net-metering co-location require PUCT 60-day approval, which is friction but not prohibition; under the common-ownership exemption (registered jointly by Jan 1 2025) some BTM proceeds outside the rules [18] |
| **Liquid cooling >100 kW/rack** | Indifferent | Hyperscaler/colo problem |
| **Capital / FFO-to-debt** | **Constraint owner** | CNP's own FFO/Debt was 12.5% at Q1'26 vs Moody's downgrade threshold ~13% — only ~150 bps cushion [6] |

The honest read: **CNP is principally a beneficiary of the local-distribution
and resiliency capex lane**, less so the headline EHV build, and the *binding*
bottleneck to actual GW-energization in Texas is generation, not wires.

## Competitive teardown
CNP doesn't have "competitors" inside its CCN — that's the moat. The relevant
competitive question is: **what alternatives exist for a hyperscaler that wants
Texas capacity, and how do those alternatives affect CNP's rate-base trajectory?**

1. **Oncor (private, Sempra+majority).** ~50% larger T&D footprint than Houston
   Electric, covering DFW/Permian/Central Texas — the area where the bulk of
   765 kV STEP is going [13][19]. Hyperscalers picking DFW (Stargate-style sites)
   sit on Oncor wires, not CNP. **Already at parity or ahead** on inter-regional
   transmission and on regulatory standing post-Beryl (Oncor was not the storm
   underperformer).
2. **AEP Texas / AEP (NASDAQ: AEP).** Operates the only meaningful base of
   existing 765 kV experience in the U.S. The 2025 RTP and Eastern Backbone
   selection picked 765 kV partly *because* AEP can execute it [14]. CNP's
   participation on Eastern Backbone is a co-build, not a lead.
3. **Vistra (NYSE: VST), Constellation (CEG), NRG.** These are **vertically
   adjacent, not competitive** — they own the generation CNP doesn't. Vistra's
   $4.7B Cogentrix acquisition (Jan 2026, +5.5 GW gas) and Constellation's
   $16.4B Calpine deal are the IPP plays on the same demand backdrop [20][21].
   The fork: if hyperscalers strike PPAs with these IPPs and *also* take
   ERCOT-grid power through Houston Electric, CNP wins. If they co-locate
   behind the meter at IPP plants (more common outside ERCOT given FERC tariff
   asymmetry, but SB6 now constrains this in Texas), CNP loses the load.
4. **Self-build BTM (Crusoe + GE Vernova 19-turbine order, etc.) [15].**
   This is the genuinely disruptive case. SB6's 75-MW disclosure rule and the
   PUCT's 60-day approval window are designed precisely to slow this, but it is
   not banned, and the Jan-1-2025 common-ownership exemption is a loophole.
5. **Other regulated peers (D, AEP, ED, ETR, EIX, SO).** Stock-market comp set,
   not operational competitor. The relevant axis is **whose service territory is
   getting the data-center load** — and Texas (CNP, Oncor, AEP-TX), Virginia
   (Dominion), Ohio (AEP), and the Carolinas (Duke) are the four winners.

Where CNP is *clearly ahead*: its 12.2 GW committed pipeline is the largest
disclosed metro-area load growth figure for any single U.S. TDU on a peak-load
percentage basis (~50% by 2029, doubling to ~42 GW by mid-2030s vs. ~22 GW
historical peak [22][11]). Dominion's data-center pipeline is bigger in absolute
GW; CNP's is bigger as a *share of starting peak*.

## Bull case — technical
For the stock to outperform from $42, the following technical conditions need
to hold:

1. **The 12.2 GW commitments must convert.** PUCT 16 TAC §25.194 finalizes in
   mid-2026 with the 20%/80% security-forfeiture structure intact, which both
   filters speculation *and* monetizes any drops to ratepayer benefit (reducing
   load-pull risk on CNP). Conversion rate of 60%+ would imply ~7 GW genuine
   energizations — enough to keep the 11% rate-base growth track [9].
2. **The Eastern Backbone 765 kV project stays on its 2030–2032 ISD** [13].
   Even though Oncor/AEP lead, the project relieves Houston import constraints
   and lets the 8 GW data-center pipeline actually run.
3. **The Beryl-era regulatory penalty cycle stays at the $50M-annual order of
   magnitude** [10]. Texas PUCT politics are the swing variable; the $25k/day
   service-quality penalty cap is *small* relative to a $65B capex plan, and
   the SRP $3.2B settlement already discounted [23].
4. **FFO/Debt holds above ~12% through the heaviest capex years (2026–2028)** —
   helped by the AMT cash refund (≈$1B equivalent of capacity, per
   management [6]) and continued attractive convertible/securitized issuance.
5. **Base rate on tech displacement of T&D incumbents.** Historical CCN
   displacement rate in U.S. regulated utilities since 1935: effectively zero
   absent state legislative action. Even ERCOT deregulation in 2002 preserved
   T&D as monopoly. Closest analog is the Calif. PCIA / community-choice
   carve-outs, which compressed margin but didn't displace wires ownership.
   The bull case is consistent with this base rate.

Financial outcome if all five hold: 8–9% EPS CAGR through 2028 [24], dividend
growth at the same clip, modest multiple stability around 22×; HSD–LDD total
return.

## Bear case — technical
Written as the short would write it:

1. **SB6 forecast haircut is brutal.** PUCT and ERCOT staff have publicly
   stated speculative requests are 5–10× actual builds [16][17]. If the 12.2 GW
   "firmly committed" figure cracks to 4–6 GW post-disclosure cleanup, the
   capex incremental opportunity collapses, and the long-term EPS guide moves
   from "high end of 7–9%" toward the low end. The market is currently paying a
   ~22× forward multiple for the high end.
2. **Co-location & BTM ecosystem outflanks the wires model.** GEV's 80 GW
   turbine backlog is being burned, in part, by buyers building campus power on
   the customer side of the meter [15]. Crusoe's 19-turbine order is the
   prototype [15]. If hyperscalers respond to ERCOT congestion by building
   gigawatt-class on-site gas+battery campuses, CNP gets the interconnection
   study fee but not the GW-scale distribution rate base. SB6 is friction, not
   prohibition, and the Jan-1-2025 common-ownership exemption is a clear
   carve-out [18].
3. **FFO/Debt is the silent screw turning.** $65.5B capex vs. ~$28B equity
   market cap, with only 150 bps cushion to Moody's Baa1 (Houston Electric) /
   Baa2 (holdco) thresholds [6][25]. A downgrade would raise the WACC across
   the rate base build and the company would either (a) issue dilutive equity,
   or (b) slow capex, or (c) face credit-driven valuation compression. Many bull
   models assume rate-base growth happens without any of these.
4. **Operational re-indictment.** A second major hurricane outage event would
   reopen the political file Beryl already opened; Texas PUCT has explicitly
   asked the legislature for higher penalty caps [26]. Probability is low on
   any given year but the conditional outcome is severe.
5. **Generation bottleneck physics break the buildout.** If GEV slots don't
   free up until 2029–2030, the 8 GW pipeline timeline slips, and so does the
   load that CNP capex was sized against. The capex precedes the revenue by
   18–36 months in distribution interconnection; if the load isn't actually
   energized on schedule, CNP carries the financing cost without the offsetting
   rate revenue.

Bear base rate: in past utility load-growth booms (1960s nuclear, 1990s gas,
2000s wind in Texas) actual load growth has chronically come in **below**
utility forecasts. The 5–10× speculative ratio cited by ERCOT staff is
consistent with this prior.

## Market view check
At $42.24 the stock trades at 22.1× FY26 EPS, well above the regulated-utility
ten-year median (~17–18×), with a 2.1% yield well below the peer median (~3.5%).
The consensus PT of $42.89 implies essentially no upside — the buy-side has
**already priced in execution of the 7–9% long-term EPS CAGR**. What the market
appears to believe: (a) the 12.2 GW pipeline largely converts, (b) the $65.5B
capex earns at ~10.3% allowed ROE with minimal regulatory lag, (c) the equity
financing burden is manageable. What it appears *not* to be pricing: (a) a
material SB6 haircut on the load forecast, (b) a Baa1→Baa2 downgrade at
Houston Electric, (c) a second Beryl-class operational failure. The asymmetry
is **negatively skewed at this multiple** — the bull case is "guidance"; the
bear cases all involve idiosyncratic but non-trivial tail events.

## 90-day falsifiers
Things you can actually check between now and ~early August 2026:

1. **PUCT final adoption of 16 TAC §25.194.** Comments closed April 17, 2026 [8].
   A final rule that *softens* the security-forfeiture structure (e.g., 50/50
   instead of 20/80, longer cure periods) is bullish for the speculative-pipeline
   conversion rate. A *stricter* final rule with a lower-than-75 MW threshold is
   bearish for the 12.2 GW figure.
2. **Q2 2026 large-load update (late July).** Does "firmly committed" rise from
   12.2 GW or compress? A flat-to-down number after a 63% one-quarter jump is a
   yellow flag.
3. **ERCOT approval of the remaining ~9 GW.** Management said it would file
   "within weeks" of the Q1'26 call [11]. Monitor ERCOT's monthly large-load
   integration reports for project-by-project approvals.
4. **Moody's / S&P credit action on Houston Electric or CNP holdco.** Any
   negative outlook revision is a direct read on FFO/Debt; any affirmation
   meaningfully de-risks the financing.
5. **Final order on the 2026–2028 Systemwide Resiliency Plan.** PUCT approval of
   the $3.2B settlement [23] confirms ~$1B/year of incremental securitizable
   capex starting H2 2026.
6. **Texas hurricane season (peak Aug–Oct).** Operational performance is the
   single biggest non-financial swing factor.
7. **Hyperscaler announcements naming Houston Electric service territory** vs.
   announcements naming Oncor/AEP-TX — directly reads who is winning the load.

## What I could not verify
- The exact net debt figure at 3/31/2026; EV and EV/sales above are inferred
  from FFO/Debt 12.5% [6] and revenue [27]. A current 10-Q figure would refine.
- Short interest as % of float — utility names rarely have informative short
  data and I did not locate a current number.
- The **fraction of CNP's $65.5B plan formally tied to load-growth-driven
  capex** vs. resiliency, base T&D refresh, and gas LDC; management gives the
  electric/gas split ($45.5B / $19.3B [24]) but not a clean load-growth carve-out.
- Whether CNP has signed any direct large-load service agreements with named
  hyperscalers (Microsoft, Meta, Oracle, Anthropic), or if the 12.2 GW is
  disclosed only at the aggregate level.
- How the PUCT's draft rule will treat *parallel* interconnection requests by
  the same parent — this is the most direct mechanism for haircutting the
  12.2 GW number, and the final text matters more than the draft [8].
- The exact YE25 close used for YTD return; reported as approximate from
  52-week range.

## Sources
[1] https://en.wikipedia.org/wiki/CenterPoint_Energy — retrieved 2026-05-10 — establishes T&D-only structure in ERCOT plus gas LDC footprint in IN/MN/OH/TX and Indiana electric legacy
[2] https://www.marketbeat.com/instant-alerts/filing-principal-financial-group-inc-has-3691-million-holdings-in-centerpoint-energy-inc-cnp-2026-05-10/ — retrieved 2026-05-10 — May 7, 2026 close at $42.24
[3] https://www.macrotrends.net/stocks/charts/CNP/centerpoint-energy/market-cap — retrieved 2026-05-10 — market cap ~$27.9B Q1 2026
[4] https://finance.yahoo.com/quote/CNP/key-statistics/ — retrieved 2026-05-10 — 52-week range, forward P/E 22.09×, forward dividend $0.92
[5] https://seekingalpha.com/news/4578875-centerpoint-reiterates-2026-non-gaap-eps-1_89-1_91-as-houston-electric-firmly-committed-load — retrieved 2026-05-10 — 2026 non-GAAP EPS guidance $1.89–$1.91
[6] https://www.fool.com/earnings/call-transcripts/2026/04/23/centerpoint-cnp-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1'26 FFO/Debt 12.5%, 150 bps Moody's cushion, AMT refund commentary
[7] https://www.wallstreetzen.com/stocks/us/nyse/cnp/stock-forecast — retrieved 2026-05-10 — consensus PT $42.89; range $38–$47
[8] https://www.gtlaw.com/en/insights/2026/3/texas-senate-bill-6-update-what-data-centers-large-load-customers-should-know-about-proposed-interconnection-standards — retrieved 2026-05-10 — PUCT draft rule 16 TAC §25.194, 75 MW threshold, $100k study fee, 20/80 security split, April 17 comment deadline
[9] https://www.bracewell.com/resources/texas-senate-bill-6-ushers-in-major-overhaul-of-large-load-interconnection-and-grid-access-rules/ — retrieved 2026-05-10 — SB6 statutory framework and PUCT charge to minimize stranded infra
[10] https://www.prnewswire.com/news-releases/centerpoint-energy-reaches-settlement-agreement-with-parties-to-lower-bills-for-customers-in-its-2024-houston-electric-rate-case-302363889.html — retrieved 2026-05-10 — Houston Electric 2024 rate case settlement, ROE 10.30%, 52.49% equity layer, –$50M annual revenue
[11] https://www.businesswire.com/news/home/20260422904150/en/CenterPoint-Energy-reports-strong-Q1-2026-results — retrieved 2026-05-10 — 12.2 GW committed load, 3.2 GW ERCOT-approved, 8 GW expected energized by 2029
[12] https://www.texastribune.org/2024/07/25/texas-power-grid-puc-centerpoint-hurricane-beryl/ — retrieved 2026-05-10 — PUCT investigative report on Hurricane Beryl response
[13] https://www.ercot.com/files/docs/2025/12/01/14.1-25RPG025-AEP-Texas-CPS-Energy-Oncor-and-CNP-Texas-765-kV-STEP-Eastern-Backbone-Project.pdf — retrieved 2026-05-10 — 765 kV STEP Eastern Backbone $9.4B, 1,108.8 miles, 2,500 MW import capacity, ISD 2030–2032
[14] https://www.zeroemissiongrid.com/insights-press-zeg-blog/ercot-765-kv-infrastructure/ — retrieved 2026-05-10 — AEP 2,200 mi 765 kV operating experience; Texas 765 kV rationale
[15] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — GEV 80 GW backlog stretching to 2029; Crusoe 19-turbine order
[16] https://insideclimatenews.org/news/10102025/texas-grid-operators-and-regulators-iron-out-new-rules-for-data-centers/ — retrieved 2026-05-10 — ERCOT staff acknowledgment that speculative interconnection 5–10× real
[17] https://www.utilitydive.com/news/texas-data-center-buildout-stranded-costs-SB6/753656/ — retrieved 2026-05-10 — stranded-cost dynamics under SB6
[18] https://www.weil.com/-/media/files/pdfs/2025/july/weil-energy-alert--senate-bill-6-reforms-interconnection-and-colocation-rules-for-data-centers-and-o.pdf — retrieved 2026-05-10 — SB6 net-metering and common-ownership Jan-1-2025 exemption
[19] https://www.oncor.com/content/dam/oncorwww/documents/about-us/transmission-system/Oncor%20STEP%20One-Pager%20QA%20-%20Feb2026.pdf — retrieved 2026-05-10 — Oncor STEP scope
[20] https://markets.financialcontent.com/stocks/article/marketminute-2026-1-28-power-play-vistras-47-billion-cogentrix-acquisition-signals-new-era-of-ai-driven-energy-m-and-a — retrieved 2026-05-10 — Vistra Cogentrix $4.7B / 5.5 GW
[21] https://markets.financialcontent.com/stocks/article/marketminute-2026-3-24-the-power-behind-the-pulse-constellation-energys-164-billion-calpine-acquisition-solidifies-the-ai-energy-backbone — retrieved 2026-05-10 — Constellation–Calpine $16.4B
[22] https://www.utilitydive.com/news/centerpoint-peak-load-to-jump-50-by-2029-2-years-early/812542/ — retrieved 2026-05-10 — 50% peak growth by 2029; doubling to ~42 GW by mid-2030s
[23] https://www.prnewswire.com/news-releases/centerpoint-energy-reaches-settlement-agreement-on-landmark-systemwide-resiliency-plan-302481612.html — retrieved 2026-05-10 — $3.2B 2026–2028 SRP settlement, $240M cost deferment to H2 2029
[24] https://investors.centerpointenergy.com/news-releases/news-release-details/centerpoint-energy-announces-record-10-year-plan-invest-65 — retrieved 2026-05-10 — $65.5B 10-yr plan, $45.5B electric / $19.3B gas, 7–9% EPS CAGR through 2035, 11%+ rate-base growth through 2030
[25] https://www.moodys.com/research/Moodys-downgrades-CenterPoint-Energy-Houston-Electric-to-Baa1-from-A3--PR_417381 — retrieved 2026-05-10 — Moody's Baa1 Houston Electric / Baa2 holdco
[26] https://www.houstonpublicmedia.org/articles/news/energy-environment/2024/11/21/506768/hurricane-beryl-texas-puc-investigation-centerpoint-legislative-regulatory-fixes/ — retrieved 2026-05-10 — PUCT recommendation to legislature on higher penalty caps post-Beryl
[27] https://www.macrotrends.net/stocks/charts/CNP/centerpoint-energy/revenue — retrieved 2026-05-10 — TTM revenue ~$9.1B through Sept 2025
```