I have sufficient data. Writing the dossier now.

# AES — The AES Corporation (NYSE: AES)

## Where this sits in the AI stack
AES is a power generator and regulated utility — the layer underneath the substation, transformer, and PDU that feeds a hyperscale data hall. It physically operates ~32 GW of generation across utility-scale solar, onshore wind, 4-hour battery storage, combined-cycle gas, two Caribbean LNG regas terminals, and two regulated US electric utilities (AES Indiana ~3.9 GW, AES Ohio T&D)[1][2][7]. It is workload-indifferent — what it sells is firmed MWh under 15- to 20-year PPAs, mostly to AI/cloud hyperscalers (Microsoft, Google, Meta, Amazon)[3][4][8]. AES does not touch silicon, packaging, networking, or runtime; it is the substrate beneath those, and is itself currently mid-deal of a $15.00/share take-private led by BlackRock's GIP and EQT[5][6].

## Snapshot
- **Price:** $14.28 (close 2026-05-08; May 10 is Sunday)[10]
- **Market cap:** $10.2B[10]
- **52-week range:** $9.46 – $17.65[10]
- **Forward P/E:** 6.2× (on FY2026 consensus EPS $2.29)[12]
- **EV / NTM revenue:** ~2.7× (deal EV $33.4B / ~$12.5B revenue)[5][9]
- **Consensus 12-month price target:** $17.08 (avg of 15 analysts)[19] — but stale; bounded above by the $15.00 cash deal
- **YTD total return:** approximately −1% price; ~+1% incl. dividend[16]
- **Short interest (% of float):** n/a — could not source a clean 2026-dated figure; deal-arb names typically run elevated short interest as the long side closes the spread
- **Net debt / 2025E EBITDA:** ~$22.7B / ~$2.75B = ~8.3×[5][9][22]
- **Adjusted EBITDA 2025 guidance:** $2,650–$2,850M[22]
- **Dividend yield:** 4.9% ($0.70 annualized)[16]

## Moat — what it is physically made of
For a power generator, "moat" is not silicon or kernels; decompose honestly:

**1. Land + interconnection queue positions (durable, ~5–7 yrs).** The binding scarce asset in US power right now is not panels or turbines — it is a studied, signed Generator Interconnection Agreement at a node with available transmission. ERCOT had >2,000 active interconnection requests as of May 2025; PJM, MISO, and NYISO have suspension rates of 46–79% late in study[15]. AES has spent 20+ years sequencing studies and acquiring sites; the 12+ GW backlog with 5+ GW already in construction[3][22] is partly a measure of this queue inventory. A new entrant cannot replicate this in <5 years at any price. This is the *real* moat.

**2. Long-dated PPA cash flows (durable, contractual).** ~12 GW of signed PPAs, of which ~9 GW are direct hyperscaler offtake[8][3], typically 15–20 yr tenor with investment-grade counterparties (MSFT, GOOG, META, AMZN). PPAs include time-of-delivery shaping; AES bundles 4-hour batteries (e.g., 110 MWac solar + 55 MW/4-hr storage with Microsoft in California[4]) to firm noon solar into evening load. Pricing has reset higher: LevelTen index +9% YoY in 2025, CAISO solar+storage now $70–$85/MWh[14]. Mark-to-market replacement value of the backlog is materially above contracted rates — this is part of what GIP/EQT are buying.

**3. Regulated rate-base monopolies (durable, regulatory).** AES Indiana (1.3M customers) and AES Ohio together support double-digit rate-base growth into 2027, with the Petersburg coal-to-gas conversion ($1.1B Pike County investment) coming online in two tranches: Unit 1 commercial June 2026, Unit 2 December 2026[1][20][7]. These are textbook regulated returns at allowed ROEs of ~9.5–10%, essentially uncorrelated to the AI thesis but providing baseload cash flow stability.

**4. LNG regas terminals in the Caribbean (specialized, hard to replicate).** Dominican Republic and Panama assets with long-term industrial offtake[1] — this is a discrete moat asset of the Energy Infrastructure SBU, but it has no AI thesis attached.

**5. Tax-credit monetization machinery (transient).** $1.5B of US tax credits monetized in recent reporting periods[3]. OBBBA (signed July 4, 2025) terminates new PTC/ITC starts for solar/wind after construction commencement past July 4, 2026, and prohibits transfers to FEOCs[18]. AES's ability to monetize future credits compresses sharply in 2027+.

**What is NOT a moat:** no proprietary technology — panels are First Solar/Trina/JinkoSolar, batteries are Tesla/Fluence/CATL, turbines are Vestas/GE/Siemens. There is no code, no patents, no developer ecosystem. Project execution capability matters but is not unique to AES (NextEra, Brookfield, Clearway, Engie all do this). AES's moat is real but is essentially: *queue positions × signed contracts × regulated rate base*. That is exactly what infrastructure private equity buys at 11–12× EBITDA, and that is what the deal is paying.

## AI buildout bottleneck map
Specific gating constraints over the next 24 months and where AES sits:

- **Power generation capacity** — *beneficiary/supplier.* IEA projects global DC electricity demand to ~945 TWh by 2030 (>2× current); EPRI projects US AI load at 50+ GW by 2030[17]. AES backlog is ~5% of EPRI 2030 US AI load. Direct positive exposure.
- **Gas turbines (large frame, H-class)** — *exposed customer, not supplier.* GE Vernova, Siemens Energy, Mitsubishi sold out through 2029–2030; reservations expected fully booked through 2030 by end-2026[11]. Combined-cycle CapEx has roughly doubled in 15 months from ~$1,000/kW to $2,000–$2,500/kW[11]. AES's Petersburg coal-to-gas conversion is contracted with Babcock & Wilcox and an existing turbine slot[20]; future gas additions are exposed to this bottleneck and pricing.
- **Grid interconnect queue** — *constraint owner.* AES owns positions in PJM/MISO/ERCOT/CAISO. AES Clean Energy publicly opposed MISO's proposed 50% peak-load queue cap[15], suggesting they see queue inventory as a competitive advantage worth defending.
- **Transmission build-out** — *exposed.* IEA warns up to 20% of planned DC projects could be delayed without transmission investment[17]. Most acute in PJM "speed to power" problem. AES PPAs are typically structured at the busbar; transmission delays push COD and IRR.
- **HBM / CoWoS-L / advanced packaging / optical interconnect** — *indifferent.* No exposure.
- **Liquid cooling, electrical contractors at >100 kW/rack** — *indifferent at the generation layer.*
- **Behind-the-meter colocation regulation** — *modestly negative.* FERC's December 2025 order on PJM colocation (Talen-AWS Susquehanna lineage)[21] tightens the rules for selling power directly to a co-sited DC, channeling more demand back through grid-connected PPAs, which is AES's product. But the ruling is messy; the three-year transition through Dec 2028 creates ambiguity.
- **OBBBA / FEOC tax-credit risk** — *negative.* Compresses the PTC/ITC window and disqualifies projects with Chinese cell/module content[18]. Most exposed are post-2027 builds in the backlog.

## Competitive teardown
Specific axes, current evidence:

- **NextEra Energy (NEE).** ~30 GW total renewables backlog; ~10.5 GW serving tech/DC customers when buildout is included[13]. ~2.5x bigger than AES on like-for-like renewables backlog. NEE has lower cost of equity (~8% vs ~11%), better credit rating (A-/Baa1 vs BBB-/Baa3), bigger ITC/PTC monetization throughput. On the technical axis of *new PPA wins per quarter*, NEE has been outpacing AES by roughly 2:1. AES is a smaller player here, not a leader.
- **Brookfield Renewable.** Microsoft framework agreement for 10.5 GW between 2026–2030 ($10B commitment); Google hydro framework up to 3 GW[24]. Brookfield's parent capital base and global pipeline (~84 GW) is structurally larger than AES's. Brookfield is the marginal price-setter for hyperscaler renewable framework deals.
- **Constellation Energy (CEG).** Different product entirely — operating nuclear with 24/7 firm power. Three Mile Island restart for Microsoft, Clinton for Meta[8]. Trades at ~13× EV/EBITDA[23]. CEG owns the highest-value AI offtake (firm zero-carbon baseload). AES has zero nuclear exposure; this is a gap, not an overlap.
- **Vistra (VST).** PJM merchant + nuclear PPAs (2.6 GW Meta deal Jan 2026)[8]. Different market structure — merchant generation with capacity-market upside. ~10× EV/EBITDA[23]. Higher operating leverage than AES.
- **Talen Energy (TLN).** Pure-play merchant nuclear; 1.92 GW AWS PPA (17-yr, $18B)[21][8]. Most exposed to FERC colocation ruling outcomes — November 2024 FERC rejection of the Susquehanna ISA reset the framework[21]. AES has no analogous behind-the-meter exposure.
- **Clearway Energy (CWEN).** Smaller IPP (~12.7 GW late-stage pipeline)[24]; ~2 GW new hyperscaler/DC PPAs in 2025. Direct comp by structure but smaller.

Honest read: AES is a **mid-tier IPP with a quality regulated utility tail.** It is not a leader on backlog, build pace, or cost of capital relative to NEE/Brookfield. It is materially smaller than CEG/VST in firm/baseload AI offtake. The fact that it traded at a public-market discount to peers (≤10× EV/EBITDA pre-deal vs. NEE ~13×, CEG ~13×) is the *reason* GIP/EQT could buy it at $15 — public markets were applying a leverage and EM-exposure penalty that infra capital can absorb.

## Bull case — technical
This is no longer a fundamentals-driven stock. It is a merger arb with a small embedded technical thesis if the deal breaks favorably or gets re-cut.

Conditions for the long thesis to work:
1. **Deal closes on terms.** Stockholder vote (proxy filed; regulatory approvals from FERC, CFIUS, IURC, PUCO, NYPSC, foreign authorities)[6][19]. Equity-financed, no financing contingency. Realistic probability of close in late-2026/early-2027 window: ~85–92%. Return at $14.28: $0.72/share + ~$0.35–$0.53 in dividends through close = 7–9% gross IRR over ~10–13 months.
2. **Topping bid.** A strategic (NextEra, Brookfield) overbids. Low probability — the consortium already paid 40.3% to undisturbed July 2025 VWAP[5]; the deal *was at a 13% discount to the rumor-inflated $17.28 trading price*, and AES shares fell on announcement, signaling no expectation of a topper.
3. **Underlying technical case** (only matters if the deal breaks AND fundamentals hold): hyperscaler PPA pricing continues to firm (+9% in 2025[14]), backlog converts at scheduled COD, regulated utility rate cases continue to be granted (AES Indiana settled at ~$90.7M revenue increase in 2025, half of asked but routine[7]), and Petersburg gas conversion closes on time at Unit 1 June 2026 and Unit 2 December 2026[20]. EBITDA guidance reaffirmed at $2.65–$2.85B[22]. None of this matters as a public-equity holder unless the deal breaks.

**Base rate on platform displacement:** Power generation moats erode slowly — multi-decade timescales. PPAs are contractual; queue positions are administrative. Unlike CPU→GPU or x86→ARM, there is no software lock-in to displace. The right base rate for a power-generation moat is closer to "very durable" than "fragile" — but the moat isn't worth a higher multiple than infra PE pays for it.

## Bear case — technical
Symmetric — what a short who reads the stack would say:

1. **Deal break.** Lowest-probability path but highest-magnitude downside. CFIUS friction over Qatar Investment Authority's participation[6][19] is the most cited risk. State PUC denials (IURC, PUCO) are more boilerplate but add timing risk. If the deal breaks, undisturbed price was ~$10.50 in early July 2025[5]. Downside: ~−27% to ~$10.50. Termination fees: $321M from AES if it walks; $100–$588M from consortium depending on cause[19]. The break scenario wipes out the deal premium and likely sends shares well below the undisturbed price because intervening dilution and OBBBA tax-credit headwinds have eroded the standalone case.
2. **Adverse deal re-cut at lower price.** If financing costs spike or material regulatory conditions are imposed, consortium could renegotiate. Lower probability since the deal is 100% equity-funded[5].
3. **Standalone bear case (post-break):**
   - **OBBBA bites the backlog.** Construction-start deadline July 4, 2026[18]. Backlog projects that miss start dates lose tax credits — equity IRR on a typical solar project drops from ~10% levered IRR to ~5–6% without ITC. ~5+ GW of AES backlog in pre-construction phase is exposed. NEE has the same problem at larger scale, but AES's smaller balance sheet makes it more sensitive.
   - **Hyperscaler PPA pricing peaks.** If the gas turbine bottleneck loosens (GE Vernova ramping to 24 GW annualized by 2028[11]) or SMR deployments accelerate, marginal PPA pricing could moderate from the 2025 +9% pace. AES's *unsigned* backlog optionality is worth less.
   - **Latin America (AES Andes) leverage.** Chile, Colombia, Argentina exposure with ongoing coal exit costs[2][26]. FX, sovereign, and commodity risk ignored by US-focused investors but real.
   - **Net debt/EBITDA at ~8×** is high for the asset class[9]. NextEra runs ~5–6×. A higher-rates regime tightens fixed-charge coverage.

4. **Competitive displacement on new PPAs.** NEE, Brookfield, Clearway are signing larger and more frequent deals. AES's *incremental* market share of new hyperscaler deals has been declining — the marginal MSFT/GOOG/META framework deal is going to bigger balance sheets.

## Market view check
At $14.28 on a $15.00 cash deal, the market is pricing ~5% gross spread to deal close[10][5]. Adding ~3 quarters of dividend through close (~$0.53)[16] gives a gross 8.8% return over ~10–13 months — annualized ~7–10% IRR. That is a *normal* infra-arb spread for a deal with foreign-investor regulatory exposure, not a screaming opportunity. Forward P/E of 6.2× is functionally meaningless because the deal price caps upside at $15 regardless of earnings; multiple expansion is not in the option set. Forward EV/EBITDA at the deal price is ~12×, in line with private infra comps and at a 1–2 turn discount to NEE/CEG public peers[23] — which is the precise arbitrage GIP/EQT is harvesting. The market is consistent with my read: this is no longer a technology-thesis stock, it is a controlled liquidation into infra-PE ownership at a fair (not generous) price.

## 90-day falsifiers
Specific events to monitor through August 2026:

1. **Definitive proxy / record date and stockholder vote scheduling** — DEF 14A details out, vote likely Q3 2026[19]. A vote miss is functionally impossible at a 40% premium, but watch for ISS/Glass Lewis recommendations.
2. **CFIUS notice + clearance filing milestones** — QIA participation is the gating regulatory risk[6][19]. Watch for any CFIUS-required mitigation (governance carve-outs around AES Indiana/Ohio data, restricted-info regimes). A mitigation agreement signed = de-risking; an extended review or blocked-status filing = break risk rising.
3. **IURC and PUCO change-of-control filings** — initial filings should appear in Q2 2026; staff testimony Q3. Watch for opposition from AG/consumer counsel on rate-impact grounds.
4. **Q2 2026 earnings (early August)** — confirm 2026 EBITDA guidance ($2.65–2.85B reaffirmed)[22]; backlog disclosure update; any cancellation/delay disclosures on PPAs (cancellation triggers contractual termination payments to AES, generally favorable, but signals weakening counterparty appetite).
5. **OBBBA construction-start deadline July 4, 2026.** Any portion of backlog that fails to begin construction by this date crystallizes a tax-credit loss. Watch the post-Q2 disclosure on "begun construction" GW.
6. **Spread movement.** A widening past 8% gross would signal new regulatory information; a tightening to <3% signals broker confidence in clean close. Monitor weekly.
7. **FERC PJM colocation compliance filing.** PJM has a 60-day window from the December 2025 order to propose new transmission services[21]. The shape of these affects whether AES's grid-tied PPA model gains or loses competitive ground vs. behind-the-meter alternatives.

## What I could not verify
- Precise Q1 2026 *adjusted* EPS — sources disagreed ($0.27 reported in one trade press item appears to be Q1 2025 mislabeled; AInvest reports $0.645 vs. $0.27 PY; 10-Q shows GAAP $0.68; consensus was ~$0.42–$0.50). I infer adjusted EPS landed in the $0.50–$0.65 range, beating consensus, but I could not source the canonical press release directly.[9][12]
- Exact short interest as % of float as of May 2026.
- Specific unsigned versus signed split inside the "12 GW" backlog as of May 2026 (the most recent clean disclosure I found is 11.1 GW signed at end of Q3 2025[22]; subsequent commentary cites 12 GW range but with some category-of-counterparty ambiguity).
- The breakup fee triggers in detail — I have $321M (AES) and $100–$588M (consortium) but not the specific behaviors that move within that range.[19]
- Whether the consortium has implicitly committed to retain the regulated US utilities or could divest them post-close (this affects post-deal market structure rather than the arb).
- AES Andes contribution to consolidated EBITDA in detail; the segment is reported under "Energy Infrastructure" but the LATAM-specific carve-out is not transparent in the public filings I sourced.

## Sources
[1] https://www.aes.com/energy-solutions/technology/natural-gas-flexible-capacity — retrieved 2026-05-10 — AES portfolio composition: renewable, thermal, LNG, storage; AES Indiana 3.9 GW
[2] https://www.aesandes.com/en/blog/aes-andes-consolidates-its-renewable-transformation — retrieved 2026-05-10 — AES Andes Chile coal exit + 1,620 MW renewable pipeline
[3] https://www.prnewswire.com/news-releases/aes-reports-record-sales-with-data-center-hyperscalers-302212934.html — retrieved 2026-05-10 — Hyperscaler PPA backlog disclosure; 12.6 GW figure
[4] https://www.datacenterdynamics.com/en/news/microsoft-signs-110mw-ppa-with-aes-to-power-california-data-centers/ — retrieved 2026-05-10 — Microsoft 20-yr 110 MWac solar + 55 MW/4hr storage California PPA
[5] https://www.aes.com/energy-insights/consortium-led-global-infrastructure-partners-and-eqt-agrees-acquire-aes — retrieved 2026-05-10 — Definitive deal terms: $15.00/share, $10.7B equity / $33.4B EV, 100% equity financed, board unanimous, close late-2026/early-2027
[6] https://www.spglobal.com/market-intelligence/en/news-insights/articles/2026/3/aes-shares-fall-after-long-awaited-10-7b-take-private-acquisition-is-announced-99233483 — retrieved 2026-05-10 — Stock fell on announcement; regulatory approvals required (PUCO, FERC, NYPSC, CFIUS); foreign-investor scrutiny risk
[7] https://www.aesindiana.com/press-release/aes-indiana-reaches-partial-settlement-regulatory-rate-review-reducing-proposed — retrieved 2026-05-10 — AES Indiana 2025 rate case settlement at $90.7M revenue increase
[8] https://enkiai.com/data-center/constellations-nuclear-strategy-for-ai-data-centers-2025 — retrieved 2026-05-10 — Constellation/Vistra/Talen/AWS nuclear PPAs in detail
[9] https://www.stocktitan.net/sec-filings/AES/10-q-aes-corp-quarterly-earnings-report-0bb7c2a4bb5f.html — retrieved 2026-05-10 — Q1 2026 10-Q: GAAP EPS $0.68, revenue $3.18B, segment splits, board unanimously approved $15 deal
[10] https://finance.yahoo.com/quote/AES/ — retrieved 2026-05-10 — AES May 8 2026 close $14.28; market cap $10.21B; 52-week range $9.46–$17.65; P/E 7.41
[11] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — GE Vernova gas turbine 80 GW backlog through 2029; ramping to 20 GW Q3 2026, 24 GW by 2028; combined-cycle capex doubled to $2,000–$2,500/kW
[12] https://markets.financialcontent.com/stocks/article/barchart-2026-4-21-heres-what-to-expect-from-aes-corporations-next-earnings-report — retrieved 2026-05-10 — 2026 EPS consensus $2.29; 2027 $2.38
[13] https://www.investor.nexteraenergy.com/~/media/Files/N/NEE-IR/news-and-events/events-and-presentations/2025/2025-09-02%20September%20Investor%20Deck.pdf — retrieved 2026-05-10 — NEE ~30 GW backlog; ~10.5 GW DC/tech-customer-served
[14] https://www.utilitydive.com/news/renewable-ppa-prices-up-9-in-2025-set-to-continue-ascent-with-energy-dema/812990/ — retrieved 2026-05-10 — LevelTen index +9% YoY 2025; CAISO solar+storage $70–$85/MWh
[15] https://www.misoenergy.org/engage/stakeholder-feedback/2024/ipwg-generator-interconnection-queue-improvements-pac-2023-1-20240723/ + https://www.zeroemissiongrid.com/insights-press-zeg-blog/interconnection-backlog/ — retrieved 2026-05-10 — MISO queue cap; ERCOT >2,000 requests; PJM/NYISO suspension rates 46–79%; AES CE opposition
[16] https://stockanalysis.com/stocks/aes/dividend/ — retrieved 2026-05-10 — Annualized $0.70 dividend; ~4.87–4.93% yield; YTD return ~−1%
[17] https://www.iea.org/news/data-centre-electricity-use-surged-in-2025-even-with-tightening-bottlenecks-driving-a-scramble-for-solutions + https://www.spglobal.com/energy/en/news-research/latest-news/electric-power/081325-artificial-intelligence-power-demand-in-us-could-top-50-gw-by-2030-epri — retrieved 2026-05-10 — IEA: global DC demand to 945 TWh by 2030; EPRI: 50+ GW US AI by 2030; transmission constraint risk to 20% of planned DC
[18] https://www.arnoldporter.com/en/perspectives/advisories/2025/07/from-ira-to-obbba-a-new-era-for-clean-energy-tax-credits + https://www.bdo.com/insights/tax/how-the-obbba-transforms-the-energy-tax-credit-transfer-market — retrieved 2026-05-10 — OBBBA July 4 2025; construction-start by July 4, 2026; FEOC restrictions effective Jan 1, 2026
[19] https://www.stocktitan.net/sec-filings/AES/def-14a-aes-corp-definitive-proxy-statement-bf977875bf2a.html — retrieved 2026-05-10 — Proxy details, regulatory approvals list, termination fees ($321M AES side; $100M/$588M consortium side), $17.08 consensus PT context
[20] https://www.aesindiana.com/press-release/aes-indiana-receives-approval-repower-remaining-petersburg-units-coal-natural-gas + https://www.powermag.com/aes-indiana-switching-last-coal-units-to-gas-adding-solar-and-storage/ — retrieved 2026-05-10 — Petersburg coal-to-gas: Unit 1 COD June 2026, Unit 2 COD December 2026; Babcock & Wilcox EPC; $281M 20-yr savings
[21] https://www.ferc.gov/news-events/news/fact-sheet-ferc-directs-nations-largest-grid-operator-create-new-rules-embrace + https://introl.com/blog/ferc-pjm-colocation-ruling-data-center-power-plant-guide-2025 + https://ir.talenenergy.com/news-releases/news-release-details/talen-energy-statement-ferc-order-rejecting-susquehanna-isa — retrieved 2026-05-10 — FERC Dec 18, 2025 PJM colocation order; Talen Susquehanna ISA rejection precedent
[22] https://s202.q4cdn.com/986265382/files/doc_financials/2025/q3/11-05-25-Q3-2025-Financial-Review_FINAL.pdf — retrieved 2026-05-10 — 2025 EBITDA guidance $2.65–2.85B; Renewables segment guide $890–960M; backlog 11.1 GW signed; 5 GW under construction
[23] https://intellectia.ai/blog/best-electricity-power-stock-to-buy-2026 + https://247wallst.com/investing/2025/12/06/constellation-holds-margin-lead-as-vistra-expands-with-gas-plants-and-buybacks/ — retrieved 2026-05-10 — VST forward EV/EBITDA ~10×; CEG ~13×; 2026 guidance ranges
[24] https://introl.com/blog/microsoft-brookfield-10-5-gw-renewable-energy-deal-2026 + https://www.tipranks.com/news/company-announcements/brookfield-renewable-posts-record-2025-ffo-expands-global-clean-energy-platform-and-hyperscaler-deals — retrieved 2026-05-10 — Microsoft-Brookfield 10.5 GW / $10B framework; Brookfield 84 GW pipeline
[25] https://www.investor.nexteraenergy.com/~/media/Files/N/NEE-IR/news-and-events/events-and-presentations/2025/2025-12-08%20NextEra%20Energy%20Investor%20Conference%20vF.pdf — retrieved 2026-05-10 — NEE backlog scale and DC-customer commentary
[26] https://www.aesandes.com/en/press-release/aes-andes-agrees-sell-thermal-units-ventanas — retrieved 2026-05-10 — AES Andes Ventanas thermal divestiture; 72% of 2018 coal capacity hibernated/sold/retire-ready by Jan 2025