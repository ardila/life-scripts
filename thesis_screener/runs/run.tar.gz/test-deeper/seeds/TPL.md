# TPL — Texas Pacific Land Corporation

## Where this sits in the AI stack
TPL is not silicon, not packaging, not networking. It is the **physical substrate underneath the data-center half of the AI buildout in the Permian Basin**: ~882,000 fee-simple surface acres in West Texas plus a perpetual non-participating royalty interest (NPRI) under roughly 456,000 of those acres, plus surface easements, brackish/produced-water rights, and a freeze-desalination R&D facility at Orla [1][8][12]. Its workload exposure is **inference- and training-campus power siting**, not compute itself — specifically the land + gas + water + cooling stack underneath behind-the-meter natural-gas campuses that hyperscalers and merchant developers are using to bypass ERCOT's ~400 GW large-load interconnection queue [11][14]. It is a real-asset name dressed as an energy royalty trust that is being repriced as AI infrastructure.

## Snapshot
- **Price:** $416.77 (2026-05-08 close) [2][9]
- **Market cap:** ~$28.7B (68.97M sh out × $416.77) [2]
- **52-week range:** $269.20 – $547.20 [9]
- **Forward P/E:** 43.6× on FY2026 EPS consensus of ~$9.56 (revised post-Q1); range $7.95–$8.83 from a broader analyst panel implies up to ~50× on the lower estimate [9][10][13]
- **EV / NTM revenue:** ~27× on FY2026 revenue of $1.07B (no meaningful net debt; cash ≈ EV/market-cap delta) [9][13]
- **Consensus 12-month price target:** $452.65 (avg of 8 analysts, +8.6% from spot); one Street high at $639 [10][13]
- **YTD total return:** +34.9% [2]
- **Short interest (% of float):** 2.59% (1.66M shares) [10]

## Moat — what it is physically made of
The "moat" is **a fee-simple land position that cannot be replicated at any price** plus a royalty structure that is structurally capital-free. Decomposing:

1. **Fee-simple surface estate, ~882,000 acres, in the highest-productivity hydrocarbon basin on earth.** Concentrated in Loving, Reeves, Culberson, Hudspeth and Pecos counties — the Delaware sub-basin core. This is **contiguous, large-block surface ownership**, which matters because a 1 GW data-center campus needs ~1,000–2,000 acres of contiguous, flat, restriction-free land within ~10 miles of a 138 kV+ tie-in and within reach of a 30+ MMcf/d gas lateral. Permian surface is otherwise checkerboarded across thousands of small ranches and state-owned tracts — TPL is the only party that can option 5,000+ acre contiguous blocks at a stroke [1][8][12]. Bolt's December 2025 deal targets **10 GW** sited on TPL land specifically because of this contiguity property [3][6][7].

2. **Non-participating perpetual royalty interest under the same land:** 1/128 NPRI under ~85,000 acres + 1/16 NPRI under ~371,000 acres + ~33,000 additional NRA, for ~224,000 net royalty acres total [12]. Because it is *non-participating*, TPL pays zero D&C capex and bears no plugging-and-abandonment liability — every barrel produced by Oxy, BP, Devon, Exxon, et al. across the position remits a check. Q1 2026 production through this position averaged ~37,001 BOE/d, +19% YoY, with completion activity concentrated in Loving/Reeves (Delaware) and Martin (Midland) [4][16]. This is a structurally ~95% gross-margin business — the closest thing to a perpetual annuity in U.S. equities.

3. **Surface use and produced-water royalties.** Every Permian operator drilling on or near TPL land needs surface for pads, gathering, salt-water disposal (SWD) wells, and pipelines. TPL collects easement fees up front plus per-barrel produced-water royalties ($0.07–$0.10/bbl) for allowing third-party SWD infrastructure on its surface — second-highest quarterly water volumes in company history in Q1 2026 [4]. Aris Water in particular pays TPL to permit and drill on TPL surface [5] — TPL is essentially the rent-collector on the entire produced-water value chain across its acreage.

4. **Brackish groundwater rights under Texas's correlative-ownership rule.** In Texas, groundwater belongs to the surface owner (rule of capture, modified by groundwater conservation districts). TPL controls source water across hundreds of thousands of acres in a region where water is the second-most-constrained input after power for both fracking *and* for evaporative data-center cooling.

5. **The Orla freeze-desalination pilot (10,000 bbl/d Phase 2B nearing commissioning).** This is the genuinely speculative leg. Multistage fractional-freeze desalination + granular activated carbon + seawater RO turns Permian produced water (TDS often >120,000 ppm, near saturation) into something approaching fresh water. The thermodynamics are roughly 70–90 kWh/m³ — three to four times reverse-osmosis seawater, *unless* you can scavenge waste heat. TPL is allocating ~$20M in 2026 to co-locate the freeze plant with data-center waste-heat capture, which is the only configuration where the unit economics close [4][12]. If it works, TPL turns a $0.30–$0.60/bbl disposal liability into an $0.80–$2.00/bbl freshwater product *and* sells the cold side as cooling. If it doesn't, it is a write-down, not a thesis-killer.

**Durability assessment by component:** the fee-simple surface estate is essentially perpetual (Texas land patents from 1888); the NPRI is also perpetual but its cash flow scales with Permian completion activity and oil price; the surface/water royalty stream is **the most replicable component** because LandBridge (315k acres) and a handful of large ranchers own adjacent surface and can compete on lease terms; the freeze-desalination IP is an option, not a moat. **Person-years to replicate:** infinite for the land itself (you cannot manufacture more Delaware Basin surface); 3–5 years for a credible competitor *if* they could assemble 300k+ contiguous acres, which they cannot.

## AI buildout bottleneck map
The binding constraints on the 2026–2028 AI buildout, ranked:

1. **Power generation + grid interconnect** — ERCOT large-load queue at ~400 GW vs. 85 GW current peak, with transmission planners modeling realistic interconnect of ~85 GW by 2031 [11][14]. **TPL: beneficiary.** Behind-the-meter gas on TPL land sidesteps the queue entirely. Bolt's plan starts at 1 GW gas-fired, scaling to 10 GW with later renewables/nuclear [3][6][7]. Chevron's 5 GW Permian BTM campus and FO Permian's 5 GW off-grid platform validate the architecture independently [5][6].

2. **Gas-turbine deliveries.** GE Vernova, Siemens Energy and Mitsubishi Power are quoting 2029–2031 for new H-class slot deliveries; aero-derivatives (LM6000, LM2500) are tighter on near-term capacity but faster to install. *Could not source a precise current backlog quarter for this dossier — flagged below.* **TPL: indifferent / mild headwind.** A turbine shortage caps the rate at which 10 GW can actually be built, regardless of how much land is available; TPL collects pad rent and gas royalties on whatever does get built.

3. **CoWoS-L advanced packaging.** TSMC scaling from ~9k wpm in 2024 to ~30k wpm by end-2026; NVIDIA has reportedly booked >50% of 2026 CoWoS capacity [15]. **TPL: indifferent.** A CoWoS shortage caps GPU deliveries, which caps how fast 10 GW of data-center load needs to come online — this is a *demand-side* concern for TPL, not a supply-side one.

4. **HBM3e / HBM4.** Fully allocated through 2026; Micron and SK Hynix have multi-year hyperscaler lock-ups [15]. **TPL: indifferent**, same logic.

5. **Permian gas takeaway.** Waha hub regularly trades negative; takeaway is constrained eastward (Matterhorn online late 2024 helped, more pipe in 2026–2027). **TPL: beneficiary.** Behind-the-meter combustion at the wellhead is the obvious solution to stranded gas, and TPL's 224k NRA gives it royalty leverage on every Mcf produced upstream of those constraints [4].

6. **Liquid cooling and produced-water reuse.** >100 kW/rack densities require direct-to-chip liquid loops and large makeup-water volumes. **TPL: differential beneficiary** if the freeze-desal pilot scales; otherwise, just a beneficiary via surface/water royalties.

7. **High-voltage transformers and 138 kV+ switchgear.** 100–150 week lead times globally. **TPL: mild headwind**, same logic as turbines — physically caps the rate of buildout.

8. **Electrical contractor / lineman labor.** ~Tens of thousands of qualified linemen in the U.S., with industrial-scale contractors (Quanta, MasTec, MYR) booked out 12–24 months. **TPL: indifferent.**

## Competitive teardown
The competitor set is **not** the AI-infrastructure cohort — it is *other parties that can sell or lease similarly powered, similarly located land*.

- **LandBridge (LB)**, ~315,000 surface acres in the Delaware core [5]. Materially overlapping geography, more concentrated in a smaller area, more aggressive M&A. Already announced a 2 GW LOI on ~2,000 acres for a 1,100 MW gas plant in Reeves County in 2025 [5][6]. On a per-acre basis LandBridge currently trades at a *higher* implied surface multiple, which suggests the market views their surface mix as higher-quality for data-center siting; on a total-asset basis TPL's NPRI dominates. **What would have to be true for LandBridge to take share:** anchor-hyperscaler signing on LandBridge surface that prices their land at $50k–$200k/acre transactionally, which would commoditize the Permian "powered land" thesis broadly and compress TPL's incremental land-sale multiples. This is plausibly a 2026–2027 event.

- **Aris Water Solutions (ARIS)** competes on the produced-water/recycle layer specifically and has commercial agreements *with* TPL to permit and drill on TPL surface [5]. Aris monetizes the operational complexity of the water; TPL monetizes the underlying surface and groundwater right. Not a head-on competitor — closer to a customer.

- **FO Permian Partners** — privately announced 5 GW off-grid platform, 320 acres in Midland County, 150 MW Phase 1 in 2026 [6]. Demonstrates that midstream + land + gas turbines can be combined by non-TPL parties. The 320-acre footprint is small; a 5 GW build at typical AI density needs closer to 2,500–4,000 acres, so FO will need to acquire more — pressuring surface valuations broadly.

- **Chevron** — negotiating 5 GW BTM AI campus in the Permian [6]. Chevron is a hydrocarbon operator with surface positions and a strong gas-supply story but does not own contiguous surface at TPL scale; they are likely a customer or JV partner for TPL/LandBridge.

- **Fermi America** — 17 GW project drawing 300,000 MMBtu/d Permian gas [6][14]. Larger but earlier-stage.

- **Adjacent basins:** the Marcellus (Appalachian gas) and the Haynesville have cheaper gas but lack ERCOT's permissive interconnection rules and the regulatory speed of Texas; PJM-area data-center moratoria (Virginia) push more load toward Texas, not away. The Eagle Ford and Anadarko have less surface concentration.

**Honest read on competitive parity:** for any *single* data-center campus, LandBridge and large private Permian surface owners can match TPL on land terms. TPL's structural advantage is **portfolio scale and royalty stack** — the ability to underwrite a 10-campus, 10 GW program on a single counterparty's surface, with co-located gas royalties and surface easements creating triple-stacked rent. Bolt chose TPL for this reason, not because TPL's individual acres are uniquely better.

## Bull case — technical
For TPL to outperform, the following technical conditions need to hold over the next ~36 months:

1. **ERCOT large-load queue stays gridlocked** (>200 GW backlog, transmission build remains years behind demand). [11][14]. This is the single most important condition — it is what forces hyperscalers and merchant developers to behind-the-meter gas, which is what gives TPL surface its scarcity premium.
2. **Henry Hub / Waha gas stays $2–$5/MMBtu**, keeping all-in BTM electricity at $35–$60/MWh — well below grid PPAs in load-constrained ERCOT zones.
3. **Bolt closes a Series B and signs at least one Tier-1 hyperscaler anchor tenant by mid-2027.** A signed Microsoft/Anthropic/OpenAI/Meta tenant against the 10 GW pipeline converts the "optionality" narrative into recurring rent.
4. **At least one of the next three Permian BTM projects (Chevron, Fermi, FO) commissions a >200 MW phase**, demonstrating that the architecture works at scale and de-risking permitting timelines.
5. **The Orla freeze-desalination plant achieves >70% recovery at <$1.50/bbl total cost** at the 10,000 bbl/d pilot, unlocking the produced-water → cooling-water → fresh-water cascade.
6. **CoWoS / HBM bottlenecks ease modestly through late 2026**, accelerating GPU deployment and increasing data-center starts (without easing enough to collapse the constraint).

**Base rate on technology displacement at this point in the cycle:** historically, scarce-land monopolies retain pricing power for 10–30 years (Texas grazing leases, NYC airspace, port-adjacent industrial land), but **resource-driven land premiums fade in 5–10 years** when transmission build-out or substitute geographies emerge (cf. Williston/Bakken land premium 2010–2015, eroded as production peaked and pipe came online). TPL's premium has both a permanent (royalty NPRI) and a cyclical (data-center siting) component; the bull case requires the cyclical component to persist longer than 5 years.

Financial outcome: at $1.07B 2026 revenue and a ~75% EBITDA margin, ~$800M EBITDA. If the 10 GW pipeline converts at $5k–$15k/acre/year ground rent across 25,000 acres, that adds $125M–$375M of ~100% margin rent on top of an asset that already trades at ~36× EV/EBITDA. Bull case is a re-rate plus growth; doubling is conceivable; tripling requires Bolt to convert and the freeze-desal to work.

## Bear case — technical
The version a stack-literate short-seller would write:

1. **ERCOT Batch Study process actually works.** ERCOT contracted McKinsey in early 2026 to redesign the large-load interconnection process, with a Batch Zero pilot framework at the February 2026 PUCT meeting [11]. If the batch process clears even 30 GW of West Texas interconnections by end-2027, the speed advantage of TPL's BTM gas siting evaporates — Tier-1 hyperscalers prefer grid power for reliability, water access, and ESG optics. TPL's premium compresses.

2. **Gas-turbine backlog kills the timing arbitrage.** If H-class delivery slots are 2030+ and aero-derivatives can only fill in to ~1.5 GW total in the Permian over the next 36 months, then the "BTM Permian campus" goes from "fastest path to power" to "third-fastest, after grid expansion catches up." Bolt's 10 GW pipeline reduces to 1–2 GW realized, and the rest is paper. *This is plausibly the biggest single risk and I could not source a precise current backlog quarter — see "What I could not verify."*

3. **The land-sale multiple decompresses.** TPL has been monetizing surface via outright sales (Q1 2026 sale of a "large-scale data center and power generation project" parcel [4]). A sale at $40k–$80k/acre is fine; but if LandBridge or FO Permian signs a deal that sets a public mark at, say, $25k–$35k/acre for similar-quality surface, TPL's recent comps look frothy and the EV/acre arithmetic compresses.

4. **Behind-the-meter regulation tightens.** Texas legislators have begun discussing data-center load classification under PURA and the cost-of-service allocation between BTM loads and the grid. If BTM campuses are required to pay a grid-reliability charge equivalent to interconnected loads, the cost advantage shrinks materially. This is a 2026–2027 PUCT/legislative risk.

5. **Permian completion activity slows.** Royalty production +19% YoY in Q1 2026 [4] is partly the lagged effect of late-2025 completions by Oxy/BP/Devon/Exxon. If WTI sits below $65 for two consecutive quarters in 2026, completion guidance from those four operators is cut and TPL's underlying royalty growth slows from +19% to flat or down. Half the equity story would still work (data centers), but the half that pays the dividend today (royalties) deteriorates.

6. **Freeze-desal doesn't work at commercial cost.** If the Orla pilot can't get below $2.50/bbl all-in, produced-water reuse stays a niche solution and TPL has spent $20M+ on a science project. Not thesis-killing, but the highest-margin growth story dies.

7. **The narrative is wrong about water for cooling.** Hyperscalers are aggressively moving to closed-loop liquid cooling specifically because of water availability concerns; if Blackwell/Rubin-generation racks at 140–250 kW each go fully closed-loop, the freshwater offtake from a Permian campus is *much* smaller than the produced-water industry assumes, undermining the cascade thesis.

8. **Valuation is the bear case on its own:** 43–50× forward P/E and ~27× EV/NTM revenue against a business whose core earnings (royalties) are commodity-cyclical and whose growth optionality (data centers) is still entirely paper. The implied perpetual growth rate at 11% cost of equity is ~9% — a heroic assumption.

## Market view check
At ~$417 / ~27× NTM revenue / ~44–50× forward EPS, the market is paying a real-asset multiple, not an energy multiple — peer royalty trusts trade at 10–15× P/E [9][10]. The price embeds (i) Permian royalty growth continuing in the high teens through 2026, (ii) the Bolt 10 GW pipeline converting to *some* recurring rent within 24 months, and (iii) optionality on freeze desalination, brackish water sales, and additional surface monetizations. The street consensus PT of $452 implies the market thinks most of this is in the price already (+8.6% upside on a name that has run +35% YTD [2][10]). The mispricing thesis is **not** valuation arbitrage — it is whether the **technical substrate of the AI buildout in the Permian** holds for 5+ years vs. <3 years. Long the stock here is a bet that the ERCOT queue stays gridlocked and that gas-turbine + BTM economics keep the Permian as the lowest-friction path to >1 GW campuses. Short the stock here is a bet that grid interconnect normalizes faster than gas-turbine deliveries can fill in.

## 90-day falsifiers
- **ERCOT Batch Zero / Batch Study results published with named projects** — if >10 GW of West Texas large-load gets a credible 2027–2028 interconnect date, TPL's siting premium compresses [11].
- **Bolt Series B announcement or hyperscaler anchor disclosure.** A named Tier-1 tenant on TPL land confirms the 10 GW thesis; silence past July 2026 raises execution risk on the partnership [3][7].
- **Q2 2026 TPL earnings (early August):** specifically the disclosed land-sale price/acre on the next data-center parcel, produced-water royalty volumes, and any Orla commissioning update [4].
- **GE Vernova / Siemens Energy Q2 2026 earnings turbine backlog quarters** — confirms or rebuts the "speed advantage" of BTM siting.
- **LandBridge LOI conversion to definitive agreement on the 2 GW Reeves County deal** [5]. A signed contract sets a public per-acre comp; failure to convert signals demand is softer than narrative.
- **Permian completion guidance from Oxy/BP/Devon/Exxon Q2 calls** — directly drives TPL's royalty cash flow [4].
- **Any FERC, PUCT or Texas legislative filing on BTM data-center load cost allocation** — material to TPL's customers' economics.
- **Hyperscaler Q2 capex commentary on Permian or West Texas explicitly** — currently $725B aggregate 2026 capex [15]; a >10% sequential cut in any one of MSFT/META/GOOG/AMZN would be a meaningful negative read.

## What I could not verify
- **Current GE Vernova / Siemens Energy / Mitsubishi gas-turbine backlog in quarters.** Widely reported as multi-year but I did not source a clean primary number for this dossier; this is material to the bear case.
- **Specific per-acre transaction price on the Q1 2026 TPL data-center land sale.** TPL disclosed the sale but not, in the sources I read, the implied $/acre comp.
- **Bolt's investor list beyond the $150M raise and TPL's $50M.** A named hyperscaler or sovereign LP would change the credibility of the 10 GW pipeline.
- **The actual recovery rate and unit cost of the Orla freeze-desalination pilot in commissioning runs.** TPL has discussed process improvements but no published kWh/m³ or $/bbl figures.
- **The geographic distribution of TPL's 224k NRA across counties** — whether the NPRI concentrates in the highest-IP-rate Delaware sections matters for royalty durability and I did not see a county-level breakdown.
- **What fraction of TPL's 882k surface acres is actually contiguous in blocks >1,000 acres** — total acreage matters less than developable contiguous blocks; the company has not published a buildable-acres figure.
- **Texas groundwater conservation district rules specific to TPL's counties** — correlative ownership is the state-level rule but local districts can cap export and pumping, which materially affects the water thesis.

## Sources
[1] https://www.texaspacific.com/assets/royalty-acreage — retrieved 2026-05-10 — TPL company description of ~882k surface acres + 224k NRA with NPRI breakdown (1/128 under 85k acres; 1/16 under 371k acres; +33k additional NRA).
[2] https://finance.yahoo.com/quote/TPL/ — retrieved 2026-05-10 — current price, market cap, recent close data for TPL.
[3] https://fortune.com/2026/01/02/eric-schmidt-ai-data-centers-bolt-texas-pacific-land-tpl/ — retrieved 2026-05-10 — Bolt Data & Energy / TPL strategic agreement, Eric Schmidt as Bolt chairman, 10 GW ambition.
[4] https://www.fool.com/earnings/call-transcripts/2026/05/07/tpl-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1 2026 TPL earnings: $237M revenue, ~37k BOE/d royalty production +19% YoY, water royalties, Orla pilot status, data-center land sale.
[5] https://310value.substack.com/p/data-centers-in-the-permian-basin-9c9 — retrieved 2026-05-10 — Permian data-center substrate analysis: LandBridge 315k acres, Aris Water relationship to TPL, behind-the-meter economics.
[6] https://www.texastribune.org/2026/02/02/texas-permian-basin-power-plant-project-data-centers/ — retrieved 2026-05-10 — Chevron 5 GW Permian BTM campus, FO Permian Partners 5 GW off-grid platform, Fermi America 17 GW proposal.
[7] https://www.texaspacific.com/investors/news-events/press-releases/detail/176/bolt-and-tpl-announce-strategic-agreement-to-pursue-data — retrieved 2026-05-10 — official TPL/Bolt strategic agreement press release (Dec 17, 2025).
[8] https://markets.financialcontent.com/stocks/article/finterra-2026-3-31-texas-pacific-land-corporation-tpl-the-permians-scarcity-asset-for-the-ai-era — retrieved 2026-05-10 — TPL framed as scarcity asset; surface acreage and AI siting analysis.
[9] https://www.gurufocus.com/term/forward-pe-ratio/TPL — retrieved 2026-05-10 — TPL forward P/E ratio 43.56× reference.
[10] https://www.marketbeat.com/stocks/NYSE/TPL/forecast/ — retrieved 2026-05-10 — analyst consensus PT, short interest, EPS forecasts.
[11] https://www.latitudemedia.com/news/ercots-large-load-queue-has-nearly-quadrupled-in-a-single-year/ — retrieved 2026-05-10 — ERCOT large-load interconnect queue ~400 GW vs. 85 GW peak; planner-realistic 85 GW by 2031; McKinsey/Batch Study process.
[12] https://markets.financialcontent.com/stocks/article/stockstory-2026-5-7-tpl-q1-deep-dive-permian-upside-data-center-ambitions-and-desalination-progress — retrieved 2026-05-10 — Orla freeze-desalination 10k bpd pilot, $20M co-location waste-heat capex plan for 2026.
[13] https://www.investing.com/news/company-news/texas-pacific-land-q1-2026-slides-record-revenue-77-ebitda-margin-93CH-4670385 — retrieved 2026-05-10 — TPL Q1 2026: 77% EBITDA margin, FY2026 revenue forecast ~$1.07B, EPS forecast $9.56 (post-revision).
[14] https://www.ercot.com/files/docs/2026/03/17/ERCOT-Monthly-February-2026-FINAL.pdf — retrieved 2026-05-10 — ERCOT February 2026 monthly recap; large-load process status; West Texas transmission constraints.
[15] https://newsletter.semianalysis.com/p/ai-capacity-constraints-cowos-and — retrieved 2026-05-10 — CoWoS/HBM3e supply constraint analysis; NVIDIA share of TSMC CoWoS; hyperscaler 2026 capex ~$725B.
[16] https://www.texaspacific.com/investors/news-events/press-releases/detail/184/texas-pacific-land-corporation-announces-first-quarter — retrieved 2026-05-10 — official TPL Q1 2026 press release; royalty production by operator (Oxy/BP/Devon/Exxon) and county (Loving, Reeves, Martin).