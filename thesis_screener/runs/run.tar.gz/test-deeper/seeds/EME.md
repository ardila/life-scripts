# EME — EMCOR Group, Inc.

## Where this sits in the AI stack
EMCOR is the unionized specialty contractor that physically installs the power and mechanical guts of hyperscale data centers — medium-voltage switchgear, busway, paralleling controls, transformers and standby generation on the electrical side; chilled-water plants, condenser-water risers, coolant distribution units (CDUs), direct-to-chip manifolds, primary/secondary loops, and leak detection on the mechanical side. It sits between the silicon (NVIDIA/AMD), the OEM gear (Schneider, Vertiv, Eaton), and the shell GC (DPR, Turner, Holder). It does not design chips, sell ASICs, or operate compute. Its scope is the *labor and project-management layer* that converts gear deliveries into a turn-up-ready white space, with a separate recurring services segment that maintains those plants post-handover [1][6][10].

## Snapshot
- **Price:** $921.64 (2026-05-08 close) [3]
- **Market cap:** $40.96B [3]
- **Enterprise value:** $40.56B [3]
- **52-week range:** $427.90 – $951.95 [11]
- **Forward P/E:** ~31.1× on consensus, ~31.8× on the midpoint of management's 2026 EPS guide ($28.25–$29.75) [3][2]
- **EV / NTM revenue:** ~2.15× (EV $40.56B / 2026 guide midpoint $18.875B) [3][2]
- **Consensus 12-month price target:** wide dispersion — low $675, average ~$832, recent revisions to $900 (UBS), $945, $1,123 (Cantor). Implied return at average target is negative from the current print; the upper revisions imply roughly flat-to-+22% [11]
- **YTD total return:** ~+60% inference from the +49% YTD figure flagged when shares were at $832 in late Q1 [12]; precise YTD not directly verified
- **Short interest (% of float):** 2.08% [3]
- **Dividend yield:** 0.17% [3]

## Moat — what it is physically made of
EMCOR's "moat" is not patented. There is no kernel library, no foundry contract, no piece of IP that a competitor cannot in principle replicate. The durable advantages are four physical/organizational stacks:

**1. Local-density IBEW/NECA labor pools.** Roughly 45–70% of the construction cost of a data center is the electrical scope [4]. In Northern Virginia — the single largest concentration of data-center capacity globally — IBEW Local 26 performs approximately 97% of the work [5]. EMCOR's Dynalectric DC subsidiary is the largest contractor pulling from that local; the recently retired CEO of Dynalectric DC was a 52-year IBEW member and director of the D.C. NECA chapter [5]. That kind of relationship is not transferable; a non-union competitor cannot recruit the same crew without disrupting an entire local. The 2025 Miller Electric acquisition ($865M cash) extended this pattern into the Southeast, where EMCOR previously had "limited electrical construction presence" and where Miller already runs 24% of its book through data centers [6]. The moat is a *geographic patchwork of labor monopsonies*, not a single national brand.

**2. Supervision pipeline, not headcount.** This is the single most distinctive technical point from the Q1 2026 call. CEO Tony Guzzi explicitly named the constraint as the *foreman-to-craftsman ratio*, not raw electrician supply: "our real bottleneck...is supervision. We have to create more foreman. We have to create more general foreman" [1]. Data centers are schedule-driven jobs with $50M–$500M+ contract values; a single missed switchgear energization slips an entire 100 MW phase. The capacity to *run* that work — bid it, sequence it, hold tolerance on day-five-of-pour conduit coordination — lives in maybe 5,000 to 15,000 individuals nationwide, and EMCOR has been farming them internally for 20 years through Miller's "pro-trade" 2–4-week certification curriculum [1]. A competitor can lure journeymen with $250K packages [4], but cannot lure 200 general foremen.

**3. Prefabrication catalogs.** EMCOR's prefab shops kit out switchgear lineups, busway, mechanical skids, and CDU subassemblies offsite for site delivery [1]. This collapses installation hours per MW, which is the only knob that actually scales output at a labor-constrained ceiling. Guzzi described the prefab posture as "almost a catalog…taking all these different parts from distributors and OEMs, put them together, so it almost kits out to the site" [1]. This is operationally not yet a commoditized capability; Comfort Systems has been more aggressive on mechanical modular skids, but the integrated electrical+mechanical prefab posture is harder to replicate.

**4. Recurring-services flywheel.** The Building Services and Industrial Services segments (~28% of 2025 revenue) [10] do the post-handover O&M. Critical-facility customers strongly prefer the contractor who built the plant to maintain it; this both raises switching cost on future capex and gives EMCOR continuous on-site visibility into capacity additions before they're publicly disclosed.

**Durability assessment, component-by-component:**
- Labor density: **high durability**. Constraint is multi-decade because apprenticeship pipelines are 4–5 years and 20,000 electricians retire annually against 300,000+ needed for AI demand [4]. *This is a moat the market under-prices because it does not look like one.*
- Supervision pipeline: **high durability**, very hard to replicate.
- Prefab: **medium durability**. The competitor set (FIX, MTZ, PWR) is catching up; this is the easiest piece to copy.
- Services flywheel: **high durability**, low growth rate.

What EMCOR is *not*: it is not a technology IP company. There is no NVIDIA-grade asymmetry. The right comparable is not CUDA-vs-ROCm; it is the unionized construction sub-sector of an industrial cycle.

## AI buildout bottleneck map
Listed in approximate severity (most binding first), with EMCOR's positioning:

| Bottleneck | Status (24-month outlook) | EMCOR position |
|---|---|---|
| Gas turbines (utility-scale + behind-the-meter) | GE Vernova ~55 GW backlog, sold through 2029–2030; Mitsubishi sold into 2028 [7] | **Indifferent / mild beneficiary** — EMCOR doesn't build turbines, but installs balance-of-plant and is downstream of every behind-the-meter project at hyperscaler sites |
| Grid interconnect / transmission | Multi-year queue depths in PJM, ERCOT, MISO; pivot to behind-the-meter gas | **Beneficiary, indirectly** — Quanta is the more direct beneficiary on the transmission side |
| Skilled electrical trades (journeymen) | 300K+ shortfall vs AI demand, 20K/year retirements, wages up to $250K [4] | **Direct beneficiary and constraint owner** — EMCOR is short the labor it sells; the constraint is its key pricing-power lever |
| Supervision (foremen/GFs) | Not publicly quantified; EMCOR identifies this as *the* binding constraint [1] | **Constraint owner, highest leverage** |
| Liquid-cooling installation capacity | GB200 NVL72 at ~120 kW/rack now standard; Vera Rubin NVL144 to 600 kW/rack in 2026; D2C is the dominant 50–150 kW solution [8] | **Direct beneficiary** — drove the +86% YoY mechanical N&C revenue in Q1 [1][2] |
| HBM3e / CoWoS-L allocation | SK Hynix HBM "sold out" for 2026; NVIDIA holds >60% of TSMC CoWoS-L [9] | **Exposed customer of downstream demand**, not directly geared to packaging — if silicon arrives, EMCOR has work; if it doesn't, RPO conversion slows |
| Liquid-cooled rack ecosystem (CDUs, manifolds) | Vertiv/Schneider co-developing with NVIDIA [8] | **Beneficiary** — EMCOR installs what those OEMs ship |
| Electrical contractor capacity (national) | 45–70% of DC cost; 11-month average contractor backlog; Oracle has slipped projects from 2027→2028 due to electrician availability [4] | **Direct beneficiary** — this is EMCOR's core scarcity |

The cleanest read of EMCOR's positioning: it is short the two factors that most directly gate the AI buildout — *unionized electrical labor and the supervision to deploy it* — at a moment when gas turbines and HBM are also short. It does not own the most valuable piece of the stack, but it owns one of the indispensable pieces, and the indispensable pieces all gate each other.

## Competitive teardown
The peer set is four publics and a long tail of regional privates:

**Quanta Services (PWR).** Q1 2026 record backlog $48.5B; the "Technology and Load Center" segment expected to grow 70–110% YoY [11]. PWR's center of gravity is *outside the fence*: transmission/distribution, substation work, renewables. Inside the data hall, PWR has been buying its way in (Cupertino Electric acquisition in particular). Axis of overlap with EMCOR is *medium-voltage and substation electrical work for hyperscaler campuses*. PWR is the better beneficiary of utility-scale grid spend; EMCOR is the better beneficiary of white-space electrical. They are converging.

**Comfort Systems USA (FIX).** Technology-related work now ~40% of revenue [12]; modular/skidded mechanical capacity is FIX's most credible technical differentiator. FIX is the most direct overlap with EMCOR's mechanical construction segment. On modular CDU skids and mechanical prefab, FIX has been louder publicly about scaling capacity. Forward P/E ~25× vs EMCOR ~31× [12][3] — the market is paying a premium for EMCOR's electrical mix, which is fair because electrical is the larger and more labor-constrained scope per facility.

**MasTec (MTZ).** Energy-infrastructure heavy (pipelines, transmission). Data-center entry is more recent and less direct than PWR or EMCOR; revenue growth 2026E +31.5%, 2027E +28% [12] is impressive but coming from a smaller mix. Not currently a head-on competitor inside the white space; competes for the same supervision pool indirectly.

**Regional privates / mechanical contractors (Rosendin, Helix Electric, etc.).** Rosendin is the meaningful non-public peer in Northern Virginia and Phoenix. Most are non-union and compete on flexible cost in non-union markets (Texas, Arizona, Southeast). EMCOR's Miller acquisition was an explicit response in the Southeast; before that, EMCOR was structurally weak there [6].

**What would have to be true for share loss:** A hyperscaler-driven shift from union to merit-shop in EMCOR's union strongholds (Northern Virginia, Chicago, NY/NJ). That has not happened in any visible way. Or: FIX/PWR converting prefab into a 10–20% labor-hour advantage on identical scope, which is theoretically possible and worth watching.

## Bull case — technical
Stock outperforms if:

1. Hyperscaler capex stays at or above current run rate through 2027. Recent Q1 capex commentary across MSFT/META/GOOG/AMZN supports this on a trailing basis; the leading signal is GPU/HBM/CoWoS allocation visibility through 2026 [9], which is already booked.
2. The electrical labor bottleneck does not loosen. Base rate: electrical apprenticeships are 4–5 years; pipelines added in 2024 do not become productive journeymen until ~2028–2029. A loosening within the 24-month thesis window is implausible.
3. Liquid cooling continues to push mechanical scope per MW up, not down. GB200 NVL72 → Vera Rubin NVL144 at 600 kW/rack [8] means each MW shipped requires more mechanical plant per square foot of white space, not less. Direct positive read-through to EMCOR's mechanical segment.
4. EMCOR successfully scales its supervision pipeline at the rate Guzzi described (Miller's program rolled out across subsidiaries) [1]. This is the variable most under EMCOR's control.
5. M&A optionality: an additional Miller-scale tuck-in in a non-union geography (Texas, Phoenix, Atlanta) is plausible given the $500M buyback authorization is unspent and the balance sheet is roughly net-cash [13].

**Base rate context:** Construction services in technology cycles tend to be late-cycle beneficiaries. In prior buildouts (telecom 1998–2000, cloud 2014–2018) specialty contractors compounded EPS at 20–30% for ~3–5 years and then derated sharply when capex normalized. The current cycle is unusual in that the *physical* gating constraints (power, packaging, HBM) are more durable than the demand-side constraint historically.

Financial frame at this outcome: EPS compounding ~15–20% annually 2026–2028 on backlog conversion, multiple holding ~25–30× — total return roughly mid-teens annualized.

## Bear case — technical
Stock underperforms if:

1. **Hyperscaler capex digestion.** The most credible bear catalyst is not "AI demand collapses" but "hyperscalers run out of CoWoS-L allocation and power, so they stop *signing* new capacity through 2028 even if 2026 deliveries continue." Backlog conversion would still print through 2027; the new-bookings line would weaken first. Watch the *order intake* line, not the revenue line.
2. **Vertical integration by hyperscalers.** Microsoft and Meta have both internalized portions of prefab and self-perform on commissioning. If a hyperscaler decides to in-source electrical engineering and contract individual locals directly (bypassing EMCOR's national-scale relationship), the moat thesis becomes much weaker. There is precedent in the modular construction space.
3. **Pricing power inverting.** Today EMCOR has pricing power because customers want certainty of delivery. If the supervision constraint loosens (either via union apprenticeship surge or via successful FIX/PWR scaling), pricing power normalizes faster than backlog burns.
4. **Margin mix headwind.** Q1 2026 electrical operating margin was 12.1% vs 12.5% prior-year [1] — Miller integration intangible amortization plus deliberate mix toward GMP/cost-plus contracts in new geographies. Management has explicitly told the Street to focus on *dollars, not percentages* [1], which is the right answer technically but is exactly the language management uses when it knows percentages are headed down. If 2026 segment margins compress 100+ bps, the multiple comes in.
5. **Multiple compression.** At ~31× forward EPS [3], EME is being valued like a software company on industrial-cyclical earnings. The 5-year median forward P/E was 17× [12]. A reversion halfway to that range with EPS still growing 15% would be a flat-to-down stock.
6. **Insider behavior.** CEO Tony Guzzi sold 36,000 shares ($26M) at $729 in March 2026 [13]; over 5 years, 15 sales and 0 buys. That is not unusual for a CEO at this stage of his tenure, but it is not a vote of confidence at $921.

**Base rate context:** Specialty-contractor multiples derate ~40–60% peak-to-trough when buildout cycles end. EMCOR derated from ~18× to ~10× in 2001–2002 and again in 2008–2009. The starting point this cycle is much higher, so the asymmetry in a derating scenario is materially worse than prior cycles.

## Market view check
At $921 and ~31× forward EPS / 2.15× EV/sales, the stock is priced for sustained 15%+ EPS growth and no multiple compression. The current price embeds, in our read, three implicit views: (a) backlog converts cleanly through 2027 with margin held, (b) the supervision bottleneck is binding for competitors but not for EMCOR — i.e., EMCOR's share *gains* — and (c) the buildout cycle extends meaningfully past 2027. Views (a) and (b) we agree are plausible. View (c) is where the market and we diverge: the buildout cycle is plausibly longer than the typical 3–5-year specialty-contractor cycle, but it is *not* infinite, and the stock's multiple is more consistent with an infinite-cycle read. The market is paying for a labor-monopsony moat at a software multiple. That can work for another 12–18 months on momentum, but the asymmetry from here is unfavorable.

## 90-day falsifiers
- **Q2 2026 earnings (late July).** Three specific things to check: (i) Network & Communications RPO sequential growth — anything below +10% q/q would signal hyperscaler order intake decelerating despite revenue still printing strong; (ii) Electrical construction segment operating margin — below 11.5% would confirm the mix-shift compression bear case; (iii) any disclosure of customer concentration above ~15% (currently undisclosed) would meaningfully change risk profile.
- **Q2 2026 hyperscaler capex calls (late July/early August).** MSFT, META, AMZN, GOOG forward capex guidance. A sequential cut of >10% on any of the four, or commentary about "moderating data-center spend," is a direct read-through.
- **Cantor / UBS / Baird price-target revisions.** The dispersion in PTs ($675 to $1,123) [11] suggests the sell-side has not converged. A median revision *down* by more than $100 within 90 days would indicate cracks in the consensus.
- **Quanta Q2 2026 print** (~early August). If PWR's Technology & Load Center segment posts >100% growth and starts naming specific hyperscaler customers, that suggests share is moving toward PWR's grid+inside-the-fence integrated pitch.
- **Comfort Systems modular capacity disclosures.** Watch for FIX disclosing physical sq ft additions to its modular plants — that is the leading indicator of mechanical-scope share shift.
- **NECA / IBEW apprentice intake.** Aggregated intake numbers for 2026 cohort year are published in Q3. A surprise upward surge (>20% YoY) would signal the labor moat eroding faster than base rates suggest.
- **Insider transactions.** Any further large CEO/CFO sales above $900 would compound the signal from the March transaction.

## What I could not verify
- Customer concentration. EMCOR has consistently refused to name hyperscaler customers or disclose top-customer concentration on calls [1]; Microsoft, Meta, Google, AWS, Oracle, and CoreWeave are all *probable* customers based on geographic footprint, but specific contract sizes are not public.
- Specific dollar split of Network & Communications RPO ($4.46B at YE2025, ~$7B+ implied at Q1 2026 [2]) between US-East (Northern Virginia/Chicago), US-West (Phoenix/Reno), and Southeast (post-Miller). Management discusses it qualitatively but does not disclose by geography.
- Exact supervision-to-craft ratio target and the absolute size of EMCOR's general-foreman pool. Guzzi has identified the constraint qualitatively but not quantified it.
- Margin headroom on GMP/cost-plus contracts vs. fixed-price. Management says deliberate mix is moving toward GMP in new geographies, but the relative profitability gap is not disclosed.
- Net liquid-cooling content per MW. Industry reports point to a $2,500–$4,500/kW capex premium for D2C [8], but EMCOR's labor-hour share of that premium versus OEM gear share is not publicly broken out.
- The precise post-March-2026 share count and whether the $500M buyback authorization has been deployed during the run from $730 to $921 [13].

## Sources
[1] https://www.fool.com/earnings/call-transcripts/2026/04/29/emcor-eme-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q1 2026 EMCOR earnings call transcript: supervision-as-bottleneck quote, prefab catalog approach, liquid cooling driving mechanical, Miller training program.
[2] https://www.investing.com/news/company-news/emcor-q1-2026-slides-record-revenue-ai-boom-lifts-backlog-93CH-4646176 — retrieved 2026-05-10 — Q1 2026 results: $4.63B revenue (+19.7%), EPS $6.84, RPO $15.62B, electrical N&C +50%, mechanical N&C +86%, full-year guide raised to $18.5–19.25B revenue and $28.25–29.75 EPS.
[3] https://stockanalysis.com/stocks/eme/statistics/ — retrieved 2026-05-10 — Current stats: $921.64 close, $40.96B market cap, $40.56B EV, forward P/E 31.11, EV/EBITDA 21.91, short interest 2.08% of float, beta 1.17.
[4] https://fortune.com/2026/03/02/ai-data-centers-electrician-shortage-gen-z-training-careers/ and https://www.cnbc.com/2026/03/18/ai-data-center-buildout-jobs-salary-skilled-traders-worker-shortage.html — retrieved 2026-05-10 — Electrician shortage: 300K+ shortfall, 20K/yr retirements, 45–70% of DC cost is electrical, $120K–$250K compensation packages, Oracle project slippage 2027→2028.
[5] https://ibew.org/electrical_worker/the-data-center-surge-a-new-generation-of-ibew-jobs/ — retrieved 2026-05-10 — IBEW data on Northern Virginia data-center work: Local 26 performs ~97% of regional work; Dynalectric DC's link to NECA D.C. leadership.
[6] https://www.businesswire.com/news/home/20250114453472/en/EMCOR-Group-Inc.-Announces-Agreement-to-Acquire-Miller-Electric-Company — retrieved 2026-05-10 — Miller Electric acquisition: $865M cash, closed Feb 2025, $805M revenue / $80M EBITDA, 24% data center mix, Southeast geographic fill.
[7] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ and https://oilprice.com/Energy/Energy-General/US-Power-Boom-Triggers-Global-Gas-Turbine-Shortage.html — retrieved 2026-05-10 — Gas turbine backlogs at GE Vernova (~80 GW into 2029), Mitsubishi (sold into 2028), 5-year wait at all three majors.
[8] https://introl.com/blog/building-100kw-gpu-racks-power-cooling-architecture and https://datacentremagazine.com/top10/top-10-direct-to-chip-cooling-companies-22-04-2026 — retrieved 2026-05-10 — Rack densities (GB200 NVL72 at 120 kW; Vera Rubin NVL144 at 600 kW projected); D2C cooling now dominant for 50–150 kW; CDU/manifold ecosystem co-developed by Vertiv/Schneider with NVIDIA; capex premium ~$2,500–$4,500/kW.
[9] https://newsletter.semianalysis.com/p/ai-capacity-constraints-cowos-and and https://info.fusionww.com/blog/inside-the-ai-bottleneck-cowos-hbm-and-2-3nm-capacity-constraints-through-2027 — retrieved 2026-05-10 — CoWoS-L allocation (NVIDIA >70% share of CoWoS-L, >60% of total CoWoS); HBM3e sold out for 2026 per SK Hynix.
[10] https://www.stocktitan.net/sec-filings/EME/10-k-emcor-group-inc-files-annual-report-62a78bc14854.html — retrieved 2026-05-10 — 2025 10-K segment mix: construction ~72% of revenue, building services 21%, industrial services 7%; electrical 30% / mechanical 42% of revenue; ~97% U.S.
[11] https://www.prnewswire.com/news-releases/quanta-services-reports-first-quarter-2026-results-302758147.html and https://public.com/stocks/eme/forecast-price-target — retrieved 2026-05-10 — Quanta Q1 2026 record backlog $48.5B with Technology & Load Center segment +70–110%; EME 52-week range $427.90–$951.95; analyst PT dispersion from $675 to $1,123.
[12] https://www.tradingview.com/news/zacks:9d6bbdad0094b:0-emcor-jumps-49-ytd-here-s-how-to-play-the-stock-at-25-34x-p-e/ and https://qz.com/is-comfort-systems-riding-on-the-ai-infrastructure-growth-wave — retrieved 2026-05-10 — EME +49% YTD as of Zacks article (with shares at $832); 5-year median forward P/E 17×; Comfort Systems ~40% revenue tech-related, forward P/E ~25×; MasTec 2026E revenue growth +31.5%.
[13] https://www.gurufocus.com/insider/86328/anthony-guzzi — retrieved 2026-05-10 — CEO Anthony Guzzi sold 36,000 shares at $729.48 on March 5, 2026 ($26.3M); 15 sales, 0 buys over 5 years; $500M buyback authorization approved December.