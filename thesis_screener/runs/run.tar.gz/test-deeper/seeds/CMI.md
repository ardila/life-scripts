# CMI — Cummins Inc.

## Where this sits in the AI stack
Cummins manufactures large reciprocating engines, gensets, alternators, controls, switchgear, and aftermarket service contracts for the **power layer** that sits behind every megawatt of AI compute. The two relevant SKU families are: (i) the **QSK95** high-horsepower diesel platform (3–4 MW standby) used as the conventional Tier III/IV backup behind hyperscale halls; and (ii) the **HSK78G** spark-ignited natural-gas reciprocating engine (~2 MW per unit at 44.2% electrical efficiency, designed for **prime/peaking** duty)[3][12]. Until 2024 the data-center exposure was almost entirely standby diesel. In 2025–26 the mix is shifting toward HSK78G-class **continuous gas** for behind-the-meter prime power as hyperscalers route around 36–84-month grid interconnection queues[4][14]. The exposure is to the AI **buildout** (capex installed per MW of IT load), not to inference run-rate or chip cycles.

## Snapshot
- **Price:** $681.96 (2026-05-08 close)[1]
- **Market cap:** ~$92B (May 2026, derived from price × ~135M shares; Yahoo data shows $90.9B late April)[1][15]
- **52-week range:** $305.13 – $718.08[1]
- **Forward P/E:** ~24.7× FY26 consensus EPS (high-teens to low-20s depending on data source/date; GuruFocus 20.8× as of April 22)[7][8]
- **EV / NTM revenue:** ~2.5–2.6× (EV ~$95B on Yahoo per April data; FY26 revenue guided +8–11% off $33.67B 2025 base = ~$37B)[15][16][17]
- **Consensus 12-month price target:** $619.92 average / $649–$699 across providers; implies **‑5% to +3%** from spot — i.e. the stock has run **through** the sell-side[6]
- **YTD total return:** +44.8% per one provider through early May 2026; the stock is up roughly 2× over the prior 12 months and trades within 5% of its 52-week high[6][1]
- **Short interest (% of float):** n/a — not retrieved with confidence from primary sources in this session

## Moat — what it is physically made of
The "Cummins moat" is **not** software. It's the unglamorous physical and contractual scaffolding around a 90-tonne lump of iron. Decompose it:

**1. High-horsepower engine IP and tooling (durable, 10+ years).** The QSK95 (95-litre, 16-cyl, ~3.5 MW) and HSK78G (78-litre, 12-cyl natural-gas) require multi-year combustion calibration, materials work on cylinder liners and turbochargers, and crankcase tooling that is not cleanly purchasable. The HSK78G's 80,000-hour major overhaul interval and 44.2% electrical efficiency at 50Hz are at the frontier for spark-ignited reciprocating gas[3]. A new entrant from scratch is a 7–10 year project; the credible challengers (Caterpillar, Rolls-Royce mtu, INNIO Jenbacher, Wärtsilä) already exist and have parity products. **Moat vs. greenfield: high. Moat vs. CAT/mtu: thin to none on the engine itself.**

**2. Manufacturing capacity in the right places (durable for ~3 years, the length of current lead times).** Cummins doubled QSK95 capacity at Seymour, IN through 2025 and announced a ~$150M Fridley, MN expansion in Feb 2026 to lift QSK95 output another ~30%[2]. Lead times still extend "into the back half of '28" per management at the Q1 2026 call[5]. Caterpillar in parallel is scaling **3×** large-reciprocating-engine capacity by 2030 (~15 GW/yr incremental)[9]. Rolls-Royce is targeting **2.2×** its Mankato MN mtu Series 4000 output[10]. **Read: capacity is being multiplied across the field. The "you can't get a genset" moat dissolves around 2027–28.**

**3. Distribution + service network (the real moat, durable 15+ years).** Cummins' wholly-owned distribution arm (the **Distribution segment**, $3.1B Q1 2026 rev, +7% YoY, with management citing "data center applications" as the driver[16]) covers OEM-direct service for the ~25-year operating life of an installed genset. For a hyperscaler running 30+ MW of standby behind a $3B facility, the **switching cost is not the engine — it's the parts network and 24/7 on-site service contract.** This is closer to the Otis elevator model than to a hardware moat. CAT's dealer network is comparable in NA; mtu/Kohler/Generac are weaker in HHP service density.

**4. Hyperscaler co-engineering relationships (medium durability).** Management has disclosed (qualitatively) a partnership "with a major hyperscaler account" to **model genset response against live AI training workloads** — i.e., the transient load profile of synchronous gradient-update spikes across 100k+ GPUs[11]. This is meaningful because AI loads behave nothing like a conventional colo: SemiAnalysis has documented GW-scale **second-by-second power swings** during training that can trip standard generator controls and even threaten grid stability[19]. The co-engineering work is genuine moat — but Caterpillar and mtu are doing the same work with their hyperscaler accounts.

**5. Accelera (hydrogen / electrolyzer / fuel cell) — NOT a moat.** Cummins booked $458M in 2025 charges exiting electrolyzers and another $199M Q1 2026 charge selling its low-pressure fuel-cell business to Alstom[13]. Accelera is now ~1.4% of revenue and shrinking. Treat as a strategic concession that the zero-emissions stack is being won by **solid-oxide fuel cells (Bloom)** and **batteries**, not Cummins' PEM-flavored bets. Honest read: management has correctly cut the losses.

**Net:** the durable moat is the **distribution+service network** plus the multi-year **hyperscaler service contracts** that come bundled with installed gensets. The "supply-constrained engine OEM" moat is real today but is being deliberately competed away by capacity additions from CAT, mtu, and Cummins itself.

## AI buildout bottleneck map
The gating constraints on the next 24 months of AI buildout, in roughly the order they bite, with CMI's position:

| Bottleneck | Lead time | CMI position |
|---|---|---|
| **Grid interconnection** (substation + transformer + utility studies) | 36–84 months[14] | **Beneficiary** — drives behind-the-meter demand for gas reciprocating engines, exactly the HSK78G use case |
| **HV transformers** (GSU, ~500MVA class) | Was 24–30 mo pre-2020, now ~5 yrs[14] | Indirect beneficiary; complements gensets but not CMI revenue |
| **Heavy-duty gas turbines** (GE Vernova HA-class, Mitsubishi M501JAC, Siemens SGT) | 30+ months; GE Vernova sold out **through 2030**[18][14] | **Beneficiary by substitution** — reciprocating engines are the only fast alternative for prime power |
| **Large reciprocating engines** (CMI QSK95, CAT 3500/G3500, mtu Series 4000) | 24–30 months; CMI specifically into back-half 2028[5][14] | **Constraint owner** — direct seller |
| **Solid oxide fuel cells** (Bloom SOFC) | 16–18 months[14]; Bloom targeting 2 GW/yr capacity by end-2026[19] | **Exposed substitute** — see Project Jupiter below |
| **CoWoS-L / HBM3e / Blackwell wafer-out** | TSMC CoWoS-L and SK Hynix HBM3e are gated to mid-2026 | Indifferent — CMI sells the same diesel whether the GPU is Blackwell or MI400 |
| **Liquid cooling >100 kW/rack, electrical contractors, switchgear** | Severe but supplier-specific | Indifferent; Vertiv / Eaton / nVent territory |
| **Kernel/compiler talent, training data** | Talent-bound | Indifferent |

The bottleneck where **CMI is most clearly a beneficiary** is the gas turbine shortage. With GE Vernova's slot book full through 2030[18], the only physical way to put a new 200–500 MW prime-power load behind the meter on a 2027 schedule is to stack 100–250 reciprocating engines (HSK78G class). The xAI Memphis precedent — 41 turbines at Southaven, plus five 380 MW Doosan units — shows hyperscalers will buy whatever they can permit and ship[20]. That said, **Caterpillar is the bigger named beneficiary** of this dynamic so far: CAT's Q1 2026 power-generation revenue grew +41% to $2.82B vs. Cummins' Power Systems +19% to $1.96B[9][16].

## Competitive teardown
The competitive question is not "is Cummins beating NVIDIA" — it's "is Cummins beating Caterpillar, Rolls-Royce mtu, and Bloom Energy on the **specific axes that matter for AI workloads**."

**vs. Caterpillar (the direct peer):**
- **HHP backup diesel ≥2 MW:** rough parity. Both have multi-year backlogs. CAT has a slightly larger NA dealer footprint; CMI has a slightly broader international service presence (esp. China/India/Saudi)[2][4].
- **Prime power gas reciprocating:** CAT's G3500 platform competes with HSK78G. CAT announced a **2.1 GW prime-power gas genset agreement** in 2026[9] — CMI has not disclosed an order of that scale publicly. **Edge: Caterpillar.**
- **Capacity expansion velocity:** CAT going 3×; CMI going ~1.3× on QSK95. **Edge: Caterpillar.**
- **Revenue mix exposure:** CAT power gen is more concentrated in data center per dollar of segment revenue, but Cummins gets compounding lift from its **Distribution** segment service tail. Roughly comparable AI buildout torque per dollar of revenue.
- The relevant evidence: CAT Q1 2026 power-gen +41% YoY vs. CMI Power Systems +19% YoY[9][16]. CAT is taking share at the margin in 2026.

**vs. Rolls-Royce mtu Series 4000:** mtu's flywheel-battery hybrid eliminates transfer delays — a meaningful technical edge for facilities that can't tolerate the 8–10 second start lag on a conventional diesel. mtu's new 20-cyl L64 hits 2.8 MW in 45 seconds[10]. **Edge: mtu on the niche of zero-transfer-time deployments; CMI competitive on bulk standby.**

**vs. Bloom Energy SOFC (the existential question):** Oracle's Project Jupiter (New Mexico, up to 2.45 GW) replaced the originally-planned **gas turbines AND diesel backup** with Bloom fuel cells — a fully islanded microgrid, "no diesel, no turbines, no batteries"[21][22]. Oracle has now committed up to **2.8 GW of Bloom SOFC** with 1.2 GW already in progress[22]. This is the first proof-point that a hyperscaler will skip the genset entirely for a greenfield AI campus. Bloom is targeting 2 GW/yr SOFC capacity by end-2026[19]. Read: this is real but small relative to the **~50 GW/yr** of incremental AI capacity coming online over the next 3 years; SOFC supply is also constrained.

**vs. GE Vernova / Mitsubishi / Siemens (gas turbines):** Reciprocating engines win on (a) faster startup, (b) better part-load efficiency, (c) modular scaling in 2 MW increments vs. 380 MW slabs[24]. Gas turbines win on $/kW at scale and footprint. The split is being made in real time: Meta Hyperion uses **both** — H-class turbines AND reciprocating engines on the same campus[20]. **Read: this is share-coexistence, not displacement.**

**vs. Kohler/Rehlko, Generac, Atlas Copco, Himoinsa:** these compete mainly sub-1 MW. Largely irrelevant to the AI thesis. Top-5 (CAT, CMI, mtu, Generac, Kohler) hold ~63–72% of the data center genset market combined; CAT + CMI specifically dominate ≥2 MW[4][8].

## Bull case — technical
For CMI to outperform from a ~$92B / ~24× forward EPS starting point, the following technical conditions need to hold:

1. **Grid interconnection queues stay >36 months** through 2027–28. As long as utilities can't deliver a megawatt under three years, hyperscalers continue building behind-the-meter prime power, which is structurally favorable to large reciprocating engines. *Base rate caveat:* utility timelines historically improve only on the order of 5–10% per year — meaningful relief is multi-year.
2. **Gas turbine slot book stays full to 2030.** GE Vernova has signed 21 GW of new agreements in Q1 2026 alone[18]. As long as this holds, every GW of prime-power demand spills over to HSK78G-class reciprocating engines.
3. **Bloom SOFC supply remains <5 GW cumulative** through 2028. SOFC manufacturing scaling is real but slow; Bloom at 2 GW/yr by end-2026 cannot absorb the AI buildout. Diesel + gas reciprocating remains the only ship-by-2027 option for >10 GW of incremental prime power.
4. **AI capex stays at hyperscaler-guided run-rate** (~$400B/yr 2026 across the top 5). Standby genset spend tracks IT load installed at roughly $300–600/kW. ~$3.5B of CMI's 2025 revenue was data-center-related[7]; this could plausibly double to $7B+ by 2027 if buildout pace holds.
5. **Caterpillar's 3× capacity expansion stays on its 2030 timeline** (not earlier). If CAT pulls in capacity to 2027, CMI's pricing power compresses faster.

If 1–4 hold, Power Systems revenue compounds 15–20% for two more years at 25%+ EBITDA margins. That implies $4B+ of segment EBITDA by 2027 vs. ~$2.4B at 2025 run-rate, and total company EPS in the $25–28 range. **Base rate on technology displacement at this point in cycle:** the historical analog is post-2000 telco-equipment OEMs — peak earnings tend to coincide with peak buildout. The stock typically rolls 1–2 quarters **before** revenue.

## Bear case — technical
The short-seller version of this story, written honestly:

1. **The genset is a 25-year asset; the AI demand wave is 5 years.** Hyperscalers may double-order in 2025–26 against capacity that arrives in 2027–28, and find themselves with surplus standby by 2029. Genset orders are not a recurring SaaS-like revenue stream; they're lumpy capex tied to facility nameplate. A capex pause in late 2027 looks like a 30–40% bookings drop.
2. **Power Systems EBITDA margin of 29.5% Q1 2026[16] is a peak number.** It was 23.6% a year earlier. Margins this high attract capacity. The 6-point margin expansion in 12 months is partly "net tariff recovery and one-time cost recoveries" per management — these are not durable[16].
3. **Caterpillar is taking share.** CAT power-gen +41% vs CMI Power Systems +19% in Q1 2026[9][16]. CAT's $63B backlog with orders into 2028 implies CAT has captured more of the multi-year hyperscaler commitments[9]. If this gap persists for 2 more quarters, the bull case on Cummins-specific share is wrong even if the bull case on the buildout is right.
4. **Bloom Energy / SOFC scaling is faster than expected.** Oracle's 2.8 GW commitment was signed in ~6 months. If 2–3 more hyperscalers follow the Project Jupiter playbook for greenfield campuses, the **prime-power** opportunity for reciprocating engines compresses dramatically. Note: this does not eliminate **standby** demand, but standby gensets are ~$300–500/kW vs. prime power gensets at $1,500–2,500/kW — a 5× revenue/MW haircut.
5. **Cummins ex-data-center is a low-growth cyclical truck-engine business.** Q1 2026 total revenue +3% YoY[16]. Engine segment exposure to Class 8 truck cycle is unchanged. If data-center growth normalizes, the multiple compresses to the historical 12–15× P/E range, implying $350–450/share rather than $680.
6. **Trade compression from analyst PTs.** Average consensus PT $620 is **below** spot[6]. The stock has out-run the sell side. The marginal incremental buyer at $680 needs the sell-side to *raise* targets — which requires either a guidance raise (already happened Q1 2026) or a multi-quarter pattern of unexpected upward surprises.

Base rate on capex-cycle stocks at peak multiple: historically (telco equip 2000, oil services 2014, semiconductor capital equipment 2021) the stock peaks **6–9 months before** the order book peaks. Volume sell-through can still surprise upward while the stock derates.

## Market view check
At ~$680 and ~25× forward EPS, the market is pricing CMI as a **structurally growthier business** than the 12–15× cyclical it traded at pre-2024. The implicit assumption is that Power Systems compounds at 15%+ for 3+ years and that this growth is durable, not cyclical. Consensus PT averaging **below** spot[6] tells you the buy-side has front-run the sell-side; the marginal flow is momentum/passive into AI baskets, not fundamental DCF. The technical reality I see is more nuanced: the **2-year window** is genuinely strong (grid + turbine bottlenecks gift the reciprocating engine vendors a windfall), but Caterpillar's faster capacity ramp and Bloom's prime-power displacement risk are not in consensus. I'd characterize this as **fairly priced on the 2-year fundamental, expensive on the 5-year**. The asymmetry has compressed since the run.

## 90-day falsifiers
Specific things observable by ~August 2026 that would update the thesis:

1. **Q2 2026 Power Systems revenue growth.** Above 22% YoY validates that CMI is closing the gap with CAT's +41%; below 17% confirms share loss.
2. **Q2 2026 Power Systems EBITDA margin.** Above 29.5% (Q1 print) means pricing power is intact; below 27% means the one-time recoveries flagged in Q1 are fading.
3. **Caterpillar Q2 2026 power-gen revenue growth.** A second print of >35% YoY confirms CAT taking share. <30% suggests Q1 was a timing anomaly.
4. **Any disclosed hyperscaler PPA awarding ≥500 MW prime-power gas reciprocating to a specific OEM.** Watch for Microsoft, Meta, Anthropic, OpenAI/Stargate, Oracle, AWS announcements. CMI named: bull. CAT or mtu named: bear for CMI.
5. **Bloom Energy production print.** Q2 2026 Bloom revenue and capacity ramp. >40% YoY revenue growth suggests SOFC scaling faster than the bull case assumes.
6. **GE Vernova turbine slot book disclosure at Q2 call.** If GEV opens 2028 slots (i.e., lead times compress), the reciprocating engine substitution thesis weakens.
7. **CMI capacity announcement.** Any further Fridley/Seymour expansion announcement beyond the Feb 2026 $150M commitment — signals management sees demand extending past 2028.
8. **Hyperscaler capex guidance from MSFT, META, GOOG, AMZN, ORCL in their July 2026 prints.** Sequential cut >10% would be a clear sector signal; a raise extends the runway.

## What I could not verify
- **Cummins' specific share of named hyperscaler awards.** Management has not disclosed customer names, GW awarded, or contract values. Most evidence is qualitative ("a major hyperscaler account").
- **Cummins' data-center revenue inside the Distribution segment** vs. Power Systems. The $3.5B 2025 data-center figure was cited as spanning both segments[7], but the split is not disclosed.
- **Short interest as % of float** as of May 2026. Sources reference the figure exists but I did not retrieve a clean number.
- **Power Systems backlog dollar figure.** Cummins does not break this out publicly the way Caterpillar discloses its $63B total backlog. Management has only said "into 2028" with "active conversations for 2029+"[7].
- **HSK78G unit shipments / production rate.** Cummins discloses capacity actions but not units shipped per quarter for HHP gas vs. diesel mix.
- **Mix of standby diesel vs. prime gas in 2026 incremental revenue.** This is the single most important number for forecasting durability — standby and prime have very different $/MW economics — and it is not disclosed.
- **Independent MLPerf-equivalent benchmarking** of any of these gensets (there is no such benchmark in this industry; OEM specs are self-reported).
- **YTD return** — sources disagreed (+45% vs +6%); I could not reconcile cleanly without a live data terminal.

## Sources
[1] https://finance.yahoo.com/quote/CMI/ — retrieved 2026-05-10 — CMI spot price $681.96 (5/8 close), 52-week range $305.13–$718.08
[2] https://www.swiftequipment.com/how-cummins-caterpillar-kohler-generators-are-powering-the-data-center-boom-in-2025-4/ — retrieved 2026-05-10 — Fridley MN $150M expansion and QSK95 18-month lead times; market share commentary
[3] https://www.cummins.com/sites/default/files/2019-08/Spec-Sheet-HSK78G-50Hz_2.pdf — retrieved 2026-05-10 — HSK78G technical specifications (78L, 12cyl, ~2 MW, 44.2% electrical efficiency, 80k hr overhaul)
[4] https://www.mordorintelligence.com/industry-reports/data-center-generator-market — retrieved 2026-05-10 — market structure: top-5 share 63-72%, CAT/CMI dominate >2MW segment, top-5 named
[5] https://www.fool.com/earnings/call-transcripts/2026/05/05/cummins-cmi-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q1 2026 transcript; 95L lead times into back-half 2028; capacity expansions
[6] https://stockanalysis.com/stocks/cmi/forecast/ — retrieved 2026-05-10 — analyst PT consensus $619.92 average, range $490–$703; consensus rating Buy
[7] https://www.tikr.com/blog/cummins-stock-has-nearly-doubled-in-a-year-is-the-data-center-rally-fully-priced — retrieved 2026-05-10 — $3.5B 2025 data center revenue (vs $2.6B 2024); backlog "into 2028"; $1.96B Q1 2026 Power Systems
[8] https://www.gurufocus.com/term/forward-pe-ratio/CMI — retrieved 2026-05-10 — forward P/E 20.83 (April 22 2026)
[9] https://www.prnewswire.com/news-releases/caterpillar-reports-first-quarter-2026-results-302758655.html — retrieved 2026-05-10 — CAT Q1 2026 power-gen +41% to $2.82B; $63B backlog; 3× large engine capacity by 2030; 2.1 GW prime power gas genset deal
[10] https://www.rolls-royce.com/media/press-releases/2025/03-06-2025-rr-powers-data-center-growth-with-increased-investment-in-us-manufacturing.aspx — retrieved 2026-05-10 — mtu Mankato MN +120% production by 2026; new L64 engine 2.8 MW in 45 sec
[11] https://www.cummins.com/en-na/news/2025/11/24/how-ai-shaping-future-data-center-power-infrastructure-design — retrieved 2026-05-10 — Cummins co-engineering with hyperscaler for AI workload-calibrated genset modeling
[12] https://www.cummins.com/news/releases/2019/03/05/cummins-makes-bold-move-and-introduces-new-technology-new-natural-gas — retrieved 2026-05-10 — HSK78G product positioning for prime/peaking
[13] https://fuelcellsworks.com/2026/02/05/electrolyzer/major-blow-to-hydrogen-sector-as-cummins-stops-electrolyser-sales — retrieved 2026-05-10 — $458M 2025 electrolyzer exit charges; $199M Q1 2026 fuel-cell sale charge to Alstom
[14] https://avanzaenergy.substack.com/p/data-centers-are-killing-the-grid — retrieved 2026-05-10 — grid interconnection 36–84 months; HV transformer lead times now ~5 years; SOFC 16–18mo; recip 24–30mo; turbines 30+mo
[15] https://finance.yahoo.com/quote/CMI/key-statistics/ — retrieved 2026-05-10 — market cap ~$90.9B and EV ~$95.4B
[16] https://www.sec.gov/Archives/edgar/data/26172/000002617226000013/cmi2026q18-kex99.htm — retrieved 2026-05-10 — Cummins Q1 2026 8-K exhibit: $8.4B rev, $4.71 EPS, Power Systems $1.956B +19% at 29.5% EBITDA, Distribution $3.116B citing data center applications; FY26 guidance +8–11% revenue
[17] https://www.macrotrends.net/stocks/charts/CMI/cummins/revenue — retrieved 2026-05-10 — 2025 full-year revenue $33.67B
[18] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — GE Vernova 80 GW gas turbine backlog; 21 GW signed Q1 2026; sold out through 2030
[19] https://newsletter.semianalysis.com/p/how-ai-labs-are-solving-the-power — retrieved 2026-05-10 — SemiAnalysis on onsite gas; Bloom Energy 2 GW/yr SOFC capacity target by end-2026
[20] https://www.tomshardware.com/tech-industry/artificial-intelligence/u-s-electricity-grid-stretches-thin-as-data-centers-rush-to-turn-on-onsite-generators-meta-xai-and-other-tech-giants-race-to-solve-ais-insatiable-power-appetite — retrieved 2026-05-10 — xAI 41 turbines Mississippi, five 380 MW Doosan units; Meta Hyperion using both turbines + reciprocating engines
[21] https://www.datacenterknowledge.com/build-design/oracle-s-project-jupiter-ditches-gas-turbines-for-bloom-fuel-cells — retrieved 2026-05-10 — Project Jupiter pivot from turbines+diesel to 100% Bloom SOFC microgrid
[22] https://www.datacenterdynamics.com/en/news/oracle-to-deploy-up-to-245gw-of-bloom-fuel-cells-at-new-mexico-data-center/ — retrieved 2026-05-10 — Oracle 2.45 GW (and up to 2.8 GW) Bloom SOFC commitment; 1.2 GW in progress
[23] https://www.powermag.com/data-centers-are-turning-to-gas-generators-for-prime-power-to-eliminate-long-lead-times-for-grid-connections/ — retrieved 2026-05-10 — industry shift to gas reciprocating for prime power behind grid queues
[24] https://www.power-eng.com/gas/turbines/turbines-vs-reciprocating-engines/ — retrieved 2026-05-10 — technical comparison reciprocating engines vs. gas turbines: faster startup, better part-load, modularity vs. $/kW at scale