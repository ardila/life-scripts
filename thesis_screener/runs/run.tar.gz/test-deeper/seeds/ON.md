# ON — onsemi (ON Semiconductor Corporation)

## Where this sits in the AI stack
onsemi sells discrete power semiconductors (silicon MOSFETs, IGBTs, Field-Stop 7 IGBT, silicon-carbide MOSFETs/modules under the EliteSiC brand, and an emerging vertical-GaN line), analog/mixed-signal ICs (the new "Treo" 65nm BCD platform), intermediate-bus controllers, and CMOS image sensors. In the AI buildout it sits **upstream of the GPU**, in the power-conversion tree from grid to die: medium-voltage AC→800VDC rectification in sidecar racks, 800V→48V intermediate-bus conversion (with partners like Flex Power Modules), 48V→12V/0.8V multi-phase regulation, and battery-backup units (BBU). It does **not** make compute, networking, HBM, or optics. AI data center revenue was ~$250M in 2025 (~4% of total) and is guided to ~$500M in 2026 [1][2].

## Snapshot
- **Price:** $103.20 (2026-05-08 close; markets closed on 2026-05-10, a Sunday — most recent print) [3]
- **Market cap:** $40.4B (391.87M shares × $103.20) [3]
- **52-week range:** $38.69 – $105.90 [3]
- **Forward P/E:** ~24.4× on FY26 consensus EPS ≈ $2.90 (recently re-rated after Q1 beat; was ~34× pre-beat on lower estimates) [3][4]
- **EV / NTM revenue:** ~6.0× (TTM 6.81×; NTM revenue run-rate ≈ $6.3–6.7B against EV ≈ $41B incl. net debt after the $1.3B 0% convert) [3][5]
- **Consensus 12-month price target:** $103.45 (effectively flat to spot — the rally has caught up to the sell-side) [4]
- **YTD total return:** +90.6% [3]
- **Short interest:** 7.72% of float [3]

## Moat — what it is physically made of
onsemi's moat is **not** ecosystem-software (it has nothing analogous to CUDA/NCCL/Triton). It is a stack of mostly **physical** assets that decay slowly but visibly:

1. **End-to-end SiC vertical integration.** onsemi is the only Western power-semi vendor that owns boule growth → wafer → epi → device → module under one roof, after acquiring GTAT (boules) in 2021. In 2026 it ramped 200mm SiC volume production at Bucheon, Korea, claiming ~80% more die per wafer vs. 150mm [6][7]. STMicroelectronics leads SiC share at ~35%, onsemi second at ~23–25%, Infineon ~15%, Wolfspeed ~11% and in Chapter 11 [6][7][8]. Durability: **high, 3–5 years**, then erodes as Chinese players (BYD Semi, StarPower, SICC) close the 200mm gap.

2. **Auto-qualified, locked-in socket positions.** AEC-Q101/Q100 qualification cycles run 18–36 months. Once a SiC traction-inverter module is designed into a vehicle platform, switching costs ≈ a new platform refresh (5–7 years). onsemi has design-ins at VW (next-gen PPE/SSP platform), BMW, Hyundai, NIO, Zeekr, and is positioned on ~55% of new-EV models at the 2026 Beijing Auto Show; ~30% of revenue from China [9][10]. Durability: **high but slow-growth** — the EV demand curve has flattened.

3. **Vertical-GaN IP fence.** Most commercial GaN is lateral GaN-on-Si (Navitas, Power Integrations, Innoscience). onsemi has GaN-on-GaN bulk substrates from its Syracuse NY fab with ~130 issued/pending patents, sampling 700V and 1200V devices (volume late 2026) [11][12]. vGaN is ~3× smaller die for the same FOM and runs at higher frequency — material for the 1MW-rack 800V architecture. Durability: **uncertain but potentially high** — only ON and academic groups have working vGaN; if real customer yields hold, this is a defensible position. Falsifier: lateral-GaN incumbents reaching ≥1200V at competitive Rds(on)·A.

4. **Treo BCD platform.** A 65nm bipolar-CMOS-DMOS process targeting analog/mixed-signal across power management, sensor interface, and isolated drivers — onsemi's late and necessary catch-up to TI's LBC9/LBC11 and Infineon's smart-power flows. Revenue +2.5× sequentially off a small base; targeted 60–70% gross margin [13]. Durability: **low-medium** — TI and ADI have 20+ years of analog catalog depth and 100k+ active SKUs; onsemi cannot replicate that catalog moat in three to five years.

5. **CMOS image-sensor pole position in ADAS.** Hyperlux family is co-design partner with Mobileye and Renesas R-Car. Sony and Omnivision are the only real competitors here. Durability: **high in auto, irrelevant to AI**.

Net: a real moat on auto-SiC and vGaN substrate science, a weak moat on analog/mixed-signal, no moat at all on the AI server power tree socket-by-socket — those are being competed for on price, density, and time-to-design-in.

## AI buildout bottleneck map
The 24-month gating constraints, and where ON sits on each:

- **Power generation + grid interconnect** (turbine backlogs at GE Vernova, Siemens Energy are 2–4 years; Texas/Virginia interconnect queues 18–36 months): **indifferent / indirect beneficiary** — the more constrained grid power is, the more valuable on-rack efficiency becomes, which pulls SiC/GaN content per rack.
- **CoWoS-L advanced packaging at TSMC** (Blackwell/Rubin gated, ~80–90k wpm 2026 exiting): **indifferent**, onsemi does not consume or supply CoWoS.
- **HBM3e/HBM4 yield** (SK hynix, Samsung, Micron): **indifferent**.
- **800VDC sidecar power architecture for 1MW racks** (the big new opening): **direct beneficiary**. NVIDIA's October 2025 announcement named ten silicon partners on 800VDC: ADI, Infineon, Innoscience, MPS, Navitas, onsemi, Renesas, ROHM, STMicro, TI [14]. ON is one of the few with both **SiC for the front-end rectifier** and **vGaN for the 16:1 / 64:1 DC-DC step-downs**.
- **Liquid cooling at >100kW/rack** (Vertiv, CoolIT, JetCool): **indifferent**, but enables the rack densities that pull more $-power-content per kW.
- **Multi-phase regulators at the GPU** (the "last-inch" 48V→0.8V smart-power-stage step): **non-participant today**. This socket sits with MPS and Infineon. MPS displaced Vicor in H100 and held the GB200/GB300 socket; ON is not a credible bidder here in 2026 [15][16].
- **Battery-backup units (BBU)** for ride-through (now mandatory at hyperscalers): **direct supplier** via the Flex Power partnership and SiC cascode JFETs [17].
- **Kernel/compiler talent**: irrelevant.

Read: ON benefits from one specific bottleneck — the 800V transition — and is exposed-as-customer to none. The economic question is what share of the 800V dollar content it captures versus Infineon, TI, Navitas.

## Competitive teardown
The competition is socket-by-socket along the power tree, not platform-vs-platform:

| Stage of power tree | Incumbent / leader | onsemi position |
|---|---|---|
| Grid → rack-level rectification (MV AC → 800VDC, sidecar) | Delta, Eaton, Vertiv at system level; Infineon + STMicro SiC inside | Supplier of SiC MOSFETs to several sidecar vendors; not a system OEM [14][18] |
| 800V → 48V intermediate bus converter (high-density DCX/LLC) | Vicor (legacy), MPS, Flex Power, Delta | onsemi is the silicon for Flex's 3kW BMR313 module using FD6000 controller — partnership is real, but Flex is one of several module makers [17] |
| 48V → 12V regulation | MPS (dominant), Infineon (TDM/TLF), Renesas | ON not currently in this socket at hyperscalers |
| 12V → 0.8V multi-phase / smart power stage at GPU | MPS dominant (won H100 from Vicor), Infineon (TDA family) | ON not a credible bidder on Blackwell/Rubin generation |
| BBU / hold-up | Diversified: ON, Infineon, ST, TI | ON has SiC-cascode-JFET + PowerTrench Si MOSFET combo positioned here [17] |
| Future 800V silicon (vGaN/SiC) for Kyber 2027 | Infineon, Navitas, ON, TI all named partners | ON differentiated on vGaN; Navitas on GaN-on-Si; Infineon on integrated modules; TI on full-stack reference design [11][14][19] |

**Infineon** is the strongest competitor in absolute terms: it is guiding €1.5B AI power revenue FY26 and €2.5B FY27 — roughly 3× to 5× larger than onsemi's AI data-center book. Infineon's advantage is **integrated power modules** (MOSFET + driver + inductor + control in one package) and a 20-year analog catalog. ON's advantage vs. Infineon is **vertical SiC + vGaN substrate IP**.

**Navitas** is the high-beta GaN pure-play; its lateral-GaN technology is volume-shipping today, but it does not scale cleanly past ~650V. ON's vGaN at 1200V is technically superior **if and only if** yields hold in volume — unverified at scale today.

**MPS** is the immediate competitive threat at the inner-rack regulator sockets. ON has no public roadmap to displace MPS at the 48V→0.8V step.

**STMicro** dominates SiC share (~35%) but its analog/digital factory has had execution issues. ON is taking some share from ST in China auto programs.

**TI** announced a complete 800VDC reference architecture in March 2026 [19] — the most aggressive systems-level push by a US analog player. TI has the breadth, the channel, and the EPS-machine balance sheet to win on price.

For ON to materially take share at the AI socket level versus Infineon/MPS/TI, vGaN needs to ship in volume at competitive cost in late 2026 and translate into design-in wins at the Kyber generation (production 2027).

## Bull case — technical
The technical conditions that have to hold:

1. **1MW racks become real on time.** NVIDIA Kyber ships into Vera Rubin Ultra in 2027 with 576 GPUs per rack at ~600kW–1MW; the 800VDC transition is mandatory because copper busbar mass and I²R losses make 48V infeasible above ~250kW [20][21]. Hyperscalers commit capex (currently ~$420B combined 2026 capex) consistent with this trajectory.
2. **onsemi's vGaN holds yield at 1200V in volume by late 2026** and is designed into Kyber-generation 800V→48V DCX modules. Each 1MW rack carries ~$100k of power-semi content (William Blair estimate, doubled from ~$50k in the 250kW-rack era) [22]; capture of even 10–15% of that across the 800V-DCX, BBU, and front-end SiC sockets implies $1.5–2.5B of run-rate AI data-center revenue at maturity — i.e. 4–6× the 2026 base.
3. **EV bottom is in.** Q1 2026 automotive revenue grew YoY for the first time in 8 quarters [1]. SiC ASP erosion from Chinese entrants is offset by 200mm Bucheon cost-down and the 900V platform mix shift (VW PPE/SSP, NIO, Geely).
4. **Treo platform takes share** in zonal automotive architectures and industrial automation at 60–70% GM, mix-shifting blended GM back to the 45%+ that the prior management team committed to.

Financial outcome: revenue compounds mid-teens 2026→2028, gross margin recovers from 38.5% toward 45%, EPS run-rate $4.50–5.00 in 2028. At 22× = $100–110 — i.e. **the bull case requires multi-year execution to hold the current ~$103 stock**, with the upside coming from gradual estimate revisions.

**Base rate caveat:** in past compute platform power transitions (mainframe → minicomputer → 12V server → 48V OCP server → 800V AI rack), incumbents in the prior generation kept ~50–60% share of the new generation if their silicon process was competitive. The exception was Vicor → MPS at the 48V/0.8V layer, a case where the incumbent failed on cost. ON is not currently the incumbent at any AI socket; it is one of ten approved silicon partners. Base-rate share for a new entrant approved on a transition is ~5–15%.

## Bear case — technical
The technical conditions for the moat to erode:

1. **vGaN yield does not hold.** Bulk-GaN substrate growth is hard — defect density on GaN-on-GaN substrates has historically been 10²–10⁴× silicon. If 2026 volume ramp slips into 2027 or yields cap below ~70%, ON ships engineering samples while Navitas (lateral GaN) and Infineon (CoolGaN G2) take the 800V→48V design wins. This is the single biggest binary risk in the thesis and **not verifiable** outside leaked customer ramp data.
2. **Chinese SiC commoditizes the EV business.** StarPower, BYD Semi, SICC, and Hua Micro are shipping 200mm SiC at price points 30–40% below Western vendors. With 30% of ON revenue from China, ASP compression here is structural. The Wolfspeed bankruptcy did not eliminate Chinese supply; it eliminated Western supply [8].
3. **The AI data-center socket fight is won by Infineon and MPS, not ON.** Infineon's integrated-module approach and 20-year analog catalog gives it pole position on 48V→0.8V; MPS has the smart-power-stage socket at GB300/Rubin. ON ends up with the lowest-margin discrete-SiC and BBU sockets while the integrated-module players capture the dollar content per rack. AI revenue scales to $700M–1B rather than $2B+.
4. **Treo is too late.** TI's analog catalog is ~80,000 SKUs deep; Infineon ~50,000; ADI similar. Treo today has dozens of parts. The analog moat is not buildable in 5 years; design-in cycles in industrial are 5–10 years. Treo grows revenue but at much lower margins than the 60–70% target as it competes with TI in mature segments.
5. **EV slowdown second-leg.** If global BEV penetration plateaus at 25–30% (rather than the 50% by 2030 path), SiC TAM is half of consensus. PSG segment growth decelerates to mid-single-digit.

Financial outcome: 2027–2028 revenue grows 8–10%, GM stuck at 38–40%, EPS $3.00–3.50. At 18× = $54–63 — i.e. **40–50% downside** if the auto/industrial recovery stalls and the AI socket fight goes against ON.

## Market view check
The stock is up 90% YTD on a thesis pivot from "auto-cyclical SiC story" to "AI power proxy." At $103, forward P/E ~24× and EV/NTM revenue ~6× sit well above the company's pre-AI multiple range (P/E 12–18×, EV/sales 3–4× during 2021–2024 [3]). Consensus 12-month PT of $103.45 implies sell-side has caught up — no incremental signal. The market is **pricing the bull case as base case**: doubling of AI revenue in 2026, second-order doubling in 2027, GM recovery, and Treo at 60%+ GM. Given ON's AI revenue is still only ~7% of total (2026E), this is a high-multiple bet that the **2027 socket wins materialize before the multiple compresses**. My read: the technical thesis is real but not unique to ON — Infineon, MPS, Navitas, TI, ST all share the 800VDC tailwind, and ON does not have the incumbent advantage at the highest-dollar inner-rack sockets. Multiple looks fair-to-slightly-rich for what is fundamentally a #2/#3 player in each technical axis.

## 90-day falsifiers
Observable between now and August 2026:

- **NVIDIA OCP / Hot Chips (Aug 2026) Kyber power-tree partner disclosures.** If onsemi is named primary 800V→48V DCX silicon supplier alongside or instead of Infineon/Navitas → bull. If named only as BBU/front-end SiC → neutral. If absent → bear.
- **vGaN volume production confirmation in the Q2 (Aug 2026) earnings call.** Watch for: yield specifics, named customer ramp (not just "early-access"), unit-economics commentary. Vague language → bear signal.
- **Q2 2026 AI data-center revenue print.** Run-rate consistent with $500M FY26 implies ~$130–140M Q2. Below $110M would break the doubling trajectory.
- **Automotive PSG sequential trajectory.** Q1 showed +5% YoY first up-quarter in 8; Q2 needs ≥mid-single-digit YoY growth to confirm cycle bottom.
- **Infineon Q3 calendar (next reported) guidance for AI power revenue.** If Infineon raises FY27 AI guide above €2.5B with named hyperscaler design wins, this is share onsemi probably did not get.
- **Texas Instruments capex / 800V design-win commentary** — TI's complete 800V reference architecture is a direct competitive overhang.
- **Convertible note ($1.3B 0% due 2031) usage disclosure** — buybacks vs. capex tells you whether management thinks the stock is cheap or whether they are funding capacity.
- **Wolfspeed Chapter 11 plan confirmation** and asset disposition — if Wolfspeed Mohawk Valley 200mm SiC fab is acquired by a Chinese consortium, it accelerates the China SiC commoditization bear case.

## What I could not verify
- onsemi-specific vGaN yield and defect density figures at volume — entirely company-disclosed, no independent measurement [11][12].
- The "$100k power-semi content per 1MW rack" figure attributed to William Blair — sourced via secondary citation only [22]; could not access the primary note.
- Specific share of ON's $250M 2025 AI revenue between hyperscaler PSU SiC, BBU, and intermediate bus controller versus other applications — segment is reported in aggregate only.
- Whether ON has any design-in on Kyber (2027) versus Oberon (current GB300) generation — public partner list is silicon-supplier-approved, not socket-allocated [14].
- Treo platform's actual unit volume vs. revenue (the "2.5× sequential" is off a base ON does not disclose).
- Long-term ASP trajectory on Chinese SiC modules — public data is fragmentary; the 30–40% discount figure is industry consensus rather than transaction-level.
- The $25.39B market-cap figure on one secondary source [4] conflicts with the $40.4B Finviz calculation [3]; I used the latter (current price × shares outstanding).
- Customer concentration: ON does not disclose top-10 customer revenue mix; auto-OEM concentration is presumably high but unquantified publicly.

## Sources
[1] https://finance.biggo.com/news/US_ON_2026-05-04 — retrieved 2026-05-10 — Q1 2026 earnings call summary: revenue $1.51B, AI data center +30% QoQ doubling YoY, GM 38.5%, segment splits.
[2] https://mlq.ai/news/onsemi-projects-ai-data-center-revenue-doubling-and-margin-gains-for-2026/ — retrieved 2026-05-10 — 2026 AI data center revenue guidance to double from ~$250M.
[3] https://finviz.com/quote.ashx?t=ON — retrieved 2026-05-10 — current price $103.20, market cap $40.44B, 52-week range, forward P/E 24.41×, EV/Rev 6.81×, short interest 7.72%, YTD +90.58%, shares 391.87M.
[4] https://public.com/stocks/on/forecast-price-target — retrieved 2026-05-10 — analyst price targets, consensus PT $103.45, distribution of buy/hold ratings.
[5] https://www.stocktitan.net/news/ON/onsemi-announces-pricing-of-private-offering-of-1-3-billion-of-0-wum1w98ojyks.html — retrieved 2026-05-10 — $1.3B 0% convertible notes due 2031, 52.5% conversion premium.
[6] https://www.trendforce.com/presscenter/news/20240620-12196.html — retrieved 2026-05-10 — SiC market share rankings: STMicro 32.6%, onsemi 23.6%, Wolfspeed third.
[7] https://markets.financialcontent.com/stocks/article/finterra-2026-4-13-the-power-architect-a-deep-dive-into-onsemis-on-strategic-transformation-and-sic-leadership — retrieved 2026-05-10 — 200mm Bucheon ramp, end-to-end SiC supply chain, 60% design-in rate Chinese EV models, ~30% China revenue.
[8] https://markets.financialcontent.com/stocks/article/marketminute-2025-9-26-wolfspeed-plummets-bankruptcy-restructuring-wipes-out-shareholder-value-amidst-silicon-carbide-turmoil — retrieved 2026-05-10 — Wolfspeed Chapter 11 details, $6.7B debt, 70% reduction plan, market share dynamics.
[9] https://www.onsemi.com/company/news-media/press-announcements/en/onsemi-selected-to-power-volkswagen-group-s-next-generation-electric-vehicles — retrieved 2026-05-10 — VW Group EV platform SiC supply agreement.
[10] https://www.electronicdesign.com/markets/automotive/article/55376226/electronic-design-onsemi-joint-efforts-put-900-v-ev-platforms-on-the-fast-track — retrieved 2026-05-10 — 900V EV platform partnerships with Geely, NIO.
[11] https://www.onsemi.com/company/news-media/press-announcements/en/onsemi-unveils-vertical-gan-semiconductors-a-breakthrough-for-ai-and-electrification — retrieved 2026-05-10 — Vertical GaN announcement: 700V/1200V sampling, volume late 2026, Syracuse NY fab, 130+ patents.
[12] https://www.semiconductor-today.com/news_items/2025/oct/onsemi-301025.shtml — retrieved 2026-05-10 — Independent coverage of vGaN: 3× smaller die vs lateral GaN, 50% loss reduction claims.
[13] https://www.onsemi.com/solutions/technology/treo-platform — retrieved 2026-05-10 — Treo 65nm BCD platform, $36B TAM claim, mixed-signal scope.
[14] https://developer.nvidia.com/blog/building-the-800-vdc-ecosystem-for-efficient-scalable-ai-factories/ — retrieved 2026-05-10 — NVIDIA 800VDC ecosystem partner list: ADI, Infineon, Innoscience, MPS, Navitas, onsemi, Renesas, ROHM, ST, TI.
[15] https://newsletter.semianalysis.com/p/energizing-ai-power-delivery-competition — retrieved 2026-05-10 — SemiAnalysis on MPS displacing Vicor at H100, competitive landscape for power delivery.
[16] https://the-razors-edge.ghost.io/vicor-short-thesis-ai-chip-mania-accelerates-vicors-competitive-demise-provides-an-asymmetric-short-opportunity/ — retrieved 2026-05-10 — Vicor competitive collapse at NVIDIA sockets, MPS displacement details.
[17] https://flexpowermodules.com/new-ultra-small-intermediate-bus-converter-developed-together-with-onsemi — retrieved 2026-05-10 — Flex BMR313 3kW IBC using onsemi FD6000 controller, 908 W/cm³ density.
[18] https://blog.se.com/datacenter/2025/10/16/the-1-mw-ai-it-rack-is-coming-and-it-needs-800-vdc-power/ — retrieved 2026-05-10 — Schneider Electric on 1MW rack 800VDC architecture, sidecar topology.
[19] https://www.ti.com/about-ti/newsroom/news-releases/2026/2026-03-16-ti-unveils-complete-800-vdc-power-architecture-for-future-generation-ai-data-centers-with-nvidia.html — retrieved 2026-05-10 — TI complete 800VDC architecture with NVIDIA, direct competitive overhang.
[20] https://developer.nvidia.com/blog/nvidia-800-v-hvdc-architecture-will-power-the-next-generation-of-ai-factories/ — retrieved 2026-05-10 — NVIDIA technical blog on 800VDC, Kyber rack architecture, copper/loss math.
[21] https://glennklockwood.com/garden/Kyber — retrieved 2026-05-10 — Kyber architecture technical detail, 576 GPU/rack, Vera Rubin Ultra 2027.
[22] https://www.techinvestments.io/p/power-semis-in-the-ai-data-center — retrieved 2026-05-10 — William Blair $50k → $100k power-semi content per AI rack estimate; Infineon €1.5B FY26 / €2.5B FY27 AI revenue guidance.