# WDC — Western Digital Corporation

## Where this sits in the AI stack
Post-SanDisk spinoff (Feb 2025), WDC is a **pure-play mechanical hard drive** manufacturer. It does not sell silicon, packaging, networking, optics, or runtime software. Its product is high-capacity nearline HDDs (24–32TB shipping today, 40TB UltraSMR in H2 CY26, 36–44TB HAMR in CY27) sold almost entirely (~89% of revenue) to cloud and hyperscale customers [4][6][20]. In the AI stack, this is the **cold/warm bulk-storage tier under the GPU**: training-corpus archives, checkpoints, inference logs, RAG sources, video and synthetic-data outputs — data that has to exist somewhere when it isn't pinned in HBM, on a CXL pool, or on an NVMe hot tier [3][14]. It is not on the critical path of a training step; it is on the critical path of the dataset that feeds the training step.

## Snapshot
- **Price:** $480.00 (2026-05-08 close, the most recent close before today's session) [1]
- **Market cap:** ~$162B (339M shares outstanding × $480) [13]; companiesmarketcap reported $147B at the 2026-05-01 close, consistent with the run into Friday [9]
- **52-week range:** $43.88 – $483.87 (note: low is a post-spin print; the SanDisk separation completed 2025-02-24 and resets pre-spin comparability) [2][12]
- **Forward P/E:** 28.9× on FY27 consensus [10]; Street is modeling EPS toward $25 over the next two years [9]
- **EV / NTM revenue:** ~10× on a ~$15B NTM revenue print against ~$160B EV (low net debt after dividend reset and the SanDisk separation cash flows)
- **Consensus 12-month price target:** $505.94 mean (16-analyst, 3-month window) / $492 (27-analyst broader panel); implied ~+5% from $480 — i.e., the Street has essentially caught up to the move [21]
- **YTD total return:** +57% (per FinanceCharts industry ranking) [16]; some sell-side notes cite +170% but appear to be running off a January low rather than a 2025-end base [9]
- **Short interest (% of float):** 7.89% (~26.8M shares) — elevated for a name with this kind of momentum [22]

## Moat — what it is physically made of
The moat is not "scale" or "brand." Decomposing:

**Market structure (durable, but cyclical).** Three companies — WDC, Seagate, Toshiba — supply the entire planet's hard drives, with WDC at ~42% unit share, Seagate ~40%, Toshiba ~18–20% [12][8]. This is not an oligopoly that emerged recently; it is the residue of >200 firms that exited or merged out since the 1980s. The re-entry cost is prohibitive: HDDs are precision mechatronics requiring sub-nanometer flying-height control on rotating media, decades-deep tribology IP, captive head and media supply (TDK heads, Resonac/Showa Denko platters [11]), and clean-room capacity not interchangeable with any other product. Inference: a new entrant would need 7–10 years and >$10B before producing a competitive drive, which is why nobody is trying. This is the strongest, most durable component of the moat — and it sits orthogonal to AI.

**Patent portfolio and process-IP (durable).** WDC self-reports 4,500+ active HDD patents and 300+ PhDs in HDD R&D [18]. Specific, named technical primitives I would call out:
- **OptiNAND** — embedded iNAND flash holding HDD metadata, enabling sector-level (not track-level) write recording, which is what makes their 26TB+ ePMR drives possible without HAMR [18].
- **Triple-Stage Actuator (TSA)** — three articulation points (VCM + milli + micro piezo) for narrower track widths and higher bandwidth track-following [18]. Seagate has dual-stage; the third stage is WDC-specific.
- **HelioSeal** — hermetic helium fill (1/7 density of air), enabling 10+ platter stacks. Both vendors now use it; WDC was first to market [18].
- **UltraSMR** — software-controlled shingled writes (host-managed) that get ~10–20% capacity over CMR on the same physical platform. Currently >50% of WDC's nearline exabyte mix [4][6].
- **ePMR** — energy-assisted PMR; an evolutionary step short of HAMR that lets WDC stretch ePMR to ~36–40TB before the technology shift [3][20].

**Hyperscaler qualification lock-in (durable on 2–3 year horizon).** Hyperscalers qualify HDDs over 12–18 month cycles touching firmware, error handling, telemetry, RAID/erasure-code behavior, and operational SOPs. WDC has signed **multi-year Long-Term Agreements (LTAs) with binding exabyte volumes and pricing extending into CY2028–CY2029** [7][15]. Three of its largest hyperscaler customers have adopted UltraSMR; two are nearly fully on UltraSMR for incremental exabytes [7][15]. To swap WDC out for Seagate or Toshiba on warm storage is a 12+ month operational program, not a procurement decision.

**Component supply contracts (medium-durable).** Resonac (ex-Showa Denko) is the dominant glass-substrate and magnetic-media supplier; TDK supplies recording heads [11]. Both have HAMR-specific multi-year codevelopment programs with Seagate publicly disclosed; WDC's HAMR media/head supply relationships are less publicly disclosed and a source of asymmetry — Seagate is further along the HAMR supply curve.

**What is *not* the moat.** Brand has no meaning to a hyperscaler. There is no software ecosystem switching cost analogous to CUDA — open protocols (SATA, SAS, NVMe-oF) make the drive itself interchangeable at the firmware level. The moat is structural (oligopoly + capex + LTAs) and physical (patents + manufacturing process), not ecosystem.

## AI buildout bottleneck map
Of the named gating constraints for the 2026 AI buildout, WDC's position by constraint:

| Bottleneck | WDC position |
|---|---|
| Power generation / grid interconnect | **Beneficiary** (HDDs are 5–11W active vs QLC SSD 15–20W write, ~$0.01/kWh·yr edge at exabyte scale [17]) |
| CoWoS-L advanced packaging | Indifferent — HDDs don't use it |
| HBM3e/HBM4 yield | **Indirect beneficiary** — HBM crowds out conventional DRAM/NAND wafer starts, keeping QLC pricing structurally high (NAND contract +70–75% QoQ in Q2 CY26 [19]) |
| Optical interconnect supply | Indifferent |
| Liquid cooling >100kW/rack | Indifferent — HDDs deploy in air-cooled storage racks alongside GPU pods |
| Electrical contractor / data center build capacity | Mild beneficiary — storage halls are simpler and earlier-built than GPU halls |
| Kernel/compiler talent | Indifferent |
| Training-data quality / volume at the frontier | **Direct beneficiary** — exabytes of synthetic data, multimodal video, agent traces all land on HDD [3][14] |
| HDD manufacturing capacity itself | **Constraint owner** — WDC's entire CY2026 nearline output is contractually allocated and Seagate is similar [3][6]. This is the bottleneck the company owns. |

The honest summary: WDC is mostly **indifferent** to the headline AI bottlenecks that dominate sell-side chatter (HBM, CoWoS, NVLink, liquid cooling). It is a beneficiary of the *spillover* — the dataset growth that scales with model training — and is itself the gating supply on the warm-storage tier. The NAND-shortage spillover is meaningful: as long as HBM consumes ~3 bits of DRAM-equivalent fab capacity per bit of HBM produced [19], QLC SSDs cannot get cheap fast enough to compress HDD's $/TB advantage.

## Competitive teardown

**Seagate (STX) — the only peer competitor on technical axes.** Seagate is *ahead on HAMR*: shipping 30/32/36TB Mozaic 3+ drives in volume from 2024 onward, with Mozaic 4 (4TB/platter) in volume H1 CY26, while WDC's first HAMR drives ship in 2027 [5][20]. WDC has *parity-via-different-path* using UltraSMR on ePMR: a 40TB UltraSMR drive in H2 CY26 lands roughly the same usable capacity as Seagate's 36TB CMR HAMR drive [3][20]. Two reads on this:
- Charitable to WDC: ePMR+UltraSMR has known reliability and known yields; HAMR has open reliability questions around NFT thermal damage, head-disk interface lubricant degradation, and write-pole carbon overcoat lifetime [23]. Hyperscalers are conservative on warm-tier MTBF.
- Charitable to Seagate: HAMR is the only path past ~60TB. The longer WDC takes to get to volume HAMR, the more the next-decade capacity curve belongs to Seagate. Seagate's tighter codevelopment with Resonac on FePt media is a real asymmetry [11].

On *current* economics this is a duopoly with rough parity and shared pricing discipline. On a 2027–2029 horizon, this is where Seagate could take share unless WDC's HAMR ramp is within ~1–2 quarters.

**Toshiba — pricing cudgel, not a strategic threat.** ~18–20% share; explicitly used by hyperscalers as a third source to keep duopoly pricing honest [12]. MAMR-based platform, with HAMR in development. Doesn't take meaningful share from WDC at the high end.

**QLC SSD (Solidigm, Samsung, Micron, Kioxia) — the real long-run threat.** Meta has publicly argued for a QLC SSD tier *between* HDD and TLC SSD specifically because high-capacity HDD bandwidth-per-TB has been shrinking as capacity rises (a 30TB HDD reads at roughly the same MB/s as a 4TB HDD did — i.e., MB/s/TB falls roughly linearly with capacity) [24][25]. That is a real technical argument, not a marketing claim. But: the $/TB delta is still 9–15× at high capacities, and the 2026 NAND shortage widens, not narrows, the gap [17][19]. For QLC to threaten WDC's nearline base case, NAND $/GB has to fall faster than HDD areal density rises, *and* a Meta-style tier has to be operationally adopted by AWS/Azure/Google. Today neither is happening at scale; in 2027–2028 this risk grows.

**DNA storage, glass (Project Silica), tape** — out of scope on a 24-month horizon. Tape is real for cold archive but doesn't displace nearline.

## Bull case — technical
The technical conditions for outperformance:

1. **HDD supply remains structurally allocated.** Independent verification: hyperscaler LTAs run through CY28–CY29 [7][15]; vdura/Trendforce report CY26 production is fully allocated [3][6]. If this holds, ASP/TB is contractually rising not just from mix but from base [4].
2. **40TB UltraSMR ships on schedule in H2 CY26.** WDC needs to deliver the ePMR step without a HAMR ramp slip into the back half of 2027. Currently in qualification with 2–3 hyperscale customers [6][20].
3. **HAMR ramps in 2027 within 1–2 quarters of Seagate.** WDC doesn't need to lead HAMR; it needs to not fall a full generation behind.
4. **NAND remains structurally tight through CY26 due to HBM allocation.** This is the single most important external variable for WDC and is currently true [19].
5. **Hyperscaler capex compounds.** $725B aggregate 2026 capex across MSFT/AMZN/GOOG/META, ~75% AI-allocated, with memory now ~30% of data center spend [10]. Training-data-volume scales with this, and that data lands on WDC drives.

**Base rate caution.** Technology platform shifts in semis (CPU→GPU, x86→ARM in mobile, NAND→QLC progression) typically take 5–10 years from credible technical viability to volume displacement. QLC SSDs reached credible $/TB viability for *some* warm workloads in ~2023–2024 (Meta blog March 2025 [25]). On a base rate, that puts a real HDD displacement event in 2028–2031, *outside* the LTA window. The bull case is that WDC monetizes the gap window at oligopoly margins, and the equity reflects mid-cycle FCF, not a terminal value.

Financial translation: at ~50%+ gross margin [4][20], FY27 revenue of $14–15B and EPS approaching $25 [9] makes the current ~29× forward P/E *expensive on history* but explainable if you believe 50% GM is the new floor through CY28 LTAs.

## Bear case — technical
The version a short-seller who reads ServeTheHome would write:

1. **HAMR is harder than the roadmaps suggest, and WDC is later than Seagate.** The published literature on HAMR identifies real reliability problems — near-field transducer (NFT) thermal damage, write-pole carbon overcoat delamination, lubricant degradation at write temperatures [23]. Seagate has been "shipping HAMR" since 2024 but exabyte mix from HAMR was small for two years; if WDC misses 2027 by even two quarters, hyperscalers fill the gap by re-allocating to Seagate exabytes — not by going to SSD.
2. **The Meta-style QLC middle tier is a slow-motion displacement.** Not a 2026 issue; a 2027–2029 issue. But the bandwidth-per-TB problem in HDD is real and structural — 30TB drives read at ~285 MB/s, the same as 8TB drives, so for any workload where access-rate-per-stored-byte matters (analytics over training corpora, RAG over recent data, agent memory), the workload economics already favor QLC even at 3–5× the $/TB [17][24][25]. The boundary of "what counts as warm" creeps outward each year.
3. **The current NAND shortage will end.** Memory shortages mean-revert. When SK Hynix/Samsung/Micron capacity catches up to HBM demand in 2027–2028, QLC NAND $/GB will normalize. The HDD/QLC $/TB spread compresses *as the LTAs roll off* — exactly the wrong sequencing for WDC.
4. **Hyperscaler capex is the demand stack, and it is cyclical.** Microsoft FCF is structurally falling under capex; Amazon is heading to ~–$17B FCF in 2026 [10]. AI capex is a base-rate candidate for a sharp >10% sequential cut on any frontier-model disappointment (a GPT-5/Claude-5 plateau, an enterprise ROI shortfall, a new architecture that compresses storage requirements). On a base rate, hyperscaler capex cycles since 2012 have shown 4–6 quarter pullbacks of 15–30% post-overbuild.
5. **The stock has 10×'d off lows and short interest is 7.9%.** Even at 29× forward, this is priced for continued execution. The asymmetry has flipped — upside is bounded by the LTAs, downside is unbounded by a cycle reset.

## Market view check
At $480 the market cap is ~$162B on a company doing ~$13B in revenue and headed to $14–15B with ~50% gross margins [4][20]. Forward P/E is 29×; EV/NTM revenue is ~10×. Consensus target is essentially flat to spot. The market has correctly identified that (a) post-SanDisk spin, this is a pure HDD oligopoly play, (b) LTAs give 2–3 years of revenue visibility, (c) the NAND shortage widens HDD's TCO moat. What the market may be underpricing is *the cyclicality this name has always had* — WDC is a 30-year cyclical that has been re-rated as a structural AI beneficiary; the LTAs end in 2028–2029 and the equity duration mismatches that. What the market may be *over*pricing is HAMR execution certainty: the stock is implicitly assigning Seagate-like HAMR delivery probability to WDC despite the 1-year roadmap lag.

## 90-day falsifiers
Specific, dated checks before mid-August 2026:

- **WDC Q4 FY26 print (late July 2026):** Revenue ≥$3.65B; gross margin ≥51%; nearline exabytes; LTA disclosure update. A miss on gross margin >100bps with a price/mix story (not cost) would be a thesis crack [20].
- **Seagate equivalent (FY Q4):** HAMR exabyte mix disclosure. If Seagate's HAMR mix crosses ~30% of nearline exabytes with normalized yields, the case that "WDC's UltraSMR holds parity" weakens.
- **40TB UltraSMR qualification & ship announcement:** Press release of GA shipment to first hyperscaler before end of CY3Q (Sept). A slip into Q4 CY26 is a yellow flag; into 2027 is a red flag.
- **Hyperscaler capex commentary (MSFT/META/GOOG/AMZN earnings, late July):** Watch for any *sequential* capex guide cut. Memory/storage component-level commentary in Amy Hood and Susan Li scripts.
- **NAND spot pricing (TrendForce monthly):** A reversal from current +70% QoQ trajectory to flat or down would be the first sign the structural NAND tightness is ending sooner than 2027.
- **WDC 13F flow (Aug filing for Jun 30):** Hedge-fund-style fast money rotating out into HDD-cycle shorts would precede sentiment reversal.
- **TDK / Resonac quarterly results:** Their HAMR-media and HAMR-head shipment cadence is a leading indicator on WDC's 2027 ramp confidence.

## What I could not verify
- WDC's contractual HAMR head and media supply terms (Resonac and TDK have publicly disclosed Seagate codevelopment; WDC equivalents are not publicly detailed) [11].
- Whether the reported "+57% YTD" or "+170% YTD" prints reconcile under the post-spin cost basis — sources disagree, likely an indexing artifact [9][16].
- Precise breakdown of UltraSMR adoption per named hyperscaler — WDC discloses "three largest customers" but not by name [7].
- WDC's HAMR cost-per-TB at first commercial volume vs Seagate's — there is no independent third-party teardown yet.
- The actual nearline exabyte gross margin (vs blended company GM ~50%); WDC does not break this out and consensus models use blended.
- Whether Seagate's reported HAMR shipments since 2024 represent volume production or pilot/early-customer cohorts — public exabyte mix data is sparse.
- True remaining technical risk on WDC's HAMR transition (NFT reliability, lubricant lifetime at production temperatures) — academic literature flags issues [23] but no production-failure data is public.
- Whether the Microsoft/Meta/Google QLC SSD warm-tier programs displace HDD demand sequentially or are additive to total exabyte demand.

## Sources
[1] https://finance.yahoo.com/quote/WDC/ — retrieved 2026-05-10 — WDC May 8, 2026 close ~$480, prior close $463.91
[2] https://stockanalysis.com/stocks/wdc/history/ — retrieved 2026-05-10 — 52-week range $43.88–$483.87
[3] https://www.vdura.com/2026/05/04/follow-the-hdds-what-this-weeks-wdc-and-seagate-earnings-tell-us-about-ai-storage/ — retrieved 2026-05-10 — HDD-AI thesis; 90% nearline exabyte mix; allocated through FY27
[4] https://futurumgroup.com/insights/western-digital-q2-fy-2026-results-beat-on-cloud-hdd-demand/ — retrieved 2026-05-10 — WDC Q2 FY26 GM>50%, UltraSMR mix
[5] https://www.tomshardware.com/pc-components/hdds/seagate-launches-32tb-exos-m-hard-drive-based-on-hamr-technology-mozaic-3-drives-are-the-worlds-first-generally-available-hamr-hdds — retrieved 2026-05-10 — Seagate 30/32TB Mozaic HAMR in volume
[6] https://www.fool.com/earnings/call-transcripts/2026/04/30/western-digital-wdc-q3-2026-earnings-transcript/ — retrieved 2026-05-10 — WDC Q3 FY26 transcript: 40TB UltraSMR H2 CY26, HAMR 2027
[7] https://finance.yahoo.com/quote/WDC/earnings/WDC-Q3-2026-earnings_call-548617.html — retrieved 2026-05-10 — LTAs extending into CY28–CY29
[8] https://www.itcandor.com/hard-disk-suppliers/ — retrieved 2026-05-10 — HDD market structure history; consolidation to three vendors
[9] https://www.fool.com/investing/2026/05/08/this-glorious-growth-stock-has-surged-170-in-2026/ — retrieved 2026-05-10 — Forward EPS path toward $25; cumulative 2026 return context
[10] https://www.tomshardware.com/tech-industry/big-tech/big-techs-ai-spending-plans-reach-725-billion — retrieved 2026-05-10 — Hyperscaler 2026 capex $725B, 75% AI-allocated
[11] https://www.resonac.com/news/2021/06/10/1133.html — retrieved 2026-05-10 — Resonac/Showa Denko–Seagate HAMR media codevelopment; TDK head collaboration
[12] https://www.statista.com/statistics/1257240/hard-disk-drive-hdd-supplier-market-share/ — retrieved 2026-05-10 — WDC ~42%, STX ~40%, Toshiba ~18–20% unit share
[13] https://stockanalysis.com/stocks/wdc/statistics/ — retrieved 2026-05-10 — WDC share count 339M outstanding
[14] https://introl.com/blog/data-lake-architecture-ai-exabyte-scale-storage-patterns — retrieved 2026-05-10 — Data lake architecture, hot/warm/cold tier model
[15] https://news.alphastreet.com/western-digital-corporation-wdc-q3-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Three top customers on UltraSMR; LTA structure
[16] https://www.financecharts.com/stocks/WDC/performance/total-return — retrieved 2026-05-10 — WDC +57% YTD 2026
[17] https://www.idtechex.com/en/research-article/qlc-vs-hdds-the-battle-for-high-capacity-storage/33094 — retrieved 2026-05-10 — QLC SSD vs HDD $/TB, power per TB comparisons
[18] https://www.westerndigital.com/company/innovation/hdd-innovation — retrieved 2026-05-10 — 4,500+ HDD patents, OptiNAND, TSA, HelioSeal
[19] https://www.trendforce.com/presscenter/news/20260331-12995.html — retrieved 2026-05-10 — NAND +70–75% QoQ in 2Q26; HBM crowding conventional memory
[20] https://www.tomshardware.com/pc-components/hdds/western-digital-still-plans-to-start-shipping-36tb-hamr-hard-drives-in-2027 — retrieved 2026-05-10 — WDC 36/40/44TB HAMR variants, 2027 commercial start
[21] https://stockanalysis.com/stocks/wdc/forecast/ — retrieved 2026-05-10 — Consensus 12-month target $492–$506
[22] https://www.marketbeat.com/stocks/NASDAQ/WDC/short-interest/ — retrieved 2026-05-10 — Short interest 7.89% of float, 26.76M shares
[23] https://en.wikipedia.org/wiki/Heat-assisted_magnetic_recording — retrieved 2026-05-10 — HAMR reliability literature: NFT damage, write-pole overcoat, FePt media
[24] https://www.techradar.com/pro/facebook-engineers-say-that-bigger-hard-disk-drives-is-making-one-critical-metric-far-far-worse — retrieved 2026-05-10 — Meta engineer commentary on HDD MB/s/TB decline
[25] https://engineering.fb.com/2025/03/04/data-center-engineering/a-case-for-qlc-ssds-in-the-data-center/ — retrieved 2026-05-10 — Meta's published case for QLC as warm-tier between HDD and TLC SSD