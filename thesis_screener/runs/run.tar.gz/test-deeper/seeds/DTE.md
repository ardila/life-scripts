Now I have enough research. Drafting the dossier.

# DTE — DTE Energy Company

## Where this sits in the AI stack
DTE is a **regulated electric and gas utility serving southeast Michigan inside MISO Zone 7** — it sits at the very bottom of the AI stack, in the **power generation, transmission, and interconnection layer**. It does not sell silicon, software, or merchant electrons; it sells front-of-the-meter regulated electric service under a state-issued franchise. Its AI exposure is entirely a *load-growth* story driven by hyperscaler co-located behind-utility-meter campuses (Oracle/OpenAI Stargate in Saline Twp; Google in Van Buren Twp), where the earnings mechanic is rate-base capex × authorized ROE, not merchant power prices [1][2][3][4].

## Snapshot
- **Price:** $141.03 (2026-05-10 close) [5]
- **Market cap:** $29.2B (≈208M shares out) [6]
- **52-week range:** $126.23 – $154.63 [5]
- **Forward P/E:** ~18.4× (FY26 op-EPS guide $7.59–$7.73 midpoint $7.66) [7]
- **EV / NTM revenue:** ~3.7× (EV $55.9B; revenue ~$15B run-rate) — *note: low signal for a regulated utility; rate base / earned ROE is the operative metric* [8]
- **Consensus 12-mo PT:** ~$152–$160 (~+8–13% upside, "Buy" tilt, 11–12 analysts) [7]
- **YTD total return:** ~+9% (price + ~1 dividend received) — inference from $129 YE25 reference vs. $141.03 + $1.165 paid [5][9]
- **Short interest:** 2.6% of float (~5.35M shares, late Mar-26) [10]
- **EV/EBITDA:** 12.6× (vs. regulated-utility median ~11–12×) [8]

## Moat — what it is physically made of
Calling DTE a "moat" requires intellectual honesty: the moat is **not technological**. It is a **state-granted territorial monopoly** plus the physical infrastructure that locks in 50-year customer relationships. Decomposed:

1. **The certificated service territory.** Michigan Public Service Commission (MPSC) jurisdiction grants DTE Electric an exclusive obligation-to-serve in 7,600 sq mi of southeast Michigan including Wayne, Oakland, Macomb, Washtenaw counties — the same counties where Oracle/OpenAI (Saline) and Google (Van Buren Twp, "Project Cannoli") chose to site [2][3]. Hyperscalers picked Michigan for cheap MISO power, water, climate, and Detroit fiber routes; once a 1.4 GW campus is steel-in-ground, the customer cannot change utility provider. **Durability: very high** — switching requires legislation; MPSC has held this compact for >100 years.

2. **Authorized ROE of 9.9% on a growing rate base.** This is the actual earnings mechanic. The Feb-2026 rate order (Case U-21860) preserved 9.9% ROE on an equity-thick capital structure and approved $242M in additional revenue [11]. Every dollar of approved capex (transmission upgrades, the planned CCGT, Cleam Capacity Accelerator storage, distribution buildout for hyperscalers) earns ~9.9% pre-tax. **Durability: medium** — Michigan Attorney General Nessel is publicly hostile and has called DTE's rate-freeze offer a "ransom note" [12]; this is the single biggest political risk.

3. **The 19-year Oracle/Stargate Power Supply Agreement.** Approved 3-0 by MPSC in Dec-2025. Key technical features: **80% take-or-pay on contracted capacity**, hyperscaler bears all incremental T&D and generation cost, hyperscaler funds dedicated battery storage; if customer defaults, costs cannot be socialized to other ratepayers [1][2][3]. This is materially better economics than the merchant-PPA structures TLN/CEG signed (which FERC has subsequently blocked at the co-location level) [13].

4. **Google PSA + Clean Capacity Accelerator Agreement** (signed Mar-26). 1.0 GW; ramps Dec-27 → Dec-28; obligates DTE to deploy **480 MW of energy storage and 1,600 MW of new renewables at customer cost**, plus a separate $1.7B-over-life affordability credit to other ratepayers [4][14]. MPSC ruling expected by 2026-09-10; this is the single biggest near-term binary.

5. **Physical interconnection position in MISO Zone 7.** DTE owns the substations and high-voltage interconnects feeding southeast Michigan. New entrants need MISO Definitive Planning Phase studies (DPP-2023 still working through DPP-2 in 2026; new MISO Large Load Framework took effect for >50 MW sites Sep-1-2026) [15][16]. **Durability: high over 24-month horizon** — queue position is physically scarce and DTE's projects already cleared.

What this is **not**: it is not a CUDA-style switching cost, not a process-node lead, not an IP-secured supply chain. It's regulatory geography and franchised infrastructure. A first-year analyst saying "DTE has an AI moat" is wrong; the right framing is **"DTE is a vehicle for converting hyperscaler capex into rate base at 9.9% ROE."**

## AI buildout bottleneck map
Using the 24-month gating constraints on the AI buildout, mapping DTE's position:

| Constraint | DTE position |
|---|---|
| **Power generation capacity** | **Constraint owner.** Michigan reserve margin tight; DTE retiring 1,500 MW Monroe coal in 2028 + 1,500 MW more by 2032 [17][18] while taking on 2.4 GW of new hyperscaler load by 2028. DTE must add CCGT + storage + renewables on a forced timeline. |
| **Grid interconnect / transmission** | **Beneficiary** of franchise but **execution risk.** MISO interconnection queue reform helps, but DPP timelines still 2–3 years [15][16]. DTE's existing 345kV backbone in southeast MI is a real edge. |
| **Gas turbine supply** | **Exposed customer.** GE Vernova backlog 80 GW through 2030; lead times 5–7 yrs [19][20]. DTE has *not* publicly disclosed locked turbine slots for replacement CCGT capacity post-Monroe, which is a quiet risk. (See "What I could not verify.") |
| **HBM / CoWoS-L / silicon** | **Indifferent.** This is the customer's problem, not DTE's. |
| **Liquid cooling >100kW/rack** | **Indifferent at the meter.** Cooling is BTM; DTE's interface is at the substation. Water rights for evaporative cooling are a Michigan Department of Environment issue, not DTE's. |
| **Long-lead optical/networking** | **Indifferent.** |
| **Electrical contractor / BESS integrator capacity** | **Exposed.** Google CCAA requires 480 MW BESS + 1,600 MW renewables on a 24-month timeline — substantively the same skilled-labor pool every other utility in MISO is fighting for. |
| **Coal-to-gas conversion logistics** | **In-flight.** Belle River unit conversions 2025–2026 (1,270 MW total) [21] are mid-execution; one bad outage at Monroe before 2028 retirement = capacity shortfall during ramp. |

The summary: DTE is **not** a beneficiary of AI as a *technology supplier*; it is a beneficiary as a **regulated capex sponge** that gets paid 9.9% on every dollar of generation/T&D the data centers force it to build. The constraints that hurt the rest of the AI stack (HBM, CoWoS, optics) don't touch DTE; the constraints that *do* hurt DTE (gas turbine queue, contractor labor, MPSC politics) are the ones a financials-first analyst usually misses.

## Competitive teardown
DTE is structurally different from the names retail investors call "AI power":

- **Constellation Energy (CEG):** Owns 24/7 carbon-free nuclear (~22 GW); sells under merchant PPAs to Microsoft/Meta. Direct exposure to merchant power prices and to FERC's stance on co-location (FERC rejected Talen-Amazon Susquehanna co-location amendment, hitting CEG comparables) [13][22]. **DTE has zero merchant-power upside** — but also zero merchant-price downside or FERC-co-location risk; its load comes through the regulated tariff.
- **Vistra (VST):** Merchant fleet (gas + nuclear) in ERCOT/PJM/ISO-NE; signed AWS 1.2 GW Comanche Peak PPA + Meta 2.6 GW; FY26 EBITDA guide $6.8–7.6B [23][24]. **Different beast entirely** — VST's earnings are a function of merchant clearing prices and PPA contracting; DTE's are a function of MPSC orders.
- **Talen (TLN):** Merchant nuclear in PJM; sold Susquehanna data center campus to Amazon. **The cleanest cautionary tale for DTE bulls:** TLN's structure relies on FERC accepting BTM co-location amendments. That has been blocked. DTE's structure routes everything through *retail*, *front-of-meter*, MPSC-approved tariffs — explicitly designed to avoid FERC co-location risk.
- **Adjacent integrated utilities (AEP, Southern, Duke):** Larger pipelines but more diversified. DTE is *more concentrated* in AI-load growth as a % of base load: 8.4 GW pipeline against ~12 GW system peak would be ~70% load expansion if fully realized [25] — extreme by utility standards.

**The technical axis where DTE has parity or edge:** structural protection of incumbent ratepayers (no socialization of hyperscaler costs), 80% take-or-pay locking in revenue, regulator-blessed capex recovery. **The technical axis where DTE is at a disadvantage:** it cannot capture merchant upside if MISO clearing prices rip; the 9.9% ROE is a cap, not a floor with upside. CEG's Three Mile Island restart at >$110/MWh blended PPA is something DTE structurally cannot replicate.

## Bull case — technical
For DTE to outperform from $141:

1. **The 1.0 GW Google PSA must be approved by MPSC by 2026-09-10** [4]. This is a contested case, not a settled one; Saline approval was 3-0 but Google's is a separate proceeding with active intervenors. If approved on the same architecture (80% take-or-pay, customer pays for new generation), it converts ~$4B+ of capex into rate base.
2. **The pipeline of "3–4 GW in advanced negotiations" must convert** [25] — DTE has guided to 8.4 GW total. Two more deals at the Saline architecture would lift the 5-year capex plan from $36.5B toward ~$42–45B, lifting rate-base growth from ~9% to ~11–12% CAGR [26].
3. **CCGT/BESS/renewables additions must execute on time** — meaning DTE has to be at the front of the GE Vernova queue and the BESS integrator queue. If DTE has secured 2027–28 turbine slots (currently unverified — see below), this is durable; if it has to procure spot in 2027, costs blow out.
4. **MPSC must hold ROE near 9.9%.** Nessel is pushing to slash the next $474M case by 85% [27]; if ROE survives at ≥9.5%, the math works.
5. **No MISO capacity emergency.** Monroe coal retiring 2028/2032 + Belle River converting must not coincide with a heat-dome auction event before replacements are online.

**Base rate on platform shifts:** Regulatory utility franchises have the *slowest* erosion rate of any moat I assess in tech infra — 50+ year half-lives, vs. ~10–15 years for software ecosystems and ~5–7 years for process-node leadership. The scenario where DTE *loses* its franchise inside 24 months is essentially zero.

Connecting to financials: at 11% rate-base CAGR and 9.9% ROE, op-EPS compounds at ~7–9% on the high end of guidance. At a 19× forward multiple, modest multiple expansion to 20–21× (regulator-approved AI tailwind) takes the stock to ~$170–175. Total return ~+25% over 18 months including ~3.3% yield.

## Bear case — technical
A short-seller who actually understands the stack would write:

1. **Gas turbine slots are not confirmed.** DTE's $36.5B 5-year plan assumes a new combined-cycle gas plant gets built to backstop Monroe retirement. With GE Vernova booked through 2030 and 5–7 yr lead times [19][20], unless DTE has placed orders by 2024–2025 (which I could not verify in primary sources), the replacement CCGT slips and DTE faces a capacity gap *exactly when* hyperscaler load is ramping. MISO Zone 7 capacity auction prices spike; DTE pays.
2. **MPSC politics turn.** Nessel's "ransom note" framing [12] and the AG's intervention to slash 85% of the pending $474M rate case [27] are real signals. If a future MPSC commissioner trims authorized ROE to 9.0–9.25% or applies stricter capex prudency tests on the data-center-driven build, the math compresses materially. Regulated utility ROE compression of 50bps is roughly a 5% EPS hit.
3. **Hyperscaler footprint shifts.** Stargate has *multiple* sites under development (Texas, New Mexico, others reportedly evaluated in PJM / SPP). If OpenAI restructures or its compute partner deprioritizes Saline, DTE collects 80% on contracted capacity for 19 years — but the *upside pipeline* (the 3–4 GW under negotiation) evaporates. The 80% take-or-pay protects downside; it doesn't deliver the upside priced into a 19× multiple.
4. **Local opposition and siting friction.** Townships including Saline neighbors, Genoa Twp, and others are now actively legislating against new data-center siting [28]. Each site DTE plans needs township approval; this is a non-utility execution risk that historically has not been priced.
5. **FP4/inference efficiency curve outpaces buildout.** This is the technically interesting bear: if Blackwell-Ultra and post-MI400 inference workloads on FP4/FP6 deliver materially better tokens-per-watt than the planning assumptions in 2024–25, hyperscaler power draw per dollar of compute *falls*, and the marginal hyperscaler campus contracted in 2027–28 may downsize from 1 GW → 600 MW. The 80% take-or-pay protects on existing contracts but flattens the pipeline.
6. **Premium valuation against utility comps.** 18–19× forward vs. ~16× for AEP/Duke/Southern means the market has *already* awarded DTE an AI premium. If any of (1)–(4) misses, multiple compresses to peer median; that's a 12–15% derate before earnings revisions.

## Market view check
At 18.4× forward EPS and 12.6× EV/EBITDA, DTE is trading roughly 1.5–2 turns above the regulated-electric median (Duke ~16–17×, Southern ~17×, AEP ~16×). A "Buy" consensus with $152–$160 PT (+8–13%) is consistent with the market pricing in **partial** Google-deal approval and **none** of the additional 3–4 GW pipeline. The market appears to believe: Saline is in the bag, Google is probable but not certain, and the 8.4 GW headline number is aspirational. I think this is approximately right but understates two things — (a) the *structural protection* of the take-or-pay tariff structure relative to merchant-PPA peers facing FERC risk, and (b) the *non-linearity* of rate-base growth if even 2 of the 3–4 GW pipeline closes. The technical thesis is consistent with the price, leaning slightly favorable; this is not a deep mispricing.

## 90-day falsifiers
- **MPSC ruling on the Google 1.0 GW PSA, deadline 2026-09-10** [4]. Approval ≈ +$4B rate-base lever; denial or onerous conditions = thesis breaker on the pipeline.
- **MPSC interim or final order on the pending $474M rate case** (filed Feb-26, AG seeking 85% cut) [12][27]. ROE held ≥9.5% = thesis intact; ROE cut to <9.25% = thesis impaired.
- **DTE Q2 2026 earnings (early Aug)** — watch for: (i) updated number on "advanced negotiations" pipeline (currently 3–4 GW), (ii) any disclosure of secured turbine slot deposits with GE Vernova / Mitsubishi, (iii) any change to the $36.5B 5-yr capex plan.
- **Township-level zoning votes** in Genoa, Saline-adjacent communities — any *additional* moratorium on hyperscaler siting damages pipeline conversion probability.
- **MISO Zone 7 PRA (Planning Resource Auction) clearing prices for 2026/27** — if Zone 7 clears at the cap, signals capacity tightness and risk that Monroe/Belle River timing slips create exposure.
- **A FERC ruling adverse to front-of-meter "ratepayer-protection" tariffs** — the FERC Talen/Amazon precedent was BTM, but any expansion of jurisdiction toward FOM hyperscaler tariffs would be material.

## What I could not verify
- Whether DTE has placed and secured **specific gas turbine slot reservations** with GE Vernova or Mitsubishi for replacement CCGT capacity post-Monroe retirement. Investor materials reference "a new combined-cycle gas plant" but I did not find a public order disclosure with a delivery date.
- The exact **MISO Zone 7 reserve margin trajectory** through 2027–28 net of Monroe retirement and Belle River conversions; MISO PRA results sit behind operational disclosures.
- Whether the "3–4 GW advanced negotiations" pipeline includes any **Microsoft, Meta, or AWS** counterparties (only Oracle/OpenAI and Google are named publicly).
- **Float and institutional ownership concentration** — search results disclosed shares-out and short interest but not a clean float number.
- The **specific minimum-bill / ready-to-serve dollar amount per MW** in the Stargate contract — only the 80% take-or-pay headline is public.
- Whether the **DTE Vantage** non-utility segment (RNG, custom energy) is materially benefiting from data-center adjacency or remains a small EPS contributor.

## Sources
[1] https://www.tomshardware.com/tech-industry/artificial-intelligence/openais-stargate-data-center-gets-approval-to-receive-1-4-gigawatts-of-power-in-michigan-some-residents-furious-as-energy-company-is-given-go-ahead-by-regulatory-body-without-hearing-opposition — retrieved 2026-05-10 — Stargate 1.4 GW approved, $7B Oracle/OpenAI campus
[2] https://www.michigan.gov/mpsc/commission/news-releases/2025/12/18/mpsc-approves-dte-electric-energy-contracts-for-data-center — retrieved 2026-05-10 — MPSC official approval order with ratepayer protection conditions
[3] https://bridgemi.com/michigan-environment-watch/michigan-regulators-approve-contract-for-michigans-first-hyperscale-data-center/ — retrieved 2026-05-10 — 19-yr term, 80% take-or-pay structure, $300M ratepayer benefit
[4] https://www.stocktitan.net/sec-filings/DTB/8-k-dte-energy-co-reports-material-event-f8ada91fd48b.html — retrieved 2026-05-10 — Google 1.0 GW PSA + Clean Capacity Accelerator Agreement, 480 MW BESS + 1,600 MW renewables, MPSC decision by 2026-09-10
[5] https://finance.yahoo.com/quote/DTE/ — retrieved 2026-05-10 — DTE close $141.03, 52-wk range $126.23–$154.63
[6] https://stockanalysis.com/stocks/dte/market-cap/ — retrieved 2026-05-10 — Market cap $29.2B, ~208M shares
[7] https://stockanalysis.com/stocks/dte/forecast/ — retrieved 2026-05-10 — Analyst PT range $148–$170, mean ~$152–$160
[8] https://stockanalysis.com/stocks/dte/statistics/ — retrieved 2026-05-10 — EV $55.9B, EV/EBITDA 12.6×, debt $26.3B
[9] https://www.marketbeat.com/instant-alerts/dte-energy-company-declares-quarterly-dividend-of-117-nysedte-2026-05-08/ — retrieved 2026-05-10 — Quarterly dividend $1.165
[10] https://www.marketbeat.com/instant-alerts/dte-energy-company-nysedte-short-interest-update-2026-04-17/ — retrieved 2026-05-10 — Short interest 5.35M sh / 2.6% of float (3/31/26)
[11] https://www.michigan.gov/ag/news/press-releases/2026/02/19/mpsc-approves-dte-electric-rate-hike — retrieved 2026-05-10 — Case U-21860 $242M revenue increase, ROE held at 9.9%
[12] https://planetdetroit.org/2026/04/dte-rate-hike-data-centers/ — retrieved 2026-05-10 — Nessel "ransom note" framing of DTE's rate-freeze offer
[13] https://www.nbcphiladelphia.com/news/business/money-report/tech-partnerships-with-power-companies-for-ai-in-doubt-after-government-rejects-key-amazon-agreement/4017760/ — retrieved 2026-05-10 — FERC rejection of Talen/Amazon BTM co-location
[14] https://planetdetroit.org/2026/03/google-dte-data-center-van-buren/ — retrieved 2026-05-10 — Van Buren Twp "Project Cannoli" Google site
[15] https://www.zeroemissiongrid.com/insights-press-zeg-blog/miso-large-load-additions/ — retrieved 2026-05-10 — MISO LLWG large-load framework, >50 MW threshold from 2026-09-01
[16] https://www.spglobal.com/energy/en/news-research/latest-news/electric-power/022525-miso-on-path-to-reduce-queue-process-to-one-year-with-reforms-technology-executive — retrieved 2026-05-10 — MISO interconnection queue reform timeline
[17] https://planetdetroit.org/2023/07/dte-agrees-to-shut-down-coal-fired-monroe-plant-in-2032-three-years-ahead-of-schedule/ — retrieved 2026-05-10 — Monroe retirement schedule (Units 3,4 by 2028; 1,2 by 2032)
[18] https://en.wikipedia.org/wiki/Monroe_Power_Plant — retrieved 2026-05-10 — Monroe 4×850 MW = 3,300 MW total
[19] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — GE Vernova 80 GW backlog, slots into 2029
[20] https://www.power-eng.com/gas/turbines/data-centers-drive-record-surge-in-ge-vernova-power-equipment-orders-as-turbine-slots-tighten-through-2030/ — retrieved 2026-05-10 — Lead times 5–7 yrs, GE Vernova capacity expansion
[21] https://www.utilitydive.com/news/dte-energy-resource-plan-irp-solar-coal-michigan-psc/635781/ — retrieved 2026-05-10 — Belle River 1,270 MW coal-to-gas conversion 2025–26
[22] https://markets.financialcontent.com/stocks/article/marketminute-2026-3-31-the-nuclear-chill-constellation-energy-shares-plunge-7-as-2026-outlook-falls-short-of-ai-hype — retrieved 2026-05-10 — CEG -23% YTD on FERC/co-location risk
[23] https://www.fool.com/investing/2026/04/18/crowd-dumping-vistra-why-buy-stock-down/ — retrieved 2026-05-10 — Vistra AWS Comanche Peak 1.2 GW + Meta 2.6 GW PPAs, FY26 EBITDA guide
[24] https://247wallst.com/investing/2026/05/04/how-ai-data-centers-are-reshaping-the-power-market-and-the-4-plays-investors-are-making/ — retrieved 2026-05-10 — Cogentrix gas-fleet acquisition for VST
[25] https://www.utilitydive.com/news/dte-energy-data-center-earnings-reliability/819052/ — retrieved 2026-05-10 — 8.4 GW total data-center pipeline aspiration
[26] https://www.industrialinfo.com/iirenergy/industry-news/article/data-center-demand-drives-dtes-five-year-capex-increase-to-365-billion--353526 — retrieved 2026-05-10 — $36.5B 5-year capex plan, ~11% rate-base growth
[27] https://www.michigan.gov/ag/news/press-releases/2026/03/20/ag-nessel-seeks-to-slash-dte-rate-hike — retrieved 2026-05-10 — AG seeks 85% reduction to pending $474M rate case
[28] https://www.tomshardware.com/tech-industry/michigan-towns-rush-to-block-ai-data-centers-after-16-billion-stargate-project-overrode-local-opposition — retrieved 2026-05-10 — Township opposition to additional siting
[29] https://finance.biggo.com/news/US_DTE_2026-04-30 — retrieved 2026-05-10 — Q1 2026 earnings call: $1.95 op-EPS, 3–4 GW pipeline, 8%+ EPS growth outlook
[30] https://www.benzinga.com/insights/news/26/04/52172645/dte-energy-q1-2026-earnings-call-complete-transcript — retrieved 2026-05-10 — Q1 2026 transcript with management commentary on 8.4 GW pipeline ambition