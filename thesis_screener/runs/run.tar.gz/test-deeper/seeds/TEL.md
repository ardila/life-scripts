I have enough material. Writing the dossier now.

# TEL — Tokyo Electron Limited (8035.T / TOELY)

## Where this sits in the AI stack
TEL sells semiconductor process equipment to the fabs that manufacture every frontier AI chip and every HBM stack — it operates one layer below ASML in the lithography flow, and is a co-equal of Applied Materials and Lam Research in etch, deposition, cleaning, and thermal processing. Specifically: TEL's CLEAN TRACK coater/developer (a.k.a. "track") is the wafer prep + post-exposure tool bolted in-line with every ASML scanner; their cryogenic dielectric etchers attack 3D NAND high-aspect-ratio channels; their plasma and selective etch tools shape GAA nanosheets at TSMC N2 / A16 and Samsung SF2; their Synapse Si wafer-to-wafer (W2W) hybrid bonders and Synapse V temporary bond/debond tools sit inside the HBM stacking and CoWoS flows [1][2][9]. TEL touches every AI accelerator die and every HBM stack at multiple process steps, but does not sell anything that runs an inference token itself.

## Snapshot
- **Price:** ¥51,720 (2026-05-08 close; 2026-05-10 is Sunday) [3]
- **Market cap:** ¥21.7T / ~$151B USD [3][20]
- **52-week range:** ¥19,870 – ¥52,650 [4]
- **Forward P/E:** ~30–32× (implied on FY3/27 EPS in the ¥1,600–1,700 range after the +33% H1 guide; consensus tape EPS of ¥1,195 cited by Stockopedia appears stale vs. the post-guide print) [5][6]
- **EV / NTM revenue:** ~6.5–7× (NTM revenue ~¥3.0T post-guide; net-cash balance sheet, so EV ≈ market cap less ~¥0.5T cash) — inferred from disclosed H1 FY27 sales guide of ¥1,570B [6][7]
- **Consensus 12-month price target:** ¥50,238 (implied −2.9% from spot — i.e., the tape has caught up to the sell side and run past it) [21]
- **YTD total return:** ~+25–30% — inferred; +16.5% single-day move on May 8 on the FY26 print [3][22]
- **Short interest (% of float):** n/a — Japanese single-name short data is sparse and not reliably reported in the same form as US tickers

## Moat — what it is physically made of
TEL's moat is **not one thing**. It is four physically distinct franchises with very different durability profiles:

**1. Coater/developer ("track") — near-monopoly, deepest moat.** ~90% global share, ~100% of EUV-compatible tracks installed [2][8][9]. The track sits in-line with the ASML scanner; a single wafer flows coat → bake → expose (in the scanner) → post-exposure bake → develop without breaking environment. The technical lock-in is **chemistry-physics co-engineering**: chemically amplified resists (CAR) require post-exposure bake control to within sub-degree temperatures; metal-containing resists (MOR, e.g. Inpria's tin oxide systems used at SK Hynix and Intel) require non-aqueous develop chemistry; dry-resist development (Lam's bid to disrupt the segment) requires a vacuum-integrated process step that TEL's LITHIUS Pro Z platform now incorporates [10]. The cooperation with ASML dates to 2003 and has been re-cemented for High-NA: TEL installed an EUV track at the imec-ASML High-NA lab in Veldhoven in 2021 and is the only track vendor on the EXE:5000 platform [8][9]. **Person-years to replicate:** SCREEN Semiconductor (the only other meaningful track vendor) has had 20+ years to take share and sits at ~5–8% [11]. Replication at parity is not a 3-year project; it is a generational one.

**2. Cryogenic dielectric etch (HARC) — moat under construction, attacking Lam's monopoly.** Until ~2023, Lam owned essentially 100% of the channel-hole etch on 3D NAND (cuts a 10-μm contact through 200+ stacked oxide/nitride layers with <0.1% CD deviation top-to-bottom). TEL's cryogenic etcher (negative tens of °C, ML-tuned recipe, fluorocarbon-free) etches a 10-μm hole in 33 minutes, ~2.5× the prior throughput, and cuts global warming potential ~84% [12][13][14]. Lam responded with Cryo 3.0 [15]. This is a contested duopoly now, not a Lam monopoly. The economic value of the share TEL takes here scales directly with the 3D NAND layer count (400+ layers shipping in 2026, ~1,000 layers on the YMTC/Micron/SK Hynix roadmaps for 2028–29).

**3. Wafer-to-wafer (W2W) hybrid bonding & temporary bonder/debonder — emerging position.** TEL holds ~20% in W2W hybrid bonding via the Synapse Si platform and is the market leader in temporary bonder/debonder, which is consumed heavily in HBM stacking [16][17]. The 2026 Synapse-class bonder has integrated X-ray metrology directly in the bonder head — i.e. measures die-to-wafer alignment in real time and corrects before contact, eliminating the metrology-bonder loop that has capped hybrid-bonding yields industry-wide [17]. TEL projects the bonder TAM at ¥100B (2025) → ¥300B (2030); 60% growth in advanced packaging revenue in FY26 already booked [18]. **This is the most contestable franchise** — BESI (the die-to-wafer hybrid-bonding incumbent in alliance with Applied Materials' Kinex integrated platform) is the structural threat [19].

**4. Customer co-development infrastructure.** ¥1.5T 5-year R&D commitment (FY25–29) plus ¥700B capex, with a 10,000-person hire plan (50% headcount expansion off ~20k base); new Kumamoto R&D hub physically adjacent to TSMC's JASM site for sub-2nm co-development; participation in NY Creates / Albany Nanotech High-NA EUV center [11][23]. This is the engineering substrate that lets TEL keep its track and etch positions current as nodes advance — not a "moat" by itself, but a moat-maintenance machine that competitors have to fund symmetrically.

What TEL **does not** have a structural moat in: CVD/ALD deposition (Applied Materials is roughly 2× larger here and has the better integrated stack); metrology/inspection (KLA's franchise, untouched); ion implant (AMAT).

## AI buildout bottleneck map
The actual gating constraints on the 2026–27 AI buildout, and TEL's exposure to each:

- **Power generation & grid interconnect.** Indifferent. TEL sells fab tools, not data-center equipment.
- **Advanced packaging (CoWoS-L) capacity.** **Beneficiary, indirect.** TSMC is roughly doubling CoWoS capacity through 2026 and adding 14-reticle CoWoS by 2028 [24][25]. TEL sells the temporary bonder/debonder, RDL formation tooling, and increasingly W2W hybrid bonders consumed in this expansion.
- **HBM (3e/4) yield and unit volume.** **Beneficiary, direct.** TEL's hybrid bonder TAM 3×'s into HBM4-with-hybrid-bonding (postponed for some vendors but on roadmap [26]); TBDB consumed per HBM stack; cryo etch into the DRAM cell stack scales with capacity.
- **EUV / High-NA EUV scanner availability.** **Co-beneficiary with ASML.** TEL ships a track per ASML scanner. High-NA inflects 2026–27.
- **Liquid cooling, optical interconnect, electrical contracting.** Indifferent.
- **Kernel / compiler talent.** Indifferent.
- **Training data quality.** Indifferent.
- **Chinese WFE demand cycle.** **Exposed.** China was 26.8% of revenue in FY26 Q4, down from 47.4% in FY24 Q4 [27]; further compression is the bear case (see below).

In one sentence: TEL is a **secondary-but-broad beneficiary** of AI capex — broader than ASML (which is single-product) and more contested than KLA (which has a true inspection monopoly), but with the unique property that almost every AI buildout vector except power flows through one or more of its tools.

## Competitive teardown

**vs. Lam Research — etch & advanced packaging.**
- *3D NAND channel hole (HARC):* Lam had ~100% share; TEL is now a credible second source with cryogenic etch and has won qualification at SK Hynix and Micron (per Nikkei/Yole reporting through 2024–25 [13][14]). Lam responded with Cryo 3.0 [15]. Genuine duopoly now.
- *Atomic layer etch, GAA selective etch:* roughly even; node-by-node share swings.
- *Dry resist:* Lam pursued vacuum dry-resist as a track displacement; TEL has integrated dry-resist process into the LITHIUS platform, neutralizing the threat at the toolset level [10].

**vs. Applied Materials — deposition, hybrid bonding, materials.**
- *PVD, epi, implant:* AMAT dominant; TEL not a major participant.
- *ALD / selective deposition:* AMAT slightly ahead in scale; TEL competitive on advanced node ALD for GAA work-function metal and high-k.
- *Hybrid bonding:* AMAT + BESI integrated Kinex platform [19][28] is the structural challenge to TEL's Synapse Si. A consummated AMAT-BESI consolidation would concentrate the entire die-to-wafer hybrid bonding stack in one vendor, leaving TEL with W2W and temporary bonding.

**vs. BESI / ASMPT — die-to-wafer hybrid bonding.**
- BESI is the precision incumbent on D2W hybrid bonding (the format that matters for HBM4-and-beyond and chiplet stacking). ASMPT has scale + temporal bonding strength. TEL's W2W path is technically different (whole-wafer bonding before dicing) and serves different customers (CMOS image sensors, future 3D logic-on-memory) but **does not directly compete on the HBM hybrid-bond TAM** — that is the BESI/AMAT vs. ASMPT contest. This is the franchise where TEL is most exposed to having a "good but not winning" position [16][19][26].

**vs. NAURA, AMEC, SMEE (China domestic).**
- China is now under a 50% domestic-equipment-content mandate for new fabs [29][30]. NAURA furnaces are >60% of SMIC 28nm capacity already; NAURA etch is in 7nm trial at SMIC [31]; AMEC claims 5nm-and-below etch tools and targets >60% in-house in 5–10 years [31].
- TEL's response: drop China share from ~47% to ~27% of revenue and pivot to advanced-node and AI customers in Taiwan, Korea, US, Japan [27]. This is working in the aggregate but it is a one-way ratchet — share lost to NAURA/AMEC in mature-node fab equipment will not come back.

**vs. SCREEN Semiconductor — coater/developer.**
- The only direct track competitor. ~5–8% share, no meaningful EUV position, no High-NA participation. Not a credible 24-month threat.

**vs. ASML.**
- Not a competitor; structural complement. The track-scanner co-engineering is the bedrock of TEL's strongest franchise.

## Bull case — technical
The technical conditions that need to hold for the stock to compound from here:
1. **High-NA EUV ramps on time at TSMC, Intel, Samsung in 2026–27.** Each High-NA scanner ships with a TEL track. ASML's ramp is the leading indicator.
2. **GAA nanosheet manufacturing remains etch-and-deposition intensive.** N2 / A16 / Intel 18A / Samsung SF2 transistor formation requires more selective etch and ALD steps per wafer than FinFET — TEL benefits broadly even where it doesn't lead.
3. **HBM stack count grows (12-Hi → 16-Hi → hybrid-bond era).** Temporary bonder/debonder is consumed per stack — TEL's most reliable HBM exposure, independent of who wins the D2W hybrid-bond contest.
4. **3D NAND restart.** NAND capex troughed in 2023; SEMI expects +12.7% in 2026 [32]. TEL's cryo etch wins compound on this cycle.
5. **AMAT-BESI integration is slow or messy.** Buys TEL 18–24 months to scale Synapse Si into a credible second source.

**Base rate on this kind of franchise displacement:** capital-equipment monopolies in semiconductors have historically taken 10–20 years to erode meaningfully (Lam in HARC etch, KLA in patterned wafer inspection, ASML in EUV). Equipment customers are extremely conservative — a tool change is 12–18 months of qualification per recipe. So TEL's coater/developer franchise is structurally durable on a 5-year view; its etch and packaging positions are durable on a 2–3 year view; only the hybrid-bonding *D2W* position is at near-term risk.

**Financial mapping:** WFE TAM ¥125B → ¥139B → $156B (2025/26/27 SEMI consensus) [32][33]. TEL is guiding +33% H1 sales growth on a 25–30% WFE growth assumption [22], implying margin leverage from mix shift to advanced nodes (gross margin already 46.8% Q4, medium-term target >50%) [34].

## Bear case — technical
What a short-seller who actually reads MLPerf and SEMI World Fab Forecast would write:

1. **The cycle has already inflected.** Stock is +98% TTM, +16.5% in one session on the FY26 print [3]. Forward multiple ~30× on a cyclical name is not cheap — analogous TEL peaks (2017, 2021) preceded 40–55% drawdowns when memory rolled. The 52-week low (¥19,870) was eight months ago.
2. **Hybrid bonding consolidates around AMAT-BESI.** If Applied Materials closes a BESI deal or extends the Kinex partnership into exclusive D2W tooling, TEL's hybrid-bonding TAM is partially capped before it scales [19][28]. ¥300B 2030 TAM becomes ¥150B and TEL's share within it gets pressured.
3. **China decouples faster than priced.** 50% domestic mandate is now policy; NAURA etch in 7nm trial; AMEC at 5nm [29][31]. The base case is China revenue compresses further from 27% toward 15% over 24 months. Some of that is offset by Taiwan/Korea/US but at lower margin per tool because of competitive intensity at the bleeding edge.
4. **Cryo etch share gains are slower than narrative.** Lam's Cryo 3.0 closes the throughput gap; HARC etch is qualified per fab line, and changing vendor on an in-flight 3D NAND ramp is a 12+ month requalification. The Nikkei narrative ("TEL takes aim at Lam") overstates the velocity.
5. **Yen weakness reverses.** ~50% of TEL's reported revenue strength since 2022 is FX translation. If USDJPY normalizes to 130 from ~150, FY27 reported revenue takes a high-single-digit hit at constant volumes.
6. **High-NA EUV slips.** TSMC has been quiet on High-NA commitment for A14; if N2P/A16 hit volume with standard EUV (which they will [35]), High-NA scanner shipments are pushed out, and TEL's tracks-per-scanner attach pushes out with them.

## Market view check
At ¥51,720, TEL trades at ~30× forward EPS and ~7× EV/NTM revenue, ~98% above its 52-week low and right at consensus PT. The market is pricing the strongest TEL franchises (track + etch + temporary bonding) as structurally durable through the High-NA EUV cycle, plus assigning credit for the hybrid-bonding optionality. I broadly agree with the durability of the first three; the hybrid-bonding credit is the part that looks priced for execution that hasn't happened yet. There is also a cyclical risk the tape is ignoring: TEL has historically given back 40%+ when memory capex inflects down, and at 30× forward, the cushion is thin. The stock looks **fairly valued on the technical merits, expensive on cycle position** — i.e., I'd be a buyer on a 25–30% drawdown driven by memory air pocket or Chinese-WFE shock, not at the highs.

## 90-day falsifiers
Specific, observable, dated:
1. **Aug 6, 2026 — Q1 FY27 earnings.** Confirms or breaks the +33% H1 sales guide. A >5% downward revision is a material thesis break.
2. **TSMC, Samsung, SK Hynix Q2 FY26 earnings (late July).** Capex run-rates and 2026 capex revisions. Particularly: TSMC CoWoS unit guidance for 2027 and Samsung HBM4 qualification status at Nvidia.
3. **AMAT–BESI corporate development.** Any acquisition announcement, exclusive partnership extension, or Kinex roadmap update [19][28] that locks D2W hybrid bonding into the AMAT stack.
4. **ASML Q2 earnings (July) — High-NA shipments and 2026 backlog.** TEL's track attach rides directly on this.
5. **SEMI World Fab Forecast Q2 2026 update.** Watch 2026 WFE estimate vs. the +9% / $139B baseline; a cut below +5% would invalidate the bull-case TAM math.
6. **China domestic-equipment-share data.** SEMI quarterly disaggregation by region/vendor — if NAURA + AMEC combined cross ~40% of China WFE in 2026 (vs. ~35% in 2025 [29]), the bear-case decoupling thesis accelerates.
7. **MLPerf Inference v5.0 (likely Sep 2026).** Indirect: if AMD MI400 / Trainium 3 close the gap to Blackwell at scale, AI capex broadens beyond NVIDIA and TSMC, raising rather than lowering process-equipment TAM. Bullish for TEL.

## What I could not verify
- Exact FY27 consensus EPS post-guide — published consensus (¥1,195) appears not to have been updated after the +33% H1 guide; my forward P/E is an inferred range.
- TEL's specific share in High-NA EUV coater/developer (claimed 100%, but only one toolset is in operation at the imec-ASML lab; not strictly a "share" until volume installations begin).
- Whether the AMAT-BESI relationship is moving toward acquisition or remains partnership; the Tiger Brokers / FinancialContent reporting [19][28] suggests both AMAT and Lam are interested but is not primary-sourced.
- TEL's exact participation in the temporary-bond/debond TAM growth (claimed "market leader" but no public market-share number).
- Specific MLPerf or hyperscaler-disclosed qualification of TEL's cryo etcher at SK Hynix and Micron beyond the Nikkei reporting [14].
- Short interest on 8035.T — Japanese single-name short-interest disclosure is sparse.
- The split between yen weakness and unit volume in TEL's reported revenue growth FY24–FY26; I can infer this is material but cannot decompose it precisely without the company's constant-currency disclosure.

## Sources
[1] https://www.tel.com/product/ — retrieved 2026-05-10 — TEL product line: track, etch, deposition, cleaning, thermal, test, bonding.
[2] https://www.klover.ai/tokyo-electron-ai-strategy-analysis-of-dominance-in-semiconductor-equipment/ — retrieved 2026-05-10 — Coater/developer >88% share, 100% EUV track share.
[3] https://meyka.com/blog/8035t-stock-surges-165-on-may-8-2026-tokyo-electron-jpx-gains-0705/ — retrieved 2026-05-10 — May 8, 2026 close ¥51,720, +16.5% intraday on FY26 results.
[4] https://stockinvest.us/stock/8035.T — retrieved 2026-05-10 — 52-week range ¥19,870–¥52,650, 12-month total return ~+98%.
[5] https://www.stockopedia.com/share-prices/tokyo-electron-TYO:8035/ — retrieved 2026-05-10 — FY27 consensus EPS ¥1,195 (appears pre-guide).
[6] https://in.investing.com/news/company-news/tokyo-electron-fy2026-slides-q4-beats-fuel-40-growth-outlook-93CH-5374622 — retrieved 2026-05-10 — H1 FY27 sales guide ¥1,570B; +33% growth; 27.5% operating margin.
[7] https://www.tickerreport.com/banking-finance/13340191/tokyo-electron-otcmktstoely-updates-fy-2026-earnings-guidance.html — retrieved 2026-05-10 — FY26 revenue ¥2,443.5B; net income ¥574.4B; EPS ¥1,254.57.
[8] https://www.tel.com/news/topics/2021/20210608_001.html — retrieved 2026-05-10 — TEL coater/developer at imec-ASML High-NA EUV lab, integrated with EXE:5000.
[9] https://www.eetimes.com/asml-tokyo-electron-team-for-advanced-litho-tools/ — retrieved 2026-05-10 — ASML-TEL strategic alliance for advanced litho, since 2003.
[10] https://newsletter.semianalysis.com/p/lam-research-tokyo-electron-jsr-battle — retrieved 2026-05-10 — Dry resist competitive dynamic: Lam vs TEL track integration.
[11] https://www.nomadsemi.com/p/tokyo-electron-deep-dive-part-1 — retrieved 2026-05-10 — TEL franchise breakdown, R&D history, SCREEN positioning.
[12] https://www.tel.com/news/product/2023/20230609_001.html — retrieved 2026-05-10 — Cryogenic 3D NAND channel etch: 10-μm depth, 33 min, 84% GWP reduction.
[13] https://semianalysis.com/2023/07/16/nand-flash-monopoly-broken-tokyo/ — retrieved 2026-05-10 — TEL breaking Lam's HARC etch monopoly with cryo etch + Moly dep.
[14] https://asia.nikkei.com/business/tech/semiconductors/tokyo-electron-takes-aim-at-nand-etching-leader-lam-research — retrieved 2026-05-10 — TEL targeting Lam's 3D NAND etch share.
[15] https://investor.lamresearch.com/2024-07-31-Lam-Research-Introduces-Lam-Cryo-TM-3-0-Cryogenic-Etch-Technology-to-Accelerate-Scaling-of-3D-NAND-for-the-AI-Era — retrieved 2026-05-10 — Lam Cryo 3.0 response, <0.1% CD deviation across 10-μm depth.
[16] https://www.semiconsam.com/p/hbm-hybrid-bonding-the-companies — retrieved 2026-05-10 — TEL ~20% W2W bonder share; CMP roles in hybrid bonding.
[17] https://www.trendforce.com/news/2026/01/23/news-chip-tool-giants-accelerate-advanced-packaging-push-led-by-asml-tokyo-electron-and-others/ — retrieved 2026-05-10 — TEL 2026 bonder integrates X-ray metrology in bonder head; bonder TAM ¥100B (2025) → ¥300B (2030).
[18] https://www.tel.com/ir/policy/mplan/i9nanv00000000ga-att/20250226_TELIRDay_E_rev.1_slide_r3.pdf — retrieved 2026-05-10 — TEL IR Day deck: advanced packaging revenue, R&D plan.
[19] https://www.itiger.com/news/1159006392 — retrieved 2026-05-10 — Reports of AMAT / Lam interest in acquiring BESI; hybrid bonding consolidation.
[20] https://companiesmarketcap.com/tokyo-electron/marketcap/ — retrieved 2026-05-10 — TEL market cap ~$151B USD (May 2026).
[21] https://www.investing.com/news/analyst-ratings/bernstein-raises-tokyo-electron-stock-price-target-on-strong-2026-outlook-93CH-4491126 — retrieved 2026-05-10 — Bernstein PT raise, consensus PT ~¥50,238; buy rating.
[22] https://www.ainvest.com/news/tokyo-electron-defies-5-wfe-slump-40-ai-sales-pivot-raised-profit-outlook-2604/ — retrieved 2026-05-10 — TEL guides on 25–30% WFE growth in 2026; AI-driven pivot.
[23] https://www.trendforce.com/news/2025/10/16/news-tokyo-electron-builds-major-kumamoto-rd-hub-near-tsmc-to-advance-1nm-chip-equipment/ — retrieved 2026-05-10 — Kumamoto R&D hub adjacent to TSMC JASM site.
[24] https://markets.financialcontent.com/wral/article/tokenring-2026-1-1-the-great-packaging-pivot-how-tsmc-is-doubling-cowos-capacity-to-break-the-ai-supply-bottleneck-through-2026 — retrieved 2026-05-10 — TSMC ~doubling CoWoS through 2026.
[25] https://www.tomshardware.com/tech-industry/semiconductors/tsmcs-details-next-gen-cowos-roadmap-over-14-reticle-packages-and-48x-leap-in-compute-power-expected-by-2029-massive-size-enables-24-hbm5e-stacks-and-additional-memory-bandwidth-jump — retrieved 2026-05-10 — TSMC 14-reticle CoWoS by 2028; 24 HBM stacks roadmap.
[26] https://semiengineering.com/hbm4-sticks-with-microbumps-postponing-hybrid-bonding/ — retrieved 2026-05-10 — HBM4 sticks with microbumps; hybrid-bonding migration deferred for some vendors.
[27] https://www.trendforce.com/news/2025/12/08/news-tokyo-electron-sees-ai-driven-sales-hitting-40-by-2026-offsetting-china-slowdown/ — retrieved 2026-05-10 — China revenue 26.8% Q4 FY26 vs. 47.4% Q4 FY24.
[28] https://www.eetimes.com/applied-materials-besi-push-die-to-wafer-hybrid-bonding-toward-high-volume-manufacturing/ — retrieved 2026-05-10 — AMAT-BESI Kinex integrated D2W hybrid bonding platform.
[29] https://japantoday.com/category/tech/exclusive-china-mandates-50-domestic-equipment-rule-for-chipmakers-sources-say — retrieved 2026-05-10 — China 50% domestic-equipment-content mandate.
[30] https://www.trendforce.com/news/2026/01/12/news-chinas-domestic-chip-equipment-adoption-beats-2025-target-at-35-led-by-naura-amec/ — retrieved 2026-05-10 — China domestic chip equipment adoption hits 35% in 2025.
[31] https://247wallst.com/technology-3/2026/05/01/chinas-semiconductor-equipment-companies-gain-share-despite-u-s-sanctions/ — retrieved 2026-05-10 — NAURA etch in 7nm SMIC trial; AMEC 5nm logic etch claim.
[32] https://www.semi.org/en/semi-press-release/global-total-semiconductor-equipment-sales-forecast-to-reach-a-record-of-dollar-139-billion-in-2026-semi-reports — retrieved 2026-05-10 — SEMI 2026 equipment TAM $139B; WFE +9.0% in 2026, +7.3% in 2027; NAND +12.7%.
[33] https://www.semi.org/en/semi-press-release/global-semiconductor-equipment-sales-projected-to-reach-a-record-of-156-billion-dollars-in-2027-semi-reports — retrieved 2026-05-10 — SEMI 2027 equipment TAM $156B.
[34] https://www.theglobeandmail.com/investing/markets/stocks/TOELY/pressreleases/1727859/tokyo-electron-signals-robust-start-despite-margin-strain/ — retrieved 2026-05-10 — TEL FY27 H1 27.5% operating margin guide; medium-term GM >50% target.
[35] https://www.anandtech.com/show/18832/tsmc-outlines-2nm-plans-n2p-brings-backside-power-delivery-in-2026-n2x-added-to-roadmap — retrieved 2026-05-10 — TSMC N2P with backside power delivery in 2026; A16 in 2H 2026.