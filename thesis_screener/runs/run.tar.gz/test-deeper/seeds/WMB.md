# WMB — The Williams Companies, Inc.

## Where this sits in the AI stack
WMB is not in the compute or memory layers — it is at the **fuel + on-site power generation** layer underneath them. Concretely it owns and operates the 10,000-mile Transco interstate natural-gas pipeline (≈19.5 Bcf/d throughput, ~200 Bcf of storage) connecting Marcellus/Haynesville production basins to the Mid-Atlantic and Southeast load centers where most U.S. hyperscale training and inference capacity is being sited; and is now selling the molecule **plus** the kWh at the meter via behind-the-meter (BTM) gas-fired generation built specifically for AI campuses (Socrates 400 MW for Meta in Ohio; Neo Power 682 MW)[1][3][4][5]. The relevant workload is 24/7 base + ramping load — i.e. training clusters and large-batch inference — that grid utilities in PJM/Dominion cannot currently interconnect on the timelines hyperscalers demand[13][15].

## Snapshot
- **Price:** $74.25 (2026-05-06 close — most recent intraday data I could verify; the May 8 close was not separately confirmed)[1]
- **Market cap:** ~$91.7 B[1]
- **52-week range:** $55.82 – $77.41[24]
- **Forward P/E:** 33.0× on consensus FY26 EPS (trailing 34.9×)[22]
- **EV / NTM EBITDA:** ~15.4× on FY26 mid-point guide ($8.2 B), ~18× on trailing[23][3]
- **Consensus 12-month price target:** $78.60–$79.68 (avg of 23 analysts; high $90, low $60; 21 Buy / 1 Sell / 3 Hold) — implied ~+6–7% from spot[24]
- **YTD total return:** approximate +13–18% (derived from 52-wk range and dividend; exact 2025 year-end close not verified — flagged below)
- **Dividend yield:** ~2.83% ($2.10 annualized)[24]
- **Short interest (% of float):** n/a — could not verify a current figure

## Moat — what it is physically made of
Williams' moat is **physical right-of-way and FERC-certificated incumbency**, not technology. Decomposed:

1. **The Transco corridor itself.** Built originally 1948–50 and continuously expanded under grandfathered certificates, it runs from the Agua Dulce / South Texas supply zone up to Station 210 in NJ/NY, passing through Station 165 in Pittsylvania County, VA — the precise injection point that feeds Virginia, the Carolinas, Georgia and Alabama[7][9]. Replacing this corridor greenfield is functionally impossible today: the Mountain Valley Pipeline took ~10 years and required an act of Congress to finish, and Atlantic Coast Pipeline was abandoned after $3.4B sunk. Williams therefore enjoys a regulatory + NIMBY moat that has **strengthened** since 2015 even though the asset has aged. Brownfield expansions (compression, looping, replacements-in-kind) clear FERC in 18–30 months vs. 5–10+ years for greenfield[8].
2. **Station 165 as a chokepoint.** The Southeast Supply Enhancement (SSE, 1.6 Bcf/d, $1.53B, FERC-approved, Q4 2027 in-service) and Power Express (750 MMcf/d, in-service 2030) both originate at Station 165[8][9]. WMB owns the only large-diameter mainline that can be looped to move Appalachian gas to Dominion/Duke power-burn south of the Mason-Dixon at the scale needed. This is durable — it is the physical analog of owning the only fiber trench into a city.
3. **Storage.** ~200 Bcf of working gas storage gives WMB swing/peaking capability that matters when a 200 MW BTM campus has to ride through a polar vortex or a Henry Hub spike. Storage is the **batteries for the gas grid** and the supply is largely fixed.
4. **Contract structure.** New BTM and pipeline contracts are 10–13 years take-or-pay (Atlas 13 years; Neo 12.5 years; Socrates is long-term with a Meta affiliate)[3][4][6]. This converts the moat into recurring fee-based EBITDA rather than commodity exposure.
5. **What is *not* a moat.** The turbines themselves (Solar Turbines Titan 250, Siemens SGT-400, Caterpillar 3520 reciprocating engines used at Socrates[4]) are commodity off-the-shelf — anyone with capital and a delivery slot from GE Vernova / Siemens / MHI can buy them. WMB's "Power Innovation" segment is asset-aggregation and contract structuring, not proprietary tech. The defensibility there is mostly **integration with the underlying pipe** (you have to bring the gas in anyway), and being early in the queue with turbine OEMs.

**Person-years to replicate:** the corridor itself is essentially un-replicable on any commercial timeline. Replicating the Power Innovation business is mostly a financing-and-EPC exercise — 18–36 months per site if turbine slots are available, which they largely aren't through 2029[10][11][12].

## AI buildout bottleneck map
Specific 24-month gating constraints and WMB's posture vs. each:

- **Grid generation + interconnect (PJM/Dominion):** Summer 2027 is the first season PJM expects to be short of capacity; PJM capacity prices have risen from $28.92/MW-day (2024/25) to $329.17/MW-day (2026/27); interconnection queue waits exceed 36 months and Cycle #1 doesn't seat new gen until Aug 2027[13][14][15]. **WMB = direct beneficiary** — every quarter PJM is short and every hyperscaler that wants 2027 power, BTM gas is the only physically deliverable answer.
- **Gas turbines (large-frame + aero-derivative + recips):** GE Vernova's gas-turbine reservations + backlog grew from 83 GW to 100 GW in Q1 2026; CEO expects to be sold out through 2030 by end-2026; Mitsubishi and Siemens slots are largely booked 2027–28[10][11][12]. **WMB = exposed customer** — every additional BTM site requires turbines they have to compete for. Socrates was de-risked by mixing in Cat 3520 recip engines for fast-start capacity[4], which is a smart workaround but limits scale.
- **Advanced packaging / HBM / optical interconnect:** indifferent — WMB is downstream of compute, doesn't sell into these.
- **Liquid cooling at >100kW/rack:** indifferent except insofar as it raises kW/site and therefore gas demand. Increases TAM, doesn't create a constraint for WMB.
- **Electrical contractor & substation transformer capacity:** **constraint on BTM execution** — large-frame GSU transformers run 24–36 month lead times. WMB is a customer here.
- **FERC/state regulatory capacity (pipeline + colocation):** WMB has the strongest incumbent FERC position in midstream (SSE cleared in early 2026)[8][9]. Separately, FERC's Nov-2024 / Mar-2026 rejection of the Talen-AWS amended ISA at Susquehanna and the order directing PJM to design colocation rules **favors** WMB's design choice — Socrates is explicitly *not* physically connected to the grid[4], which sidesteps the colocation tariff fight entirely[20][21].
- **Supply (Marcellus/Haynesville production):** Haynesville +1.2 Bcf/d in 2026 to 15.6 Bcf/d; Appalachia +0.3 Bcf/d 2026 + 0.5 Bcf/d 2027[16][17]. **WMB = beneficiary** — Transco is the marquee Marcellus take-away into the highest-priced demand basins.
- **Training data quality / model algorithm efficiency:** the one real demand-side risk. See bear case.

## Competitive teardown
The right way to score this is **by basin and by mile**, not by name.

- **Kinder Morgan (KMI).** Backlog ~$9.3B, ~50% power-driven, ~$3.4B capex 2026[18]. KMI's Tennessee Gas / SNG systems compete in the Southeast and Texas. KMI does **not** own the Transco corridor and cannot directly serve the Station 165 → Dominion Virginia route at scale. Effective parity in Texas/Gulf, structural disadvantage in Mid-Atlantic.
- **Enbridge (ENB).** **The actual peer threat.** Texas Eastern + Algonquin reach into PJM and ENB explicitly claims gas systems within 50 miles of 29 new data centers[19]. Texas Eastern can compete head-to-head for Virginia load on routes from Marcellus. Where Williams has SSE looping, ENB has TETCO expansions in flight. This is genuine route competition — bull/bear depends on which FERC docket clears faster.
- **Energy Transfer (ET).** ERCOT-centric (CloudBurst 0.45 Bcf/d)[19]. Texas is a separate, larger AI market (Stargate-class campuses) where WMB has limited assets. ET wins Texas; WMB wins PJM South.
- **TC Energy (TRP).** Columbia Gas footprint overlaps WMB on Appalachian takeaway; in discussions with 30+ counterparties but slower commercial cadence in disclosed contracts.
- **Behind-the-meter direct competitors.** Crusoe, Vantage, Constellation (nuclear PPAs), Vistra, GE Vernova (selling turn-key) — these all compete in BTM gen, but **only WMB couples BTM gen with owned pipeline injection rights**. A pure BTM gen developer still has to buy transport from someone, often Transco.

The honest summary: WMB has **structural advantage in PJM South / Mid-Atlantic**, **parity at best in Texas and the Gulf**, and **a software-style network effect** (every pipe added increases optionality on the next BTM site). It is *not* a monopoly — it is a regionally dominant utility.

## Bull case — technical
For WMB to compound at the implied EBITDA growth (10%+ CAGR through 2030 per Q1 2026 guide[3]) the following must hold:

1. PJM remains capacity-short through 2028 and Dominion's 4 GW data-center load behind its substation cap forces hyperscalers to BTM rather than wait for the queue[13][15]. Base rate: power infrastructure shortages in deregulated US markets historically last 4–7 years from onset of price signal (Texas '21–'25; California '00–'04) — points to a tailwind through at least 2028.
2. FERC's evolving colocation rules continue to make grid-connected colocation legally fraught, pushing customers to **physically islanded** BTM designs (Socrates model). The Mar-2026 rehearing rejection on Susquehanna is the leading indicator[20][21].
3. Gas turbines remain capacity-constrained — WMB's early reservations (Socrates already in Q3 2026 commissioning) become more valuable, not less, as slot prices rise[10][11].
4. Haynesville/Marcellus continue to add 1.5–2 Bcf/d/yr of supply, keeping basis differentials between supply basins and Transco Zone 5/Zone 6 attractive enough that producers pay for firm transport[16][17].
5. No SMR commercial deployment at scale before 2030 (base rate: nuclear first-of-a-kind has slipped 100% of the time in the modern era).

Under these conditions, WMB's $7B+ Power Innovation backlog converts to a recurring fee-based stream that re-rates the multiple from a 15× EV/EBITDA midstream toward 18–20× — i.e. closer to a regulated utility growth name — and the stock outperforms.

## Bear case — technical
The honest short-seller's version:

1. **Algorithm/silicon efficiency outruns power demand.** This is the one technical falsifier that midstream bulls under-weight. The training FLOP/$ improvement from Hopper→Blackwell→Rubin is ~3× per generation, and the inference Watts/token improvement from FP16→FP8→FP4 with sparsity has been ~4× over 24 months. If the next 24 months deliver another 5–10× combined efficiency improvement and frontier model size growth saturates (a real possibility given diminishing returns on pre-training observed since GPT-4-class), 2027 power demand could come in 30–40% below current hyperscaler capex guidance. Midstream multiples re-rate **down** before the contracted revenue starts.
2. **FERC ultimately blesses grid colocation.** If FERC's eventual PJM colocation order permits nuclear/renewable behind-the-meter without forcing full grid-tariff-paying interconnection, gigawatts shift from gas BTM toward Susquehanna-style nuclear PPAs. WMB's Socrates business model survives — physically isolated BTM is even cleaner — but Power Express and SSE come under pressure because some Virginia data center load is met by direct PPA to existing nuclear/renewable rather than incremental gas[20][21].
3. **Marcellus basis collapses.** If LNG export buildout slows (Trump-era permits notwithstanding) and Appalachian production keeps adding 800 MMcf-1 Bcf/d/yr without proportionate takeaway demand growth, Transco firm-transport renewal pricing weakens for the *non-AI* baseload portion of WMB's book. AI demand offsets, but doesn't fully replace, the legacy heating/industrial baseload economics.
4. **Turbine delivery slips.** If WMB cannot get turbines for FY27–28 Power Innovation projects, the backlog converts more slowly than the multiple implies. The Cat 3520 / Solar Titan workaround at Socrates is partly an admission that frame-class turbine slots aren't available[4][10].
5. **Multiple compression.** At 15× EV/EBITDA WMB is already trading two turns above its 12-month average and ~five turns above the pre-AI midstream regime. If the cycle rolls, the multiple is the variable that compresses fastest. Base rate on midstream multiple expansions reversing: 12–18 months from peak hyperscaler capex revision (cf. shale midstream 2014).

## Market view check
At $74 the market is pricing WMB at ~15× forward EV/EBITDA and ~33× forward earnings — explicitly the regulated-utility / data-center-utility band, not the historical midstream MLP band of 9–11×. Consensus PT $79.68 implies +7% — the sell side is essentially saying "the AI thesis is now correctly reflected, hold for the dividend and 10% CAGR." I think the market is **roughly right at the asset-level** but is under-pricing two specific things: (a) the optionality value of being the only BTM developer with a pipeline-integrated supply story in PJM South — that's a real call option on Power Express + SSE + follow-on Transco loops; and (b) the regulatory tailwind from FERC's anti-colocation drift, which de-facto subsidizes WMB's islanded-BTM design. Against that, the market is **under-discounting** algorithmic efficiency tail risk, which is the largest single bear-case factor and is genuinely hard to forecast.

## 90-day falsifiers
- **Q2 2026 earnings (early Aug):** Power Innovation backlog growth from $7.3B; any new BTM contracts disclosed by name (Anthropic, Microsoft, Oracle) — confirms or denies hyperscaler diversification.
- **Socrates Q3 2026 in-service.** If commissioning slips materially, every other BTM project's 2027–28 in-service date should be discounted.
- **FERC PJM colocation final order** (paper-hearing deadline runs through summer 2026)[21]. If FERC permits grid-tied colocation under a workable tariff, this is a small negative; if it doubles down on the Talen rejection, this is a positive.
- **GE Vernova / Siemens Q2 2026 backlog and slot-pricing updates** — if turbine slot prices for 2028 delivery rise sharply, WMB's early Socrates/Neo reservations gain in-the-money optionality; if they soften (signaling demand cooling), bear case strengthens.
- **Hyperscaler capex guidance revisions** (MSFT, META, GOOG, AMZN — all report mid-summer). A >10% sequential cut to FY27 capex from any two of the four would be the cleanest demand-side falsifier.
- **Marcellus rig count and Haynesville production prints** — sustained adds above the 1.5 Bcf/d/yr glide confirms the supply-side leg.

## What I could not verify
- **WMB May 8, 2026 closing price** (I have a verified May 6 close at $74.25 and a May 1 close at $75.54; haven't confirmed the Friday before today separately).
- **Exact YTD total return** — I don't have a verified 2025-12-31 close, so the +13–18% figure is an inferred band, not a measurement.
- **Current short interest % of float.**
- **Per-site contract economics on Socrates and Neo** — I have $/MW capex ($1.6B / 400 MW = $4 M/MW; $2.3B / 682 MW = $3.4 M/MW) but no disclosed capacity-payment $/kW-mo or fixed gas-spread terms, so I can't independently compute unlevered IRR vs. the 12–15% midstream return target the company implies.
- **WMB's actual turbine slot positions** with GE Vernova / Siemens / Solar Turbines beyond what is named in the Socrates FERC filing — I infer they are scarce/early but cannot quantify.
- **Specific share of the 4 Bcf/d "Northeast incremental data-center gas demand" that Williams expects to capture** vs. ENB/TRP/KMI on competing routes.
- **Power Express FID + customer name** — disclosed as 750 MMcf/d for Virginia data center growth but the specific anchor shipper(s) and offtake structure were not in any source I could pull.

## Sources
[1] https://247wallst.com/investing/2026/05/06/williams-eyes-13-upside-on-ai-data-center-boom/ — retrieved 2026-05-10 — WMB May 6 close $74.25, market cap $91.66B, current valuation context.
[2] https://www.investing.com/news/company-news/williams-q1-2026-slides-record-ebitda-data-center-push-accelerates-93CH-4660128 — retrieved 2026-05-10 — Q1 2026 deck summary; $9.6B data-center power strategy; 7.1 Bcf/d pipeline projects.
[3] https://www.businesswire.com/news/home/20260504880577/en/Williams-Announces-Record-First-Quarter-2026-Results — retrieved 2026-05-10 — Record Q1 EBITDA $2.25B; Atlas 164 MMcf/d / 13-yr; Neo Power 682 MW / 12.5-yr / $2.3B; Power Express upsized to 750 MMcf/d.
[4] https://www.williams.com/expansion-project/socrates-power-solution-facilities/ — retrieved 2026-05-10 — Socrates equipment list: Solar Titan 250, PGM 130, Siemens SGT-400, Cat 3520; 2×200 MW BTM design; dedicated 24-inch supply pipes.
[5] https://www.datacenterdynamics.com/en/news/ohio-regulators-approve-construction-of-200mw-gas-power-plant-to-serve-meta-data-center-in-new-albany-ohio/ — retrieved 2026-05-10 — Meta affiliate (Sidecat LLC) as Socrates offtaker; 740-acre New Albany campus.
[6] https://www.power-eng.com/gas/williams-pushes-deeper-into-power-generation-as-data-center-demand-accelerates/ — retrieved 2026-05-10 — Williams Power Innovation segment framing; Socrates $1.6B; H2 2026 ISD.
[7] https://pgjonline.com/news/2026/may/williams-tops-earnings-as-gas-demand-drives-transco-expansion — retrieved 2026-05-10 — Transco scale and corridor positioning.
[8] https://naturalgasintel.com/news/transco-gets-ferc-green-light-to-build-16-bcfd-southeast-natural-gas-supply-expansion/ — retrieved 2026-05-10 — SSE 1.6 Bcf/d, $1.53B, Q4 2027 in-service, Station 165 origination.
[9] https://www.ogj.com/pipelines-transportation/pipelines/news/55355355/transcos-16-bcfd-sse-expansion-receives-ferc-approval — retrieved 2026-05-10 — SSE corroboration and routing into Carolinas/Georgia/Alabama.
[10] https://www.power-eng.com/gas/turbines/data-centers-drive-record-surge-in-ge-vernova-power-equipment-orders-as-turbine-slots-tighten-through-2030/ — retrieved 2026-05-10 — GE Vernova turbine slots tightening through 2030.
[11] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — GE Vernova 80 GW backlog stretching into 2029.
[12] https://www.industrialinfo.com/iirenergy/industry-news/article/ge-vernovas-global-natural-gas-turbine-reservations-and-order-backlog-grows-to-100-gw--356705 — retrieved 2026-05-10 — Reservations + backlog 100 GW Q1 2026.
[13] https://www.utilitydive.com/news/solving-pjms-data-center-problem/805600/ — retrieved 2026-05-10 — PJM capacity shortfall framing.
[14] https://ieefa.org/resources/projected-data-center-growth-spurs-pjm-capacity-prices-factor-10 — retrieved 2026-05-10 — PJM capacity price $28.92 → $329.17/MW-day.
[15] https://introl.com/blog/pjm-grid-crisis-6gw-shortfall-data-center-power-2027 — retrieved 2026-05-10 — Summer 2027 PJM capacity-short forecast; Dominion 4 GW behind substation cap.
[16] https://naturalgasintel.com/news/williams-sees-haynesville-marcellus-fueling-data-center-growth/ — retrieved 2026-05-10 — Williams' view on Haynesville/Marcellus supply tie-in.
[17] https://www.hartenergy.com/upstream/shale-plays/he-appalachia-marcellus-utica-shale-2026/ — retrieved 2026-05-10 — Appalachia +0.3 Bcf/d (2026) +0.5 Bcf/d (2027); Haynesville +1.2 Bcf/d to 15.6 Bcf/d.
[18] https://www.klover.ai/kinder-morgan-ai-strategy-analysis-of-dominance-in-energy-infrastructure-ai/ — retrieved 2026-05-10 — KMI backlog mix and capex profile.
[19] https://www.etftrends.com/energy-infrastructure-content-hub/midstream-leans-ai-data-center-boom/ — retrieved 2026-05-10 — Enbridge 50-mile data-center proximity claim; ET CloudBurst 0.45 Bcf/d.
[20] https://www.utilitydive.com/news/ferc-interconnection-isa-talen-amazon-data-center-susquehanna-exelon/731841/ — retrieved 2026-05-10 — FERC rejection of Talen-Amazon Susquehanna amended ISA.
[21] https://www.utilitydive.com/news/ferc-pjm-colocation-data-center/808368/ — retrieved 2026-05-10 — FERC orders PJM to draft large-load colocation rules; March 2026 rehearing affirmation.
[22] https://stockanalysis.com/stocks/wmb/statistics/ — retrieved 2026-05-10 — Trailing 34.9× / forward 33.0× P/E.
[23] https://multiples.vc/public-comps/williams-companies-valuation-multiples — retrieved 2026-05-10 — EV/EBITDA 15.4×, EV/Revenue 10×.
[24] https://public.com/stocks/wmb/forecast-price-target — retrieved 2026-05-10 — Consensus PT $79.68 (n=23), 52-wk range $55.82–$77.41, dividend $2.10.
[25] https://eastdaley.com/media-and-news/wmbs-project-socrates-offers-enlightening-energy-solution — retrieved 2026-05-10 — Independent commentary on Socrates structure and Williams' Power Innovation strategy.