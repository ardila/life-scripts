I have enough material. Writing the dossier now.

```
# ADI — Analog Devices, Inc.

## Where this sits in the AI stack
ADI is a precision analog/mixed-signal silicon vendor whose AI exposure is concentrated in two non-glamorous but structurally important layers: (1) the **power conversion chain** that moves grid energy into a GPU socket — hot-swap controllers, 800V-to-48V first-stage converters, intermediate bus converters, multiphase PMBus controllers, smart power stages and vertical-power µModules — and (2) the **precision instrumentation silicon** (high-speed ADCs/DACs, references, amplifiers) embedded inside Teradyne and Advantest automated-test-equipment (ATE), which is how every NVIDIA, AMD, Google TPU, and HBM stack actually gets characterized before shipment.[1][2][3] ADI does not make GPUs, switch ASICs, optical DSPs, or HBM. Within the optical stack it sells signal-chain and monitoring content around the transceiver, not the 200G-per-lane DSPs/TIAs that Marvell, Broadcom, Semtech and TeraSignal contest at the data-path level.[4][5]

## Snapshot
- **Price:** $416.07 (2026-05-08 close)[6]
- **Market cap:** ~$204B[6]
- **52-week range:** $206.00 – $418.75[6]
- **Forward P/E:** ~34.4× (on consensus FY26 EPS ~$11.35)[6]
- **EV / NTM revenue:** ~15×  — inference from $204B market cap, ~$2B net cash, ~$13.5B NTM revenue using Q2 guide $3.5B × 4[2][6]
- **Consensus 12-month price target:** $393.16 (implies **-5.6%** from current; BofA at $425 represents the high-end-of-Street view)[7]
- **YTD total return:** +53.3%[6]
- **Short interest:** n/a — not reported in surfaced sources; ADI is a large-cap with historically low SI (~1–2%), but I could not confirm a precise current figure.

## Moat — what it is physically made of
ADI's moat decomposes into four distinct technical assets with very different durabilities.

**1. Precision mixed-signal IP (the core).** Multi-GSPS RF-sampling ADCs (e.g., AD9213, AD9088 / AD9084 "Apollo MxFE" — 16-bit 28GSPS DAC, 12-bit 20GSPS ADC core)[8][9], multi-channel synchronization for digital beamforming, sub-µV/°C reference IP, and the LTC analog regulator library inherited from the $14.8B Linear Technology acquisition (2017).[10] This IP is *cumulative* — built over 40 years of process recipes, layout know-how, and test characterization data on proprietary BiCMOS/BCD processes. New entrants don't replicate this in 3–5 years; the empirical base rate for displacement of top-3 analog mixed-signal incumbents over a 10-year window is effectively zero (TI, ADI, Infineon have held the leadership oligopoly since the 1990s through three semi cycles). This is the most durable component.

**2. Power IC portfolio (LTC + Maxim).** LTC388X-family multiphase PMBus controllers, smart power stages (vertical-power µModules sampled to first customer Q4 FY25), LTC3880/3882/3883 digital power managers, LTC4280/4282/4230 hot-swap, and the new 800VDC first-stage converters claiming >98% efficiency.[11][12][13] **This is the moat component most at risk in the AI buildout.** A new socket (vertical power on GB300/Rubin) means every vendor designs from scratch; design-in stickiness only kicks in *after* the win. ADI shipped to its first vertical-power customer last quarter; MPS has won more GPU power sockets historically due to lower cost and tighter integration into reference designs.[14] Linear Technology's brand premium translates to ~71% gross margin but does not by itself guarantee socket wins on Blackwell-Ultra or Rubin.

**3. Embedded content inside ATE platforms.** ADI silicon is standard instrumentation content in Teradyne FLEX/UltraFlex and Advantest V93000 testers. Once qualified into a tester platform, content lifecycles are 10+ years and re-qualification cost is prohibitive for ATE OEMs.[15][16] Roche disclosed on the Q1 FY26 call that **ATE is ~40% of ADI's $2B+ data-center run-rate**, i.e. ~$800M annualized.[1][2] The HBM4 ramp (12-Hi 32Gb stacks, ~2x test time per stack vs HBM3e) and the secular increase in AI accelerator complexity (chiplet count, package size, SLT requirements) make this a hidden tax on AI scale-out. Very high-quality moat — narrow but extremely durable.

**4. Hybrid manufacturing posture.** ADI fabs in Wilmington/Beaverton/Limerick/Camas for analog-specific nodes, layered with TSMC partnership including dedicated capacity at JASM (Kumamoto).[17][18] This is defensive value (capacity resilience during shortages, geopolitical insurance) not offensive moat. Less differentiated; competitors have similar postures.

What ADI **does not** have: a CUDA-style developer ecosystem lock-in, network-effect software, or a frontier-node process advantage. The moat is silicon IP, qualification history, and embedded incumbency — not platform economics.

## AI buildout bottleneck map
The 24-month gating constraints, with ADI's position on each:

- **Power generation / grid interconnect (turbine backlogs ~3–7 years for GE/Siemens gas turbines):** ADI **indifferent** — operates inside the rack, not upstream.
- **TSMC CoWoS-L advanced packaging:** ADI **indifferent** at gross product level (its mainstream parts are mature node), but the AD9084/AD9088 class of MxFE parts uses advanced packaging — they're tiny consumers vs. GPUs.
- **HBM3e/HBM4 yield and stack-level test:** ADI is a **beneficiary** indirectly — every HBM4 stack tested on Advantest V93000 carries ADI instrumentation silicon. The slower HBM yields, the *more* test time, the *more* ATE BOM consumption.[16]
- **800V/HVDC rack power distribution (NVIDIA's stated 2027+ architecture for 1MW racks):** ADI is a **supplier** — announced ecosystem partner in August 2025 alongside Infineon, MPS, Navitas, onsemi, Renesas, ROHM, ST, TI. TI announced its own complete 800VDC architecture with NVIDIA in March 2026, so the field is crowded.[12][19][13]
- **Liquid cooling >100kW/rack:** ADI **indifferent** at silicon level; some sensor/control content but not a primary play.
- **Optical interconnect at 200G/lane and CPO:** ADI is **exposed** — not a leader in the high-value DSP/TIA layer. Marvell's Ara 3nm 1.6T DSP, Broadcom's Sian3 PHY, Semtech GN1834D and TeraSignal TS9801 own the 200G/lane TIA market. ADI's optical revenue (~$600M run-rate, inferred from 30% of the $2B data-center figure) is signal-conditioning, monitoring, and power around the module — second-tier BOM content.[4][5][20]
- **Vertical/backside power delivery (the new socket emerging on GB300/Rubin):** ADI is a **contestant**, not yet a leader. First Smart Power Stage customer shipped Q4 FY25.[1]
- **GaN/SiC wide-bandgap transistors for 800VDC efficiency:** ADI is **exposed** — does not have a wide-bandgap discrete franchise at scale comparable to Infineon, onsemi, or Wolfspeed. This is a structural gap in the 800V story.

The honest read: ADI is a beneficiary of the *peripheral* layers of the buildout (test, mid-rack power conversion), but is not the gating supplier on any single constraint, and is genuinely outside the highest-IP optical and WBG layers.

## Competitive teardown
- **MPS (Monolithic Power Systems, $78B):** Direct competitor in GPU socket power delivery. MPS has won more high-volume sockets through lower cost and tighter integration into NVIDIA reference designs; ADI's LTC-heritage parts are premium-priced and known for documentation and reliability rather than cost-leadership.[14] **For ADI to gain share** here: the vertical-power transition (different socket entirely) has to favor LTC/Maxim's high-current density expertise. Plausible but unproven — first customer ship Q4 FY25 is one data point, not a trend.
- **Texas Instruments:** Broad-portfolio competitor; announced complete 800VDC architecture with NVIDIA in March 2026.[19] TI has internal fab scale advantage; ADI has higher gross margin (~71% vs ~58%). Co-existence likely on the 800VDC ecosystem; both win.
- **Infineon:** German power-discrete leader with strong WBG (SiC/GaN) franchise. **In the 800VDC architecture, Infineon's WBG transistors are the active devices; ADI provides controllers and hot-swap. This is symbiotic, but the higher-margin content (the transistors) accrues to Infineon, not ADI.** Possible bear case here.
- **Marvell / Broadcom (optical DSP):** Not a head-to-head competitor; they own the data-path silicon ADI doesn't make. ADI is content-adjacent in the optical module BOM, not on the value-defining lane.[4][20]
- **Semtech / TeraSignal (200G/lane TIAs):** ADI does not appear to compete at 200G/lane datacom TIA — its TIA portfolio (LTC6561/6563) is positioned for LiDAR and instrumentation, not 1.6T optical interconnect.[5] Material gap.
- **Renesas:** Direct competitor in industrial mixed-signal, less in AI data-center power; not the primary threat.

What would have to be true for displacement? On the precision signal-chain side, displacement requires 5+ years of foundry process work plus customer qualification cycles — extremely unlikely. On the power side, displacement is happening every socket cycle and is **the** technical risk.

## Bull case — technical
For ADI to outperform consensus from here, four technical conditions need to hold:

1. **AI accelerator test complexity continues to outpace ASP declines.** Each Blackwell/Rubin/MI400 generation requires more ATE seconds per die, plus longer system-level-test (SLT) at thermal load. ADI's $800M ATE content compounds at HBM-stack-count × accelerator-volume × test-time-per-die. This is the highest-conviction part of the thesis and the base-rate-favorable one (ATE content has near-zero displacement risk; HBM4 starts ramping H2 2026).[15][16]
2. **800VDC architecture moves from announcement to production on NVIDIA's Rubin-class systems in 2027.** ADI's first-stage converter content per rack at 1MW density is non-trivial; if their >98% efficiency claim holds in production, they take meaningful share at the entry point.[11][12]
3. **Industrial cyclical recovery has 4–6 quarters of runway.** Channel inventory is at ~6 weeks (lean by historical standards), Q1 industrial was +38% YoY with book-to-bill >1 excluding pricing, and "other industrial" sub-segments are still 20% below prior peak.[1][3] This is a non-AI lever for gross margin (71%+) and revenue compounding.
4. **Vertical power ramps to multiple customers in FY27.** First customer ship was a Q4 FY25 milestone; if a second/third Tier-1 hyperscaler design-in is announced in the next two quarters, the moat in this new socket becomes real rather than hypothetical.

**Base-rate note:** Top-3 analog mixed-signal incumbents have not lost their oligopoly position in any 10-year window since the 1990s. The probability that ADI is structurally displaced from its precision signal chain franchise is empirically very low. The risk is *not* displacement but *under-exposure* — that the highest-growth AI content (GPUs, HBM, DSPs, WBG transistors) goes to other vendors and ADI gets the lower-multiple peripheral content.

## Bear case — technical
The honest short-seller's case:

1. **The "data center" segment is partially recategorized industrial.** ATE has always been a sub-segment of industrial; reclassifying it under "data center" inflates the AI exposure number. If you back out ATE, true AI-direct revenue is ~$1.2B / $13.5B ≈ 9% of the company. The market is paying for an AI multiple on a ~9% AI business.[1]
2. **The valuable optical IP is not ADI's.** Marvell, Broadcom, Semtech, TeraSignal own the 200G/lane DSP and TIA value layer. ADI's "optical" revenue is signal-conditioning and monitoring — commodity-adjacent content with weaker pricing power.[4][5]
3. **The valuable 800VDC IP is the WBG transistor, which Infineon/onsemi/Wolfspeed own.** ADI sells the controllers and hot-swap silicon around the transistor. Higher gross margin on lower dollar content. The transistor vendor captures more of the architectural transition value.
4. **MPS is winning the vertical-power race in the high-volume sockets.** ADI's "first vertical-power customer" disclosure is a hopeful signal, not a share statement. If MPS retains GPU power leadership through Rubin, ADI's power growth is capped at the premium tier.[14]
5. **The consensus price target is below the stock.** The Street's average $393.16 vs. $416 price implies the analyst community has not validated the current multiple expansion. The stock is +53% YTD on multiple expansion, not new fundamental disclosures since Q1 — the move has run ahead of model updates.[7]
6. **Industrial is *cyclical*, not secular.** The +38% YoY industrial number is a recovery off a deep destocking trough, not a permanent step-up. When the cyclical pop normalizes (4–6 quarters), the run-rate growth reverts to mid-single-digits. The market is currently extrapolating cyclical recovery and AI growth simultaneously.

## Market view check
At $416 the stock trades at ~34× FY26 EPS and ~15× NTM revenue against ~12-15% revenue growth and 71% gross margins. Consensus 12-month target is below current price, meaning the rally has outrun published analyst models. The market is paying TI/MPS-like growth multiples for a company that is structurally a hybrid: a high-quality cyclical industrial business (~47% of revenue, recovering) with a real but narrower AI exposure (~20% data center, of which ~40% is the durable ATE layer and ~60% is the contested power+optical layer). The implicit market view is that data-center grows fast enough and long enough to drive blended growth above mid-teens for 3+ years while industrial reflates simultaneously. That is a defensible thesis at $300; at $416 it requires both legs to deliver, with no slippage on either, and assumes the Street upgrades to current price levels rather than the stock reverting to consensus.

## 90-day falsifiers
Specific, observable, within next 90 days (through August 2026):

- **ADI Q2 FY26 earnings (~May 21, 2026):** If actual data-center revenue grows <40% YoY (vs. ~50% recent pace) or if management *fails* to disclose a second/third vertical-power customer, the power-side bull case weakens materially.
- **Q2 FY26 gross margin print:** Guide is for +100bps to ~72.2%. A miss on this — particularly if attributed to pricing rather than utilization — would indicate the cyclical industrial reflation is plateauing.
- **Hyperscaler Q1 capex commentary (May earnings season, Hyperscalers report through early May):** A >10% sequential cut in capex guidance from any of MSFT/AMZN/GOOG/META is a direct hit to ADI's optical+power data-center run-rate.
- **NVIDIA Computex (June 2–6, 2026) / Rubin architecture disclosures:** If NVIDIA discloses Rubin power vendor partners with explicit ranking, ADI's positioning vs. MPS/TI/Infineon becomes legible.
- **MPS Q2 2026 earnings:** If MPS data-center revenue accelerates on Rubin design-in commentary, that is direct evidence ADI is *not* winning the high-volume GPU power socket.
- **Advantest / Teradyne quarterly results and SLT commentary:** Test-time-per-die commentary on HBM4 and AI accelerator SLT validates (or invalidates) the ATE compounding thesis.
- **Bank of America / Morgan Stanley / Goldman analyst day notes coming out of ADI investor events:** If the analyst community starts upgrading PTs above $420, the consensus catches up — if not, the stock is exposed to a mean-reversion to ~$390.

## What I could not verify
- **Exact short interest %.** Surfaced sources did not have a current figure; ADI's historical SI is <2% but unconfirmed for May 2026.
- **Specific ADI BOM dollar content per GB200/GB300 NVL72 rack.** SemiAnalysis BOM breakdowns reference NVIDIA's reference design power vendors generically; per-rack ADI content (vs. MPS or Infineon) is not publicly disclosed.
- **Hyperscaler customer concentration.** Roche did not name customers; the "data center business" exposure to a single hyperscaler (likely Microsoft or Meta based on power-tier design-in patterns) is unknown.
- **ADI's exact role in CPO-enabled switches** (NVIDIA Spectrum-X Photonics, Broadcom Tomahawk 6-Davisson). Surfaced sources suggest ADI plays in the power and monitoring around CPO, not in the photonic engine, but precise content is unverified.
- **The contradiction between 12-month consensus PT ($393) and recent BofA PT ($425).** Whether the consensus average is stale or whether the BofA upgrade is an outlier could not be determined from one search pass; the average lagging the price is itself a fact.
- **Quantified gross margin contribution from the 800VDC product family.** Management did not disclose; my "first-stage > 98% efficiency" claim is an ADI marketing number, not third-party verified.

## Sources
[1] https://www.fool.com/earnings/call-transcripts/2026/02/18/analog-devices-adi-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1 FY26 earnings call transcript; data-center 20% of revenue, $2B run-rate, 40% ATE / 60% balanced power+optical, vertical-power first customer Q4 FY25, gross margin 71.2%.
[2] https://investor.analog.com/news-releases/news-release-details/analog-devices-reports-fiscal-first-quarter-2026-financial — retrieved 2026-05-10 — Q1 FY26 GAAP financials and Q2 guide ($3.5B revenue, $2.88 EPS).
[3] https://seekingalpha.com/news/4553423-analog-devices-signals-20-percent-sequential-industrial-growth-for-q2-2026-amid-ai-driven — retrieved 2026-05-10 — Industrial Q2 sequential guide +20%, book-to-bill above 1 excluding pricing.
[4] https://www.marvell.com/solutions/data-center/optical-dsp.html — retrieved 2026-05-10 — Marvell Ara 3nm 1.6T PAM4 optical DSP positioning; confirms Marvell ownership of high-value optical DSP layer ADI does not contest.
[5] https://terasignal.com/terasignal-unveils-worlds-first-4x200g-intelligent-tia-with-tslink-digital-eye-monitor-and-adaptive-equalizer-for-1-6t-optical-interconnects/ — retrieved 2026-05-10 — 200G/lane TIA leadership held by TeraSignal/Semtech/Marvell/Broadcom, not ADI.
[6] https://finance.yahoo.com/quote/ADI/ — retrieved 2026-05-10 — price $416.07 (2026-05-08 close), 52-week range $206–$418.75, ~$204B market cap, YTD +53.3%, forward P/E ~34.4×.
[7] https://www.marketbeat.com/stocks/NASDAQ/ADI/forecast/ — retrieved 2026-05-10 — 12-month consensus PT $393.16 (32 analysts), range $295–$475; BofA at $425 (Apr 2026).
[8] https://www.analog.com/en/products/ad9088.html — retrieved 2026-05-10 — AD9088 Apollo MxFE 28GSPS DAC / 20GSPS ADC specs.
[9] https://www.rfglobalnet.com/doc/analog-bit-gsps-radio-adc-sets-performance-benchmarks-instrumentation-and-defense-0001 — retrieved 2026-05-10 — AD9213 12-bit 10.25-GSPS RF ADC for radar / instrumentation.
[10] https://investor.analog.com/news-releases/news-release-details/analog-devices-announces-combination-maxim-integrated — retrieved 2026-05-10 — Maxim acquisition ($21B, closed Aug 2021) plus prior LTC ($14.8B, 2017) and Hittite ($2B, 2014).
[11] https://www.analog.com/en/newsroom/press-releases/2025/8-21-2025-powering-the-future-of-ai.html — retrieved 2026-05-10 — ADI 800VDC announcement: hot swap + first-stage conversion >98% efficiency, NVIDIA ecosystem partner.
[12] https://developer.nvidia.com/blog/nvidia-800-v-hvdc-architecture-will-power-the-next-generation-of-ai-factories/ — retrieved 2026-05-10 — NVIDIA 800VDC architecture; ADI listed alongside Infineon, MPS, Navitas, onsemi, Renesas, ROHM, ST, TI as silicon partners.
[13] https://www.ti.com/about-ti/newsroom/news-releases/2026/2026-03-16-ti-unveils-complete-800-vdc-power-architecture-for-future-generation-ai-data-centers-with-nvidia.html — retrieved 2026-05-10 — TI's competing 800VDC architecture with NVIDIA, March 2026.
[14] https://markets.financialcontent.com/stocks/article/finterra-2026-4-9-the-power-behind-the-brain-a-deep-dive-into-monolithic-power-systems-mpwr-in-the-ai-era — retrieved 2026-05-10 — MPS competitive positioning vs. ADI on GPU power sockets; MPS cost/integration advantage, ADI premium positioning.
[15] https://tspasemiconductor.substack.com/p/advantest-leading-the-ai-testing — retrieved 2026-05-10 — Advantest V93000 EXA Scale and SLT positioning; AI accelerator + HBM test-time scaling.
[16] https://axiomaticresearch.substack.com/p/deep-dive-advantestteradyne — retrieved 2026-05-10 — Teradyne/Advantest market structure (>70% combined share), HBM4 test ramp, SLT integration.
[17] https://www.analog.com/en/who-we-are/resilient-hybrid-manufacturing.html — retrieved 2026-05-10 — ADI hybrid fab strategy: internal Beaverton/Limerick/Camas expansions + TSMC/JASM partnership.
[18] https://investor.analog.com/news-releases/news-release-details/analog-devices-strengthens-capacity-and-resiliency-through — retrieved 2026-05-10 — TSMC/JASM Kumamoto capacity arrangement for fine-pitch nodes (wBMS, GMSL).
[19] https://www.analog.com/en/products/MAX20754.html — retrieved 2026-05-10 — MAX20754 multiphase controller for AI/data-center power regulation.
[20] https://www.marvell.com/company/newsroom/marvell-introduces-1-6-tbps-lpo-chipset.html — retrieved 2026-05-10 — Marvell 1.6T LPO chipset (200G TIA + driver) — confirms Marvell ownership of optical signal-chain layer adjacent to where ADI plays.
```