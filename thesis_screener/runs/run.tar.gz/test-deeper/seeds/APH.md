# APH — Amphenol Corporation

## Where this sits in the AI stack
Amphenol is a physical-layer interconnect supplier: connectors, cable assemblies, fiber, sensors, power distribution and liquid-cooling quick-disconnects. Inside an AI rack it does not sell silicon, switch ASICs, transceivers, or software — it sells the copper, fiber and PCB-to-PCB mating systems that route 200 Gb/s-PAM4 SerDes lanes between GPUs, switches and NICs, plus the power whips and liquid-cooling QDs at >100 kW/rack [1][2][3]. The two product franchises that matter for AI are (a) the **NVLink spine "cartridge"** containing ~5,184 twinaxial copper cables that physically wire the 72-GPU all-to-all fabric inside an NVL72 rack, and (b) the **Paladin HD2 / OverPass / DensiLink** 224G connector-and-cable systems used board-to-board and tray-to-tray [1][3][4]. APH is therefore a beneficiary of the scale-up copper plane and (via the 2025 CommScope acquisitions) of the optical/fiber backbone outside the rack, but it is not a beneficiary of the compute itself.

## Snapshot
- **Price:** $128.03 (2026-05-08 close — most recent trading day prior to 2026-05-10) [5]
- **Market cap:** ~$157.5B [5][6]
- **52-week range:** $80.11 – $167.04 [5][6]
- **Forward P/E:** ~23–26× (Finviz 23.0×, StockAnalysis 25.8× on FY26 consensus EPS ~$4.95–5.55) [5][6]
- **EV / NTM revenue:** ~5.7× (EV ≈ $176B incl. ~$18.7B gross debt post-CommScope; NTM rev ~$31B implied off Q2 guide annualized + growth) [5][7]
- **Consensus 12-mo PT:** $168–185 (median ~$169, range $135–210; Citi $180, Baird $177 post Q1) [8][6]
- **YTD total return:** approximately flat-to-+5% — inferred from ~$120s start-of-year context and recent 6.3% post-earnings/sell-off drawdown on 2026-05-08; not directly verified [5]
- **Short interest (% of float):** 1.13% [6]
- **Institutional ownership:** 96.45% [6]; beta 1.29 [6]

## Moat — what it is physically made of
The "moat" is **not** brand and **not** scale per se. Decomposed:

**1. Co-design lock-in on NVIDIA's scale-up plane.** The NVL72 NVLink spine is 5,184 coaxial copper cables, ~2 miles aggregate, terminated into ~four "cartridges" that Amphenol assembles as preintegrated, pre-tested modules [1][3][4][9]. The cartridge is not a connector you buy — it is an SI/PI-validated subassembly that NVIDIA co-designed against Amphenol's twinax and Paladin HD2 mating system. Walking from a sole-cable BOM to a cartridge BOM is a multi-year qualification effort: 224 Gb/s PAM4 over passive copper at this density requires <~1 dB/in insertion loss, controlled impedance to ±5%, and skew matching that is essentially impossible without proprietary fixtures. Marvell's 224G LR DSP demos at DesignCon used Amphenol, Molex and TE — three vendors qualified, not one — but the Paladin HD2 is the densest at 144 differential pairs/U orthogonally [10][11]. CEO Norwitt on the Q1 call: "we are not a sole source in any respect" — that is technically true and a real risk, but in practice the GB200/GB300 design-in is Amphenol-dominant per teardown reporting [3][12].

**2. The cable that survives the cableless transition.** Vera Rubin NVL144 CPX adopts a *cableless* compute tray — signals route off the Bianca HPM board through midplane PCB, not flyovers. This was the loudest bear thesis of 2025 ("APH dead beyond NVL72"). The relevant fact: the off-board interface is the **Amphenol Paladin board-to-board connector**, and the Ethernet path from CX-7/8 NIC to OSFP cage inside the compute tray remains the **Amphenol DensiLink OverPass**, sole-sourced per teardowns [2][13]. So a midplane that eliminates cables still passes through APH connectors — the moat morphed but did not disappear.

**3. Liquid cooling QDs and rack power.** As racks move from ~60 kW (Hopper) to 130 kW+ (Blackwell) to 600 kW (Rubin Ultra Kyber, 2H27) [14], the connector content per rack rises non-linearly. Amphenol's UQD/UQDB/SHQD blind-mate liquid-cooling quick disconnects and high-amperage power-shelf connectors are an underappreciated content layer — these are not commoditized; leak-free at 60+ PSI under thermal cycling is a long qualification cycle [15].

**4. Optics breadth, post-CommScope.** The $10.5B CommScope connectivity/cable unit deal (announced Aug-2025) plus the earlier $2.1B Outdoor Wireless / DAS deal gave APH a credible optical and structured-cabling franchise [16][17][7]. This matters because the *between-rack* network is moving to optics (see "Competitive teardown"). Without CommScope's fiber, APH was a pure copper play; with it, it owns content on both sides of the copper-to-optical inflection.

**Durability assessment (per component):**
- NVLink spine cartridge: high through Rubin/Rubin Ultra inside-rack (2027); displaced by optical NVLink in Feynman platform mid-to-late 2028, and even then NVIDIA has stated "we're going to do both" copper and optical scale-up [18][19].
- Paladin HD2 B2B: high — survives the cableless midplane transition by definition.
- DensiLink OverPass: high near-term, vulnerable medium-term as the NIC↔transceiver function moves toward CPO (Spectrum-X Photonics 2H26, Quantum-X CPO already shipping) [20][21].
- Liquid cooling QDs: high and rising — Rubin Ultra at 600 kW/rack mandates direct-to-chip cold plates.
- Mobile/Andrew/CommScope optical: cyclical, lower technical moat, but a real cash franchise.

Person-years to replicate at parity: I'd estimate 3–5 years for Luxshare to reach 224G-class qualified production at hyperscaler volume; the constraint is not engineering but *yield at scale* and customer-side qualification cycles. Luxshare already has 224G KOOLIO and Intrepid backplane assemblies shipping into Chinese-market AI clusters, so the technology gap is narrower than the Western-market customer-qualification gap [22].

## AI buildout bottleneck map
- **Grid interconnect / generation:** 5–7 year CCGT turbine backlogs; ~80 GW orders vs. ~30 GW/yr OEM capacity at GE Vernova/Mitsubishi/Siemens Energy; only ~5 GW of the announced 12 GW US AI capacity for 2026 is physically under construction [23][24]. **APH position:** indifferent on aggregate GW, but per-GW content rises with rack density — net beneficiary of capacity bottlenecks because customers densify what they can deploy.
- **Advanced packaging (CoWoS-L):** TSMC capacity gates NVIDIA/AMD GPU output [25 — inferred from broad reporting]. **APH position:** indifferent direction; gates the customer's silicon, not APH content.
- **HBM3e/HBM4 yield:** Micron/SK Hynix/Samsung supply-limited. **APH position:** indifferent.
- **Optical interconnect supply (transceivers, lasers, fibers):** Coherent, Lumentum, Eoptolink, Innolight constrained; CPO ramping into Spectrum-X Photonics 2H26 [20][21]. **APH position:** structurally short — every dollar that moves from pluggable+DAC to CPO removes a connector socket. CommScope acquisition partially hedges this on the structured-cabling side.
- **Liquid cooling at >100 kW/rack:** CDUs, cold plates, manifolds, QDs all on allocation. **APH position:** direct beneficiary (UQD family).
- **Electrical contractor / busbar capacity:** Rising rack power requires modular busbar and high-current connectors. **APH position:** beneficiary via Industrial Operations group.
- **Kernel/compiler talent, training data:** **APH position:** indifferent.

Net: APH is a beneficiary of three of the seven hard constraints, exposed to one (optics displacement of in-rack copper), and indifferent to three. That is asymmetrically favorable for the next 8–10 quarters; less clear from 2028.

## Competitive teardown
**TE Connectivity (TEL).** Direct overlap on 224G backplane and B2B. TE has been narrowing the gap with platform-level solutions and is shipping into the same Marvell 200G/lane reference designs [11][26]. On a technical-axis basis: parity at 224G connector performance, narrow APH lead in density (Paladin HD2 144 diff-pairs/U vs TE Sliver/STRADA Whisper ~120). The 2026 share question is split allocations, not displacement — and the *combined* APH+TEL revenue (~$19B in high-speed connectivity) suggests the duopoly is intact rather than fragmenting [26][27].

**Molex (Koch, private).** Active in 224G, less aggressive on dense B2B for hyperscaler AI; stronger in legacy datacom optical pluggables. Not a near-term threat to NVLink spine but a credible 2027+ entrant if NVIDIA dual-sources.

**Luxshare-ICT (China).** The serious medium-term threat. Already ships 224G KOOLIO CPC/NPC and Intrepid NEXUS backplane into Chinese AI clusters and "select overseas" deployments [22][28]. Strategically subsidized by China-domestic AI buildouts. The reason this is not yet a P&L event for APH: hyperscaler procurement is still gating on U.S. supply-chain hygiene for sensitive AI infrastructure. If that gates loosens (or for non-NVIDIA, non-U.S. customers — Huawei Ascend racks, Alibaba, ByteDance internal silicon), Luxshare wins by default. **Watch this name.**

**Volex (VLX LN).** Sub-scale (~$1B revenue) but growing 224G DAC/AEC presence [29]. Not a 2026–27 threat for primary NVLink content; potential second-source at the margin.

**Bizlink / Foxconn FII / Wistron NeWeb.** Lower technical content; cable assembly rather than connector design. Capacity arbitrage rather than IP threat.

**The competitor that matters most is the architecture, not a company.** Co-packaged optics displaces the connector socket entirely. NVIDIA roadmap: Quantum-X InfiniBand CPO shipping now; Spectrum-X Ethernet Photonics 2H26; **optical NVLink scale-up in Feynman, mid-to-late 2028** [18][20][21]. Note: NVIDIA has been explicit that copper and optical scale-up coexist beyond 2028, and the *intra-rack* scale-up of even NVL576 Rubin Ultra Kyber remains copper — CPO is for the *between-rack* tier [19][14]. So copper has runway through at least 2027 for in-rack and the displacement is gradual not cliff-shaped.

## Bull case — technical
Conditions that have to hold:
1. **NVLink scale-up stays copper inside the rack through Rubin Ultra (NVL576, 2H27).** Confirmed by NVIDIA's own GTC 2026 materials — CPO is for inter-rack, not intra-rack scale-up [19][14]. **Base case.**
2. **Rack power density continues to rise** (Blackwell 132 kW → Rubin ~250 kW → Rubin Ultra Kyber 600 kW) [14], driving per-rack APH dollar content for liquid-cooling QDs and power up faster than rack unit shipments. **Base case.**
3. **Q2 guide of $8.1–8.2B and the implied IT Datacom step-up** is achieved, validating that the AI orders book ($9.4B Q1 orders, +78% YoY) is not a one-quarter pull-forward [3][30].
4. **CommScope integration delivers $4.1B in 2026 revenue with $0.15 accretion** at announced margins; allows APH to participate in optical without ceding share when copper is displaced [30].

**Base rates on platform displacement at this stage of a buildout:** Connector duopolies in long-cycle platform transitions (mainframe-to-client-server, copper-to-optical inside the rack at 25G→56G→112G→224G) typically retain incumbency for 2–3 generations after a credible alternative appears. The base rate says copper does not collapse — it bleeds 5–15% of intra-rack share per generation while total volume keeps the absolute dollars rising for the next 3–4 years. That's the APH bull pattern.

Financial outcome under base case: 2026 revenue ~$32–34B (vs implied ~$31B at guide annualization), EPS $5.20–5.60, supporting current ~$128 price at ~22–25× forward, with optionality from Rubin Ultra content disclosures in 2H26.

## Bear case — technical
A short-seller who reads the stack would write:

1. **The customer concentration is real and unstated.** "Just over 40%" of sales in IT Datacom at +99% USD growth implies single-customer (NVIDIA-system) exposure of roughly 20–25% of total — APH does not break this out, but the math is hard to escape. Norwitt's "we are not a sole source" line is technically true but operationally beside the point if one BOM cycle (Rubin → Feynman) removes the cartridge.
2. **The cartridge is the highest-dollar SKU and is exactly what CPO displaces.** Optical NVLink in Feynman (2028) is not optional — NVIDIA has committed to silicon-photonics scale-up. If the timeline pulls in by a year (which has happened — NVIDIA stated CPO arrives "five years ahead of schedule" in some 2026 commentary [31]), APH's highest-margin SKU bleeds at a steeper slope than the bull case allows.
3. **The Q1 2026 order book is an inventory build, not a demand signal.** Book-to-bill of 1.24× is anomalously high for a Tier-1 connector vendor; in 2018 (memory-cycle peak) APH printed similar ratios and gave back >20% over the next two quarters when the build phase ended. The 6.3% drop on 2026-05-08 may be the market starting to discount this [5].
4. **CommScope is buying revenue at a margin discount.** Q1 segment margins compressed 20 bps sequentially on CommScope dilution [30]. Optical/fiber is a structurally lower-margin business than 224G connectors — the mix-shift is real and durable.
5. **Luxshare and the China bifurcation.** If the AI buildout splits into a U.S.-NVIDIA-Amphenol stack and a China-Huawei-Luxshare stack, APH's TAM caps somewhere below the consensus "global AI buildout" framing [22].
6. **Valuation reflects little of this.** Forward P/E ~23–26× on consensus EPS that assumes IT Datacom continues at +80% organic growth past the comp wall — sell-side numbers have not adjusted for the second-derivative slowdown that's mechanically baked in by mid-2026.

Falsifier for the bear: Rubin NVL144 ramps with APH content per rack flat-to-up vs. GB300; Q4 2026 IT Datacom prints +50%+ organic against the +80% comp.

## Market view check
At $128 and ~24× forward EPS, APH trades roughly in line with high-quality industrial-tech compounders (TE at ~20×, MKSI at ~17×, Rockwell at ~25×) but at a premium to its own 10-year median of ~22×. The market is paying for the AI mix (40% IT Datacom, +99% YoY), not just the long-term electrification/automotive/defense story. The recent 6.3% post-earnings drawdown despite a 7%-revenue beat and orders +78% YoY suggests the marginal investor is already worried about (a) second-derivative deceleration as 2025 comps lap and (b) the optical-displacement clock. **My view:** the market is correctly pricing the *direction* but not the *duration*. Copper-spine intra-rack content runs through 2027 and the optical-displacement narrative is being mis-timed by ~12–18 months. That's a mild upside skew, not a screaming buy — the easy money was made between $80 and $130.

## 90-day falsifiers
- **NVIDIA Q2 FY27 (calendar Q2 26) earnings, late Aug.** If NVIDIA tightens the Rubin ramp timeline and confirms NVL144/NVL576 BOMs that retain Amphenol cartridges, bull case strengthens. If they pre-announce optical-NVLink content earlier than Feynman, bear case strengthens.
- **APH Q2 2026 print (late July).** Watch (i) IT Datacom organic growth specifically — anything below +60% organic is a red flag; (ii) book-to-bill — anything above 1.1× is still constructive, below 1.0× is the inventory-build bear thesis confirmed; (iii) segment-level operating margin in Communications Solutions (CommScope dilution).
- **Spectrum-X Photonics SN6810 production shipments (2H26 commercial).** Public deployment confirmations from any of MS/Meta/AWS would mark the start of the optical scale-out displacement of DensiLink-class cables.
- **Any disclosed Luxshare 224G design-in at a U.S./Western hyperscaler.** This would be a step-function change in the competitive narrative.
- **Hyperscaler capex guidance prints.** Specifically Microsoft FY27 capex guide (their FQ4 is calendar Q2 26); any sequential cut of >10% would re-rate the AI-infrastructure cohort including APH.

## What I could not verify
- Exact APH dollar content per NVL72 rack (estimates from third-party teardowns range $30k–$60k including cartridges, Paladin, DensiLink, power, QDs — none of these are official).
- Exact YTD 2026 total return for APH at 2026-05-10 — derived from price-history fragments rather than a single authoritative quote.
- The split between APH vs. TE vs. others on the NVLink cartridge — claims of "primary supplier" are well-sourced but actual share percentage is not disclosed.
- Whether NVIDIA's Feynman timeline (2028 optical NVLink) accelerates; this is the single most important variable and is unknown.
- The unit economics of CommScope assets at the line-of-business level inside APH — disclosure has been segment-level only.
- The actual customer mix within IT Datacom at 41% of sales — APH refuses to name customers; the NVIDIA-system exposure is inferred, not disclosed.
- Whether the 2026-05-08 6.3% decline was idiosyncratic to APH or a broader AI-infra-cohort sell-off — the close was reported but the day's sector context was not retrievable in time.

## Sources
[1] https://www.diskmfr.com/nvidia-gpu-copper-cable-interconnect-technology-explained/ — retrieved 2026-05-10 — NVL72 uses 5,184 copper cables for 72-GPU all-to-all at 900 GB/s; Paladin HD 224G named as connector
[2] https://www.designworldonline.com/amphenol-demonstrates-co-packaged-copper-interconnect-at-designcon-2026/ — retrieved 2026-05-10 — Amphenol DesignCon 2026 co-packaged copper demo, Paladin HD2 and OverPass identified as industry-standard 224G platforms
[3] https://www.fool.com/earnings/call-transcripts/2026/04/30/amphenol-aph-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1 2026 transcript: $7.62B sales, IT Datacom 41% of sales +99% USD/+81% organic, "not a sole source," Q2 guide $8.1–8.2B
[4] https://developer.nvidia.com/blog/nvidia-contributes-nvidia-gb200-nvl72-designs-to-open-compute-project/ — retrieved 2026-05-10 — NVL72 OCP design, four NVLink cartridges with >5,000 copper cables, 36× faster than Ethernet at scale-up
[5] https://stockanalysis.com/stocks/aph/ — retrieved 2026-05-10 — Price $128.03 May-8-26 close, market cap $157.51B, 52-week $80.11–$167.04, forward P/E 25.8×, average PT $168.27
[6] https://finviz.com/quote.ashx?t=APH — retrieved 2026-05-10 — Forward P/E 23.0×, P/S 6.08×, short float 1.13%, institutional ownership 96.45%, beta 1.29, average analyst PT $184.87
[7] https://www.cnbc.com/2025/08/04/amphenol-to-buy-commscopes-broadband-connectivity-cable-unit.html — retrieved 2026-05-10 — $10.5B CommScope connectivity/cable unit acquisition announced Aug 2025
[8] https://public.com/stocks/aph/forecast-price-target — retrieved 2026-05-10 — Consensus PT and analyst ratings as of May 2026; Citi $180, Baird $177 raises post Q1
[9] https://semianalysis.com/2024/07/17/gb200-hardware-architecture-and-component/ — retrieved 2026-05-10 — GB200 BOM and component supply chain, NVLink spine cartridge architecture
[10] https://www.amphenol-cs.com/product-series/paladin-hd.html — retrieved 2026-05-10 — Paladin HD spec: 112–224 Gb/s, 144 differential pairs per 1U orthogonal
[11] https://www.marvell.com/company/newsroom/marvell-extends-connectivity-leadership-with-200G-lane-partner-demonstrations-at-designcon.html — retrieved 2026-05-10 — Marvell 224G LR DSP demo partners: Amphenol, Keysight, Molex, TE
[12] https://globaltechresearch.substack.com/p/nvidia-nvda-us-2025-gtc-review-is — retrieved 2026-05-10 — "APH dead beyond NVL72" bear thesis review; DensiLink OverPass exclusively Amphenol, Paladin B2B survives cableless midplane
[13] https://newsletter.semianalysis.com/p/another-giant-leap-the-rubin-cpx-specialized-accelerator-rack — retrieved 2026-05-10 — Rubin NVL144 CPX cableless design via Paladin B2B from Amphenol; HPM Bianca board interface
[14] https://www.datacenterdynamics.com/en/news/nvidias-rubin-ultra-nvl576-rack-expected-to-be-600kw-coming-second-half-of-2027/ — retrieved 2026-05-10 — Rubin Ultra Kyber rack 600 kW, 2H27 availability
[15] https://amphenol-industrial.com/products/liquid-cooling-systems/ — retrieved 2026-05-10 — Amphenol UQD/UQDB/SHQD liquid-cooling quick-disconnect portfolio
[16] https://investors.amphenol.com/news-and-events/news-details/2024/Amphenol-Corporation-to-Acquire-Mobile-Networks-Businesses-From-CommScope/default.aspx — retrieved 2026-05-10 — $2.1B OWN/DAS (Andrew) acquisition announcement, ~$1.3B 2025 revenue
[17] https://www.rcrwireless.com/20250804/ai-infrastructure/amphenol-commscope — retrieved 2026-05-10 — Second CommScope deal at $10.5B for broadband/connectivity/cable unit
[18] https://www.theregister.com/on-prem/2026/04/05/nvidia-embraces-optical-scale-up-as-copper-reaches-limits/5225238 — retrieved 2026-05-10 — Copper distance limit 1.8 TB/s few-feet runs; Rosa Feynman NVL1152 mid-late 2028 with copper-or-CPO; "we're going to do both"
[19] https://developer.nvidia.com/blog/nvidia-vera-rubin-pod-seven-chips-five-rack-scale-systems-one-ai-supercomputer/ — retrieved 2026-05-10 — Vera Rubin POD architecture; intra-rack scale-up stays copper through Rubin Ultra; CPO for inter-rack scale-up only
[20] https://www.tomshardware.com/networking/nvidia-outlines-plans-for-using-light-for-communication-between-ai-gpus-by-2026 — retrieved 2026-05-10 — Spectrum-X Photonics 2H26 commercial; SN6810 102.4 Tb/s, 128×800G ports
[21] https://newsletter.semianalysis.com/p/co-packaged-optics-cpo-book-scaling — retrieved 2026-05-10 — CPO scaling, hyperscaler power-per-bit drivers, pluggable transceiver displacement timeline
[22] https://www.prnewswire.com/news-releases/from-interconnect-to-power-and-thermal-management-luxshare-ict-expands-its-role-in-ai-data-center-infrastructure-302752966.html — retrieved 2026-05-10 — Luxshare 224G KOOLIO and Intrepid backplane shipping into Chinese and select overseas AI clusters
[23] https://www.tomshardware.com/tech-industry/turbine-shortage-threatens-ai-datacenters-as-wait-times-stretch-into-2030 — retrieved 2026-05-10 — CCGT 5–7 year backlogs; ~80 GW orders vs ~30 GW/yr capacity; GE Vernova/Mitsubishi 2028+ slots
[24] https://www.techinvestments.io/p/power-bottlenecks-and-the-ai-data — retrieved 2026-05-10 — Sightline 12 GW announced 2026 AI capacity, only 5 GW physically under construction
[25] https://newsletter.semianalysis.com/p/nvidia-the-inference-kingdom-expands — retrieved 2026-05-10 — GTC 2026 review, Rubin platform details and CoWoS gating context
[26] https://finance.yahoo.com/news/amphenol-vs-te-connectivity-connector-165900290.html — retrieved 2026-05-10 — APH overtook TE as #1 connector vendor globally on AI-driven datacom
[27] https://www.openpr.com/news/4411305/key-players-in-the-high-speed-connector-market-te-connectivity — retrieved 2026-05-10 — High-speed connector market structure: APH, TE, Molex, FIT as top 4
[28] https://en.wikipedia.org/wiki/Luxshare — retrieved 2026-05-10 — Luxshare background, Shenzhen-listed, Wang Laichun founder ex-Foxconn
[29] https://www.volex.com/products-and-services/high-speed-copper-interconnect-data-transfer-cables — retrieved 2026-05-10 — Volex DAC/ACC/AEC product line for hyperscale AI data centres
[30] https://www.levelfields.ai/news/amphenol-delivers-record-q1-results-as-orders-and-margins-surge — retrieved 2026-05-10 — Q1 2026 orders $9.435B +78% YoY, adj. operating margin 27.3%, CommScope 2026 $4.1B sales / $0.15 EPS accretion
[31] https://wccftech.com/nvidia-fast-forwarded-co-packaged-optics-five-years-ahead-arriving-with-feynman-gpus/ — retrieved 2026-05-10 — NVIDIA acceleration of CPO timeline into Feynman GPU generation