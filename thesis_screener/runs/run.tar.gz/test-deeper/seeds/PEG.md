I have enough to write a grounded dossier. Writing now.

# PEG — Public Service Enterprise Group

## Where this sits in the AI stack
PEG sits at the **power layer** of the AI stack — upstream of silicon, packaging, and cooling — and combines two distinct businesses: (1) **PSE&G**, a fully regulated New Jersey electric/gas transmission and distribution monopoly (>80% of operating earnings), and (2) **PSEG Power**, a merchant generator whose value is dominated by ~3.5 GW of nameplate nuclear capacity at the **Salem (Units 1/2)** and **Hope Creek** stations in southern NJ, both running ~96% capacity factor and selling into PJM [1][3][8]. The nuclear fleet is "the asset" for any AI-power thesis — it is the only large, 24/7, zero-carbon, already-permitted, behind-the-fence-eligible baseload sitting inside the PJM footprint that PSEG controls outright. PSE&G also owns the transmission infrastructure into which any new data-center load in NJ must interconnect [11].

## Snapshot
- **Price:** $77.13 (2026-05-08 close) [1]
- **Market cap:** ~$40.7B [4]
- **52-week range:** $76.00 – $91.26 [1][6]
- **Forward P/E:** ~17.8× on FY2026 EPS guidance midpoint of $4.34 ($4.28–$4.40 range; consensus ~$4.40) [1][7]. A 20.6× forward P/E figure appears on one screener but is inconsistent with stated guidance and looks stale [4].
- **EV / NTM revenue:** ~5.3× (inferred: ~$40.7B mkt cap + ~$22B net debt vs. ~$12B FY26E revenue; not a standard utility metric — flagging as estimate) [4][7]
- **Consensus 12-month price target:** $90.58 average / $90.00 median (+17% from $77.13) [4]
- **YTD total return:** ~-12% (inferred from price vs. 52-week range; not directly sourced — flagging) — stock is ~15% off its 52-week high near $91 [1][6]
- **Short interest (% of float):** n/a — I could not verify a current figure within sources searched
- **Dividend:** $2.68 annual / ~3.3% yield, 15th consecutive annual raise, ~6% guided growth through 2030 [12]

## Moat — what it is physically made of
This is a **physical-asset moat**, not a software moat, and you have to decompose it honestly:

1. **Salem + Hope Creek nuclear fleet (~3.5 GW nameplate, ~2.6 GW PSEG ownership share).** PSEG owns 57.4% of Salem 1 & 2 (Constellation owns the balance) and 100% of Hope Creek [3][8]. This is the technical core of the thesis. The replacement cost of an equivalent 2.6 GW of new clean baseload inside PJM in 2026 is, in practical terms, infinite within a 10-year horizon: large-light-water reactor construction in the US (Vogtle 3/4) ran ~$15B/GW and took 14+ years; the most-permissive SMR roadmaps (NuScale, BWRX-300) put first commercial units in the late 2020s at best, at sub-300 MW each. **License renewals filed with the NRC would extend operations to 2056/2060 (Salem) and 2066 (Hope Creek)** [2]. The fleet's ~96% capacity factor [3][8] is the operational ceiling of the technology — it is not improvable by a competitor.

2. **PSE&G T&D monopoly in northern/central NJ.** This is a true regulatory moat with a known mechanism: rate base grows ~6–7.5% CAGR through 2030 on $22.5–25.5B regulated capex [9][7]. Any data center built in PSE&G's service territory pays grid charges that flow into PSE&G's rate base whether or not PSEG Power supplies the electrons. This is the "you can't avoid us" leg — anything that interconnects in the territory ultimately pays into the regulated wires business.

3. **Site rights and contiguous land at Salem/Hope Creek.** The Artificial Island complex has a completed port, skilled-workforce ecosystem, switchyard infrastructure, and — critically — physical land for behind-the-fence data-center construction or for new nuclear (SMR or large LWR) [2][11]. Constellation similarly has site assets at Three Mile Island; Vistra at Comanche Peak; Talen at Susquehanna. The site itself is part of the moat because **NRC-licensed nuclear sites are essentially un-replicable on greenfield timelines** even after NJ lifted its de facto moratorium in April 2026 [10].

4. **PJM transmission position post-Sandy/post-2003-blackout.** LaRossa has explicitly cited that NJ's transmission was rebuilt after Sandy and the 2003 blackout, giving PSE&G headroom for load growth that more constrained pockets of PJM (e.g., northern Virginia) do not have [11]. This is plausible but I have not independently verified the headroom number.

**Durability assessment.** The nuclear fleet itself is essentially undisplaceable through 2040+ given license extensions and the lead-time math on alternatives. The T&D monopoly is durable but its returns are bounded by state regulators (NJ BPU). The **monetization** of the nuclear fleet at AI-hyperscaler-premium pricing is the *only* part of the moat that is not durable — it depends on FERC and NJ BPU outcomes that are still in flight (see Bear case).

## AI buildout bottleneck map
Where PEG sits versus each gating constraint over the next 24 months:

- **Power generation (baseload, clean):** **Beneficiary, but indirectly.** PSEG owns 2.6 GW of the scarcest clean-baseload supply in PJM. Capacity is structurally short: PJM's 2027/28 BRA cleared at the **$333.44/MW-day price cap** vs. $28.92/MW-day for 2024/25 — a ~10× repricing, with data centers responsible for ~$6.5B of the $16.4B in capacity costs [5]. PSEG has ~95% of 2026 nuclear output hedged at prices above the $15/MWh IRA PTC floor — meaning energy revenue is now well above the PTC backstop and capacity revenue is captured at the new high prices [13].
- **Power transmission / PJM interconnection queue:** **Supplier and beneficiary.** PSE&G's pipeline of large-load (mostly data-center) interconnection requests has grown to **~9.4 GW**, of which management expects 10–20% to materialize over time [11]. Competitive FERC transmission projects (e.g., $424M MD/VA project, ISD 2027) add a separate FERC-regulated earnings stream [9].
- **Gas turbine supply:** **Indirect beneficiary.** GE Vernova's 80 GW backlog stretches into 2029 and is expected to be sold out through 2030 by end-2026; Siemens Energy's heavy-duty production ramps from ~48 to 70–80 units annually only by 2026; S&P reports US lead times of up to 7 years [14]. Translation: even if every hyperscaler wanted to build behind-the-meter gas, the equipment is not deliverable until ~2030. **This is the strongest structural argument for nuclear-incumbent value:** the substitute is not available at scale on the relevant timeline.
- **Advanced packaging (CoWoS-L) / HBM3e:** **Indifferent / irrelevant.** PEG does not touch silicon. CoWoS and HBM constraints [15] gate how many GPUs hyperscalers can deploy, which sets the *ceiling* on power demand growth — so PEG is downstream of those constraints in the same way every utility is.
- **Liquid cooling >100 kW/rack, electrical contractor capacity:** Indifferent.
- **Kernel/compiler talent:** Indifferent.

## Competitive teardown
Three classes of competitor for the nuclear-to-AI-power monetization opportunity:

1. **Constellation Energy (CEG)** — the pure-play. ~22 GW nuclear, post-Calpine ~60 GW total [16]. CEG is structurally a more direct AI-power play: zero regulated utility, all merchant. The market reflects this: CEG trades at ~$108B mkt cap on a P/E in the 40× range [17], vs PEG at ~17.8× forward. CEG also owns the *other 42.6% of Salem* alongside PSEG [3] — meaning any Salem co-location structure requires a CEG agreement. CEG is ahead of PEG on landed hyperscaler deals (Microsoft-TMI restart, etc.).
2. **Vistra (VST), Talen (TLN)** — also merchant nuclear/gas IPPs. Vistra's Meta deal (6.6 GW announced multi-tech package with Vistra/Oklo/TerraPower) is the closest comparable [16]. Talen's restructured AWS-Susquehanna PPA (1.92 GW, 17-year, **front-of-the-meter** to sidestep the FERC ruling) is the working blueprint for nuclear-to-hyperscaler contracting after the November 2024 FERC rejection of the BTM expansion [18][19].
3. **Regulated peers (Dominion, Duke, NextEra, Southern, AEP)** — compete for the *transmission/distribution* portion of the AI load opportunity. PSEG's edge here is the NJ territory and the nuclear-adjacent siting; the disadvantage is single-state regulatory exposure to NJ BPU and the new Sherrill administration's "affordability" framing [20].

**On which technical axis PEG is differentiated:** the *combination* of (a) merchant nuclear ownership + (b) regulated wires monopoly in the same state. CEG/Vistra/Talen have (a) but not (b); the regulated utilities have (b) but not (a). This is unique among large US power names. It is **also why PEG cannot move as aggressively on co-location pricing** as Talen — its regulated utility subsidiary needs to keep the same NJ BPU happy that is policing the rate environment.

## Bull case — technical
For the stock to outperform from $77, the following technical conditions need to hold:

1. **PJM capacity prices remain elevated.** The $329–$333/MW-day clearing prices for delivery years 2026/27 and 2027/28 [5] are not yet fully in PSEG Power's run-rate earnings because of the hedging cadence; uncapped, the 2027/28 auction would have cleared near $530 [5]. As pre-existing low-priced hedges roll off, nuclear gross margin steps up mechanically. **Base rate:** capacity-market scarcity from a generation-undersupplied RTO has historically taken 5–10 years to mean-revert (PJM 2007–2012 scarcity), because new entry is gated by interconnection queues and turbine lead times — both of which are currently broken (turbine lead times to 2029–2030 [14], interconnection cycles 1–2 years post-reform [21]).
2. **At least one PSEG nuclear-to-hyperscaler contract is announced** — even at FTM pricing (the Talen-AWS structure), the premium over wholesale capture would be material on 30+ TWh of generation [13]. Jefferies sees this as "upside but lower likelihood" [20].
3. **NJ moratorium repeal (signed April 2026) translates into a credible large-LWR or SMR new-build option at the Salem complex** [10][2] — providing growth runway beyond 2030. The 200 MW Salem uprate [2] is the lower-risk version of this.
4. **PJM-FERC colocation framework (Dec 2025 order, PJM Feb 16, 2026 compliance filing)** [22][23] produces workable Firm Contract Demand Transmission Service terms that allow nuclear-adjacent data centers without ratepayer cost-shift backlash.

If all four hold, PSEG looks like a regulated utility (6–8% earnings CAGR floor [7]) with embedded nuclear optionality being mispriced at 17.8× — CEG-style optionality at PSE&G-style multiple.

## Bear case — technical
The short case that someone who reads FERC dockets would write:

1. **FERC has already said no once.** The November 2024 rejection of the Talen-Amazon expanded ISA was a 2–1 ruling that the parties hadn't justified why ratepayer-funded grid capacity should backstop a private BTM deal [18]. The December 2025 colocation order [22][23] creates a *process* but explicitly preserves the cost-causation principle. Translation: hyperscalers may not be able to capture the full BTM "no transmission charge" discount, which compresses the price PSEG can extract.
2. **NJ BPU is the bottleneck, not the asset.** Jefferies' downgrade rationale was explicit: "given the affordability crisis... less likely PSEG will pursue data center deals at its nuclear power plants" [20]. The Sherrill administration is reportedly looking to *lower* PSEG rates [20]. A regulated utility cannot simultaneously argue for higher returns on T&D and BTM premium pricing on nuclear in front of the same regulator.
3. **Most of PSEG's earnings are not the nuclear story.** With ~80%+ of operating earnings from regulated PSE&G, even a great hyperscaler nuclear deal moves consolidated EPS by a modest amount versus the 6–8% baseline. The illustrative gross-margin sensitivity at 30 TWh × $50/MWh above PTC is $1.5B [13] — meaningful but not transformative against ~$2.2B FY26E net income.
4. **The 9.4 GW data-center pipeline is mostly speculative.** Management's own range is 10–20% materialization [11]. That's a 1–2 GW realistic load addition — meaningful but not at the level the bull-case framing implies.
5. **Multi-axis competition for the same hyperscaler dollars.** Constellation, Vistra, Talen, and the SMR developers are all chasing the same Microsoft/Meta/AWS/Google deal flow. PSEG is constrained from matching their aggression by point (2) above.
6. **Base rate on power-sector "AI re-rating" trades:** Constellation already plunged 13% YTD on guidance that "fell short of AI hype" [16]. The market has been pricing peak optimism in the nuclear-IPP names and is now demanding actual signed deals; PEG is exposed to that derating dynamic even though its multiple is much lower.

## Market view check
The stock at $77 trades at ~17.8× the midpoint of FY26 EPS guidance for a name growing earnings 6–8% with a 3.3% yield — i.e., **as a regulated utility with no premium for the nuclear optionality.** Consensus PT $90.58 implies ~17% upside, which is consistent with the technical reality: the market is awarding little credit for hyperscaler monetization until contracts are signed, which is roughly correct given (a) the Jefferies-flagged regulatory friction and (b) the lessons from Talen-AWS-FERC. The asymmetry is that the **floor is hard** (rate-base-driven utility earnings + PTC-backstopped nuclear), while the upside option is unpriced. Compared to CEG at ~40× P/E, PEG is the lower-beta way to play the same physical thesis — at the cost of the explicit nuclear optionality CEG has begun to capture.

## 90-day falsifiers
Things you can actually check by ~August 2026:
- **PJM's Feb 16, 2026 colocation compliance filing** and subsequent FERC action on it — specifically whether the Firm Contract Demand Transmission Service mechanics make BTM economics workable [22][23].
- **Any PSEG Q2 2026 earnings (~late July/early August) commentary on signed/term-sheet hyperscaler deals**, plus updates to the 9.4 GW large-load pipeline and the 10–20% materialization ratio [11].
- **NJ BPU rate-case posture under the Sherrill administration** — any order on PSE&G rates that materially lowers allowed ROE or imposes data-center cost-allocation rules would validate the bear case [20].
- **PJM 2028/29 BRA results** (typically July–August) — a clearing price near or at the $333.44 cap would confirm structural capacity scarcity is durable; a sharp clear below would undercut the run-rate margin step-up.
- **NRC docketing of Salem/Hope Creek license renewal applications** moving forward without surprise issues [2].
- **Any GE Vernova / Siemens Energy capacity update** indicating earlier turbine delivery slots — would compress the structural scarcity argument.

## What I could not verify
- Current short interest as a % of float — sources did not return a recent figure.
- Exact YTD total return — I inferred ~-12% from price action; not directly sourced.
- The 20.6× forward P/E figure on one financial screener cannot be reconciled with stated $4.28–$4.40 guidance, so I report 17.8× off guidance midpoint instead — but I have not located a primary buyside consensus tape.
- Specific TWh-by-counterparty hedge profile for 2027/28 (i.e., what portion of nuclear output is contracted at exactly what realized energy and capacity price by year) — disclosed at the bucket level [13], not transaction level.
- Whether any of the 9.4 GW large-load pipeline is contracted vs. early-stage inquiry — management has only given the 10–20% materialization range [11].
- Specific FERC docket numbers for PSEG-affiliated colocation filings (if any exist beyond the PJM-wide proceeding).
- Whether the lifted NJ moratorium has translated into any concrete SMR vendor MOU at Salem yet, beyond the announced state Nuclear Task Force [10].

## Sources
[1] https://finance.yahoo.com/quote/PEG/ — retrieved 2026-05-10 — current PEG price ($77.13), 52-week range $76.00–$91.26, May 8 close
[2] https://www.ans.org/news/2026-05-08/article-8015/gov-sherrill-pseg-ceo-talk-nj-nuclear-expansion/ — retrieved 2026-05-10 — Salem/Hope Creek license renewal extensions to 2056/2060/2066; ~200 MW uprate potential; NJ Nuclear Task Force
[3] https://en.wikipedia.org/wiki/Salem_Nuclear_Power_Plant — retrieved 2026-05-10 — Salem capacity 2,275 MW, PSEG 57.4% ownership; Hope Creek 1,268 MW 100% PSEG; combined ~3.5 GW
[4] https://stockanalysis.com/stocks/peg/statistics/ — retrieved 2026-05-10 — market cap $40.7B, analyst price target $90.58 average / $90.00 median
[5] https://www.utilitydive.com/news/data-centers-pjm-capacity-auction/808951/ — retrieved 2026-05-10 — data centers = 40% of $16.4B PJM capacity costs; $333.44/MW-day cap; 10× increase from $28.92
[6] https://www.marketbeat.com/stocks/NYSE/PEG/ — retrieved 2026-05-10 — analyst ratings distribution 10 Buy / 10 Hold / 1 Sell
[7] https://www.fool.com/earnings/call-transcripts/2026/05/05/peg-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q1 2026 EPS $1.55, FY26 guidance $4.28–$4.40, 6–8% CAGR through 2030, $22.5–25.5B PSE&G capex, $24–28B PSEG Power capex
[8] https://en.wikipedia.org/wiki/Hope_Creek_Nuclear_Generating_Station — retrieved 2026-05-10 — Hope Creek capacity 1,268 MW; capacity factor history
[9] https://nj.pseg.com/newsroom/newsrelease237 — retrieved 2026-05-10 — FERC transmission formula $82M annual increase; $424M MD/VA project ISD 2027
[10] https://www.governing.com/infrastructure/new-jersey-eases-rules-to-spur-new-nuclear-development — retrieved 2026-05-10 — NJ April 2026 moratorium lift; Sherrill bill; second state to lift in 2026
[11] https://www.utilitydive.com/news/pseg-earnings-new-jersey-power-plants-pjm/813334/ — retrieved 2026-05-10 — 9.4 GW PSE&G large-load pipeline, ~90% data center, 10–20% materialization; LaRossa on transmission headroom post-Sandy/2003
[12] https://www.prnewswire.com/news-releases/pseg-increases-2026-common-stock-dividend-302697834.html — retrieved 2026-05-10 — $2.68 annual dividend, 15th consecutive raise, ~6% growth guidance
[13] https://www.investing.com/news/company-news/pseg-q1-2026-slides-8-earnings-growth-nuclear-upside-potential-93CH-4660378 — retrieved 2026-05-10 — 95% of 2026 nuclear hedged above PTC; 30–32 TWh expected; illustrative $1.5B margin sensitivity
[14] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — GE Vernova 80 GW backlog to 2029, sold out through 2030 by end-2026; Siemens 48→70–80 turbine annual ramp; S&P up to 7-year lead times
[15] https://newsletter.semianalysis.com/p/ai-capacity-constraints-cowos-and — retrieved 2026-05-10 — CoWoS-L and HBM3e supply allocated through 2026
[16] https://markets.financialcontent.com/stocks/article/marketminute-2026-3-10-constellation-energy-finalizes-164-billion-calpine-acquisition-solidifying-lead-in-ai-data-center-power-race — retrieved 2026-05-10 — Constellation-Calpine $16.4B close, 60 GW combined; Meta-Vistra 6.6 GW; CEG -13% YTD
[17] https://companiesmarketcap.com/constellation-energy/marketcap/ — retrieved 2026-05-10 — CEG market cap $108.4B at $303.63
[18] https://www.utilitydive.com/news/ferc-interconnection-isa-talen-amazon-data-center-susquehanna-exelon/731841/ — retrieved 2026-05-10 — FERC 2–1 rejection of Talen-AWS expanded BTM ISA Nov 2024
[19] https://www.theregister.com/2025/06/12/amazon_talen_nuclear_deal/ — retrieved 2026-05-10 — Talen-AWS restructured 1,920 MW front-of-meter PPA
[20] https://www.investing.com/news/analyst-ratings/jefferies-downgrades-public-service-enterprise-stock-rating-on-nuclear-concerns-93CH-4613942 — retrieved 2026-05-10 — Jefferies downgrade to Hold, $89 PT, "affordability crisis" framing
[21] https://insidelines.pjm.com/pjm-completes-interconnection-reform-transition-cycle-1-studies/ — retrieved 2026-05-10 — PJM interconnection reform: 1–2 year study cycles, transition queue ~46 GW
[22] https://www.ferc.gov/news-events/news/fact-sheet-ferc-directs-nations-largest-grid-operator-create-new-rules-embrace — retrieved 2026-05-10 — Dec 18, 2025 FERC order on PJM colocation; three new transmission service categories
[23] https://www.mintz.com/insights-center/viewpoints/2151/2026-02-02-ferc-directs-pjm-issue-new-rules-co-location-power — retrieved 2026-05-10 — Feb 16, 2026 PJM compliance filing deadline; Firm Contract Demand Transmission Service mechanics