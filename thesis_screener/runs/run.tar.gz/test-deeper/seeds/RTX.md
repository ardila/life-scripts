# RTX — RTX Corporation (NYSE: RTX)

## Where this sits in the AI stack

RTX is not an AI infrastructure company in the sense the framework above implies; it sells no silicon, no HBM, no NCCL-equivalent fabric, and no training-platform runtime. It is an aerospace-and-defense prime composed of three operating segments: **Collins Aerospace** (avionics, mission systems, interiors), **Pratt & Whitney** (the F135 engine for F-35, the F119 for F-22, and the PW1100G/PW1500G geared-turbofan family for A320neo/A220/E-Jets E2), and **Raytheon** (radars, missiles, integrated air-and-missile-defense, hypersonics) [2][3]. The thin AI surface area is real but second-order: an AI/ML-powered cognitive Radar Warning Receiver flown on F-16 in late 2024, the Battle-Space Command and Control Center (BC3) software that fuses sensor-to-shooter chains, and AI battle management embedded in the Golden Dome architecture [4][5][16]. RTX appears in an "AI investor" conversation because (a) defense electronics are increasingly software-defined and (b) the Golden Dome program explicitly bakes machine learning into target discrimination — not because RTX is exposed to the training/inference compute cycle. **The technical-investor framework still applies, but the moats here are GaN MMIC manufacturing, jet-engine thermals, and integrated fire control — not CUDA.**

## Snapshot

- **Price:** $176.09 (2026-05-08 close; the named "2026-05-10" date is a Sunday so this is the last printed close) [1]
- **Market cap:** ~$238B [1]
- **52-week range:** $126.03 – $214.50 [6]
- **Forward P/E:** ~26× on FY26 adj. EPS midpoint of $6.80 [1][7]
- **EV / NTM revenue:** ~3.0× (EV ≈ $274B inferred from $238B mkt cap + ~$36B net debt; NTM revenue $92.5–$93.5B guide) [7][14] — *inference flagged; net debt is rough*
- **Consensus 12-month price target:** ~$206 (median of 27 analysts, range $179–$240); implied upside ~+17% [6]
- **YTD total return:** +7.5% [11]
- **Short interest (% of float):** 1.33% (below A&D peer average ~3.0%) [10]
- **Dividend yield:** 1.5% on $2.92 annualized after the Apr-26 7.4% raise [9]
- **Backlog:** $271B (~$162B commercial / $109B defense); book-to-bill 1.56 [7][8]
- **FY26 FCF guide:** $8.25–$8.75B (capex ~$3.1B) [14]

## Moat — what it is physically made of

The RTX moat decomposes into four distinct technical components with very different durabilities.

**1. The Raytheon GaN MMIC foundry in Andover, Massachusetts.** Raytheon owns one of the few merchant-defense gallium-nitride foundries qualified for DoD use, and has shipped GaN T/R modules in volume since the AN/SPY-6 program at scale; LTAMDS (GhostEye), the Patriot-replacement radar, is built around 144-GaN-module Radar Modular Assemblies (61×61×61 cm bricks) [12][13]. GaN-on-SiC gives roughly 5–10× the power density of legacy GaAs at the X- and S-bands the radars need. Replicating an ITAR-cleared, security-cleared foundry with two decades of process learning is a 6–10 year project for a competitor; Northrop has one but smaller, Lockheed buys most of its GaN. This is the most durable piece of the moat and the part the framework's "physical substrate" lens picks up cleanly.

**2. Pratt & Whitney F135 sole-source on F-35.** The F135 is the only engine certified for F-35A/B/C. The Pentagon explicitly chose Pratt's **Engine Core Upgrade** (ECU) over a clean-sheet Adaptive Engine in 2023, and finalized a $6.6B Lot 18/19 production-plus-ECU contract in April 2026 [15]. The F135 ECU is the gating component for F-35 Block 4 (electrical/thermal headroom for new sensors and weapons), with first deliveries scheduled 2029. Sole-source on a ~$13B/year production aircraft with a 30-year sustainment tail is the highest-quality cash-flow stream in the portfolio. Replacement cost: the GE XA100 program existed, was funded, and was killed — that is the actual base rate.

**3. The PW1100G "GTF" installed base.** ~1,800 aircraft delivered, plus the powder-metal-AOG headache [17]. The aftermarket on this is structurally locked-in for 20–25 years because re-engining an A320neo is uneconomic. The installed-base annuity is the asset; the powder-metal shop-visit acceleration (600–700 incremental visits 2023–2026) is the temporary cost. AOG count was down 15% Q1 2026 with castings supply +10% YoY and forgings +18% YoY [17].

**4. System-integration know-how on integrated air-and-missile-defense (IAMD).** RTX produces both the Patriot radar/ground-system AND the SM-3/SM-6/Tomahawk/AMRAAM interceptor family — but does NOT make the PAC-3 MSE interceptor (Lockheed does) [18][19]. The "moat" here is the multi-decade software baseline of Patriot fire control, foreign-military-sales relationships in 19 countries, and the BC3 battle-management glue. This is a "scale + relationships + accumulated software" moat, less unique than the GaN piece — Lockheed has equivalent depth on PAC-3 + THAAD + Aegis BMD.

**What is not part of the moat:** Collins Aerospace's avionics business competes seriously with Honeywell and Safran on every program; it is a #1 or #2 player but not a sole source. Pratt's narrowbody engine business has a ~40% share of A320neo vs CFM's LEAP at ~60%, and zero share of 737 MAX (which is LEAP-1B exclusive) [20]. Both facts the prompt asked to "say honestly if it's mostly brand or scale" — Collins and the GTF program are scale-plus-incumbency, not unique IP.

## AI buildout bottleneck map

This is where the framing diverges most from a pure-AI name. RTX is **mostly indifferent or marginally exposed** to the AI buildout bottlenecks named in the prompt:

| Bottleneck | RTX position |
|---|---|
| Power generation, grid interconnect | Indifferent (no datacenter exposure of consequence) |
| TSMC CoWoS-L allocation | Indifferent — defense electronics don't use HBM-stacked logic |
| HBM3e supply | Indifferent |
| Optical interconnect supply | Marginal — Collins makes some FOTS/avionics optical, but it is not a 800G InfiniBand/Ethernet supplier |
| Liquid cooling >100 kW/rack | Indifferent |
| Electrical contractor capacity | Indifferent |
| Kernel/compiler talent | Marginal — Raytheon competes with Anduril/Palantir for ML engineers but mainly on signal-processing rather than training-systems talent [16] |
| Training data quality | Indifferent |

**The bottleneck map that actually binds RTX is a different one** and worth naming explicitly because that is where the alpha-vs-sell-side lives:

- **Solid rocket motor (SRM) capacity** — gating Tomahawk/SM-6/AMRAAM production; the L3Harris–Aerojet acquisition concentrated supply, and DoD is funding alternate suppliers (Northrop, Anduril/X-Bow). RTX is **exposed customer** here, not constraint owner.
- **GaN-on-SiC wafer supply** — 4-inch and 6-inch SiC substrates; Wolfspeed's distress in 2024–25 tightened defense-side wafer availability. RTX is partly insulated via its captive foundry but still **exposed**.
- **Titanium forgings and large castings** (engine cases, missile bodies) — Pratt cited castings +10%/forgings +18% YoY as proof of recovery, meaning these were the bottleneck through 2024–25 [17]. **Exposed.**
- **PW1100G powder-metal alloy lot inspection capacity** — the actual binding constraint on aftermarket throughput; effectively single-source through Carpenter and a handful of qualified Asian forges. **Constraint owner downstream**, i.e., RTX bears the AOG cost.
- **Cleared kernel/embedded engineers** — security-cleared ML and DSP engineers are scarcer than cleared cyber engineers; the Anduril/Palantir/Saronic neo-primes are pulling some of this talent out of the primes [21]. **Beneficiary today, exposed tomorrow.**

If you want to invest in the "AI buildout bottleneck map" specifically, RTX is the wrong vehicle. If you want to invest in the analogous defense supply-chain bottleneck map, the GaN foundry and the F135 are the two pieces worth owning.

## Competitive teardown

**Lockheed Martin (LMT)** — competitor on the missile/interceptor axis (PAC-3 MSE, THAAD, NGI for homeland midcourse) and on F-35 itself (LMT is airframe prime, RTX is engine + many electronics). The 2026 multiyear deal raises PAC-3 MSE production from 550 to 2,000/year over six years [19]. **Parity-or-better for LMT on hit-to-kill interceptors**; RTX wins on sensor + ground systems.

**Northrop Grumman (NOC)** — competitor on hypersonics (HACM is a Raytheon-Northrop *joint* award, $1.4B total, first flight slipped from FY25 to FY26) [22], B-21 bomber (NOC sole), and ICBM/Sentinel (NOC sole). NOC has its own GaN MMIC capability but lower volume than Andover. **Parity on hypersonics; NOC has owned the next-gen strategic platforms.**

**General Dynamics (GD)** — minimal overlap (ground vehicles, submarines, IT services).

**CFM International (GE Aerospace + Safran)** — the binding competitor on commercial narrowbody engines. LEAP is sole-source on 737 MAX and has ~60% A320neo share [20]. LEAP-1A and LEAP-1B together have a 99.9%+ dispatch reliability and 250M+ flight hours; GTF has had three years of AOG drama. **CFM has parity on thrust and superior parity on reliability today**; the GTF advantage is fuel-burn and aftermarket margin once the powder-metal cohort is through.

**Honeywell and Safran** — Collins Aerospace's competitors on avionics, flight controls, interiors. No segment of Collins is a true sole-source franchise.

**The neo-primes — Anduril, Palantir, SpaceX, Saronic, Scale AI** — this is the one to take seriously even though they are not yet a P&L threat. They beat the primes on **obligations per employee** (SpaceX and Anduril already exceed Northrop, Boeing, GD on that metric) [21]. They prefer fixed-price contracts (Palantir and SpaceX use them ~exclusively; Anduril 65–80%), which is corrosive to the cost-plus-margin model the primes were built on. SpaceX has 28 of 54 NSSL launches through 2029. **None of this directly takes the F135 or LTAMDS away from RTX in the next five years** — these are programs of record with multi-decade tails. The threat is in the *next* generation of programs: cheap mass (autonomous ships, attritable drones), software-defined battle management, and on-orbit constellations, which is where RTX's incumbency advantage is thinnest. The Golden Dome procurement structure (340 new vendors approved in tranche 3 alone, bringing the pool to 2,440 [5]) is the structural canary.

## Bull case — technical

The technical conditions that have to hold for RTX to outperform from $176:

1. **GTF powder-metal AOG curve continues to flatten** (Q1 26 was −15% in groundings; needs to keep going). If aftermarket comes back to a normal cycle by 2027, the Pratt segment swings from net cost-cause to net cash producer through the largest installed-base monetization wave in narrowbody history. **Falsifier: AOG plateaus or increases in Q3 2026.**
2. **F135 ECU passes critical design review (CDR) on schedule** — currently PDR cleared per Janes [15]. CDR completion locks in the sole-source position through ~2045. **Falsifier: a competing-engine RFP is reopened.**
3. **GaN remains the radar substrate of choice into 2030** with no GaN-on-diamond or wide-bandgap successor closing on production. Andover is a 10-year lead.
4. **Defense supercycle holds**: $271B backlog at 1.56 book-to-bill is roughly three years of revenue under contract [8]. As long as DoD outlays grow nominally and FMS continues at the recent Ukraine/Israel/Taiwan/GCC pace ($3.7B Ukraine PAC-2 deal in April 2026 alone [18]), Raytheon segment revenue is mechanically up at 8–10%.
5. **Golden Dome share** — Raytheon is one of 12 SHIELD primes [5]. Even a modest share of the $151B program over 10 years is incremental.

**Base rate context:** Defense primes have lost share roughly never in the post-1990s consolidation cycle. The 51-to-10 prime shrinkage is the actual reference class [23]. Cost-plus, multi-decade sustainment tails, and security clearance gates make the displacement base rate much lower than CPU→GPU or on-prem→cloud. The closest analog is GE → Pratt on F-35 engine in 1996 — the *winner* there is RTX. Working against this is that we are likely at the early innings of the *first* genuine private-capital-funded prime entrants (Anduril, SpaceX) in 30 years, so the historical base rate may understate displacement risk for next-generation programs.

Financial: at $176, ~26× forward earnings with mid-single-digit organic top-line and high-single-digit segment margin expansion on backlog conversion gets you to ~$8.00 EPS by 2028 and a re-rate to the LMT/NOC ~22× multiple = ~$210 — call it ~+20% on a 24-month horizon, with the dividend.

## Bear case — technical

The version a short-seller who reads `mil-std-883` would write:

1. **Powder metal contamination isn't isolated to PW1100G.** The same Carpenter Powder Products lot was used in PW2000 (C-17, 757) and the FAA published a draft AD in 2024 linking PW2000 parts to the same defect [17]. If the FAA expands the inspection requirement to additional Pratt fleets or finds the contamination affects other parts of the GTF (HPT disks, etc.), the AOG curve re-steepens. Customer compensation (Lufthansa, IndiGo, Spirit, Wizz settlements) has already exceeded $5B and remains an open liability.
2. **Tariff drag on Collins is structural, not transient.** RTX absorbed $500M of IEEPA tariff costs YTD and guides to $850M for the full year, with 130bps margin headwind to Collins offset partially by $75M of mitigation [13]. Collins margin is now a function of an executive-order regime that can change quarterly.
3. **Fixed-price defense contracting is creeping in.** Multiyear missile production agreements (Tomahawk to 1,000/yr, AMRAAM to 1,900/yr, SM-6 to 500/yr) are nominally favorable but priced before the latest input-cost inflation [18]. If SRM and energetics costs run hot, RTX absorbs it.
4. **Neo-prime erosion of next-gen contract awards.** Anduril/Palantir/SpaceX/Saronic obligations-per-employee exceeding NOC/GD/Boeing is the metric to watch — the relevant lens is not current revenue but whose architecture wins the next ten years of program-of-record awards [21]. Golden Dome is the canary: if Anduril's autonomy stack ends up doing the AI battle-management layer that RTX's BC3 was being positioned for, the highest-margin software wedge of the future IAMD stack goes to neo-primes and RTX is left selling commodity GaN and missile bodies.
5. **GaN-on-SiC monopoly is shorter than it looks.** Wolfspeed's distress (which RTX sources around) is signaling the substrate is getting cheaper, more available, and showing up in commercial 5G base stations and EV inverters. Foundry moats shorten as substrate volume scales.
6. **Geopolitical de-escalation removes a beat.** The Q1 2026 sell-off was specifically attributed to Iran-ceasefire optimism unwinding the "defense premium" in the multiple [13]. A genuine de-escalation in Ukraine + Middle East + Taiwan would not zero out the backlog (it's contracted) but it would compress the forward multiple from ~26× to ~18× quickly. The asymmetric tail is large.

## Market view check

At $176 / ~26× forward / ~3.0× EV-revenue / 1.5% yield, the market is paying full price for the *current* defense supercycle backlog conversion and *some* of the GTF aftermarket recovery, but is **not** paying much for a Golden Dome share, F135 ECU optionality, or the GaN scarcity story. The recent sell-off from the 52-wk high of $214 looks more like de-rating on tariff/peace-deal noise than a re-assessment of the franchises. **The market consensus is essentially: "good defense beneficiary, GTF eventually heals, but capital-intensive and not an AI play."** That last clause — "not an AI play" — is correct as I've laid out, but does not fully discount the AI-adjacent monopoly on cleared GaN production for next-generation sensing. If you're underwriting the defense supercycle as a 5-year story, the technical substrate justifies the price. If you're underwriting "AI infrastructure exposure," this is the wrong ticker.

## 90-day falsifiers

- **Q2 2026 earnings (late July):** GTF AOG count — needs to keep declining QoQ. >5% sequential improvement = bull confirmation; <0% = bear thesis activates.
- **FAA action on PW2000/GTF powder-metal AD:** publication of a final rule expanding inspection scope, or RTX disclosure of a new compensation reserve charge.
- **F135 ECU CDR milestone** (publicly tracked via Janes/A&SF — currently PDR passed) [15]. CDR slippage past Q3 = ECU first delivery slips past 2029.
- **Golden Dome SHIELD task-order awards:** the IDIQ structure means follow-on TOs (rather than the headline $3.2B umbrella) drive actual revenue. Watching for Raytheon's share of the next tranche.
- **LTAMDS deliveries:** "two more by end-2025" needs to have actually closed and additional Army OTC quantities awarded [12].
- **Continuing-resolution / NDAA dynamics:** FY27 NDAA mark-up in July typically reveals multiyear procurement authority for Tomahawk/SM-6 — gating production above the 2-4× rates targeted [18].
- **DoD Replicator-style commitments to attritable systems** at scale, or Anduril/Saronic landing a $1B+ program-of-record — would update the neo-prime displacement timeline.

## What I could not verify

- Exact RTX net debt as of Q1 2026 close; EV calculation uses an estimated ~$36B which I could not pin to a 10-Q line.
- Specific share of CoWoS-or-equivalent advanced packaging used by defense electronics — this is not a meaningful number for RTX based on what I read but I cannot rule out small exposures via Collins mission-systems silicon.
- Pratt's actual remaining GTF compensation liability beyond what's been disclosed publicly (>$5B cumulative), and whether any new reserve was taken in Q1 26.
- The internal economics of the Andover GaN foundry — capacity utilization, wafer cost, dependence on external SiC substrate suppliers.
- The exact distribution of the $109B defense backlog by program (Patriot vs. AMRAAM vs. SM-3 vs. F135 sustainment) — RTX does not break this out at that granularity.
- Whether the Lot 18/19 F135 contract is fixed-price-incentive-fee or firm-fixed-price; this matters for margin durability under input-cost inflation.

## Sources

[1] https://finance.yahoo.com/quote/RTX/ — retrieved 2026-05-10 — RTX last close $176.09, market cap ~$238B, trailing P/E 33×

[2] https://www.rtx.com/news/news-center/2026/04/21/rtx-reports-q1-2026-results- — retrieved 2026-05-10 — Q1 2026 official release: $22.1B sales, $1.78 adj EPS, segment breakouts, guidance raise

[3] https://www.prnewswire.com/news-releases/rtx-reports-q1-2026-results-302748514.html — retrieved 2026-05-10 — segment detail and FY26 guide $92.5–93.5B / $6.70–6.90 adj EPS

[4] https://www.rtx.com/news/news-center/2025/02/24/rtxs-raytheon-demonstrates-first-ever-ai-ml-powered-radar-warning-receiver-for-4 — retrieved 2026-05-10 — CADS cognitive RWR demonstrated on F-16

[5] https://www.airandspaceforces.com/space-force-reveals-space-based-interceptor-awards-golden-dome/ — retrieved 2026-05-10 — Golden Dome SHIELD IDIQ structure and $3.2B initial awards

[6] https://www.marketbeat.com/stocks/NYSE/RTX/forecast/ — retrieved 2026-05-10 — analyst price targets ($206 median; range $179–$240) and 52-week range

[7] https://stockanalysis.com/stocks/rtx/statistics/ — retrieved 2026-05-10 — valuation ratios (forward P/E 26×, EV/EBITDA 17.35×, revenue TTM $90.4B)

[8] https://www.tikr.com/blog/rtx-q1-2026-22-1b-revenue-and-21-eps-growth-back-the-defense-thesis — retrieved 2026-05-10 — backlog composition ($162B commercial / $109B defense), book-to-bill 1.56

[9] https://stockanalysis.com/stocks/rtx/dividend/ — retrieved 2026-05-10 — $0.73/qtr dividend after 7.4% raise, 1.5% yield

[10] https://fintel.io/ss/us/rtx — retrieved 2026-05-10 — short interest 1.33% of float vs 2.98% peer avg

[11] https://www.financecharts.com/stocks/RTX/performance/total-return — retrieved 2026-05-10 — YTD total return +7.5%

[12] https://www.armyrecognition.com/news/army-news/2026/u-s-army-moves-to-fix-patriot-air-defense-coverage-gaps-with-ltamds-radar — retrieved 2026-05-10 — LTAMDS production, 360° GaN AESA, $3.8B cumulative contract

[13] https://www.militaryaerospace.com/sensors/article/55355629/raytheon-technologies-corp-raytheon-to-continue-building-gallium-nitride-gan-ltamds-missile-defense-radar-in-1-billion-order — retrieved 2026-05-10 — Andover GaN foundry, $1B follow-on order, prototype-in-18-months

[14] https://stockstory.org/us/stocks/nyse/rtx/news/earnings-call/rtx-q1-deep-dive-defense-outperformance-and-supply-chain-challenges-shape-2026-outlook — retrieved 2026-05-10 — tariff drag $500M YTD / $850M FY, FCF guide $8.25–8.75B, CapEx $3.1B

[15] https://breakingdefense.com/2026/04/pentagon-awards-pratt-whitney-6-6-billion-for-f-35-engines/ — retrieved 2026-05-10 — F135 Lot 18/19 + ECU $6.6B sole-source contract, ECU PDR passed, 2029 first delivery

[16] https://www.airandspaceforces.com/air-defense-software-prototype-raytheon/ — retrieved 2026-05-10 — Raytheon $39M Air Force air-defense software award and BC3 battle management

[17] https://www.flightglobal.com/engines/2026/04/rtx-says-gtf-groundings-are-coming-down-thanks-to-maintenance-ramp/ — retrieved 2026-05-10 — Q1 2026 GTF AOG −15%, castings +10%, forgings +18%, plan on track; PW2000 powder-metal AD context

[18] https://news.usni.org/2026/02/04/raytheon-to-bolster-tomahawk-and-sm-6-production-in-critical-munition-deal — retrieved 2026-05-10 — Tomahawk >1000/yr, AMRAAM 1,900/yr, SM-6 >500/yr, multiyear DoW agreements; $3.7B Ukraine PAC-2 deal

[19] https://www.eurasiantimes.com/us-awards-2-45-billion-contract-for-patriot-pac-3-missile-production-while-ukraine-receives-its-first-system/ — retrieved 2026-05-10 — Lockheed PAC-3 MSE 550→2,000/yr ramp; clarifies LMT vs RTX division of labor on Patriot

[20] https://airinsight.com/engine-market-share-on-airbus-narrow-body-aircraft/ — retrieved 2026-05-10 — LEAP-1A ~60% / GTF ~40% A320neo split, LEAP-1B exclusive on 737 MAX, fleet hours and reliability

[21] https://responsiblestatecraft.org/defense-tech-partnership/ — retrieved 2026-05-10 — neo-prime obligations-per-employee, fixed-price contract mix, Anduril/Palantir/SpaceX/Saronic dynamics

[22] https://www.airandspaceforces.com/hacm-flight-tests-fy26-yearlong-delay/ — retrieved 2026-05-10 — HACM joint Raytheon/Northrop scramjet, $1.4B cumulative, first flight slipped to fall 2025

[23] https://www.csis.org/analysis/why-us-defense-industrial-base-so-isolated-us-economy — retrieved 2026-05-10 — 51-to-10 prime consolidation as base rate for displacement in defense