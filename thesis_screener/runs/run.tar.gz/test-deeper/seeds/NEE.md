# NEE — NextEra Energy, Inc.

## Where this sits in the AI stack
NEE sits at the **power layer** — the gating physical input to every GPU rack, downstream of nothing and upstream of the entire AI compute stack. It operates through two distinct businesses: (1) **Florida Power & Light (FPL)**, a vertically integrated regulated utility serving ~5.9M customers; and (2) **NextEra Energy Resources (NEER)**, the world's largest developer and operator of merchant wind, solar, battery storage, and nuclear generation, selling primarily under 15–25 year PPAs. The relevant workload is **AI training and inference data center load** — i.e., 24/7 base load with low PUE and tight latency/reliability tolerances, not residential or industrial demand. NEER's product is firmed MWh delivered to a hyperscaler campus or to a balancing authority that the hyperscaler draws from; FPL's product is regulated transmission and generation to data centers locating in Florida.

## Snapshot
- **Price:** $93.10 (2026-05-08 close) [1]
- **Market cap:** ~$194B [1]
- **52-week range:** $63.88 – $98.75 [13]
- **Forward P/E:** 21.5× (vs. 5-yr avg 24.6×); implies consensus FY26/FY27 blended EPS ~$4.30, above company guidance midpoint of $3.97 for FY26 [2][3]
- **EV / TTM revenue:** ~10.9× (EV $303B / TTM rev $27.9B) [2]
- **Consensus 12-mo PT:** $94.62 (≈ flat); high targets $104 (UBS), $106 (MS) imply +12–14% [2]
- **YTD total return:** +19.6% [13]
- **Short interest:** n/a — current FINRA print not retrieved with confidence; historically low for an A-rated regulated utility (typically <2% of float).

## Moat — what it is physically made of
The "moat" here is not software lock-in. It is a stack of physical and regulatory artifacts that a new entrant cannot replicate in the relevant window (24–60 months). Decomposing:

**1. Interconnection queue position.** This is the single most underrated moat. PJM's median application-to-COD time has gone from <2 years (2008) to >8 years (2025) [4]. ERCOT's generation queue now exceeds 2,000 requests; MISO is still working through GIAs from 2018–2019 [4]. NEER's 33 GW contracted backlog [5] consists overwhelmingly of projects that already cleared queue gates — meaning the asset is not "33 GW of nameplate," it is "33 GW of nameplate **with an interconnect slot a new entrant would need 5–8 years to obtain**." This is the single hardest input to procure and the least visible on a balance sheet.

**2. Operating nuclear fleet.** ~6.2 GW across Turkey Point and St. Lucie (FPL, PWR), Seabrook (NH, PWR), and Point Beach (WI, PWR) [6]. Replacement cost is effectively infinite over the relevant horizon: zero new US light-water reactors have entered commercial service since Vogtle 3/4 (2023/2024), which took 16 years and cost $30B+ for 2.2 GW. The 615 MW Duane Arnold restart for Google (Q1 2029 COD, 25-yr PPA) [7] is unique: there are only ~10 candidate plants in the US with intact containment, and NEER controls one of the most viable. Constellation has Three Mile Island and Clinton [8]; Talen has Susquehanna; the universe of dispatchable, 24/7, carbon-free, restart-ready nuclear is small and finite.

**3. CoWoS-equivalent for power: gas turbine slot allocation.** GE Vernova's gas-turbine backlog hit 100 GW in Q1 2026 and CEO Strazik expects to be sold out through 2030 by year-end [9]. Siemens Energy is similar. NEER's announced 9.5 GW gas hub package (4.3 GW Pennsylvania, 5.2 GW Texas, $33B combined) under the US–Japan trade deal [10] requires turbine slots that NEER appears to have secured ahead of new entrants. This is the closest analog to TSMC CoWoS-L allocation in the AI hardware stack — a physical constraint where slot ownership equals optionality. NEER has not disclosed the turbine OEM split, which I could not verify.

**4. FPL regulated rate base mechanics.** The November 2025 FPSC settlement approved $945M of incremental base rates in 2026 and $705M in 2027, plus solar/storage recovery riders in 2028–2029 [11]. Critically, NEE management has quantified large-load economics: "every GW of large load = ~$2B of capex opportunity at FPL" [11]. Florida is structurally advantaged for data centers (no state income tax, weather-driven cooling can be offset by sea-water and air-cooled designs, and FPL's existing generation reserve margin). A regulated utility earning its allowed ROE on incremental rate base is a near-perfect annuity that competitors literally cannot enter — FPL has a state-granted monopoly.

**5. Development capability at scale.** NEER's 110 GW battery-storage pipeline and 60+ GW data-center-hub opportunity pipeline (vs. ~50 GW in Dec 2025) [5][12] reflects an organization that signs land options, performs interconnect studies, manages EPC partners, and closes tax-equity financings at a rate no other developer matches. This is closer to a manufacturing learning curve than a moat — replicable in principle, but it took NEER 25 years to build.

Durability ranking: nuclear fleet (very high, regulatory barriers near-permanent) > interconnect queue position (high, decays only as queues clear post-reform) > FPL franchise (high, but politically exposed) > gas turbine slots (medium, time-limited optionality) > development pipeline (medium, replicable by Constellation/Vistra/AES with capital).

## AI buildout bottleneck map
Gating constraints over the next 24 months, with NEE's exposure:

| Constraint | Status | NEE position |
|---|---|---|
| **Power generation capacity** | Severe. US data center load forecast 325–580 TWh by 2028 from 176 TWh in 2023 [4] | **Beneficiary + supplier.** Largest renewable developer, growing gas+nuclear |
| **Grid interconnect (PJM/MISO/ERCOT)** | Critical. 5–8 year waits; FERC Dec 2025 PJM order initiates reform [4][14] | **Owner of queue positions** worth billions in option value |
| **Gas turbine supply** | Bottleneck. GE Vernova ~100 GW backlog, sold out to 2030 [9] | **Slot holder** for 9.5 GW gas hubs — must verify OEM commitments |
| **HV transformer / switchgear** | Severe. 2–3 year lead times for large GSU transformers (Hitachi, Hyundai, Mitsubishi) | Exposed but better positioned than new entrants via long-term supplier contracts (unverified specifics) |
| **Liquid cooling at >100 kW/rack** | Vendor problem, not NEE's | Indifferent |
| **HBM3e / CoWoS-L** | Vendor problem (NVDA/TSM) | Indifferent |
| **Skilled electrical/EPC labor** | Tight. Boilermakers, linemen, IBEW shortage | Exposed but mitigated by FL non-union scale at FPL |
| **IRA tax credit eligibility** | OBBBA July 2025 phases out solar/wind PTC/ITC for projects starting construction after July 4, 2026 unless in service by 12/31/27; battery, geothermal, nuclear retain credits through 2034 [15] | **Mixed.** Hurts marginal new solar/wind economics post-2027; helps batteries/nuclear; existing 33 GW backlog largely safe-harbored |
| **Behind-the-meter co-location ruling** | FERC Dec 2025 order to PJM forces new tariff for co-located large loads; threatens "carve out a chunk of nuclear plant for one hyperscaler" model [14] | **Net beneficiary** — pushes hyperscalers back to grid-connected PPAs (NEER's product) |

The honest reading: NEE is the most diversified beneficiary in this map. It is exposed to gas-turbine slots (a constraint it has partially solved), and it is exposed to IRA repeal of wind/solar credits (but the credits survive for batteries through 2034 and for grandfathered projects in its 33 GW backlog).

## Competitive teardown

**Constellation Energy (CEG).** The single most important competitor. Closed the $16.4B Calpine deal in February 2026, creating a 55 GW fleet [8] heavily weighted to nuclear (~22 GW) and natural gas. On the technical axis of **24/7 dispatchable carbon-free baseload**, CEG is ahead of NEE: more operating nuclear MW, Three Mile Island (Crane) restart for Microsoft, Clinton for Meta. Where NEE wins: scale of renewables development (NEER ~33 GW backlog vs. CEG ~minimal greenfield renewables), FPL regulated cash flow stability, geographic diversification beyond PJM.

**Vistra (VST).** Meta deal Jan 2026 for existing PJM nuclear plus a 300 MW SMR option at one of Vistra's sites [8]. Vistra is more leveraged to merchant power-price upside (Texas/PJM); NEE is more leveraged to long-term contracted volumes. On a per-MWh basis, Vistra captures more spot upside if AI demand spikes prices; NEE captures more visibility.

**Talen (TLN).** AWS Susquehanna 1.9 GW PPA ($18B over 17 years) [8]. Talen was the test case for behind-the-meter co-location and lost at FERC in Nov 2024 [8]; the Dec 2025 FERC PJM order is partially responsive [14]. Talen is a single-asset story; NEE is a portfolio.

**GE Vernova (GEV).** Not a substitute — a **supplier and gatekeeper**. The 100 GW turbine backlog [9] means GEV is the rate-limiter on every gas project NEE (and everyone else) wants to build. GEV's slot allocation effectively decides which utility gets to build gas in 2028–2030. The strategic risk to NEE: GEV could prioritize larger-volume customers (Saudi, Asian IPPs) over NEE.

**Independent renewable developers (AES, Brookfield Renewable, EDP Renováveis, Engie).** Compete with NEER on individual project bids. AES has won marquee Google deals. The honest read: NEER is larger, has lower cost of capital, and has more queue positions, but its win-rate on hyperscaler bids is not 100% — Google in particular multi-sources.

**SMR startups (Kairos, X-energy, NuScale, Oklo, TerraPower).** A 2030+ threat to nuclear pricing power. Kairos has Google MOU targeting 2030 first unit [16]; X-energy targets 2029 at Dow's Texas site [16]; NuScale has NRC design approval and targets 2030 [16]. None will be at commercial scale in the next 4 years; all have first-of-a-kind cost risk historically running 2–3× projection. NEE has hedged by partnering with Google on "new nuclear" exploration alongside the Duane Arnold restart [7].

What would have to be true for a competitor to take material share from NEE: (a) CEG's nuclear-restart pipeline expands beyond TMI/Clinton, which requires another 4–5 candidate plants with intact containment that don't currently exist in NEE's portfolio; (b) GE Vernova / Siemens accept a new entrant for >5 GW of 2028–2030 turbine slots, which would require slots NEE hasn't already reserved; (c) SMRs hit commercial COD at <$60/MWh fully loaded by 2030, which has never happened for first-of-a-kind nuclear.

## Bull case — technical

Base rate context: in the last six platform shifts where a physical input was the bottleneck (mainframe→PC supplying DRAM in the 1980s; mobile networks needing fiber in the 2000s; EV requiring lithium 2018–2024), the bottleneck-holder enjoyed elevated returns for 4–7 years before competitive supply caught up. Power is harder to scale than any of those — new gas units take 4–5 years from order to COD; new nuclear takes 10+.

Technical conditions for outperformance:
1. **Hyperscaler capex remains structurally elevated.** 2026 aggregate ~$725B (+77% YoY) [17], of which ~75% is AI infrastructure. As long as 2027 guidance doesn't roll back >15% sequentially, the demand side is intact.
2. **GE Vernova / Siemens turbine backlogs do not unwind.** Confirmation that NEER's 9.5 GW gas hubs convert from MOU to definitive in Q3 2026 [10] would be a major proof point.
3. **PJM/MISO interconnect reform proceeds slowly.** The longer queues remain backed up, the more valuable NEER's existing queue positions are.
4. **Duane Arnold NRC approval tracks to plan** for Q1 2029 COD [7]. Slippage of one year reduces NPV of the Google PPA modestly; cancellation would be very damaging to the AI-nuclear-restart narrative across the sector.
5. **FPL data-center wins materialize.** Florida is not yet a top-3 data-center cluster (vs. Northern VA, Texas, Phoenix). If even 3–5 GW of incremental large-load lands in FPL territory, the $2B-capex-per-GW math [11] translates to $6–10B of regulated rate base growth on top of existing trajectory.

Financial implication: at $93 and ~22× consensus, NEE is priced for ~6–8% EPS CAGR. If the 33 GW backlog converts at expected margins plus the 9.5 GW gas hubs sign in 2026, EPS growth could sustain 10%+ for several years, supporting multiple stability or modest expansion to 24–26×. Combined with the dividend (~3%), total return of 13–18% annualized over 3 years is achievable without heroic assumptions.

## Bear case — technical

The honest short thesis written by someone who reads turbine specs:

1. **Hyperscaler capex is cyclical, not secular.** A coherent bear view: training compute requirements per frontier model have grown ~4–5× per generation; if Anthropic/OpenAI/Google find that GPT-5/Claude-class architectures don't yield the expected loss reductions, or if inference shifts toward smaller distilled models (e.g., post-Llama-4 distillation, Mixture-of-Experts efficiency gains), then the 2027/2028 capex curve flattens. NEE's 33 GW backlog is contracted, but the >60 GW pipeline of hub opportunities is not, and growth is priced into the multiple.

2. **NEER is structurally a wind-and-solar developer in a world where wind-and-solar tax credits are being repealed.** The OBBBA phases out PTC/ITC for solar/wind projects starting construction after July 4, 2026 [15]. Existing backlog is grandfathered; new bookings post-2026 face materially worse economics. NEER's response (more gas, more nuclear) is rational but reduces growth velocity relative to the renewables-heavy thesis.

3. **Gas builds may be slower than guided.** The 9.5 GW Texas/Pennsylvania hubs require ~15–20 GE/Siemens H-class turbines plus HRSGs, plus generator step-up transformers (24-month leads), plus interstate pipeline capacity in Marcellus/Eagle Ford, plus interconnect approvals. Slippage of 12–24 months from advertised in-service is the historical base rate for greenfield CCGT of this scale.

4. **FERC could expand the behind-the-meter exception.** If the December 2025 PJM order [14] is interpreted permissively under a Trump-friendly FERC, hyperscalers could directly contract with merchant nuclear (Constellation, Vistra, Talen) bypassing the grid-connected PPA model NEER sells. This isn't the base case — the order tightened co-location rules in many respects — but a reversal would compress NEER's pricing power.

5. **Renewable cost re-inflation already in motion.** Lazard's June 2025 LCOE+ shows utility-scale solar and onshore wind LCOE rising in 2024–2025 for the first time in a decade (tariffs, interconnect costs, labor) [18]. If gas turbines are >$2,000/kW installed and renewables-plus-storage is >$1,500/kW, the cost arbitrage NEER built its business on is narrowing.

6. **Competitive dynamics: Constellation post-Calpine is the bigger fish on dispatchable.** At 55 GW including ~22 GW nuclear [8], CEG offers hyperscalers something NEER cannot: large-scale, paid-for, already-operating 24/7 carbon-free baseload. Every GW that goes to CEG is a GW NEER doesn't sell.

The bear path to underperformance: hyperscaler 2027 capex guidance falls 10–20% in early 2027; NEER backlog adds decelerate from 4 GW/quarter to <2 GW; multiple compresses to 18–19× as the "AI-tied utility" framing fades.

## Market view check
At $93 and 21.5× forward EPS [2], NEE trades roughly in line with high-quality regulated peers (Southern, Duke ~18–20×) plus a modest premium for the NEER growth engine. Consensus PT of ~$95 [2] implies the market views the AI tailwind as **already in the price**. The market appears to believe: (a) ~9–10% EPS growth is durable through 2028; (b) the IRA repeal is digestible because backlog is grandfathered; (c) the AI buildout is real but not all gains accrue to NEE. I think the market is roughly right on direction but slightly underweighting the **interconnect queue moat** and **gas-turbine slot optionality** — both of which are cheap puts on continued AI demand and expensive puts to replicate. A multiple of 24× on FY27 EPS of ~$4.40 implies ~$105, which is closer to UBS/MS targets. The asymmetry is modestly favorable but not screamingly so; this is not a 50% mispricing.

## 90-day falsifiers
- **Q2 2026 NEE earnings (late July 2026):** does NEER add >3 GW to backlog? Does management raise FY26 EPS guidance toward the high end of $4.02? Does the data-center hub pipeline grow from 60+ GW toward 70 GW or stagnate?
- **Q2 2026 hyperscaler earnings (MSFT/GOOGL/META/AMZN):** does any of them cut 2026 capex guidance by >10% sequentially? Especially watch Meta and Amazon, which have the most discretionary AI infra spend.
- **GE Vernova Q2 2026 (July):** total backlog at 110 GW as guided [9]? Any signs of slot reallocation away from NEER's Texas/Pennsylvania hubs?
- **NEER 9.5 GW Japan trade deal definitive agreements:** management said Q3 2026 [10]; failure to sign by end of August would be a material setback.
- **Treasury IRA "begin construction" safe-harbor guidance:** expected mid-2026. If Treasury defines "begin construction" narrowly (5% spend rule strict, no continuous-work alternative), more of NEER's pipeline falls outside the grandfather.
- **FERC PJM compliance filing on co-location:** PJM was directed to file new tariff in 2026 [14]. Restrictive ruling = bullish for NEER (forces grid-connected PPAs); permissive = bullish for CEG/VST/TLN.
- **Florida PSC docket updates on data-center cost allocation:** if FPSC approves a "large customer" rider that lets FPL recover data-center-driven generation capex without rate impact on residentials, this is materially positive for the FPL leg.
- **Duane Arnold NRC milestones:** any indication of license-amendment timing for restart approval.
- **AI scaling-law surprise:** GPT-5 / Claude-Opus-5 / Gemini-3 inference cost per token, or any indication that frontier training compute is plateauing. This is the macro variable that determines whether 2027 hyperscaler capex grows or shrinks.

## What I could not verify
- NEER's specific gas-turbine OEM commitments for the 9.5 GW hubs (GE Vernova vs. Siemens vs. Mitsubishi split, and whether slot reservations are firm purchase orders or "slot reservation agreements" subject to cancellation).
- The exact percentage of NEER's 33 GW backlog that is fully "safe-harbored" under the OBBBA grandfather for IRA credits.
- Current NEE short interest as % of float (FINRA print).
- Hyperscaler-specific take-or-pay structure on the Google 3.5 GW and Meta 2.5 GW PPAs (curtailment terms, escalators, force-majeure provisions).
- Whether the 60+ GW data-center hub "pipeline" reflects signed land options/LOIs or earlier-stage commercial discussions.
- NEER's HV transformer supply commitments and any exposure to Hitachi/Mitsubishi/Hyundai lead times.
- The specifics of any 24/7 carbon-free-energy (CFE) matching obligations in the Google PPAs that could require firming costs at NEER's expense.
- Capacity factor assumptions and curtailment risk on the Texas solar/storage backlog given ERCOT's growing renewable saturation.

## Sources
[1] [NextEra Energy (NEE) — Yahoo Finance](https://finance.yahoo.com/quote/NEE/) — retrieved 2026-05-10 — current price and market cap.
[2] [NEE Statistics & Valuation — stockanalysis.com](https://stockanalysis.com/stocks/nee/statistics/) — retrieved 2026-05-10 — forward P/E 21.5×, EV $303B, TTM revenue $27.9B.
[3] [NEE Stock Forecast & Analyst Price Targets — stockanalysis.com](https://stockanalysis.com/stocks/nee/forecast/) — retrieved 2026-05-10 — consensus PT $94.62; UBS $104, MS $106.
[4] [How ISOs and RTOs Are Addressing Large Load Growth in 2025 — Yes Energy](https://www.yesenergy.com/blog/how-isos-and-rtos-are-addressing-large-load-growth-in-2025) and [ERCOT large load queue — Latitude Media](https://www.latitudemedia.com/news/ercots-large-load-queue-has-nearly-quadrupled-in-a-single-year/) — retrieved 2026-05-10 — established PJM 8-yr queue, ERCOT 2,000+ requests, US DC load forecast 325–580 TWh by 2028.
[5] [NextEra adds record 4 GW of renewables and storage backlog in Q1 — PV Magazine](https://pv-magazine-usa.com/2026/04/23/nextera-energy-adds-record-4-gw-of-renewables-and-storage-backlog-in-q1/) — retrieved 2026-05-10 — 33 GW backlog, 110 GW battery pipeline.
[6] [NextEra Energy Resources — Nuclear page](https://www.nexteraenergyresources.com/our-solutions/nuclear.html) and [Wikipedia — Point Beach Nuclear Plant](https://en.wikipedia.org/wiki/Point_Beach_Nuclear_Plant) — retrieved 2026-05-10 — 7 units / 4 sites / ~6 GW nuclear capacity.
[7] [NextEra and Google Announce New Collaboration to Accelerate Nuclear Energy Deployment — newsroom.nexteraenergy.com](https://newsroom.nexteraenergy.com/NextEra-Energy-and-Google-Announce-New-Collaboration-to-Accelerate-Nuclear-Energy-Deployment-in-the-U-S?l=12) — retrieved 2026-05-10 — Duane Arnold 615 MW, 25-yr PPA, Q1 2029 COD.
[8] [Constellation Finalizes $16.4B Calpine Acquisition — FinancialContent](https://markets.financialcontent.com/stocks/article/marketminute-2026-3-10-constellation-energy-finalizes-164-billion-calpine-acquisition-solidifying-lead-in-ai-data-center-power-race) and [AWS-Talen 17-year PPA — EnkiAI](https://enkiai.com/nuclear/aws-data-center-talen-energy/) — retrieved 2026-05-10 — competitive landscape (CEG 55 GW, Vistra-Meta, Talen-AWS).
[9] [GE Vernova 80-GW backlog stretching into 2029 — Utility Dive](https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/) and [GE Vernova reservations + backlog grows to 100 GW — Industrial Info](https://www.industrialinfo.com/iirenergy/industry-news/article/ge-vernovas-global-natural-gas-turbine-reservations-and-order-backlog-grows-to-100-gw--356705) — retrieved 2026-05-10 — turbine bottleneck data.
[10] [NextEra to develop 9.5 GW of gas in Texas, Pennsylvania — Utility Dive](https://www.utilitydive.com/news/nextera-gas-generation-doe-softbank-texas-pennsylvania/815541/) and [NEE Q1 2026 Earnings — BigGo Finance](https://finance.biggo.com/news/US_NEE_2026-04-23) — retrieved 2026-05-10 — 4.3 GW PA + 5.2 GW TX, $33B combined, Japan trade deal.
[11] [Florida regulators approve FPL rate agreement — newsroom.fpl.com](https://newsroom.fpl.com/2025-11-20-Florida-regulators-approve-FPL-rate-agreement-that-keeps-customer-bills-low,-meets-needs-of-growing-state) and [PSC approves $7B rate hike for FPL — Florida Phoenix](https://floridaphoenix.com/2025/11/20/psc-approves-contentious-7-billion-rate-hike-for-florida-power-light-customers/) — retrieved 2026-05-10 — $945M 2026 + $705M 2027 rate increase; "$2B capex / GW large load."
[12] [NextEra Energy Q1 2026 slides — Investing.com](https://www.investing.com/news/company-news/nextera-energy-q1-2026-slides-eps-beats-amid-record-renewables-backlog-93CH-4633331) — retrieved 2026-05-10 — 60+ GW data-center hub pipeline.
[13] [NEE Total Return YTD — financecharts.com](https://www.financecharts.com/stocks/NEE/performance/total-return) and [NEE Yahoo summary](https://finance.yahoo.com/quote/NEE/) — retrieved 2026-05-10 — YTD +19.6%, 52-wk range $63.88–$98.75.
[14] [FERC Order on PJM Co-Location — ferc.gov fact sheet](https://www.ferc.gov/news-events/news/fact-sheet-ferc-directs-nations-largest-grid-operator-create-new-rules-embrace) and [Gravel2Gavel summary](https://www.gravel2gavel.com/ferc-new-order-data-center-co-location-what-utilities-need-know/) — retrieved 2026-05-10 — Dec 18, 2025 PJM co-location order details.
[15] [OBBBA phase-out of clean energy tax credits — Simpson Thacher](https://www.stblaw.com/about-us/publications/view/2025/07/08/president-trump-signs-legislation-enacting-phased-elimination-of-federal-tax-credits-for-new-clean-energy-projects-directs-treasury-to-strictly-enforce-credit-termination-for-solar-and-wind-facilities) and [Sidley Austin OBBBA analysis](https://www.sidley.com/en/insights/newsupdates/2025/07/the-one-big-beautiful-bill-act-navigating-the-new-energy-landscape) — retrieved 2026-05-10 — solar/wind PTC/ITC phase-out details, battery/nuclear retained through 2034.
[16] [Big Tech's Nuclear Bet — WWT](https://www.wwt.com/blog/big-techs-nuclear-bet-key-small-modular-reactors-for-cloud-power) and [Energy for Growth Hub SMR update](https://energyforgrowth.org/article/sept-2025-update-which-advanced-nuclear-models-are-likely-to-hit-emerging-markets-first/) — retrieved 2026-05-10 — Kairos 2030, X-energy 2029, NuScale 2030+ timelines.
[17] [Hyperscaler capex 2026 $725B — Tom's Hardware](https://www.tomshardware.com/tech-industry/big-tech/big-techs-ai-spending-plans-reach-725-billion) — retrieved 2026-05-10 — MSFT $190B, GOOGL ~$190B, META $125–145B, AMZN $200B.
[18] [Lazard LCOE+ June 2025](https://www.lazard.com/media/uounhon4/lazards-lcoeplus-june-2025.pdf) and [Higher renewables costs — Utility Dive](https://www.utilitydive.com/news/higher-renewable-energy-costs-lazard-lcoe-storage-hydrogen/720177/) — retrieved 2026-05-10 — CCGT LCOE +16% to $102/MWh, renewables cost re-inflation.