Now I have comprehensive primary-source data. Writing the dossier.

# CAT — Caterpillar Inc.

## Where this sits in the AI stack
CAT sits at the **prime-power and standby-power layer** between the substation and the data hall, plus the **earthmoving layer** that prepares hyperscale sites. Specifically: large reciprocating gas/diesel gensets in the 1.5–4 MW class (Cat 3500/3600 series; G3516 ~2 MW, G3520K ~2.5 MW) deployed in N+1/N+2 strings as either backup or, increasingly, **continuous-duty prime power**; industrial gas turbines via Solar Turbines (Centaur 40 ~3.5 MW through Titan 350 ~38 MW) for behind-the-meter generation; integrated gensets-plus-BESS-plus-SCR packages with switchgear; and Construction Industries machinery (large excavators, articulated trucks, dozers, graders) for the 1,000+-acre site prep that hyperscale AI campuses now require.[1][2][3] The workload is *not* GPU silicon, training, or inference — it is the kilowatt-to-megawatt step that has become the binding constraint of the AI buildout, because grid interconnection in PJM/ERCOT now stretches 5–8+ years and large-frame gas turbines (GE Vernova 7HA, Mitsubishi M501JAC) are sold out into 2029–2030.[4][5][6][7]

## Snapshot
- **Price:** $904.59 (NYSE close, 2026-05-05); intraday ATH $931.35 on 2026-05-07.[8]
- **Market cap:** ~$362–368B[8]
- **52-week range:** $323.31 – $931.35[8]
- **Forward P/E:** 36.6× (industry median 14.2×; ~158% premium)[9]
- **EV / NTM revenue:** ~5.3–5.6× (derived: $17.4B Q1 2026 sales annualized ≈ $70B run-rate, NTM consensus ~$73–75B, EV ~$395–410B incl. ~$30–35B finance-segment debt; not a value-line metric historically applied to CAT, included for the AI-name comparison)[10][11]
- **Consensus 12-month price target:** $689 median (MarketBeat, 37 analysts; implies –24%); $890 mean across other panels (high $1,165, low $575)[12]
- **YTD total return:** +32% (FY 2026 to date); 1-year +183–192%[13]
- **Short interest:** 1.65–2.13% of float (peer group ~4.85%; below average)[14]

## Moat — what it is physically made of
The moat is **not** intellectual property and it is **not** technology in the silicon sense. The Cat 3500/3600 reciprocating engine architecture is a derivative of mature 1990s/2000s industrial-engine designs that overlap heavily with Cummins QSK60/95, Rolls-Royce mtu Series 4000, and Wärtsilä 50SG. The moat is six concrete physical/contractual things:

1. **Manufacturing capacity for large reciprocating engines and the rate at which it can be expanded.** The binding constraint. The Lafayette, IN plant (1.6M ft² existing + 300,000 ft² announced October 2025 for $725M, completion end-2026) is the production node for the 3500/3600 family.[15] CAT is taking large-engine capacity from baseline 2024 levels to **~3× by ~2029**, which adds roughly **15 GW/year of incremental nameplate capacity**.[16] You cannot conjure equivalent capacity inside three years: you need block-and-crankshaft machining tools, foundry slots, and specialized welders. Cummins is doing the same dance one step behind ($150M Fridley, MN expansion announced Feb 2026, +30% QSK95 output).[17] This is the most durable component of the moat in the 24–36 month window.

2. **Solar Turbines lead-time advantage in the 5–40 MW band.** Solar's 24–36 month lead times sit beneath GE Vernova LM6000/LM2500XPRESS (3–5 years) and Siemens SGT-A35 (3–5 years), and far beneath Mitsubishi M501JAC and GEV 7HA heavy frames (6–7 years).[18][6] The Titan 350 (38 MW, introduced 2023) is the unit management cited as the "fastest solution out there" for behind-the-meter data-center prime power.[2] Solar's installed base (predominantly oil & gas mechanical drive and offshore power for ~70 years) is also a high-margin recurring service annuity.

3. **Dealer network — Boyd CAT, Wheeler, Holt, Caterpillar of Australia, Finning, etc.** ~150 independent dealers, ~2,500+ locations.[19] The Monarch Compute Campus deal in West Virginia is structured through Boyd CAT, not CAT direct; the dealer is the installation, commissioning, fuel-system, and 24/7 service entity. A new entrant can ship engines but cannot replicate this footprint at the speed AI campuses are commissioning.

4. **Cat Financial vendor financing.** The Monarch/AIP press release explicitly disclosed Cat Financial vendor equipment financing "aligned with equipment delivery phasing" — the first time Cat Financial has been visible at GW scale in a hyperscaler-adjacent deal.[1] This is a sticky moat ingredient because capital-constrained sponsors (AIP, Crusoe, etc.) need integrated financing, not just iron.

5. **Engineering integration: gensets + BESS + SCR + switchgear + microgrid controls.** The Joule Utah deal (4 GW G3520K + 1.1 GWh battery storage, CCHP architecture)[20] and the Monarch design (fast-response G3516 with 7-second start, augmented by BESS to absorb the ~50–80% load swings of GPU training workloads)[1] are *integrated systems*, not engine sales. Vertiv MOU (Nov 18, 2025) explicitly couples CAT/Solar generation with Vertiv's power distribution + cooling for a pre-engineered AI reference architecture.[21]

6. **Brand / risk-reduction in mission-critical infrastructure.** Inference: in a market where downtime cost is measured in millions per hour, "no one got fired for buying Cat" is real. Hard to quantify; not zero.

What is **NOT** moat: the engine technology itself, the SCR aftertreatment (off-the-shelf from Tenneco/CDTi), or the basic switchgear (commodity from ABB/Eaton/Schneider). If reciprocating engines were the moat, the moat would already be split with Cummins, Wärtsilä, mtu, and MAN. They aren't, because the moat is *capacity + dealer + financing + dealer-installed system integration*, not engineering IP.

## AI buildout bottleneck map
Gating constraints over the next 24 months and CAT's position on each:

| Bottleneck | Status | CAT exposure |
|---|---|---|
| **Grid interconnect (PJM/ERCOT)** | Queue went from <2 yr (2008) to >8 yr (2025); ERCOT large-load queue at 226–233 GW (+~4× YoY); PJM 160 GW large loads committed; Dominion alone 70 GW backlog[5][7] | **Direct beneficiary** — bridge-power demand is the entire near-term thesis |
| **Large-frame gas turbines (>100 MW)** | GEV 100 GW under contract, expects "sold out through 2030 by end-2026"; Mitsubishi sold out into 2028, doubling capacity over 2 years; Siemens turbines sold doubled YoY (100→194 units); pricing +10–20% Q-on-Q; Wood Mackenzie projects $600/kW by end-2027[6][22][23] | **Indirect beneficiary** — pushes demand to recip + aero |
| **Aero-derivative gas turbines (25–75 MW)** | LM2500/LM6000/SGT-A35 lead times 3–5 yr | **Direct beneficiary via Solar Turbines** (Titan 250/350 24–36 mo) |
| **Recip gensets (1.5–5 MW)** | Cat 3600 lead time ~107 weeks (~2 yr) per Raymond James, +20 weeks since mid-Sep 2025; Cummins QSK95 doubled capacity in 2025; Wärtsilä booked 507 MW US BTM in Nov 2025[24][17][25] | **Constraint owner** — supplier of the scarce good |
| **CoWoS-L advanced packaging (TSMC)** | TSMC bottleneck for Blackwell/Rubin substrates | **Indifferent** |
| **HBM3e/HBM4** | SK hynix dominant, Micron ramping, Samsung qualification slipping | **Indifferent** |
| **Optical interconnect / co-packaged optics** | Coherent, Lumentum, Marvell capacity | **Indifferent** |
| **Liquid cooling >100 kW/rack** | Vertiv, Boyd, CoolIT scaling | **Adjacent (via Vertiv MOU)** but not direct revenue |
| **Permitting (air, gas pipeline, water)** | Gating in some states; Project Jupiter NM swapped from gas to Bloom SOFCs to dodge NOx/water[26] | **Exposed** — deal flow contingent |
| **Natural gas supply / pipeline** | Constraint in TX/PA/VA in some sub-zones | **Exposed** (gas-fired equipment) |
| **Electrical contractor + skilled-labor capacity** | National constraint | **Exposed** (delivers iron, dealer/EPC must install) |

## Competitive teardown

**Cummins (CMI).** The closest direct competitor; same axis (recip gensets, 1–4 MW). Power Systems segment hit $7.5B revenue (+16%) and 22.7% EBITDA margin in 2025; data-center revenue ~$3.5B in 2025 (vs. $2.6B in 2024), backlog into 2028 with 2029+ active.[27][28] Cummins **doubled 95L (QSK95) capacity in 2025**, ahead of schedule, and is investing $150M in Fridley, MN for +30% incremental QSK95 output.[17] On engine performance and Tier 4/EPA NSPS compliance, the QSK95 is at parity with the Cat 3516E in standby and prime-power duty. The market is most likely a **CAT/Cummins duopoly in 1.5–4 MW prime power for the next 24 months**, both winning, with CAT's edge in integration (Solar Turbines + dealer + Cat Financial) and Cummins's edge in pure engine ramp pace. There is no axis on which Cummins is *behind* CAT in raw recip. Loss-of-share risk is real if hyperscalers begin standardizing on QSK95 reference designs.

**GE Vernova (GEV).** Different axis (large frame and aero-derivative). Backlog: **44 GW firm + 56 GW slot reservations = ~100 GW** as of Q1 2026, up 20% sequentially, with $2.4B of Q1 2026 data-center electrification orders alone (more than all of 2025).[6][22] The aero LM2500XPRESS (35 MW, 5-min black start, dual-fuel) is the unit competing head-on with Solar Titan 350; Crusoe has booked **29 LM2500XPRESS units (~1 GW)** across Dec 2024 + June 2025 orders.[29] Solar's advantage vs. GEV aero is delivery lead time, not technology — both are mature aero-derivative platforms. Where GEV has **structural parity** with CAT: the LM2500XPRESS for >25 MW BTM modules. Where GEV has **structural advantage**: heavy-frame combined-cycle for utility-scale supply behind hyperscaler campuses, where Solar does not play.

**Mitsubishi Power.** Heavy-frame M501JAC (440–465 MW class). Sold out into 2028; doubling capacity over 2 years.[23][30] Less direct overlap with CAT — Mitsubishi competes with GEV 7HA in the utility-scale tier feeding campuses, not with CAT's 2 MW gensets.

**Siemens Energy.** **#1 share in >10 MW gas turbines (31%); #2 in >100 MW (26%)**. €146B record backlog (FY2025).[31] SGT-A35 aero (32–39 MW) competes with Solar Titan 350 in EU/MEA markets more than US; less visible in US hyperscaler deals than GEV.

**Wärtsilä.** Recip in the 12–19 MW per-engine class — *one tier above* CAT's 3500 series. Booked **507 MW (27× 50SG engines)** for an unnamed US data-center developer Nov 20, 2025, BTM primary power, 2027 delivery.[25] Pitch is "flexible engine power plants" superior to gas turbines on ramp rate and starts/day for AI loads. Real share threat at the 100+ MW BTM plant level where CAT requires 30–60 individual 3516s vs. 6 Wärtsilä 50SGs.

**Rolls-Royce Power Systems (mtu).** Series 4000 L64 (2.8 MW, 45-second start); Mankato, MN expansion +120% by 2026 vs. 2024.[32][33] Direct head-to-head with Cat 3516 in 2–3 MW class; strong in EU, growing in US.

**Bloom Energy (BE) — the asymmetric threat.** Solid-oxide fuel cells. AEP $2.65B / 1 GW MSA (Jan 2026); Brookfield $5B AI infrastructure partnership (Oct 2025); Oracle Project Jupiter NM **2.45 GW that explicitly displaced previously-planned gas turbines and diesel gensets**; doubling manufacturing 1→2 GW/yr by end-2026 for ~$100M capex.[34][35][26] Installed cost ~$2.65M/MW vs. ~$0.6–1.2M/MW for gas turbine equipment.[36] Bloom's structural advantages: no NOx permits, no water, modular, faster deployment in permit-hostile jurisdictions (CA, NJ, parts of NY/VA). Disadvantages: 50–55% efficiency vs. 60% combined-cycle gas; capex 2–4× turbine; durability/replacement at multi-GW scale not yet field-proven. **Real displacement risk to CAT inside 36 months in <50 MW BTM where permitting bites.**

**SMRs (Oklo, X-energy, NuScale, TerraPower, Kairos).** Meta locked in **6.6 GW** of nuclear options Dec 2025–Feb 2026 with Vistra/Oklo/TerraPower; Amazon led $500M in X-energy. **Realistic timeline: first-of-a-kind 2028–2030, scale 2030s.**[37][38] **Not a 24-month threat.** Useful for narrative; structurally not a 2026–2028 displacement vector.

**Bottom line:** CAT has share parity with Cummins in 1.5–4 MW recip (duopoly), is structurally advantaged via Solar Turbines vs. GEV/Siemens aero in 25–40 MW because of shorter lead time, is at risk to Wärtsilä at the >12 MW per-unit BTM tier, is at meaningful 36-month risk to Bloom in permit-constrained <50 MW jurisdictions, and is not yet exposed to SMRs.

## Bull case — technical
For CAT to outperform from $904 over 12–24 months, these technical conditions must hold:

1. **Grid interconnect queues remain >5 years in PJM and ERCOT.** This is the single most important condition because BTM gas-genset prime power is, mathematically, the *only* deliverable solution for a 2026–2028 commercial-operation date. FERC Order 2023 implementation has been slow; ERCOT's queue grew ~4× YoY in 2025 even with reform efforts.[5][7] Base rate: queue reform is a multi-year political/operational lift. Probability **high** the bridge demand persists through 2027.
2. **Large-frame turbine backlog (GEV/MHI/Siemens) stays sold out into 2029+.** GEV CEO has guided to "sold out through 2030 by end-2026."[6] This funnels demand into recip gensets and aero-derivatives where CAT plays.
3. **CAT's 3× capacity expansion executes without major slip.** Lafayette completion end-2026; new units shipping 2027+. Sept 2026 – Aug 2027 Monarch deliveries are the real-time stress test. Base rate on industrial capacity expansions: ~70% deliver within 6 months of guidance.
4. **Bloom Energy and other SOFC/fuel-cell entrants do not displace gas at scale before 2028.** Bloom installed cost needs to fall from $2.65M/MW toward $1.5M/MW for hyperscale dominance, and stack longevity at >3-year continuous-duty must be field-proven.
5. **Hyperscaler capex stays at >$300B/yr aggregate through 2027.** Q2 2026 capex commentary from MSFT/AMZN/GOOGL/META is the leading indicator.
6. **Tariff drag stays in line with the $2.2–2.4B FY 2026 guide** (vs. $600M in Q1 2026) — i.e., does not escalate.[39]

If those hold, Power & Energy compounds at 18–25% revenue growth with ~20% margins through 2028, total CAT revenue grows 8–10% (~$80–82B by 2028 vs. ~$70B 2026 run-rate), and EPS reaches $25–28 by 2028 vs. ~$20 trailing. At a 25–30× P/E (still elevated but less stretched), $625–840 fair value. Multiple expansion past today's 36× requires further re-rating as an "AI infrastructure" name, which is possible but not the central case.

**Base rate on technology displacement at this stage of the cycle.** The reference cycles are useful: (i) the **Cisco/Juniper telco buildout 1998–2001** — picks-and-shovels names *kept shipping* for ~18 months past peak optimism because backlogs do not unwind instantly; (ii) the **2008–2014 oil-and-gas E&T cycle** — when shale capex peaked, CAT's E&T orders rolled over with a 4–6 quarter lag and the segment lost ~30% of revenue over 2014–2016; (iii) **2010s wireless infrastructure** — Crown Castle/American Tower kept compounding past peak iPhone demand because tower contracts had multi-year escalators. AI BTM gas equipment is closer to (i) than (iii) because the customer is the offtaker, not the incumbent telco — i.e., the contracts are firm but new orders can stop suddenly.

## Bear case — technical
The honest bear:

1. **Capacity overbuild risk into 2029.** CAT is adding 15 GW/yr of new capacity by 2029. Cummins is expanding 95L. GEV is adding 4 GW. Wärtsilä is shipping 500+ MW chunks. **The OEMs collectively are bringing >25–30 GW/yr of incremental capacity to a market that may peak at ~10–12 GW/yr of true behind-the-meter prime-power demand.** When the bridge demand recedes (because grid catches up, or because hyperscaler training capex peaks), CAT walks into a glut. This is the 2014 oil-cycle pattern and management has lived through it before — the question is whether 2027–2029 is the analogous turn.

2. **Bloom Energy displacement at scale.** Project Jupiter NM (2.45 GW Bloom) explicitly *replaced* previously-planned gas turbines and diesel gensets.[26] If this becomes the template for permit-hostile sub-50 MW deployments and Bloom's $/MW moves toward $1.5M, the addressable BTM gas-genset TAM shrinks 20–30% by 2028.

3. **BTM regulatory backlash.** Methane leakage, NOx permitting, fuel-cycle emissions accounting, and community opposition. Microsoft's WV deal alone could raise its emissions by 40%.[40] If Virginia/West Virginia/Texas tighten air permits or FERC restricts co-location, the deal flow slows materially. Inference, not yet quantified.

4. **AI training-demand inflection.** If frontier scaling laws wall up at GPT-5/Gemini-class compute and inference can be served on existing fleets, hyperscaler capex peaks 2027 instead of 2029. CAT then ships against backlog through 2028 but new orders stop, and the multiple compresses ahead of revenue.

5. **Cummins wins the standardization battle.** If two or more hyperscalers select QSK95 as their reference recip platform (as the trade press is hinting), CAT loses share at the margin even in a growing market.

6. **Multiple compression.** CAT at 36× forward EPS and ~5.5× EV/sales is unprecedented for this name (10-year average forward P/E ~17–19×). If the market re-rates back toward 22–25× — which is what consensus PT $689 essentially prices — even a +15% EPS year produces a flat-to-down stock.

7. **Tariff escalation.** $2.2–2.4B FY 2026 tariff hit guided already. A second-leg-up scenario (e.g., new China retaliation, or US tariffs on Mexican-built large engines) compounds margin pressure.

## Market view check
At $904 (~36× forward EPS, ~5.5× EV/sales, +183% trailing 12-month), CAT is being priced as a secular AI-infrastructure compounder, not a heavy-machinery cyclical. Sell-side consensus PT median $689 implies the analyst community is calling for ~24% downside on a 12-month view — an unusually large gap. The technical reality (record backlog, multi-year customer commitments, 6 GW+ of >1 GW prime-power deals signed, 3× capacity expansion underway, lead-time advantage at Solar Turbines) is consistent with above-trend revenue growth through 2028. But the valuation is pricing in *both* multi-year EPS upside *and* a sustained re-rating to a tech-multiple regime. The market's apparent belief — "CAT is a 30+× P/E AI infrastructure stock for years" — collapses on either (a) an unexpected hyperscaler capex moderation or (b) a successful displacement event from Bloom or GEV aero. Asymmetry is no longer favorable to longs at this entry. The technical thesis is real; the price is rich.

## 90-day falsifiers
Specific, observable events from 2026-05-10 through 2026-08-10 that would update the thesis materially:

1. **Q2 2026 hyperscaler capex calls (late July / early Aug).** A combined 2H 2026 + FY 2027 capex cut >10% sequentially across MSFT/AMZN/GOOGL/META is a yellow flag for CAT order rate by Q4.
2. **CAT Q2 2026 earnings (typically late July/early Aug).** Watch: Power & Energy backlog growth (need to stay >+50% YoY); explicit count of >1 GW prime-power deals (now 6, look for 8+); update on Lafayette completion timing; tariff guide for FY 2026.
3. **Cummins Q2 2026 earnings.** If CMI data-center revenue accelerates faster than CAT's Power Generation line (>40% YoY), evidence Cummins is taking incremental share at the recip standardization point.
4. **GE Vernova Q2 2026 earnings + investor day.** Confirmation backlog hit guided 110 GW combined and aero pricing held — validates the supply-tightness funnel into CAT.
5. **Bloom Energy Q2 2026 earnings.** Specifically: any new GW-scale hyperscaler MSA, and disclosed installed $/MW. If $/MW moves below $2.0M, displacement risk accelerates.
6. **FERC Order 2023 implementation milestones / ERCOT large-load tariff rule.** Any reform that would credibly compress interconnection queue from 5–8 years to 3 years would cap CAT's bridge-demand thesis.
7. **EPA NSPS rule for stationary combustion turbines / RICE-NESHAP update expected mid-2026.** Tighter NOx/methane rules slow gas BTM; looser rules accelerate.
8. **Stargate-related power-equipment OEM disclosures.** OpenAI/Oracle/SoftBank Stargate has not (publicly) named a recip-genset OEM at GW scale. A disclosed CAT or Cummins selection would be material; a Bloom or Wärtsilä selection would shift the thesis.
9. **Any Microsoft / Meta direct-CAT MSA disclosure.** Currently CAT's hyperscaler exposure is through developers (Crusoe-equivalents like AIP, Joule, Nscale). Direct MSA would extend backlog visibility.
10. **3600-series lead-time prints in Raymond James / Morgan Stanley dealer channel checks.** Current ~107 weeks. Movement to >120 weeks confirms further tightness; movement to <90 weeks signals demand softening.

## What I could not verify
- **Solar Turbines revenue and backlog as a standalone line.** CAT consolidates inside Power & Energy and does not break out the subsidiary. All Solar-specific commentary is qualitative from the Q&A or trade press.
- **CAT's market share in hyperscale prime-power gensets vs. Cummins.** No clean third-party share data; competing trade-press claims.
- **Whether the Joule/Monarch/AIP deals are already in the $63B Q1 2026 backlog or partially incremental.** Materially affects the implied book-to-bill.
- **Stargate/Chevron-with-CAT specific deals** mentioned in the original prompt — could not confirm in primary sources. Chevron is building a 2.5 GW gas plant in Pecos, TX (target 2027) but the OEM is not publicly disclosed as CAT.
- **Construction Industries data-center mix percentage.** Inference from Q1 2026 +30% sales growth and management commentary, but no explicit CI data-center disclosure.
- **Fully-loaded LCOE for CAT G3520K BTM prime power vs. Bloom SOFC vs. GEV LM2500XPRESS** over 10-year lifecycle. Existing analyst estimates vary by 30–40% on basic assumptions (heat rate, fuel price, run hours).
- **Whether the Cat 3500/3600 fleet meets the EPA NSPS gas turbine + RICE-NESHAP updates expected mid-2026 without retrofit.** Probable yes (SCR-equipped variants exist) but not confirmed.
- **Cummins and CAT relative pricing for hyperscaler bulk orders.** Both publicly-listed only at retail-list level.
- **Solar Turbines backlog duration directly.** Triangulated from Q3/Q4 2025 transcripts ("extended" lead times) and trade-press 24–36 month estimates, not a CAT-disclosed figure.

## Sources
[1] https://investors.caterpillar.com/news/news-details/2026/American-Intelligence--Power-Forms-Strategic-Alliance-with-Caterpillar-and-Boyd-CAT-to-Deploy-2-Gigawatts-of-Dedicated-Power-for-Hyperscale-AI-Infrastructure/default.aspx — retrieved 2026-05-10 — Caterpillar IR press release (Jan 28, 2026): AIP/Monarch 2 GW G3516 fast-response gas gensets, Sept 2026–Aug 2027 deliveries, Cat Financial vendor financing.
[2] https://s25.q4cdn.com/358376879/files/doc_financials/2025/q4/updated/4Q-2025-Caterpillar-Inc-Earnings-Conference-Call_Transcript.pdf — retrieved 2026-05-10 — Q4 2025 transcript: Creed quotes on Titan 350 ramp, "fastest solution out there" lead-time positioning.
[3] https://www.solarturbines.com/en_US/products/turbine-ratings.html — retrieved 2026-05-10 — Solar Turbines product line ratings (Centaur 40 ~3.5 MW through Titan 350 ~38 MW).
[4] https://www.power-eng.com/onsite-power/caterpillar-engines-to-support-2-gw-of-onsite-power-at-west-virginia-data-center-campus-tied-to-microsoft-nvidia/ — retrieved 2026-05-10 — Power Engineering (Mar 17, 2026): G3500 series at Monarch Compute Campus WV, 2 GW by H1 2028, NVIDIA Vera Rubin DSX reference design.
[5] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — GE Vernova Dec 2025 investor day: 80 GW gas turbine backlog into 2029.
[6] https://www.power-eng.com/gas/turbines/data-centers-drive-record-surge-in-ge-vernova-power-equipment-orders-as-turbine-slots-tighten-through-2030/ — retrieved 2026-05-10 — GEV Q1 2026: 100 GW under contract, sold out through 2030 by end-2026, $2.4B Q1 data-center electrification orders.
[7] https://www.latitudemedia.com/news/ercots-large-load-queue-has-nearly-quadrupled-in-a-single-year/ — retrieved 2026-05-10 — ERCOT large-load queue 226–233 GW year-end 2025, +4× YoY, data centers >70%.
[8] https://www.marketbeat.com/stocks/NYSE/CAT/forecast/ — retrieved 2026-05-10 — CAT close $904.59 May 5 2026, ATH $931.35 May 7 2026, market cap ~$362–368B, 52-week range $323.31–$931.35, consensus PT $689 median (37 analysts).
[9] https://www.gurufocus.com/term/forward-pe-ratio/CAT — retrieved 2026-05-10 — Forward P/E 36.6× vs. industry median 14.2×.
[10] https://www.fool.com/earnings/call-transcripts/2026/04/30/caterpillar-cat-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1 2026 earnings transcript: $17.4B revenue, $5.54 EPS, $63B backlog, "3.5x" recip backlog growth quote.
[11] https://stockanalysis.com/stocks/cat/statistics/ — retrieved 2026-05-10 — CAT EV/EBITDA 32×, debt/equity 2.31, derived EV/NTM revenue ~5.3–5.6×.
[12] https://stockanalysis.com/stocks/cat/forecast/ — retrieved 2026-05-10 — Analyst 12-month PT distribution: high $1,165, low $575, mean $890 across panel.
[13] https://www.tikr.com/blog/caterpillar-stock-is-up-32-in-2026-heres-what-a-935-valuation-says-now — retrieved 2026-05-10 — CAT YTD +32%, 1-year +183–192%.
[14] https://www.marketbeat.com/stocks/NYSE/CAT/short-interest/ — retrieved 2026-05-10 — Short interest 1.65–2.13% of float, peer group 4.85%.
[15] https://www.caterpillar.com/en/news/corporate-press-releases/h/lafayette-large-engine-expansion.html — retrieved 2026-05-10 — Lafayette IN $725M capacity expansion announced Oct 2025.
[16] https://www.manufacturingdive.com/news/caterpillar-triple-power-generation-capacity-raises-2030-targets-q1-2026-earnings/819078/ — retrieved 2026-05-10 — CAT Q1 2026: 3× 2024 large recip engine capacity, +15 GW/yr, capex 4–5% of MP&E sales through 2030.
[17] https://www.cummins.com/news/releases/2026/02/05/cummins-reports-strong-fourth-quarter-and-full-year-2025-results-records — retrieved 2026-05-10 — Cummins FY2025: $7.5B Power Systems, +16%, 22.7% EBITDA, doubled 95L capacity, $150M Fridley MN expansion.
[18] https://www.industrialmarinepower.com/titan-350--35-mw/ — retrieved 2026-05-10 — Solar Titan 350 specs and trade-press lead-time context (24–36 mo industrial vs. 5–7 yr large frame).
[19] https://www.caterpillar.com/en/company/global-footprint/dealers.html — retrieved 2026-05-10 — Cat dealer network footprint context.
[20] https://www.caterpillar.com/en/news/corporate-press-releases/h/joule-caterpillar-wheeler.html — retrieved 2026-05-10 — Joule/CAT/Wheeler 4 GW G3520K Utah deal (Aug 7, 2025) with 1.1 GWh BESS.
[21] https://www.caterpillar.com/en/news/corporate-press-releases/h/vertiv-caterpillar-collaboration.html — retrieved 2026-05-10 — Vertiv-CAT MOU (Nov 18, 2025) for AI data-center reference architecture.
[22] https://www.gevernova.com/news/press-releases/ge-vernova-crusoe-announce-major-29-unit-aeroderivative-gas-turbine-deliver-ai-data-centers — retrieved 2026-05-10 — GEV-Crusoe 29 LM2500XPRESS units (~1 GW).
[23] https://www.utilitydive.com/news/mitsubishi-gas-turbine-manufacturing-capacity-expansion-supply-demand/759371/ — retrieved 2026-05-10 — Mitsubishi Power doubling production over 2 years.
[24] https://www.investing.com/news/analyst-ratings/caterpillar-engine-lead-times-extend-as-data-center-demand-surges-93CH-4435497 — retrieved 2026-05-10 — Raymond James (Jan 7, 2026): Cat 3600 lead time ~107 weeks, +20 weeks since mid-Sept 2025.
[25] https://www.wartsila.com/media/news/20-11-2025-wartsila-continues-growth-in-the-data-center-segment-with-a-507-mw-order-in-the-us-offering-engines-as-a-reliable-power-solution-3686573 — retrieved 2026-05-10 — Wärtsilä 507 MW US BTM data-center order (Nov 20, 2025), 27× 50SG, 2027 delivery.
[26] https://www.datacenterdynamics.com/en/news/oracle-to-deploy-up-to-245gw-of-bloom-fuel-cells-at-new-mexico-data-center/ — retrieved 2026-05-10 — Oracle Project Jupiter NM 2.45 GW Bloom SOFC explicitly displacing planned gas turbines + diesel gensets.
[27] https://www.cummins.com/en-na/generators/data-centers — retrieved 2026-05-10 — Cummins data-center genset positioning (Centum, QSK95).
[28] https://www.tikr.com/blog/cummins-stock-has-nearly-doubled-in-a-year-is-the-data-center-rally-fully-priced — retrieved 2026-05-10 — Cummins data-center revenue $3.5B 2025, backlog into 2028.
[29] https://www.power-eng.com/gas/turbines/data-centers-drive-record-surge-in-ge-vernova-power-equipment-orders-as-turbine-slots-tighten-through-2030/ — retrieved 2026-05-10 — GEV pricing momentum +10–20% Q-on-Q; Wood Mackenzie $600/kW projection by end-2027.
[30] https://www.power-eng.com/gas/turbines/mitsubishi-power-m501jac-gas-turbine-will-be-first-in-u-s-to-operate-in-simple-cycle/ — retrieved 2026-05-10 — Mitsubishi M501JAC first US simple-cycle deployment.
[31] https://www.siemens-energy.com/global/en/home/press-releases/earnings-release-q4-fy-2025.html — retrieved 2026-05-10 — Siemens Energy €146B backlog, gas turbine market shares (#1 >10 MW, #2 >100 MW), 100→194 turbines sold YoY.
[32] https://www.rolls-royce.com/media/press-releases/2025/02-10-2025-rr-introduces-fast-start-mtu-gas-gensets-for-powering-data-centers.aspx — retrieved 2026-05-10 — mtu Series 4000 L64 fast-start variant for data centers.
[33] https://www.rolls-royce.com/media/press-releases/2025/03-06-2025-rr-powers-data-center-growth-with-increased-investment-in-us-manufacturing.aspx — retrieved 2026-05-10 — Mankato, MN +120% mtu output by 2026 vs. 2024.
[34] https://www.utilitydive.com/news/aep-bloom-energy-fuel-cell-data-center/733150/ — retrieved 2026-05-10 — AEP-Bloom $2.65B / 1 GW MSA.
[35] https://www.datacenterdynamics.com/en/news/bloom-energy-signs-5bn-partnership-with-brookfield-to-deploy-fuel-cell-tech-across-ai-data-centers/ — retrieved 2026-05-10 — Brookfield-Bloom $5B AI data-center SOFC partnership (Oct 2025).
[36] https://enkiai.com/data-center/bloom-energy-fuel-cell-2026-2-8-gw-oracle-agreement/ — retrieved 2026-05-10 — Bloom installed cost ~$2.65M/MW vs. gas turbine ~$0.6–1.2M/MW context.
[37] https://www.utilitydive.com/news/meta-nuclear-deal-oklo-vistra-terrapower-ai-data-centers/809215/ — retrieved 2026-05-10 — Meta 6.6 GW nuclear options (Oklo, TerraPower, Vistra), first phases 2030–2032.
[38] https://www.tonygraysonvet.com/post/nuclear-power-for-ai-datacenters — retrieved 2026-05-10 — Realistic SMR timeline analysis (first-of-a-kind 2028–2030, scale 2030s).
[39] https://www.caterpillar.com/content/dam/caterpillarDotCom/releases/4q25/4q25-caterpillar-inc-financial-results.pdf — retrieved 2026-05-10 — CAT Q4 2025 financial results: Power & Energy segment trajectory, FY 2026 tariff guide $2.2–2.4B.
[40] https://www.distilled.earth/p/microsofts-latest-data-center-project — retrieved 2026-05-10 — Microsoft WV BTM project potential +40% emissions impact.