# STX — Seagate Technology Holdings plc

## Where this sits in the AI stack
STX is the largest of the three remaining HDD vendors and the only one shipping HAMR (heat-assisted magnetic recording) at scale into hyperscale data centers. Physically it sells 3.5-inch nearline drives — currently the Mozaic 4+ platform at 44 TB per drive — that form the **capacity tier** beneath AI training and serving stacks: training-set raw corpora, checkpoints aged past the hot window, multimedia object stores, log/telemetry archives, and the warm tier of S3-compatible object stores under model pipelines. It is not in the GPU, HBM, optical, or scale-out fabric path; it sits behind those, under software-defined storage layers (S3, GCS, Tectonic, Colossus) consumed by AI workloads.[1][2][3]

## Snapshot
- **Price:** $782.64 (2026-05-08 close; 2026-05-10 is a Sunday)[4]
- **Market cap:** ~$175.5B (≈224M shares outstanding)[4][5]
- **52-week range:** $94.97 – $802.13[4]
- **Forward P/E:** ~33× (on FY26 EPS run-rate; Q3 FY26 non-GAAP EPS $4.10, Q4 guide $5.00 ±$0.20)[1][4]
- **EV / NTM revenue:** ~12–13× (on $13–14B NTM revenue; net debt ~0.7× leverage on ~$1.4B trailing EBITDA — minor adjustment to mkt cap)[1][4]
- **Consensus 12-month price target:** ranges widely post-Q3 print — Morgan Stanley/Wedbush style targets $615–$875; older medians remain $468–$634; this dispersion itself is a signal that sell-side has not yet converged[5][6]
- **YTD total return:** approximately +250–300% (stock came off a low near $95 inside the last 12 months)[4]
- **Short interest (% of float):** 3.77% (~8.4M shares)[7]

## Moat — what it is physically made of

The moat is **not "CUDA-style" software lock-in**; it's a thin manufacturing and IP advantage measured in calendar quarters, sitting on top of a much wider structural cost-per-TB moat that the entire HDD industry holds versus NAND.

**1. Heat-assisted magnetic recording (HAMR) — the company-specific edge.**
HAMR writes by transiently heating an FePt media grain above its Curie point (~700 °C) via a plasmonic near-field transducer (NFT) integrated into the recording head, then writing while the local region cools through anisotropy collapse. This lets Seagate use much smaller (~4–5 nm), much higher anisotropy (L10-ordered FePt) grains than perpendicular magnetic recording (PMR) tolerates — the actual physical knob that lifts areal density past the PMR superparamagnetic wall.[8][9]

What is moat-grade about Seagate's specific HAMR implementation:

- **Vertically integrated photonics.** Seagate designs and fabricates the NFT and the on-head laser in-house. The company states it has built >25M plasmonic NFTs across the development program, started in the late 2000s — a sub-50 nm plasmonic optic with reliability targets at billions of write cycles is not a part you can order from a catalogue.[9][10]
- **L10-FePt media via Resonac (formerly Showa Denko) partnership.** HAMR-grade glass substrates with epitaxial L10-FePt films were jointly developed with Showa Denko under a 2021 agreement. Resonac and HOYA (glass substrates) are effectively the entire credible external media supply chain. WDC sources glass primarily via the Hoya media operations it acquired in 2019, but the L10-FePt sputter process at HAMR-grade quality is reportedly later-stage at WDC's media partners than at Resonac for Seagate.[10][11]
- **Calendar lead over WDC.** Seagate is shipping qualified 44 TB drives to two hyperscalers; WDC's first HAMR drive (36 TB CMR / 44 TB UltraSMR) is targeted for late-2026 qualification with volume in 1H27. That is a ~12–18 month head start in customer qualification cycles — a long time when hyperscale BTO contracts run through CY27.[12][1][13]
- **Architectural choice.** Seagate uses a 10-platter mechanical stack and scales capacity primarily via areal density. WDC plans up to 14 platters and a dual-actuator design to bridge to HAMR. Seagate's Jason Feist publicly framed platter-count escalation as a tell that the competitor "has hit a density wall" — and the cost-per-platter argument is real: extra platters add head/arm/disk material cost and don't help lower-tier SKUs.[14]

**2. The wider structural moat shared by the HDD oligopoly.**
HDD manufacturing is a three-vendor concentrated capital base (Seagate, WDC, Toshiba). Combined HDD capex over the last decade has run *below* depreciation in several years. New head-wafer fabs cost billions; no greenfield entrant is credible on a 5-year horizon. Seagate's HAMR head wafer fab in Bloomington/Minnetonka and Northern Ireland thin-film lines are the bottleneck — the IP is patented (Seagate holds thousands of granted patents around HAMR media, NFT design, and write head architecture; exact count not verified at the SKU level), but the physical capacity to make heads is itself a moat.[3][11]

**3. Customer lock-in via build-to-order (BTO).**
This is the more interesting recent moat layer. Seagate has flipped its commercial model from spot/PO to multi-quarter BTO contracts with nearly all major CSPs — pricing, capacity, and configuration locked through CY27. This both (a) gives revenue visibility through fiscal 2027 and (b) crowds out competitors who would have to dislodge a contracted slot, not just be cheaper on a spot bid.[1][15][16]

**Durability of each piece:**
- HAMR lead over WDC: durable for ~18–24 months from today; **erodes** as WDC's HAMR qualifies (2H26 → 1H27).
- FePt/laser/NFT manufacturing know-how: durable beyond 5 years — process and yield secrets are hard to transfer.
- BTO contract coverage: durable through CY27 mechanically; renewable depending on technology cadence into CY28.
- HDD-vs-flash $/TB advantage: durable for the foreseeable future at hyperscale capacity tier (see Bottleneck Map and Competitive Teardown).

## AI buildout bottleneck map

Where STX sits against each gating constraint over the next 24 months:

| Bottleneck | STX position |
|---|---|
| Power generation / grid interconnect | **Indifferent** — HDD power draw is a rounding error vs GPU racks (a 44 TB drive at idle ~5W; an exabyte of HDD ~110 kW vs an H200 rack at ~100 kW). |
| CoWoS-L advanced packaging | **Indifferent.** No silicon exposure. |
| HBM3e/HBM4 yield | **Indifferent.** |
| Optical interconnect / co-packaged optics | **Indifferent.** |
| Liquid cooling at >100 kW/rack | **Indifferent.** HDDs run air-cooled. |
| NAND wafer supply | **Beneficiary.** Coordinated NAND output cuts (2H25), Samsung pricing 20–30% YoY higher into 2026, Kioxia 2026 wafer volume sold out, and Q1-2026 contract NAND +55–60% q/q with TrendForce forecasting +70–75% in Q2 — every dollar that QLC SSD $/TB doesn't come down is a dollar that pushes capacity-tier workloads back onto Seagate.[17][18][19] |
| Training-data quality (frontier) | **Beneficiary** indirectly. As frontier labs hoard data (raw video, audio, simulation rollouts), the warm and cold corpus expands; that corpus lands on HDD, not flash. |
| HAMR media & laser supply | **Constraint owner.** Resonac FePt media capacity and Seagate's own head-wafer/laser capacity are the gating items inside the HDD industry; capacity is the reason nearline is sold out through CY27.[1][11] |
| Hyperscaler capex (~$725B 2026, ~$450B AI-specific) | **Customer-exposed.** Direct levered exposure: top-3 CSP combined RPO doubled to ~$1.1T (per Seagate's Q3 call), but if hyperscale capex re-rates lower, BTO renewal economics for FY28 weaken.[1][20] |
| Electrical contractor capacity / racks | **Indifferent** for STX directly; relevant only as a determinant of how fast hyperscale shells fill, which determines drive intake. |

## Competitive teardown

**Western Digital (WDC).** The only direct nearline HDD competitor. WDC's strategy is the more conservative hedge: push ePMR with platter-count escalation (up to 14 platters) and UltraSMR to ~40–60 TB while qualifying HAMR for late 2026 / volume 1H27.[12][13][16] On the **areal-density axis** Seagate is unambiguously ahead — 4 TB/platter (Mozaic 4+) vs WDC ePMR ~3.2 TB/platter; on **drive-level capacity** parity is roughly arriving in late 2026 (both reach ~44 TB) but only because WDC is stacking more platters. On **shipped HAMR exabytes** Seagate has effectively 100% of HAMR market share today; WDC has none in volume. Two things would have to be true for WDC to take material share: (1) its HAMR drives need to qualify on time and at parity yield at both AWS and one of {GCP, Azure, Meta} before mid-2027, and (2) Seagate would need to lose a contracted CY27 BTO slot, which mechanically only happens if it under-delivers on units. The base case is that WDC catches **technical** parity by mid-2027 and contract parity by FY28 renewals.

**Toshiba (Kioxia is the unrelated NAND co; HDD division is separate Toshiba electronic devices).** ~5–7% share. FC-MAMR-first strategy, HAMR-as-test-vehicle through 2026–27. Will not be a competitive threat at frontier capacity tier in the 24-month window — they ship later, in lower volume, and don't have hyperscale exabyte-scale BTOs.[21][14]

**QLC NAND SSDs (Solidigm, Micron 6600 ION 245 TB, Samsung BM1743, Kioxia/SanDisk LC9).** The actual "displacement" risk. The technical reality today:
- Cost: Enterprise QLC SSD is still 5–7× $/TB of HAMR HDD (HDD raw $/TB ~$10–15 wholesale, QLC SSD $/TB ~$60–80 even with NAND price increases pushing them higher, not lower).[22][23]
- Power: Vendor pitch is QLC delivers ~8 TB/W vs ~3.4–4.4 TB/W for HDD — true for read-heavy workloads at low duty cycle. Independent analysis (Scality) finds HDD wins by ~19% on read and ~94% on write power density at hyperscale-real workloads because NAND write power dominates. Net: power is workload-dependent, not a universal SSD win.[24][22][23]
- Supply: 2026 NAND wafer supply is sold out (Kioxia, SanDisk explicit). Even if you *wanted* to displace HDD at hyperscale capacity tier, the wafers aren't there.[17][18]
- The Meta engineering blog argument for QLC in the data center is real but bounded — it targets warm tiers where IO patterns favor flash; the cold/capacity tier remains HDD.[25]

Net: QLC SSD takes some workloads at the warm tier on the margin, especially as 245TB/300TB+ SSD SKUs land in 2H26–27, but no axis (cost, supply, power) supports a >10-percentage-point share shift at the capacity tier inside 24 months.

## Bull case — technical

For STX to materially outperform from here, the following technical conditions need to hold:

1. **HAMR ramp on plan.** Mozaic 4+ takes >50% of nearline exabytes by year-end 2026 (management says HAMR exabytes "dominant by late 2026" and Mozaic 4 specifically ~70% of nearline HAMR exabytes by end-FY27). Mozaic 5 (50 TB) qualification samples ship late 2027. Yield on the laser/NFT stack stays >90% through volume ramp (unverified specific number; **inference**: Seagate calling out vertically integrated yield improvements implies it's the binding metric they track).[1]
2. **ASP/TB stays flat-to-up.** Historically HDD $/TB declined ~15%/yr. In Q3 FY26 data center revenue per TB grew **mid-single digits YoY** — a structural break.[1] If areal density growth (capacity per drive) outpaces $/drive growth, gross margin keeps walking up from 47% toward 50%+.
3. **WDC HAMR slips by another 1–2 quarters** or qualifies at lower density/yield. Each quarter of WDC delay extends Seagate's BTO renewal pricing power.
4. **NAND supply stays tight through 2027.** Continued QLC wafer scarcity keeps capacity-tier workloads from leaking to flash even at the warm edge.
5. **Hyperscaler capex curve doesn't roll over before FY28 contract renewals.**

Financial outcome under bull: FY27 revenue ~$15–16B (vs FY26 ~$13B run-rate), gross margin 49–50%, EPS in the high-$20s, FCF $4.5–5B/yr. At a 25× P/E that's a $700–$800+ stock; at 20× a $550–$650 stock. The price already largely reflects the bull case.

**Base rate caveat.** Technology displacement of incumbent commodity storage tiers is slow. The HDD-to-SSD "client" transition (consumer laptops) took ~10–12 years and was driven by latency, not $/TB. The capacity-tier displacement clock is not yet ticking at hyperscale because the $/TB gap is wider than the client gap was. Cycles of "this is the year HDD dies" date to 2014; HDD industry exabytes are at record highs.[26][22]

## Bear case — technical

The short-seller-who-understands-the-stack version:

1. **HAMR is not yet a "20-year drive."** PMR drive AFR (annualized failure rate) under hyperscale duty cycles took a decade of process maturation to reach ~0.5%. HAMR write heads experience repeated thermal cycling of an NFT at ~700°C local heating; long-term NFT recession/degradation and laser diode life under realistic 24/7 duty are the open reliability question.[8][9] If a hyperscaler reports elevated AFR on Mozaic 3/4 fleet drives after 18–24 months in service, the qualification posture across the industry hardens fast, and Seagate may lose volume share even with a technology lead. **I could not verify** an independent post-deployment AFR number for HAMR; this is the single biggest technical unknown.
2. **WDC HAMR comes in faster than expected.** WDC has shifted resources aggressively after acquiring Hoya media operations and benefits from observing Seagate's deployment issues. If WDC qualifies a 44 TB HAMR drive at AWS or Meta in CY26 (vs management plan of mid-CY27), Seagate's contract pricing power for FY28 BTO renewals compresses, and the 47% gross margin re-rates back toward 35–38%.
3. **NAND price cycle reverses.** NAND historically cycles 18–24 months. If Samsung/Micron/Kioxia restart aggressive bit growth in 2H27, QLC $/TB could halve. Combined with 245→300+ TB SSD SKUs, the warm-tier shift accelerates. Even ~10–15 percentage points of nearline exabytes shifting to flash would meaningfully derate STX revenue.
4. **Hyperscaler capex re-rates lower.** ~$725B is a number that has only existed for one cycle. A genuine post-training compute slowdown (e.g., if inference-only workloads dominate and training fleet utilization peaks) cuts the rate of *new* exabyte intake more sharply than it cuts compute, because storage scales with corpus more than with FLOPs. Storage capex is also the *easiest* line to defer in any AI capex retrenchment.
5. **Multiple compression.** STX is trading at ~33× forward, ~13× EV/sales — historically the median has been 6–10× forward earnings for the cycle. Even if the technology thesis holds, a single ASP guide-down or qualification slip could compress to 15–20× forward, ~40% downside from $782 absent earnings growth.

## Market view check

The price has run from ~$95 to ~$782 inside 12 months — an 8× move. The market is implicitly pricing in (i) HAMR exabyte dominance, (ii) ASP/TB inflation continuing, (iii) BTO renewals through FY28 at favorable terms, and (iv) NAND remaining structurally tight. That stack-up is **directionally consistent** with what the technical evidence supports for the next 24 months, but it removes margin of safety for any single leg breaking. The dispersion in sell-side targets ($468 to $875) is itself evidence that even bulls and bears agree the technical thesis is broadly right but disagree by 80% on what to capitalize for. The stock is not "wrong"; it is fully valued on the bull base case, with the asymmetry now mildly skewed to downside — you are paying for execution-on-plan and an unbroken capex cycle. Disagreement with the market would need to be on durability past FY27, not on the 24-month picture.

## 90-day falsifiers

Observable events that would materially update the thesis through August 2026:

1. **WDC Q3 CY26 earnings (early August 2026)** — any hyperscaler HAMR qualification announcement, or guide for HAMR volume into 1H27 above current expectations. Falsifies the "WDC stays a year behind" leg.
2. **Seagate fiscal Q4 print (late July 2026)** — actual vs $3.45B revenue / $5.00 EPS guide. A miss on units (rather than ASP) would suggest HAMR yield wall; a miss on ASP would suggest contract pricing softness.
3. **NAND contract price prints (Q2-26 and Q3-26 TrendForce/DRAMeXchange data)** — if NAND contract prices flatten or decline q/q (rather than the +70–75% Q2 forecast), the QLC SSD displacement risk to capacity tier ticks up.
4. **Hyperscaler July/August capex updates** — AWS, Meta, Microsoft, Google. A sequential capex guide cut of >10% from any of the top 4 would re-rate the entire AI capex thesis and STX with it.
5. **Mozaic 5 (50 TB) sampling timing** — management currently says "qualification shipments late 2027." Any pull-in or push-out announced at Q4 call extends or compresses the visible HAMR cadence advantage.
6. **Public field-failure data on Mozaic 3/4 HAMR drives** — Backblaze drive-stats releases (quarterly) or any hyperscaler disclosure of HAMR AFR. The first 24-month-on-deployment data point is in 2026 for some early Mozaic 3 fleets.

## What I could not verify

- **HAMR field AFR / NFT lifetime in production.** No independent multi-quarter deployment data published; Backblaze Q1-2026 drive stats had not yet aggregated meaningful HAMR populations.
- **Seagate's HAMR head-wafer fab effective capacity** in exabytes/quarter at current yield — Seagate gives unit and exabyte ship numbers but not absolute capacity ceilings.
- **Resonac L10-FePt media capacity** in disks/year and its allocation split between Seagate, WDC partners, and Toshiba.
- **WDC HAMR media yield** at its internal/Hoya line, beyond press-stated 2H26 qualification timeline.
- **Exact NFT yield** at the head wafer step (Seagate cites integrated improvements; absolute number not disclosed).
- **Specific patent count and patent strength** around HAMR write heads, plasmonic NFT, and FePt media — Seagate has thousands of issued patents but the relevant subset and overlap with WDC's portfolio (which includes the legacy Hitachi/HGST stack) is not characterized in public disclosure.
- **Stock-level YTD return** precisely (estimated ~+250–300% from year-end 2025 to 2026-05-08 based on price history; not pulled from a single canonical YTD source).
- **Consensus 12-month price target convergence** — sell-side has not yet recut models post-blowout Q3; the published range $468–$875 is wide enough to be effectively non-informative.

## Sources

[1] https://www.fool.com/earnings/call-transcripts/2026/04/28/seagate-stx-q3-2026-earnings-transcript/ — retrieved 2026-05-10 — Q3 FY2026 transcript; HAMR ramp, BTO through CY27, Mozaic 5 timing, RPO commentary, $3.1B revenue, 47% GM.
[2] https://www.seagate.com/blog/why-hdds-dominate-hyperscale-cloud-architecture/ — retrieved 2026-05-10 — Seagate's framing of capacity-tier role in cloud architecture.
[3] https://www.seagate.com/innovation/mozaic/ — retrieved 2026-05-10 — Mozaic platform spec, 4+ TB/disk and 10-disk architecture, 44 TB drive.
[4] https://stockanalysis.com/stocks/stx/ — retrieved 2026-05-10 — price $782.64 (2026-05-08), mkt cap $175.49B, P/E 74, fwd P/E 33, 52w range $94.97–$802.13.
[5] https://www.marketbeat.com/stocks/NASDAQ/STX/forecast/ — retrieved 2026-05-10 — analyst price target dispersion.
[6] https://tickernerd.com/stock/stx-forecast/ — retrieved 2026-05-10 — post-Q3 PT updates from Morgan Stanley/Wedbush range.
[7] https://www.nasdaq.com/market-activity/stocks/stx/short-interest — retrieved 2026-05-10 — 8.44M shares short, 3.77% of float.
[8] https://en.wikipedia.org/wiki/Heat-assisted_magnetic_recording — retrieved 2026-05-10 — HAMR principles, NFT, FePt L10 media, Curie-point write physics.
[9] https://www.seagate.com/www-content/ti-dm/tech-insights/en-us/docs/TP707-1-1712US_HAMR.pdf — retrieved 2026-05-10 — Seagate's HAMR technical brief; NFT count (>25M built during program), 15-yr development.
[10] https://www.resonac.com/news/2021/06/10/1133.html — retrieved 2026-05-10 — Showa Denko / Seagate joint HAMR media development agreement.
[11] https://www.anandtech.com/show/16755/seagate-signs-hamr-deal-with-showa-denko-secures-second-source-for-hamr-platters — retrieved 2026-05-10 — second-source HAMR media supply structure.
[12] https://www.tomshardware.com/pc-components/hdds/western-digital-to-unveil-44tb-hamr-hdds-in-2026-100tb-in-2030 — retrieved 2026-05-10 — WDC HAMR roadmap, 44TB UltraSMR HAMR late-CY26 qual, 1H27 volume.
[13] https://www.tomshardware.com/pc-components/hdds/wd-innovation-day-2026-press-q-and-a-transcript-roadmap-plans-to-reach-60tb-with-epmr-and-100tb-via-hamr-by-2029-at-some-point-the-laws-of-physics-will-require-us-to-transition-to-hamr — retrieved 2026-05-10 — WDC roadmap to 60TB ePMR + HAMR transition language.
[14] https://www.blocksandfiles.com/disk/2026/03/25/seagate-if-youre-adding-platters-youve-hit-a-density-wall/5211295 — retrieved 2026-05-10 — Seagate (Feist) critique of platter-stack strategy.
[15] https://www.trendforce.com/news/2026/01/28/news-seagate-q3-guidance-tops-estimates-nearline-hdd-capacity-fully-booked-through-2026/ — retrieved 2026-05-10 — sold-out through 2026, allocation through 2027.
[16] https://www.tomshardware.com/pc-components/hdds/high-capacity-hdd-roadmap-the-race-to-100tb-and-zettabyte-scale-storage-toshiba-seagate-and-wd-outline-three-distinct-strategies — retrieved 2026-05-10 — three-vendor roadmap comparison.
[17] https://www.pcgamer.com/hardware/ssds/memory-manufacturer-kioxia-reveals-its-entire-nand-flash-production-volume-for-2026-is-already-sold-out/ — retrieved 2026-05-10 — Kioxia 2026 NAND sold out.
[18] https://www.trendforce.com/news/2025/11/13/news-nand-giants-reportedly-cut-output-in-2h25-as-prices-surge-samsung-mulls-20-30-hike-in-2026/ — retrieved 2026-05-10 — NAND output cuts, Samsung 20–30% price hike.
[19] https://www.kucoin.com/news/flash/nand-flash-prices-surge-130-in-four-months-amid-ai-demand — retrieved 2026-05-10 — NAND price action 2025-26.
[20] https://alcapitaladvisory.com/research/intelligence/ai-infrastructure.html — retrieved 2026-05-10 — hyperscaler capex ~$725B 2026 / ~$450B AI-specific.
[21] https://www.techradar.com/pro/toshiba-wants-to-launch-a-55tb-hard-drive-by-2030-40tb-model-set-to-appear-in-2026-new-slides-show — retrieved 2026-05-10 — Toshiba FC-MAMR + HAMR roadmap.
[22] https://www.solved.scality.com/high-density-power-consumption-hdd-vs-qlc-flash/ — retrieved 2026-05-10 — Scality independent HDD vs QLC SSD power analysis, write power dominance.
[23] https://horizontechnology.com/news/data-storage-tco-at-scale-hdd-vs-flash/ — retrieved 2026-05-10 — TCO comparison, HDD $20–25/TB vs enterprise QLC SSD 5–7× higher.
[24] https://www.solidigm.com/products/technology/power-efficient-ai-data-center-with-solidigm-qlc-ssds.html — retrieved 2026-05-10 — vendor (Solidigm) QLC efficiency claim, 4.88 TB/W reference.
[25] https://engineering.fb.com/2025/03/04/data-center-engineering/a-case-for-qlc-ssds-in-the-data-center/ — retrieved 2026-05-10 — Meta engineering on QLC in warm tier, not capacity tier displacement.
[26] https://www.tomshardware.com/pc-components/hdds/seagate-begins-shipping-44tb-hard-drives-with-hamr-tech-to-data-centers-mozaic-4-platform-expands-to-10-platters — retrieved 2026-05-10 — 44 TB Mozaic 4+ commercial shipment confirmation.