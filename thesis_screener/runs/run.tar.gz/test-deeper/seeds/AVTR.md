I have sufficient material. Drafting the dossier now — honestly framing AVTR as a life sciences supply name (not an AI infrastructure play), with technical depth on its actual substrate (chromatography resins, single-use bioprocessing, NuSil silicones, lab distribution).

# AVTR — Avantor, Inc.

## Where this sits in the AI stack

Avantor does not sit in the AI stack in any meaningful way, and I will not pretend otherwise. AVTR is a life-sciences supply chain company across two re-named segments [1][9]: (1) **VWR Distribution & Services** (~$4.7B / ~70% of revenue) — a "one-stop" lab procurement channel for consumables, equipment, reagents, and services to >300k customer sites in biopharma, academic, government and industrial labs [3][14]; and (2) **Bioscience & Medtech Products (BMP)** (~$2.3B) — proprietary high-purity process chemicals, chromatography resins (J.T. Baker BAKERBOND PROchievA Protein A) [11], single-use bioprocessing bags/assemblies, GMP excipients, and medical-grade silicones (NuSil) [13]. There is one tangential AI-adjacent sliver — Avantor's Macron / J.T. Baker high-purity acids, solvents and electronic-grade chemicals are sold into semiconductor fabs and photovoltaic/flat-panel manufacturers from Phillipsburg, NJ and Paris, KY [21]. That slice is small, undisclosed-as-percent, and at the bulk-chemicals layer of the fab supply chain (wet chemistry consumables, not lithography, EUV resists, HBM, advanced packaging or interconnect). Treating AVTR as an AI play is a category error; the real thesis is a deeply discounted, post-destocking, activist-pressured biopharma-tools turnaround under a new operator who ran the dominant competitor.

## Snapshot

- **Price:** $8.31 (2026-05-08 close) [2]
- **Market cap:** $5.67B [2]
- **52-week range:** $7.27 – $15.93 [2]
- **Forward P/E:** ~9.8× on consensus FY26 EPS $0.85; ~10.4× on company guidance midpoint $0.77–$0.83 [2][8]
- **EV / NTM revenue:** ~1.4× ($5.67B equity + $3.60B net debt) / ~$6.6B NTM revenue [18][20]
- **EV / TTM adj. EBITDA:** ~8.5× ($9.3B EV / ~$1.09B implied from 3.3× net leverage) [18]
- **Consensus 12-month price target:** $12.89 (avg of 14 analysts; +55% from spot) [2]
- **YTD total return:** approximately -30% (inferred from 52w -44% and timing of decline; not a clean YTD-2026 figure)
- **Short interest:** 4.36% of float (29.6M shares; below peer-group avg 5.17%) [23]
- **Net leverage:** 3.3× adj. EBITDA, $3.60B net debt as of 3/31/26 [18]

## Moat — what it is physically made of

The "moat" decomposes into four very different pieces with very different durability. Don't average them.

**1. Regulatory specification lock-in in BMP (the real moat).** Avantor states it is "specified into 85% of the top 20 commercial biologic therapies" [3]. The mechanism is that when a biologic is filed with FDA/EMA, the supplier of a high-purity process chemical, excipient, buffer or chromatography resin is named in the regulatory dossier and Drug Master File. Switching that supplier on a commercial biologic is not a procurement decision — it requires comparability studies, regulatory variation filings, and (depending on jurisdiction and material classification) potentially clinical bridging, often 12–36 months of work. This is a genuine, durable, multi-year switching cost on the **installed base** of approved drugs. It does not protect new-program wins, where Avantor competes head-to-head with Cytiva, MilliporeSigma, Sartorius and Thermo Fisher.

**2. NuSil medical/space-grade silicones (durable niche).** NuSil is the global leader in implant-grade and space-rated silicones — used in pacemakers, cochlear implants, breast implants, drug-delivery devices and aerospace applications [13]. The moat here is real: ISO 10993 biocompatibility files, decades of implant clinical history, FDA Master Files, and qualification cycles measured in years. There is no obvious challenger of comparable depth in the medical-grade silicone niche. This is small (probably <10% of revenue, undisclosed) but high-margin and structurally protected.

**3. J.T. Baker / Macron high-purity chemistry (mid-durable).** Baker-grade reagents and Macron solvents have ~120 years of brand equity in HPLC, electrochemistry and analytical wet labs [3][21]. Purity grades (e.g., "Baker Analyzed") and lot-to-lot consistency get specified in customer methods. Switching costs exist (revalidation of analytical methods) but are lower than DMF-locked process chemicals. MilliporeSigma's Sigma-Aldrich is the equal-or-superior competitor and Thermo Fisher's Fisher Chemical brand is comparable.

**4. VWR distribution scale (the weakest moat — possibly an anti-moat).** VWR is the **#3** lab distributor behind Thermo Fisher's Fisher Scientific and MilliporeSigma [3][14]. In a 3-player oligopoly with a clear scale leader, #3 is structurally disadvantaged: same fixed-cost SKU breadth, lower volume to amortize across, weaker private-label leverage, weaker logistics density. Thermo Fisher's $40B+ revenue base and 500k customer locations [analyst aggregations] mean it amortizes catalog, e-procurement integration and logistics across more volume. Avantor's segment EBITDA margins around the low teens, vs. life-sciences-tools peers' high-teens-to-low-20s, are consistent with this. This segment is ~70% of revenue and the lowest-quality piece of the company.

**Bottom line on moat:** real and durable in BMP and NuSil, mid-durable in J.T. Baker/Macron specialty, structurally weak in VWR distribution. The market currently appears to be valuing the whole company at the weakest piece's quality. If the BMP and NuSil pieces could be cleanly separated (Engine Capital's implicit thesis [7]), the sum-of-parts is materially higher than the consolidated multiple.

## AI buildout bottleneck map

Honest version: Avantor is a **bystander** to the AI buildout. There is one weak supplier link.

- **Power generation, grid interconnect, gas turbines, transformers** — indifferent. No exposure.
- **Advanced packaging (CoWoS-L), HBM yield, wafer fabrication** — weak supplier. Avantor's electronic-grade solvents, acids, hydrogen peroxide and process chemicals serve fab wet stations; this is bulk wet chemistry, not the constrained nodes (CoWoS allocation, HBM3e packaging). Margin is decent but not the bottleneck.
- **Optical interconnect, liquid cooling, electrical contractor capacity** — indifferent.
- **Kernel/compiler talent, training data, software runtime** — indifferent.
- **AI-driven biopharma R&D demand pull** — possible second-order beneficiary. If AI lifts biopharma R&D productivity (more INDs, more clinical programs in flight), Avantor's BMP and VWR volumes benefit. This is speculative and not in any near-term consensus number.

A reader using the AI-buildout lens to underwrite AVTR is using the wrong frame. The right frame is biopharma capex + academic research funding + activist-driven margin recovery.

## Competitive teardown

Specifics by axis. Avantor is at parity or behind on every technical axis except its narrow regulatory-specified franchises.

- **Lab distribution / consumables (VWR vs. Thermo Fisher's Fisher Scientific vs. MilliporeSigma):** Avantor is #3 on scale and breadth [3][14]. Thermo Fisher has more SKUs, more locations, deeper e-procurement integration into hyperscaler-style buying programs at large pharma. What would have to be true for Avantor to take share: a meaningful private-label cost advantage or a digital procurement platform leap. Neither is visible. Today's reality: Avantor competes on price and relationships, and its lower share means worse purchase economics on third-party SKUs.
- **Single-use bioprocessing (bags, assemblies, bioreactors) vs. Sartorius (Biostat STR) and Cytiva (Pall + Xcellerex):** Avantor is a **niche** player, not a top-3. Sartorius + Danaher (Cytiva) + Merck KGaA + Thermo Fisher account for ~50–55% of single-use globally [10]. Avantor's RIM Bio acquisition (2021) added China-based bag/assembly capacity but did not meaningfully shift global share. The technical axis here is integrated process trains: Sartorius Biostat STR + Ambr scales predictably from PD to commercial; Cytiva integrates Pall filtration + Xcellerex bioreactors + ÄKTA chromatography; Avantor does not have an equivalent integrated stack. Path to take share: deep cost-disrupt or step-change scalability — neither is visible.
- **Protein A chromatography resin (BAKERBOND PROchievA vs. Cytiva MabSelect SuRe / PrismA):** Cytiva's MabSelect PrismA is the industry default; PrismA X and SuRe 70 launched 2025 to extend the franchise [12]. Avantor's PROchievA was launched in 2020 as a "second-source" alternative, pitched on supply-chain resilience [11]. The technical claim of comparable performance is credible at the bench; the displacement reality is that for new commercial mAb programs, switching from MabSelect implies re-validation that most sponsors won't accept absent a strategic supply reason. PROchievA's role is more likely a credible #2 source for risk management than an outright share gain.
- **High-purity silicones (NuSil vs. Dow Performance Silicones, Wacker, Shin-Etsu, Elkem):** NuSil leads in implantable medical and space grades; Dow/Wacker dominate broader industrial silicones [13]. Genuine parity-or-better on Avantor's narrow target use cases.

Net: Avantor has competitive parity-or-leadership in two narrow franchises (NuSil; specified-in process chemicals/excipients on legacy biologics) and is outflanked-but-credible everywhere else. The new CEO's biggest asset is that he ran Cytiva — he knows exactly which doors to push on and which fights are unwinnable [5][6].

## Bull case — technical

For AVTR to outperform meaningfully over 12–24 months, the following technical conditions need to hold:

1. **Bioprocessing destocking is over and the recovery is real.** Cytiva (Danaher) reported >30% Q1'26 YoY equipment-orders growth — first such quarter in two years [16]. Sartorius BPS reports stabilization [17]. Avantor's BMP book-to-bill was 1.1× in Q1 with double-digit organic growth in process chemicals [9]. If consumables-led recovery flows through (process chemicals first, then fluid handling/equipment in 2H26), BMP organic revenue inflects positive, mix shifts favorable, and BMP segment margins expand 200–300bps.
2. **Ligner executes the Cytiva playbook in BMP.** As CEO of Cytiva (2020–2024) he integrated Pall and built a coherent bioprocess franchise [6]. The repeatable moves are: SKU rationalization, channel discipline, premium pricing on regulated franchises, and capital allocation toward true differentiation (here: NuSil, process chemicals) rather than incremental distribution acquisitions. He knows the customer base because he sold to it from the other side.
3. **$400M Revival cost-out flows through to margin.** From 13.9% Q1'26 EBITDA margin toward 18% near-term and 20%+ long-term [8]. On ~$6.6B revenue, that's ~$270M of EBITDA expansion vs. TTM ~$1.09B base, a ~25% lift in EBITDA dollars before any organic growth.
4. **Activist outcome.** Engine Capital's stated framework: $17–19/share in a sale, $22–26/share in an executed turnaround by end-2027 [7]. With Vanguard already filing a 5.29% passive 13G [search], a strategic sale to Thermo Fisher (antitrust concerns), MilliporeSigma, or a private-equity carve-up of VWR / BMP / NuSil is within the option set.
5. **Base-rate context.** Mid-cap life-sciences tools turnarounds in the post-COVID destocking cycle have been mixed but tractable — Sartorius has rallied 60%+ from its 2024 trough; Bio-Rad and Repligen have similar shapes. The base rate for a specialty-chemicals/distribution business at <1.5× EV/sales with new operator and activist is 30–50% upside in 12 months when execution is competent. Failure rates in life-sciences M&A integrations and turnarounds are ~30–40% based on the cycle's history.

Financial outcome at success: $1.4B EBITDA × 11–12× = $15–17B EV → equity ~$11–14B → ~$16–20/share, broadly matching Engine Capital's framework.

## Bear case — technical

The version a short-seller who understands the stack would write:

1. **VWR distribution is structurally impaired.** It is 70% of revenue, growing slower than the market, in a 3-player oligopoly where #1 has a 6–8× revenue advantage [14]. NIH cuts (~2,100 grants/$9.5B in 2025; 15% indirect-cost cap) [15] hit the academic/government end market that VWR over-indexes to. This is not a destocking issue; it's a structural funding contraction. Even when it stabilizes, the segment grows at GDP, generates low-teens margins, and consumes working capital.
2. **BMP isn't actually a single-use bioprocessing leader.** It's a basket of niches. Process chemicals are growing well (recurring, regulated) but fluid handling and equipment ("new sales") were down double-digits in Q1'26 [9]. The durable-good piece of bioprocessing is where Sartorius and Cytiva win, and Avantor is undersized. New-program wins increasingly route to integrated process trains, not piecemeal procurement.
3. **PROchievA hasn't displaced MabSelect.** Six years post-launch, Cytiva's MabSelect SuRe 70 and PrismA X are the new defaults [12]. The "second source" pitch works for risk management but doesn't translate to material share.
4. **Leverage limits flexibility.** 3.3× net leverage and $3.6B net debt at falling EBITDA means refinancing pressure if rates stay elevated and EBITDA doesn't recover [18]. Equity is thin against the debt — sensitivity to a 1× leverage tick from EBITDA shortfall is large.
5. **Tariff and China exposure.** Sartorius is calling out ~100bps of revenue from US tariff surcharges [22]; Avantor's Phillipsburg/Deventer/Mexico/Poland/Changzhou footprint is more globally exposed than peers, with RIM Bio's Changzhou single-use plant explicitly in the China crosshairs [search on RIM Bio]. BIOSECURE indirect effects on US biopharma's China supplier qualifications add friction.
6. **Ligner doesn't have a Cytiva-grade hand.** He came to Cytiva with the Pall portfolio and Danaher's operating system. At Avantor he has a weaker product portfolio, weaker installed base, and 3.3× leverage. The risk is that he diagnoses the structural problem correctly (VWR is the problem) and the fix — a separation/sale — takes 18–24 months and value is destroyed in the bridge.
7. **Base rate.** Distribution rollups in low-margin scientific consumables that are #2 or #3 (think Office Depot in office products, McKesson historically) tend to compress, not expand, multiples through cycles. The "poor man's Thermo Fisher" framing [14] has been correct for a decade and may continue to be.

Bear outcome: $0.65 normalized EPS × 8× = $5.20/share, with a real risk of further compression if the BMP recovery proves shallow.

## Market view check

At $8.31 with a $12.89 consensus PT and 9.8× forward P/E / 1.4× EV/sales / ~8.5× EV/EBITDA [2], the stock is priced as a structurally impaired distributor that happens to own some valuable specialty pieces. Life-sciences-tools peers (Thermo Fisher, Danaher, Sartorius, MilliporeSigma) trade at 14–22× forward EPS and 3.5–7× EV/sales — Avantor trades at a 50–70% discount to the group, which is wider than at any point since the 2020 IPO ex-COVID lows. The market is implicitly believing: (a) the BMP recovery will be shallow and slow; (b) Engine Capital will not catalyze a strategic transaction; (c) Ligner's first 12 months will be diagnostic, not value-creating; and (d) leverage caps the downside hedge. You disagree with the market most credibly on (a) — peers are visibly inflecting and Avantor's BMP book-to-bill is consistent — and on (b), where activist + new-CEO + Vanguard 13G is a non-trivially-loaded option for a process. (c) and (d) are probably right and bound the upside speed.

## 90-day falsifiers

- **Q2 2026 earnings (early August 2026):** Does BMP organic growth turn positive (vs. guided trough in Q2)? Does book-to-bill stay >1×? Does VWR organic decline narrow from -5% toward flat? A miss on any of these resets the recovery thesis.
- **Capital Markets Day or strategic review announcement:** Engine Capital's pressure raises the probability of a formal portfolio review. Announcement of separation of NuSil or BMP, or a strategic alternatives process, would re-rate the stock toward the $17–19 framework. Silence beyond Q2 is bearish.
- **NuSil / process chemicals disclosure:** Any new segment-level revenue/margin disclosure (the prior segment reorg was meaningful but doesn't break out NuSil or process chemicals separately). Cleaner disclosure would let the market price the sum-of-parts.
- **CFO/COO/digital leadership hires under the Revival plan:** Specifically a CFO change, which is consistent with a more activist-aligned operating-model overhaul.
- **Tariff developments:** Any shift in US tariff posture on EU pharma supplies or China-sourced single-use components. Sartorius's 100bps tariff surcharge as a signal of pricing-power and of cost-pass-through dynamics.
- **NIH FY27 budget signals:** House/Senate appropriations markups by late summer set the 2026/2027 academic-research demand environment that drives VWR.
- **Cytiva and Sartorius Q2 reads:** If their bioprocessing recoveries persist (>20% equipment-order growth at Cytiva; Sartorius BPS guidance held), Avantor's BMP recovery is highly likely; if they stall, Avantor's BMP guide is at risk.

## What I could not verify

- Exact dollar revenue contribution from electronic-grade chemicals into semiconductor fabs (Avantor doesn't disclose this granularly).
- NuSil's specific revenue and EBITDA contribution within BMP.
- Avantor's actual market share in Protein A chromatography resin (vs. Cytiva MabSelect family) — qualitatively the picture is clear but I could not source a quantitative share number.
- The number of FDA-approved drugs/biologics where Avantor is a named DMF or specified supplier — the "85% of top 20 biologics" figure is Avantor's own marketing claim and I could not independently verify it from the FDA DMF list [3].
- Avantor's specific exposure to BIOSECURE Act second-order effects through its Changzhou (RIM Bio) single-use facility.
- Insider buying activity post-Ligner's August 2025 appointment — sources didn't surface specific Form 4 data.
- Whether Engine Capital has board representation or only public-letter pressure — sources confirmed the campaign and 3% stake but not a formal standstill or seat agreement.
- Precise YTD-2026 total return — the search data was clear on 52-week (-44%) but did not isolate calendar-2026 cleanly; I estimated ~-30% from internal triangulation.
- Whether the Sartorius/Cytiva tariff data point applies symmetrically to Avantor's manufacturing footprint (Phillipsburg/Paris-KY US production may insulate parts of US revenue, but EU/Asia production into US may have different exposure).

## Sources

[1] https://news.avantorsciences.com/2023-12-07-Avantor-R-Hosts-Investor-Day,-Announces-New-Strategic-Operating-Model-to-Drive-Growth-and-Productivity — retrieved 2026-05-10 — Avantor's strategic operating model and segment reorganization (VWR Distribution & Services + Bioscience & Medtech Products).

[2] https://stockanalysis.com/stocks/avtr/statistics/ — retrieved 2026-05-10 — current price $8.31, market cap $5.67B, share count ~676M, 52-week range, valuation multiples, consensus 12-mo PT $12.89.

[3] https://en.wikipedia.org/wiki/Avantor — retrieved 2026-05-10 — company history, VWR acquisition (2017), NuSil merger (2016), segment composition, "specified into 85% of top 20 commercial biologics" claim.

[4] https://news.avantorsciences.com/2025-04-25-Avantor-R-Announces-CEO-Transition — retrieved 2026-05-10 — Stubblefield CEO-transition announcement, April 2025.

[5] https://news.avantorsciences.com/2025-07-21-Avantor-Announces-Emmanuel-Ligner-as-Next-President-and-CEO — retrieved 2026-05-10 — Ligner appointed CEO effective August 18, 2025.

[6] https://www.stocktitan.net/news/AVTR/avantor-announces-emmanuel-ligner-as-next-president-and-jqlze2kcy8w3.html — retrieved 2026-05-10 — Ligner background: ex-CEO of Cytiva (2020–2024), ex-CEO of GE Life Sciences, Pall integration leadership.

[7] https://www.cnbc.com/2025/08/16/engine-capital-takes-a-stake-in-avantor-activist-sees-several-ways-to-create-value.html — retrieved 2026-05-10 — Engine Capital 3% stake, framework: $17–19 in sale, $22–26 turnaround by 2027.

[8] https://www.ainvest.com/news/avantor-400m-cost-cutting-plan-path-margin-recovery-operational-efficiency-leadership-shifts-2508/ — retrieved 2026-05-10 — Revival plan, $400M run-rate cost savings target by end-2027 (raised from $300M by 2026), automation investments, new operating model.

[9] https://www.fool.com/earnings/call-transcripts/2026/04/29/avantor-avtr-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1 2026 results: $1.581B revenue, -4% organic, BMP -2% organic with double-digit growth in process chemicals offset by double-digit declines in fluid handling and new sales, BMP book-to-bill 1.1×, Q2 EPS guide $0.19–$0.20, FY26 reaffirmed.

[10] https://www.marketsandmarkets.com/ResearchInsight/single-use-bioprocessing-market.asp — retrieved 2026-05-10 — Sartorius, Danaher (Cytiva), Thermo Fisher, Merck KGaA combined ~50–55% of single-use bioprocessing globally; Avantor a smaller player.

[11] https://news.avantorsciences.com/2020-03-18-Avantor-R-Launches-New-Protein-A-Chromatography-Resin-PROchievA-that-Provides-Supply-Chain-Flexibility-and-Improves-Downstream-Purification-Performance-for-Monoclonal-Antibodies-mAbs-Production — retrieved 2026-05-10 — BAKERBOND PROchievA Protein A resin launch and positioning as a supply-chain alternative for mAb purification.

[12] https://www.cytivalifesciences.com/en/us/news-center/cytiva-advances-resins-portfolio-10001 — retrieved 2026-05-10 — Cytiva MabSelect SuRe 70 and MabSelect PrismA X 2025 launches; alkaline stability claim of 200 cycles in 0.5 M NaOH.

[13] https://www.newmountaincapital.com/avantor-performance-materials-and-nusil-technology-to-merge/ — retrieved 2026-05-10 — NuSil merger (2016), positioning as global leader in medical and space-grade silicones; combined revenue post-merger >$700M growing 14%.

[14] https://scuttleblurb.substack.com/p/avtr — retrieved 2026-05-10 — Avantor as #3 lab distributor behind Thermo Fisher (Fisher Scientific) and Merck KGaA (MilliporeSigma); critique of 2021 acquisition multiples; "poor man's Thermo Fisher" framing.

[15] https://cen.acs.org/policy/nih-nsf-ostp-science-research-funding-cuts/103/web/2025/12 — retrieved 2026-05-10 — NIH cut ~2,100 grants ($9.5B) by mid-2025; 15% indirect-cost cap; ~6,500 fewer awarded projects vs. decade norm.

[16] https://www.labmanager.com/what-danaher-s-q1-2026-earnings-mean-for-lab-managers-bioprocessing-turns-a-corner-new-diagnostics-tools-arrive-and-ai-takes-center-stage-35279 — retrieved 2026-05-10 — Cytiva Q1 2026 equipment-orders growth >30% YoY, first such quarter in nearly two years.

[17] https://www.sartorius.com/en/company/newsroom/corporate-news/2026-first-quarter-results-sartorius-stedim-biotech-1817704 — retrieved 2026-05-10 — Sartorius Stedim Q1 2026 stabilization in BPS order intake, FY26 sales growth guide of 6–10% in constant currencies including ~100bps US-tariff-surcharge contribution.

[18] https://www.prnewswire.com/news-releases/avantor-reports-first-quarter-2026-results-302756438.html — retrieved 2026-05-10 — Q1 2026 financial details: $1.581B revenue, EBITDA $219M (13.9% margin), $0.17 adj. EPS, net debt $3.6B, 3.3× adj. net leverage, $105M debt repayment.

[19] https://www.investing.com/news/transcripts/earnings-call-transcript-avantor-q1-2026-beats-expectations-stock-surges-93CH-4645291 — retrieved 2026-05-10 — Q1 2026 earnings call commentary on book-to-bill, process chemicals momentum, NIH/funding environment.

[20] https://www.macrotrends.net/stocks/charts/AVTR/avantor/revenue — retrieved 2026-05-10 — FY2025 revenue $6.552B (-3.4% YoY), FY2024 $6.784B (-2.6% YoY).

[21] https://news.avantorsciences.com/2025-03-17-Avantor-R-Provides-First-Look-at-Recently-Completed-Hydration-Expansion-at-DCAT-Week-2025 — retrieved 2026-05-10 — Phillipsburg, NJ expansion of synthesized-salt and USP/WFI hydration manufacturing capacity; Macron product line scope.

[22] https://www.fiercepharma.com/pharma/regulatory-policy-uncertainties-are-hamstringing-biopharma-strategy-industry-execs-warn — retrieved 2026-05-10 — Cytiva and industry-exec commentary on regulatory and tariff uncertainty hamstringing biopharma planning.

[23] https://www.benzinga.com/insights/short-sellers/25/01/43065267/avtr-analyzing-avantors-short-interest — retrieved 2026-05-10 — short interest 29.57M shares, 4.36% of float, peer-group average 5.17%, 7.66 days to cover.

[24] https://www.alphaspread.com/market-news/corporate-moves/activist-investor-engine-capital-urges-avantor-to-sell-itself-or-explore-alternatives — retrieved 2026-05-10 — Engine Capital activist letter detail: sale-vs-turnaround framework, board-overhaul ask, urgency framing.