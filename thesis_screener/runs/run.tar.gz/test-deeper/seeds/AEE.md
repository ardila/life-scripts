# AEE — Ameren Corporation

## Where this sits in the AI stack
AEE is a regulated electric and gas utility, not a chip vendor or hyperscaler — it sits at the **power-and-interconnection layer** beneath every GPU rack in its footprint. Its operating subs are Ameren Missouri (MISO Local Resource Zone 5, vertically integrated generation + T&D under Missouri PSC) and Ameren Illinois (MISO Zone 4, wires-only delivery under ICC, with separate gas distribution). The relevant AI workload is **training and inference colocation at hyperscale campuses** — multi-hundred-MW single-meter loads where the binding constraint is not silicon but firm capacity, substation timing, and regulated rate-base recovery on the gas-and-wires it must build to serve them.

## Snapshot
- **Price:** $108.66 (2026-05-07 close) [1]
- **Market cap:** $30.9B [1]
- **52-week range:** $93.27 – $112.66 [11]
- **Forward P/E:** ~20.3× on FY2026 midpoint EPS $5.35 (guidance $5.25–$5.45); ~18.7× on NTM blended consensus ~$5.80 [3][5]
- **EV / NTM revenue:** ~6.3× (EV ~$46.4B against NTM revenue consensus ~$7.4B) — inference, see "What I could not verify" [5]
- **Consensus 12-month price target:** $117–$122 median across 11–22 covering analysts (~+8% to +12% from price) [5][11]
- **YTD total return:** +12.8% [11]
- **Dividend yield:** 2.6% (annualized $2.84) [11]
- **Short interest (% of float):** n/a — not surfaced in primary sources; regulated utilities of this size typically run <2% and AEE shows no unusual short signal in coverage

## Moat — what it is physically made of
The "moat" word is almost wrong here — AEE is a state-conferred monopoly, not a competitive advantage. What actually matters is the **stack of regulatory mechanisms** that determine whether $30B of incremental rate base earns the allowed return without lag, and the **physical optionality** of an integrated generator inside MISO Zone 5. Decomposed:

1. **Service-territory monopoly (durable, but politically contestable):** Ameren Missouri is the certificated provider in 64 Missouri counties; Ameren Illinois delivers electricity across most of downstate Illinois. A hyperscaler that wants Missouri or downstate Illinois interconnection at scale is structurally a customer, not a counterparty. Behind-the-meter (BTM) bypass is the only real alternative and is rare for >100MW loads because it forfeits N+1 grid backup and capacity-market hedging [10].

2. **Plant-In-Service Accounting (PISA) — Missouri (durable, statutory since 2018):** Defers 85% of depreciation and return on new plant placed in service between rate cases for future recovery, materially compressing regulatory lag on rate-base growth [7]. This is the single biggest reason Missouri can sustain ~10%+ rate-base CAGR without dilutive multi-year rate freezes.

3. **Missouri SB 4 / CWIP (new, 2025):** Allows CWIP recovery in rates for new natural gas and nuclear generation **before commercial operation**, plus future test years. For an 800–2,100 MW combined-cycle plant with 4–5 year construction lead time, this eliminates AFUDC carry and pulls forward cash earnings by ~2-3 years per project [8]. This is the structural reason West Alton (2,100 MW NGCC, CCN filing Q3 2026) and Big Hollow (800 MW + 400 MW BESS, 2028 ISD) are accretive on day one rather than dragging on near-term earnings [4].

4. **Large-Load Tariff (Missouri PSC, approved Nov 2024):** 12-year minimum term, 80% take-or-pay on contracted MW, two-year termination notice, early-exit fees, **100% of direct interconnection cost paid up front**, and two years of minimum monthly bills as collateral [2][9]. Customers had already wired $28M into the prework escrow by Oct 2025 [12]. This is the cleanest stranded-cost ringfence I have seen in a US LRZ — meaningfully tighter than AEP Ohio's framework — and it is what makes the 2.2 GW of signed ESAs financeable.

5. **Generation optionality inside Zone 5:** Vertically integrated with ~10 GW of existing assets, control of brownfield sites (Rush Island redevelopment for 800 MW gas + storage, Castle Bluff 800 MW, Sioux site for the 2,100 MW West Alton CCGT) [4][6]. Brownfield sites carry the gas lateral, water rights, switchyard, and (critically) **avoid greenfield MISO queue position** — most replacement generation can be re-energized in the existing interconnection.

6. **Illinois — structurally weaker (acknowledge honestly):** ICC slashed Ameren Illinois's grid plan from $333M to $83M in incremental investment in Dec 2024 and cut allowed ROE to 8.715% (vs. ~9.7% Missouri-historical) [13]. Illinois is delivery-only, no generation rate base, and the ICC operates a more adversarial multi-year rate plan regime than the Missouri PSC. Illinois is roughly a third of consolidated rate base but a smaller share of incremental earnings power.

**Person-years to replicate:** not a meaningful concept here — the moat is statutory, not technical. The relevant question is "how durable is Missouri's regulatory regime" — answered in the bear case.

## AI buildout bottleneck map
| Bottleneck | AEE position | Notes |
|---|---|---|
| **Power generation** | Beneficiary + constraint owner | Owns 10+ GW; building 5+ GW through 2030; CCN approval is the gating step [4] |
| **Grid interconnect / transmission** | Beneficiary | Awarded multiple MISO LRTP Tranche 1 + 2.1 transmission projects [4]; Tranche 2 bids submitted Jan + May 2026 [4] |
| **MISO capacity adequacy** | Beneficiary (tight market) | PRA 2025/26 cleared at $217/MW-day annualized (10× PY 24/25); summer at $666.50; system reserve margin dropped 6.5 → 4.6 → 2.6 GW over three years [14][15]. ERAS expedited-interconnect process rejected by FERC May 2025 [16]. |
| **Advanced packaging / HBM** | Indifferent | Not exposed |
| **Optical / NCCL fabric** | Indifferent | Not exposed |
| **Liquid cooling at >100 kW/rack** | Indirect beneficiary | Higher rack density → higher MW/site → more $/customer for AEE, but the cooling vendor captures none of AEE's value |
| **Electrical contractor / substation labor** | Exposed customer | Same constrained labor pool serving all utilities; cost overruns flow through rate cases with some lag |
| **Kernel/compiler/SW talent** | Indifferent | |
| **CoWoS-L / TSMC** | Indifferent | |

The point: AEE is not a *picks-and-shovels* play on the AI stack the way an NVDA, AVGO, or VRT is. It is a **power-rate-base** play — its return profile depends on Missouri PSC continuing to permit gas + nuclear CWIP, on MISO capacity prices staying tight enough that vertical integration is preferred over IPP procurement, and on ~10% rate-base CAGR being earned through (not eroded by) regulatory lag.

## Competitive teardown
The right comparison set is **MISO/SPP utilities with hyperscaler exposure**, not chip vendors. AEE is mid-pack on absolute pipeline size but arguably best-in-class on regulatory mechanism.

| Peer | Contracted/ESA load | 5-yr capex | Rate-base CAGR | Note |
|---|---|---|---|---|
| **AEE** | 2.2 GW ESAs + 1.2 GW MO + 0.85 GW IL construction agts (~4.25 GW firm) [4] | $31.8B | 10.6% [4] | PISA + SB 4 CWIP, large-load tariff |
| **Evergy (EVRG)** | 2.5 GW ESAs (Meta + Google named) [17] | $21.6B [17] | 11.5–12% [17] | MO/KS, adjacent footprint, more concentrated counterparty risk |
| **AEP** | 56 GW pipeline (~41 TX, 16 PJM, 6 SPP) [18] | ~$54B | ~8–9% | Vastly larger pipeline but split across 11 jurisdictions and three RTOs |
| **Entergy (ETR)** | 7–12 GW DC pipeline (Meta named) [19] | $41B | ~8% | Heavy gas build, Louisiana/Mississippi regulatory regime less tight than MO |

**Where AEE is structurally weaker:** absolute scale (one-tenth of AEP's pipeline), MISO Zone 5 is a smaller capacity pool than PJM or ERCOT, and Missouri is not a top-five data-center hub geographically — St. Louis is meaningfully behind Northern Virginia, Phoenix, Dallas, and Columbus in fiber density and existing campus inventory.

**Where AEE is structurally stronger:** the Missouri tariff/PISA/CWIP combination is the most rate-payer-protective and shareholder-friendly composite in the country. Compare to PJM, where the cost-allocation fight (FirstEnergy's refusal to "take commodity risk on generation and energy" for data centers, ongoing CIFP proceedings) [20] is unresolved and where stranded-cost risk sits with the IOU. Missouri pushed that risk explicitly onto the customer via 80% take-or-pay + collateral. That is a real moat at the **regulatory-architecture** layer, not just rhetoric.

**Substitution path — behind-the-meter:** the only credible workaround. Grid interconnect timelines are 3–7 years in many markets vs. 18–24 months to build the data center [10], so hyperscalers are deploying BTM gas turbines (VoltaGrid, ProEnergy) and reserving SMR slots (Oklo, X-energy, NuScale). The threat to AEE is **not zero** but the BTM economics work best for first-tower bridging power, not for the 20-year build-out of a multi-GW campus, because BTM forgoes capacity-market revenue, requires private dispatch, and adds emissions liability the hyperscaler is trying to offload. In a tight MISO capacity market, the cheapest MWh is still the regulated utility MWh.

## Bull case — technical
For AEE to outperform meaningfully from here, three technical conditions must hold:

1. **Hyperscaler training-cluster scaling continues at frontier:** GPT-class and successor models continue to scale parameter count and post-train compute, sustaining 200–500 MW single-campus power demand. If frontier scaling stalls or shifts decisively to inference-on-edge / smaller models, the multi-GW pipeline contracts. Base rate on platform transitions (CPU→GPU, on-prem→cloud) suggests scaling cycles run 7–10 years before inflecting — we are ~3 years into the current AI scaling cycle, so a 24-month-horizon thesis is consistent with continued scale-up.

2. **MISO Zone 5 stays capacity-tight:** PRA prices remain elevated, ERAS-equivalent expedited interconnect stays blocked or limited, and existing 309 GW queue continues to throttle IPP entry [16][15]. This keeps utility self-build the lowest-cost firm capacity and protects PISA/CWIP economics. Missouri summer reserve margin has been the binding constraint and is widely expected to remain so through 2028.

3. **Missouri PSC continues to honor SB 4 / PISA / large-load tariff:** No legislative rollback, no rate-case ROE compression below ~9.5%, no consumer-advocate-led reopening of the tariff. The Dec 2025 consumer-group challenge to the data-center rate case [21] is the live test — if it fails (likely, given the PSC approved unanimously), the regulatory framework is durable for the buildout cycle.

If all three hold: 10.6% rate-base CAGR translates roughly 1:1 to EPS growth with PISA reducing lag, plus ESA-funded upside above the current plan. EPS toward $7.50 by 2030 → at 18× → $135 + dividends compounded. The $122 consensus PT is a reasonable 12-month read but the **2027–2028 setup** is materially better than the consensus 5-year EPS guide of 6–8% suggests, because the 2.2 GW Missouri ESAs ramp into rate base through 2027–2030 and are not yet fully in plan.

## Bear case — technical
Three credible erosion paths:

1. **Hyperscaler load forecast was speculative:** the 309 GW MISO queue [15] vs. 127 GW peak load is partly speculative IPP capacity, but the **demand** side is also speculative — multiple analysts estimate hyperscaler load forecasts are double-counted across utilities (the same project shopping multiple service territories). If 2027 deployment delivers 40–60% of the pipeline, AEE still benefits because of take-or-pay, but the **outsized pipeline beyond ESAs** evaporates. The $70B 10-year capex pipeline becomes the $32B 5-yr plan and the multiple compresses.

2. **Behind-the-meter + SMR bypass at scale:** if Oklo (Aurora, 75 MWe) or X-energy reach commercial operation by 2028–2029 on a hyperscaler campus, and the regulatory clarity for co-located gen catches up (FERC, NRC), every incremental hyperscaler campus has a credible non-utility option. This is the genuine technology-displacement scenario. Base rate on regulated-utility displacement is low — closest analog is muni-vs-IOU competition, which moves at decade scale — but SMR + private fiber + BTM gas is a more concentrated threat than historical examples.

3. **Missouri political reversal:** SB 4 passed in 2025 on narrow margins, consumer groups are explicitly campaigning against CWIP [8][21], and the Sierra Club / Consumer Council coalition has standing in every rate case. A 2027 statehouse change could repeal CWIP or constrain PISA. If allowed ROE drifts to ~9.0% (vs. the implied ~9.7% in current authorizations) and CWIP is reversed, ~150 bps of authorized earnings power evaporates and the multiple goes to 16× — stock would be flat to down despite EPS growth.

A genuine short would also flag: at 20× forward earnings, AEE is at the top of the regulated-utility multiple range — XEL, DUK, SO trade ~17–18× with similar growth profiles. The premium is the data-center optionality, which is partly priced in. If any of the three conditions breaks, the de-rate is real.

## Market view check
At $108.66, 20× FY2026 EPS midpoint, and 2.6% yield, AEE trades roughly **two multiple points above the regulated-utility median** and at the top of its own historical band. The market is paying for data-center optionality at ~$5–8B of incremental enterprise value — fair compensation for ~3 GW of firm ESAs and several GW of pipeline given the Missouri tariff/PISA/CWIP stack. The consensus PT of $122 implies the market view is: data-center growth is real, it's substantially priced in, +10% over 12 months. I think this is approximately right on a 12-month horizon and **modestly undervalued on a 2027–2030 horizon** if the bull case 2 (MISO tight) and 3 (regulatory durability) hold — because the rate-base step-up from the 2.2 GW ESAs is not fully in the 5-year plan EPS.

## 90-day falsifiers
- **Q2 2026 earnings (~early Aug):** management raises 2026 guidance or 5-year EPS CAGR above the current 6–8% range, *and* announces incremental ESAs (>500 MW) → bull case strengthens. Conversely, any softening of pipeline language (especially "engineering studies" not converting to construction agreements) → bear case live.
- **West Alton CCN filing (targeted Q3 2026):** an actual filing on schedule, with hearing milestones set, validates the 2,100 MW NGCC and its CWIP recovery path. A delay or scope cut materially impairs the 2028–2031 earnings ramp.
- **Missouri PSC decision on consumer-group rehearing request (filed Dec 2025):** rejection (likely) confirms tariff durability; granting reopening = thesis-altering negative.
- **MISO PRA 2026/27 results (typically released April–May):** if Zone 5 prices compress sharply due to new IPP commissioning or demand-side easing → vertical-integration thesis weakens.
- **MISO Tranche 2 transmission award (mid-2026):** AEE explicitly bid; award size and scope is a direct check on the $70B 10-yr pipeline.
- **Hyperscaler customer disclosure:** any identification of the 2.2 GW ESA counterparties (likely Meta and/or Google given Sept 2025 Google-link reporting on the St. Charles site [22]) — investment-grade counterparty names tighten the credit picture and reduce ringfence-stress probability.
- **Any FERC ruling on the next-generation ERAS or co-located load:** material for the broader sector but tends to compress utility multiples if BTM/co-located generation gets cleaner FERC treatment.

## What I could not verify
- The exact identity of the 2.2 GW Missouri ESA counterparties — disclosed only as "multiple large hyperscalers"; credit quality of contracts is therefore inferred, not confirmed.
- The precise allowed ROE in the Sept 2025 Missouri rate-case settlement; sources reference $335M revenue settlement (vs. $446M requested) but stop short of an explicit ROE number. Historical authorized ROE has been ~9.74% but the new case settlement specifics were not in the public summaries I could access.
- A precise NTM revenue consensus for the EV/revenue ratio — I inferred from market cap, debt, and reasonable consensus revenue range. The metric is less meaningful for regulated utilities than EV/EBITDA or P/B (~2.1× book on rough estimate) anyway.
- Short interest as a percent of float — not surfaced; for a $30B regulated utility this is almost certainly trivial (<2%) but I could not confirm a specific number.
- Whether the 2.2 GW of ESAs is fully reflected in the disclosed $31.8B 5-year capex plan or whether it represents incremental upside (management language on the Q1 call — "could be an upside driver if those ramps occur faster than planned" [4] — suggests partial inclusion, but I could not pin down which generation and T&D projects are tied to which ESAs).
- The actual capacity-factor and dispatch economics of the planned NGCC fleet at 2028+ gas prices and MISO LMP — material to whether the CWIP-recovered plants earn the allowed return or under-run.

## Sources
[1] https://www.thestockobserver.com/2026/05/07/ameren-nyseaee-issues-fy-2026-earnings-guidance.html — retrieved 2026-05-10 — May 7 close $108.66, Q1 EPS $1.28 vs $1.17 consensus, FY26 EPS guide $5.25–$5.45
[2] https://psc.mo.gov/Electric/PSC_Approves_Ameren_Missouri_Large_Load_Power_Rate_Plan_with_Customer_Protections--pr-26-40 — retrieved 2026-05-10 — PSC unanimous approval of large-load tariff (>75 MW, 12-yr term, take-or-pay, collateral)
[3] https://finance.yahoo.com/quote/AEE/ — retrieved 2026-05-10 — price quote and forward P/E reference
[4] https://www.fool.com/earnings/call-transcripts/2026/05/06/ameren-aee-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q1 2026 transcript: 2.2 GW Missouri ESAs, 1.2 GW MO + 850 MW IL construction agts, $31.8B 5-yr capex, $70B+ 10-yr pipeline, 10.6% rate-base CAGR, generation projects (West Alton 2,100 MW, Castle Bluff 800 MW, Big Hollow 800+400 MW), MISO Tranche transmission bids
[5] https://public.com/stocks/aee/forecast-price-target — retrieved 2026-05-10 — analyst PT consensus, forward PE, EV
[6] https://www.gem.wiki/Sioux_Power_Plant — retrieved 2026-05-10 — Sioux Energy Center 1,099 MW West Alton, retirement 2030
[7] https://www.ameren.com/-/media/missouri-site/files/aboutus/amerenmissourifactsheet.ashx — retrieved 2026-05-10 — PISA mechanism details (85% deferred recovery)
[8] https://moenvironment.org/blog/senate-bill-4-explained/ — retrieved 2026-05-10 — Missouri SB 4 CWIP and future-test-year provisions (gas + nuclear)
[9] https://www.stlpr.org/health-science-environment/2025-11-24/missouri-utility-regulators-approve-ameren-rates-data-centers — retrieved 2026-05-10 — tariff approval details, customer protections
[10] https://www.datacenterhawk.com/resources/market-insights/behind-the-meter-power-solutions-the-data-center-industry-s-new-reality — retrieved 2026-05-10 — BTM substitution dynamics, 3–7 year interconnect timelines
[11] https://www.financecharts.com/stocks/AEE/growth/total-return — retrieved 2026-05-10 — YTD +12.83%; also Marketbeat/dividend.com — 52-week range, dividend yield 2.6%, annualized $2.84
[12] https://www.stlpr.org/health-science-environment/2025-10-20/data-centers-ameren-missouri-28m-electric-bills-rise — retrieved 2026-05-10 — $28M paid upfront by data-center prospects
[13] https://www.illinois.gov/news/press-release.30764.html — retrieved 2026-05-10 — ICC amended grid plan Dec 2024, ROE 8.715%, $83M of $333M requested
[14] https://www.sysotechnologies.com/2025/05/15/miso-2025-2026-capacity-auction-results/ — retrieved 2026-05-10 — MISO 2025 PRA, $217/MW-day annualized, $666.50 summer
[15] https://cdn.misoenergy.org/06_2025-09-16_SPC_Open_Long%20Term%20Resource%20Adequacy%20%20Interconnection%20Queue%20Update_FINAL717559.pdf — retrieved 2026-05-10 — 309 GW queue, peak load 127 GW, resource adequacy outlook
[16] https://www.klgates.com/Regional-Grid-Operators-Attempt-to-Tackle-Resource-Adequacy-by-Fast-Tracking-Generator-Interconnection-6-6-2025 — retrieved 2026-05-10 — FERC rejected MISO ERAS proposal May 2025
[17] https://www.utilitydive.com/news/evergy-capital-spending-meta-google-data-center/812647/ — retrieved 2026-05-10 — Evergy 2.5 GW ESAs, $21.6B capex, ~12% rate-base growth
[18] https://www.utilitydive.com/news/aep-pjm-spp-data-centers-earnings/819419/ — retrieved 2026-05-10 — AEP 56 GW data-center pipeline distribution
[19] https://www.utilitydive.com/news/gas-continues-to-dominate-entergy-plans-as-data-center-pipeline-grows/804521/ — retrieved 2026-05-10 — Entergy DC pipeline 7–12 GW, $41B capex
[20] https://www.utilitydive.com/news/firstenergy-earnings-pjm-auction-affordability-data/818929/ — retrieved 2026-05-10 — FirstEnergy refusal to take commodity risk; PJM cost-allocation disputes
[21] https://www.stlpr.org/health-science-environment/2025-12-04/consumer-advocacy-group-hearing-ameren-missouri-data-center-rate-case — retrieved 2026-05-10 — Consumer Council request for rehearing of large-load tariff
[22] https://www.stlpr.org/economy-business/2025-09-08/documents-link-secretive-st-charles-data-center-google — retrieved 2026-05-10 — Google linkage to St. Charles MO data-center site