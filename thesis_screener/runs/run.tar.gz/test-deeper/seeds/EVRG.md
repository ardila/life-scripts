# EVRG — Evergy, Inc.

## Where this sits in the AI stack
Evergy is a vertically integrated, two-state regulated electric utility (Kansas Corporation Commission and Missouri Public Service Commission jurisdictions; SPP balancing authority) serving ~1.7M customers across the Kansas City metro and most of Kansas and western Missouri. It does not manufacture silicon, packaging, networking, cooling, or software. Its sole AI-stack exposure is **electrons and the substation-scale infrastructure that delivers them** — i.e., the layer immediately upstream of every data hall: generation (Wolf Creek nuclear, ~4.5 GW of legacy coal, growing CCGT fleet), transmission inside SPP, distribution into the KC metro, and — most importantly — the regulatory monopoly that lets it sign multi-decade Electric Service Agreements (ESAs) with hyperscalers under a tariff its commissioners have already blessed [1][7][8][12][16][17].

## Snapshot
- **Price:** $81.78 (2026-05-08 close) [9]
- **Market cap:** $18.85 B [9]
- **Enterprise value:** $34.71 B (≈$13.5 B long-term debt + market cap, less cash) [9][10]
- **52-week range:** $63.29 – $85.27 [11]
- **Forward P/E:** 19.3× on FY26 mgmt midpoint EPS $4.24 (range $4.14–$4.34) [4][9]
- **EV / TTM revenue:** 5.76×; **EV / EBITDA (TTM):** 12.46× [9]
- **Consensus 12-month price target:** $86.57 (avg of 7 sell-side; high $95, low $76) → +5.9% from spot [4]
- **YTD total return (price):** ≈ +12% (vs. roughly flat S&P; +11.8% as of 3/20, modest drift since) [11]
- **Short interest (% of float):** 5.7% [9] — elevated for a regulated utility (typically 1–2%), suggesting some active fade of the AI-power narrative
- **Dividend yield:** 3.40%; **5Y beta:** 0.54 [9]

## Moat — what it is physically made of
The first thing to be honest about: this is not a CUDA moat. There is no proprietary compiler stack, no person-years of kernel work, no patent thicket. Evergy's "moat" is a stack of **regulatory, geographic, and physical-equipment** advantages that AI buyers cannot route around in the relevant time window. Decomposed:

1. **Statutory monopoly franchise** in Kansas and western Missouri. The KCC and MoPSC grant exclusive distribution service territory; a hyperscaler that wants to land at a Kansas City–metro site cannot procure retail electricity from anyone else without going off-grid (which means siting and permitting their own ~1+ GW gas plant, a 5–7 year exercise). This is durable until the legislature changes — Kansas/Missouri are not on any deregulation track.

2. **Wolf Creek nuclear** — single PWR, ~1,250 MW(e) net, 94% Evergy-owned (47% each by Evergy Metro and Evergy Kansas South), license extended to 2045, ~92% capacity factor [13][14]. This is ~10% of company net generation and the only meaningful baseload carbon-free asset in the footprint. Hyperscalers with 24/7 carbon-free targets (Google, Meta) will pay up for grid mixes that include nuclear; this is a structural advantage Evergy *already owns*, vs. peers chasing scarce nuclear PPAs (Constellation–Microsoft, Talen–AWS).

3. **Approved Large Load Power Service (LLPS) tariff**, applicable to any customer with ≥75 MW expected demand. Rate design recovers Evergy's *incremental* cost of service from the new customer; capex driven solely by the new load is direct-assigned; **two years of minimum monthly bills as up-front collateral**; minimum bill (take-or-pay-equivalent) for the contract life [3][7][16]. KCC approved 2025-11-06; MoPSC approved mid-November 2025. This is the single most important risk-shifting instrument and it was negotiated *with consumer-advocate concurrence*, which materially reduces appellate risk.

4. **Pre-secured long-lead equipment.** Management explicitly said on the Q1'26 call: "we have turbine reservations beyond what is needed in the ESAs we have announced" [4]. With GE Vernova's heavy-frame backlog at ~80 GW stretching to 2029 and likely sold out through 2030 by year-end 2026 [5][20], a utility that *already holds* 2029/2030 slots has a moat measured in years vs. greenfield competitors. Evergy's two announced 705 MW CCGTs (Viola, Sumner County KS, ISD 1/1/2029; McNew, Reno County KS, ISD 1/1/2030) plus the 440 MW simple-cycle Mullin Creek #1 in Nodaway County MO have Mitsubishi Power Americas as the PIE contractor with bids competed against GE Vernova and Siemens [12].

5. **Existing transmission rights and substation footprint** in the KC metro — not glamorous, but real: SPP's generator interconnection queue ran a multi-year backlog and only cleared in September 2025 after 24 cluster studies of 340 GW [6]. New independent power producers face years of GIA studies and direct-assignment costs that Evergy's incumbent grid does not.

**Honest assessment:** components 1, 2, and 5 are highly durable (multi-decade). Component 3 is durable for the contract term but can be litigated by ratepayer advocates if cost-shifting emerges in practice. Component 4 is durable for ~3–5 years, eroding as turbine OEM capacity expands (GE Vernova guides 24 GW/yr by mid-2028) [5]. None of this is a *technology* moat — it is a **siting, permitting, and franchise** moat, which is exactly what is binding in the AI buildout right now.

## AI buildout bottleneck map
The actual gating constraints over the next 24 months and EVRG's posture against each:

- **Power generation capacity (firm dispatchable):** binding. EVRG is a **direct beneficiary** — it is the counterparty selling the firm capacity. 1.9 GW of new CCGT in build; 2,500 MW of hydrogen-capable gas planned 2029–2032; 6,000 MW total firm dispatchable in 20-year IRP [2][12].
- **Heavy-frame gas turbines (GE Vernova 7HA, Mitsubishi M501JAC, Siemens SGT6-9000HL):** binding through 2029–2030. EVRG is **slot-secured beyond announced ESAs** per management [4]; OEM industry capacity 80 GW backlog extending to 2029 [5][20].
- **SPP transmission interconnection:** binding historically; **moderate** going forward post-backlog clearance Sept 2025 [6]. EVRG is the **incumbent transmission owner** — new third-party gen wanting to serve the same load goes through the queue; EVRG-owned generation does not.
- **Large power transformers and GSUs:** binding industry-wide. Lead times 128 weeks for std power transformers, 144 weeks for GSUs; Wood Mac forecasts 30% supply deficit in 2025 worsening in 2026 [15]. EVRG **exposed customer** — I could not verify specific reserved transformer slots, this is a real execution risk.
- **High-voltage switchgear, breakers, cable:** binding industry-wide. Same exposure profile as transformers.
- **Grid interconnect approvals & state permitting:** binding nationally; **EVRG advantaged** — Kansas and Missouri have less restrictive permitting than CA/NY/MA; KS already issued the PSD air permit for Viola ahead of schedule [12].
- **Liquid cooling >100kW/rack, optical interconnect, HBM3e/HBM4 supply, CoWoS-L allocation, kernel/compiler talent:** **indifferent** — these affect Evergy's *customers'* ability to consume the power, not Evergy's ability to sell it. The pass-through is: if Meta/Google can't get racks, ramp slows, and Evergy's minimum-bill clauses convert to a credit-quality question (counterparties are BBB+ / A-class hyperscalers).
- **Water supply for cooling:** **moderate**, regional issue; KC metro is comparatively water-rich vs. Phoenix/Northern VA.

## Competitive teardown
EVRG does not compete with NVIDIA, AMD, or Broadcom. It competes (a) with other regulated utilities for hyperscaler site selection and (b) with merchant generators and behind-the-meter alternatives for large-load power supply.

- **AEP Ohio / Texas / Indiana:** much larger (32 GW today, targeting 63 GW by 2030, ~90% from data centers [18]). AEP has scale and ERCOT exposure EVRG lacks, but AEP also has larger regulatory drag (multi-state, including PUCO scrutiny). On a per-share growth basis EVRG's 7–8% load CAGR is competitive.
- **Duke (Carolinas, Florida):** 7.6 GW signed ESAs (vs. EVRG's 2.5 GW under LLPS + 0.45 GW Panasonic) [18]. Duke's Microsoft/Compass deals are larger in absolute terms but EVRG is materially more concentrated in data-center load as % of base. EVRG's **rate base CAGR ~12%** is at or above Duke's.
- **Southern Company (Georgia Power):** 50 GW of *pending* interconnection requests vs. signed [18] — much more pipeline, much more likely a chunk doesn't convert. Southern trades at 24× FWD vs. EVRG at 19× — partly explained by Vogtle nuclear premium and larger absolute pipeline.
- **Constellation (CEG) and Vistra (VST):** different animal — merchant power, deregulated PJM/ERCOT exposure, nuclear-heavy, multi-decade hyperscaler PPAs at premium $/MWh. They trade at ~26× and ~50×+ respectively. They benefit from spot price upside; EVRG does not (regulated cost-of-service ROE caps upside but also cuts left-tail).
- **Behind-the-meter (BTM) self-generation by hyperscaler:** Meta–Entergy Hyperion (5.2 GW gas + 2.5 GW solar, utility-build but hyperscaler-funded) [19] is the threat-model template — hyperscalers can fund their own dedicated capacity. The defensive answer is what EVRG already offers: incumbent grid, existing nuclear, sub-7-year time-to-power vs. greenfield BTM at 5–8 years and full gas-turbine queue exposure.
- **Wolfspeed-style independent gas IPPs:** in SPP, building merchant capacity to sell into a regulated state's data center load is structurally harder than in PJM/ERCOT because there is no LMP market for capacity sales; new gen has to either contract with the utility or go BTM.

The honest read: EVRG is not the biggest beneficiary in the sector by absolute GW (that is AEP, Duke, Southern). It is one of the **higher-growth-rate, more concentrated** beneficiaries on a per-share basis, with comparatively constructive two-state regulators.

## Bull case — technical
The technical conditions for outperformance:

1. **The 2.5 GW LLPS book ramps on schedule** — first ESA contributes early 2027 [4]. This requires the Viola CCGT (1/1/2029 ISD) and McNew (1/1/2030 ISD) to land on time. Mitsubishi PIE delivery, Kansas PSD air permit already in hand, KCC settlements already approved [12] — the leading indicators are favorable.
2. **Tier 2 pipeline (1.5–3 GW) converts to signed ESAs over the next 18 months.** This is *not* in current capex/EPS guidance and represents the upside [4]. Each incremental GW of LLPS load drives ~$X B of incremental rate base (utility math: ~$2–3 B per GW of integrated capacity), which compounds at the allowed ROE.
3. **LLPS tariff withstands appellate / consumer-advocate challenge.** Constructed with Sierra Club concurrence [1], collateral and minimum-bill provisions intact.
4. **The base rate of technology displacement is on EVRG's side.** Historical analogs (CPU→GPU took 8 years from CUDA 2007 to Volta 2017 for clear-cut displacement; on-prem→cloud took ~10 years) are slow; more importantly, the **electrification stack** — generation, transmission, transformers — has historically displaced *more slowly than software* because it requires concrete pours and copper. The "displacement" that bears worry about — distributed BTM nuclear (SMRs), behind-the-meter gas at hyperscaler scale — is on a 7–10 year timeline, behind EVRG's contracted ESA tenor of 16–17 years [4]. By the time SMRs or BTM scale, the LLPS contracts have already amortized.
5. **Connected to financials:** if Tier 2 converts even at midpoint (~2.25 GW incremental beyond plan), rate base CAGR plausibly extends from 12% toward 14%+; mgmt's "8%+ EPS growth from 2028" guide [4] becomes 9–10%, and EVRG re-rates from 19× toward Duke's 20–21× or higher. Stock at ~$95–100 in 18 months on consensus EPS of ~$4.55 × ~21× = $95.

## Bear case — technical
A short-seller who reads the stack would write:

1. **Hyperscaler capex digestion.** Meta and Google have publicly committed to KC; both can renegotiate or delay. Meta's Phase 1 came online before LLPS, so it sits on legacy industrial rates [3]; future Meta phases sit on LLPS only if Meta opts in, and Meta has demonstrated (Hyperion, Louisiana) it will fund BTM gas plants when a utility tariff is unfavorable [19]. The minimum-bill is enforceable but a renegotiation cycle would still pressure equity.
2. **Long-lead equipment slip is a 12–18 month event.** EVRG claims slot security but does not disclose vendor confirmations publicly. A six-month slip on Viola or McNew shifts revenue out of 2029, pressures the FFO/debt 14–15% target [4], and forces incremental equity issuance beyond the planned $700–900M/yr ATM.
3. **LLPS gets revisited.** The minimum-bill structure is novel for both states; if a Tier 1 customer downsizes and the minimum bill triggers headlines about "ratepayers paying for unused gas plant," consumer advocates can re-open the docket. Earthjustice-aligned interveners are already analyzing these contracts [16][17].
4. **Equity dilution.** $3.3 B of common equity 2026–2030 [2] against $18.85 B market cap = ~17% dilution over 5 years; if executed at lower-than-current prices (rate environment, recession), accretion gets cut.
5. **Stranded-coal cost overhangs.** ~4,500 MW of coal retirements over 20 years [8]; accelerated retirement under future EPA/state pressure could leave undepreciated balances seeking recovery — fine if commissioners allow it, expensive if not.
6. **The base rate of regulator generosity in periods of cost increases is *not* favorable.** When rates rise quickly (gas plant capex, transmission), residential rate fatigue creates political pressure on PSCs to disallow recovery. Missouri specifically has historical episodes of disallowance.
7. **Connected to financials:** at 19× FWD, EVRG already trades 1–2 turns above the 5-year regulated-utility average. A miss on Tier 2 conversion plus a coal-recovery disallowance could compress the multiple to 16–17×, with EPS of $4.20 → $67–72 stock, ~15–18% downside.

## Market view check
At $81.78 / 19.3× forward / EV/EBITDA 12.5×, EVRG trades roughly in line with Duke (~20×) and AEP (~19.5×), at a discount to NextEra (~28×) and Constellation (~26×), and at a discount to Southern (~24× — but Southern has Vogtle in rate base). Consensus PT $86.57 implies ~6% upside; the average sell-side note appears to credit the announced 2.5 GW LLPS book and roughly half of management's 7–8% load growth claim, but **does not price Tier 2 (1.5–3 GW) conversion**. The technical reality I read is that the *hard* parts of the value chain — turbine slots, regulator-blessed tariff, existing nuclear in the mix, two-state franchise — are largely in hand; the *soft* parts — Tier 2 customer signings, equity issuance pricing, no-disallowance regulatory cycle — are not. Spot pricing is consistent with ~50/50 odds on Tier 2; the asymmetry tilts mildly favorable, not screaming.

## 90-day falsifiers
Specific events between now and August 2026 that would update the thesis:

- **Q2 2026 EPS print (early August):** management guided 17–19% YoY growth [4]; a miss vs. that range *with* a Tier 2 announcement is fine; a miss *without* Tier 2 progress is bearish.
- **Kansas IRP filing (Q2 2026 expected) [4]:** does Evergy raise the 6,000 MW firm-dispatchable plan? Watch for incremental gas turbine additions beyond Viola/McNew/Mullin Creek.
- **Missouri 2026 IRP filing [4]:** symmetric.
- **Sixth ESA announcement (Tier 2 → signed):** material upside catalyst; would lift rate-base CAGR estimate above 12%.
- **Missouri Metro rate case interim orders:** disallowance language on data-center cost allocation = bearish.
- **Q2 GE Vernova / Mitsubishi Power earnings disclosures of EVRG-named slot reservations:** independent confirmation of the "turbine reservations beyond ESAs" claim.
- **Hyperscaler Q2 capex updates (META, GOOG, MSFT prints late July / early August):** any sequential capex *cut* >10% is bearish for the entire utility-AI complex; sequential raise is bullish.
- **SPP queue Q2 update / GIA execution count:** confirms transmission backlog hasn't reopened.
- **Any LLPS appeal filed by a Missouri or Kansas consumer-advocate group:** materially bearish — the tariff is the load-bearing wall.

## What I could not verify
- Specific MW breakdown of EVRG's existing fleet by fuel (sources gave ~12,500 MW total, 4,600 MW renewable, ~4,500 MW coal-retiring, but a clean current-year stack table was not in the public-facing summaries I retrieved [8]).
- Whether EVRG has executed transformer/GSU slot reservations equivalent to its turbine reservations — management discussed turbines but I did not see an analogous transformer disclosure [4][15].
- Specific contracted minimum-bill **percentages** in each ESA (the call referenced minimum bill provisions and 16–17 year tenors but not the take rate) [4].
- Counterparty identities and credit ratings beyond the disclosed BBB+ rating of the fifth ESA customer [4].
- Allowed ROEs in current Missouri Metro and pending Missouri West rate cases — these drive the actual return on the $21.6B capex.
- Whether the 2.25 GW served by 2030 [4] is steady-state peak or annual-average; the gap matters for capacity-factor / revenue modeling.
- Whether Evergy's data-center contracts include carbon-attribute / 24x7 CFE matching commitments that obligate accelerated renewables build.
- Tier 2 customer identities — pipeline figure of 1.5–3 GW is mgmt-disclosed but unattributed.

## Sources
[1] https://www.utilitydive.com/news/evergy-capital-spending-meta-google-data-center/812647/ — retrieved 2026-05-10 — Capital plan $21.6B with $9.3B in generation; Meta/Google ESA context.
[2] https://www.investing.com/news/company-news/evergy-q4-2025-presentation-data-centers-and-216b-investment-plan-to-drive-68-eps-growth-93CH-4514266 — retrieved 2026-05-10 — 2026–2030 financing plan; $13.5B operating cash, $8.4B incremental debt, $3.3B common equity; 12% rate base CAGR.
[3] https://www.kshb.com/news/local-news/kansas/johnson-county/how-will-kcs-data-center-boom-impact-electric-bills-evergy-discusses-new-load-rate-for-large-customers — retrieved 2026-05-10 — LLPS rate context; Meta Phase 1 grandfathered.
[4] https://www.fool.com/earnings/call-transcripts/2026/05/07/evergy-evrg-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1'26 transcript: 2.5 GW LLPS + 0.45 GW Panasonic = 3 GW signed; Tier 2 1.5–3 GW; Tier 3 >10 GW; turbine reservations beyond ESAs; FY26 EPS $4.14–$4.34; equity issuance plan.
[5] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — GE Vernova 80 GW backlog stretching to 2029; ~20 GW/yr by mid-2026, 24 GW/yr by mid-2028.
[6] https://spp.org/news-list/southwest-power-pool-achieves-milestone-in-generator-interconnection-study-backlog-mitigation/ — retrieved 2026-05-10 — SPP cleared interconnection backlog Sept 2025; 24 clusters / 340 GW / 190 GIAs.
[7] https://www.utilitydive.com/news/kansas-michigan-data-center-large-load-evergy-consumers/805115/ — retrieved 2026-05-10 — KCC approval of Evergy LLPS tariff Nov 6, 2025.
[8] https://newsroom.evergy.com/Economic-growth-drives-new-generation-plans — retrieved 2026-05-10 — IRP plan: 5,100 MW renewables and 6,000 MW firm dispatchable over 20 years; 2,500 MW hydrogen-capable gas 2029–2032; 4,500+ MW coal retirement.
[9] https://stockanalysis.com/stocks/evrg/statistics/ — retrieved 2026-05-10 — Price $81.78, market cap $18.85B, EV $34.71B, fwd P/E 18.98, EV/EBITDA 12.46, EV/Rev 5.76, dividend yield 3.40%, beta 0.54, short interest 5.7% of float.
[10] https://www.stocktitan.net/sec-filings/EVRG/10-q-evergy-inc-quarterly-earnings-report-58821807a3d4.html — retrieved 2026-05-10 — Long-term debt $13,514 M Q1'26; ESA contract minimum consideration $8.7B over 10–17 years.
[11] https://www.financialcontent.com/article/barchart-2026-3-20-is-evergy-stock-outperforming-the-s-and-p-500 — retrieved 2026-05-10 — 52-week range $63.29–$85.27; YTD +11.8% as of 3/20/26.
[12] https://investors.evergy.com/news-releases/news-release-details/evergy-announces-two-new-705-mw-high-efficiency-natural-gas — retrieved 2026-05-10 — Viola (Sumner Co KS, ISD 1/1/2029) and McNew (Reno Co KS, ISD 1/1/2030) 705 MW CCGTs; Mitsubishi Power Americas PIE; bids competed against GE Vernova and Siemens.
[13] https://en.wikipedia.org/wiki/Wolf_Creek_Generating_Station — retrieved 2026-05-10 — Wolf Creek ~1,250 MW(e); 47%+47% Evergy ownership; license extended to 2045.
[14] https://www.evergy.com/landing/wolf-creek-nuclear-generating-station — retrieved 2026-05-10 — Wolf Creek operational profile.
[15] https://www.powermag.com/transformers-in-2026-shortage-scramble-or-self-inflicted-crisis/ — retrieved 2026-05-10 — Transformer lead times 128 wk std / 144 wk GSU; Wood Mac 30% supply deficit forecast.
[16] https://earthjustice.org/experts/mandy-deroche/new-report-examines-electricity-contracts-for-data-centers-and-other-mega-load-or-large-load-facilities — retrieved 2026-05-10 — Consumer-advocate framing of large-load tariff design.
[17] https://www.latitudemedia.com/news/the-unsettled-landscape-of-large-load-tariffs/ — retrieved 2026-05-10 — Large-load tariff legal landscape; minimum-bill / collateral provisions across utilities.
[18] https://www.latitudemedia.com/news/third-quarter-earnings-and-utilities-data-center-moment/ — retrieved 2026-05-10 — Comparable utility data-center commitments; AEP/Duke/Southern context.
[19] https://www.datacenterfrontier.com/hyperscale/article/55310441/ownership-and-power-challenges-in-metas-hyperion-and-prometheus-data-centers — retrieved 2026-05-10 — Meta–Entergy Hyperion 5.2 GW gas + 2.5 GW solar; BTM-style hyperscaler funding template.
[20] https://www.spglobal.com/energy/en/news-research/latest-news/electric-power/052025-us-gas-fired-turbine-wait-times-as-much-as-seven-years-costs-up-sharply — retrieved 2026-05-10 — Industry-wide turbine wait times 5–7 years; cost trajectory.