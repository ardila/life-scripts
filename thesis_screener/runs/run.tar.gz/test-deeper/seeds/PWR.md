# PWR — Quanta Services, Inc.

## Where this sits in the AI stack
PWR is the largest North American specialty contractor for the **electric power layer underneath the AI stack** — the physical work of stringing 765 kV transmission, building substations, manufacturing large power transformers (LPTs), interconnecting gas generation, and wiring the inside-the-fence electrical balance of plant for hyperscale data centers. It does not touch silicon, packaging, or any software runtime. Its workload is field construction and engineering EPC under multi-year master service agreements with investor-owned utilities (AEP, NiSource) and, since the 2024 Cupertino Electric acquisition, direct work for hyperscalers on the data center electrical fitout [1][8][12].

## Snapshot
- **Price:** $745.00 (2026-05-08 close) [2]
- **Market cap:** $111.79B [2]
- **52-week range:** $315.00 – $785.24 [2][9]
- **Forward P/E:** 51.6× (on mid-range 2026 adj. EPS guidance of $13.90) [2][6]
- **EV / NTM revenue:** ~3.9× (on $34.7–35.2B 2026 guide) [2][6]
- **EV / NTM adj. EBITDA:** ~32× (on $3.49–3.65B adj. EBITDA guide) [6][11]
- **Consensus 12-month price target:** $619.86 (implied -16.8% from spot; consensus is **stale** — the stock has run through it and analysts have not fully reset since the Q1 print and Investor Day) [2][9]
- **YTD total return:** ~+76% [10]
- **Short interest (% of float):** 3.14% [2]

The price-vs-target gap is itself a signal: sell-side has been chasing the technical thesis, not anticipating it.

## Moat — what it is physically made of
The "moat" decomposes into six distinct pieces, with very different decay rates:

**1. Craft labor pool — the deepest and least replicable.** Quanta self-performs ~85% of its work using ~70,000 craft employees, the largest such pool in North America [4][14]. Linework is a 4-year apprenticeship; journeymen linemen in IBEW jurisdictions command total comp packages of $85–110/hr [13]. The Department of Energy estimates the US needs 300,000+ additional electricians/linemen this decade against a retiring base [13]. A competitor with capital but no crews cannot accelerate training; PWR owns **Northwest Lineman College**, which trains ~6,000 lineworkers annually across four campuses — vertical integration on the binding input [4]. **Replacement cost: 5–10 years for a competitor to reach parity at scale; not solvable with M&A because the firms that own crews are PWR's acquisition targets.**

**2. 765 kV experience.** AEP's November 2025 partnership names PWR as **"the most experienced 765 kV constructor in the United States"** — a specific claim because 765 kV requires specialty stringing equipment, helicopter crews, hot-line techniques and right-of-way know-how that fewer than a handful of contractors can field [7]. The AEP capital plan is $72B (2026–2030); the partnership explicitly bypasses competitive bid for 765 kV scope [7]. **Replacement cost: probably 3–5 years for a focused entrant, but nobody is currently building this capability.**

**3. Master Service Agreements (MSAs).** Q1 2026 backlog growth was disproportionately MSA-driven, not lumpy fixed-price awards [3][15]. MSAs are cost-plus-style frameworks with multi-year terms, priority storm response and right-of-first-refusal mechanics. Switching costs for utilities are non-trivial because their crews are already integrated with PWR's. **Decay: low — but the moat is the relationship, which can be re-tendered every contract cycle. Reset risk is real if execution slips.**

**4. In-house LPT manufacturing.** Pennsylvania Transformer Technology (acquired 2023 for ~$300M, 1M sq ft Pittsburgh complex) gives PWR captive transformer supply at a moment when industry lead times for >100 MVA units run 120–210 weeks [5][16]. Quanta announced a $500–700M multi-year program to double this capacity, plus a partnership with AEP for extra-high-voltage transformers and circuit breakers [3][7][15]. **This is the most fragile leg of the moat — Hyosung, Hitachi, Prolec GE and Siemens Energy are all expanding US LPT capacity. PWR's edge is captive supply for its own EPC backlog, not market share in the merchant transformer market** [17].

**5. Data center inside-the-fence electrical (Cupertino Electric).** $1.54B acquisition in 2024; CEI has installed electrical for >20M sq ft of data centers and has the 6th-largest US electrical workforce [8]. This puts PWR on both sides of the fence: utility-side T&D AND customer-side electrical fitout. **Direct competitor at this layer is EMCOR**, which has scaled faster in pure electrical/mechanical for hyperscalers (RPOs $15.6B, +33% YoY) [18].

**6. Specialty fleet and engineering.** 2,000+ in-house engineers, plus helicopter and specialty equipment fleets for transmission [15]. This is real but commodifiable — competitors can rent or buy fleet; engineers can be hired. **Moderate decay.**

The honest read: the labor pool and 765 kV experience are the durable pieces. Transformers, MSAs, and data-center-electrical are erodible on 3–5 year horizons by well-capitalized competitors. The moat is **physical scarcity of skilled bodies**, not technology IP.

## AI buildout bottleneck map
Mapping PWR against the 24-month gating constraints:

| Bottleneck | PWR position | Evidence |
|---|---|---|
| Large power transformers (>100 MVA), 120–210 wk lead times | **Beneficiary AND supplier** (PTT, doubling capacity); buyer of competing units | [5][16] |
| Gas turbines (GE Vernova 80 GW backlog through 2029; sold through 2030 by end of 2026) | **Adjacent beneficiary** — does balance-of-plant for new gas peakers and CCGTs (NiSource/Zachry JV) | [19][20] |
| Lineworker labor (300k national shortage) | **Constraint owner** via NLC training pipeline | [4][13] |
| Interconnection queue (PJM median 55 months; 70 GW Dominion backlog) | **Beneficiary** — builds the substations and transmission that clear queues | [21] |
| Liquid cooling >100 kW/rack | **Indifferent** — not their layer |  |
| HBM / CoWoS-L | **Indifferent** |  |
| Behind-the-meter generation rise (Bloom 2.8 GW Oracle deal; AEP 1 GW Bloom offtake) | **Mixed**: BTM bypasses T&D (negative) but PWR still does on-site electrical balance-of-plant (partial offset) | [22] |
| Electrical contractor capacity for data center inside-the-fence | **Beneficiary** via Cupertino Electric; competing with EMCOR | [8][18] |
| 765 kV bulk transmission capability | **Near-monopoly** | [7] |

PWR is unusually well-positioned: it is *both* the chokepoint operator (lineworker labor) *and* a primary supplier to other chokepoints (transformers, substations). The one durable threat — behind-the-meter — is partially mitigated because BTM still needs electrical EPC.

## Competitive teardown
The competitor framing depends on which axis you measure. PWR is not displaced by one rival on all axes simultaneously.

- **EMCOR (EME)** — already at parity *inside the fence* for hyperscaler data center electrical/mechanical. EME's Q1 2026 RPOs $15.6B (+33% YoY), FY26 rev guide $18.5–19.25B [18]. EMCOR does **not** do bulk T&D or 765 kV work — different scope. On the data center electrical axis, the market is large enough for both, but EME is the harder competitor on margin in the building-services slice that Cupertino plays in.

- **MasTec (MTZ)** — ~$14B 2025 revenue, heavier renewables/communications/pipeline mix [23]. Direct overlap on distribution and some transmission but lacks 765 kV résumé and craft scale. Falling further behind on the AI-power axis specifically.

- **MYR Group (MYRG)** — T&D pure-play but ~$3.5B revenue scale, ~1/10 of Quanta. Genuine competitor for medium-voltage T&D and renewables interconnect but cannot bid the largest scopes alone [24].

- **Primoris (PRIM)** — Engineering on the Stargate site (buildings 3/4/5, 1.2 GW), $400–500M shortlisted data center work [25]. Stealth riser, but its data center exposure is single-digit % of revenue and largely site work / fiber rather than the electrical heart.

- **Zachry Group (private)** — JV partner with PWR on NiSource gas generation. Co-opted, not competitor — but a signal that Quanta is willing to share margin to access combined-cycle gas EPC where Zachry has scale.

The only competitive axis where PWR is genuinely vulnerable is the **inside-the-fence data center electrical fitout vs. EMCOR** — and even there, EME is winning, not threatening to displace. On 765 kV transmission and the broader craft-labor moat, **no current public competitor is investing at a rate that would close the gap in 3 years**.

## Bull case — technical
For the stock to outperform from here, several technical conditions need to hold:

1. **Hyperscaler capex stays at or above ~$500B/yr through 2027** [11]. This is the demand pull. Base rate on industrial-cycle infrastructure cycles (fiber 1998–2000, shale 2011–2014): peak capex periods last 4–7 years, not 2. We are roughly year 3.

2. **The grid remains the binding constraint, not chip supply.** As of April 2026, ~50% of planned 2026 US data centers are delayed or cancelled for *grid* reasons, not chip reasons [26]. If this persists, every gigawatt-class data center the hyperscalers want to land in 2027–2029 must run through PWR-type EPCs.

3. **Behind-the-meter is incremental, not substitutive.** BTM generation (Bloom SOFCs, gas peakers) accelerates total power deployed because it bypasses interconnection queues — and even BTM sites need electrical EPC for the 480V → MV step-up, paralleling switchgear, and connection to backup grid. PWR participates via Cupertino plus the NiSource/Zachry JV [12][22].

4. **The labor moat compounds.** As lineworker wages climb (~$200k for foremen, total IBEW packages $85–110/hr), the pricing power passes through to PWR cost-plus MSAs at near-100% margin retention [13]. Competitors trying to bid against PWR with smaller crew bases face structural disadvantage on schedule.

5. **AEP 765 kV and NiSource ramp on schedule.** AEP $72B/5-yr plan and NiSource ~$5–7B/5–7 yr opportunity convert from announcement to revenue 2027–2029 [3][7][12].

**Base rate check on platform-shift displacement risk to PWR's labor moat:** The closest historical analog is the 1990s telecom buildout. Specialty contractors (Dycom, MasTec predecessors) saw multiples expand to 30–40× during peak buildout, then compress over 2001–2003 as overbuild surfaced. The difference now is that *demand* in this cycle is from operating cash flow of 5 hyperscalers earning $500B+/yr, not from credit-financed CLEC startups. This makes the demand floor structurally higher, but does not invalidate the cyclicality.

Financial outcome: if 2030 EPS hits the mid-point of management's $21.60–$26.75 guidance [27] and the multiple compresses to 30× from 52× (which is still a premium), the stock prints ~$725 — flat from here. The bull case needs **multiple maintenance** or earnings outperformance vs guidance to deliver double-digit annual returns from the current entry.

## Bear case — technical
The honest short-side technical argument:

1. **Hyperscaler capex cycle is closer to peak than middle.** If MSFT/META/GOOG/AMZN combined capex growth decelerates from +60% YoY to flat in 2027, the marginal EPC bid environment loosens fast. Construction is high operating leverage on the way up; the symmetric effect on the way down means PWR's adj. EBITDA margin would compress materially before headline revenue rolls over.

2. **Behind-the-meter generation eats the T&D opportunity.** Bloom's $7.65B of data-center contracts in Q1 2026 alone, Oracle 2.8 GW, AEP 1 GW offtake — these projects deliberately route around the 5-year interconnection queue [22]. If 30% of the next 50 GW of data center load lands BTM, that is ~15 GW of new T&D that doesn't get built — directly negative for PWR's electric segment.

3. **The 765 kV "monopoly" is contestable on a 3–5 year horizon.** AEP's own historical 765 kV crews were built by AEP, not Quanta — PWR became the dominant contractor through hiring and acquisition. There is no patent or process IP. A motivated entrant (MYRG with PE backing, or a Korean E&C house following Hyosung into the US) could build a 765 kV practice if utility incumbents wanted multi-source supply.

4. **Cost-plus contract mix is asymmetric in a slowdown.** MSAs grow with utility capex; in a slowdown, the absolute work volume falls even though the margin per hour holds. PWR's $48.5B backlog is 1.4× revenue — historically high but not exceptional, and includes long-duration items (NiSource is 2027–2029 revenue) that are not yet locked in execution-mode.

5. **Multiple compression risk is the dominant equity risk, not earnings risk.** At 52× forward P/E and 32× EV/EBITDA, PWR is priced like a software platform, not a construction company. Compare: Fluor (FLR) and Jacobs (J), both engineering peers, trade at 15–20× forward. The PWR premium is justifiable on growth and moat, but the **delta** is the entire risk: a re-rating to 30× on stable earnings = -42%, with no operational catastrophe required.

6. **AI demand normalization.** If foundation-model revenue growth at OpenAI/Anthropic/Google decelerates (e.g., enterprise saturation on chat-style products), hyperscaler ROI math on the buildout deteriorates. The buildout doesn't stop — sunk capex is sunk — but **incremental** orders past 2027 ease.

A short-seller would also note: the consensus 12-month price target ($619.86) sits 17% *below* the current price. The sell-side, even chasing the rally, doesn't see further upside.

## Market view check
At $745, PWR trades at 52× forward P/E and 32× NTM EV/EBITDA — a software-style multiple on a labor-intensive contractor. The implied terminal economics require either (a) earnings hitting the high end of the 2030 $21.60–$26.75 management range AND multiple holding at ~30×, or (b) management's $2.4T TAM through 2030 [27] proving conservative. The market is pricing the bullish read of the technical thesis: durable 15–20% EPS CAGR through 2030, with the labor and 765 kV moats both holding. **My disagreement is with the price, not the thesis.** The technical reality (labor scarcity, transformer integration, 765 kV experience, MSA stickiness) is real and durable; the price assumes none of the bear cases materialize. The asymmetry is therefore poor at the current entry: limited multiple expansion left, meaningful compression risk, but the long-term operational moat is among the most durable in the AI-adjacent universe. A pullback to ~$550 (30–35× forward, ~3.0× EV/revenue) would offer a much better entry on an identical thesis.

## 90-day falsifiers
Specific, observable events that would update the thesis between now and ~August 2026:

- **Q2 2026 earnings (late Jul/early Aug):** Watch backlog trajectory (must hold above $48B), MSA renewal cadence with top-10 utility customers, and whether data center segment growth holds at the 70–110% directional range guided in Q1 [3][15]. A book-to-bill print below 1.0× would be the first crack.
- **Hyperscaler Q2 2026 capex updates (MSFT/META/GOOG/AMZN, late Jul):** Any reduction in 2026 capex guidance >10% sequentially is the cleanest bear signal for PWR. Conversely, confirmed acceleration into 2027 supports the bull.
- **AEP 765 kV project schedule update:** Any disclosure of slippage on Phase-1 Wyoming-Jacksons Ferry-style projects or on the broader $72B plan would directly impair the 765 kV monopoly narrative.
- **Bloom Energy / GE Vernova additional BTM mega-deals:** A single >2 GW behind-the-meter agreement signed by Meta or Google routing around the grid would meaningfully validate the bear case on T&D substitution.
- **NiSource / Zachry JV milestone:** First substantive contract value disclosure or scope change. The $5–7B opportunity should start showing in backlog reconciliations in 2H26.
- **Insider activity:** CEO Duke Austin sales above historical 10b5-1 cadence.
- **Competitor capability announcements:** MYRG or MTZ announcing a 765 kV crew build-out or a public utility splitting AEP's work to a second contractor.

## What I could not verify
- The exact concentration of PWR's backlog tied to AI/hyperscaler-driven workload (management discloses segment-level but not customer-specific data center share).
- The fixed-price vs. cost-plus split inside the $48.5B backlog. Management commentary suggests MSA-heavy, but the AEP 765 kV scope economics are not public.
- PWR's projected share of US LPT capacity post-PTT expansion vs. Hyosung's announced ramp to 250 units/yr from Memphis [17] and Hitachi's $250M Virginia/Missouri/Mississippi build [17].
- Whether the "most experienced 765 kV constructor in the United States" claim from AEP is contractually exclusive or descriptive — i.e., whether other contractors are formally barred or just second-tier on the bid list [7].
- The actual replacement cost in years for a competitor to build a 70k-craft workforce at parity. My "5–10 years" estimate is inference from apprenticeship cycle math (4 years for a journeyman + 3 years to a foreman + recruiting saturation), not a sourced industry estimate.
- Quanta's true exposure if a recession arrives mid-cycle. The company has not been stress-tested by a hyperscaler capex pause in its current scale configuration.

## Sources
[1] https://www.quantaservices.com/ — retrieved 2026-05-10 — Quanta corporate overview; craft workforce framing
[2] https://stockanalysis.com/stocks/pwr/statistics/ — retrieved 2026-05-10 — May 8 2026 close $745, market cap, FwdP/E, EV/Rev, EV/EBITDA, short interest
[3] https://www.prnewswire.com/news-releases/quanta-services-reports-first-quarter-2026-results-302758147.html — retrieved 2026-05-10 — Q1 2026 results: $7.87B revenue, $48.5B backlog, raised guidance
[4] https://www.quantaservices.com/companies/northwest-lineman-college-nlc — retrieved 2026-05-10 — NLC training scale, 6,000+/yr, four campuses
[5] https://www.powermag.com/transformers-in-2026-shortage-scramble-or-self-inflicted-crisis/ — retrieved 2026-05-10 — LPT lead times 120–210 weeks; WoodMac survey data
[6] https://finance.biggo.com/news/US_PWR_2026-04-30 — retrieved 2026-05-10 — Q1 2026 earnings call detail: $34.7–35.2B rev guide, $13.55–14.25 EPS guide, $3.49–3.65B adj EBITDA
[7] https://www.prnewswire.com/news-releases/aep-and-quanta-services-announce-strategic-partnership-to-advance-transmission-and-power-infrastructure-302604662.html — retrieved 2026-05-10 — AEP-Quanta partnership; "most experienced 765 kV constructor"; $72B AEP plan
[8] https://www.prnewswire.com/news-releases/quanta-services-acquires-cupertino-electric-inc-a-premier-electrical-infrastructure-solutions-provider-to-the-technology-and-renewable-energy-industries-302200361.html — retrieved 2026-05-10 — $1.54B CEI acquisition; >20M sq ft data center electrical installed
[9] https://public.com/stocks/pwr/forecast-price-target — retrieved 2026-05-10 — Consensus analyst median PT ~$492 (pre-rally print) to $619 (latest aggregator); 52-week range
[10] https://meyka.com/blog/pwr-quanta-services-earnings-beat-q2-2026-results-0105/ — retrieved 2026-05-10 — YTD return ~+76% (reported in May 2026)
[11] https://fortune.com/2026/04/30/big-tech-hyperscalers-will-spend-700-billion-on-ai-infrastructure-this-year-with-no-clear-end-in-sight-eye-on-ai/ — retrieved 2026-05-10 — Hyperscaler capex framing $500–700B
[12] https://www.prnewswire.com/news-releases/building-upon-decades-of-power-generation-experience-quanta-expands-its-total-solutions-platform-and-announces-its-selection-by-nisource-to-provide-power-generation-and-grid-infrastructure-solutions-for-a-large-load-customer-302599432.html — retrieved 2026-05-10 — NiSource selection; 3 GW; JV with Zachry on CCGT
[13] https://fortune.com/2026/03/02/ai-data-centers-electrician-shortage-gen-z-training-careers/ — retrieved 2026-05-10 — Electrician shortage; IBEW wages $59.50/hr journeyman, $200k foreman; 300k+ needed this decade
[14] https://www.utilitiesbusinessreview.com/quanta-services — retrieved 2026-05-10 — 85% self-perform; 70,000-employee craft workforce
[15] https://www.fool.com/earnings/call-transcripts/2026/04/30/quanta-pwr-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q1 2026 transcript: 2,000+ engineers, off-site fab 6.7M sq ft, MSA-driven backlog growth
[16] https://www.tdworld.com/utility-business/article/21277195/quanta-buys-pennsylvania-transformer-manufacturer — retrieved 2026-05-10 — PTT acquisition $300M, 1M sq ft Pittsburgh complex
[17] https://www.powersystems.technology/news/hyosung-to-expand-u-s-transformer-production-amid-rising-demand-transformer-technology-news.html — retrieved 2026-05-10 — Hyosung Memphis ramp to 250 units; Prolec GE, Hitachi expansions
[18] https://www.investing.com/news/company-news/emcor-q1-2026-slides-record-revenue-ai-boom-lifts-backlog-93CH-4646176 — retrieved 2026-05-10 — EMCOR Q1 2026 RPOs $15.62B; FY26 rev guide $18.5–19.25B
[19] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — GE Vernova 80 GW backlog into 2029; slots sold through 2030 by end of 2026
[20] https://www.power-eng.com/gas/turbines/data-centers-drive-record-surge-in-ge-vernova-power-equipment-orders-as-turbine-slots-tighten-through-2030/ — retrieved 2026-05-10 — Gas turbine equipment supercycle; 20% data center load
[21] https://www.zeroemissiongrid.com/insights-press-zeg-blog/pjm-2026-cycle/ — retrieved 2026-05-10 — PJM queue; 55-month median; 70 GW Dominion backlog
[22] https://www.microgridknowledge.com/data-center-microgrids/article/55371018/hyperscaler-oracle-raises-bloom-energy-fuel-cell-commitment-to-nearly-3-gw — retrieved 2026-05-10 — Oracle 2.8 GW Bloom; AEP 1 GW offtake; behind-the-meter trend
[23] https://beyondspx.com/quote/MTZ/mastec-s-infrastructure-powerhouse-fueling-growth-through-diversification-and-execution-nyse-mtz — retrieved 2026-05-10 — MasTec ~$14B revenue, renewables/communications mix
[24] https://matrixbcg.com/blogs/competitors/myrgroup — retrieved 2026-05-10 — MYRG competitive position vs. Quanta
[25] https://www.industrialinfo.com/news/article/primoris-picks-up-epc-work-amid-ai-demand-surge-across-us--344083 — retrieved 2026-05-10 — Primoris Stargate engineering; $400–500M shortlisted
[26] https://europeanbusinessmagazine.com/technology-data-centre-power-crisis-ai-growth-2026/ — retrieved 2026-05-10 — ~50% of 2026 US data center builds delayed for grid reasons
[27] https://www.themarketsdaily.com/2026/04/04/quanta-services-investor-day-ceo-pegs-2-4t-tam-targets-21-60-26-75-eps-by-2030.html — retrieved 2026-05-10 — Investor Day: $2.4T TAM through 2030, $21.60–$26.75 2030 EPS target, 15–20% growth