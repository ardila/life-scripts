# GOOGL — Alphabet Inc.

## Where this sits in the AI stack
Alphabet is the only company on Earth that owns the **full vertical stack**: a custom training/inference silicon line (TPU v7 "Ironwood" GA, v8 "Sunfish/Zebrafish" announced for late-2027) [1][2][5], the compiler/runtime that targets it (XLA + JAX) [10], a building-scale optical fabric (Jupiter, ~13 Pb/s, OCS-based) [8][9], the data-center campus and 1 MW-rack power/cooling system [22], the frontier model (Gemini 3, currently #1 on LMArena at 1501 Elo) [23], the consumer surface (Search, AI Mode, Gemini app at ~750M MAU) [24], and an emerging ad/agentic monetization layer. It both *operates* a hyperscale fleet for first-party workloads (Search, YouTube, Gemini training+serving) and *sells* TPU capacity to third parties via GCP — including Anthropic, Apple, Safe Superintelligence, and (per reports) Meta and OpenAI [3][14][26]. Workload mix straddles frontier training, large-batch inference, and real-time consumer serving.

## Snapshot
- **Price (GOOGL):** ~$400.80 (2026-05-08 close) [17]
- **Market cap:** ~$4.81T (combined GOOGL+GOOG) [17]
- **52-week range:** $151.67 – $402.00 [18]
- **Forward P/E:** ~27.8× on consensus FY27 EPS (sources span 27.8×–32×) [17][27]
- **EV / NTM revenue:** ~9.5× — *inference, not directly cited; derived from $4.8T mcap less ~$95B net cash on ~$500B FY26E revenue (Q1 2026 annualized at $440B/run-rate)* [6]
- **Consensus 12-month price target:** ~$406 (essentially flat to spot) — distribution shows clusters at $390 (sell-side base) and $450 (bull, ~30× FY27) [18]
- **YTD total return:** ~-1% (was ~+25% YTD in early Feb 2026 before AI-capex digestion concerns) — *inference from 52-week-range positioning; not directly cited*
- **Short interest (% of float):** ~0.64%–1.37% (78–80M shares, ~2.5 days to cover); a non-event [28]

## Moat — what it is physically made of

**1. The TPU world-size moat (most important).** A single Ironwood "superpod" addresses **9,216 chips** as one logical accelerator over a 3D torus of 9.6 Tb/s ICI links carried through MEMS optical circuit switches [1][2]. NVIDIA's flagship topology — NVL72 today, NVL576 on roadmap — tops out an order of magnitude smaller; beyond that you stitch with InfiniBand or Spectrum-X over copper-then-optical, with worse bandwidth tapers and collective-comms latencies. For frontier training of trillion-parameter models the natural sharding (data×tensor×pipeline×expert parallel) maps cleanly onto a 9k-chip flat torus and far less cleanly onto rail-optimized fat-trees of NVL72 islands. **This is a physics moat, not a software one** — it lives in MEMS mirror count, fiber routing, and Google's >25-year datacenter-fabric build-out (Jupiter is now in its 5th generation) [9]. Replicating it requires an OCS supply chain (Google is the only hyperscaler running them at scale today) and the systems software to drive dynamic topology reconfiguration during training.

**2. XLA/JAX + Pathways software stack.** JAX compiles directly to XLA, which targets the TPU's systolic array natively. Gemini, Gemma, and (per Apple's own paper) Apple's foundation models are all trained on JAX/XLA on TPU [10][11]. PyTorch-on-TPU exists via PyTorch/XLA but with a real performance haircut on idiomatic PyTorch code — this is the chief migration friction. Google has been actively closing this gap (PyTorch/XLA 2.7 + JAX bridge) to widen the TAM beyond JAX-native shops [10]. Versus CUDA's ~17-year, ~4M-developer ecosystem moat, JAX/XLA is narrower and deeper: fewer developers but the developers that matter (frontier labs).

**3. Codesign of silicon, network, and compiler.** Ironwood was co-designed by Google, Broadcom (SerDes, ASIC physical implementation), TSMC (3nm N3), and Samsung (HBM3e, ~60% share of TPU HBM supply via Broadcom) [4][7][12]. The TPU 8 fork — Broadcom-led "Sunfish" (training) and MediaTek-led "Zebrafish" (inference) on TSMC N2 — is a deliberate split that lets each chip drop general-purpose silicon (no graphics, no FP64, minimal control-plane) and trades flexibility for ~2× perf/W [12][13]. This codesign loop is replicable in principle (AWS Trainium, Meta MTIA, MS Maia) but Google has a 10-year head start and a working frontier model to feed back ground-truth workload signal.

**4. Power and cooling at GW scale.** Google is shipping liquid cooling at GW scale across 2,000+ TPU pods at 99.999% uptime [22]. Ironwood pods are ~10 MW each, and Google has published its +/-400 VDC, 1 MW-rack reference design at OCP [22]. Each pod added replaces a meaningful share of rival hyperscaler capex on power infrastructure that they don't yet have liquid-loop expertise in.

**5. Captive demand.** Even if no one ever bought a TPU externally, Google would need ~3+ GW of compute for first-party Gemini training, AI Overviews (2B MAU) [25], and Search-with-AI serving. This *baseline internal demand* — paid for out of an ad business throwing off ~$80B+ in operating cash — is what underwrites the per-unit cost curve that lets Google undercut NVIDIA on external pricing [11][2].

**Durability ranking** (my read): physics fabric (very durable, 5-10y) > captive demand (durable while Search/YouTube hold) > codesign loop (durable but copyable) > XLA/JAX (medium; PyTorch convergence is the risk) > brand. Critically, **none of the moat is "ad business profits subsidizing AI"** — the ad business funds capex, but the technical moat lives in OCS/HBM/SerDes/compiler artifacts, not in cross-subsidy.

## AI buildout bottleneck map

| Bottleneck (next 24 mo) | Status | GOOGL position |
|---|---|---|
| **TSMC CoWoS-L allocation** (2026 sold out) [21] | NVIDIA largest taker; Google #2; Meta reportedly *transferring* its CoWoS share to Google for TPU as Meta moves to TPU [21] | **Beneficiary** — secured allocation; can pull share from NVIDIA tail |
| **HBM3e / HBM4 supply** (~20% price hike '26) [21] | Samsung supplying 60%+ of TPU HBM3e via Broadcom; Samsung HBM4 reportedly passed Broadcom qualification ahead of SK hynix for Google [7] | **Supplier-locked beneficiary** — Samsung relationship is a hedge against the SK hynix/NVIDIA primary axis |
| **Power / grid interconnect** | Multi-GW campus contracts; Intersect Power acquisition closed March 2026 (this is why the FY26 capex guide rose by $5B) [27] | **Constraint owner via M&A** — closer to vertical integration of generation than peers |
| **Liquid cooling at >100 kW/rack** [22] | 2,000+ pods deployed at GW scale, 99.999% uptime; 1 MW-rack design published | **Beneficiary / reference designer** |
| **Optical interconnect supply** (LPO, CPO) | Operates own MEMS OCS layer for ~6+ years in production [9] | **Constraint-immune** — only hyperscaler running OCS at scale |
| **Frontier kernel/compiler talent** | XLA team at Google; the JAX team is the JAX team | **Beneficiary** |
| **Frontier data quality** | Owns YouTube (only public video corpus at scale), Search query stream, Gmail/Workspace (with consent constraints) | **Beneficiary** |
| **Electrical contractor / siteworks capacity** | Same constraint everyone faces | **Indifferent** |

The map is unusually favorable: GOOGL is a beneficiary or constraint-owner on every gating input except contractor labor.

## Competitive teardown

**NVIDIA (the incumbent).** On peak-FLOP and HBM bandwidth, GB300 narrowly leads Ironwood per-chip (Ironwood "nearly closes the gap" with ~1 year delay) [2]. On **scale-up world size**, TPU leads ~128× (9,216 vs 72). On **TCO**, SemiAnalysis estimates Ironwood is ~44% lower than GB200 internally, ~30% cheaper at external rate-card after Google + Broadcom margin take [2][30]. On **ecosystem**, NVIDIA is overwhelmingly ahead — CUDA/cuDNN/cuBLAS/CUTLASS/NCCL/Triton/TensorRT/Megatron is the default for ~95% of new model code on GitHub. The asymmetry: NVIDIA wins the long tail (every startup, every researcher), Google wins the *head of demand* (frontier labs that can amortize a port: Anthropic, Apple, SSI, plausibly Meta and OpenAI) [3][14][26]. The structural risk for NVIDIA is that frontier labs are now the largest spenders, and they're the segment where the port economics most clearly favor TPU.

**Anthropic deal as proof point.** ~$200B over 5y, 5 GW, up to 1M TPUs [3][14]. On a $40k/chip-equivalent basis this is an explicit revealed-preference bet against NVIDIA at frontier scale.

**AMD (MI355/MI400).** Closed FP8 gap meaningfully on per-chip but ROCm software stack still has fewer person-years than CUDA. Multi-node scaling fabric (Ultra Ethernet) is not yet at parity with NVLink72, let alone OCS pods. **Threat to Google: low for next 24 months** — both companies are competing for the residual that doesn't go to GPUs, not directly with each other.

**AWS Trainium2/3, Microsoft Maia, Meta MTIA.** All in-house, none sold externally. Trainium2 is shipping in volume to Anthropic but Anthropic's revealed preference (the new 5 GW deal is Google, not AWS) suggests TCO gap [14]. Meta entering TPU talks while continuing MTIA development is the strongest market signal that internal-only ASIC programs are not closing the gap to TPU on schedule [3].

**OpenAI.** Reports that OpenAI will use TPU + the simultaneous renegotiation of better NVIDIA pricing via TPU threat [26] mean OpenAI is now multi-silicon in production. Symbolically important; financially a marginal contribution because OpenAI's main bet is on Microsoft/Stargate compute with NVIDIA + custom silicon.

## Bull case — technical

The bull thesis is **not** "Cloud accelerates from 63% to 80% growth" [6]. It is:

1. **Frontier training spend concentrates in 2027–28 around clusters of size 50k–500k chips.** At that scale, NVL576-of-72-chip-islands is fundamentally less efficient than 9k-flat-torus pods stitched via Jupiter. *Base rate caveat*: large-scale-up architectural advantages have historically been gravity wells (CDC→Cray, vector→SIMD, GPU→GPU-cluster). A scale-up advantage of 100×+ at the natural training shard size is the kind of thing that compounds — but only if frontier model compute keeps scaling. **Falsifier:** if MoE/sparsity reduces dense training-cluster size needs and inference dominates capex, the OCS-fabric moat narrows toward TPU 8i (Zebrafish) — still favorable, but more contested.
2. **AI Overviews + AI Mode + ad-monetized Gemini turn into >$50B incremental revenue by FY28** as Google ships ad units inside the AI experiences (already ~25.5% of AI Overview SERPs carry ads vs. ~3% in Jan 2025) [25]. This is the demand side that pays for the supply side.
3. **Anthropic and Meta TPU deals validate the playbook**, prompting at least one more frontier lab to commit (xAI, SSI, or Mistral) over the next 12 months [3].
4. **Base rate on platform moats:** CUDA's 17-year run says incumbent ML accelerator moats are durable. But CUDA's run has been *against weaker challengers* (AMD, Intel Habana, Graphcore, Cerebras). It has not yet been tested against an opponent that has its own frontier model + free internal demand + a working compiler stack + a structurally different fabric. The right base rate is "first-time challenge by a vertically-integrated peer," which has no clean precedent — closest analog is Apple Silicon vs. Intel, where the displacement was decisive within 4 years on a more constrained platform (laptop). Treating Google as having ~30–40% probability of taking >20% frontier-training share by 2028 is consistent with that base rate.

Financial translation: if Cloud holds >50% growth into FY27 with TPU-led mix shifting margins, FY28 Cloud op income could plausibly print >$60B vs. consensus closer to $35–40B; that alone moves SOTP fair value toward $480–500. *Inference; not directly cited.*

## Bear case — technical

A short-seller who reads SemiAnalysis would write something like:

1. **The TPU TCO advantage assumes Google's internal cost.** External rate cards are ~30% below NVIDIA but the gap shrinks at the GPU spot price, and **Google has to keep both Broadcom's and its own margin take** to make TPU-as-a-service profitable. Anthropic's $200B is impressive but the *gross margin* on that revenue is unclear — Google may be capacity-constrained but margin-thin on the external book [14].
2. **PyTorch convergence erodes JAX/XLA's structural lock.** torch.compile is closing the gap; PyTorch/XLA's JAX bridge cuts both ways: Google gets PyTorch users on TPU, but the work that goes into that bridge also makes it easier to leave [10].
3. **NVIDIA NVL576 + Spectrum-X + CPO in 2027 closes the world-size gap.** If Vera Rubin Ultra ships at NVL576 or larger with co-packaged optics, the structural fabric advantage compresses from 128× to ~16× and at the relevant model size the difference may be inside the noise of MFU achieved.
4. **Sundar's 1 MW racks and 9k-chip pods are stranded if frontier model size plateaus.** Inference workloads — including Gemini's own — fit in much smaller blast radii. If 2026–27 is the year capex outpaces revenue (and ad-monetized Gemini misses), the ROI math on the >$180B/yr capex run-rate gets very ugly — Alphabet's depreciation schedule is already accelerating and the operating-leverage thesis only works if utilization holds.
5. **Antitrust overhang.** The Mehta ruling (Sept 2025) banned exclusive default-distribution deals and required data sharing; the DOJ has cross-appealed asking again for Chrome divestiture, with arguments expected late 2026 / early 2027 [16]. The remedies do not yet bite ad revenue but the *unbundling pressure* is real — and a Chrome divestiture, while currently unlikely, would be a discrete ~$50–100B event-driven loss.
6. **AI Overviews are eating publisher click-throughs (organic CTR -15% to -61% on affected queries; 93% of AI Mode queries generate no outbound clicks)** [25]. Ad monetization in AI surfaces has to *replace*, not just supplement, the lost performance-marketing top-of-funnel. If RPM in AI surfaces lags traditional Search by >40%, blended Search ad revenue compresses even as AI usage rises.

The bear case is not silly. The most uncomfortable point is #1 — we have very little visibility into TPU-as-a-service unit economics versus the captive cost.

## Market view check

At ~$400 / 27.8× FY27 EPS, GOOGL trades at a modest premium to its 5-year mean and a *discount* to MSFT (~32×) and a *premium* to META (~25×) on a P/E basis. The market is implicitly assuming: (a) Cloud growth normalizes from 63% to ~30–40% by FY28, (b) Search ad revenue grows mid-single-digits despite AI Overview cannibalization, (c) capex peaks around $200B in FY27 and starts to lever, (d) no Chrome divestiture, (e) Waymo remains optionality rather than a numerator. That bundle of assumptions is roughly right but **does not fully credit the OCS/world-size structural advantage** — the price is consistent with "Google is one of three credible AI infrastructure winners" rather than "Google is the only vertically-integrated AI stack on Earth." My read is mildly mispriced to the upside (~10-15% undervalued vs. technical reality) with two-sided tail risk: the upside tail (~$500+) requires another 1–2 frontier labs committing externally; the downside tail (~$300) requires capex digestion + AI ad RPM disappointment + adverse antitrust ruling.

## 90-day falsifiers

Specific events to watch by ~August 2026:

- **Q2 2026 earnings (late July).** Cloud growth deceleration to <50% YoY would reset the TPU narrative; capex guide cut by >$10B sequentially would break the supply-confidence story; backlog growth slowing below ~$40B QoQ would similarly damage [6].
- **MLPerf Training v4.0 / Inference v6 submissions** (typically June/September). Independent submissions of TPU v7 vs. GB300 on Llama-class architectures at multi-thousand-chip scale would resolve the "44% TCO" claim from internal Google estimates to public benchmark.
- **Apple WWDC (June 2026).** Apple's Apple Intelligence has trained on TPU v4/v5p [11]. A move to in-house ANE-only training, or a switch to Anthropic-on-AWS, would cut a lighthouse customer; a deepening of TPU usage would confirm the moat.
- **Meta TPU deal finalization.** Reports describe "advanced talks" [3]; a signed multi-GW deal in the next 90 days would be the second-largest external validation after Anthropic.
- **Samsung HBM4 ramp data points.** If Samsung HBM4 yield disappoints on Broadcom qualification and SK hynix takes lead, Google's TPU supply chain narrative weakens [7].
- **DOJ appeal calendar.** Briefing schedules set in this window will tell us whether Chrome divestiture re-enters the live remedy menu in 2027.
- **Anthropic NVIDIA hedge.** Any sizable new Anthropic NVIDIA commitment (>$10B) in the next 90 days would suggest the TPU port has hit operational limits.

## What I could not verify

- **External-TPU gross margin.** I could not source a credible estimate of unit economics on TPU-as-a-service vs. internal use; the SemiAnalysis "30% cheaper externally" implies meaningful margin but I don't have a Google-disclosed number.
- **Exact split of FY26 $180–190B capex** between TPU servers, NVIDIA GPUs (Google still buys some), data-center shells, and land/power. Q4 2025 was disclosed as ~60/40 server vs. land/networking but not the silicon mix [27].
- **Internal vs. external TPU fleet share.** Widely reported as predominantly internal but I could not source an explicit % for 2026.
- **CoWoS-L allocation share.** Reports of Meta transferring allocation to Google [21] are sourced to industry trackers, not confirmed by either company.
- **TPU 8t/8i performance claims** ("2.7× $/training over Ironwood v7e") are Google's own estimates from Cloud Next; no independent benchmark exists and the chips don't ship until late 2027 [12][13].
- **Actual Jupiter intra-pod latency / bisection bandwidth** in Ironwood-era deployments — Google's published numbers are 13 Pb/s aggregate but not the relevant per-collective metrics [8].
- **Waymo unit economics** — revenue line is clear (~$355M annualized) [19] but cost-per-mile and breakeven path are not.
- **Forward P/E base.** Sources span 27.8× to ~32× depending on whether they use FY26 or FY27 consensus and whether they strip stock-comp; consensus is fragmented.

## Sources

[1] https://docs.cloud.google.com/tpu/docs/tpu7x — retrieved 2026-05-10 — Ironwood/TPU7x official specs (192GB HBM3e, 7.37 TB/s, 9,216-chip pod, ICI 9.6 Tb/s).
[2] https://newsletter.semianalysis.com/p/tpuv7-google-takes-a-swing-at-the — retrieved 2026-05-10 — TPU v7 architecture, ~44% TCO advantage vs. GB200, 3D torus + OCS world-size argument.
[3] https://www.anthropic.com/news/google-broadcom-partnership-compute — retrieved 2026-05-10 — Anthropic's April 2026 multi-GW TPU/Broadcom commitment to Google.
[4] https://cloud.google.com/blog/products/compute/inside-the-ironwood-tpu-codesigned-ai-stack — retrieved 2026-05-10 — Ironwood codesign details (silicon + network + compiler).
[5] https://blog.google/innovation-and-ai/infrastructure-and-cloud/google-cloud/eighth-generation-tpu-agentic-era/ — retrieved 2026-05-10 — TPU v8 Sunfish/Zebrafish official announcement (April 2026 Cloud Next).
[6] https://www.cnbc.com/2026/04/29/alphabet-googl-q1-2026-earnings.html — retrieved 2026-05-10 — Q1 2026 results: $109.9B revenue, Cloud +63% to $20B, capex guide $180–190B.
[7] https://www.trendforce.com/news/2025/12/01/news-samsung-reportedly-supplies-60-of-google-tpu-hbm3e-set-to-remain-primary-supplier-in-2026/ — retrieved 2026-05-10 — Samsung 60%+ of Google TPU HBM3e via Broadcom; HBM4 lead.
[8] https://cloud.google.com/blog/products/networking/speed-scale-reliability-25-years-of-data-center-networking — retrieved 2026-05-10 — Jupiter at 13 Pb/s, 25-year evolution.
[9] https://research.google/pubs/jupiter-evolving-transforming-googles-datacenter-network-via-optical-circuit-switches-and-software-defined-networking/ — retrieved 2026-05-10 — Jupiter OCS/MEMS architecture (SIGCOMM 2022 paper).
[10] https://pytorch.org/blog/pytorch-xla-2-7-release-usability-vllm-boosts-jax-bridge-gpu-build/ — retrieved 2026-05-10 — PyTorch/XLA 2.7 + JAX bridge state of play.
[11] https://www.cnbc.com/2025/11/07/googles-decade-long-bet-on-tpus-companys-secret-weapon-in-ai-race.html — retrieved 2026-05-10 — TPU as Google's "secret weapon"; Apple/Anthropic/SSI customers; Apple Intelligence trained on v5p/v4.
[12] https://www.storagereview.com/news/google-announces-tpu-v8t-sunfish-and-tpu-v8i-zebrafish — retrieved 2026-05-10 — TPU v8 Sunfish (training, Broadcom) / Zebrafish (inference, MediaTek), TSMC N2, late 2027.
[13] https://www.nextplatform.com/compute/2026/04/24/with-tpu-8-google-makes-genai-systems-much-better-not-just-bigger/ — retrieved 2026-05-10 — TPU 8 superpod 9,600 chips, 121 EFLOPS FP4, 2 PB HBM, perf/W gains.
[14] https://techcrunch.com/2026/04/07/anthropic-compute-deal-google-broadcom-tpus/ — retrieved 2026-05-10 — Anthropic April 2026 next-gen TPU compute deal expansion; Anthropic ~$30B run rate.
[15] https://www.cnbc.com/2025/10/23/anthropic-google-cloud-deal-tpu.html — retrieved 2026-05-10 — Anthropic October 2025 1M-TPU / 1+ GW deal.
[16] https://fortune.com/2025/09/02/google-antitrust-remedy-ruling-exclusive-search-distribution-deals-chrome/ — retrieved 2026-05-10 — Mehta remedies (Sept 2025): no exclusive defaults, data sharing, Chrome not divested; DOJ appealing.
[17] https://stockanalysis.com/stocks/googl/ — retrieved 2026-05-10 — GOOGL price/market cap.
[18] https://www.marketbeat.com/stocks/NASDAQ/GOOGL/forecast/ — retrieved 2026-05-10 — Analyst PT distribution and 52-week range.
[19] https://techcrunch.com/2026/02/02/waymo-raises-16-billion-round-to-scale-robotaxi-fleet-london-tokyo/ — retrieved 2026-05-10 — Waymo $16B raise at $126B valuation; ride volumes.
[20] https://firstpagesage.com/seo-blog/google-vs-chatgpt-market-share-report/ — retrieved 2026-05-10 — Search vs. ChatGPT/Perplexity 2026 market-share split.
[21] https://www.fusionww.com/insights/blog/inside-the-ai-bottleneck-cowos-hbm-and-2-3nm-capacity-constraints-through-2027 — retrieved 2026-05-10 — 2026 CoWoS-L sold out; allocation dynamics including Meta→Google rumor.
[22] https://cloud.google.com/blog/topics/systems/enabling-1-mw-it-racks-and-liquid-cooling-at-ocp-emea-summit — retrieved 2026-05-10 — 1 MW rack design, +/-400 VDC, 2,000+ TPU pods at 99.999% uptime.
[23] https://blog.google/products/gemini/gemini-3/ — retrieved 2026-05-10 — Gemini 3 Pro launch (Nov 2025); LMArena 1501 Elo, GPQA 91.9%, AIME 95%.
[24] https://www.businessofapps.com/data/google-gemini-statistics/ — retrieved 2026-05-10 — Gemini ~750M MAU, AI Overviews ~2B MAU.
[25] https://www.digitalapplied.com/blog/google-ai-mode-75m-users-ads-in-ai-results-2026 — retrieved 2026-05-10 — AI Mode user counts; ad penetration of AI Overviews; CTR impact.
[26] https://www.datacenterdynamics.com/en/news/google-offers-its-tpus-to-ai-cloud-providers-report/ — retrieved 2026-05-10 — Google's external TPU customer initiative.
[27] https://www.aicerts.ai/news/alphabets-90b-capital-expenditure-surge-explained/ — retrieved 2026-05-10 — Alphabet capex trajectory and FY27 "significantly higher" guidance; Intersect Power M&A driver.
[28] https://www.marketbeat.com/stocks/NASDAQ/GOOGL/short-interest/ — retrieved 2026-05-10 — Short interest 78–80M shares, ~0.64–1.37% of float, days-to-cover 2.5.
[29] https://www.tomshardware.com/tech-industry/artificial-intelligence/google-deploys-new-axion-cpus-and-seventh-gen-ironwood-tpu-training-and-inferencing-pods-beat-nvidia-gb300-and-shape-ai-hypercomputer-model — retrieved 2026-05-10 — Ironwood vs. GB300 head-to-head positioning.
[30] https://www.spheron.network/blog/google-tpu-trillium-v6-vs-nvidia-b200-llm-inference/ — retrieved 2026-05-10 — TPU TCO/$ per-token economics versus NVIDIA at sustained inference scale.