# V — Visa Inc.

## Where this sits in the AI stack
Visa does not sell silicon, packaging, memory, networking, or training capacity. It operates a four-party card network (VisaNet) that authorizes, clears, and settles ~66B processed transactions per quarter and ~$3.7T in payments volume per quarter[3][5]. Its AI exposure is *adjacent*: (i) AI as input — proprietary deep-learning models (VAAI, VAAI Score) score 100% of VisaNet transactions in ~1ms and ~20ms respectively, with VAAI Score trained on 15B transactions and 182 risk features[8]; (ii) AI as channel — "Visa Intelligent Commerce" issues scoped tokenized credentials to AI agents via integrations with Anthropic, OpenAI, and Microsoft, positioning the network as the rails for agentic checkout[6]; (iii) AI as threat — agentic commerce is the proximate mechanism by which stablecoin rails could route around 2–3% interchange[22]. So Visa is a software-defined real-time-payments utility whose technical substrate is workload-agnostic; the AI question is whether agents are net-additive demand or a Trojan horse for disintermediation.

## Snapshot
- **Price:** $319.10 (2026-05-08 close)[17]
- **Market cap:** ~$612B[19]
- **52-week range:** $293.89 – $375.51[17]
- **Forward P/E:** 22.4× (on ~FY26 consensus EPS)[1st search]
- **EV / NTM revenue:** 14.4× (EV ~$623B / NTM rev ~$43B)[19]
- **Consensus 12-month price target:** ~$395 median (range $323–$450, 54 analysts), implied **+23.8%**[5th search]
- **YTD total return:** **-11.4%**[21]
- **Short interest (% of float):** **1.29%** (Apr 15, 2026 report) — extremely low; not a contested name in derivatives[18]

## Moat — what it is physically made of
The "Visa is a CUDA-style ecosystem" framing is wrong but the moat *is* a stack of specific components, each with different durability:

1. **The dual-sided BIN/acquirer network and scheme rules.** ~4.8B credentials, ~150M merchant acceptance points, 14,500+ issuing banks. The "rule of one signature" — that any Visa card works at any Visa terminal under uniform liability, chargeback, and dispute rules — is the network's actual product. This is not software; it is 60 years of arbitrated rulebooks plus the daily clearing-and-settlement legal plumbing. Replicating it requires either bank-by-bank legal agreements at scale (FedNow took 4 years to onboard ~1,700 of ~9,000 U.S. depositories) or a sovereign mandate (UPI, Pix). **Durability: very high in DM, eroding fast in greenfield EM.**

2. **VisaNet itself.** ~65,000 transaction messages/sec capacity, 127B transactions annually, sub-millisecond authorization SLA, multi-active datacenters with non-stop failover[8]. This is well-engineered but not exotic — Stripe and a stablecoin-native stack can match raw throughput. The moat is not the TPS; it is the universal acceptance contract pointing at it. **Durability: moderate; raw infra is replicable.**

3. **Visa Token Service (VTS).** 12.6B network tokens issued (+44% YoY), built on the EMVCo payment tokenization standard with per-transaction cryptograms[9][24]. Each token is a 16-digit reference scoped to a domain (merchant, device, channel) with revocation under Visa control. Stated impact: 6% lift in approval rates, 30% fraud reduction. Critically, **Visa controls the cryptogram namespace** — a merchant integrated with VTS for Apple Pay or "card-on-file" has a hard switching cost because the tokens are not portable. Tokenization is also the technical hook for agentic commerce: scoped credentials issued *to AI agents* under "Visa Intelligent Commerce"[6]. **Durability: high in the medium term — this is the most underappreciated piece of the moat.**

4. **VAAI / VAAI Score.** GenAI-augmented fraud models with feature stores spanning 15B transactions, 182 attributes, ~85% false-positive reduction vs. prior rule-based scoring; cited $40B fraud prevented 2022–2023[8]. Replicating requires the labeled fraud data, which only the issuer-aggregator can see. Mastercard has a comparable stack; nobody else does at the scheme layer. **Durability: high — data moat compounds.**

5. **Regulatory licensing.** Card scheme operator status in 200+ jurisdictions, AML/KYC, PCI-DSS compliance, GENIUS Act–aligned crypto-rail certification[13]. Years-long to replicate; this is what kills naive "build a stablecoin Visa" proposals from VCs.

6. **Patents, distribution contracts.** Multi-year exclusivity deals with major issuers (Chase, Capital One, USAA renewals 2024–2026); a typical bank deal is 7–10 years. These lock recurring volume regardless of any technical disruption. **Durability: high but cliff-shaped — a single Chase defection would be a violent reset.**

What the moat is **not**: it is not a developer/SDK ecosystem the way CUDA is. There is no "4M CUDA-developer" analog. Stripe, Adyen, Checkout.com, and others sit between Visa and the merchant developer; Visa is closer to a regulated utility than a platform. This is an important difference because *regulated utility moats erode via regulation, not via software*.

## AI buildout bottleneck map
For most rows on a frontier-AI buildout map (HBM3e supply, CoWoS-L, optical interconnect, >100kW liquid cooling, grid interconnect queue, 350kV transformer lead times), Visa is **indifferent**: its own datacenter footprint is mid-single-digit MW per region, traditional air-cooled x86 plus modest GPU inference for fraud — not a meaningful draw on the constrained inputs. Where Visa *is* exposed:

- **Inference compute for agentic commerce.** Modest. Authentication and risk scoring per agent-initiated transaction is ~ms-scale and runs on Visa's own infra. Indifferent to GPU supply.
- **Stablecoin rail integration.** Visa has now integrated nine chains for settlement (Ethereum, Solana, Avalanche, Stellar, Base, Polygon, Canton, Arc, Tempo); annualized stablecoin settlement run-rate $7B, +50% Q/Q[1][2]. Visa is a **rail aggregator** here — it is *adjacent* to a buildout (L1/L2 throughput, validator capex) it does not finance.
- **AI fraud model training cost.** Trivial vs. its $3B+ annual tech spend. Not a constraint.

Honest read: Visa is **indifferent** to the physical AI buildout. It is a *beneficiary* of the application layer that buildout enables (agentic commerce → more digital transactions → more interchange-bearing volume), and a *target* of one specific application (AI agents that comparison-shop on cost-to-acquirer).

## Competitive teardown
The textbook competitor is Mastercard (same moat shape, ~2× exposure to cross-border). The interesting competitors are the ones that bypass the four-party model entirely.

| Competitor | Axis of attack | Current evidence | What has to be true to take share |
|---|---|---|---|
| **Mastercard** | Mirror-image network. Closing technical gap on agentic commerce. | "Agent Pay" with Agentic Tokens; first agentic transaction Q4 2025[7]. BVNK acquisition for $1.8B (Mar 2026) for stablecoin infra[15]. | Already at parity on core rails; share shift is at the margin via issuer wins and stablecoin moves. Mastercard's faster M&A here is a real, narrow lead. |
| **Stablecoin rails (Stripe+Bridge, Circle/Arc, Tempo)** | Bypass interchange entirely; agentic routing on cost. | Stripe acquired Bridge for $1.1B; processed $1.9T in 2025[16]. Stablecoin supply $273B (Mar 2026), 40× since 2020[1][15]. Citrini Research thesis: AI agents route around 2–3% fees[22]. | Two things must hold simultaneously: (i) agentic checkout reaches material % of volume; (ii) stablecoin UX matches card UX on chargeback/dispute/fraud reimbursement. The second is the harder one — consumers do not give up Reg E and Visa zero-liability lightly. |
| **A2A rails (Pix, UPI, FedNow, SEPA Instant)** | Sovereign-mandated bank-to-bank, near-zero MDR. | Pix = 42% Brazil e-commerce vs cards 41%, projected 50% by 2028 (CAGR ~18%)[10]. UPI = 75% of India e-commerce A2A[10]. FedNow processed $850B in 2025 across 1,700 banks; RTP $1.3T (+428% YoY)[4][11]. | Already winning in EM greenfield. Threat to U.S. is slower — Visa Direct is already integrated with 11 RTP networks[4]. Real DM risk is 2028+ if Walmart-class merchants force "Pay by Bank" at scale post-settlement. |
| **PayPal/Block/Apple wallet stack** | Wallet-level routing decision shifts away from card rails. | Apple Pay still cards-on-file (via VTS) — Visa benefits. PayPal Stablecoin (PYUSD) is small but growing. | Wallets currently entrench VTS rather than replace it. Risk inflects if Apple/PayPal go merchant-direct on stablecoin at checkout. No evidence yet. |

Base rate check: payment network displacement in DM has been slow (cards displaced cash/checks over ~40 years; ACH-to-card took ~30). Greenfield/EM displacement of cards has been **fast**: Pix went from launch to >40% e-commerce share in 5 years[10]. The base rate that should worry a Visa long is therefore not "card networks lose share" — it is "newly digitizing economies skip the card era entirely." Visa's *growth* is largely in those geographies; the *cash flow* is in DM.

## Bull case — technical
For Visa to outperform, four technical conditions must hold:

1. **Agentic commerce routes through tokenized card credentials, not native stablecoin.** This is the most important technical bet. Visa Intelligent Commerce is shipping[6]; the agent gets a scoped VTS token with spend/category/counterparty limits, and uses *Visa rails for the authorization* even if settlement is stablecoin. Visa wins on every agent-initiated checkout the same way it wins on every Apple Pay tap. If this becomes the dominant integration pattern in 2026–2027 (it currently is, per Anthropic/OpenAI/Microsoft partnership disclosures[6]), Visa monetizes agentic commerce as growth, not as a tax loss.
2. **Stablecoin remains a settlement layer, not a consumer presentment layer.** The current pattern — stablecoin between issuer-acquirer settlement, fiat at the consumer edge — preserves interchange. Visa's $7B stablecoin settlement run-rate is the company *eating its own future*[2], which is the right strategic move. If stablecoin stays B2B/cross-border (where Visa's MDR is lower anyway), the net is positive.
3. **VTS tokenization penetration continues from ~50% toward ceiling.** Each incremental token is a hard switching cost embedded in a merchant. Forward 5-year growth in tokenization roughly tracks forward 5-year growth in switching cost. The 44% YoY token issuance growth is the cleanest forward indicator of moat depth[9].
4. **The merchant interchange settlement closes near current terms.** A 10bp posted-rate cut for 5 years is ~3% of net revenue — material but absorbable[12]. Walmart and the merchant coalition want fundamental rate-setting reform; if Judge Cogan keeps the rate-cap settlement narrow, Visa avoids a structural reset.

Connected to financials: at $319, 22× forward EPS, vs. a name that has historically traded 28–32×, **a 10pp multiple re-rate plus mid-teens EPS growth gets you to consensus $395 in 12 months.** Base rate on platform-style moats with regulatory licenses: they do not break suddenly; they break over 10–15 years if at all (IBM mainframes are still ~$2B/yr revenue 40 years after "death").

## Bear case — technical
This is the version I'd write as a short:

1. **Agentic commerce is the trigger event for stablecoin disintermediation.** Citrini's published thesis is the right one to engage seriously[22]: an AI agent's reward function explicitly includes minimizing transaction cost. When a Claude/GPT/Gemini agent is choosing between (a) push USDC to merchant for 5–15 bps total cost or (b) authorize a Visa card for 200–250 bps interchange, the agent picks (a) **unless the wallet/merchant explicitly disallows it.** The cliff is not 2026 — it is when (i) consumer protection parity for stablecoin (chargeback, fraud reimbursement) is mandated or built, and (ii) >25% of consumer e-commerce flows through agents. A reasonable 2028–2029 inflection.
2. **Mastercard's BVNK acquisition is a tell.** $1.8B is a 1.6× premium to standalone value — Mastercard paid up to *not be late*[15]. This implies Mastercard's technical leadership believes stablecoin rails are not optional. Visa is responding via the Tokenized Asset Platform but has *not* M&A'd at this scale. If MA is right about timing, Visa is one acquisition behind.
3. **EM displacement is the structural drag.** UPI/Pix have re-priced the floor on payment costs in their geographies. The relevant question is not whether Visa loses Brazil — it largely already has on share growth — but whether the **Pix model is exported** (Mexico's CoDi v2, Argentina's Transferencias 3.0, ASEAN cross-border CBDC pilots). Visa's international growth depends on EM digitization; if EM digitization happens *via A2A*, Visa is growing volume at a depressed take rate.
4. **Interchange settlement is the proximate cash-flow risk.** The $200B settlement is unloved by merchants[12]; if Judge Cogan forces a structural revisit in late-2026/early-2027 (e.g., merchant-routing rights on credit, posted-rate determination by a neutral panel), the 10bp cut is the optimistic scenario.
5. **Multiple compression is the proximate price risk.** EV/EBITDA has gone from 24× to 18.8× in 14 months[19] — the market is **already pricing some of the bear case.** But forward P/E at 22× is still ~25% above the S&P 500; the de-rating may not be done if cross-border volume growth slips below 10%.

Honest assessment: the bear case is technically credible at a 3-year horizon. It is **not** credible at a 12-month horizon — too few of the inflection points have arrived.

## Market view check
At $319 / 22× forward / 14.4× EV/NTM-revenue with 14–17% revenue growth and ~50% operating margins, Visa is trading at a discount to its 10-year average multiple and roughly in line with the S&P 500 P/E despite materially better fundamentals[19]. Consensus PT $395 implies +24% with no fundamental thesis change — *just multiple normalization*. The market is currently pricing **partial belief in the stablecoin disintermediation thesis**: enough to compress the multiple, not enough to price the EPS impact. My read is the market is roughly right to compress (the threat is real over 3–5 years) but is conflating *speed* with *certainty* — the technical evidence for 2026–2027 is that Visa is *capturing* agentic commerce, not losing to it. If I'm correct on that read, the price is too low.

## 90-day falsifiers
- **Visa F3Q26 earnings (late July 2026)**: cross-border volume ex-Europe growth <8% would signal real EM-A2A bleed (current run-rate 11%[3]). Tokenized transaction count growth <35% YoY would suggest VTS adoption is plateauing.
- **OCC final GENIUS Act rule (target July 2026)[13]**: if final rule permits stablecoin issuers to pay interest indirectly (via partner rebates), the consumer presentment threat materially accelerates.
- **Judge Cogan ruling on merchant settlement (expected late 2026, watch docket activity)[12]**: any signal the settlement is rejected in favor of structural reform is a -3% to -8% event on V.
- **Chase / Capital One / large issuer renewal news**: a Mastercard win on a top-10 U.S. issuer would be the cleanest evidence the BVNK / Agent Pay edge is converting.
- **First public disclosure of agentic checkout volume share by a top-10 merchant (Shopify, Amazon, Walmart)**: above 5% and Visa's agentic positioning gets validated; if the disclosed transaction *settlement* is stablecoin-native rather than VTS, that's a falsifier on the bull case.
- **Mastercard's next M&A move**: a second stablecoin-infra or agentic-AI acquisition would force Visa to respond.

## What I could not verify
- Visa's actual **incremental margin** on agentic-commerce transactions vs. standard card-present. Inference: similar to card-not-present, ~10–20bps higher gross take, but this is not disclosed.
- The **share of VTS tokens that are merchant-domain vs. issuer-domain vs. device-domain** — this matters because merchant-domain tokens are the stickiest. Only aggregate count disclosed[9].
- **Specifics of the Anthropic / OpenAI / Microsoft Intelligent Commerce contracts** — exclusivity terms, revenue share, whether agents can default-prefer stablecoin. Visa's press[6] is marketing-grade only.
- **Engineering headcount and CUDA/Triton-class technical talent at Visa.** Job postings suggest a sizable ML org but no public technical detail on the model serving stack for VAAI.
- **Real-world chargeback / dispute behavior for stablecoin-settled transactions on Visa rails** — Visa is publishing volume[1][2] but not loss rates, which is the leading indicator for whether stablecoin can pass the consumer-protection test that gates broad adoption.
- **Short-interest detail beyond aggregate %** — institutional positioning data not retrieved.

## Sources
[1] https://investor.visa.com/news/news-details/2026/Visa-Accelerates-Stablecoin-Momentum-Adding-Five-Blockchains-for-Settlement/default.aspx — retrieved 2026-05-10 — Visa adding Base, Polygon, Canton, Arc, Tempo to stablecoin settlement; 9 chains total.
[2] https://www.coindesk.com/business/2026/04/29/visa-expands-stablecoin-settlement-network-as-volume-hits-usd7-billion-run-rate — retrieved 2026-05-10 — $7B stablecoin settlement annualized run-rate, +50% Q/Q.
[3] https://s1.q4cdn.com/050606653/files/doc_financials/2026/q2/Q2-2026-Earnings-Release_vF.pdf — retrieved 2026-05-10 — Visa Q2 FY26 release: $11.2B revenue (+17%), $3.7T payments volume, 66.1B processed tx.
[4] https://www.paymentsdive.com/news/Visa-CFO-Fednow-realtime-payments-competition-credit-legislation/631047/ — retrieved 2026-05-10 — Visa Direct integrated with 66 ACH, 11 RTP, 16 card networks; CFO commentary on FedNow.
[5] https://www.marketbeat.com/stocks/NYSE/V/forecast/ — retrieved 2026-05-10 — 54-analyst consensus median PT $400.60 (range $323–$450).
[6] https://corporate.visa.com/en/products/intelligent-commerce.html — retrieved 2026-05-10 — Visa Intelligent Commerce: scoped tokenized credentials for AI agents; integrations with Anthropic, OpenAI, Microsoft.
[7] https://www.digitalcommerce360.com/2026/04/02/visa-mastercard-in-agentic-commerce/ — retrieved 2026-05-10 — Mastercard Agent Pay / Agentic Tokens; first agentic transaction Q4 2025.
[8] https://usa.visa.com/about-visa/newsroom/press-releases.releaseId.20661.html — retrieved 2026-05-10 — VAAI Score: 15B training transactions, 182 features, 20ms scoring, 85% false-positive reduction, $40B fraud prevented 2022–2023.
[9] https://corporate.visa.com/en/solutions/tokenization.html — retrieved 2026-05-10 — Visa Token Service: 12.6B tokens issued, +44% YoY; 6% approval lift, 30% fraud reduction.
[10] https://insights.ebanx.com/en/upi-and-pix/ — retrieved 2026-05-10 — Pix 42% Brazil e-comm vs cards 41%; UPI 75% India e-comm A2A.
[11] https://www.fxcintel.com/research/analysis/upi-pix-2025-growth — retrieved 2026-05-10 — RTP $1.3T 2025 (+428%); FedNow $850B / 1,700 banks.
[12] https://www.pymnts.com/credit-cards/2026/retailers-object-to-200-billion-visa-mastercard-swipe-fee-settlement/ — retrieved 2026-05-10 — Proposed $200B settlement: 10bp credit-interchange cut for 5 years; merchant opposition.
[13] https://www.congress.gov/bill/119th-congress/senate-bill/1582 — retrieved 2026-05-10 — GENIUS Act signed July 18, 2025; 1:1 reserves, interest banned; OCC rules July 2026, effective Jan 18, 2027.
[14] https://www.weforum.org/stories/2025/07/stablecoin-regulation-genius-act/ — retrieved 2026-05-10 — GENIUS Act overview, implementation timeline.
[15] https://www.coindesk.com/opinion/2026/03/27/why-mastercard-paid-double-for-stablecoin-infrastructure-it-could-have-built — retrieved 2026-05-10 — Mastercard's $1.8B BVNK acquisition rationale.
[16] https://blockonomi.com/visa-v-and-mastercard-ma-battle-stablecoin-disruption-with-bold-2026-strategies/ — retrieved 2026-05-10 — Stripe acquired Bridge for $1.1B; $1.9T Stripe payment volume 2025.
[17] https://stockanalysis.com/stocks/v/history/ — retrieved 2026-05-10 — Visa close $319.10 on May 8, 2026; 52-week range $293.89–$375.51.
[18] https://www.marketbeat.com/stocks/NYSE/V/short-interest/ — retrieved 2026-05-10 — Visa short interest 1.29% of float as of Apr 15, 2026.
[19] https://www.tikr.com/blog/visa-stock-is-down-11-8-in-2026-heres-what-the-valuation-says — retrieved 2026-05-10 — EV/NTM revenue 14.4×; EV $623B; NTM EV/EBITDA contracted from 24.2× (Mar 2025) to 18.8×.
[20] https://www.investing.com/news/company-news/visa-q2-fy2026-slides-17-revenue-growth-92b-returned-to-shareholders-93CH-4650845 — retrieved 2026-05-10 — Q2 FY26 capital return: $7.9B buyback, $1.3B dividend; new $20B authorization.
[21] https://www.benzinga.com/money/visa-stock-price-prediction — retrieved 2026-05-10 — YTD 2026 return -11.35%.
[22] https://coincentral.com/how-visa-and-mastercard-are-responding-to-the-stablecoin-threat-in-2026/ — retrieved 2026-05-10 — Citrini Research thesis: AI agents route around 2–3% interchange via stablecoin.
[23] https://usa.visa.com/content/dam/VCOM/regional/na/us/Solutions/documents/visas-journey-through-tokenization.pdf — retrieved 2026-05-10 — VTS technical architecture: EMVCo standard, per-transaction cryptograms, domain scoping.
[24] https://www.coindesk.com/business/2026/01/30/visa-and-mastercard-aren-t-buying-the-stablecoin-hype-for-everyday-payments — retrieved 2026-05-10 — Network CEOs' stated position that stablecoin remains a B2B/cross-border tool, not consumer presentment.