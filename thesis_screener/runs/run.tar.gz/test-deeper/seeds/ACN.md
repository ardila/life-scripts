I have enough to write. Let me draft the dossier — being honest that ACN sits at the integration/services layer, not silicon, so the moat analysis is fundamentally different from a hardware name.

```
# ACN — Accenture plc

## Where this sits in the AI stack
ACN is at the **application/integration/services layer**, not silicon, packaging,
HBM, networking, power, or compiler runtimes. It physically sells **labor and
IP wrappers**: ~774,000 people [1] (700K core workforce, ~77,000 of whom are
classified as AI/data professionals [2][3]) deployed to enterprises (mostly
Global 2000) to design, build, and operate AI-enabled business processes on
top of hyperscaler infrastructure (Azure, AWS, Google Cloud) and model/silicon
vendor stacks (NVIDIA, OpenAI, Anthropic, Adobe, SAP, ServiceNow). Its closest
thing to a proprietary asset is "AI Refinery," a reference architecture built
*on top of* NVIDIA AI Foundry, NIM microservices, NeMo, AI Enterprise, and
Omniverse — i.e. it is a deployment/orchestration layer above someone else's
silicon and frameworks [4][5]. The dossier framing of "what physical moat
underlies the AI buildout" therefore has to be honest: ACN owns none of the
physically constrained inputs (CoWoS, HBM, optics, turbines). Its thesis is
about whether the **integration tax** on AI deployments is durable, or whether
the same agents ACN is selling to clients eventually disintermediate it.

## Snapshot
- **Price:** $180.42 (2026-05-08 close) [6]
- **Market cap:** $110.8B [6]
- **52-week range:** $172.52 – $325.71 [7]
- **Forward P/E:** ~13.1× (FY26 EPS guidance midpoint $13.78, range $13.65–$13.90) [8]
- **EV / NTM revenue:** ~1.5× (EV ≈ mkt cap; net cash position; FY26 revenue
  guide $71.8B–$73.2B [9])
- **Consensus 12-month PT:** ~$250 (27-analyst avg, range $210–$320) → +39%
  implied [10]
- **YTD total return:** –25.9% [7]
- **Short interest (% of float):** ~1.4% (low; historically uninteresting to
  shorts) — I could not source a fresh May-2026 print and treat this as
  approximate [11]

## Moat — what it is physically made of
A senior infra reader has to be told the uncomfortable truth: most of ACN's
moat is **not** physical or technical in the way NVIDIA's CUDA + NVLink + HBM
allocation is. Decomposing:

1. **Trusted-vendor seat at the Fortune 500 CIO.** ACN runs the SAP, Oracle,
   Workday, ServiceNow, mainframe modernization, and ERP transformations at a
   large fraction of the Global 2000. This is *relationship capital*: master
   service agreements, security/audit clearances, on-site teams that have
   been embedded for 5–15 years. Replacement cost is real but not infinite —
   consulting relationships migrate, especially when a successor partner can
   point to a measurable cost-out story.
2. **Delivery scale + global labor footprint.** ~774K people across 120+
   countries, ~50% in India delivery centers [1]. The economic moat here is
   labor arbitrage + ramp speed: ACN can put 500 cleared engineers on a
   federal program in a quarter; few competitors can. This moat is durable
   *only as long as the unit of consumption is human-hours*. Agentic AI is a
   direct attack on it.
3. **Preferred-SI status with the four AI platform owners.** "NVIDIA Business
   Group" — 30,000 staff, named global SI partner [4]. Microsoft "Azure AI"
   alliance, AWS Generative AI Center of Excellence, Google Cloud
   partnership. These confer early access to roadmap, shared GTM motion, and
   in the NVIDIA case co-branded reference architectures. They are not
   exclusive; Deloitte, Capgemini, IBM, TCS, Infosys, Wipro all carry the
   same designations. So this is a "must-have" not a "moat."
4. **Proprietary IP on top of OSS/vendor stacks.** AI Refinery, switchboard
   patterns, industry verticals (e.g., the "Foundation Model for Materials"
   work in life sciences). On inspection these are reference
   implementations and accelerators — not proprietary models or weights.
   Faculty (UK AI lab acquired Q2 FY26 [12]) is the clearest piece of
   genuine technical IP — Marc Warner, the Faculty CEO, has been elevated
   to ACN's CTO and joined the global management committee, which is a
   meaningful signal that ACN itself recognizes it lacked deep-stack AI
   talent in-house.
5. **Reskilling factory (LearnVantage).** $1B/3yr program plus tuck-ins
   (Udacity, TalentSprint, Ascendient, Aidemy) reskilling 250K technologists
   on data/AI [13][14]. This is interesting: the right read is not "ACN
   sells training" but "ACN is racing to remake its own delivery workforce
   before billable-hour deflation lands." It's a defensive moat-rebuild,
   not a moat itself.

**Honest assessment:** ACN's moat is *brand + scale + relationships +
reskilling speed*, not physical. Person-years to replicate is meaningful —
no one else has 774K people — but the question is whether that headcount
remains the right unit of value at all in a world of agents. Compare to
NVIDIA, where the moat lives in CoWoS-L allocation, HBM3e contracts, NCCL
collective primitives, and 4M CUDA developers; ACN has nothing remotely
analogous in physical or kernel-level lock-in.

## AI buildout bottleneck map
ACN is **mostly indifferent to the physical bottlenecks**, which is
underappreciated. Going through them:

- **Power gen + grid interconnect** (turbine backlogs at GE Vernova, Siemens
  Energy stretching past 2028; substation queue in PJM): ACN does *some*
  utility consulting and sustainability work but is not a beneficiary or
  constraint owner. **Indifferent.**
- **CoWoS-L advanced packaging at TSMC** (Blackwell, Rubin, MI400 all
  competing for the same tools): **Indifferent.** ACN is downstream of
  whatever silicon ships.
- **HBM3e/HBM4 supply** (SK Hynix > Micron > Samsung in qualifying):
  **Indifferent.**
- **Optical interconnect / co-packaged optics** (CPO ramp at Broadcom,
  Marvell, Coherent): **Indifferent.**
- **Liquid cooling at >100 kW/rack** (Vertiv, CoolIT, BoydCorp, Schneider):
  **Mild beneficiary** through datacenter advisory and IT/OT integration
  practices, but a rounding-error revenue contributor.
- **Electrical contractor and substation EPC capacity** (Quanta, MYR, EMCOR
  backlogs): **Indifferent.**
- **Kernel/compiler/distributed-systems talent** (the binding constraint at
  the frontier labs): **Negative exposure.** ACN does not hire at this
  tier — the people who write Triton kernels or NCCL patches don't take
  consulting jobs at MSA-rate cards. ACN's 77K "AI/data professionals" are
  overwhelmingly applied: data engineers, MLOps, prompt and agent
  developers, MLE-3-equivalents implementing third-party models.
- **Frontier training data quality**: **Indifferent** (its clients' data is
  the asset; ACN charges to clean/govern it).
- **Enterprise AI deployment capacity** (the *integration* bottleneck —
  hooking models to SAP/mainframe/Workday/Salesforce, governance, change
  management, data plumbing): **Primary beneficiary.** This is the only
  line on this list where ACN is the named winner. The bull thesis lives
  or dies here.

The clean conclusion: ACN is exposed to one bottleneck — *enterprise
integration* — and that bottleneck is itself the most plausibly
AI-automatable item on the list. Every other constraint that's making
hyperscaler capex go vertical is happening upstream of it.

## Competitive teardown
Differentiate by axis, not by "competitor":

- **Strategy/transformation high end:** McKinsey, BCG, Bain. They have
  brand premium ACN cannot match for board-level AI strategy work (one
  reason ACN bought what was Strategy& renaming and pushed into
  "Strategy & Consulting"). McKinsey QuantumBlack arguably leads on
  AI-strategy mindshare. ACN trades the McKinsey brand for ~10× the
  delivery muscle.
- **Big-4 audit-adjacent integration:** Deloitte, EY, PwC, KPMG. Deloitte
  is the closest like-for-like comparator on tech delivery + GenAI
  bookings; both were hit by DOGE federal contract cuts in 2025
  (Deloitte $371M reported savings; ACN ~$240M cited and growing) [15]
  [16]. Big-4 have audit-relationship lock that ACN cannot replicate.
  ACN has more pure tech depth.
- **Indian-heritage offshore ITS:** TCS, Infosys, Wipro, HCL, Cognizant.
  Compete on cost — bill rates 30–60% below ACN. Their GenAI bookings
  trail (TCS reported AI/GenAI deal TCV growing but materially smaller
  than ACN's $5.9B FY25 GenAI bookings [17]). The pyramid economics there
  are *more* exposed to AI productivity gains than ACN's because their
  business is more weighted to staff augmentation. ACN is currently
  taking share at the high end and losing none at the low end — but if
  agentic coding flattens the pyramid, the offshore players' lower cost
  base gives them more room to drop prices.
- **Hyperscaler professional services arms:** Microsoft Industry
  Solutions, AWS Professional Services, Google Cloud Consulting. These
  are the structural threat. Hyperscalers can bundle services into
  consumption deals and price them at near-zero to win cloud workloads.
  ACN's defense is that hyperscaler PS deliberately stays smaller than
  the SI ecosystem to keep partner relationships intact — but that is a
  *choice* by Microsoft/Amazon/Google, not a structural barrier.
- **Hyperscaler agent platforms** (Microsoft Copilot Studio, AWS Bedrock
  Agents, Google Agentspace, Salesforce Agentforce, ServiceNow AI
  Agents, OpenAI Agent Builder): the most underappreciated competitor.
  These are direct attacks on the integration value-add ACN charges for.
  An enterprise that can stand up an agent in Salesforce Agentforce in
  a week did not need ACN to do it — though ACN may still get paid to
  govern, evaluate, and chain agents at scale. Whether the residual
  governance/orchestration tax is 10% or 80% of the historical SI tax is
  the central uncertainty.
- **IBM Consulting + Red Hat + watsonx:** Resurgent on hybrid AI
  positioning; smaller but with the OpenShift/Red Hat distribution. Not
  a meaningful share-taker against ACN today; worth watching as IBM's
  watsonx.governance and orchestration story matures.

## Bull case — technical
For ACN to outperform from $180 over the next 12–24 months, the following
technical conditions need to hold:

1. **Enterprise AI deployment remains the binding bottleneck.** Foundation
   models keep getting better, but the marginal dollar of enterprise AI
   value is gated by data plumbing, identity/permissioning, evaluation
   harnesses, and integration to systems-of-record. Every customer
   testimony from Anthropic and OpenAI's enterprise teams cites the same
   pattern: model swap is fast; production deployment is slow. SI labor is
   the swing factor.
2. **Agents do not collapse the hourly billing model fast enough to
   matter in the FY26–FY27 P&L.** ACN's response is value-based pricing
   and outcome-tied deals, but McKinsey is at ~25% outcomes-tied today
   [18]; ACN is lower. If agentic coding raises productivity 2× by FY28
   but client willingness-to-pay shifts only gradually, ACN can absorb
   the deflation through mix shift to advisory and managed services.
3. **NVIDIA AI Foundry / Refinery + sovereign AI mandates create a new
   integration cycle.** The 30K-person NVIDIA practice [4] and growing
   sovereign AI deals (UK, France, Germany, Saudi, Japan) provide a
   concrete revenue line that maps to physical bottlenecks (those
   countries are buying GPU capacity and need an SI to wrap apps around
   it).
4. **Federal recovers.** DOGE cuts hit ~8% of revenue; if mission-critical
   designations stick and FY27 budgets normalize, this is a one-time
   reset.
5. **Reskilling moat works.** LearnVantage successfully converts ACN's
   own pyramid into AI-native delivery so that automation gains accrue
   to ACN, not to clients.

**Base rate check on technology displacement:** Historically, services
intermediaries (Big SI in mainframe → client-server, then client-server
→ web, then web → cloud) have *always* survived platform shifts and
usually grown through them, because each new platform created more
integration surface area, not less. The cloud transition is the most
recent precedent: AWS launched 2006, the Big SI consulting line grew
through 2024 alongside hyperscaler PS. **However**, every prior
platform shift was tooling for humans. Agents are tooling for *no
humans*, and that is a regime change without a clean historical
precedent. Base rate is ambiguous.

If the bull case holds, ACN earns ~$14 in FY26 and grows EPS HSD; a
15–17× multiple gets you $215–$240. Add buybacks (~3% yield) and the
~2% dividend, total return of 25–35% over 12 months is plausible.

## Bear case — technical
The version a short with technical literacy would write:

1. **Agentic coding is real and the deflation is non-linear.** Cursor,
   Claude Code, GitHub Copilot Workspace, Devin, and the OSS agent
   frameworks (LangGraph, AutoGen, AG2) reduce time-to-deliver on
   generic enterprise IT work by 30–70%, and the curve has been
   accelerating quarter-over-quarter through 2025–26. ACN's modal
   deliverable — an SAP S/4HANA or Workday rollout, a custom CRM build,
   an enterprise data platform — is exactly the kind of work most
   exposed to this. Even at constant client demand, revenue per FTE has
   to fall.
2. **Hyperscaler agent platforms eat the integration tax directly.**
   Salesforce Agentforce, ServiceNow AI Agents, Microsoft Copilot Studio,
   and AWS Bedrock Agents are explicit attempts to let *the customer's
   own admins* stand up workflow automation that previously required SI
   consultants. Each platform has thousands of named enterprise
   deployments now and the configuration surface is shrinking.
3. **Pyramid implosion.** ACN's profit comes from leverage of senior
   billable rates over junior delivery cost. AI compresses junior work
   first. If junior FTE count falls 20% but senior count stays flat,
   utilization economics break. The 11,000 layoffs of "people without
   AI skills" plus $865M reinvention charge in FY25 are the first
   visible evidence of this re-shaping; expect more [19].
4. **Bookings ≠ revenue, and the gap is widening.** Q2 FY26 bookings
   $22.1B were a record [20], yet revenue grew only 4% in local
   currency [20] and the FY26 revenue guide ($71.8–73.2B) came in
   $700M–$2.1B below sell-side consensus [9]. The bull rebuttal — "AI
   bookings have longer revenue tails" — is *also* the bear thesis:
   tails imply per-deal revenue is being stretched, which is what
   deflation looks like in this industry's accounting.
5. **End of separate AI metric disclosure** (after Q1 FY26) is a yellow
   flag [21]. Management's framing — "advanced AI is now embedded in
   everything" — is plausible, but the comparable case is when companies
   stop breaking out a once-fast-growing line because the comp is about
   to roll over.
6. **The federal cut is not one-time.** DOGE-style cost discipline at
   scale, plus state and EU equivalents, plus enterprise CIO budget
   pressure as AI capex eats opex, points to a multi-year compression of
   the consulting wallet, not a one-quarter air pocket [15][16].

If the bear case holds, FY27 EPS comes in flat or down vs. the $14
guide, and ACN re-rates to ~10× as it loses growth-stock status. That
is $130–$150 — another 15–25% downside from here.

## Market view check
At $180.42 and ~13× forward EPS, ACN trades at a discount to the
S&P 500 forward multiple (~21–22×) and a *deep* discount to the
Magnificent Seven AI cohort. The 27-analyst consensus PT of ~$250 [10]
implies +39% upside, a Buy/Strong-Buy weighted rating. **The market
appears to be pricing ACN as a structurally challenged services name
with one-time AI optionality**, not as an AI beneficiary. The implied
disagreement: sell-side believes ACN's bookings will convert to
above-guide revenue and the multiple re-rates back toward 18–20×;
the market disagrees and is willing to bet that the agentic deflation
arrives before the booked work converts. My read of the technical
substrate: the market is closer to right than the sell-side
consensus on the *direction* of risk, but possibly overshooting on the
*magnitude* — the integration bottleneck is real for at least the next
4–6 quarters, and ACN's reskilling pace is faster than the offshore
peers'. Net: the price discount looks roughly fair given the technical
risks, with asymmetric upside only if FY27 bookings-to-revenue
conversion accelerates visibly.

## 90-day falsifiers
Specific, observable events in the next 90 days that would update the
thesis materially:

1. **Q3 FY26 earnings (late June 2026).** If revenue growth in local
   currency comes in <3% YoY *and* book-to-bill <1.0×, the agentic
   deflation thesis gets concrete. If revenue >6% local currency and
   book-to-bill >1.1×, the integration-bottleneck bull case is
   reasserted.
2. **AI bookings disclosure.** Whether management restores or replaces
   the discontinued advanced-AI metric with a substitute (e.g., "AI
   embedded revenue mix"). Continued opacity is a tell.
3. **Headcount print.** ACN guided to add ~7,000 net hires in FY26 [3];
   if Q3 disclosure shows headcount flat or down, the labor model is
   under more pressure than guided.
4. **Federal contract base.** Any updated DOD/civilian contract
   terminations vs. mission-critical reaffirmations; Air Force Cloud One
   $1.4B status [16] is the single biggest line to watch.
5. **Hyperscaler agent platform adoption disclosures.** Salesforce
   Agentforce, ServiceNow AI Agents, Microsoft Copilot Studio quarterly
   numbers — if these accelerate sharply (>3× YoY paid agent count), it
   is direct evidence of the disintermediation channel.
6. **Faculty integration / Marc Warner positioning** — any technical
   product announcements (new ACN-proprietary models or agents) within
   90 days would meaningfully raise the IP-moat read.
7. **Pricing model disclosures.** Any specific outcome-based deal
   announcements above $500M that publicly disclose the structure.

## What I could not verify
- Current short interest as of May 2026 — I cited a stale ~1.4% figure.
- Net cash vs. net debt position at FY26-Q2 end (assumed near-zero net
  debt; not confirmed against a fresh balance sheet).
- Independent third-party estimates of ACN's per-FTE productivity gain
  from internal AI tooling (the "are they eating their own deflation?"
  question). Management talks about it qualitatively; no audited number.
- Faculty acquisition price and revenue contribution — disclosed as
  "subject to closing conditions" in early 2026; no firm number found.
- The actual revenue conversion curve on AI bookings (months from
  booking to revenue), which is the central unknown for FY27 modeling.
- Whether the ~$5B FY26 inorganic spend [22] is incremental to the
  guide or already embedded; ambiguous from earnings transcripts.
- Concrete MLPerf-style benchmark of AI Refinery vs. competing SI
  reference architectures (e.g., Deloitte's Trustworthy AI, IBM
  watsonx.governance) — no apples-to-apples comparison exists.

## Sources
[1] https://www.accenture.com/us-en/about/company/integrated-reporting-financial — retrieved 2026-05-10 — Accenture corporate workforce and segment overview
[2] https://www.constellationr.com/blog-news/insights/accenture-goes-big-ai-reskilling-acquires-udacity-launches-learnvantage — retrieved 2026-05-10 — LearnVantage launch and AI/data professional headcount expansion
[3] https://infotechlead.com/software/it-services-hiring-trends-2026-accenture-adds-7000-staff-concentrix-targets-5000-tech-roles-as-ai-reshapes-talent-demand-95585 — retrieved 2026-05-10 — FY26 ACN net hiring plan ~7,000
[4] https://www.consultancy-me.com/news/9351/accenture-launches-global-nvidia-business-group-and-ai-refinery-platform — retrieved 2026-05-10 — 30K-person NVIDIA Business Group and AI Refinery built on NIM/NeMo/Foundry
[5] https://www.accenture.com/us-en/services/data-ai/ai-refinery — retrieved 2026-05-10 — AI Refinery technical stack composition
[6] Yahoo Finance ACN quote — retrieved 2026-05-10 — close $180.42, mkt cap $110.82B
[7] https://www.financecharts.com/stocks/ACN/summary/price — retrieved 2026-05-10 — 52-week range $172.52–$325.71, YTD –25.85%
[8] https://newsroom.accenture.com/content/2qfy26-earnings/accenture-reports-second-quarter-fiscal-2026-results.pdf — retrieved 2026-05-10 — FY26 EPS guide $13.65–$13.90; Q2 EPS $2.93
[9] https://www.marketbeat.com/instant-alerts/accenture-nyseacn-releases-fy-2026-earnings-guidance-2026-04-09/ — retrieved 2026-05-10 — FY26 revenue guide $71.8–73.2B vs. consensus ~$73.9B
[10] https://stockanalysis.com/stocks/acn/forecast/ — retrieved 2026-05-10 — 27-analyst consensus PT ~$250
[11] https://www.marketbeat.com/stocks/NYSE/ACN/short-interest/ — retrieved 2026-05-10 — short interest data (figure approximate, not freshly confirmed)
[12] https://newsroom.accenture.com/news/2026/accenture-completes-acquisition-of-faculty — retrieved 2026-05-10 — Faculty (UK AI) acquisition; Marc Warner becomes ACN CTO and joins Global Management Committee
[13] https://www.accenture.com/us-en/services/learnvantage-index — retrieved 2026-05-10 — LearnVantage scope: 250K technologists, 550K reskilled on GenAI fundamentals
[14] https://newsroom.accenture.com/news/2025/accenture-acquires-talentsprint-to-expand-learnvantage-s-capabilities-in-developing-future-ready-talent-for-enterprises-and-governments — retrieved 2026-05-10 — TalentSprint, Ascendient, Aidemy tuck-ins
[15] https://fortune.com/2025/04/03/doge-private-contract-crackdown-deloitte-consultancies/ — retrieved 2026-05-10 — DOGE Deloitte 124 contracts, $371M claimed savings
[16] https://www.washingtontechnology.com/contracts/2025/04/pentagon-hits-accenture-booz-allen-and-deloitte-contract-cancellations/404500/ — retrieved 2026-05-10 — Pentagon contract cancellations affecting ACN incl. Air Force Cloud One $1.4B
[17] https://www.outlookbusiness.com/corporate/accentures-fy25-revenue-up-7-yoy-ai-deal-bookings-double-to-59-billion — retrieved 2026-05-10 — FY25 GenAI bookings $5.9B, doubled YoY
[18] https://medium.com/enrique-dans/the-end-of-billable-hours-how-ai-is-forcing-consulting-to-reinvent-itself-bd3ae059b97b — retrieved 2026-05-10 — McKinsey ~25% outcomes-tied fees benchmark
[19] https://fortune.com/2025/09/27/accenture-865-million-reinvention-exiting-people-ai-skills/ — retrieved 2026-05-10 — 11,000 layoffs and $865M reinvention charge
[20] https://www.whalesbook.com/news/English/tech/Accentures-AI-Breakthrough-Bookings-Surge-to-dollar22-Billion-Before-Metric-Shift/6944d9d6d491bcfbdd167af1 — retrieved 2026-05-10 — Q2 FY26 record bookings $22.1B; revenue $18.0B / +4% LC
[21] https://stocktwits.com/news-articles/markets/equity/accenture-stock-slips-after-ceo-says-this-will-be-the-last-quarter-for-breaking-out-ai-metrics/cLegv53RErO — retrieved 2026-05-10 — ACN ending separate AI metric disclosure after Q1 FY26
[22] https://www.gurufocus.com/news/8785707/accenture-acn-expands-ai-strategy-with-5b-acquisition-target — retrieved 2026-05-10 — FY26 inorganic spend target raised to $5B
```