# J — Jacobs Solutions Inc.

## Where this sits in the AI stack
Jacobs is a professional engineering and design firm — not a contractor, not a silicon vendor, not a kernel-stack company. It sells **architectural and engineering (A&E) design, owner's-representative services, permitting, commissioning, and digital-twin reference design** for the **physical envelope** that wraps an AI cluster: substations and gen-tie, MEP for >100 kW/rack liquid-cooled halls, water/cooling tower loops, structural shell, site civil, and security/fire suppression [1][3][7]. It is two layers below the GPU and two layers above the rebar: hyperscaler customer → **Jacobs (design, PE stamps, reference architecture)** → GC (DPR, Holder, Turner) → trade contractors (Quanta, EMCOR for electrical; Comfort Systems for mechanical). Workload-agnostic to training-vs-inference at the silicon layer; mass-and-power-density-sensitive at the building layer (gigawatt campuses and ~250 MW colos are its sweet spot) [8][9]. ~90% of revenue is Infrastructure & Advanced Facilities (I&AF); ~10% is PA Consulting (digital advisory) [4].

## Snapshot
- **Price:** $118.43 (2026-05-08 close) [5]
- **Market cap:** $13.98B [5]
- **Enterprise value:** $17.17B [5]
- **52-week range:** $118.38 – $168.44 [10]
- **Forward P/E:** 15.4× (on FY26 midpoint EPS guide $7.22) [5][2]
- **EV / Revenue (TTM):** 1.30× [5]
- **EV / NTM revenue:** ~1.1× (inferred — FY26 guide of 8–10.5% net rev growth implies gross rev ~$15.5B NTM)
- **Consensus 12-month price target:** $153–156 (avg, +29–32% from spot); RBC $169, Citigroup constructive [2][6]
- **YTD total return:** –7.2% [2]
- **Short interest (% of float):** 3.77% [5]
- **Beta (5Y):** 0.71 [5]

## Moat — what it is physically made of
This is a **professional-services moat, not a technology moat.** Honest readout of the components:

1. **Codified reference design ("Cloud Condos" + Digital Twin).** Jacobs has converted a decade of hyperscaler delivery (17M ft², 3,600 MW, ~$30B in construction value) into a modular Plan-of-Record that the company claims compresses design-to-online by ~40% [1][3][9]. In March 2026 it released a gigawatt-scale AI data center digital twin built on the **NVIDIA Omniverse DSX blueprint**, featured in NVIDIA's GTC keynote — co-simulating compute, power, and cooling against a virtual building [9][14]. This is the closest thing the firm has to durable IP. **Durability assessment:** medium. Reference designs are copyable in 18–36 months by a sufficiently funded competitor (AECOM is doing this; Stantec/Tetra Tech follow). The NVIDIA endorsement is a marketing lever, not exclusivity — DSX is an open blueprint with multiple ecosystem partners.

2. **Permitting, EHS, and PE-stamped credentialing.** Each data center site requires state-by-state professionally-engineered drawings, NEPA/CEQA environmental work, water-rights navigation, and AHJ negotiation. Jacobs has the licensed-PE roster across all 50 states and most OECD jurisdictions. **Durability:** high. This is the same moat type that protects AECOM, WSP, Stantec — it took those firms decades to build and is essentially uncopyable in the relevant 24–36-month window. It is, however, **shared** across the top 4–6 firms.

3. **Hyperscaler reference customer list.** Microsoft and AWS are disclosed multi-year customers; OCP and US Army Corps relationships [1]. Switching costs for the customer are real — Jacobs holds tribal knowledge on a specific campus's substation topology and water permits — but the customer can dual-source on the next campus. **Durability:** medium. Hyperscalers explicitly cultivate 2–3 A&E partners to retain leverage.

4. **Backlog visibility.** $26.97B backlog as of March 27, 2026 (+21.7% YoY), with management disclosing line-of-sight "well through 2027, going into 2028" on data center pipeline [11][12]. The data-center *pipeline* is up 400% YoY and data-center *revenue* doubled YoY [12][13]. This is not a moat — it's a forward-visibility artifact of demand. It would reverse with the cycle.

5. **PA Consulting (digital advisory).** ~$1.4B run-rate revenue, 22.3% segment margin — higher-margin than core engineering [11]. Management is now allowed (post-UK conflict-of-interest restrictions) to cross-sell PA into I&AF accounts [13]. **Durability:** low-to-medium. PA is a strategy-consulting boutique; the cross-sell story is real but unproven at scale.

**Honest summary:** Jacobs has no equivalent of CUDA, no equivalent of CoWoS allocation, no equivalent of a 3nm node. It has a brand, a license stack, a customer Rolodex, and a reference-design codification effort. The competitive position is **defensible against new entrants** (no one can spin up a 60,000-engineer global A&E firm in five years) but **not differentiated against the top 3–4 incumbents** (AECOM most pointedly).

## AI buildout bottleneck map
The 24-month gating constraints, and where Jacobs sits on each:

| Constraint | State of bottleneck | Jacobs' position |
|---|---|---|
| **Large power transformers (345kV/138kV)** | Lead times 128–210 weeks; demand +274% since 2019; ~80% of US large transformers imported [15] | **Beneficiary** — Jacobs designs the substations, but the throughput cap belongs to Hitachi Energy / Siemens Energy / GE Vernova. Jacobs can't accelerate this; it can advise customers on creative interconnect (BTM gas, behind-the-meter SMR, etc.) |
| **Utility interconnect queue / grid capacity** | ERCOT, MISO, PJM queues stretched 4–7 years | **Beneficiary as advisor** — interconnect studies and utility coordination are billable engineering work, even when the project doesn't get built |
| **CoWoS-L / HBM3e** | NVIDIA holds ~60% of CoWoS allocation through 2026; CoWoS-L 510k wafers earmarked [16] | **Indifferent** — operates two layers above silicon |
| **Liquid cooling at >100kW/rack** | CDUs, manifolds, rear-door HXs scaling; supply tightening | **Beneficiary** — Jacobs designs the loop, picks the vendors, sizes the CDU plant. Has documented direct-liquid-cooling reference designs [1] |
| **MEP / electrical labor** | 340k unfilled data-center positions through 2026; aging PE workforce [17] | **Constraint owner partially** — Jacobs is itself competing for the same MEP engineers it bills out. Labor is its COGS. Wage inflation compresses margin if it can't be passed through |
| **GC / electrical contractor capacity** | Quanta $48.5B backlog, EMCOR record DC backlog [18] | **Indifferent / mildly negative** — if GC capacity caps starts, Jacobs' design revenue lags by 6–9 months |
| **Kernel/compiler talent, training data** | Frontier-lab constraints | **Indifferent** |
| **AI-aided design tooling (BIM + LLM)** | Emerging | **Cuts both ways** — could compress engineering hours per project (revenue headwind) or accelerate pipeline conversion (volume tailwind). Jacobs is leaning into this via the NVIDIA Omniverse partnership [9][14] |

The honest read: Jacobs is a **derivative play on data-center starts**, with limited ability to harvest scarcity rent because the binding constraints (transformers, interconnect queues, GPU supply) live upstream and downstream of its work, not at its layer.

## Competitive teardown
Direct competitors, by axis of competition:

- **AECOM (ACM).** The most direct comparable. ~11+ GW delivered across 45 countries over 25 years vs. Jacobs' 3,600 MW over the past decade [3][8]. AECOM is rolling out "AECOM AI" advisory and targeting Advisory NSR to double to $400M [19]. **On data-center A&E, AECOM is at parity or modestly ahead by delivered megawatts.** Jacobs counters with deeper digital-twin integration (NVIDIA DSX) and the Cloud Condos POR. *What has to be true for AECOM to take share:* it ships its own competing reference design at parity speed-to-market, which is achievable in 12–24 months.

- **Fluor (FLR), Bechtel (private).** EPC megaproject firms — they self-perform construction, which Jacobs largely doesn't. Compete on **integrated EPC delivery** rather than design-only. Hyperscalers historically have preferred design-bid-build (Jacobs/AECOM design, separate GC) but a shift toward integrated EPC for >GW campuses would favor Fluor/Bechtel. Watch for hyperscalers consolidating to EPC contracting models.

- **Stantec (STN), WSP, Tetra Tech (TTEK).** Mid-tier A&E firms growing data-center practices off lower bases. *Threat is dilutive, not displacing* — they take incremental share at the edges (smaller colos, edge sites) but lack the gigawatt-campus track record.

- **Hyperscaler in-housing.** Meta and Google have substantial internal data-center design teams; Microsoft and AWS use Jacobs/AECOM more heavily. *The bear path is that Microsoft/AWS replicate the Meta playbook over 3–5 years.* Counter-argument: the gigawatt-campus pivot increases complexity faster than internal teams can hire, which historically pushes work *to* external A&E.

- **Quanta (PWR), EMCOR (EME), MasTec, Comfort Systems.** Not competitors — they are downstream trade contractors. Jacobs designs; they install. **Pair trade consideration:** if you want pure exposure to the same theme with more operating leverage and self-performed work, PWR/EME have arguably tighter linkage to physical buildout volume.

- **NVIDIA's own ecosystem playbook.** NVIDIA's DSX blueprint *commoditizes* the data center reference design over time by publishing best practices. Jacobs is partnering with this (running into the wave) rather than fighting it — sensible, but the partnership's exclusivity is unclear.

## Bull case — technical
For Jacobs to outperform from $118, the following technical conditions need to hold over the next 24 months:

1. **Gigawatt-campus complexity scales faster than hyperscaler in-house engineering teams can hire.** This is the central technical claim. Each step-up in rack power density (10 kW → 30 kW → 130 kW → 250 kW) and campus power (50 MW → 250 MW → 1 GW → multi-GW) introduces new failure modes in cooling, electrical resonance, fault-current handling, and water systems that **the internal teams of MS/AWS/Meta/Google have not previously designed for**. Jacobs' moat is being the consolidated repository of multi-customer learning curve — this only matters if the learning curve keeps steepening.

2. **Reference-design + digital-twin codification becomes a durable margin lever.** If the Omniverse-DSX digital twin reduces re-engineering hours per project by 30–50%, Jacobs harvests that as margin expansion (Q2 was +70 bps on +27% revenue — still labor-bound). Bullish margin path requires the digital-twin tooling to become *operating leverage*, not just a sales tool.

3. **Power transformer / interconnect bottleneck shifts spend toward engineering and away from steel.** When you can't get a 345kV transformer for 3 years, you spend more on substation re-engineering, on-site generation feasibility studies, and SMR/BTM advisory — all Jacobs-billable hours. This is the "constraint-derivative" thesis: as physical-equipment supply tightens, advisory and engineering capture more of the dollar.

4. **AECOM does not ship a competitive reference-design + digital-twin product within 18 months.** This is the key competitive falsifier.

5. **PA Consulting cross-sell delivers ≥15% revenue contribution from joint go-to-market within 24 months** [13].

**Base rate caveat:** technology-driven displacement of incumbents in engineering services is *rare and slow*. Top-tier A&E firms have held their relative positions for decades (Bechtel founded 1898, AECOM ~1990, Jacobs 1947). The displacement risk in this space is meaningfully lower than in silicon or cloud platforms. This makes the bull case more *cycle-dependent* than *moat-dependent*.

**Financial connection:** consensus has FY26 EPS at $7.22 (midpoint of guide $7.10–$7.35) [2]. If data-center grows 40%+ for two more years off a 10–11% mix, AI-related work hits ~17–20% of business by FY28, supporting a multi-year mid-teens EPS CAGR. At 18× FY27 EPS of ~$8.25, fair value is ~$148 (~+25%). Bull case requires multiple re-rate to ~22× on visibility, getting to ~$180.

## Bear case — technical
Where the thesis breaks:

1. **It's a labor body shop with a brand.** Engineering services revenue is fundamentally headcount × utilization × bill rate × realization. Q2 margins expanded 70 bps on 27% revenue growth — that's modest operating leverage for a "tech-adjacent" name. If AI design tooling (Autodesk Forma, Bentley iTwin, internal hyperscaler tooling) compresses billable hours per MW designed, Jacobs faces deflation in its core product. The same digital-twin pitch that bulls cite could become the mechanism by which the work gets commoditized.

2. **AECOM parity is already real.** AECOM has more delivered GW and is publicly aiming at the same advisory margin pool [3][19]. The two firms split the hyperscaler design wallet roughly evenly. Jacobs' premium multiple (15.4× fwd) vs. AECOM (~21× fwd from public data; not independently verified here) does not reflect a moat differential.

3. **Hyperscaler in-housing is a slow-burn risk.** Meta runs a large internal design organization. If MS or AWS shift even 30% of design work in-house over 5 years, Jacobs loses a couple hundred basis points of growth per year. This is observable in headcount disclosures and job postings at the hyperscalers.

4. **Cycle, eventually.** Engineering services is cyclical with capex. The CFOs of MS/META/GOOG/AMZN have signaled $300B+ aggregate capex in 2025–2026 [implicit; widely reported]; any pullback hits Jacobs' *pipeline*-conversion rate first, *backlog* second (with ~9–12 month lag), and *revenue* third (~18 month lag). Backlog at $26.97B is real, but cancellation rates in a hyperscaler-capex pause have not been stress-tested at this scale.

5. **Power and interconnect can stop the buildout before it stops being designed.** Designed-but-unbuilt projects pay design fees but not commissioning fees or change-order revenue. If 30% of designed GW slips 2+ years on transformer/interconnect delays, FY27–28 revenue assumptions look high.

6. **Margin profile is not a software profile.** I&AF segment runs ~11.4% operating margin on net revenue [11]. There is no realistic path to 30%+ margins; this is a services business. Bull cases assuming margin expansion to a "tech multiple" mistake the entity.

## Market view check
At $118 / 15.4× FY26 EPS and 1.1× NTM revenue, with consensus PT ~$155 implying +30%, the market is paying a roughly **industrial-services multiple with a modest AI premium**. AECOM trades at a *higher* multiple despite a comparable franchise — implying the market is *not* aggressively pricing Jacobs as an AI-infrastructure pure play. The 23% drawdown from the October 2025 high of $164 [2][10] suggests the AI-data-center trade has already de-rated mid-2026 alongside hyperscaler capex digestion fears. **The market view appears to be: real beneficiary, durable cycle, but not a multiple-expansion story.** I think that read is approximately correct on the moat (Jacobs is not CUDA), slightly too cautious on the cycle duration (visibility into 2028 is real per management [12]), and roughly fair on multiple. Mispricing, if any, is modest — call it 15–25% upside to fair value, not 2×.

## 90-day falsifiers
Observable signals in the next 90 days that would meaningfully update the thesis:

1. **NVIDIA GTC fall keynote (likely Q3) DSX partner roster.** If AECOM or a hyperscaler in-house team gets equal-or-superior billing to Jacobs on the DSX blueprint, the digital-twin moat narrative weakens.
2. **Microsoft / Alphabet / Meta / Amazon next earnings (late-July / early-Aug 2026).** If aggregate hyperscaler capex guidance is cut >10% sequentially or 2027 capex commentary turns cautious, Jacobs' pipeline-conversion assumptions need to come down.
3. **AECOM Q3 FY26 earnings (Aug 2026).** A side-by-side read on data-center backlog growth — if AECOM grows DC backlog faster than Jacobs' +21.7%, parity-or-loss signal.
4. **Jacobs Q3 FY26 print (early-Aug 2026).** Watch for: (a) data-center pipeline conversion to backlog (book-to-bill in DC specifically), (b) operating leverage — does margin expansion exceed 70 bps? (c) FY27 commentary on backlog burn.
5. **PE labor inflation print.** Engineering-services wage data (BLS, Robert Half industry reports) — if PE wages run >8% YoY, margin compression risk materializes.
6. **Power-transformer lead-time updates (Hitachi Energy, GE Vernova earnings).** If lead times extend further, designed-but-unbuilt risk grows; if they compress, conversion accelerates.
7. **Any hyperscaler insourcing announcement** (e.g., AWS standing up a major internal data-center design org). Slow burn but tape-bombable.

## What I could not verify
- Whether **Cloud Condos** and the **Omniverse DSX digital twin** generate licensing revenue or are purely sales-enablement assets. The economics of the "IP" moat hinge on this and I could not source it.
- Exact **revenue concentration by hyperscaler customer**. Jacobs does not disclose; sales of $X to Microsoft / $Y to AWS would materially change the customer-concentration risk read.
- **Headcount per delivered MW** trends and whether the digital twin is actually reducing it. The labor-leverage thesis depends on this.
- Independent **MW-delivered comparison** between Jacobs and AECOM on a like-for-like basis (different disclosure windows: Jacobs cites "past decade" 3,600 MW; AECOM cites "past 25 years" 11+ GW).
- Whether **NVIDIA partnership has any exclusivity** or is non-exclusive ecosystem participation.
- **PA Consulting cross-sell pipeline conversion**, beyond management's "very high" qualitative language [13].
- **AECOM's current forward multiple and 2026 backlog growth** at sufficient precision for direct head-to-head valuation.
- Whether large hyperscaler **EPC contracting model is shifting** toward integrated EPC (Fluor/Bechtel-favorable) or staying design-bid-build (Jacobs/AECOM-favorable).
- Detail on the **percentage of Jacobs DC work that is greenfield-design vs. commissioning vs. owner's rep** — different revenue durability profiles.

## Sources
[1] https://www.jacobs.com/sites/default/files/2022-04/Jacobs-2021-Mission-Critical-Capabilities.pdf — retrieved 2026-05-10 — Jacobs' own capabilities deck establishing 11M ft² / 2,000 MW historical delivery, hyperscaler customer list (MS, AWS, OCP, USACE), and direct-liquid-cooling reference designs.
[2] https://finance.yahoo.com/markets/stocks/articles/rbc-capital-raises-price-target-105356153.html — retrieved 2026-05-10 — RBC raises PT to $169 May 6 2026; cites Q2 print, FY26 raise to $7.10–$7.35 EPS; YTD return –7.2%; trading 23.6% below 52-wk high $164.44 (Oct 2025).
[3] https://www.blackridgeresearch.com/blog/latest-top-largest-data-center-construction-epc-builders-firms-companies-in-the-world — retrieved 2026-05-10 — Top-10 DC construction company ranking placing AECOM #1, Jacobs in top 3; Jacobs delivered 17M ft² / 3,600 MW / >$30B in construction value over the past decade.
[4] https://www.jacobs.com/newsroom/press-release/jacobs-spin-off-and-merge-its-critical-mission-solutions — retrieved 2026-05-10 — Jacobs–Amentum CMS spinoff completed Sept 2024; segment realignment establishing I&AF and PA Consulting as two reporting segments.
[5] https://stockanalysis.com/stocks/j/statistics/ — retrieved 2026-05-10 — Snapshot data: price $118.43 (May 8, 2026), mkt cap $13.98B, EV $17.17B, fwd P/E 15.43, P/S 1.06, EV/Rev 1.30, shares out 118.08M, short interest 3.77% of float, beta 0.71.
[6] https://stockanalysis.com/stocks/j/forecast/ — retrieved 2026-05-10 — Analyst consensus PT $153–156 range; 10 analysts, "Buy" rating.
[7] https://www.jacobs.com/solutions/markets/advanced-manufacturing/data-centers — retrieved 2026-05-10 — Jacobs services menu: design, construction, commissioning, owner's-rep for data centers.
[8] https://aecom.com/markets/industrial/high-tech/ — retrieved 2026-05-10 — AECOM claims 11+ GW delivered across 45 countries over 25 years.
[9] https://www.prnewswire.com/news-releases/jacobs-releases-digital-twin-solution-for-ai-data-centers-302714843.html — retrieved 2026-05-10 — Jacobs Digital Twin solution released March 16, 2026, built on NVIDIA Omniverse DSX blueprint, gigawatt-scale + 250 MW reference designs.
[10] https://www.dailypolitical.com/2026/05/09/jacobs-solutions-nysej-price-target-raised-to-181-00.html — retrieved 2026-05-10 — 52-week low $118.38 / high $168.44.
[11] https://www.businesswire.com/news/home/20260505139418/en/Jacobs-reports-strong-fiscal-second-quarter-2026-results — retrieved 2026-05-10 — Q2 FY26 results: revenue $3.69B (+27% YoY), backlog $26.97B (+21.7%), I&AF op profit $225.2M (11.4% margin), PA Consulting $358.6M rev / 22.3% margin.
[12] https://www.constructiondive.com/news/jacobs-earnings-may-2026-data-center-investment-cycle/819518/ — retrieved 2026-05-10 — Pragada quote: "still in early stages"; DC pipeline +400% YoY; visibility through 2027 into 2028.
[13] https://www.fool.com/earnings/call-transcripts/2026/05/05/jacobs-j-q2-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q2 transcript: AI ecosystem 10–11% of business growing >40%; DC revenue >100% YoY; PA cross-sell now unblocked from UK conflict restrictions.
[14] https://www.marketscreener.com/news/jacobs-rsquo-data-center-digital-twin-featured-in-nvidia-gtc-keynote-ce7e5edcdc8df723 — retrieved 2026-05-10 — Jacobs digital twin featured in NVIDIA GTC keynote.
[15] https://timlig.com/posts/ai-supply-chain-crisis/ — retrieved 2026-05-10 — Large power transformer lead times 128–210 weeks; demand +274% since 2019; ~80% imported; individual units 100–400 tons.
[16] https://www.astutegroup.com/news/industrial/advanced-packaging-demand-soars-nvidia-secures-60-of-cowos-capacity/ — retrieved 2026-05-10 — NVIDIA ~60% of 2026 CoWoS allocation; ~510k wafers earmarked for CoWoS-L.
[17] https://introl.com/blog/data-center-workforce-shortage-340000-unfilled-positions-2026 — retrieved 2026-05-10 — 340,000 unfilled data center positions through 2026; specific demand for MEP engineers, commissioning agents, liquid-cooling techs.
[18] https://finance.yahoo.com/markets/stocks/articles/quantas-record-48-5b-backlog-160200162.html — retrieved 2026-05-10 — Quanta backlog $48.5B end 2025; RPO $15.62B Q1 2026 +32.9% YoY.
[19] https://investors.aecom.com/news-releases/news-release-details/aecom-announces-increased-financial-targets-built-further — retrieved 2026-05-10 — AECOM AI advisory platform; targets doubling Advisory NSR to $400M over three years.