# MRVL — Marvell Technology, Inc.

## Where this sits in the AI stack
Marvell is a **chip shepherd and connectivity silicon vendor** sitting one layer below the hyperscaler XPU and one layer above the optical transceiver module. Physically, MRVL sells (1) hyperscaler-owned custom AI accelerators ("XPUs") that it co-designs, takes through physical implementation, and shepherds through TSMC + advanced packaging — anchored by AWS Trainium 2, in transition on Trainium 3, and contested on the next nodes; (2) "XPU-attach" silicon — PCIe Gen6/CXL retimers, CXL memory controllers (Structera), NICs, AECs; (3) 1.6T PAM4 and 2nm coherent optical DSPs (Nova, Ara, Spica, Electra) that drop into pluggable transceivers across scale-out and DCI links; (4) Teralynx 10, a 51.2 Tbps merchant Ethernet switch ASIC; and (5) post-Celestial-AI, a "Photonic Fabric" stack aimed at optical scale-up I/O [1][2][6][9]. It does not own software runtimes, it is not in the NVLink hardware path (yet), and it does not sell into power/cooling.

## Snapshot
- **Price:** $170.13 (2026-05-08 close; May 9 saw a ~7% intraday selloff on profit-taking and a JPMorgan note disputing the Google "win" framing) [1][14]
- **Market cap:** $148.77B (874.46M shares out) [3]
- **52-week range:** ~$56 (June 2025 trough, implied by +202% 1-yr return) – $175.79 (intraday high during early-May 2026 rally) [1][3]
- **Forward P/E:** 44.4× (FY27 non-GAAP EPS consensus ~$3.83) [3]; trailing GuruFocus quoted 43.1× as of 2026-05-05 [15]
- **EV / NTM revenue:** ~13.5× ($150.9B EV against ~$11B FY27 management guide); ~10× on FY28 ~$15B guide [3][8]
- **Consensus 12-month price target:** $122.63 (32 analysts; "Strong Buy") — **implied ~ -28% from current price**; high $195, low $67 [16]
- **YTD total return:** estimated **+85–90%** through May 8 (March '26 Q4 print + Nvidia $2B deal + Google rumor compounded a ~100%+ rally; 1-yr return +202%) [3][14]
- **Short interest (% of float):** 3.33% [3]

## Moat — what it is physically made of
Marvell's moat is **not** developer ecosystem (it has none comparable to CUDA) and **not** branded compute (no MRVL-branded ASIC at the workload layer). It is a portfolio of IP blocks and a service relationship — a credible but eroding moat. Decomposing:

**1. SerDes / analog mixed-signal IP.** The defensible core. Marvell ships production 112G PAM4 SerDes and is rolling 224G PAM4 across its own DSPs, the Teralynx 10 switch, and customer XPUs [10][11]. Replicating a fab-qualified 224G SerDes block at parity is a 3–5 year, ~$200M+ effort even for well-funded teams (Synopsys, Cadence, Alphawave all sell IP variants but hyperscaler-grade integration is harder than the datasheet) [11]. This is also the IP that underwrites the 1.6T PAM4 DSP line (Nova/Ara) and the 2nm Electra coherent DSP that just entered production in Q4 FY26 [6][18]. **Durable, ~3–5 years.**

**2. HBM PHY, die-to-die, and chiplet integration.** Marvell has a productized 240 Tb/s die-to-die interconnect and HBM3/HBM3e controllers running in shipping Trainium 2 silicon [10]. However, this is precisely where Marvell lost ground: SemiAnalysis reports the Trainium 3 socket went to Alchip because Marvell's **chiplet-based proposal with an RDL interposer had poor execution** on Trainium 2, requiring Alchip to step in to deliver a workable interposer [4]. That is moat-relevant: chiplet/RDL execution is the active battleground, and Marvell has visibly stumbled at it once.

**3. Optical DSP leadership.** Marvell shipped the first 5nm 800G PAM4 (Spica) and the first production 1.6T PAM4 (Nova/Ara), and the first 2nm 1.6T ZR/ZR+ coherent DSP (Electra) for DCI [6][18]. Optical DSP is a 3-player merchant market (Marvell, Broadcom, smaller Inphi-style players) with high analog mixed-signal barriers. **The most durable single piece** — every 800G/1.6T pluggable optic uses one, and a 1.6T port needs ~2 DSPs (host-side or in-module). **Durable 3–5 years; CPO is the threat (see below).**

**4. Customer contracts and "design wins."** 18 active programs, "20+" wins through FY28-29, $75B claimed lifetime contract value across the pipeline [2][17]. Importantly: these are **multi-generational engagements**, not transactional tape-outs. AWS Trainium and Microsoft Maia engagements are estimated to extend 2–3 generations. But hyperscaler loyalty is conditional, not contractual — losing Trainium 3 proves that.

**5. CoWoS / wafer allocation.** Marvell has secured ~55,000 CoWoS wafers for AWS + Microsoft custom chips and 3nm/N3P advanced-packaging slots for calendar 2026 production [4][9]. This matters because NVIDIA has booked ~60% of TSMC's CoWoS capacity and 2nm/A16 fabs have 78–104 week lead times [9][13]. Marvell's allocation is meaningful but ~10% the scale of NVIDIA's; Marvell reportedly **canceled some 2026 CoWoS-R orders** after the Trainium 3 loss [4]. **A capacity moat that compounds with each successful program — and decompounds when a program is lost.**

**6. NVLink Fusion access (post-$2B Nvidia investment, March 31 2026).** Marvell is one of a short list of vendors (with MediaTek, Astera Labs, Synopsys, Cadence, Alchip) granted NVLink IP licensing to build NVLink-compatible XPUs into Nvidia rack-scale platforms [7][12]. NVIDIA controls the whitelist. This is a brand/strategy moat more than a technical one — it makes Marvell harder to bypass for any customer who wants to participate in NVL-Fusion racks, but Astera Labs and MediaTek hold the same key.

**Where there is no moat:** software runtime (Marvell does not own Neuron SDK, MAIA SDK, or compilers — those are hyperscaler-owned), application-layer; brand-on-the-rack visibility; merchant GPU compute (irrelevant). The "CUDA equivalent" doesn't apply here because Marvell's value-add ends at silicon hand-off; the hyperscaler owns the software stack.

## AI buildout bottleneck map
Over the next ~24 months, the binding constraints on AI buildout, and where Marvell sits on each:

- **CoWoS-L advanced packaging.** TSMC ramping from ~35K wafers/month (late 2024) to ~130K by end-2026 [9][13]. Marvell is a **constrained beneficiary** — has an allocation, but it's small relative to NVIDIA and contested with Broadcom. A loss-of-program (Trainium 3) directly reduces the share that converts to revenue.
- **HBM3e → HBM4 supply.** Trainium 3 ships with 12-high HBM3e at 9.6Gbps from Hynix/Micron; Trainium 4 is targeted at 8-stack HBM4 at ~4× bandwidth [4]. Marvell does not make HBM; it integrates HBM PHY and depends on its customers securing HBM. **Indirect exposure**: an HBM4 shortage hits XPU production volumes more than NVIDIA's allocation because hyperscalers are last in the supply queue.
- **2nm / 3nm leading-edge logic.** N3 fully booked, N2 78–104 week lead times [13]. Marvell has confirmed 3nm tapeouts in production for FY27 (1.6T Ara, Electra coherent DSP at 2nm) [6][18]. **Beneficiary** of staying on the leading edge but exposed to slip in customer tape-outs.
- **Optical interconnect supply (DSPs + transceivers).** Every 1.6T port needs PAM4 DSPs, and AI clusters at 100K+ XPU scale push ~10–20 optical transceivers per XPU. Marvell + Broadcom dominate merchant PAM4 DSP. **Direct beneficiary** — the volume scales superlinearly with cluster size because per-XPU bandwidth grows.
- **Co-packaged optics (CPO).** A future bottleneck and an opportunity. Marvell has demoed a 6.4T 3D SiPho engine and acquired Celestial AI for $3.25B–$5.5B in Dec '25 for optical scale-up I/O [5][8]. **Beneficiary if CPO replaces pluggables — and a threat to Marvell's own pluggable DSP business if Nvidia drives CPO adoption inside Spectrum-X/NVL72**, since CPO bypasses retimers and AEC vendors entirely.
- **Power generation, grid interconnect, GE Vernova/Siemens turbine backlog (4-quarter+ lead times), 100kW+ rack liquid cooling.** **Indifferent.** No Marvell exposure. This is Vertiv, GE Vernova, Eaton territory. Worth noting because a power-bottlenecked buildout would actually compress demand — but as of Q1 2026, hyperscaler capex is still accelerating (~$112B in the quarter alone) [19].
- **Kernel/compiler talent.** **Indifferent.** This is the hyperscaler's problem (NKI for Trainium, MAIA SDK for Microsoft, XLA for Google). Marvell does no kernel work.

## Competitive teardown

**Broadcom (AVGO) — the dominant competitor.** AVGO has ~70–80% of custom AI ASIC merchant share to Marvell's ~15% [20][21][22]. AVGO Q1 FY26 AI semi revenue: **$8.4B in a single quarter, +106% YoY** [21]. Marvell's full-year custom run rate is ~$1.5B. On Apr 7 2026, Broadcom locked a **multi-year-through-2031 deal as primary architect for Google TPU v7 "Ironwood"** on 3nm, with 9.6 Tbps SerDes [23]. This forecloses the largest custom socket (TPU is roughly the size of Trainium + Maia combined). On the merchant switch side, Broadcom's Tomahawk 5 / Jericho / Tomahawk 6 line is the volume incumbent against Teralynx 10 [24]; Marvell matches on bandwidth (51.2T) and claims latency leadership (<600ns) but Broadcom owns the deployed install base.
- *Axis Marvell can win*: optical DSP (Marvell is first to 1.6T at 2nm, ahead of Broadcom on coherent ZR), and CPO if Celestial AI's photonic fabric scales.
- *Axis Marvell cannot win at parity*: switch silicon at hyperscale, breadth of custom programs, gross margin (AVGO operates >60% non-GAAP gross margins vs MRVL ~62%, similar headline but AVGO scales it across 4–5× the AI revenue base).

**Alchip (3661.TT) — the displacer.** ASIC design service, primarily Taiwan-based. Took Trainium 3 from Marvell after Marvell's chiplet/RDL interposer execution failed; SemiAnalysis: Marvell's "development timeline took far too long" [4]. Alchip handles Trainium 3 backend physical design and packaging (two tapeouts: "Anita" Alchip-owned, "Mariana" Annapurna-owned, Mariana is majority volume) [4]. Likely sole XPU supplier on Trainium 3, contesting for Trainium 4 (Morgan Stanley flagged exclusive supply potential) [25]. Alchip is cheaper, faster, and now has a flagship XPU reference — the playbook against Marvell is now established.
- *Marvell counter*: deeper analog/SerDes IP (Alchip leans on Synopsys/Cadence for SerDes); already-integrated HBM PHY + CXL + optical stack; US/IP-friendly export geography. But the trend line favors Alchip on cost-sensitive sockets.

**Astera Labs (ALAB).** Direct competitor on **XPU-attach** layer — PCIe Gen6 retimers, CXL switching, NVLink Fusion-compatible scale-up [26]. Astera is faster-moving and has won Nvidia/AMD retimer attach. Marvell's stated $1B XPU-attach FY28 target sits in the same TAM Astera wants. *Likely outcome*: split market, Astera taking premium attach sockets, Marvell taking attach sockets that bundle with its XPU shepherding wins.

**Credo Technology.** Active electrical cable (AEC) dominator. **Threat to Marvell's optical DSP TAM growth** if AECs win the short-reach (3m) intra-rack and inter-rack links; conversely, Credo is threatened by CPO and 1.6T optical pushing into 7m+ reach. Symmetric exposure.

**MediaTek + Google in-house designs.** MediaTek is in the NVLink Fusion partner list and is a fourth named partner in Google's TPU/inference supply chain alongside Broadcom, Marvell, and GUC [27]. MediaTek brings cost discipline from mobile silicon scale and is the wildcard on Asian-cost custom XPU.

**GUC (Global Unichip).** Physical implementation partner for Microsoft Maia 200 (codename "Braga") and other TSMC-attached programs. Marvell's role on Maia 200 is **not** the lead — that goes to GUC — and Marvell's named role appears to be on the **next-generation Maia 300** as co-design partner [28]. This is a meaningful nuance: the Maia 200 launch revenue going to Microsoft (3nm, 216GB HBM3e, 5,072 FP8 TFLOPS, claimed 3× FP4 of Trainium 3) does not flow predominantly to Marvell [28][29].

## Bull case — technical
For MRVL to outperform from $170, several technical conditions must hold:

**Custom silicon market expands faster than Marvell loses share within it.** Bernstein-/SemiAnalysis-style consensus puts custom AI ASIC TAM at ~$45B by 2028, ~3× FY26. Marvell at 15% share — even with the Trainium 3 loss to Alchip — at the bottom of that range gets to ~$6–7B. At 20% (Murphy's stated target [22]), $9B. Layered with $1–2B XPU-attach, $2B+ DSPs, and switch/storage, the FY28 ~$15B guide is achievable. **Base rate caveat**: design-services market share, once lost on a program, rarely comes back at the next generation. Trainium 3 → Alchip is unlikely to flip back to Marvell at Trainium 4 unless Alchip stumbles. So the bull case requires *new program wins* (Google MPU/inference TPU, Maia 300, OpenAI silicon, Apple AI, etc.) to outpace Trainium-class attrition.

**Optical DSP & CPO ride the bandwidth-scaling curve.** Cluster scale-up from 100K → 1M+ accelerators means per-XPU optical bandwidth grows from ~3.2T to ~12.8T. Marvell's first-mover position on 1.6T PAM4 (Nova/Ara) and 2nm coherent (Electra) plus Celestial AI's optical scale-up I/O directly monetizes this scaling [6][18][8]. CPO could move $500M run rate by 2028 and $1B by 2029 [17].

**Nvidia NVLink Fusion converts to bookings.** The $2B Nvidia investment + NVLink IP license positions Marvell to be the **default custom XPU vendor inside Nvidia racks** for customers who want bespoke compute but Nvidia rack integration [7]. If even one major hyperscaler routes a 2027 program through this channel, it offsets Trainium 3 attrition. Bull pricing requires this to materialize.

**Base rate on platform displacement at this cycle stage.** Custom silicon has been chipping away at NVIDIA at ~5–10% of incremental hyperscaler XPU spend per generation since 2023. Bull case is this rate continues or accelerates as Nvidia gross margins remain in the 70%s. Historically, vertical integration (CPU→GPU; x86→ARM in mobile) takes 5–10 years to displace incumbents — we are 2–3 years into the custom-XPU cycle, suggesting another 3–5 years of share gain runway.

**Financial sanity check.** $15B FY28 at ~30% non-GAAP operating margin = $4.5B operating income → ~$5 EPS. At 40× forward, $200 stock; at 30×, $150. The $170 price is essentially priced for the bull case to substantially hit, with limited margin for further multiple expansion.

## Bear case — technical
The honest short thesis:

**The Trainium 3 loss is the leading indicator, not the anomaly.** Marvell's RDL interposer/chiplet execution failed on a flagship program. The same execution risk lives in Trainium 4, Maia 300, and any new socket. Alchip is cheaper and now has a reference design. If Marvell loses Trainium 4 to Alchip and Maia 300 stalls, the FY28 custom doubling does not happen and the FY28 $15B guide is unreachable.

**Broadcom locks the largest sockets.** Google Ironwood TPU v7 through 2031 ($60–90B serviceable AI revenue from three customers by FY27 per AVGO mgmt [21]) is foreclosed. The "Marvell wins Google" April 2026 rumor was just talks; JPMorgan disputed the "win" framing [14]. Marvell's pipeline relies on emerging customers (OpenAI, xAI, sovereign-AI labs) where unit economics and program longevity are unproven.

**Customer concentration risk.** AWS is the dominant customer at ~40%+ of data center revenue. The Trainium 2 → R2 transition keeps AWS engaged on 5nm Marvell silicon through CY2026, but Trainium 3 volumes shift to Alchip [4]. If AWS chooses Alchip for Trainium 4, Marvell's AWS revenue can step down sharply in FY28–29.

**CPO cannibalizes pluggable DSP economics.** Nvidia's roadmap suggests CPO inside Spectrum-X switches by 2027–2028. The 6.4T SiPho engine and Celestial photonic fabric are Marvell's hedge, but they cannibalize Marvell's own 1.6T pluggable DSP volumes, which are ~$1–1.5B revenue today. The transition is uncertain in timing and gross margin impact.

**Valuation is extended.** Forward P/E 44× against ~30% growth, EV/NTM rev 13.5×, vs sell-side PT $122 (-28%). On a +202% one-year return and 2.25 beta [3], any earnings miss or program-loss disclosure is a -20%+ event (the May 9 -7% on profit-taking + a JPMorgan note is a preview). Short interest 3.3% means the squeeze fuel is gone.

**Software/runtime moat is structurally absent.** Marvell does not own a developer ecosystem. If the hyperscaler-custom-silicon era turns out to be a phase rather than a permanent restructuring (Nvidia margins compress, training shifts back to merchant GPUs as inference scales), Marvell has nothing to fall back on that has CUDA-grade defensibility.

## Market view check
At $170 and ~44× forward P/E vs ~30–35% growth, the market is pricing Marvell at roughly **PEG ~1.4** — premium but not absurd if FY28 $15B guide holds. The 27.92% gap to consensus PT $122 says the sell-side has not yet caught up — typical of a stock that has rallied 202% in 12 months [3][16]. What the market is implicitly believing: (a) Marvell hits or exceeds FY28 $15B; (b) Nvidia NVLink Fusion + Celestial AI create a third leg beyond Trainium and Maia; (c) the Trainium 3 loss is contained and does not propagate to Trainium 4 or Maia 300; (d) Google MPU/inference TPU talks materialize into bookings. I disagree on (c) — Alchip's execution win is structural, not one-off — and on the time it takes (d) to translate into revenue. The price has more downside risk than upside on a 6-month horizon, but the structural setup (Nvidia behind it, hyperscaler capex still accelerating, optical DSP roadmap intact) supports the multi-year story. **Mispriced rich short-term, fairly priced long-term, contingent on execution.**

## 90-day falsifiers
1. **Q1 FY27 earnings (late May 2026): does Marvell guide Q2 FY27 above $2.55–2.6B?** Below would imply Trainium 3 attrition is hitting sooner; above confirms the AWS R2 ramp [17].
2. **AWS Trainium 4 design partner disclosure (or leak via SemiAnalysis / Morgan Stanley).** If Alchip is confirmed sole supplier or if Marvell is excluded from the chiplet/interposer work, the FY28 doubling thesis breaks. If Marvell is reinstated alongside Alchip on UALink/NVLink variants, the bear case loses force [4][25].
3. **Google TPU/MPU formal contract signing or denial.** JPMorgan flagged talks-only on May 7–8 [14]. A signed agreement before Aug 2026 would be a major upside catalyst; continued silence is a slow-burn negative.
4. **TSMC quarterly CoWoS allocation update (July 2026 earnings).** Specifically, MRVL's share commentary and any Marvell-specific CoWoS-R cancellations or additions.
5. **Microsoft Maia 200 production volume disclosure** (Build conference / earnings). If Maia 200 sells through and Maia 300 is confirmed Marvell-led on disclosure, it offsets Trainium 3.
6. **AVGO Q2/Q3 FY26 AI semi guidance.** If Broadcom guides AI semis to >$10B/qtr by Q4, it confirms the custom socket pie is expanding fast enough to absorb Marvell's share losses.
7. **Hyperscaler Q2 2026 capex revisions** (Microsoft, Alphabet, Amazon, Meta). >10% sequential cut at any one of these is a sector-wide trigger.
8. **Nvidia GTC fall 2026 / NVLink Fusion partner production milestones.** If a real customer racks a Marvell-XPU NVL-Fusion system in 2H26, the $2B Nvidia investment converts to demonstrated bookings.
9. **Celestial AI integration progress** — first taped-out photonic fabric product on a Marvell roadmap chart.

## What I could not verify
- **Exact Marvell share of TSMC CoWoS-L allocation** vs. NVIDIA's ~60% and AVGO's reported ~25%. The "55K wafers for AWS + Microsoft" figure is from a single Q1 2026 capacity tracker [9] and not corroborated by Marvell directly.
- **Whether Marvell is on Trainium 4 at all**, vs. relegated to attach-only. SemiAnalysis says Alchip leads backend; Marvell management says they have visibility "through Trainium 4 specs" — those are not mutually exclusive but the boundary is unclear [3][17].
- **The actual revenue impact of Trainium 3 loss in FY27.** Management has not broken out AWS XPU vs attach revenue. Public estimates of the program loss range from "minor since R2 replaces it" to "~$500M FY27 hit."
- **Maia 300 design partner role**. The X/Twitter leak suggests Marvell co-designs [28]; I could not find a Microsoft- or Marvell-confirmed primary source.
- **Patent strength.** PatSnap referenced 250+ Marvell vs Broadcom AI chip patent filings analyzed but I did not fetch the full breakdown — Marvell's IP defensibility relative to AVGO at the SerDes/HBM PHY layer remains directionally clear but not quantified [10].
- **CPO timing risk to existing pluggable DSP revenue.** No primary source on whether Nvidia's Spectrum-X CPO transition cannibalizes 1.6T PAM4 DSP shipments in 2027 or 2028.
- **NVLink Fusion bookings pipeline.** The $2B Nvidia investment is announced; I could not verify any specific customer commitment downstream [7].

## Sources
[1] https://247wallst.com/investing/2026/05/07/marvell-reaches-all-time-highs-buy-sell-or-hold/ — retrieved 2026-05-10 — May 8 close $170.13 (+6.32%) and May 9 ~7% intraday drop context
[2] https://www.nextplatform.com/2025/09/03/marvells-custom-xpu-pipeline-is-a-declaration-of-ai-independence/ — retrieved 2026-05-10 — 18 active programs, 12 across 4 hyperscalers (3 XPUs + 9 attach), $75B lifetime pipeline
[3] https://stockanalysis.com/stocks/mrvl/statistics/ — retrieved 2026-05-10 — Market cap $148.77B, EV $150.92B, fwd P/E 44.4, P/S TTM 18.15, fwd P/S 13.47, short int 3.33%, 1-yr +202%
[4] https://newsletter.semianalysis.com/p/aws-trainium3-deep-dive-a-potential — retrieved 2026-05-10 — Trainium 3 socket lost by Marvell to Alchip due to RDL interposer/execution failure; Anita/Mariana tapeouts; Marvell canceled some 2026 CoWoS-R orders
[5] https://www.marvell.com/company/newsroom/marvell-co-packaged-optics-architecture-custom-ai-accelerators.html — retrieved 2026-05-10 — 3D SiPho engine 6.4T, modular 1.6T-6.4T scaling
[6] https://www.marvell.com/company/newsroom/marvell-1-6t-zr-zr-plus-pluggable-2nm-coherent-dsp-ai-interconnects.html — retrieved 2026-05-10 — COLORZ 1600 + Electra 2nm 1.6T ZR/ZR+ coherent DSP
[7] https://nvidianews.nvidia.com/news/nvidia-ai-ecosystem-expands-as-marvell-joins-forces-through-nvlink-fusion — retrieved 2026-05-10 — Mar 31 2026 $2B Nvidia investment + NVLink Fusion partnership scope
[8] https://www.marvell.com/company/newsroom/marvell-completes-acquisition-celestial-ai.html — retrieved 2026-05-10 — Celestial AI close, $3.25B base / up to $5.5B earnouts, photonic fabric scale-up I/O
[9] https://siliconanalysts.com/analysis/foundry-allocation-status-q1-2026 — retrieved 2026-05-10 — N3 fully booked, 2nm 78–104 weeks; Marvell 55K wafers for AWS + Microsoft custom chips
[10] https://newsletter.semianalysis.com/p/marvelldeepdive2022 — retrieved 2026-05-10 — Marvell IP stack: 112G/224G SerDes, 240Tb/s D2D, HBM3/3e controllers; positioning on both NVLink and UALink
[11] https://www.trendforce.com/news/2026/03/13/news-serdes-wars-heat-up-broadcom-marvell-mediatek-battle-for-ai-interconnect-supremacy/ — retrieved 2026-05-10 — 224G SerDes competitive landscape, Marvell vs Broadcom vs MediaTek
[12] https://www.marvell.com/company/newsroom/marvell-expands-custom-compute-platform-with-ualink.html — retrieved 2026-05-10 — UALink scale-up solution with 224G SerDes and UALink PHY IP
[13] https://markets.financialcontent.com/stocks/article/tokenring-2026-2-5-tsmc-to-quadruple-advanced-packaging-capacity-reaching-130000-cowos-wafers-monthly-by-late-2026 — retrieved 2026-05-10 — TSMC CoWoS to ~130K wafers/mo by end-2026; Nvidia ~60% allocation
[14] https://www.proactiveinvestors.com/companies/news/1090855/marvell-falls-back-after-reports-on-google-ai-chip-talks-disputed-by-analysts-1090855.html — retrieved 2026-05-10 — JPMorgan disputes "Marvell won Google TPU" framing; talks only, Broadcom incumbent
[15] https://www.gurufocus.com/term/forward-pe-ratio/MRVL — retrieved 2026-05-10 — Fwd P/E 43.11 as of 2026-05-05; sector median 34.29
[16] https://www.tipranks.com/stocks/mrvl/forecast — retrieved 2026-05-10 — 32 analysts, Strong Buy consensus, average PT $122.63
[17] https://www.fool.com/earnings/call-transcripts/2026/03/05/marvell-mrvl-q4-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q4 FY26 transcript: FY27 ~$11B, FY28 ~$15B; data center +40% then +50% YoY; custom >20% then 2× ; 20+ design wins by FY28-29; 1.6T coherent production
[18] https://investor.marvell.com/news-events/press-releases/detail/1013/marvell-ushers-in-the-1-6t-era-with-expanded-optical-dsp-platform-portfolio — retrieved 2026-05-10 — Nova / Ara X / Ara T / Petra / Aquila M / Electra sampling Q1 2026
[19] https://tomtunguz.com/2026-04-29-the-112-billion-quarter-hyperscalers-bet-the-farm-on-ai/ — retrieved 2026-05-10 — Q1 2026 hyperscaler capex $112B; Amazon $44.2B, Google $35.67B, Microsoft $30.88B
[20] https://seekingalpha.com/news/4555407-broadcom-is-best-in-class-in-asic-market-but-marvell-qualcomm-catching-up-evercore — retrieved 2026-05-10 — Evercore: Broadcom best-in-class, Marvell + Qualcomm catching up in ASIC
[21] https://www.tradingkey.com/analysis/stocks/us-stocks/261826119-broadcom-marvell-asic-google-deal-ai-chips-valuation-competition-tradingkey — retrieved 2026-05-10 — AVGO Q1 FY26 AI semi $8.4B +106%; MRVL Q4 AI ~$960M; AVGO ~70% ASIC share
[22] https://www.heygotrade.com/en/blog/broadcom-vs-marvell-custom-ai-silicon-battle-2026/ — retrieved 2026-05-10 — Murphy 20% ASIC market share target; Marvell ~15% share
[23] https://markets.financialcontent.com/stocks/article/marketminute-2026-4-9-broadcom-cemented-as-ai-infrastructure-backbone-with-landmark-2031-google-and-anthropic-deals — retrieved 2026-05-10 — AVGO + Google Ironwood TPU v7 through 2031, 3nm, 9.6 Tbps SerDes
[24] https://www.servethehome.com/inside-a-marvell-teralynx-10-51-2t-64-port-800gbe-switch/ — retrieved 2026-05-10 — Teralynx 10 51.2T monolithic 5nm, <600ns latency; matched to Tomahawk 5 bandwidth
[25] https://x.com/Jukanlosreve/status/1940903893556514936 — retrieved 2026-05-10 — Morgan Stanley (C. Chan): Alchip likely exclusive Trainium 3 supplier with high probability of Trainium 4
[26] https://seekingalpha.com/article/4800387-astera-labs-breaking-ai-connectivitys-duopoly — retrieved 2026-05-10 — Astera Labs breaking Marvell/Broadcom connectivity duopoly in retimers + CXL
[27] https://thenextweb.com/news/google-inference-chips-nvidia-challenge-supply-chain — retrieved 2026-05-10 — Google 4-partner inference chip supply chain: Broadcom, MediaTek, Marvell, GUC
[28] https://x.com/wallstengine/status/1950521888196722965 — retrieved 2026-05-10 — Maia 200 "Braga" slipped to 2026 (GUC-led); Maia 300 co-designed with Marvell
[29] https://www.tomshardware.com/pc-components/cpus/microsoft-introduces-newest-in-house-ai-chip-maia-200-is-faster-than-other-bespoke-nvidia-competitors-built-on-tsmc-3nm-with-216gb-of-hbm3e — retrieved 2026-05-10 — Maia 200 specs: TSMC 3nm, 216GB HBM3e, 5,072 FP8 TFLOPS, 3× FP4 of Trainium 3