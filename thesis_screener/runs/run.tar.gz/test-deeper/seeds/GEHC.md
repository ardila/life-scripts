# GEHC — GE HealthCare Technologies Inc.

## Where this sits in the AI stack
GEHC is **not** an AI infrastructure company. It is the largest Western imaging-and-diagnostics OEM (MRI, CT, ultrasound, X-ray, patient monitoring, iodinated/gadolinium contrast media, PET/SPECT radiotracers) [1][9]. AI shows up in two narrow places: (a) **edge inference** baked into scanners — deep-learning image reconstruction (AIR Recon DL, Sonic DL, Effortless Recon DL) running on the scanner host, and (b) the **Edison** application layer hosting 72 FDA-cleared AI devices for radiologist workflow [4][5]. So GEHC consumes compute (memory chips were a $100M Q1 cost headwind) [3][13] but does not build silicon, racks, or training systems. Read this as a medical-capital-equipment franchise with an AI feature layer, not an "AI stock."

## Snapshot
- **Price:** $63.00 (2026-05-10 close) [1]
- **Market cap:** ~$28.7B (454.89M sh out × $63) [12]
- **52-week range:** $58.75 – $89.77 [12]
- **Forward P/E:** ~12.9× FY26 adj EPS midpoint $4.90 (post-cut guide $4.80–$5.00) [2][13]
- **EV / NTM revenue:** ~1.5× (EV ~$32B vs ~$21B FY26 rev) — inference from net debt ~$3B + market cap, FY26 rev ~$21B [2][3]
- **Consensus 12-month price target:** $89.74 (+42%) [13]
- **YTD total return:** n/a — could not source clean YTD figure; stock traded in $58–$90 band over the 52-wk window with the April 30 −13% guidance-cut gap accounting for most of the YTD weakness [13]
- **Short interest (% of float):** n/a — Nasdaq page existed but figure not retrieved in time

## Moat — what it is physically made of
The "moat" is six things stacked, of very different durability. Decomposed:

**1. Installed base + service contracts (most durable).** Top-3 global imaging OEM with ~31.7% global share and ~40.2% US share in 2024 (industry-report figures, treat as directional) [11]. The Q1 2026 backlog is **$21.8B with 1.07× book-to-bill** [3][13]. Service revenue runs through long-tail contracts on installed scanners that physically cannot be displaced without rip-and-replace capex of $1–3M per room. This is the most boring and most durable component.

**2. MRI superconducting magnet engineering — Freelium.** The new SIGNA Sprint with Freelium is a **sealed 1.5T magnet using <1% of the helium load of a conventional system** (~2,000 L liquid He → near-zero), with >5h ride-through during outages and ventless siting [7]. With Q1 2025 US helium at ~$97k/MT (>4× pre-2020) and structural shortage [16], helium-light magnets are a real economic moat against competitors still bound to legacy NbTi+helium architectures. Note that **Siemens, Philips, and United Imaging all have helium-light or sealed-magnet products** — GEHC is competitive here, not differentiated. The NbTi superconducting wire itself is sourced from a concentrated supplier set (Bruker EST, Luvata, Western Superconducting Technologies) [16] — GEHC does not own this layer.

**3. Iodinated contrast manufacturing.** Visipaque (iodixanol) and Omnipaque (iohexol) — **80% Shanghai, 20% Cork, with bulk iohexol API from Lindesnes, Norway** [8]. A new Cork line is adding ~25M doses/yr by end-2027 [8]. The 2022 Shanghai-COVID outage that triggered a US contrast crisis demonstrated **how concentrated this supply chain is**: there are perhaps three meaningful global iodinated-contrast manufacturers (GEHC, Bracco, Bayer/Guerbet). Switching costs at the hospital are non-trivial because contrast injectors, dosing protocols, and electronic order sets are wired to specific agents. Durable, but Shanghai concentration is also the single largest geopolitical liability on the balance sheet.

**4. Deep-learning image reconstruction software — AIR Recon DL / Sonic DL.** Pioneered the DL-recon category in 2020; **34M+ patients scanned cumulatively, deployed back to MRI scanners >20 years old via field upgrade** [5][6]. The moat here is *not* the algorithm (Siemens has Deep Resolve, Philips has SmartSpeed, Canon has AiCE — all deployed) — it is the **install-base monetization channel**: GEHC can bill upgrades against their own ~30%+ global imaging fleet without a competitor's permission. Algorithmic parity is a 2-year matter; install-base moat is a 10-year matter.

**5. Edison + MIM Software + Icometrix AI portfolio.** 72 FDA-cleared AI devices on Edison [4]. MIM bought for $295M cash, April 2024 — gives radiation oncology / nuclear medicine workflow software (LesionID Pro for PSMA tumor burden; Centiloid for amyloid PET) [4]. Icometrix added Alzheimer's neuro-AI [4]. **Honest read: this is a portfolio play on an open-architecture market.** Edison is not a CUDA. It's a curation layer; the underlying inference is replaceable, and Siemens (syngo Carbon AI) and Philips have direct equivalents. Not a real lock-in moat.

**6. Radiopharmaceutical pipeline — Flyrcado (flurpiridaz F-18).** FDA-approved Sept 2024, US launch March 2025 at ACC [10]. **First new FDA-approved cardiac-PET tracer in ~30 years**, 109-min half-life vs ~76s for Rb-82 (the incumbent), unit-dose economics that don't require a hospital to own a $40k/month rubidium generator [10]. This is the most genuinely differentiated new product in the portfolio. Plus Pylarify (Lantheus) Japan rights via the Sept 2025 license + Nihon Medi-Physics buyout [15]. Radiopharma is durable IP-protected drug-economics, very different from the equipment moat.

**Net moat call:** GEHC has a real, physical, capital-intensive franchise (#1, #3, #6) wrapped in software claims (#4, #5) that are weaker than the company's marketing implies. Photon-counting CT (below) is the structural hole.

## AI buildout bottleneck map
Constraints on the AI buildout 2026–2028 and where GEHC sits on each:

| Bottleneck | Status 2026 | GEHC position |
|---|---|---|
| Power generation / grid interconnect | Severe — 4–7 yr turbine backlog, queues at PJM/ERCOT | **Indifferent** — scanners draw 100–200 kW each, not data-center scale |
| CoWoS-L advanced packaging | Tight; TSMC adding capacity through 2026 | **Indifferent** |
| HBM / DRAM tightness | **Acute and biting GEHC.** ~$100M Q1 cost increase explicitly attributed to memory-chip pricing [3][13] | **Exposed customer** — pays AI-driven memory inflation for scanner consoles, recon clusters, image archives |
| Liquid cooling >100 kW/rack | Tight | **Indifferent** |
| Helium supply | Structural shortage; Ras Laffan disruption pricing in [16] | **Beneficiary via Freelium** — every helium-free magnet is a competitive product against legacy fleets, including GEHC's own |
| NbTi superconducting wire | Concentrated 3-supplier market (Bruker, Luvata, WST) | **Exposed customer**, not owner |
| Iodine / contrast API | Concentrated; Norway bulk iohexol single-point | **Owner of position** — but with single-point Shanghai/Cork/Norway risk |
| Tariffs / US-China decoupling | Worsening; trade actions mid-cycle | **Highly exposed** — 12–13% revenue from China manufacturing, 70% of that sold inside China; tariffs ~$0.16 Q1 EPS hit [13][14] |

The honest summary: GEHC is **mostly indifferent** to the headline AI compute bottleneck story but **acutely exposed on memory-chip inflation as a downstream customer**. It is the rare name where rising HBM prices are a P&L negative, not a positive.

## Competitive teardown

**Siemens Healthineers — the structural CT hole.**
Naeotom Alpha was FDA-cleared in **2021**; Photonova Spectra in **March 2026** [9]. That is a **5-year head start** in photon-counting CT (PCCT) — the first new CT physics generation in 25 years. Siemens has **booked ~€1B in PCCT orders / ~€700M in PCCT revenue** [9] and has expanded to a 3-product line (Alpha.Peak, Alpha.Pro dual-source, Alpha.Prime single-source) [9]. GEHC's CEO explicitly framed **2027 as the ramp year for Photonova** [9]. Technical differentiator: GEHC's Deep Silicon detector with 8 energy bins is a credible architecture and may surpass Siemens on spectral imaging once clinical validation accumulates [9] — but **base rate on imaging-modality leadership shifts is unforgiving**: when GE lost CT leadership to Toshiba/Siemens with multi-detector CT in the early 2000s it took ~7 years to rebuild share. Dual-source is also a separate physics advantage Siemens has held for 20 years that GEHC has never replicated. *This is the single most important competitive fact about GEHC.*

**Philips, Canon Medical, Fujifilm.**
Top-5 share in US is 96% (GE+Siemens+Philips+Canon+Fuji) [11]. Philips is closer in DL recon (SmartSpeed) [5] but weaker in radiopharma. Canon's AiCE is the longest-deployed DL-recon. None has PCCT in the US market yet, so the binary 2026–28 race is GEHC catch-up vs Siemens defense.

**United Imaging Healthcare (UIH) — the China + emerging-market squeeze.**
UIH had **23% China CT share in 2021 and 32.1% PET-CT share in 2020** [17]; H1 2025 reports record overseas revenue, with overseas +42% YoY in 9M 2025 [17]. UIH and Mindray are positioned in price/performance and govt-subsidy tiers; multinationals are anchored to premium tier with installed-base lock-in [17]. GEHC's response: a **CNY 500M MRI R&D hub in Tianjin opened December 2025** [17]; Siemens countered with CNY 1B in Shenzhen [17]. *The trajectory is clear: China is a permanent share-loss market for GEHC.*

**Lantheus (radiopharma).**
Now both competitor and partner: Pylarify ($1B+ in 2024 sales, first blockbuster radiodiagnostic) is licensed to GEHC for Japan distribution [15]. Direct rivalry is in PSMA PET (Posluma, Clarity Pharma) and in cardiac PET where Flyrcado attacks Lantheus's franchise.

**Bracco / Bayer / Guerbet (contrast).**
Three-firm oligopoly with GEHC. Stable structure; share moves at the margin via contracting cycles.

## Bull case — technical
The technical bull case requires **four** things to hold:

1. **Photonova Spectra closes the PCCT gap by 2028.** Deep-Silicon detectors must demonstrate spectral-imaging parity or superiority vs Siemens cadmium-telluride in independent clinical literature; orders need to ramp to $300M+ by FY27. Base rate: imaging leadership shifts take ≥5 years to monetize once the technology is shipping (CT 1998–2005 Siemens/Toshiba transition; MRI 3T transition 2003–2010). GEHC will be a credible #2 in PCCT, not the leader.
2. **Flyrcado expands the cardiac PET TAM.** PET MPI's economic constraint has been the rubidium generator; unit-dose F-18 with 109-min half-life can be regional-pharmacy-distributed [10]. If 30%+ of US SPECT MPI volume migrates to PET over 5 years, that is a multi-hundred-million-dollar tracer market on an asset GEHC owns alone.
3. **Memory + freight inflation rolls off into 2027.** The $250M FY26 inflation guide is a one-year hit; $100M memory-chip exposure normalizes if HBM4 supply meets AI demand by 2H27 (this is genuinely uncertain and outside GEHC's control).
4. **Pricing actions take hold in 2H 2026 backlog.** Mgmt explicitly said pricing on **new orders** flows through with a lag [13]. The $21.8B backlog provides revenue visibility but not margin visibility — that depends on rolling-off legacy-priced backlog and re-pricing.

If all four hit: FY27 EPS in the $5.50–6.00 range, ~14× multiple → $80–85 stock, broadly the consensus PT [13]. **This is not a stretch case; it is a competence case.** That's why the multiple is only ~13×.

## Bear case — technical
The version a short-seller who reads MLPerf-equivalent imaging literature would write:

1. **PCCT leadership loss is structural, not catch-up-able.** Siemens has 5 years of clinical data, dual-source physics GEHC cannot replicate without ground-up re-architecture, and €1B in installed orders building reference customer lock-in [9]. Photonova's 2027 ramp slips to 2028. The most innovative new modality of the decade is now Siemens-shaped, and the imaging segment was already operating with **a CEO change announced into the Q1 print** [13] — usually a bad sign at the worst time.
2. **Patient Care Solutions structural impairment.** Segment EBIT collapsed **−79.8%** to $10M in Q1 2026; segment EBIT margin down 500 bp YoY [13]. This is monitoring/anesthesia hardware with thin moats, exposed to both tariffs and Chinese commoditization. Likely candidate for divestiture or further write-down.
3. **China is a permanent revenue and margin headwind.** Anti-corruption capex freeze + tariffs + UIH/Mindray product creep = 2024 saw a 15% China revenue decline [14]; the company is reportedly **exploring divesting its China operations** [14]. A clean exit might be margin-accretive but would shrink the revenue base by ~10%.
4. **Memory-chip inflation persists.** If HBM4 stays supply-constrained through 2027 because of AI training demand (the actual most likely scenario per hyperscaler capex commentary), the $100M Q1 hit is not a 2026 problem — it is the new baseline. GEHC has to absorb AI inflation without participating in AI revenue. **This is the single most under-appreciated bear point.**
5. **Software moat illusion.** Edison is not a platform with switching costs in the CUDA sense — it is a curation layer where every algorithm is also available standalone or through Aidoc / Rad AI / Annalise / hospital-built MLOps. As radiology-AI standardizes on open APIs (HL7 FHIR, DICOM-SR), Edison loses its assembly value.

If three of five hit: FY27 EPS flat at $4.80, multiple compresses to 11× on declining-franchise concerns → **$53 stock**.

## Market view check
At $63 / ~13× FY26 adj EPS [1][2], the market is pricing **a cyclical inflation/tariff trough that recovers by FY27**, with PCCT considered a partial offset (not leadership) and China priced as managed decline (not collapse). Consensus PT $89.74 [13] implies belief that this is mostly a short-term margin story. The ~13× multiple is **below** the 5-year average for capital-equipment medtech (16–18×) and **below** Siemens Healthineers' historical multiple. The market disagreement vs the bear case above: the market does not yet think Siemens has *structural* PCCT leadership, and is treating Photonova-2027 as a credible response. **My read: the market is correct that this is not a melting ice cube but is too sanguine on PCCT competitive dynamics; fair value sits around $70–75 absent a clean PCCT win.** No edge for entering at $63 unless you have a specific catalyst on PCCT order momentum or China divestiture.

## 90-day falsifiers
Specific, observable events through ~Aug 2026:

1. **Q2 2026 print (late July).** Adj EBIT margin must show sequential improvement off Q1's 13.5% — bull thesis dies if Q2 is flat or worse. Specifically watch Patient Care Solutions: −79.8% EBIT must reverse or impairment becomes the call.
2. **Photonova Spectra customer wins.** GEHC needs to disclose its first 5–10 reference site installations and order count by Q2 call. Siemens has the €1B comp [9] — if GEHC won't quantify, that is itself the answer.
3. **Memory chip outlook (Aug Micron / Hynix / Samsung guidance).** If HBM4 / DDR5 server-DRAM contract pricing for 2H26 is up sequentially, the $100M GEHC headwind extends into FY27. If flat-to-down, the inflation trough is real.
4. **China divestiture / restructuring announcement.** Reuters/Bloomberg reports [14] suggest active process; an actual announcement (sale, JV restructuring, or denial) by Q2 call would resolve a major overhang either direction.
5. **Imaging segment leadership replacement.** New imaging-segment CEO appointment [13] and the strategic posture on PCCT — accelerated investment vs status quo — is signal, not noise.
6. **Flyrcado revenue disclosure.** Pharmaceutical Diagnostics segment +21.7% reported [13]; mgmt should quantify Flyrcado run-rate by Q2 to validate the franchise build.

## What I could not verify
- Exact YTD total return — search results gave price points but not a clean YTD number.
- Short interest as % of float — Nasdaq page exists but value not retrieved.
- GEHC's specific NbTi-wire supplier and contract terms (Bruker EST? Luvata? In-house drawing?) — not disclosed publicly.
- Photonova Spectra unit price and gross-margin profile vs current Revolution CT line.
- Specific patent moat claims around Deep Silicon detector vs Siemens CdTe — patent landscape would require IP search beyond web results.
- Edison platform actual revenue contribution — never broken out.
- The precise mix of GEHC's $21.8B backlog by modality and geography.
- Whether the imaging-segment CEO departure was push or pull.
- China divestiture process status beyond press reports.
- 2025 full-year actuals to compute clean YoY comparisons (only have Q1 2026 vs Q1 2025).

## Sources
[1] https://finance.yahoo.com/quote/GEHC/ — retrieved 2026-05-10 — current price ($63.00) and trading range
[2] https://www.macrotrends.net/stocks/charts/GEHC/ge-healthcare-technologies/pe-ratio — retrieved 2026-05-10 — historical and current P/E ratios
[3] https://investor.gehealthcare.com/news-releases/news-release-details/ge-healthcare-reports-first-quarter-2026-financial-results — retrieved 2026-05-10 — Q1 2026 official results: $5.13B revenue, $0.99 adj EPS, 13.5% adj EBIT margin, $21.8B backlog
[4] https://www.mobihealthnews.com/news/ge-healthcare-bolsters-portfolio-acquisition-mim-software — retrieved 2026-05-10 — MIM Software $295M acquisition; Edison platform 72 FDA-cleared AI devices
[5] https://www.itnonline.com/content/ge-healthcare%E2%80%99s-pioneering-deep-learning-image-reconstruction-technology-benefits-more-2 — retrieved 2026-05-10 — AIR Recon DL: 34M+ patient scans, deployed across 20+ year MR install base
[6] https://www.gehealthcare.com/products/magnetic-resonance-imaging/air-recon-dl — retrieved 2026-05-10 — AIR Recon DL product detail
[7] https://www.gehealthcare.com/products/magnetic-resonance-imaging/1-5t-mri-scanners/signa-sprint-with-freelium-wide-bore-mri-scanner — retrieved 2026-05-10 — Freelium <1% helium use, sealed magnet, >5h ride-through
[8] https://www.auntminnie.com/clinical-news/ct/article/15631112/ge-contrast-plant-in-shanghai-to-approach-full-production-next-week — retrieved 2026-05-10 — Shanghai 80% / Cork 20% iodinated contrast split, Norway iohexol bulk supply
[9] https://theimagingwire.com/2026/03/25/fda-clearance-for-photonova-spectra/ — retrieved 2026-05-10 — Photonova Spectra FDA clearance March 2026; vs Naeotom Alpha 2021; Siemens €1B PCCT orders / €700M revenue; Arduini 2027 ramp commentary
[10] https://investor.gehealthcare.com/news-releases/news-release-details/ge-healthcare-announces-fda-approval-flyrcado-flurpiridaz-f-18 — retrieved 2026-05-10 — Flyrcado FDA approval Sept 2024; 109-min half-life; first new cardiac PET tracer in 30 years
[11] https://www.grandviewresearch.com/industry-analysis/medical-imaging-systems-market — retrieved 2026-05-10 — Global imaging share (~31.7% GEHC global, ~40.2% US, top-5 = 96% US share)
[12] https://www.macrotrends.net/stocks/charts/GEHC/ge-healthcare-technologies/stock-price-history — retrieved 2026-05-10 — market cap, shares outstanding, 52-week range
[13] https://247wallst.com/investing/2026/04/30/ge-healthcare-just-crashed-13-on-a-guidance-cut-heres-the-case-for-buying-the-dip/ — retrieved 2026-05-10 — Guidance cut details, segment EBIT performance, $100M memory chip cost, tariff $0.16 EPS, consensus PT $89.74, imaging CEO departure
[14] https://www.chicagobusiness.com/health-care/ge-healthcare-revenue-hurt-chinas-anti-corruption-push — retrieved 2026-05-10 — China revenue ~$2.13B 3rd-largest market, 12-13% revenue from China mfg, 70% sold in-China, divestiture exploration
[15] https://lantheusholdings.gcs-web.com/news-releases/news-release-details/lantheus-and-ge-healthcare-announce-exclusive-licensing — retrieved 2026-05-10 — Pylarify Japan license; Nihon Medi-Physics acquisition March 2025
[16] https://bpmforum.org/blog/why-is-there-a-helium-shortage-2025-supply-crisis-explained/ — retrieved 2026-05-10 — Helium pricing $97k/MT US Q1 2025; structural shortage; NbTi wire suppliers Bruker EST / Luvata / WST; ~2,000L LHe per 1.5T scanner
[17] https://global.united-imaging.com/en/news-center/uih-news-list/2025-04-28 — retrieved 2026-05-10 — UIH 2024 results, 9M 2025 overseas +42%, 23% China CT 2021, 32.1% PET-CT 2020; Tianjin/Shenzhen multinational responses