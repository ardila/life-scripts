I have enough material. Writing the dossier now.

# EQT — EQT Corporation

## Where this sits in the AI stack
EQT sits at the **fuel layer beneath the power layer beneath the rack**. It does not touch silicon, packaging, networking, software, or even the electrons themselves. It produces ~6.0–6.5 Bcf/d of dry natural gas from the southwest-Pennsylvania core of the Marcellus/Utica and, since closing Equitrans Midstream in July 2024, owns the gathering, transmission and 2.0 Bcf/d Mountain Valley Pipeline that takes the molecules out of the basin to combined-cycle and simple-cycle gas turbines — increasingly turbines that sit behind the meter at AI/HPC campuses bypassing the PJM interconnect queue [1][8][14]. The relevance to AI is mediated entirely through the gas-turbine power bottleneck: every 1 GW of 60%-CF gas-fired generation needs ~150 MMcf/d of fuel, and EQT has now contracted ≥1.5 Bcf/d of new long-dated supply explicitly to data-center campuses [4][7].

## Snapshot
- **Price:** $56.01 (2026-05-10 close) [1]
- **Market cap:** $35.0B (~624.1M shares out) [1][20]
- **52-week range:** $48.47 – $68.24 (ATH 2026-03-27) [1][19]
- **Forward P/E:** ~8–9× — *inference*: Q1'26 EPS was $2.33 [3], FY consensus appears to be in the ~$6.00–6.50 range based on analyst PT/multiple math; not directly sourced
- **EV / NTM revenue:** ~3.0× — *inference*: EV ≈ $40.7B (mkt cap $35.0B + net debt $5.7B [3]); Q1'26 revenue $3.38B annualized ≈ $13.5B [3]
- **Consensus 12-month price target:** $68.50 (36-analyst median, +22% from price) [11]
- **YTD total return:** +13% — *inference*: from late-March +27% YTD print [19] and roughly -11% pullback from the $68.24 March ATH to the $56.01 close
- **Short interest (% of float):** ~3.9% (24.4M shares as of latest report; 4.2% in Feb'26) [20]
- **Net debt / FCF:** $5.7B / $1.83B Q1'26 FCF (record); ~$7B+ FCF run-rate at strip [3][14]

## Moat — what it is physically made of
EQT's moat decomposes into four physically distinct layers, of which only two are real in the technical sense.

**1. Tier-1 Marcellus rock (durable, ~10+ years).** Marcellus core acreage in southwest PA is the lowest-cost dry-gas resource on the continent. EQT's pro-forma post-Olympus inventory is the largest remaining stack of Tier-1 dry-Marcellus locations in private hands — Olympus added 165 gross Marcellus + 60 Utica locations on 90,000 acres directly offsetting EQT's core, at ~500 MMcf/d net [9]. Per-unit operating cost was $1.09/Mcfe in Q1'26 — 2% below low-end guidance — and corporate unlevered NYMEX FCF break-even is ~$2.00/MMBtu [3][13]. This is geological, not commercial: a competitor cannot manufacture Tier-1 thickness, pressure, and TOC the way you can manufacture a CUDA replacement.

**2. Integrated midstream egress (durable, partially captured by Blackstone).** The Equitrans deal made EQT the only US large-scale vertically integrated gas producer — they own the gathering system that aggregates their own molecules and the 2.0-Bcf/d MVP that gets them out of the basin to Transco Station 165 in Virginia [8][14]. They then sold a non-controlling 47% economic interest in MVP + FERC transmission + Hammerhead to Blackstone for $3.5B at 12× EBITDA — keeping operational control and rights to growth projects (MVP Boost to 2.5 Bcf/d, MVP Southgate 500 MMcf/d) [12]. The strategic significance is that EQT now has a captive pipe into the data-center load growth corridor (Virginia/Carolinas), where Transco's 1.6-Bcf/d Southeast Supply Enhancement comes online Nov 2027 [22]. Appalachian outbound takeaway is forecast to reach ~39 Bcf/d by 2027 vs. ~35 Bcf/d today [22] — EQT controls the most economically advantaged share of that incremental 4 Bcf/d.

**3. Direct end-user contracts (semi-durable, contract-by-contract).** EQT now sells >4.6 Bcf/d directly to end users [13], bypassing hub spot markers. The marquee contracts: Homer City Energy Campus (665,000 MMBtu/d / ~665 MMcf/d to a 4.4 GW gas plant powering a 3,200-acre AI/HPC campus, COD 2027) [4][7]; Frontier/Shippingport (~800 MMcf/d to a 2.7 GW conversion of the retired Bruce Mansfield coal plant) [4]; Duke + Southern (1.2 Bcf/d on MVP) [13]. These are physical molecule supply agreements behind 20+ year asset lives — switching cost is a new pipeline.

**4. ESG/regulatory cover (soft moat, real for procurement).** The Appalachian basin has the lowest methane emissions intensity of any major US producing basin per AMI's satellite-verified data [16]; EQT's production-segment Scope 1 methane intensity is 0.0070% (35× below their 0.02% target) [16]. They've certified Scope 1+2 net-zero. For hyperscalers with public Scope 3 commitments, a low-methane Marcellus molecule from an electrified-frac producer is *materially different* than a Permian molecule with associated gas flaring. Worth real bps of basis differential in long-term contracts.

What is *not* a moat: brand, hedging desk skill, M&A track record. The 2024 Equitrans deal was Toby Rice undoing the 2018 spin his predecessor did — i.e., recognizing that vertical integration was the answer, not creating new technology.

**Replication cost honest assessment:** A competitor cannot replicate (1) — that's geology. They could in principle replicate (2) by acquiring midstream, but MVP cost $7.7B and 10 years of litigation to build [10] and the only other large basin-out pipe (ACP) was cancelled. (3) is a 5-year sales motion. A new entrant trying to recreate EQT today would need $40B+ and a decade.

## AI buildout bottleneck map
The AI buildout's gating constraints over the next 24 months, with EQT positioning:

| Bottleneck | Status | EQT position |
|---|---|---|
| **Gas turbines (heavy-frame)** | GE Vernova backlog 44 GW + 12 GW slot reservations as of Q1'26, sold through 2029–2030; Mitsubishi 30 GW + 20 GW reservations, 2026/27 sold out; Siemens scaling 48→80 units/yr [6][17] | **Constraint owner** by proxy — every committed turbine slot is a future customer EQT can underwrite. Homer City already has its 7× 7HA.02s allocated [4]. |
| **PJM grid interconnect** | Capacity short of reliability requirement by 6,623 MW for 2027/28 delivery year; data centers = 40% of $16.4B Dec'25 auction cost; 5,100 MW of 5,250 MW peak-load increase from DCs [5] | **Beneficiary** — the more clogged PJM is, the more behind-the-meter gas wins, the more EQT molecules sell. |
| **Appalachian gas takeaway** | MVP at 2.0 Bcf/d → 2.5 Bcf/d via MVP Boost (winter '26-'27 construction, mid-'28 ISD); Transco SSE 1.6 Bcf/d Nov '27; Power Express 950 MMcf/d proposed [10][22] | **Owner** of MVP economics; primary beneficiary of SSE pulling Marcellus south. |
| **Henry Hub price** | EIA: $3.50/MMBtu 2026, $4.60/MMBtu 2027; LNG exports +9%/+11% (Plaquemines, CC3, Golden Pass) [15] | **Levered beneficiary** with ~25–40% 2026 hedged at $3.94–$4.30 floors [13]; mostly open to price upside. |
| **Power-electrical contractor capacity** | Kiewit doing the Homer City build [4] — small pool of EPCs that can do 4 GW gas plants | **Indifferent** — not their problem, but does delay COD on their volume contracts. |
| **HBM, CoWoS-L, optical interconnect** | Real bottlenecks for GPU supply | **Indifferent** — gas demand follows GPU deployment with multi-quarter lag, but doesn't compete for the same suppliers. |
| **Permian associated gas** | Waha negative for record 25 consecutive days through March '26; +4.5 Bcf/d new takeaway late '26 [18] | **Competitive threat** — see bear case. |
| **SMRs / nuclear restart** | First commercial SMR units early-to-mid 2030s [21]; gas-plus-nuclear pairings emerging | **Indifferent near-term, exposed long-term** — the bridge fuel narrative collapses if nuclear delivers on time. Base rate: nuclear delivery on time is rare. |

The honest read: gas molecules are NOT the bottleneck. **Turbines are**. Marcellus can deliver another 4–5 Bcf/d once pipes open. EQT's edge is owning the cheapest molecule with the only built pipe to the southeast — so when turbines do show up at the rack, EQT is structurally favored to fill them.

## Competitive teardown
- **Expand Energy (EXE, Chesapeake + Southwestern merger Oct 2024).** Largest US gas producer by volume at ~7.44 Bcfe/d, diversified Marcellus + Haynesville [11]. **Axis where they win:** Haynesville proximity to Gulf LNG corridor — shorter molecule path to Plaquemines/Golden Pass. **Axis where EQT wins:** Marcellus dry-gas break-even is structurally lower than Haynesville (deeper, hotter rock = higher D&C cost in HV); EQT owns the only vertically integrated midstream stack; EQT has the in-basin AI campus relationships PJM-side. Expand cannot easily build a behind-the-meter Marcellus presence — they don't own the rock.
- **Antero Resources (AR).** ~3.4 Bcfe/d, liquids-rich Marcellus/Utica. **Axis where they win:** NGL exposure (propane/ethane to petchem/export) provides margin diversity vs. dry gas [11]. **Axis where EQT wins:** Antero T&G unit cost was ~$1.23/Mcfe vs EQT's gathering cost of ~$0.35/Mcfe post-Equitrans [8] — Antero is a price-taker on midstream; EQT is the midstream.
- **Permian gas producers (PXD/Diamondback, Coterra, etc.).** Permian gas is associated with oil — economic byproduct, not the target. **Axis where they could win:** When the +4.5 Bcf/d of new Permian takeaway lights up late 2026 [18], a structural source of cheap gas hits Gulf/Southeast markets, compressing the basis premium EQT enjoys at MVP outlets. **Axis where EQT wins:** Permian gas is high-CO2, often flared, and tied to oil-price drilling decisions. Hyperscalers signing 20-year Scope-3-aware contracts increasingly differentiate molecule provenance — and EQT's certified-low-methane Marcellus molecule has procurement value.
- **The non-competitor: SMR developers (NuScale, X-energy, Oklo, GE Vernova BWRX-300).** Earliest credible commercial dates are 2030+ [21]. Base rate on first-of-a-kind nuclear: schedule slips 2–4 years and cost overruns 50–200% (Vogtle, Olkiluoto, Flamanville). EQT has a 5–7 year clear runway as the bridge.

## Bull case — technical
The thesis is that **AI inference scaling** — not just training — pulls structural gas demand up by 4–8 Bcf/d through 2030 [15], that **gas turbines remain the only physically deliverable behind-the-meter solution at multi-GW scale** through 2029, and that EQT's **Marcellus-to-MVP-to-Southeast** corridor is the lowest-marginal-cost incremental supply for that demand. With Q1'26 already printing $1.83B of FCF on a partially hedged book at sub-$4 strip, the unhedged 2027 FCF at EIA's $4.60/MMBtu forecast plausibly approaches $7–9B against today's $35B equity — call it a 20–25% FCF yield with a structurally tightening market behind it. Mechanism for stock outperformance: hedge roll-off + 2027 LNG demand wave + Homer City COD + further direct-to-DC contract wins → multiple re-rates from ~9× forward P/E toward mid-cycle 12–14× as the market stops treating EQT as a commodity producer and starts treating it as an AI infrastructure utility with a growing % of contracted volumes.

**Base rate caveat:** Energy commodities re-rate slowly and incompletely — even in the 2003–2008 supercycle, E&P multiples expanded ~30–50%, not 2–3×. The "I'm an AI infrastructure stock now" narrative trade has worked for some adjacent names (VST, CEG, GEV) but those have direct generation or equipment exposure; EQT is one layer back. Realistic 12-month upside: $68 PT (+22%); 24-month: $80–90 if Henry Hub holds $4+ and one more marquee DC contract lands.

## Bear case — technical
The honest short thesis is not "gas demand disappoints." It's: **the bottleneck is turbines, not molecules**, and the AI capex narrative is getting priced into a commodity producer that doesn't actually capture the AI premium.

1. **Gas turbines slip.** GE Vernova's 7HA.02 backlog stretches to 2029–2030 [6][17]. If the Homer City COD pushes from 2027 to 2028 (which would be normal — large gas plants slip), EQT's contracted volumes defer too. The turbine OEMs capture the AI scarcity rent; EQT is paid the molecule price.
2. **Permian gas flooding the Southeast.** With +4.5 Bcf/d of Permian takeaway commissioning late 2026 [18], the basis premium at Transco Station 165 — EQT's sale point — narrows. Permian associated gas is effectively negative-cost (oil pays for it) and fully crowds out the marginal Marcellus molecule into Gulf and Southeast.
3. **Hyperscaler capex digestion.** Hyperscaler 2026 capex consensus is ~$830B [chase searches]; if Q3'26 guides flat-to-down, the rate of new gas plant FIDs slows. EQT's stock will trade with that capex print despite multi-year contract durations on the underlying physical asset.
4. **Behind-the-meter regulatory backlash.** PJM/FERC are actively studying whether co-located large loads should pay grid cost-share. If the BTM model gets re-tariffed (Amazon/Talen at Susquehanna precedent under FERC review), the economics that drove Homer City and Shippingport invert. EQT is exposed to the deal pipeline drying up even if existing contracts hold.
5. **Nuclear restart speed.** Three Mile Island Unit 1 / Crane Clean Energy Center for Microsoft is scheduled 2028 — a 835 MW carbon-free baseload unit at one site. If 4–6 such restarts happen 2028–2031 ahead of schedule, the first ~5 GW of "carbon-free always-on" demand goes to nuclear, not gas. Base rate is against this, but Constellation has executed.
6. **Frac/cycle risk.** Q1'26 was helped by Winter Storm Fern [3]. A normal weather year and you'd see ~$5–6B FCF, not $7B+. Stock screens cheaper than it actually is on weather-noisy quarters.

The fair short would be: long EQT-supplied turbine OEMs (GEV) and short EQT — the OEMs capture the actual scarcity rent, EQT captures gas price.

## Market view check
At $56.01 / ~$35B mkt cap / ~$40.7B EV, EQT trades at ~9× forward P/E and a ~20% FCF yield on Q1'26 annualized — *cheaper* than mid-cycle E&P multiples of 12–14× and *much cheaper* than the AI-adjacent power names (VST 22×, CEG 28×, GEV 50×). The street's $68.50 PT implies the market isn't yet capitalizing the contracted-volume mix shift — analysts are modeling EQT as a commodity producer with a hedging book, not as a midstream-integrated long-duration energy contractor with strip-independent revenue lines. If you believe the AI gas demand thesis at all, EQT is mispriced *low* — not because the price is wrong about commodity exposure, but because the market hasn't figured out how to value the contracted strip. The disagreement: market thinks EQT = beta to Henry Hub strip; technical reality is EQT is becoming beta to GW of new gas-fired data center power, which is a much steeper curve.

## 90-day falsifiers
1. **Q2'26 earnings (late July).** Watch for: another direct-to-DC supply agreement (>500 MMcf/d), 2026 hedge book remaining <40% (preserves price upside), unit cost stable at $1.10/Mcfe.
2. **GE Vernova Q2'26 earnings.** If turbine backlog conversions to firm orders accelerate or 7HA.02 delivery dates slip materially, that's a direct read on EQT's contracted ramp timing.
3. **PJM 2028/29 capacity auction (results ~July).** If clearing price drops materially below the $329.17/MW-day record set in the Dec'25 auction, behind-the-meter gas urgency declines; if it goes higher, EQT's customer pipeline accelerates.
4. **Henry Hub winter '26-'27 strip.** Currently ~$4.50/MMBtu Jan'27. Move to $5+ confirms EIA's 2027 thesis; move to $3.50 says LNG ramp is slower than thought.
5. **EPA methane rule final action.** April'26 loosened rules; expected final rule by Q3'26 either reaffirms the 2034 WEC moratorium or introduces a state-by-state mechanism. Any tightening hurts higher-emitting Permian competitors more than EQT.
6. **Permian takeaway in-service slips.** The +4.5 Bcf/d late '26 capacity coming on schedule compresses EQT's basis. Slips help.
7. **Major hyperscaler signs a non-EQT Marcellus producer.** Expand Energy or Antero landing a >500 MMcf/d data center contract would falsify the moat-from-relationships thesis.

## What I could not verify
- **EQT's specific 2026 consensus EPS.** Multiple sources gave forward-looking commentary but no clean Street EPS number; I inferred ~$6.00–6.50 from Q1 print and analyst PT/multiple math.
- **Pricing terms / take-or-pay structure of the Homer City and Frontier contracts.** Disclosed as "agreement in principle" and supply MOU; structural protection (fixed price floor? cost-of-service? volumetric take-or-pay?) not public.
- **Net economic interest EQT retained in MVP post-Blackstone.** Implied 47% economic give-up on the $8.8B JV at $3.5B but governance/distribution waterfall details not public.
- **Direct hyperscaler counterparty identity at Homer City.** Speculated to be a major hyperscaler but Kiewit/HCR have not named.
- **Whether EQT has signed any contracts with co-located generation behind a hyperscaler campus.** The deals to date are at the gas-plant level (Homer City, Shippingport), not at the rack level.
- **2026 short interest is from Feb data and may have changed materially in the Mar pullback from $68.24.** ORTEX/Fintel paywalled.

## Sources
[1] https://finance.yahoo.com/quote/EQT/ — retrieved 2026-05-10 — current EQT close $56.01, ~$35B mkt cap on 2026-05-10
[2] https://naturalgasintel.com/news/eqt-snags-two-natural-gas-supply-contracts-including-for-massive-44-gw-ai-campus-in-pennsylvania/ — retrieved 2026-05-10 — Homer City + Frontier contracts and volumes
[3] https://www.prnewswire.com/news-releases/eqt-reports-first-quarter-2026-results-302749286.html — retrieved 2026-05-10 — Q1'26 results: $1.83B FCF, 618 Bcfe, EPS $2.33, $1.09/Mcfe unit cost, net debt $5.7B
[4] https://www.businesswire.com/news/home/20250715006970/en/Homer-City-Redevelopment-Announces-Agreement-in-Principle-for-EQT-Corporation-to-Supply-Nations-Largest-Natural-Gas-Powered-Data-Center-Campus — retrieved 2026-05-10 — 4.4 GW Homer City, 665,000 MMBtu/d, 7× GE Vernova 7HA.02 turbines, 2027 COD
[5] https://www.utilitydive.com/news/data-centers-pjm-capacity-auction/808951/ — retrieved 2026-05-10 — PJM data center load = 40% of $16.4B Dec'25 auction; 5,100/5,250 MW peak-load increase from DCs
[6] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — GE Vernova 80 GW backlog stretching to 2029, gas equipment sold-out through 2027
[7] https://www.turbomachinerymag.com/view/ge-vernova-s-h-class-turbines-power-new-pennsylvania-data-center — retrieved 2026-05-10 — GE Vernova 7HA.02 turbine specs and Homer City order
[8] https://www.prnewswire.com/news-releases/eqt-announces-transformative-acquisition-of-equitrans-midstream-302085052.html — retrieved 2026-05-10 — Equitrans acquisition $35B EV, $250M base / $425M upside synergies, $2.00/MMBtu break-even
[9] https://www.hartenergy.com/exclusives/eqt-buys-private-marcellus-ep-olympus-energy-18b-212694/ — retrieved 2026-05-10 — Olympus $1.8B, 90,000 acres, 500 MMcf/d, 165 Marcellus + 60 Utica locations
[10] https://www.eia.gov/todayinenergy/detail.php?id=62323 — retrieved 2026-05-10 — MVP 2.0 Bcf/d ISD June 2024, route specifics
[11] https://www.investing.com/news/transcripts/earnings-call-transcript-eqt-corporation-q1-2026-delivers-strong-results-stock-rises-93CH-4629992 — retrieved 2026-05-10 — Q1'26 earnings call detail; Expand Energy comparison
[12] https://www.blackstone.com/news/press/eqt-announces-3-5-billion-midstream-joint-venture-with-blackstone-credit-insurance/ — retrieved 2026-05-10 — Blackstone $3.5B / $8.8B JV / 12× EBITDA on MVP + transmission + Hammerhead
[13] https://aegis-hedging.com/insights/dominion-south-basis-forces-affecting-price-aegis-reference — retrieved 2026-05-10 — EQT 4.6 Bcf/d direct-to-end-user, 25–40% 2026 hedged, Duke/Southern 1.2 Bcf/d
[14] https://www.datacenterknowledge.com/energy-power-supply/blackstone-eqt-form-3-5b-gas-pipeline-venture-amid-ai-boom — retrieved 2026-05-10 — strategic context for Blackstone JV; debt reduction from $13.7B to $9B
[15] https://www.eia.gov/todayinenergy/detail.php?id=67004 — retrieved 2026-05-10 — Henry Hub forecast $3.50/MMBtu 2026, $4.60 2027; LNG +9%/+11%; Plaquemines, CC3, Golden Pass
[16] https://esg.eqt.com/environmental/operational-ghg-emissions/ — retrieved 2026-05-10 — Scope 1 methane intensity 0.0070%, AMI Appalachian-lowest finding, electrified frac fleet
[17] https://howtheymake.money/en/blog/gev-q1-2026-ai-electrification-trade — retrieved 2026-05-10 — GE Vernova Q1'26: 44 GW backlog + 12 GW slot reservations
[18] https://www.naturalgasintel.com/news/permian-oversupply-sends-waha-tumbling-as-most-spot-natural-gas-hubs-edge-higher/ — retrieved 2026-05-10 — Waha negative pricing, +4.5 Bcf/d Permian takeaway late 2026
[19] https://intellectia.ai/news/etf/eqt-corporation-q1-2026-earnings-call-highlights — retrieved 2026-05-10 — YTD performance, 52-week high $68.24
[20] https://fintel.io/ss/us/eqt — retrieved 2026-05-10 — EQT short interest 24.4M shares / 3.91% of outstanding; 624.07M shares out
[21] https://energy-solutions.co/articles/sub/small-modular-reactors-smr-nuclear-future — retrieved 2026-05-10 — SMR commercial timeline early-to-mid 2030s
[22] https://naturalgasintel.com/news/transco-gets-ferc-green-light-to-build-16-bcfd-southeast-natural-gas-supply-expansion/ — retrieved 2026-05-10 — Transco SSE 1.6 Bcf/d Nov 2027, MVP Boost, ~39 Bcf/d Appalachian takeaway by 2027