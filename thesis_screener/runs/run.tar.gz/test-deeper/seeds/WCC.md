# WCC — Wesco International, Inc.

## Where this sits in the AI stack
Wesco is **not** a manufacturer of any AI hardware. It is a B2B value-added distributor and supply-chain integrator that sits between component OEMs (Eaton, Schneider, ABB, Vertiv, CommScope, Corning, Panduit, Belden, Generac, Cummins, etc.) and the construction / operations side of the data center buildout — hyperscale, colo, multi-tenant, and enterprise [4][8][14]. Specifically, Wesco supplies and stages the bill-of-materials for both the "white space" (CSS segment: structured cabling, fiber, high-speed copper interconnects, racks/cabinets, security/access, in-row networking) and the "gray space" (EES segment: power distribution units, busway, switchgear ancillaries, conduit, wire, MRO, controls), plus utility/grid-interconnect material via the UBS segment [4][9][12]. The economic role is logistics, kitting, prefabrication, vendor-managed inventory, and project sequencing — not silicon, not protocol IP, not heat exchangers.

## Snapshot
- **Price:** $356.80 (2026-05-08 close; 2026-05-10 is Sunday) [13]
- **Market cap:** $17.4 B [13]
- **52-week range:** $156.28 – $368.90 [11]
- **Forward P/E:** 17.0× on FY26 consensus EPS ~$15.7 (company guide $15–17) [3][7]
- **EV / NTM revenue:** ~0.75× (EV ~$18.9 B; FY26 sales guide $24.9–25.6 B) [7][3]
- **Consensus 12-month price target:** ~$321 (range cited $271–$338 across 8 analysts; –10% vs. spot — i.e. street has been slow to mark to current price) [7]
- **YTD total return:** ~+25–30% (approximate; Q1 print drove a single-day +19% move on Apr 30, on top of run from ~$160 trough Aug 2025) — see "What I could not verify" [1][6]
- **Short interest (% of float):** ~3.0% (1.4-day cover) [10]

## Moat — what it is physically made of
Be honest: this is **not** an IP moat. There is no equivalent of CUDA, no patent thicket, no proprietary fabric. The "moat" is a stack of mundane logistical advantages that compound at scale, plus one durable structural advantage that AI-era buildouts have *strengthened* materially:

1. **Working-capital scale and inventory breadth.** Wesco runs ~$24 B of revenue through ~$3.5 B of inventory across hundreds of branches and DCs; matching the SKU breadth (lighting, fiber, racks, busway, wire, MRO, security, etc.) requires both float and supplier authorization. Sonepar and Graybar have it; few others do at North-American scale [5][14]. Replication cost: years of inventory build plus ~$5 B in working capital.

2. **Multi-vendor authorization and supplier credit lines.** A hyperscaler GC building a 200 MW campus needs Schneider switchgear *and* Eaton breakers *and* Corning fiber *and* Belden copper *and* Panduit racks *and* Caterpillar gensets — usually under a single PO with kit-level traceability. Single-OEM channels can't serve this. Wesco's authorized lines across all of the above is a 10+ year customer-and-vendor accumulation. Closest analogues are Sonepar (€33.6 B '25, €1.5 B+ data center) and Graybar (~$12.5 B '24, ~25% data center/renewables) [5][14].

3. **Anixter's data-comm/structured-cabling franchise.** The 2020 $4.5 B acquisition is the *single most important asset* for the AI thesis, even though it pre-dates the AI buildout. Anixter brought the deep relationships in fiber/copper/cabinet ecosystems that became "white space" in NVL-class deployments. Wesco's 80/20 white-space/gray-space data-center mix is structurally a CSS-led story — and CSS Q1 26 grew organic +22%, EBITDA +41%, backlog +40% [1][12]. Independent Wesco never could have built that channel in time; Sonepar and Graybar did not pay for it.

4. **Kitting, pre-fab, and just-in-time staging.** Hyperscale construction now operates on schedules where electrical install lead-time is the binding constraint (see next section). Distributors who can stage rack-elevation-specific kits, deliver to bay-and-floor, and run vendor-managed inventory inside the construction trailer save the GC labor hours that cost $200/hr+ in IBEW data-center markets [16]. This is where the "hyperscaler goes direct" thesis breaks down: hyperscalers can buy a transformer direct from Eaton, but they cannot buy 14,000 SKUs from 200 vendors kitted for a specific Microsoft DC pod from anyone but a distributor.

5. **Ascent acquisition (Dec 2024, $185 M, ~$115 M TTM rev, 30% sales CAGR).** Bought specifically for liquid-cooling design/install/operations capability — a genuine technical capability gap that distributors normally don't have. Critical for GB300 NVL72-class racks (mandatory liquid cooling, ~120 kW/rack) [7][15]. Small in revenue but strategically signals the company's land-and-expand into operations-phase recurring revenue, not just construction-phase sell-through [7].

**Honest caveats on durability:** Items 1, 2, and 4 are slow-erosion advantages that have lasted decades in industrial distribution (Graybar 1869, Wesco 1922 spinoff from Westinghouse, Sonepar 1969). Item 3 is a one-time asset purchase that has paid for itself many times over but doesn't compound further. Item 5 is a $115 M revenue base in a $24 B company — a real toehold, not yet a moat. None of this prevents Sonepar from competing aggressively on the same hyperscale logos, and there's no evidence Wesco has differentiated *technical* capability that Sonepar lacks.

## AI buildout bottleneck map
Where AI buildout is binding over the next 18–24 months, and Wesco's exposure to each:

| Bottleneck | Severity | Wesco's position |
|---|---|---|
| Power generation & grid interconnect | Severe — 5–10 yr queues at major IOUs; meaningful multi-GW projects shifting to behind-the-meter gas/nuclear [21][24] | Indirect beneficiary via UBS (grid-services >$300 M, +mid-single-digit, expected double-digit '26) [12]. Not the long pole. |
| HV power transformers | Severe — 128-week (~2.5 yr) lead times, 5-yr for specialty units [16] | **Beneficiary** — distributor stocking and pre-positioning becomes valuable when lead times are this long. But Wesco itself flagged transformer/wire weakness in UBS gross margin Q1 26. |
| Switchgear & breakers | Tight — ~44-week lead times [16] | Direct beneficiary; flows through EES gray space (Q1 +100% data center). |
| CoWoS-L packaging | Single tightest node in the silicon stack — 50+ wk lead times, NVDA holds ~60% allocation FY26 [17] | **Indifferent.** Wesco is downstream of the silicon. CoWoS shortage gates *how much* AI compute lands; Wesco only sees the equipped data center. |
| HBM3e | Fully allocated 2026, prices +15–22% YoY [17] | Indifferent — same logic. |
| Liquid cooling at >100 kW/rack | Mandatory for GB200/GB300 NVL72 (~120 kW), now industry default [15][18] | **Beneficiary** via Ascent (design/ops) and CSS distribution of CDUs, manifolds, in-rack plumbing. Margin-accretive. |
| Optical interconnect (LPO, 1.6 T) | Tight — Coherent/Fabrinet/Lumentum capacity-constrained | Distributes the cabling but not the active optics; modest exposure. |
| **Electrical contractor labor** | **Microsoft's Brad Smith called it the #1 problem; data-center journeyman wages $240–280K; 300K electrician deficit; electrical work = 45–70% of DC construction cost** [16] | **Largest underappreciated beneficiary.** Every dollar that distributors take out of contractor labor (via kitting, pre-fab, VMI) is worth multiples in customer value during a labor crunch. |
| Kernel/compiler & advanced silicon talent | Severe but unrelated | Indifferent. |

The thesis-relevant insight: Wesco's value capture is **inversely correlated** with how easy data centers are to build. The harder the construction, the longer the lead times, the tighter the electrician labor — the more the customer pays a distributor to de-risk the schedule.

## Competitive teardown
Three distinct competitive sets:

**1. Other broad-line electrical distributors (the direct peers)**
- **Sonepar (private, FR)** — €33.6 B '25, €1.5 B+ in data center — closest peer at scale, more international, has been most aggressive on M&A in NA [5]. Real competitive threat on hyperscale logos, but a private balance sheet means less standalone capital to chase the moment. Parity on logistics; slightly weaker than Wesco-Anixter on white space.
- **Graybar (private)** — $12.5 B FY24, ~25% data center/renewables — strong CommScope/datacomm pedigree, employee-owned (slower decision-making is a real disadvantage in hyperscale RFPs but a real advantage in retention). Effective competitor in the CSS-equivalent white space [5][14].
- **Rexel (RXL.PA)** — more European-weighted, weaker NA data-center presence.

On the white-space/gray-space split, **none of these three has a meaningful technical advantage over Wesco**. Share gain comes from execution, sales coverage, and inventory positioning. Wesco's 70% data-center growth in Q1 26 vs. Sonepar's reported €1.5 B '25 (~+30% est.) suggests Wesco is taking share, not just riding the market — but quarter-to-quarter comparisons across reporting cadences are unreliable [1][14].

**2. OEM direct-to-hyperscaler ("disintermediation")**
- **Eaton (ETN)** — Q1 26: revenue $7.45 B (+17%), data-center orders +240%, backlog $22.8 B [Eaton]. Eaton is Wesco's *largest single supplier* by some estimates, and also the single biggest disintermediation risk: Eaton can ship transformers, switchgear, and Tripp Lite UPS direct to Microsoft, bypassing the channel.
- **Schneider, ABB, Vertiv** — same dynamic. Vertiv backlog >$15 B, $13.5–14 B revenue guide '26 [Vertiv]; pushing pre-fab modular pods that bundle the OEM's own gray-space content.
- **Honest assessment of disintermediation risk:** OEMs *will* take direct share on the largest, most standardized line items (transformers, switchgear lineups, UPS modules) — they already are. But the BOM for a 200 MW campus contains thousands of SKUs from hundreds of vendors. Disintermediation removes the **simplest** SKUs from the channel; it leaves the kitting, MRO, ancillary, and white-space content in the channel. Net effect: distributors lose share on power lineups, gain share on labor-replacement value-add. Net-net likely modest, but it caps long-run gross-margin expansion.

**3. Data-center-specific systems integrators / construction managers** — Turner, DPR, Mortenson, Kiewit. Not really competitors — they are *customers* of Wesco. Their bargaining power is real, though, and explains why Wesco's gross margin sits ~22% (low for "AI exposure"). 

Where would a competitor have to be true to take share? Sonepar would have to (a) close the white-space gap with a meaningful M&A move (no Anixter-equivalent target left), or (b) win one of the top-3 hyperscalers as a single-source on a multi-year MSA. Neither is impossible; neither is signaled in current public data.

## Bull case — technical
For the stock to outperform from $357, the following technical conditions need to hold:

1. **Hyperscaler capex actually deploys.** $725–830 B aggregate '26 capex commitments [19] convert into actual equipment purchases. Capex *announcements* are not the same as purchase orders; the purchase orders are what drive Wesco. Watch hyperscaler property/equipment additions on cash flow statements, not capex guidance.

2. **The labor / lead-time crunch persists.** As long as transformers are 128 weeks and electricians are scarce, distributors with the ability to stage, kit, and pre-fab earn value-added margin. If lead times normalize, gross margin compresses back to ~21%.

3. **Liquid-cooled, >100 kW/rack architectures (GB300 NVL72 and successors) become the dominant deployment unit.** This is now baseline for new builds and structurally favors distributors who can supply the integrated white-space + cooling BOM. Ascent's role becomes accretive [15][18].

4. **Anixter-side white space remains the moat.** No new entrant gets to a $24 B distribution platform with Anixter-equivalent datacomm depth in <5 years. Base rate on industrial-distribution platform displacement: very slow. Graybar and Wesco-Anixter have held #1/#2 positions for >50 years; the closest case of broad-line displacement is the Amazon Business push into MRO, which has materially affected Grainger more than Wesco (different SKU set, different buyer).

5. **CSS margin continues the 9% → 10%+ trajectory.** CSS EBITDA margin Q1 26 was 9.0% (+110 bps YoY) [1]. If data-center mix accretion drives CSS toward 10–11% and pulls company EBITDA margin to 7.5%+, the multiple should re-rate from ~17× toward 20× as the market grants the durability premium that Vertiv (~30× FY26) and Eaton (~26×) already enjoy.

Financial outcome: $25.5 B '26 → $28 B '27 (low-double-digit growth) at 7.0% EBITDA = ~$2.0 B EBITDA → ~$17.50 EPS '27 → 22× target = $385. A more aggressive re-rate to 25× ($435) is plausible if data center hits 25%+ of company sales by year-end '26 (it's tracking there).

**Base rate caveat:** distribution businesses historically re-rate slowly even on real fundamentals. WW Grainger (closest comp) trades at ~25× forward; that's the realistic ceiling for a re-rating exit, not 30×.

## Bear case — technical
The version a short-seller who understands the stack would write:

1. **This is a cyclical disguised as a secular.** Wesco's 2026 EBITDA margin guide of 6.6–7.0% is roughly the same as 2022 peak [1][3]. This is not Vertiv. The *incremental* margin on new data-center business is good, but the consolidated margin is structurally low because (a) UBS is genuinely cyclical and rolling over (Q1 26 EBITDA -5%, margin -120 bps), and (b) construction-phase distribution is fundamentally a thin-margin pass-through. When the buildout cycle turns — and it will — incrementals work both ways.

2. **Disintermediation is real and accelerating.** Hyperscalers have moved from "buy through distribution" to "co-design with OEM" on the largest BOM items. Vertiv ships pre-fab modular pods. Eaton ships PowerXpert switchgear direct. Microsoft signed Constellation directly for Clinton nuclear capacity [22]. Each of these is a reach-around that bypasses Wesco's value capture on the most standardized, highest-volume parts of the BOM. The remaining channel content is structurally lower-margin.

3. **Concentration risk is now severe.** Data center is 24% of company sales in Q1 26, up from <10% three years ago [1]. This is not a diversified industrial distributor anymore; it's a leveraged AI capex play. If hyperscaler 2027 capex guidance is cut even modestly — say from $830 B '26 to $650 B '27 — Wesco's revenue growth flips to flat or down very quickly given the CSS backlog is +40% YoY and that backlog is what's at risk.

4. **The cycle has already happened in the multiple.** From the August 2025 trough of $156 to today's $357, the stock has more than doubled in 9 months [11]. Forward P/E at 17× looks reasonable in isolation but is paired with an EBITDA margin guide that has not actually expanded — the multiple has expanded because the market believes data center is durable. If 2026 ends with data center at 22% of sales but EBITDA still at 7.0%, the consensus that "this is a different company" weakens.

5. **No technical IP. Period.** Unlike Vertiv (cooling IP), Eaton (switchgear lineup IP), or Coherent (optical), Wesco has no engineering moat. Its competitive position is replicable by Sonepar with sufficient capital and time. The acquisition-driven white-space advantage is a one-time asset — it is not compounding.

6. **Leadership transition risk.** CFO Dave Schulz retiring May 2026 (replaced by Indraneel Dev), 2 directors retiring same month [25]. Engel (CEO since 2009) has not signaled departure but is the central figure in the Anixter integration narrative. Distribution is a CEO-led business; transitions matter.

**Falsifying scenario for the bear:** if hyperscaler '27 capex guides come in at $900 B+ (further acceleration) and Wesco prints CSS margin >10% in any quarter, the bear case is broken — distribution-cycle skeptics need to admit the demand curve is genuinely structural.

## Market view check
At ~$357, Wesco trades at 17× forward EPS and ~0.75× EV/NTM sales — the multiple of an industrial distributor, not the multiple of an AI infrastructure stock. By contrast, Vertiv trades ~30× forward, Eaton ~26×, and Schneider ~25× [Vertiv][Eaton]. Consensus PT of ~$321 sits *below* spot, which means the sell-side has been late marking up and is now playing catch-up — the Q1 26 print drove a 19%+ single-day move because consensus had not extrapolated the data-center trajectory [1].

The market appears to believe: "data center is real, but Wesco is structurally a low-margin distributor and deserves a distributor multiple, with some growth premium." If you agree with the bull case that data center stays >20% of sales, that CSS margin keeps grinding higher, and that hyperscale labor scarcity sustains the value-add premium — then the 17× multiple is too low and the right comp is mid-WWG (~25×). If you agree with the bear case that this is a cyclical with disintermediation tailwinds against it, then 17× is fair-to-rich and the FY27 setup gets harder. The asymmetry slightly favors the bull at this multiple, but the price is no longer *cheap* the way it was at $160 last summer.

## 90-day falsifiers
- **Hyperscaler Q2 26 capex prints (late July / early Aug):** if any of Microsoft, Meta, Google, or Amazon guides Q3 capex *down* sequentially or trims FY26 capex, distributor backlog conversion risk re-prices.
- **Wesco Q2 26 print (late July):** look for (a) CSS data-center growth at or above the +60–70% Q1 26 pace, (b) CSS EBITDA margin sustaining 9%+ and ideally cracking 9.5%, (c) total backlog vs. Q1 26's record level, (d) UBS stabilization on transformer pricing.
- **Sonepar mid-year disclosure on data-center sales.** A jump from €1.5 B '25 toward €2.5+ B run-rate would suggest share is being contested rather than ceded.
- **Ascent revenue contribution disclosed as a discrete line item.** Currently buried in CSS; explicit disclosure would signal management confidence in operations-phase recurring revenue.
- **Eaton or Vertiv announcing a major hyperscaler direct-supply MSA covering ancillary content (not just headline equipment).** That would be evidence of channel-bypass extending into the kitted SKU space.
- **Any major data-center cancellation or pause** (e.g., Stargate/Crusoe-class) — would show up in CSS backlog conversion at the next print.

## What I could not verify
- Wesco's named hyperscaler customer list — management discloses only "hyperscale, multi-tenant, colocation, enterprise" generically [1]; no contract specifics in public filings.
- Wesco's share of any individual hyperscaler's electrical BOM — likely meaningful but not disclosed.
- Exact YTD 2026 total return — I have the Q1 print +19% single day plus a ~+27% trailing-six-month figure; I could not source a clean YTD number for May 8, 2026. Estimated +25–30%.
- Whether Wesco's Ascent integration is operationally on track — only press-release-level commentary available.
- The split of EES's "data center +100%" Q1 growth between true gray-space (transformers, switchgear ancillary) versus modular power product — would change the disintermediation read.
- Specific gross-margin contribution of data center vs. company average — management says "accretive" but does not quantify [1].
- The detailed terms of the Ascent purchase price ($185 M for $115 M revenue ≈ 1.6× sales, very cheap if 30% CAGR is real and durable; would expect that growth to attract competing bidders, so either (a) Wesco moved fast or (b) margin profile is weaker than top-line implies).
- Whether the recent CFO transition reflects anything beyond planned retirement.

## Sources
[1] https://www.fool.com/earnings/call-transcripts/2026/04/30/wesco-wcc-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q1 26 transcript: $6.08 B sales (+14%), data center $1.4 B (+70%, 24% of sales), TTM DC $4.8 B, CSS organic +22% / EBITDA +41% / margin 9.0%, EES organic +7% / EBITDA +30% / DC +100%, UBS organic +6% / EBITDA -5%, backlog growth, raised CSS guide to low double-digit, 2026 EBITDA margin guide 6.6–7.0%, EPS guide $15–17, FCF $500–800 M.
[2] https://www.wesco.com/us/en/knowledge-hub/articles/powering-the-ai-revolution-how-wesco-and-abb-accelerate-data-center-deployment.html — retrieved 2026-05-10 — Wesco-ABB partnership commentary on AI data-center power architecture.
[3] https://stockanalysis.com/stocks/wcc/forecast/ — retrieved 2026-05-10 — Forward P/E 17.01×, trailing 21.0×, EV $18.87 B, FY26 EPS estimate ~$15.7.
[4] https://www.wesco.com/us/en/solutions/data-center.html — retrieved 2026-05-10 — Wesco's own framing of white-space/gray-space lifecycle services.
[5] https://www.prairiecap.com/wp-content/uploads/2024/09/Prairie-Industry-Perspective-Electrical-Distribution-September-2024.pdf — retrieved 2026-05-10 — Industry overview: WCC vs Sonepar vs Graybar vs Rexel competitive landscape and consolidation.
[6] https://finance.yahoo.com/markets/stocks/articles/why-wesco-international-wcc-19-032421229.html — retrieved 2026-05-10 — Stock +19% reaction to Q1 26 print and raised guide.
[7] https://www.tickerreport.com/banking-finance/13435793/wesco-international-inc-nysewcc-receives-321-38-average-pt-from-brokerages.html — retrieved 2026-05-10 — Average analyst PT $321.38; 8 analysts, consensus Buy.
[8] https://electricaltrends.com/2026/02/16/wesco-record-sales-but-profitability-hit-data-centers-drive-growth/ — retrieved 2026-05-10 — Q4 25 framing, white-space/gray-space split detail.
[9] https://investors.wesco.com/news-releases/news-release-details/wesco-international-finalizes-purchase-ascent-premier-provider — retrieved 2026-05-10 — Ascent acquisition completion: $185 M, $115 M TTM revenue, 30%+ CAGR, liquid-cooling capability.
[10] https://www.dailypolitical.com/2026/03/03/wesco-international-inc-nysewcc-short-interest-update.html — retrieved 2026-05-10 — Short interest 1.43 M shares, ~3% of float, 1.4-day cover.
[11] https://stockanalysis.com/stocks/wcc/statistics/ — retrieved 2026-05-10 — 52-week range, beta 1.45.
[12] https://www.investing.com/news/company-news/wesco-q1-2026-slides-data-center-sales-soar-70-stock-jumps-17-93CH-4650610 — retrieved 2026-05-10 — Q1 26 segment slides; UBS detail, grid services >$300 M '25.
[13] https://www.dailypolitical.com/2026/05/08/insider-selling-wesco-international-nysewcc-evp-sells-2770-shares-of-stock.html — retrieved 2026-05-10 — May 8 2026 closing price $356.80, market cap $17.4 B.
[14] https://www.sonepar.com/en/newsroom/7956-7956 — retrieved 2026-05-10 — Sonepar €33.6 B FY25, €1.5 B+ data-center sales.
[15] https://www.nvidia.com/en-us/data-center/gb300-nvl72/ — retrieved 2026-05-10 — GB300 NVL72: 100% liquid-cooled, 1.4 kW per GPU, ~120 kW/rack.
[16] https://www.powermag.com/transformers-in-2026-shortage-scramble-or-self-inflicted-crisis/ — retrieved 2026-05-10 — Transformer 128-wk lead times, switchgear 44 wks, multi-year backlogs; combined with electrician shortage commentary (Microsoft Brad Smith calling labor #1 problem; IBEW journeyman wages; electrical = 45–70% of DC construction cost).
[17] https://siliconanalysts.com/analysis/foundry-allocation-status-q1-2026 — retrieved 2026-05-10 — CoWoS 50+ wk lead times, NVDA ~60% of FY26 CoWoS allocation, HBM3e fully booked.
[18] https://introl.com/blog/gb200-nvl72-deployment-72-gpu-liquid-cooled — retrieved 2026-05-10 — NVL72 deployment specifics, mandatory liquid cooling, CDU requirements.
[19] https://www.tomshardware.com/tech-industry/big-tech/big-techs-ai-spending-plans-reach-725-billion — retrieved 2026-05-10 — Hyperscaler capex 2026: $725 B aggregate (Amazon $200 B, Microsoft $190 B, Google $175–185 B, Meta $145 B+), ~75% AI-related.
[20] https://evertiq.com/news/2026-05-06-ai-boom-pushes-hyperscaler-capex-towards-usd-830-billion-in-2026 — retrieved 2026-05-10 — Top-9 hyperscaler '26 capex aggregate ~$830 B.
[21] https://capacityglobal.com/news/data-centres-net-new-power-deals-utilities-hyperscalers/ — retrieved 2026-05-10 — Hyperscaler direct power procurement (utility/generator deals).
[22] https://enkiai.com/data-center/hyperscaler-energy-2026-the-race-to-build-a-private-grid — retrieved 2026-05-10 — Meta-Constellation Clinton nuclear deal; Alphabet-Intersect Power $4.75 B.
[23] https://fortune.com/2026/03/02/ai-data-centers-electrician-shortage-gen-z-training-careers/ — retrieved 2026-05-10 — Electrician shortage: 300K+ deficit, 20K retiring/yr, journeyman pay scale.
[24] https://tech-insider.org/us-ai-data-center-delays-cancellations-7gw-capacity-crisis-2026/ — retrieved 2026-05-10 — ~7 GW of US data-center capacity at risk of delay/cancellation due to electrical-equipment shortage; >50% of '26 planned DCs at risk.
[25] https://www.prnewswire.com/news-releases/wesco-international-inc-announces-upcoming-retirement-of-dave-schulz-evp-and-cfo-and-appointment-of-indraneel-dev-as-evp-and-cfo-302683193.html — retrieved 2026-05-10 — CFO Schulz retiring May 2026, Indraneel Dev incoming.