# AMAT — Applied Materials, Inc.

## Where this sits in the AI stack
Applied Materials sells the **wafer-fab equipment (WFE)** — the deposition (PVD/CVD/ALD/epi), etch, ion implant, CMP, RTP, and eBeam-metrology tools — that physically build every transistor and interconnect on every leading-edge logic die, every HBM stack, and now (via die-to-wafer hybrid bonding) the advanced 2.5D/3D packaging beneath GPUs and accelerators. They do not sell silicon, they sell the tooling that turns silicon into transistors and stacks. They sit one layer below ASML (which owns lithography) and one layer above the foundries and IDMs (TSMC, Samsung, Intel, SK hynix, Micron). Workload exposure is overwhelmingly **leading-edge logic for AI training and inference accelerators, plus HBM3e/HBM4 manufacturing**, with declining residual exposure to ICAPS / mature-node China.

## Snapshot
- **Price:** $435.44 (2026-05-08 close) [1]
- **Market cap:** ~$345B (793.6M shares × $435.44) [1][14]
- **52-week range:** ~$133 – $438 (all-time high $438.04 set 2026-05-08) [1][2]
- **Forward P/E:** ~37× on FY26 consensus EPS ~$11.50 [3][2]
- **EV / NTM revenue:** ~10× (~$32B FY26E sales, 38-analyst consensus; some valuation sites still quote ~8.3× on dated estimates) [4][3]
- **Consensus 12-month price target:** $427.50 median (–2% from price; range $275–$500, 27 of 35 rated Buy) [5]
- **YTD total return:** +~65% (one of the top S&P 500 performers in 2026; +181% over trailing 52 weeks vs. +32% S&P 500) [6]
- **Short interest:** ~1.7% of shares outstanding (~13.6M shares) [14]

## Moat — what it is physically made of
The moat is **process-integration breadth on a vacuum-sealed cluster platform plus the largest installed base in WFE**, not a single-product monopoly like ASML's EUV.

**1. Integrated Materials Solutions (IMS) on Endura / Centura / Producer / Sym3 platforms.** Endura (1990) and Centura (1992) are ultra-high-vacuum cluster tools that hand wafers between PVD, CVD, epi, anneal and selective-removal chambers without breaking vacuum [7]. Every vacuum break introduces native oxide and contamination on sub-2nm transistor surfaces; AMAT's value at the GAA/BSPDN node is that it sells the complete recipe — epi + selective removal (Selectra, >1,000 chambers in field) + ALD gate stack + selective W contact — as a co-developed integrated flow, not a parts bin [8][7]. Sym3 Y Magnum is now the patterning etch of record at leading angstrom-era nodes [9]. A new entrant must replicate not only each tool but the cluster handoff, the in-chamber sensor stack, and a decade of recipe-tuning data per customer node.

**2. Portfolio breadth no competitor matches.** AMAT is the only WFE vendor with material share across PVD, CVD, epi, implant, CMP, AND etch [10]. Etch market: ~32% AMAT / ~28% Lam (ALE/dielectric vs. conductor split) [11]. Deposition: ~30% AMAT, second is Lam [11]. This breadth is what allows IMS — Lam, ASM, KLA each own one technology vertical; AMAT owns four-to-five. **Caveat:** AMAT is *not* dominant in ALD — ASM International holds >55% in single-wafer ALD and benefits disproportionately as GAA increases the ALD layer count per wafer [12]. AMAT just spent $450M expanding its Bundang (Korea) ALD R&D center to attack this gap [12].

**3. Tool-of-record stickiness.** A tool qualified into a customer's node recipe cannot be displaced mid-node: requalification costs >$10M in test wafers and 12–24 months. This is a softer version of the ASML EUV lock-in but it operates at the per-step level across hundreds of process steps per node.

**4. Vertical integration into advanced packaging via BESI.** AMAT bought 9% of BESI in April 2025 — the largest single shareholder — and jointly launched Kinex, the industry's first integrated die-to-wafer hybrid bonder combining wet clean, plasma activation, bonding, and in-situ overlay metrology in one platform [13]. As HBM moves from 12-hi TCB toward 16-hi/20-hi hybrid-bonded stacks, this vertical cuts AMAT into a market the front-end WFE oligopoly historically did not own [13].

**5. AGS — the recurring-revenue moat.** Applied Global Services hit $6.4B in FY25, with the parts/services/software portion growing double digits [15]. Services attach to the largest installed base in WFE — every Endura ever shipped is generating spares revenue. This is the durable, low-cyclicality 22% of revenue.

**6. EPIC Center.** A $4B+ Silicon Valley co-development facility opening with TSMC, Intel, Samsung, Micron, and ASML as design-in partners — explicit purpose is to lock in tool selection one node ahead [Tikr].

**Durability ranking:** AGS recurring services (very durable, 10+ years) > IMS / cluster platforms (durable but technology-shift exposed at 2nm/A14) > tool-of-record positions (per-node, refreshed every 2–3 years) > advanced packaging (early innings, contested by Lam, ASM, BESI itself, and Chinese players).

## AI buildout bottleneck map
| Constraint | Status (next 24 months) | AMAT position |
|---|---|---|
| **Power generation / grid interconnect** | Hardest binding constraint. Uptime Institute pegs AI data-center load at 10 GW by end-2026, *constrained by grid additions, not demand* [16]. US interconnection queues stretch 5–7 yrs; OpenAI ordered 29× 34MW gas turbines for Stargate Abilene [16]. | **Indifferent / second-order exposed** — slow power = slow chip uptake = eventual fab capex moderation. Not direct. |
| **CoWoS-L advanced packaging** | TSMC scaling 70–80K wpm (end-2025) → 130–150K wpm (end-2026); NVIDIA holds >50% of 2026 allocation, ~510K wafers tagged CoWoS-L for Rubin [17][18] | **Direct beneficiary** via Kinex hybrid bonder + BESI stake; AP equipment market growing $5B → >$10B by 2030 (15%+ CAGR) per AMAT mgmt [13] |
| **HBM yield / die stacking** | HBM3e dominates 2026; HBM4 16-hi sampling now, MP H2 2026; SK hynix 57% rev share, Samsung qualification still uncertain [19] | **Direct beneficiary** — HBM revenue $1.5B FY25, target $3B "in next few years"; eBeam metrology required to qualify each die before bonding [20][19] |
| **Leading-edge logic capacity (N2 GAA, A14 BSPDN)** | All three foundries ramping GAA in 2025–26; BSPDN at Intel 18A/20A and TSMC A14 | **Direct beneficiary** — epi, selective-removal, integrated gate-stack IMS are AMAT-led; backside power requires wafer-thinning + bonding (AMAT/BESI) [21][8] |
| **Optical interconnect (CPO, LPO)** | TSMC silicon photonics ramp 2026–27; co-packaged optics on Rubin/MI400 timeframe | **Indirect exposure** via SiPh process tooling; not a primary beneficiary |
| **Liquid cooling >100 kW/rack** | Direct-to-chip universal on B200/GB300; rear-door + immersion in pilot | **Indifferent** |
| **Kernel/compiler talent, model architecture** | Not an AMAT lever | **Indifferent** |

The honest read: power is the binding constraint on the *delivered AI capacity* curve; CoWoS, HBM, and N2 logic capacity are binding on the *chip-supply* curve. AMAT participates in three of the four chip-side bottlenecks. It does not participate in solving the power side.

## Competitive teardown

**ASML — non-overlapping but decisive.** Owns lithography (EUV mono / High-NA EXE:5000 ramping at Intel/TSMC at ~$380M/system) [11]. Took the #1 WFE revenue spot from AMAT in early 2026 on High-NA volume [11]. Not a direct competitor — they are upstream of AMAT in the process flow. The risk to AMAT here is *budget share*: every dollar a fab spends on a $380M EXE:5000 is a dollar not spent on AMAT tools.

**Lam Research — direct overlap, niche-specialized.** Wins on conductor etch and 3D NAND; loses to AMAT on dielectric etch and on integrated PVD/CVD/etch flows. Lam dominates HBM-bonding TSV etch and high-aspect-ratio etch in 3D NAND, both AI-relevant. **What AMAT does better:** integration across deposition+etch on one platform. **What Lam does better:** atomic-layer etch (ALE) precision and faster product-cycle cadence on AI-critical applications [10][11]. Parity expected on most leading-edge etch nodes.

**ASM International — credible threat in the most growth-leveraged process step.** ALD is the fastest-growing deposition modality because GAA requires "strong double-digit % growth" in ALD layers per wafer, per ASM [12]. ASM holds >55% in single-wafer ALD vs. AMAT's distant second. AMAT's $450M Bundang expansion is a defensive move here; **base-rate-wise, displacing an entrenched 55%+ market leader on a specialized tool inside 3 years is rare** (closest analogue: AMAT failed to take EUV from ASML over 15 years; ASML failed to take ALD from ASM over 20). Read this as ASM continues to take share within deposition while the deposition pie grows.

**KLA — non-overlapping in inspection/metrology** but expanding into eBeam metrology where AMAT has a credible offering tied to GAA/HBM. Not a near-term threat to AMAT's core; a long-term pinch point if AMAT cannot grow eBeam.

**Tokyo Electron — direct overlap on coater/developer (track), thermal, and etch.** Strong in Japan-domiciled customer base and in 3D NAND etch. Roughly steady-state share competitor.

**Naura, AMEC, SMEE (China domestic).** China's domestic equipment self-sufficiency rose from ~25% (2024) → 35% (2025), targeting 70% by 2027 [22][23]. AMEC has 5nm etch tools in TSMC validation; Naura 28nm tools in mass production at SMIC and now leading in the China advanced-packaging ramp [22][24]. **Direct displacement risk for AMAT in ICAPS / mature node, accelerating.** Not yet a credible threat at leading-edge logic outside China, but a *structural cap* on the addressable WFE market that excludes China.

**What would have to be true for share loss:** (a) ASM holds >55% ALD share through HBM4 and N2 ramp [likely]; (b) AMEC graduates from TSMC validation to volume tool-of-record at 5nm by 2027 [non-trivial probability, would be a meaningful tell]; (c) BESI prefers a Lam partnership over the AMAT relationship [low probability given 9% AMAT stake but reportedly being approached for takeover by both [13]].

## Bull case — technical
AMAT outperforms if **all four conditions** hold:

1. **Capital intensity per wafer keeps rising at the leading edge.** GAA, BSPDN, 3D DRAM (4F²), HBM4 16-hi, and hybrid bonding each add deposition + etch + epi + selective-removal steps. SemiAnalysis modeling and AMAT mgmt commentary both attribute "structural capital intensity shift to materials engineering" — the binding scaling lever shifts from lithography (where the cost-per-step ASML captures) to deposition/etch/integration (which AMAT captures) [21][25]. AMAT mgmt guides >20% growth in semi-equipment business in calendar 2026 vs. WFE market growth in the high single digits [26].

2. **HBM moves to hybrid bonding faster than consensus.** AMAT/BESI Kinex captures the volume tool-of-record position before Lam productizes its own integrated D2W solution. HBM revenue path $1.5B → $3B → $5B+ within 4 years [20].

3. **AGS recurring revenue compounds at double digits.** $6.4B base, durable margin ~30%, anchors the cyclical valuation reset.

4. **China step-down ($600–710M FY26 revenue hit) is "one and done"** — replaced by leading-edge AI demand. Fab spending on N2 / A14 / HBM4 grows fast enough that it more than absorbs the loss [27].

**Base rate:** WFE oligopolies are remarkably stable. The Big Five have held ~70%+ of WFE for 15+ years; intra-oligopoly share shifts of >3 pts in 3 years are rare absent a technology platform shift (e.g., EUV gave ASML +20 pts over a decade). At the segment level AMAT has neither lost meaningful share nor gained it; the bull case is structural growth in the *pie*, not share gain. **Financial outcome:** mid-teens revenue CAGR, gross margin holding 48–50%, EPS to $13–14 in FY27 → fair value ~$450–550 at re-rated 33–40× cyclically-adjusted P/E.

## Bear case — technical
A short-seller who reads the stack would write:

1. **The binding constraint on AI is power, not silicon, and the silicon curve will eventually slow.** If hyperscaler 2026 capex (consensus ~$600B) decelerates because GW interconnect cannot be delivered, fab capex is the second derivative — TSMC will simply not lay down the gross adds. AMAT is highly cyclical to fab capex; the multiple does not reflect this [28].

2. **AMAT's growth is concentrated in a handful of customers and tool categories** — TSMC alone is ~20–30% of incremental revenue per SemiAnalysis [25]. Single-customer dependence at the cyclical peak is the textbook short setup.

3. **ASM International keeps taking share inside deposition.** Each generation of GAA adds more ALD layers; ASM's share advantage compounds. AMAT's IMS narrative is partly a defensive frame — selling integration because it cannot win the highest-growth single tool.

4. **China domestic substitution is on a clear glide path.** 25% → 35% in one year; 70% target by 2027 [22]. The $600–710M FY26 revenue hit is *not* one-and-done; it is the first of repeated annual step-downs as Naura/AMEC graduate up nodes. AMAT's $252.5M BIS settlement for SMIC violations is also a sign that the China business has political tail risk [29].

5. **Multiple compression.** At ~37× forward P/E and ~10× EV/sales, AMAT trades at a tier reserved for software-like compounders, not a cyclical capital-equipment company that grew revenue 4% in FY25 and faces a $700M China hole in FY26. A re-rate to a 22–25× through-cycle P/E on $13 EPS is $290–325 — roughly 25–35% downside even if the technical thesis is right.

6. **Hybrid bonding as a contested market.** BESI is reportedly being courted by Lam *and* AMAT; if Lam acquires BESI outright the moat collapses [13].

## Market view check
At $435 the market is pricing AMAT ~37× forward earnings and ~10× NTM sales — multiples that historically apply to ASML (lithography monopolist) or to software, not to a diversified WFE supplier whose largest growth segment (HBM/AP) is contested by ASM, Lam, BESI, and Chinese entrants. Consensus PT of $427.50 is *below* the spot, meaning the sell-side has already capitulated on near-term upside but maintains Buy on long-duration AI capex. The market is implicitly assuming (a) hyperscaler capex compounds 20%+ multi-year, (b) WFE intensity per wafer keeps rising, (c) AMAT does not lose share inside the WFE oligopoly, and (d) the China revenue base stabilizes near current levels rather than continuing to compress. I disagree most with (a) — power-side bottlenecks make 20%+ capex CAGR through 2028 unlikely — and somewhat with (d). The price embeds the bull-case technical reality with little margin of safety.

## 90-day falsifiers
- **2026-05-14 Q2 FY26 earnings:** Did Q2 revenue beat the $7.65B midpoint? Did mgmt raise the >20% calendar 2026 semi-equipment growth bar, or quietly walk it back? Watch *advanced packaging revenue* disclosure and HBM run-rate commentary [30].
- **TSMC monthly revenue prints (May, June, July):** Sequential monthly growth >5% supports the WFE thesis; flat/down two months in a row would be a leading indicator that fab tool orders cool.
- **NVIDIA Q1 FY27 earnings (late May 2026):** Hopper/Blackwell sell-through and Rubin order book; any softening in CoWoS-L allocation pull-through hits the AP narrative directly.
- **Hyperscaler Q2 capex guides (Microsoft, Meta, Google, Amazon — late July/early August):** A >10% sequential cut to 2026 capex from any two of the four is a thesis-changer.
- **AMEC / Naura tool-of-record announcement at TSMC 5nm or below:** Would validate the China-displacement bear case ahead of timeline.
- **Any BESI tender from Lam or third party:** Would force AMAT either to bid up or watch the AP moat partly walk away.
- **BIS / Commerce Department additional China rules:** A further restriction on advanced-packaging tools to China would re-trigger the export-control discount.

## What I could not verify
- AMAT's exact FY25 revenue mix between leading-edge logic, DRAM/HBM, NAND, and ICAPS at the dollar level (mgmt discloses qualitative "fast lane" vs. "slow lane" but not the matrix).
- True person-years to replicate the Endura/Centura cluster platform from scratch (claim is "decades" but I could not source a credible engineering-effort estimate).
- Per-tool AMAT content on HBM4 16-hi vs. HBM3e 12-hi (the $1.5B → $3B HBM revenue path is mgmt-asserted, not independently triangulated).
- Specific Sym3 Y Magnum tool-of-record share at TSMC N2 vs. competing Lam Kiyo / TEL Tactras tools.
- Whether the BESI takeover rumors are real or trade-press speculation [13].
- Implied FY26E revenue precisely: 38-analyst mean is ~$32B but EV/sales of ~10× implied at $345B mkt cap & ~$5B net cash points to a slightly different denominator than the 8.3× quoted on dated sales estimates — I used the more current revenue figure for the snapshot.

## Sources
[1] https://finance.yahoo.com/quote/AMAT/ — retrieved 2026-05-10 — AMAT close $410.64 on 2026-05-07; intraday $435.44 on 2026-05-08; ATH $438.04 set 2026-05-08
[2] https://stockanalysis.com/stocks/amat/statistics/ — retrieved 2026-05-10 — 52-wk range, valuation multiples, statistics
[3] https://www.gurufocus.com/term/forward-pe-ratio/AMAT — retrieved 2026-05-10 — Forward P/E ~35–38× depending on update timestamp
[4] https://stocksguide.com/en/forecast/Applied-Materials-US0382221051 — retrieved 2026-05-10 — 38-analyst FY26E sales mean $32.0B, EV/Sales ~8.3× on dated figures
[5] https://www.marketbeat.com/stocks/NASDAQ/AMAT/forecast/ — retrieved 2026-05-10 — Median PT $427.50; 27 Buy / 8 Hold / 0 Sell
[6] https://finance.yahoo.com/markets/stocks/articles/applied-materials-stock-just-got-130002447.html — retrieved 2026-05-10 — YTD +60–68%, +181% trailing 52 weeks
[7] https://www.appliedmaterials.com/us/en/blog/blog-posts/a-new-equipment-platform-for-a-new-era-of-chipmaking.html — retrieved 2026-05-10 — Endura (1990), Centura (1992), Producer, Sym3/Centris platform history and vacuum-cluster architecture
[8] https://www.appliedmaterials.com/us/en/semiconductor/markets-and-inflections/advanced-logic/gaa.html — retrieved 2026-05-10 — Selectra >1,000 chambers; epi market leadership; GAA process steps
[9] https://www.semicontaiwan.org/en/node/13141 — retrieved 2026-05-10 — Sym3 Y Magnum adopted at angstrom-era nodes for EUV patterning
[10] https://patentpc.com/blog/top-chip-making-equipment-companies-asml-applied-materials-and-lam-research-market-data — retrieved 2026-05-10 — WFE Big-Five share data and product-line breakdown
[11] https://www.techinsights.com/blog/wfe-market-share — retrieved 2026-05-10 — ASML overtakes AMAT as #1 WFE in early 2026; AMAT 18.4%; etch/deposition shares
[12] https://www.blog.baldengineering.com/2025/05/asm-international-strengthens-ald.html — retrieved 2026-05-10 — ASM >55% in single-wafer ALD; ALD layers grow with GAA
[13] https://www.eetimes.com/applied-materials-besi-push-die-to-wafer-hybrid-bonding-toward-high-volume-manufacturing/ — retrieved 2026-05-10 — Kinex die-to-wafer hybrid bonder details; AMAT-BESI partnership; AP TAM $5B → $10B+
[14] https://fintel.io/ss/us/amat — retrieved 2026-05-10 — Short interest 13.59M shares (1.71% of shares outstanding); 793.6M shares outstanding
[15] https://ir.appliedmaterials.com/news-releases/news-release-details/applied-materials-announces-fourth-quarter-and-fiscal-year-2025 — retrieved 2026-05-10 — FY25 revenue $28.37B; AGS $6.4B; non-GAAP gross margin 48.8% (25-yr high)
[16] https://tech-insider.org/ai-data-center-power-crisis-2026/ — retrieved 2026-05-10 — Uptime Institute 10GW AI load by end-2026; grid interconnect 5–7yr; OpenAI 29 gas turbines for Stargate
[17] https://markets.financialcontent.com/stocks/article/tokenring-2026-1-23-the-great-packaging-surge-tsmc-targets-150000-cowos-wafers-to-fuel-nvidias-rubin-revolution — retrieved 2026-05-10 — TSMC CoWoS targeting 130–150K wpm by end-2026
[18] https://www.digitimes.com/news/a20251210PD218/tsmc-cowos-capacity-nvidia-equipment.html — retrieved 2026-05-10 — NVIDIA books >50% of CoWoS for 2026–27, ~510K wafers CoWoS-L for Rubin
[19] https://newsletter.semianalysis.com/p/scaling-the-memory-wall-the-rise-and-roadmap-of-hbm — retrieved 2026-05-10 — HBM market dynamics; SK hynix 57% share; HBM4 16-hi spec
[20] https://www.nasdaq.com/articles/applied-materials-fy25-hbm-revenues-hit-15b-new-growth-driver — retrieved 2026-05-10 — AMAT HBM revenue $1.5B FY25, target $3B
[21] https://newsletter.semianalysis.com/p/clash-of-the-foundries — retrieved 2026-05-10 — 2nm GAA + BSPDN capital-intensity shift toward deposition / removal / materials engineering
[22] https://www.trendforce.com/news/2026/02/20/news-china-reportedly-ramps-up-chip-tool-push-sets-70-target-by-2027-smee-naura-at-forefront/ — retrieved 2026-05-10 — China domestic WFE 35% in 2025, 70% target 2027; AMEC 5nm etch in TSMC validation; Naura 28nm at SMIC
[23] https://markets.chroniclejournal.com/chroniclejournal/article/tokenring-2026-1-21-china-reaches-35-semiconductor-equipment-self-sufficiency-amid-advanced-lithography-breakthroughs — retrieved 2026-05-10 — Confirmation of 35% domestic-equipment share milestone
[24] https://www.digitimes.com/news/a20260326PD217/naura-technology-amec-3d-packaging-equipment-investment.html — retrieved 2026-05-10 — Naura, AMEC pushing into China advanced-packaging
[25] https://fundaai.substack.com/p/deepamat-structural-capital-intensity — retrieved 2026-05-10 — TSMC contribution to AMAT growing 20–30% YoY 2026; structural capex shift to materials engineering
[26] https://www.investing.com/news/transcripts/earnings-call-transcript-applied-materials-q1-2026-beats-eps-forecast-stock-slips-93CH-4504178 — retrieved 2026-05-10 — Q1 FY26 print $7.0B; Q2 guide $7.65B ±$500M; calendar 2026 >20% semi-equipment growth target
[27] https://www.trendforce.com/news/2025/11/14/news-applied-materials-flags-a-2026-china-fab-spending-drop-amid-tougher-u-s-export-rules/ — retrieved 2026-05-10 — $600–710M FY26 revenue impact from China export restrictions; China 28% of FY25 systems+services
[28] https://ibinterviewquestions.com/guides/energy-investment-banking/data-center-power-boom-ai-demand-hyperscaler — retrieved 2026-05-10 — Hyperscaler 2026 capex ~$600B; power as binding constraint
[29] https://www.supplychaindive.com/news/applied-materials-252-2m-penalty-bis-smic-china-export-violations/812237/ — retrieved 2026-05-10 — $252.5M BIS settlement for SMIC export violations; 56 violations / $126M ion-implant equipment
[30] https://ir.appliedmaterials.com/news-releases/news-release-details/applied-materials-report-fiscal-second-quarter-2026-results-may — retrieved 2026-05-10 — Q2 FY26 earnings scheduled 2026-05-14