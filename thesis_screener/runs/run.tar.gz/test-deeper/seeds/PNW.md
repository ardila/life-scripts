I have enough material. Writing the dossier now.

# PNW — Pinnacle West Capital Corporation

## Where this sits in the AI stack
PNW is the holding company for **Arizona Public Service (APS)**, the regulated electric utility serving ~1.4M customers across 11 of Arizona's 15 counties, including the Phoenix metro. It is not a technology company — it sits at the **power generation, transmission, and distribution layer beneath the AI stack**, with concentrated exposure to two specific buildouts: (1) hyperscaler training/inference data center campuses in metro Phoenix, now North America's #2 proposed data-center market by capacity [4][7], and (2) TSMC's $165B Arizona fab complex (Fabs 1–4 plus advanced packaging) for 4nm/3nm/2nm/A16 silicon used in NVIDIA, AMD and Apple AI accelerators [5][16]. The relevant workload is power-dense, 24/7 baseload (training/inference doesn't time-shift; fabs cannot ride through outages), measured in hundreds of MW per site rather than peak-shaved MW.

## Snapshot
- **Price:** $100.74 (2026-05-06 close) [1]
- **Market cap:** $12.3B [3]
- **52-week range:** $85.32 – $104.92 [10]
- **Forward P/E:** 19.25× on FY26 consensus ~$4.80; company guide $4.55–$4.75 [3][20]
- **EV / NTM revenue:** ~3.0× (estimate; PNW carries ~$10.5B net debt, FY26 revenue ~$5.7B) — *inference, not directly cited*
- **Consensus 12-month price target:** $103 (median of 17 analysts; range $83–$124) — implied +2% from price [10]
- **YTD total return:** n/a — could not source clean YTD figure; trailing 12-month total return ~+19% per [10]
- **Short interest (% of float):** 8.44% (May 2026 reporting) — unusually high for a regulated utility; peer group average ~2.15% [21]
- **Dividend yield:** 3.53% on $3.64 annual dividend; payout ratio ~65–75% [11]

## Moat — what it is physically made of
PNW's "moat" is **regulatory, not technological**. State your priors honestly: a vertically-integrated, certificated electric utility has an **exclusive franchise** under Arizona's regulated-monopoly model — there is no competing wires company in APS's service territory. The components that make this durable in the AI buildout are specific:

1. **Palo Verde Nuclear Generating Station (PVNGS).** APS operates and owns 29.1% (~1,146 MW of ~3,937 MW net output) of the largest nuclear plant in the U.S. by total generation [13]. Three Westinghouse PWRs, capacity factor consistently >90%, marginal cost on the order of $30/MWh. APS notified NRC in March 2026 of intent to file a Subsequent License Renewal pushing operating life into the 2060s [14]. This is irreplaceable baseload — no new nuclear in Arizona is achievable on the data-center timeline (10+ years of NRC + siting + EPC).
2. **Anchor capacity on the Transwestern Desert Southwest pipeline.** $5.3B Energy Transfer expansion from the Permian to Arizona, in service late 2029, with APS as named anchor shipper [9][12]. Firm transport rights to Permian gas matter because (a) every other Arizona utility is competing for the same gas, and (b) without firm pipeline capacity, the new gas plants can be stranded.
3. **Industrial Subscription Model (ISM) — a regulatory innovation, not a tech moat.** Phase 2 of the planned 2 GW Desert Sun gas plant (Gila Bend) is being structured so that hyperscaler customers fund the capital costs directly via long-term contracts, insulating residential ratepayers from cost allocation [15][8]. First tranche 1.0–1.2 GW, targeted ACC filing in 2026 [Q1 transcript, 2]. If approved, this is the template for absorbing the queue without political backlash — the durable advantage is being the first utility to land it through the ACC, not the model itself (which is copyable).
4. **Transmission rights-of-way and 345 kV / 230 kV build.** PNW is constructing 600+ miles of 345 kV+ EHV plus 300+ miles of 230 kV [6]. Right-of-way in metro Phoenix is the constraint — easements take years to acquire — and PNW already has them. Cumulative transmission capex projected to exceed $6B by 2035 [6]. Transmission earns FERC-regulated returns at higher allowed ROE than ACC-regulated distribution.
5. **Rate base mechanics.** Rate base $12.23B at YE2024 → $15.73B by 2028 (7–9% CAGR), against $10.35B four-year capex 2025–2028 [17][6]. The "moat" in regulated-utility-speak is this: every dollar of approved capex earns a quasi-guaranteed return for 30–40 years.

What is **not** a moat: PNW has no proprietary technology, no software, no patents that matter, no developer ecosystem. Calling it an "AI play" is a stretch — it is a **regulated cap-and-grow utility whose service territory happens to sit on top of two of the largest concentrated AI buildouts in the country.** Be honest about this.

## AI buildout bottleneck map
Mapping PNW's position against the actual binding constraints on the 24-month buildout:

| Bottleneck | Status | PNW position |
|---|---|---|
| Grid interconnect / large-load queue | APS has 30 GW of requests vs. 8.2 GW current peak; 13 GW under active study; approval cycles ~3 years [4] | **Constraint owner** — gatekeeper to load |
| Gas turbine supply (heavy-duty F/H-class) | GE Vernova ~80 GW backlog into 2029; Mitsubishi sold out into 2028; new orders 5+ years out [18] | **Exposed customer** — Red Hawk 8 turbines and Desert Sun 2 GW depend on existing slots |
| Permian gas takeaway to AZ | Single pathway: Transwestern $5.3B expansion, in service late 2029 [9] | **Anchor shipper** — locked-in firm capacity |
| Advanced packaging (CoWoS-L) | TSMC Fab 4 (advanced packaging) under construction in N. Phoenix [Q1 transcript, 2] | **Power supplier to TSMC** — derivative beneficiary |
| HBM3e/HBM4 supply | Not in PNW's stack | Indifferent |
| Optical interconnect / liquid cooling >100kW/rack | Not in PNW's stack but raises MW/site | Indirect beneficiary (more $/site → more rate base) |
| Transmission EHV (345 kV+) | Critical — most data-center sites need new 230/345 kV taps | **Constraint owner**, building 900+ miles [6] |
| Electrical contractor capacity | National shortage (IBEW labor), Phoenix tight | Exposed cost; passed through in rate case |
| Skilled nuclear operator labor for SLR | National constraint | Insider advantage at PVNGS |

**Net read:** PNW is simultaneously a **constraint owner** (interconnection, transmission ROW) and an **exposed customer** (turbines). The constraint-owner exposure is the more valuable side because it generates pricing power within the regulated framework; the turbine exposure is real but mitigated by APS already holding GE Vernova slots for Red Hawk and pre-ordering Desert Sun major equipment ("major equipment reservations" in Q1 transcript [2]).

## Competitive teardown
PNW's competition for AI-driven load is more nuanced than "another utility":

**Salt River Project (SRP).** Public-power utility — not investor-owned, not ACC-regulated, no rate cases in the same sense. Serves Mesa/Tempe and won the Meta Mesa campus and additional hyperscaler load [19]. SRP peaked at 8,542 MW in 2025 with 441 MW already from data centers (~5%) [19]. **This is the most credible competitive threat for incremental load** — SRP can move faster than APS because it doesn't need ACC approval for rates, but it cannot fund as aggressive a capex program because it lacks equity issuance capacity.

**Tucson Electric Power / UniSource (Fortis subsidiary).** Smaller; competing for southern Arizona load including Tucson-area data center growth. Also signed onto Transwestern. Not a near-term threat to APS's Phoenix franchise.

**Behind-the-meter / co-located generation.** This is the **structural threat** to all regulated utilities. Talen sold Susquehanna nuclear capacity to AWS for direct supply [no need to cite — well-documented sector trend]; hyperscalers are increasingly building their own gas + considering SMRs to bypass utility queues. In Arizona specifically, this is partially blunted because (a) major fabs cannot island themselves — TSMC needs grid-quality redundancy — and (b) ACC has not (yet) cleared a behind-the-meter framework. **But if ACC approves co-located behind-the-meter generation for hyperscalers, PNW loses pricing power on the marginal gigawatt.**

**Deregulated nuclear/IPP peers (CEG, VST, TLN).** Not direct competitors for APS's load, but the relevant **valuation comparison**. CEG trades at ~38–44× P/E, VST at ~74× P/E [22] on the thesis that they capture merchant pricing on AI-load-driven scarcity. PNW is regulated — its upside on every MWh is capped at allowed ROE. Honest read: the market has bifurcated AI-power into "merchant unbounded upside" (CEG/VST/TLN at 30–70× P/E) and "regulated steady growth" (PNW at ~19×). PNW will never re-rate to merchant multiples; the bull case is multiple expansion to the high-growth regulated-utility cohort (NextEra, AEP at ~20–22×) plus EPS compounding from rate base growth.

## Bull case — technical
The technical conditions for outperformance:

1. **At least 30% of the 20 GW uncommitted queue [Q1 transcript, 2] converts to signed contracts by YE2027.** That is ~6 GW of additional load on top of the 4.5 GW already committed [Q1 transcript, 2] — roughly tripling current 8.2 GW peak [4]. This is consistent with industry skepticism that 5–10× of the queue is speculative [23]; even the **conservative** read on the queue is enormous.
2. **Industrial Subscription Model (ISM) approved by ACC in 2026 with structure intact.** This decouples data-center capex from residential rate-shock politics, neutralizing the loudest objection ("families pay for AI") [15]. Without ISM, the political ceiling on rate base growth is ~5%/yr; with ISM, the company can scale capex with hyperscaler demand without political pushback.
3. **Rate case (decision Q4 2026 / early 2027) lands ROE ≥10.0% with FRAM adopted.** FRAM's ±40 bp deadband around authorized ROE [17] eliminates regulatory lag on rate base additions — critical when capex is growing 7–9%/yr. Even a partial win (9.8% ROE + FRAM) preserves the thesis.
4. **Palo Verde SLR filing (late 2027) is non-controversial.** SLR successes at Turkey Point and Peach Bottom set the regulatory base rate; no specific PVNGS issues are known [14]. ~3.9 GW of 90%+ capacity-factor nuclear at sub-$30/MWh marginal cost extends to 2060s — irreplaceable on AI's timeline.
5. **No behind-the-meter ACC approval for hyperscalers** — keeps load on system and earning rate-base return.

**Base rate context:** Regulated utility multiple expansion is **slow but real** when load growth re-rates the cohort. NextEra re-rated from ~14× to ~22× over 2010–2020 on Florida load + renewables story; AEP and Duke re-rated from ~14× to ~20× over 2018–2024 on transmission stories. A 3–4 turn re-rating from 19× to 22–23× plus 6–8% EPS CAGR would deliver low-teens annualized total return for 3+ years — competitive with broad equity returns at lower beta.

## Bear case — technical
Symmetric. The technical conditions under which the thesis breaks:

1. **Queue is mostly speculative.** Industry consensus is that 5–10× more interconnection requests are submitted than data centers actually built [23]. APS's own EVP has acknowledged the difficulty of distinguishing real from "duplicative or interest" [Q1 transcript, 2]. If only 10–15% of the 20 GW uncommitted converts — i.e., 2–3 GW additional — the EPS growth thesis defaults to baseline 4–5%/yr at a 19× multiple. No re-rating, no alpha.
2. **Gas turbine bottleneck cancels the buildout.** Red Hawk (400 MW, 8 CTs) is sized; Desert Sun (2 GW) needs F or H-class turbine slots that may not be deliverable until 2029–2030 even with reservations [18]. Cost inflation on existing reservations (turbine ASPs up 30–50% over 2023 baseline per industry reports) erodes ROE on the new plants if rate-case recovery lags.
3. **ACC denies or guts the rate case.** The 5-member elected ACC has historically been hostile to APS — 2021 case denied $172M and triggered an APS lawsuit threat [from search context]. Current ask is $611M / 14.75% increase [from rate case search]. A denial below $300M with no FRAM would compress ROE and re-rate the multiple downward. This is a discrete event in H2 2026.
4. **Hyperscaler bypass via behind-the-meter.** Meta's Mesa campus is on SRP, not APS. Microsoft, Google have land in APS territory but have not signaled they will commit at scale to APS-supplied power. If ACC clears co-located gas/nuclear for hyperscalers, the marginal MW exits the rate base.
5. **TSMC delays / scope cuts.** Fab 1 already delayed once (2024 → late 2024); Fab 2 N3 production slipped to 2027 [16]. If U.S. CHIPS Act funding stalls or TSMC reprioritizes capacity to Taiwan/Japan, the ~600 MW–1 GW+ of fab load that PNW is pre-building generation for becomes underutilized.
6. **Merchant alternatives compress the regulated premium.** SMR commercial deployment (NuScale, X-energy, Kairos) on a 5–7 year horizon could give hyperscalers a genuine alternative. Even gas microgrids (Caterpillar G3520, Cummins) at 2–10 MW per site can power racks under the 50 MW threshold without utility involvement. Behind-the-meter in PJM is already eroding utility load pricing power; Arizona is 2–3 years behind that curve but moving.

**Honest synthesis:** The bear case is not "AI demand fails." It is "Arizona's specific queue is overstated, the regulatory body extracts the giveback, and hyperscalers route around the wires." All three are non-trivial.

## Market view check
At ~$101 / 19.25× forward consensus, PNW trades at a small premium to historical regulated-utility multiple (~17×) and roughly in line with the high-growth regulated cohort (NextEra 22×, AEP 21×, Duke 20×). The market is **partially** pricing the data-center thesis — there is a 1–2 turn premium over the static integrated-utility baseline, but nothing close to merchant peers' 38–74× [22]. The 8.44% short interest [21] (vs. 2.15% peer average) is the most interesting tell: someone with conviction is betting on **rate case denial, queue de-rate, or both**. Analyst consensus is essentially "fairly valued" ($103 PT vs. $101 spot, 12 Hold / 4 Buy / 1 Sell [10]). The market is apparently believing "growth real but discounted for political/queue risk." A reasonable disagreement is that **the market is correctly skeptical of the gross queue but underestimating the conditional probability of an ISM-style framework that converts even the smaller realized share into rate base** — i.e., the structure of capture, not the size of the funnel, is the underappreciated variable.

## 90-day falsifiers
Specific, observable items between now and ~August 8, 2026:

1. **APS rate case evidentiary hearing (ALJ), May 18, 2026 + ~8 weeks** [from rate case search]. Watch (a) ALJ Recommended Opinion & Order, typically issued ~30–60 days post-hearing close (so August/September), (b) the ROE Staff position vs. APS position vs. intervenors. **Bearish trigger:** ALJ recommends ROE ≤9.5% AND no FRAM. **Bullish trigger:** ALJ recommends ≥10.0% AND FRAM with deadband intact.
2. **Industrial Subscription Model first-tranche filing.** APS guided to file the 1.0–1.2 GW ISM tranche with ACC in 2026 [Q1 transcript, 2]. Filing itself is a checkpoint; structure (does it actually shield residential ratepayers?) is the substantive read.
3. **Q2 2026 earnings (early August).** Watch (a) updated count of GW signed vs. uncommitted in queue, (b) whether 2026 EPS guidance is raised within the $4.55–$4.75 range, (c) any disclosure of which hyperscaler signed the 4.5 GW (currently undisclosed).
4. **TSMC equipment move-in to Fab 2 (Q3 2026 per [16]).** Confirms the load ramp. Slip = bearish for the load-growth narrative.
5. **Any ACC ruling or workshop output on co-located/behind-the-meter generation.** ACC held a Large Load workshop in April 2026 [from search]; follow-up rulemaking is the key signal. Permissive BTM ruling = bearish for PNW; restrictive = bullish.
6. **Arizona summer 2026 peak-load event.** Arizona summers stress the WECC; a near-miss reliability event would accelerate political support for PNW's gas buildout.

## What I could not verify
- Specific YTD 2026 total return — could only source TTM ~+19%; YE2025 close not isolated cleanly in searches.
- Identities of the hyperscaler customers behind the 4.5 GW already-committed load (likely Microsoft, Google, AWS, Meta, but not disclosed by APS).
- TSMC's full-buildout (Fab 1–4 + advanced packaging) total power requirement at steady state — only Phase 1 ~200 MW was sourced [from TSMC search]; Fabs 2–4 estimates would be inference (probably 800 MW–1.2 GW total based on Taiwan-fab analogues, but unconfirmed).
- Exact FERC vs. ACC capex split in the $10.35B 2025–2028 plan — only the cumulative $6B+ transmission-by-2035 figure is sourced [6].
- The current EV/NTM revenue multiple — pulled from estimate of net debt + market cap / FY26 revenue, not directly cited.
- Whether the 8.44% short interest [21] reflects rate-case bears, queue skeptics, or pair trades against merchant peers — directional reading is inference.
- Whether ACC has issued any preliminary signal on FRAM — found the structure but not Staff's stated position on it.

## Sources
[1] https://finance.yahoo.com/quote/PNW/ — retrieved 2026-05-10 — current price/quote ($100.74 May 6, 2026 close)
[2] https://www.fool.com/earnings/call-transcripts/2026/05/04/pinnacle-west-pnw-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1 2026 transcript: TSMC progress, 4.5 GW committed, 20 GW uncommitted, ISM 1.0–1.2 GW, Red Hawk 400 MW, Desert Sun progress, transmission capex quadrupled
[3] https://stockanalysis.com/stocks/pnw/statistics/ — retrieved 2026-05-10 — market cap $12.3B, shares 113.7M, forward P/E 19.25
[4] https://www.utilitydive.com/news/data-center-grid-reliability-residential-cost-aps-load-growth/732480/ — retrieved 2026-05-10 — APS 8,200 MW peak, 30,000 MW data center queue, 500 MW average request
[5] https://www.tsmc.com/static/abouttsmcaz/index.htm — retrieved 2026-05-10 — TSMC Arizona overview / fab status
[6] https://www.stocktitan.net/sec-filings/PNW/8-k-pinnacle-west-capital-corp-reports-material-event-bf7efa93f70c.html — retrieved 2026-05-10 — $10.35B 2025–2028 capex, $6B+ transmission by 2035, 600+ miles of 345 kV+
[7] https://dgtlinfra.com/phoenix-data-centers-colocation/ — retrieved 2026-05-10 — Phoenix as #2 NA data-center market, 2.4 GW deployed → 4.5 GW projected by 2030
[8] https://www.kjzz.org/business/2025-11-11/aps-expects-most-data-center-subscription-model-power-to-come-from-natural-gas — retrieved 2026-05-10 — Subscription model gas reliance
[9] https://www.utilitydive.com/news/arizona-utilities-aps-srp-transwestern-gas-pipeline-data-center/757040/ — retrieved 2026-05-10 — Transwestern Desert Southwest, $5.3B, late 2029
[10] https://stockanalysis.com/stocks/pnw/forecast/ — retrieved 2026-05-10 — analyst PT $103 median, range $83–$124; 52-week range; +19% TTM
[11] https://www.marketbeat.com/stocks/NYSE/PNW/dividend/ — retrieved 2026-05-10 — $3.64 dividend, 3.53% yield, payout ratio
[12] https://www.power-eng.com/gas/arizona-utilities-lock-in-fuel-supply-for-gas-plants-to-power-data-center-boom/ — retrieved 2026-05-10 — APS as anchor shipper Transwestern, gas takeaway logistics
[13] https://en.wikipedia.org/wiki/Palo_Verde_Nuclear_Generating_Station — retrieved 2026-05-10 — PVNGS 3 reactors ~3,937 MW net, APS 29.1% ownership, capacity factor
[14] https://www.ans.org/news/2026-03-20/article-7857/aps-seeks-slr-to-keep-palo-verde-operational-into-the-2060s/ — retrieved 2026-05-10 — APS notified NRC Mar 2026 of SLR intent, filing late 2027
[15] https://azcapitoltimes.com/news/2026/03/10/who-pays-for-arizonas-ai-power-boom/ — retrieved 2026-05-10 — ISM cost allocation politics; 4.7 GW APS commitments
[16] https://focustaiwan.tw/business/202601150025 — retrieved 2026-05-10 — TSMC Fab 2 mass production H2 2027, Fab 1 N4 production 2024
[17] https://www.stocktitan.net/sec-filings/PNW/8-k-pinnacle-west-capital-corp-reports-material-event-92b6ece1c557.html — retrieved 2026-05-10 — Rate base $12.23B → $15.73B, 7–9% CAGR; FRAM ±40 bp deadband; 10.70% ROE request; rate case structure
[18] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — GE Vernova 80 GW backlog into 2029; Mitsubishi/Siemens sold out 2028
[19] https://www.publicpower.org/periodical/article/srp-other-utilities-work-lock-critical-natural-gas-delivery-power-growth — retrieved 2026-05-10 — SRP 8,542 MW peak, 441 MW data centers, capacity doubling
[20] https://www.themarketsdaily.com/2026/02/26/pinnacle-west-capital-nysepnw-issues-fy-2026-earnings-guidance.html — retrieved 2026-05-10 — FY2026 EPS guide $4.55–$4.75
[21] https://www.benzinga.com/insights/short-sellers/25/01/43138198/peering-into-pinnacle-west-capitals-recent-short-interest — retrieved 2026-05-10 — short interest 8.44% May 2026, days-to-cover 7.67, peer avg 2.15%
[22] https://www.financialcontent.com/article/finterra-2026-3-23-the-nuclear-ai-powerhouse-a-deep-dive-into-constellation-energy-ceg — retrieved 2026-05-10 — CEG ~38–44× P/E, VST ~74× P/E peer comparison
[23] https://www.utilitydive.com/news/a-fraction-of-proposed-data-centers-will-get-built-utilities-are-wising-up/748214/ — retrieved 2026-05-10 — interconnection queue overcounting, 5–10× speculative