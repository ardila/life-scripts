I have enough material to write a rigorous dossier. Note up front: ISRG is Intuitive Surgical — a surgical robotics company, not an AI infrastructure name. The right analytical move is to use the technical-substrate lens the prompt asks for, but apply it to the actual stack (mechatronics, force sensing, computer vision, FDA regulatory, razor-blade I&A economics) and be honest that ISRG sits *downstream* of the AI buildout as an edge-inference customer, not a participant.

# ISRG — Intuitive Surgical, Inc.

## Where this sits in the AI stack
ISRG is not an AI infrastructure name. It designs, manufactures and operates the dominant multi-port soft-tissue surgical robotics platform (da Vinci Xi/5/SP) plus an endoluminal lung-biopsy robot (Ion). At the AI layer, it is a **downstream edge-inference customer** — the new da Vinci 5 console embeds an NVIDIA-partnered compute platform (Blackwell-class silicon, plus Clara healthcare libraries and Omniverse simulation) to run sub-100ms anatomical-segmentation and Case Insights kinematic-analytics workloads on endoscope video and instrument telemetry [1][2]. The economic engine is the razor-blade flywheel: ~$1,800 of instruments & accessories burn per procedure with chip-enforced use limits, against an installed base of 11,395 systems and ~17% procedure growth [3][4]. Workload mix is real-time intra-operative inference + offline video analytics — not training, not frontier, not batch.

## Snapshot
- **Price:** $452.35 (2026-05-04 close) [5]
- **Market cap:** ~$160.0B [6]
- **52-week range:** $427.84 – $603.88 [7]
- **Forward P/E:** ~43.6× (on implied FY26 consensus EPS ~$10.4) [8]
- **EV / NTM revenue:** ~12.5× (market cap $160B less ~$9B net cash ≈ $151B EV / ~$12.0B NTM revenue, inferred from $2.77B Q1'26 and 13.5–15.5% procedure-growth guide) [3][6] — inference, not directly sourced
- **Consensus 12-month price target:** ~$580–$615 median (sources cluster $580–$615; high $750 Bernstein, low $378) implying +28% to +36% [9][10]
- **YTD total return:** ~-15% (down from ~$530 area at year-end 2025; stock peaked at $603.88 on Jan 7, 2026, then fell on tariff/guide concerns) [7][11]
- **Short interest (% of float):** 1.9% (6.75M shares) [6]

## Moat — what it is physically made of

Decompose by layer; durability is uneven.

**1. Installed base + razor-blade enforcement (highly durable).** 11,395 da Vinci systems globally as of Q1'26 [3]. Every EndoWrist instrument carries an embedded thermistor/EEPROM chip that the patient-cart firmware reads to decrement an internal use counter and brick the tool at a hard-coded limit (5 uses for some scissors/needle drivers, 10–18 for graspers/Maryland, with ProGrasp at 18) [12]. This is not a brand moat — it is a cryptographically-enforced consumable lock that converts every system placement into a multi-year I&A annuity at ~$1,800/procedure [3][13]. 85% of FY revenue is recurring [13]. Independent reprocessors (Rebotix, SIS) have spent a decade litigating to break the chip and have made limited US progress; ISRG has won the key antitrust/IP rounds though enforcement remains contested.

**2. EndoWrist instrument IP (durable but laddered).** ~200+ patents covering the cable-driven, wristed, sub-10mm articulating end-effector mechanism and the sterile interface that mates instrument to robotic arm [14]. The original SRI/IBM foundational license (2002) is long-expired, and the earliest wrist patents have rolled off, but ISRG has continuously refreshed the portfolio (advanced stapling, vessel sealing, force-sensing instruments, the Force Feedback line of 6 instruments on da Vinci 5). Competitors can ship a 7-DoF wristed instrument legally; what they cannot ship is the full library + the chip-enforced consumable economic model + the FDA-cleared indication breadth that comes with 10M+ historical da Vinci procedures of safety data.

**3. Surgeon switching cost (durable, slow-decay).** Published learning curves: 16–30 cases to operative-time proficiency on Xi for colorectal, 25–74 cases for rectal resection, 100–250 cases for radical prostatectomy [15]. A surgeon trained on da Vinci who switches to Hugo or Ottava is not transferring muscle memory of a different hand-controller geometry, different foot-pedal mapping, different camera-clutch dynamics, or different stapler firing logic. Importantly the switching cost is *per-surgeon-per-procedure-type*, not per-hospital — meaning that hospitals don't switch, they at most run dual platforms. That asymmetry is the moat.

**4. FDA clearance breadth (durable, regulatory).** da Vinci is cleared across urology, gynecology, general, thoracic, cardiac (5 added early 2026), colorectal, transoral, with SP recently expanded to inguinal hernia, cholecystectomy, appendectomy [16]. Hugo just cleared urology (Dec 2025) [17]; Ottava is de novo-submitted Jan 2026 for upper-abdomen general surgery [18]; Versius Plus is cleared only for cholecystectomy with gynecology pending [19]; Dexter is cleared for inguinal hernia + cholecystectomy + hysterectomy [20]. Each competitor is fighting a multi-year-per-indication regulatory expansion ISRG already completed.

**5. The da Vinci 5 compute refresh (early innings, mostly forward-looking).** ~10,000× compute vs. Xi via NVIDIA Blackwell-class platform with Clara + Omniverse [1][2]. Force Feedback samples directional forces at ~1,000 Hz over a 0–6.5N range and is reported to reduce surgeon-applied force by up to 43% in early studies [2]. Anatomical intelligence inference targets sub-100ms on endoscope video. *This is not yet a moat — it is the option on building one* as the AI-feature stack (Case Insights, real-time guidance, future automation primitives) matures on a console no competitor's hardware can run.

**What is *not* moat:** brand recognition, scale efficiencies in console manufacturing, the surgeon-console industrial design. These are real but commoditizing.

## AI buildout bottleneck map
Honest assessment: ISRG is **largely indifferent** to the AI infrastructure bottlenecks the prompt enumerates.

- **Power/grid, CoWoS-L allocation, HBM3e supply, optical interconnect, >100kW/rack liquid cooling, NCCL/collective-comms talent:** Irrelevant. ISRG runs single-node edge inference inside a sealed surgical-grade console. Volume of NVIDIA silicon needed is rounding error against hyperscaler demand — it ships at most ~2,300 da Vinci systems/year.
- **Training-data quality at frontier:** Irrelevant for training; *highly relevant* for the AI features ISRG can ship. Its proprietary corpus of millions of recorded da Vinci procedures is a private medical-imaging+kinematic dataset competitors cannot replicate without 5+ years of installed base. This is the one place an AI-buildout lens identifies actual ISRG-specific value.
- **Cheap inference compute generally (Blackwell/Rubin/etc. price-performance curves):** Net beneficiary. Edge AI features that were uneconomic on Xi-era silicon become economic on da Vinci 5 and will get cheaper. Every NVIDIA generation expands the feature surface ISRG can ship without a hardware refresh.
- **The bottlenecks that actually gate ISRG's next 24 months** are: (a) FDA clearance throughput on Ion AI-nav broader rollout, da Vinci 5 cardiac/gyn/colorectal expansions [16][21]; (b) tariff exposure — instruments built in Mexico, endoscopes in Germany, components sourced from China; FY26 guide bakes ~1.0% of revenue tariff impact, with management flagging that estimate could go to ~1.7% [22]; (c) hospital capex environment in US/EU; (d) clinical-sales-rep training capacity (every new system requires Intuitive reps to in-service the OR).

## Competitive teardown
The thesis-defining question for 2026–2028. Four credible attackers, each on a different axis. None have parity on all axes.

**Medtronic Hugo — most strategically dangerous, narrow on capability.** FDA-cleared Dec 3, 2025 for urology (prostatectomy, nephrectomy, cystectomy — ~230k US procedures/yr) [17]. Modular cart-based architecture (arms move independently — practical for mixed-OR hospitals), Touch Surgery digital ecosystem for training/insights, Expand-URO IDE trial was the largest multi-port robotic urology study in the US. **Where Hugo wins:** hospitals that already buy Medtronic stapling/energy/imaging, want a second-source bargaining chip, or want modular OR deployment. **Where Hugo loses today:** indication breadth (urology only in US — needs ~3+ years to catch general/gyn/thoracic), no force feedback, no equivalent of Case Insights at scale, no SP equivalent. **What would have to be true to take material share:** sequential indication clearances landing on schedule + visible hospital wins outside Medtronic-aligned IDNs + clinical equivalence shown in published prostatectomy outcomes. Watchable signal — quarterly count of US Hugo installs disclosed by Medtronic.

**J&J Ottava — credible but year-behind.** De novo submitted to FDA Jan 2026 for upper-abdomen general surgery [18]. Pivotal Roux-en-Y gastric bypass study met endpoints in 30-patient cohort; IDE for inguinal hernia recently approved. **Differentiator:** integrated single-table architecture (vs. Hugo's modular carts) targeting general surgery — exactly where ISRG growth has been strongest. **Timing:** US commercial launch realistic late-2026/2027 if de novo lands cleanly; this is not a 2026 share issue but a 2027–2029 one.

**CMR Versius Plus — cost-disrupt play.** First-gen de novo cleared Oct 2024; Versius Plus 510(k) for cholecystectomy Dec 2025; gynecology 510(k) submission April 2026; >40,000 procedures OUS [19]. Modular cart per arm. **Positioning:** cost-conscious community hospitals, OUS first. Less of a direct threat to ISRG's installed base than to its incremental US placements at smaller hospitals.

**Distalmotion Dexter — the asymmetric threat.** De novo Oct 2024, expanded to cholecystectomy + hysterectomy; first US sale to Memorial Hermann; raised $150M; explicitly targets ASCs with single-use instruments removing reprocessing overhead [20]. **Why this matters more than its current scale suggests:** structural ASC migration is the largest payer/CMS trend in general surgery. Dexter doesn't try to beat da Vinci 5 on capability — it tries to beat it on capital intensity and form factor in a setting where da Vinci is overbuilt and the I&A reprocessing workflow is a liability. If 15-20% of low-acuity da Vinci procedures migrate to ASCs over 3-5 years and Dexter captures them, ISRG's procedure growth narrative changes shape even if its hospital base is intact.

**Adjacent and not directly competitive:** Stryker Mako (orthopedic — different anatomical domain, hard-tissue), Asensus Senhance (sub-scale, financial distress), Virtual Incision MIRA (mini-robot, FDA cleared 2024, narrow application).

## Bull case — technical
For ISRG to outperform from $452, the following technical conditions need to hold:

1. **Procedure growth durability.** 17% Q1 was strong; full-year guide 13.5–15.5% [3]. The underlying driver is conversion of laparoscopic and open procedures to robotic — that conversion is still <15% globally in general surgery, leaving structural runway through 2030.
2. **da Vinci 5 platform refresh sustains placement mix at premium ASPs.** 232 of 431 systems placed in Q1 were da Vinci 5 (vs. 147 yr-ago) [3]. da Vinci 5 carries higher ASP and higher I&A pull-through via Force Feedback instruments. Continued mix shift sustains gross margin against tariff drag.
3. **Ion lung biopsy compounds.** 100,000+ Ion biopsies as of mid-2025, AI-nav cleared Oct 2025 for broader 2026 rollout [4][21]. Lung-cancer screening adoption (LDCT) is the supply-side bottleneck Ion attacks. Q1 Ion procedures grew 39%.
4. **AI-feature stack converts compute lead into measurable surgeon-outcome data over 3–5 years.** Case Insights kinematic analytics + Force Feedback outcome data + AI-nav clinical literature published in peer-reviewed journals = a new dimension of moat competitors can't replicate without comparable installed-base data.
5. **Competitors fail to ship indication breadth.** Hugo stays urology-bound for >18 months, Ottava clears narrow, Dexter stays ASC-niche.

**Base rate.** Medical-device incumbent share-loss historically runs 1–3 percentage points/year when credible competitors arrive — *not* 10-20 points/year as in semiconductors or consumer electronics. The reason is the regulatory + clinical-evidence + surgeon-training tax. ISRG has ~60–70% global share of multi-port soft-tissue robotics; even a credible Hugo+Ottava combined ramp leaves ISRG dominant through 2028.

Financial outcome: 14% procedure growth + 100–200bps mix-up from da Vinci 5 → mid-teens revenue CAGR; tariffs cap near-term operating leverage but ease post-2026; FY27/28 EPS could comp ~$13–14, putting current price at ~32× two-year-out earnings — defensible if procedure growth holds in low-teens.

## Bear case — technical
The honest short version a stack-literate seller would write:

1. **Convergence pressure is novel.** This is the first time ISRG faces four FDA-cleared US competitors simultaneously (Hugo, Versius Plus, Dexter, Ottava-pending). Even if no single competitor takes >5 points of share, cumulative pricing pressure on systems and instruments compresses gross margin from the high-60s toward mid-60s over 3–5 years.
2. **ASC migration is structural.** CMS payment rules have systematically moved procedures (including some hysterectomy, hernia, cholecystectomy) toward outpatient settings. da Vinci's footprint, reprocessing workflow, and consumable economics are mismatched to ASC reality — Dexter's single-use-instrument economics are not. ISRG's response (SP into general surgery, lighter-footprint configurations) is partial.
3. **The "10,000× compute" story is mostly forward-looking.** Concrete clinical-outcome evidence from Force Feedback and Case Insights is early (43% lower applied force is preclinical-grade signal, not RCT). If the AI-feature stack does not produce a measurable mortality/complication/length-of-stay edge by 2027–28, the premium console ASP narrative weakens.
4. **Instrument reprocessing legal/regulatory risk is asymmetric.** Any FTC, congressional, or right-to-repair action that forces ISRG to permit independent reprocessing of EndoWrists (the chip-counter business model) is a direct hit to ~half of recurring revenue. Probability low but tail is real.
5. **China.** ISRG-Sino (JV) is a meaningful growth vehicle that is now an explicit tariff/geopolitical exposure [22]. Local competitors (MicroPort MedBot's Toumai) are scaling rapidly with state support in a market where ISRG cannot easily defend.
6. **Valuation.** Forward P/E ~43.6× vs. medical-device median ~20× [8]. The premium prices durable mid-teens growth, no margin erosion, and successful AI-feature monetization. Any two of those slipping and the stock re-rates to 30× → ~$310.

## Market view check
At $452, the stock trades ~25% off January highs, has consensus PTs clustered $580–$615 (high $750 Bernstein) [9][10], forward P/E ~43.6× and EV/sales ~12.5×. The market is implicitly pricing: (a) procedure growth holding low-teens through 2027, (b) tariffs containable at ~1% of revenue, (c) competitors taking some incremental placement share but not denting the I&A annuity. The recent ~15% drawdown is mostly competitive-anxiety re-rating (Hugo clearance, Ottava submission) plus tariff uncertainty, not procedure-growth disappointment — Q1 print actually accelerated procedure growth and forced a guide-raise [3][11]. The market view looks consistent with the technical reality: not obviously mispriced. A stack-literate investor would say ISRG is fairly-to-richly priced for what it is — a high-quality medical-device compounder with a real but no-longer-unchallenged moat. Asymmetric upside requires da Vinci 5 AI features delivering clinical evidence faster than the competitor field clears US indications.

## 90-day falsifiers
- **Q2'26 print (mid-July).** da Vinci 5 placements as % of total — sustained mix >50% confirms refresh momentum; drop below 40% suggests da Vinci 5 demand pulled forward.
- **US Hugo installed-base disclosure** in Medtronic FY26 Q4 / FY27 Q1 earnings. >75 systems placed in <6 months would be ahead of expectations; <25 would confirm slow ramp.
- **Ottava de novo FDA decision or guidance.** A clearance accelerated to late 2026 (vs. consensus 2027) would compress ISRG's general-surgery moat by ~12 months.
- **Tariff resolution.** If US-China tariff settlement reduces the medical-device list-coverage in the next 90 days, ISRG gross-margin guide for 2H26 lifts ~50–80bps. Conversely if tariffs escalate, the 1.0% drag could move to 1.5–1.7%.
- **Ion AI-nav broader-launch metrics.** First commercial-volume data on enhanced navigation should appear in Q2/Q3 disclosures; high-profile clinical-evidence publications would extend the Ion moat.
- **Independent reprocessing antitrust developments.** Any FTC commentary or court ruling on Rebotix/Restore litigation directly affects the chip-enforced I&A model.

## What I could not verify
- Exact net cash position as of Q1'26 close (used ~$9B inference based on historical pattern; published balance sheet not directly accessed).
- The specific NVIDIA SKU(s) inside da Vinci 5. Sources confirm Blackwell-platform, Clara, Omniverse partnership but no public confirmation of whether it's Jetson Thor-class, IGX, or custom Blackwell SoC. This matters for understanding compute headroom for future AI features.
- Force Feedback latency end-to-end (1,000 Hz sample rate is confirmed [2] but full sensor→controller→haptic loop latency in milliseconds is not publicly disclosed).
- Concrete share data — ISRG's claimed "60%+ global share of multi-port soft-tissue" is widely cited but rests on company-disclosed installed-base counts; granular by-procedure share remains commercially sensitive.
- Whether Dexter's single-use-instrument economics actually pencil for ASCs at high volume (this is the central bear-case question and won't be answerable for 12–24 months of real volume).
- Hospital procurement-cycle data showing how many ISRG customers are seriously evaluating Hugo as primary platform vs. dual-source.
- Exact YTD return — derived from peak-to-current move plus 2025 close inference; should be cross-checked against custodian data.

## Sources
[1] https://www.rdworldonline.com/a-surgeon-and-intuitive-exec-explain-what-da-vinci-5s-10000x-computing-leap-actually-looks-like-inside-and-outside-the-or/ — retrieved 2026-05-10 — da Vinci 5 compute platform built in partnership with NVIDIA using Blackwell/Clara/Omniverse; 10,000× Xi compute claim.
[2] https://www.intuitive.com/en-us/about-us/newsroom/Force%20Feedback — retrieved 2026-05-10 — Force Feedback technical specs: 1,000 samples/sec, 0–6.5N, 6 enabled instruments, 43% reduction in applied force.
[3] https://isrg.intuitive.com/news-releases/news-release-details/intuitive-announces-first-quarter-earnings-7/ — retrieved 2026-05-10 — Q1'26: $2.77B revenue (+23%), 17% procedure growth, 431 system placements (232 da Vinci 5), 11,395 installed base; raised FY26 procedure-growth guide to 13.5–15.5%.
[4] https://www.intuitive.com/en-us/products-and-services/ion — retrieved 2026-05-10 — Ion installed base / procedures context.
[5] https://www.trefis.com/stock/isrg/articles2/598599/intuitive-surgical-stock-at-support-zone-bargain-or-trap/2026-05-07 — retrieved 2026-05-10 — May 4, 2026 close $452.35; support zone $429–$474.
[6] https://public.com/stocks/isrg/market-cap — retrieved 2026-05-10 — market cap ~$160B; 354M shares; short interest 1.90% / 6.75M shares.
[7] https://www.financecharts.com/stocks/ISRG/summary/price — retrieved 2026-05-10 — 52-week range $427.84–$603.88; recent peak Jan 7, 2026.
[8] https://www.gurufocus.com/term/forward-pe-ratio/ISRG — retrieved 2026-05-10 — forward P/E ~43.6×.
[9] https://stockanalysis.com/stocks/isrg/forecast/ — retrieved 2026-05-10 — consensus PT $580 range; analyst breakdown.
[10] https://www.wallstreetzen.com/stocks/us/nasdaq/isrg/stock-forecast — retrieved 2026-05-10 — median PT $615.50 / high $750 Bernstein / low $378.
[11] https://www.tikr.com/blog/intuitive-surgical-raises-2026-procedure-guidance-after-a-40-ebit-jump-analysts-price-isrg-above-700 — retrieved 2026-05-10 — stock down ~15% since Nov 30, 2025 on guide-tempering concerns; 40% EBIT jump in Q1.
[12] https://entokey.com/the-da-vinci-system-technology-and-surgical-analysis-2/ — retrieved 2026-05-10 — EndoWrist instrument life mechanics, thermistor chip enforcement, 5–18 use limits by instrument.
[13] https://rijnberkinvestinsights.substack.com/p/intuitive-surgical-a-60-market-share — retrieved 2026-05-10 — 85% recurring revenue / razor-blade model description; market share context.
[14] https://www.intuitive.com/en-us/products-and-services/da-vinci/instruments — retrieved 2026-05-10 — EndoWrist instrument family / patent portfolio context (200+ patents).
[15] https://pmc.ncbi.nlm.nih.gov/articles/PMC11475096/ — retrieved 2026-05-10 — systematic review of robotic colorectal learning curves (29.7 cases Phase 1, 39 cases expert).
[16] https://isrg.intuitive.com/news-releases/news-release-details/intuitive-announces-expanded-indications-da-vinci-sp — retrieved 2026-05-10 — da Vinci SP cleared for inguinal hernia, cholecystectomy, appendectomy (Dec 2025).
[17] https://news.medtronic.com/2025-12-03-Medtronic-announces-FDA-clearance-of-Hugo-TM-robotic-assisted-surgery-system-for-urologic-surgical-procedures — retrieved 2026-05-10 — Hugo FDA urology clearance Dec 3, 2025; ~230k procedures/yr TAM; Expand-URO trial.
[18] https://www.jnj.com/media-center/press-releases/johnson-johnson-submits-ottava-robotic-surgical-system-to-the-u-s-food-and-drug-administration — retrieved 2026-05-10 — Ottava FDA de novo submission Jan 2026 for upper-abdomen general surgery; pivotal RYGB endpoints met.
[19] https://www.globenewswire.com/news-release/2025/12/17/3206725/0/en/CMR-Surgical-secures-510-k-clearance-of-its-Versius-Plus-robotic-surgical-system.html — retrieved 2026-05-10 — Versius Plus 510(k) cleared Dec 2025 for cholecystectomy; >40,000 procedures OUS; $200M+ raised.
[20] https://www.globenewswire.com/news-release/2024/10/28/2969812/0/en/FDA-Grants-De-Novo-Marketing-Authorization-for-the-Distalmotion-Dexter-Surgical-Robot.html — retrieved 2026-05-10 — Dexter de novo Oct 2024; ASC focus; single-use instruments; $150M raised; Memorial Hermann first US sale.
[21] https://investor.intuitivesurgical.com/news-releases/news-release-details/intuitive-expands-ai-and-advanced-imaging-integration-ion — retrieved 2026-05-10 — Ion AI navigation FDA cleared Oct 2025; addresses CT-to-body divergence; broader 2026 US launch.
[22] https://www.ainvest.com/news/intuitive-surgical-tariff-crossroads-growth-margin-pressure-2504/ — retrieved 2026-05-10 — tariff exposure breakdown: instruments in Mexico, endoscopes in Germany, materials from China; ~1.0–1.7% revenue impact range.