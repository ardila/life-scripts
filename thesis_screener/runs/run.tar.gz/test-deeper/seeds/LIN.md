# LIN — Linde plc

## Where this sits in the AI stack

Linde is the world's largest industrial gas company. In the AI stack it sits two layers below the silicon: it builds, owns, and operates **on-site air separation units (ASUs)** physically integrated with leading-edge logic and memory fabs, supplying ultra-high-purity N₂/O₂/Ar by pipeline; supplies **electronic specialty gases** (NF₃, WF₆, SiH₄, dopants, ammonia) for ALD/CVD/etch; and supplies **excimer-laser gas mixtures** (Ne/Kr/Ar/F₂) for DUV lithography. AI exposure is **second-order** — Linde does not see a GPU, a switch, or a CUDA call. It sees wafer-starts at TSMC AZ, Samsung Pyeongtaek, Intel Magdeburg/Ohio, plus growing HBM stacks. A small, low-margin third-order play exists in liquid N₂/CO₂ for hyperscaler fire suppression and cryo cooling, plus blue/green hydrogen optionality that is largely orthogonal to AI [1][2][14][16][17].

## Snapshot

- **Price:** $493.16 (2026-05-08 close) [1]
- **Market cap:** ~$228B [1]
- **52-week range:** $387.78 – $521.28 [4]
- **Forward P/E:** ~27.8× on FY26 EPS guidance midpoint of $17.75 [2][4]
- **EV / NTM revenue:** ~7.0× (P/S 6.78–6.90×; modest net debt) [4]
- **Consensus 12-month price target:** ~$510–$525 (Strong Buy; implied roughly +4% to +6% from spot) [5]
- **YTD total return:** +15.7% [6]
- **Short interest (% of float):** ~1.8% [6]

## Moat — what it is physically made of

The moat is best decomposed into seven components, each with a different durability:

**1. Physically integrated ASUs at customer fence-lines.** Linde's ~$600M on-site complex at TSMC Arizona Fab 21, the eighth on-site ASU now under construction at Samsung Pyeongtaek (start-up mid-2026), the dedicated electronic-gas complex at Intel Magdeburg with sub-atmospheric WF₆ delivery for 18A/14A, plus equivalent assets at Ohio and across Asia, are **welded into the fab piping** and qualified into the fab's PFMEA / quality system [3][15][16][17]. Replacing them is not a procurement decision, it is a fab-shutdown decision. Durability: very high; switching cost is essentially infinite during a node ramp.

**2. 15–20 year take-or-pay sale-of-gas (SOG) contracts.** Q1 2026 SOG backlog at $7.1B with $300M of new project starts and $100M of new signings in the quarter, and management guiding to a possible "eight-handle" by year-end [2][18]. These are inflation-indexed take-or-pay contracts, so if a fab is built they are paid even at low utilization. Durability: contractual, ~20 years.

**3. Pipeline networks.** Houston Ship Channel, Rotterdam-Antwerp, Pyeongtaek-Hwaseong, Singapore — multi-decade hydrogen, oxygen, nitrogen pipeline grids. Inferred replacement cost in the tens of billions; not replicable on AI-cycle timeframes. Durability: highest.

**4. Excimer-laser gas formulation IP.** Linde claims >20 years and "thousands of wafer steppers and scanners" using its KrF/ArF mixtures [13]. EUV does not consume neon at the source, so as the product mix shifts to High-NA EUV, this niche shrinks at the leading edge but is sticky for the entire installed DUV base (which is still the workhorse for >90% of layers) [21]. Durability: medium — slow erosion at the bleeding edge over 10+ years.

**5. Helium and rare-gas supply chain.** Linde holds long-term offtake from Qatar (Ras Laffan), Algeria, the (now-privatized) US BLM reserves, and partial Russian volumes. Helium has **no substitute** for ion-implant cooling, leak detection, MRI quench, and several photolithography steps; demand from semis is forecast to grow >5× by 2035 [11]. Durability: very high — physically rare commodity, oligopolistic supply, decade-long contracts.

**6. Specialty gas qualification.** A 100+ molecule portfolio (NF₃, WF₆, SiH₄, GeH₄, NH₃, dopants), each individually qualified into specific tool recipes at specific fabs. Re-qualification at a new supplier costs 6–12 months per molecule per fab and risks yield. Durability: high.

**7. Oligopoly structure.** Top three (Linde, Air Liquide, Air Products) hold 75–80% of global IG; top five 80–84% [4]. The structure has been stable for ~50 years and survived the Linde–Praxair merger (which actually **tightened** it). Durability: high; capital intensity (4–5% of revenue annually) plus 10–20 year contracts make greenfield entry uneconomic.

What is **not** a moat: brand, headcount, R&D scale relative to Air Liquide. The two are at parity on chemistry and ASU technology; Linde's advantage is mostly contractual and geographic.

## AI buildout bottleneck map

- **Power generation / grid interconnect:** Not a Linde business. Modest 2nd-order exposure via clean-hydrogen ($8B 2023–27 program incl. $1.8B OCI Beaumont blue-H₂) [14]. **Indifferent to modest beneficiary.**
- **Advanced packaging (CoWoS-L):** TSMC scaling from ~35Kwpm (late-2024) to ~130Kwpm (end-2026) [7]. CoWoS lines consume bulk N₂ (inerting, purges) and specialty gases for hybrid bonding, plus large quantities of cleanroom-grade He for leak testing. Linde's Phoenix on-site complex supplies TSMC AZ packaging (Fab 21 expanding to advanced packaging fab #3/#4). **Direct beneficiary.**
- **HBM (HBM3e 12-Hi → HBM4 16-Hi):** Stack count and through-silicon-via density both rising, multiplying ALD/etch/clean steps and helium consumption per stack [8]. Samsung Pyeongtaek is Linde's largest electronics site globally; SK Hynix is more Air Liquide / Nippon Sanso. **Beneficiary, weighted to Samsung.**
- **2nm/3nm logic ramp:** Helium intensity rising ~1.20× per wafer from 3nm to 2nm; GAA nanosheet adds 15–20 ALD steps per layer [8]. **Pure beneficiary** — gas intensity is super-linear in node advancement.
- **Optical interconnect / silicon photonics:** Modest specialty-gas exposure; not a needle-mover.
- **Liquid cooling >100kW/rack:** LN₂/LCO₂ supply for fire suppression and chiller make-up. Real but small (<1% of revenue, inferred). **Modest beneficiary.**
- **Helium supply:** Linde is a **constraint owner**. Q1 2026 Middle East strikes hit Qatar's Ras Laffan complex — ~⅓ of global supply — and BLM privatization completed in early 2026, removing the buffer. Spot helium +50–70%; long-term contracts re-set on roll [11].
- **Neon for DUV:** Constraint owner; post-2022 Linde rebuilt non-Ukrainian capacity. Long-term decline as EUV expands but DUV still dominates layer count [13][21].
- **Electrical contractors / liquid-cooling techs / kernel-compiler talent:** Indifferent.

## Competitive teardown

- **Air Liquide (EPA:AI):** Closest peer, ~31% global IG share to Linde's ~32% [4]. Q1 2026 electronics revenue +5.3% vs Linde +10% [9][2]. Air Liquide is investing €200M in Japan for two ultra-pure ASUs explicitly targeting AI chip manufacturing, and just opened a Taichung advanced-deposition/etch materials plant — Air Liquide's first large-scale Asia specialty-materials site. Implication: **at parity** on ASU technology and ahead of Linde on advanced materials in Taiwan. The competitive edge is regional, not technical.
- **Air Products (APD):** ~$63B market cap vs Linde $228B [10]. Pivoted hard into mega-projects (NEOM green H₂, Louisiana blue H₂); had a CEO/board reset and lost focus on electronics. Not currently a credible challenger for advanced-fab gas wins.
- **Nippon Sanso (TYO:4091):** Strong at SK Hynix, Kioxia/Toshiba, and acquired Linde's divested European assets after the 2018 merger. Roughly even with Linde at SK Hynix HBM. **Real competitor in Korea/Japan**, less so elsewhere.
- **Hangyang / Hangzhou Oxygen (China):** Increasingly capable of bulk ASUs and some rare-gas mixtures for trailing-node Chinese fabs. Not at parity for the 100+ specialty molecules required at 5nm-or-below; cannot supply a TSMC-quality fab today. Direction-of-travel matters more than current state. **Watch on a 5–10 year arc**, not an AI-cycle threat.

## Bull case — technical

For LIN to outperform, four technical conditions need to hold:

1. **Fab capex stays in expansion phase through 2027.** Specifically: TSMC's Arizona ramp continues to Fabs 3–4, Samsung adds a 9th–10th Pyeongtaek line, Intel meaningfully starts up 18A in Ohio and Magdeburg. Each is a ~$0.5–1.0B SOG project with 15–20 year tails [3][15][16][17].
2. **Gas intensity per wafer keeps rising at 2nm/A14.** GAA + High-NA EUV add ~15–20 ALD steps per layer; He per wafer +20% at 2nm [8]. This is volume growth Linde captures **without new capex** through inflation-indexed take-or-pay.
3. **Helium tightness persists.** Qatar repair timeline plus permanent loss of BLM buffer keeps spot 30–50% above pre-disruption levels into 2027 [11]. This is essentially free margin on existing volumes.
4. **No major specialty-gas contract switches to Air Liquide or Nippon Sanso.** Specifically: Samsung's 9th-site decision and the next TSMC AZ wave both go to Linde.

If the four conditions hold, the math is: 1–2% volume + 2–3% pricing + 1–2% from project start-ups = ~5% organic, levered to ~10% EPS by buybacks ($10B program through 2027) [6] and modest margin expansion off the 30% Q1 2026 print [12]. EV/EBITDA stays at 17–18×.

**Base rate:** at substrate-supply oligopoly layers (industrial gas, photoresist, EDA), the historical displacement rate of incumbents over 10-year windows is essentially zero in the Western fab footprint. The only credible disruption is Chinese indigenization, and it is bounded to Chinese fabs.

## Bear case — technical

A short who understands the stack would write:

1. **Electronics is only ~10% of revenue, and the rest is industrial-cycle exposed.** Steel, chemicals, healthcare, food & beverage are 90% of the book. An AI-cycle multiple is being applied to a ~5–7% organic grower. The +20% YTD move ahead of S&P is multiple-led: the Q1 2026 organic was 3% (2% price, 1% volume), not a hyper-growth print [2].
2. **Pricing is doing most of the work.** If 2026 disinflation tightens the price/cost spread, the entire growth algorithm halves. Linde's "moat" allows pass-through, but pass-through is not real growth, and SaaS-like multiples on a pass-through grower are vulnerable.
3. **EUV gradually displaces neon.** EUV at 13.5nm needs no neon at the source; on a 5–10 year arc the excimer-laser gas franchise erodes at the leading edge [13][21]. Not catastrophic, but a slow margin headwind in the highest-margin specialty bucket.
4. **China indigenization caps ~25% of fab capex addressable for Linde.** Hangyang, Pengshen, and others can already supply trailing-node fabs and are climbing the purity curve. SMIC's expanding capacity is not a Linde TAM.
5. **Hydrogen optionality is a capex drag, not a margin tailwind, for the next 3–5 years.** $8B committed; payback depends on green-H₂ end-market economics (steel, ammonia) that have repeatedly disappointed [14].
6. **Multiple compression risk.** 27–28× forward P/E vs Air Liquide ~25× and APD ~21× [4][10]. Half-a-turn of compression on a static EPS is ~$25 of stock.

The honest bear thesis is not that Linde breaks. It is that **a 27× multiple on a take-or-pay industrial-gas company is wrong** — the durability is real, the growth rate is not 10%.

## Market view check

At $493 with a 28× forward and ~7× EV/sales, the market is pricing Linde as a defensible compounder on the AI tailwind. That price is **directionally right on the moat and stretched on the growth rate**: every component of the moat I can decompose is genuinely durable, but the stock is implicitly assuming low-double-digit organic for several years, while Q1 2026 was 3% organic with ~10% reported helped by FX and project start-ups [2]. The mispricing, if there is one, is that the market is treating Linde as an AI-purity name when it is fundamentally an inflation-pass-through industrial whose AI exposure is real but bounded to ~10% of revenue. That is a hold/trim bias, not a short — the moat is too good to short, and the helium tightness is a real near-term tailwind.

## 90-day falsifiers

- **Q2 2026 earnings (~Aug 2026):** Electronics segment growth decelerates from +10% to <+6% YoY, or SOG backlog fails to print >$7.3B → moat-monetization thesis weakens.
- **TSMC's July 2026 capex guidance:** Cut of >5% sequentially → Linde Arizona ramp visibility impaired; cut of >10% → 90-day falsifier on the bull thesis [7].
- **Samsung 9th Pyeongtaek ASU award:** If announced and goes to Air Liquide / Nippon Sanso rather than Linde, contradicts the "incumbency wins" claim.
- **Helium spot price:** A clean reversion to pre-disruption (<$300/Mcf wholesale) within 90 days kills the helium pricing tailwind [11].
- **Air Liquide Q2 2026 (late July):** If electronics growth re-accelerates above Linde's, the Taichung advanced-materials and Japan AI-chip ASU wins are showing up in P&L — competitive parity claim strengthens.
- **A specific contract loss:** Any disclosed loss of a top-25 fab gas contract (rare event; would be material).
- **CHIPS Act / DOC posture change:** Material policy shift on US fab subsidies that delays a confirmed Linde-supplied project (Intel Ohio, TSMC AZ Fab 3+).

## What I could not verify

- Exact electronics segment as % of total revenue (Linde does not break this out cleanly; inferred at ~10–12% from growth contribution and peer disclosures).
- Whether Linde or Air Liquide supplies the specialty gases at TSMC's CoWoS-L packaging-specific lines (the bulk gas is Linde at AZ; the specialty mix is unconfirmed).
- Project IRRs on SOG contracts (industry rule-of-thumb is 10–15% unlevered; not company-disclosed).
- Q1 2026 backlog exact composition between electronics, clean-energy, and conventional; Linde discloses total only.
- Linde's exact share of WF₆ vs Versum/Merck KGaA, SK Materials, and Nippon Sanso at advanced nodes.
- Whether Sanjiv Lamba's Q3 2025 "10% long-term growth" was repeated or walked back on the Q1 2026 call (CFO led the Q1 call, not the CEO) [18][22].

## Sources

[1] https://finance.yahoo.com/quote/LIN/ — retrieved 2026-05-10 — LIN price ($493.16 close 2026-05-08), market cap ~$228B, all-time high $521.28 (May 1, 2026)
[2] https://www.businesswire.com/news/home/20260501117311/en/Linde-Reports-First-Quarter-2026-Results — retrieved 2026-05-10 — Q1 2026 results: $8.78B sales (+8%), EPS $4.33 (+10%), 30% op margin, FY26 EPS guide $17.60–$17.90
[3] https://www.gasworld.com/story/linde-pins-growth-on-tsmc-arizona-ramp-as-helium-outlook-stays-soft/2172488.article/ — retrieved 2026-05-10 — TSMC AZ ramp dependency, helium softness, gas intensity per node
[4] https://www.gurufocus.com/term/forward-pe-ratio/LIN — retrieved 2026-05-10 — forward P/E 28.32×, P/S 6.78–6.90×, EV/EBITDA 17.4×, 52-week range
[5] https://www.marketbeat.com/stocks/NASDAQ/LIN/forecast/ — retrieved 2026-05-10 — consensus 12-month PT median ~$525, range $381–$550, JPM $530, BMO $560
[6] https://stockanalysis.com/stocks/lin/dividend/ and https://www.marketbeat.com/stocks/NASDAQ/LIN/short-interest/ — retrieved 2026-05-10 — YTD +15.65%, 33-yr dividend hike streak, 1.8% short interest, $10B buyback through 2027
[7] https://markets.financialcontent.com/wral/article/tokenring-2026-1-1-the-great-packaging-pivot-how-tsmc-is-doubling-cowos-capacity-to-break-the-ai-supply-bottleneck-through-2026 — retrieved 2026-05-10 — CoWoS scaling 35Kwpm to 130Kwpm by end-2026; CoWoS-L for Blackwell; NVIDIA >60% allocation
[8] https://reports.valuates.com/blogs/helium-demand-semiconductor-euv-chipmaking-supply-chain — retrieved 2026-05-10 — He intensity 1.20× at 2nm vs 3nm, 0.471 m³/wafer; 5× growth by 2035
[9] https://www.airliquide.com/group/press-releases-news/2026-04-28/growth-performance-and-record-investments-air-liquide-continues-its-successful-trajectory-q1-2026 — retrieved 2026-05-10 — Air Liquide Q1 2026 electronics +5.3%; €200M Japan AI gas plants; Taichung advanced-materials plant
[10] https://artificall.com/analysis/companies/comparisons/air-products-and-chemicals-vs-linde/ — retrieved 2026-05-10 — Linde $228B vs APD $63B; competitive positioning
[11] https://theoregongroup.com/commodities/helium/helium-crisis-puts-us-in-control-of-semiconductor-supply-chain/ and https://www.cnbc.com/2026/03/27/russia-helium-supply-crunch-iran-war.html — retrieved 2026-05-10 — Qatar disruption (~⅓ global supply), BLM privatization 2026, spot +50–70%, Russia-China He exports +60% YoY
[12] https://www.fool.com/earnings/call-transcripts/2026/05/01/linde-lin-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q1 2026 transcript: SOG backlog $7.1B, electronics +10%, $1B+ ultra-high-purity capex in flight, ROC 24%
[13] https://www.csis.org/blogs/perspectives-innovation/russias-invasion-ukraine-impacts-gas-markets-critical-chip-production — retrieved 2026-05-10 — Ukraine pre-2022 was 50%+ of high-purity neon; EUV at 13.5nm does not consume neon
[14] https://www.linde.com/news-and-media/2023/linde-to-invest-1-8-billion-to-supply-clean-hydrogen-to-oci-s-world-scale-blue-ammonia-project-in-the-u-s-gulf-coas — retrieved 2026-05-10 — $1.8B OCI Beaumont blue H₂; ~$8B 2023–27 hydrogen capex
[15] https://www.linde.com/news-and-media/2025/linde-to-expand-supply-of-industrial-gases-to-samsung-in-south-korea — retrieved 2026-05-10 — 8th on-site ASU at Samsung Pyeongtaek, mid-2026 start-up, "single largest site for an electronics customer worldwide"
[16] https://www.linde.com/news-and-media/2021/linde-signs-long-term-agreement-to-supply-new-world-class-semiconductor-manufacturing-complex-in-the-u-s — retrieved 2026-05-10 — TSMC Arizona $600M on-site complex; UHP N₂/O₂/Ar
[17] https://assets.linde.com/-/media/celum-connect/2023/12/21/15/11/linde20electronics20brochure185963.pdf — retrieved 2026-05-10 — 100+ specialty gas portfolio: NF₃, WF₆, SiH₄, GeH₄, NH₃, dopants
[18] https://www.insidermonkey.com/blog/linde-plc-nasdaqlin-q1-2026-earnings-call-transcript-1752600/ — retrieved 2026-05-10 — Q1 2026 call detail: 10 SOG starts/$300M, 5 new signings/$100M, "eight-handle backlog" guidance
[21] https://www.tomshardware.com/tech-industry/semiconductors/the-global-helium-shortage-is-a-direct-threat-to-chipmaking — retrieved 2026-05-10 — He criticality across chip processes; DUV vs EUV neon dependence
[22] https://www.gurufocus.com/news/3175772/linde-plc-lin-q3-2025-earnings-call-highlights-strong-eps-growth-amidst-market-challenges — retrieved 2026-05-10 — Lamba's Q3 2025 commentary on 5–7 year electronics growth visibility; 300+ AI use cases internally