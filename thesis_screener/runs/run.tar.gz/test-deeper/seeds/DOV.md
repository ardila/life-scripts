# DOV — Dover Corporation

## Where this sits in the AI stack
DOV is a diversified industrial conglomerate ($8.1B 2025 revenue across five segments, of which only ~12% is AI/power-infrastructure tied [3][4]). Its AI relevance lives almost entirely in two product lines inside the Pumps & Process Solutions segment and the Climate & Sustainability Technologies segment: (i) **Colder Products Company (CPC) liquid-cooling quick-disconnect couplings** — the brass-and-elastomer fluid connectors that join cold-plate manifolds to coolant distribution units (CDUs) inside direct-to-chip liquid-cooled GPU racks (NVL72-class and successors), and (ii) **SWEP brazed-plate heat exchangers (BPHEs)** — the secondary-loop primary heat exchanger that sits inside the CDU, transferring heat from the cleaned facility water loop to the technical coolant loop that touches the chip [1][8][12]. Both are mechanical, not silicon — DOV does not sell anything that runs in the training-loop critical path. Secondary AI exposure is via SIKORA (acquired Q2 2025, €550M) for high-voltage cable / fiber-optic line metrology used in data-center power and connectivity buildout [13], and Dover Precision Components (Waukesha Bearings, Cook Compression) for bearings on gas turbines that are now bottlenecking power for AI campuses [14].

## Snapshot
- **Price:** $227.18 (2026-05-06 close — most recent close I could explicitly source; finviz intraday showed $219.83) [2][7]
- **Market cap:** $30.96B [2]
- **52-week range:** $158.97 – $237.54 [2][7]
- **Forward P/E:** ~21.5× on FY26 guidance midpoint ($10.55 adj. EPS); ~18.9× on FY27 consensus [7][16]
- **EV / NTM revenue:** ~3.8× ($32.5B EV including ~$1.5B net debt; FY26 revenue ~$8.5B at 5–7% growth) [4][17]
- **Consensus 12-month price target:** ~$249 (range $229–$253 across recent JPM/Citi/Oppenheimer raises; implies ~+10% from spot) [16]
- **YTD total return:** +12.6% [7]
- **Short interest (% of float):** 2.27% [7]
- **Dividend yield:** 0.96% [9]

## Moat — what it is physically made of
The honest read: this is a **qualified-vendor moat in a 4–5 player oligopoly**, not a CUDA-class lock-in. The decomposition matters.

**CPC's actual moat in liquid-cooling QDs:**
1. *Spec authorship, not spec ownership.* The OCP **Universal Quick Disconnect (UQD)** spec — the ~$0.4B-and-growing AI-rack QD standard — was co-authored in 2020 by a working group including **CPC, Parker Hannifin, and Stäubli**, with Danfoss/Hansen and Gates also contributing variants [10][11]. The Rev 1.0 UQDB blind-mate spec credits CPC engineers (Dennis Downs, Elizabeth Langer, Barry Nielsen) and Parker engineers as named contributors [11]. CPC was a founding author, but the standard is **deliberately multi-vendor and interchangeable** — that is its value to hyperscalers — so the spec itself does not protect CPC margin. It commoditizes form-factor while preserving fabrication know-how rents.
2. *Qualification economics.* The UQDB Rev 1.0 spec requires **≥5,000 mate/de-mate cycles, drip-free, hot-pluggable** at single-phase water/glycol pressures, with leak-tightness at thermal cycling [11]. NVL72 needs **126 QD pairs per rack** (108 on 18 compute trays + 18 on 9 switch trays) [5]; a hyperscaler campus building 10,000 racks needs ≥1.26M qualified QDs annually with sub-ppm leak-rate budgets. Adding a fifth qualified vendor is months of testing per hyperscaler per chip generation. This sustains the oligopoly but does not exclude the existing oligopolists from each other's accounts.
3. *Manufacturing know-how.* CPC's ~50-year history is in single-use bioprocessing aseptic disconnects — the same fluidic engineering (no-spill valving, low-pressure-drop seals, elastomer chemistry against glycol/PG mixes) transfers directly. CPC claims a portfolio of **~10,000 connector SKUs** built over that history [1][3] — a real cost-to-replicate, but Stäubli (robotic/fluidic disconnects since the 1890s) and Parker (the largest motion-and-control company globally) have comparable capability.
4. *Patents.* CPC holds patents on specific non-spill valve geometries and high-flow seal stacks (the press release for Everis UQD06 specifically calls out "patented technology for high-flow capacity") [1]. These read as feature patents, not platform patents — useful, not exclusionary. *Inference:* the patent moat is narrow and design-aroundable on a 3–5 year horizon, given Stäubli and Parker have demonstrably shipped functionally equivalent UQDB blind-mate connectors [10][20].

**SWEP's moat in BPHEs:** SWEP has been a Dover subsidiary since 1994 and is an established top-3 BPHE supplier alongside Alfa Laval (Sweden) and Kelvion (Germany) [8]. The CDU primary HX is meaningful content (B-range BPHEs from BX4T to B649 plus new B327/B224 launched 2025 specifically for data-center duty [8]) but BPHE is a less differentiated product than aseptic QDs — copper-brazed stainless plate stacks are a mature ~$3B global market with multiple credible suppliers. *Inference:* moat here is scale + lead-time (Tobin: "We don't have to go grab market share on price. We can do it on lead times" [3]), not technology.

**Aggregate honest read:** CPC is one of 4 qualified vendors in a duty cycle that will see 10–50× volume growth. That is a great commercial position, but it is **not a monopoly and not a CUDA**. The right base rate is industrial-fluidics oligopolies (think Sensata in sensors, Watts in flow control), not silicon platforms — pricing power compresses as volumes scale and second-source qualification matures.

## AI buildout bottleneck map
Constraints on the 2026–2028 AI buildout [15][6][14], with DOV's position on each:

| Bottleneck | Severity | DOV position |
|---|---|---|
| Power generation / gas turbines (GE Vernova, Siemens Energy, MHI backlogs ~5 yrs; WoodMac sees 195% turbine price increase by 2027) | **Critical** | **Beneficiary, indirect** — Waukesha Bearings + Cook Compression (DPC) sell into turbomachinery OEMs; pricing on aftermarket parts strong, but DPC is small relative to OEM revenue. |
| HV transmission cable + grid interconnect | High | **Beneficiary** — SIKORA (acq. Q2 2025) sells line-end measurement on HV polymer-insulated cable extruders; capacity-constrained customer base [13]. |
| CoWoS-L advanced packaging (TSMC) | Critical | **Indifferent** — no DOV exposure. |
| HBM3e/HBM4 supply (SK hynix, Samsung, Micron) | Critical | **Indifferent.** |
| Optical interconnect / co-packaged optics | High | **Marginal** — SIKORA measures fiber-optic preforms during draw [13], so DOV touches the optical fiber supply chain but not transceivers. |
| Liquid cooling QDs at >100kW/rack | High and *opening* (current adoption ~17%, going to 76% by end-2026 per Goldman / Hyperion estimates [12][15]) | **Direct beneficiary** — CPC is one of top-4 qualified UQD/UQDB vendors. NVL72 = 126 QD pairs/rack. [5][10] |
| BPHE / CDU primary heat exchangers | Medium | **Direct beneficiary** — SWEP is top-3 globally; lead times extending [3][8]. |
| Electrical contractor / switchgear capacity | High | **Indifferent.** |
| Compiler / kernel talent | High at frontier | **Indifferent.** |

DOV is **never the constraint owner** on any AI bottleneck — there is no item where DOV's capacity is the binding constraint on the system. It is consistently a beneficiary in two cooling adjacencies and indirectly through power infrastructure.

## Competitive teardown
**On UQD/UQDB liquid-cooling connectors (the most important DOV AI revenue line):**

| Competitor | Technical position | Evidence | Honest read |
|---|---|---|---|
| **Stäubli (private, Swiss)** | Co-author of UQD; full UQD/UQDB/Mini-QD product line; press release in 2025 claims **"Stäubli's UQD & UQDB approved by NVIDIA"** [19][10] | Direct NVIDIA-page approval claim; OCP Global Summit lead role; long fluidic-disconnect heritage from robotic tool-changers | **Parity-or-better on flagship Blackwell/Rubin sockets.** I could not independently verify exclusivity vs. CPC, but Stäubli's marketing positioning is more aggressive on the NVIDIA approval narrative than CPC's. |
| **Parker Hannifin (PH, US)** | Co-author of UQD; UQDB blindmate listed on OCP product registry [20]; full Flat Face Hydraulic UQD line | OCP product page documents production qualification | Real competitor with massive scale across motion/control. Parker's broader fluid power business gives cost advantages CPC lacks. |
| **Danfoss / Hansen (DK)** | UQD + FD83 series for thermal management; #2 share globally in some estimates | MarketsandMarkets ranks Danfoss in top-5 alongside Stäubli, Parker, CPC, Gates (top-5 = 63–73% share) [10] | Strong position in EMEA, growing in NA; not as exposed to AI as the front-runners. |
| **CPC (DOV)** | Co-author of UQD; Everis UQD06 (3/8" line, 2025) specifically positioned for "AI's higher-flow requirements" [1] | NVIDIA-acknowledged DCI ecosystem partner [18]; multiple NVIDIA-platform OEM design-ins via PSG channel | **Top-tier but not unique.** Bench-marketing-wise, CPC's bioprocess-disconnect heritage is the differentiator — purity, no-spill valving for liquid-touch in compute. |
| **Gates, CEJN, Cooler Master** | Lower-tier; chasing OCP qualification | Product catalogs only | Volume share rather than mind-share; not a 2026 threat. |

**On BPHE for CDU primaries:** Alfa Laval (publicly listed) is the global #1; Kelvion (private, ex-GEA) is #2; SWEP is #3 — well-positioned but not dominant [8]. CDU integrators (Vertiv, CoolIT, Boyd, Motivair, Schneider) actively dual-source, so SWEP-vs-Alfa Laval is an evergreen split.

**Honest competitor read:** On the single highest-leverage AI line (CPC QDs), **Stäubli is at minimum at parity and may be ahead** on the headline NVIDIA-approval narrative. The bull thesis that DOV is "the" AI liquid-cooling play is overstated — it's "one of three or four" with strong qualifying moat but no exclusivity.

## Bull case — technical
1. **Liquid cooling penetration curve.** Goldman / Hyperion / Tom's Hardware triangulate to: AI-server liquid cooling adoption goes from ~15% (2024) → 54% (2025) → 76% (2026) → ~90% by 2028 [12][15]. NVL72 = 126 QD pairs/rack; Rubin/NVL144 will be similar or higher count. With $725B aggregate hyperscaler 2026 capex (~$450B AI-related) [6], even 0.5% of that flowing into QDs is ~$2B/year, of which CPC capturing 25–30% is $500–600M — a real fraction of P&PS earnings power.
2. **Margin profile holds.** P&PS segment ran **30.3% operating margin in 2025** with $652M segment earnings [4][17]. That margin is structurally consistent with engineering-rich, low-volume / high-mix fluidics (CPC's bioprocess heritage). If this segment grows 8–12% organically over a multi-year ramp, on flat-to-rising margin, the segment alone generates incremental ~$100M operating profit annually — meaningful against $30B market cap.
3. **Rubin transition does not displace CPC.** If Stäubli's NVIDIA approval is for the existing UQD/UQDB form factor (which is the stated multi-vendor OCP standard), CPC, Parker, and Danfoss all remain qualified for Rubin generations — no platform-shift risk.
4. **Power infrastructure tail.** SIKORA + DPC are real, smaller, and benefit from 5+ year gas turbine and HV cable backlogs [14] regardless of which GPU vendor wins.
5. **Falsification base rate.** Industrial fluidic-component oligopolies historically displace slowly: Watts Water, Sensata, Roper-era Neptune. None of the top-5 UQD vendors has been displaced in the 2020–2025 ramp; expect similar inertia through 2027–2028.

**Connection to financials:** Bull case justifies a forward multiple in the **22–24×** range (vs. ~21× now) on $11–12 EPS power if AI-tied revenue compounds 25–30% on a 12% base, dragging consolidated growth to high-single-digits. Implied price ~$255–290 over 18 months.

## Bear case — technical
The version a short-seller who reads the standards documents would write:

1. **The "AI cooling pure-play" framing is a stretch.** $1B of $8.1B revenue (~12%) is AI/power-infra-tied [3][4]. The other 88% is HVACR aftermarket, retail fueling, vehicle service, and marking/coding — businesses that are cyclical industrials at trailing peer multiples of 14–18× and have nothing to do with AI. The forward 21× P/E reflects an AI mix premium that the financials do not yet support.
2. **Stäubli's NVIDIA approval is real and CPC's is murkier.** Stäubli has a dedicated press release titled "Stäubli's UQD & UQDB approved by NVIDIA" [19]; CPC's analogous claim is via a generic NVIDIA-DCI-ecosystem listing alongside ~40 other vendors (Cooler Master, Boyd, AVC, Foxconn, Delta, etc.) [18]. *Inference:* if Rubin-generation hyperscale RFQs concentrate at the explicitly NVIDIA-approved socket, CPC could lose share at the margin in the highest-volume contracts.
3. **Spec is open by design.** OCP UQD/UQDB is hyperscaler-led precisely so that no single vendor captures pricing power. As Microsoft, Meta, and Google scale-up qualified-vendor counts (already 5+ shippable today), gross margin on QDs compresses on the same trajectory we saw for SSDs in hyperscale (2014–2018) and PSUs in the original Open Compute era.
4. **Vertical integration risk.** Microsoft's microfluidic in-chip cooling research [Microsoft 2025] and Meta's open hardware program both demonstrate willingness to design around the supply chain. Hyperscaler-defined connector standards inherently encourage second-source pricing pressure; in the limit, hyperscalers commission custom QDs from contract manufacturers at lower margin than CPC's bioprocess-style pricing.
5. **Architecture risk.** If immersion (Submer, GRC, Iceotope), microfluidic-in-chip, or two-phase direct-to-chip (Accelsius, ZutaCore) takes >25% of the new-AI-rack market by 2028, the QD count per rack drops materially or the entire UQD form-factor is bypassed [12][15]. Microsoft is publicly investing in microfluidic in-chip cooling that could obsolete cold-plate manifolds entirely.
6. **Cyclical air-pocket in the rest of DOV.** Most segments (Engineered Products, Imaging & Identification, Clean Energy & Fueling away from data centers) are tied to industrial PMI, retail fueling station capex, and vehicle aftermarket — all late-cycle exposures. A 2026–2027 industrial recession swamps the AI tailwind in the consolidated number.
7. **Base rate on "AI tailwind" for industrials.** Cisco-era network buildout punished diversified component suppliers as the cycle peaked (2000–2002): Emerson, Hubbell, etc. saw multiple compression even as orders held up briefly. Falsifier: a back-end multiple compression to 16–17× on a soft-landing FY27 EPS of $11.5 implies ~$185 — i.e., back to the 52-week range mid-point.

## Market view check
At ~$227 / ~21× FY26 EPS / ~3.8× EV/sales / ~16.7× EV/EBITDA [7][17], DOV trades at a premium to diversified-industrials peers (Eaton ~25× but more electrification-pure; ITW ~22×; Parker ~22×; Emerson ~20×) but a discount to liquid-cooling pure-plays (Vertiv ~30× FY26). The market appears to be paying for the **direction of mix shift** (AI/power infra rising from 12% to 18–20% over 24 months) rather than the current mix. That is consistent with the 24% Q1 bookings growth, 1.2× book/bill, and 30%+ P&PS margins [3][4]. The price is not screaming mispriced in either direction; it is paying a fair premium for the optionality on CPC + SWEP, while still embedding the broader cycle. Consensus PT ~$249 implies ~10% upside — modest, and asymmetric to the downside if Q3 2026 hyperscaler capex prints disappoint.

## 90-day falsifiers
1. **Q2 2026 earnings (late July 2026):** does management raise the $1B AI/power-infra revenue figure? A raise to $1.2B+ is a confirming event; flat is a soft bear signal.
2. **Hyperscaler Q2/Q3 2026 capex prints (late July / late October):** any sequential cut >10% from Microsoft/Meta/Google/Amazon's $725B aggregate run-rate [6] is a direct hit to NVL72 and Rubin rack volumes.
3. **NVIDIA Rubin / Vera Rubin NVL144 launch and supplier announcement (H2 2026):** if NVIDIA names Stäubli (or any single vendor) explicitly as the reference QD supplier without naming CPC, CPC share is at risk. If multiple vendors are referenced (status quo), CPC retains.
4. **OCP Global Summit (October 2026):** new UQDB rev or any hyperscaler-pushed in-house QD spec is a structural bear event. Stäubli has been more aggressive at OCP than CPC in 2024–2025 [19].
5. **Microsoft microfluidic / immersion announcements:** any production deployment (not just R&D) of a non-cold-plate architecture at material scale (>10% of new builds) materially compresses the QD TAM.
6. **P&PS segment book/bill:** the 1.2× ratio is the cleanest forward signal; below 1.0 in any quarter is the early warning.

## What I could not verify
- **CPC's specific NVIDIA-approved-vendor status for GB200/GB300/Rubin.** Stäubli has an explicit "approved by NVIDIA" press release [19]; CPC's parallel status is implied via an ecosystem listing [18] but I could not find an equivalent direct press release. The CPC-NVIDIA 2024 press PDF rendered as binary and could not be read.
- **CPC unit market share within the UQD market.** Top-5 (Stäubli, Danfoss, Parker, CPC, Gates) collectively hold 63–73% [10]; the within-top-5 split is not publicly disclosed. CPC could be #1 or #4 and the public sources do not resolve it.
- **Specific CPC content per NVL72 rack in dollar terms.** I confirmed 126 QD pairs per NVL72 [5] but ASP per pair (likely $30–$80 depending on size, valving, and chrome plating) and CPC's share of those 126 are not disclosed.
- **CPC operating margin and growth rate as a standalone unit.** P&PS reports 30.3% [4][17] but CPC mix vs. PSG / DPC / MAAG inside that is not broken out.
- **Whether the SIKORA acquisition has closed-loop tracking back to AI-data-center HV cable specifically** vs. utility-grid HV cable broadly.
- **Most recent close (2026-05-08).** Last sourced close is 2026-05-06 at $227.18; finviz quote intraday at $219.83 was simultaneous-not-confirmed-close.

## Sources
[1] https://www.prnewswire.com/news-releases/new-cpc-solution-tackles-growing-liquid-cooling-needs-for-ai-302512115.html — retrieved 2026-05-10 — CPC Everis UQD06 launch, 3/8" flow path, hyperscale AI / HPC positioning.
[2] https://www.morningstar.com/stocks/xnys/dov/quote — retrieved 2026-05-10 — DOV $227.18 close 2026-05-06, $30.96B market cap.
[3] https://www.fool.com/earnings/call-transcripts/2026/04/23/dover-dov-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q1 2026 earnings transcript: $1B AI/power infra revenue target, $2.5B Q1 bookings (+24% YoY), 1.2× book/bill, Tobin's "lead times not price" commentary.
[4] https://www.gurufocus.com/news/8812935/dover-corporation-dov-projects-strong-earnings-growth-driven-by-ai-demand — retrieved 2026-05-10 — $1B AI revenue target = 11.5% of total revenue; segment growth detail.
[5] https://introl.com/blog/gb200-nvl72-deployment-72-gpu-liquid-cooled — retrieved 2026-05-10 — NVL72 = 126 QD pairs/rack (108 compute + 18 switch), 700 LPM manifold flow.
[6] https://www.tomshardware.com/tech-industry/big-tech/big-techs-ai-spending-plans-reach-725-billion — retrieved 2026-05-10 — Hyperscaler 2026 capex $725B aggregate (MSFT $190B, GOOGL $190B, AMZN $200B, META $145B).
[7] https://finviz.com/quote?t=DOV — retrieved 2026-05-10 — DOV intraday $219.83, fwd P/E 18.86, EV/EBITDA 16.69, short float 2.27%, YTD +12.59%, 52w $158.97–$237.54.
[8] https://www.swepgroup.com/applications/data-center/data-center-cooling/cdu — retrieved 2026-05-10 — SWEP B-range BPHE for CDU primary HX, B327/B224 launched 2025; SWEP a Dover sub since 1994.
[9] https://www.dividend.com/stocks/industrials/machinery/flow-control-equipment/dov-dover-corp/ — retrieved 2026-05-10 — DOV dividend yield 0.96%, $0.515 quarterly declared 2026-05-08.
[10] https://www.marketsandmarkets.com/ResearchInsight/uqd-coupling-companies.asp — retrieved 2026-05-10 — Top-5 UQD vendors (Stäubli, Danfoss, Parker, CPC, Gates) hold 63–73% share; UQD spec co-authored 2020 by Stäubli/Parker/CPC.
[11] https://www.opencompute.org/documents/uqdb-spec-1-0-pdf — referenced via OCP search result 2026-05-10 — UQDB Rev 1.0 spec: 5,000 mate-cycle requirement, hand-mate drip-free hot-pluggable, CPC + Parker engineers as named contributors. (Direct fetch returned 403; cited from search snippets.)
[12] https://insidehpc.com/2025/09/cpc-and-the-critical-role-of-the-connector-in-the-liquid-cooled-ai-data-center/ — retrieved 2026-05-10 — Hyperion: liquid cooling adoption ~67% → ~80% in 12–18 months in HPC/AI sites. (Direct fetch was 503; cited from search excerpt.)
[13] https://investors.dovercorporation.com/news-releases/news-release-details/dover-acquire-sikora-leading-provider-measuring-and-control — retrieved 2026-05-10 — SIKORA acquisition €550M, closed Q2 2025, fiber/HV cable line metrology under MAAG.
[14] https://www.utilitydive.com/news/gas-turbine-supply-crunch-set-to-raise-prices-195-by-2027-woodmac/816904/ — retrieved 2026-05-10 — Gas turbine prices +195% by 2027 per WoodMac; OEM backlogs ~5 years; relevant to DPC bearing aftermarket.
[15] https://www.lombardodier.com/insights/2026/january/ai-supercharges-the-race.html — retrieved 2026-05-10 — Goldman trajectory: liquid-cooled AI server share 15%→54%→76% (2024→2025→2026).
[16] https://www.tickerreport.com/banking-finance/13415840/dover-nysedov-updates-fy-2026-earnings-guidance.html — retrieved 2026-05-10 — DOV FY26 adj. EPS guide $10.45–$10.65; JPM $240, Citi $253, Oppenheimer $242 PTs.
[17] https://www.panabee.com/news/dover-earnings-2025-annual — retrieved 2026-05-10 — P&PS segment 30.3% operating margin; $2.1B segment revenue, $652M segment earnings; net debt ~$1.5B.
[18] https://www.nvidia.com/en-us/data-center/gb200-nvl72/ (via search excerpts) — retrieved 2026-05-10 — CPC listed in NVIDIA's >40 DCI ecosystem partners building on Blackwell platform; non-exclusive listing.
[19] https://www.staubli.com/us/en/news/global/2025/uqd-staubli-nvidia-approved.html (via search title) — retrieved 2026-05-10 — Stäubli explicit "UQD & UQDB approved by NVIDIA" announcement; direct page fetch returned 403 — claim verified only via search-result title and PR amplification at OCP 2025.
[20] https://www.opencompute.org/products/444/parker-uqdb-series-universal-quick-disconnect-blindmate-couplings — retrieved 2026-05-10 — Parker UQDB on OCP product registry, confirms parity competitor.