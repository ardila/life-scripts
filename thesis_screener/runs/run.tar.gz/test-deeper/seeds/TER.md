Now I have enough technical depth to write the dossier. Let me draft it.

# TER — Teradyne, Inc.

## Where this sits in the AI stack

Teradyne sells the **automated test equipment (ATE)** and test programs used at wafer sort and final test to weed out defective silicon before it leaves the fab/OSAT. In the AI stack, TER's exposure is concentrated in two places: (a) **SoC test** of AI accelerators — GPUs, custom hyperscaler ASICs (TPU, Trainium, MTIA, Maia), and high-speed networking SerDes — via the **UltraFLEXplus** platform, and (b) **memory test** of HBM3E/HBM4 stacks at SK Hynix/Micron/Samsung via the **Magnum 7H** platform. A growing third leg is **silicon photonics / co-packaged optics (CPO)** test via the Photon 100, which sits at the wafer-probe insertion before SiPh dies are integrated into pluggable optics or CPO modules.[1][2][3] A separate Robotics segment (Universal Robots cobots, MiR mobile robots) is ~7% of revenue and is essentially a side bet, not the AI thesis.[4]

## Snapshot

- **Price:** $359.77 (2026-05-08 close)[5]
- **Market cap:** ~$56.3B[5]
- **52-week range:** $75.99 – $422.11 (high set 2026-04-24)[6]
- **Forward P/E:** ~36× on the long-term target model ($9.50–$11 non-GAAP EPS); on more conservative FY26 consensus run-rate (~$8–$9 implied by H1 EPS of ~$4.56 and stated H1 weighting of 55–60% of revenue) the multiple is ~40–45×.[7][8] Trailing P/E ~66×.[5]
- **EV / NTM revenue:** ~11–13× (EV ≈ market cap; net cash modest. NTM revenue ~$4.3–$5.0B based on Q1 actual $1.28B + Q2 guide midpoint $1.20B + H2 ramp).[7]
- **Consensus 12-month price target:** $263.33 (implies ~−27% from price) — but the range spans $105 (Cantor, dated June 2025) to $440 (UBS, April 2026). The mean is stale and almost certainly downward-biased by pre-AI-rerate analyst targets.[9]
- **YTD total return:** +70.6%[6]
- **Short interest (% of float):** ~3.3% (5.2M shares, most recent reading)[10]

## Moat — what it is physically made of

The TER moat is best analyzed as four separate stacks, each with very different durability:

**1. UltraFLEXplus SoC test platform + IG-XL test software.** The platform itself is silicon-and-instrumentation IP — channel cards, pin electronics, DC power instruments, parametric measurement units, high-speed digital scan, and increasingly thermal/coolant management to handle 700–1,200W test envelopes.[11][12] The harder-to-replicate moat is the **test program ecosystem** built on IG-XL: customers like Apple have written hundreds of person-years of proprietary test code targeting UltraFLEX, and a port to Advantest's V93000 is typically a **6–18 month engineering effort** per device family.[12] Replication cost for a true new entrant: 5–10 years and arguably impossible without a hyperscaler bankrolling silicon-up. Durability: high (10+ years) at incumbent customers; medium at the architectural transition (chiplet/3D KGD) where ports of test programs are an option.

**2. Magnum 7H memory tester for HBM.** Specifically targets HBM3E/HBM4 at speeds up to 4.5 Gbps with 9,216 digital pins and 2,560 power pins, claimed 1.6× throughput vs. predecessor.[3] This product is materially newer than Advantest's T5503HS3 / T5835 family, and TER has called out share gains in HBM and DRAM final test through 2025.[7][13] Durability: medium — memory test traditionally rotates among Advantest, TER, and in-house solutions every 1–2 HBM generations, and Samsung/Micron/SKH actively dual-source. HBM4 ramp 2026–2028 is the contest.

**3. Customer relationships and qualified install bases.** Two "specifying customers" and one "purchasing customer" each contributed >10% of Q1 2026 revenue.[7] The specifying customers are almost certainly Apple (UltraFLEX has been the standard there for ~15 years) plus a major hyperscaler ASIC program; the purchasing customer is likely an OSAT (ASE/Amkor/PTI).[14] Apple is structurally locked in via test programs. Hyperscaler ASICs are less locked because Broadcom and Marvell (who design many of them on behalf of Google/Meta/Microsoft) typically default to Advantest's V93000.

**4. Photon 100 silicon-photonics test platform.** Genuinely differentiated: TER has fielded **double-sided wafer probe** capability (optical from top, electrical from bottom or vice versa) integrated into the UltraFLEXplus chassis, which is needed for SiPh die that have grating couplers on one side.[15][16] Management characterizes the CPO race as "quite balanced" with Advantest.[7] Durability: unknown yet — CPO is pre-volume, and the test architecture standard is unsettled.

What is **not** a deep moat: the test handlers (often Cohu's), the prober (FormFactor, MPI, Tokyo Electron), and the loadboards (multi-source).

## AI buildout bottleneck map

Constraint-by-constraint, with TER's position:

- **CoWoS-L advanced packaging (TSMC).** Oversubscribed through 2026; Nvidia reportedly booked ~60% of CY26 advanced-packaging capacity (~595k wafers, of which ~510k CoWoS-L).[17] TER is a **derivative beneficiary**: more CoWoS-L wafers → more packaged Blackwell/Rubin/MI-series → more SoC test time. TER does not gate this.
- **HBM3E/HBM4 supply.** HBM3E 8-hi/12-hi fully allocated 2026; HBM4 ramping late 2026.[17] TER is a **direct beneficiary** via Magnum 7H share, since each HBM generation increases test time per stack and KGSD requirements.[12]
- **N2/N3 wafer capacity.** Fully booked into 2028.[17] Indirect for TER — wafer availability sets the ceiling on test demand.
- **Liquid-cooled handlers at >2kW per device.** Cohu, Advantest's in-house handler effort, and others compete here. TER specifies but does not own this layer.
- **AI accelerator test time.** Mobile SoCs test in 30–60 s; Blackwell-class accelerators consume >20 min on the same machine, an order-of-magnitude expansion driven by 814mm² reticle-limit dies, chiplet KGD, multi-die thermal, and HBM stack co-test.[12] This is **the** structural driver of TER demand — test capacity becomes a bottleneck **for the AI buildout itself** if accelerator volumes rise faster than tester install base, which is plausible through 2027.
- **Power/grid.** Indifferent to TER directly; affects end-customer capex pacing.
- **Optical interconnect / CPO supply.** TER is a beneficiary via Photon 100; CPO is a 2027+ story.
- **Engineering talent (test program development).** Probably the most under-discussed gate. AI accelerators with hundreds of distinct IP blocks need correspondingly large test program teams. TER's IG-XL ecosystem (decades of customer-side engineering investment) is a quiet moat against re-tooling on rival platforms.

## Competitive teardown

**Advantest (TYO:6857, ATEYY).** The dominant SoC tester for merchant AI accelerators. V93000 EXA Scale with Pin Scale 5000 (5 Gbit/s scan) is qualified at Nvidia, AMD, Broadcom (Google TPU), and Marvell (Meta MTIA / Microsoft Maia).[18][19] Advantest's SoC tester share went from 56% → 66% in CY25, driven entirely by AI accelerator concentration.[18] This is the single most important fact in the competitive picture: **at the highest-volume node of AI compute today (Nvidia merchant GPU), Advantest is the incumbent and TER is just now qualifying as a second source**, with TER's first multi-system production order received in Q1 2026 and ramp described as low-single-digit % in 2026 escalating to "30–70% range over midterm."[7] On memory test, Advantest is also incumbent but TER has been pulling share with Magnum 7H. **Net read:** Advantest already has parity-or-better at the highest-margin AI workload; TER's growth is share recapture from a recent trough, not new moat creation in SoC.

**Cohu (COHU).** Handlers and thermal/contactor. Competes downstream of the ATE platform decision, not really on the same axis. Pressures total cost of test but not TER's revenue line in any direct way.

**In-house and emerging.** Samsung and SK Hynix have internal memory test programs. China's domestic ATE (Hwatsing, Accotest) is gaining at trailing-edge and consumer memory but not at HBM/AI accelerators. Not a 24-month threat at the frontier; a 5-year watch item.

**The honest read on each axis:**

| Axis | Incumbent | Evidence | TER realistic path |
|---|---|---|---|
| Merchant GPU SoC test (Nvidia) | Advantest | 66% share, qualified at Nvidia[18] | New second-source qualification, ramp 2026–2028[7] |
| Custom hyperscaler ASIC SoC | Advantest (when via Broadcom/Marvell); TER (when designed in-house by Apple/Tesla) | Mixed[20] | Defend Apple-style accounts; chase TPU/MTIA/Maia is harder |
| HBM final test | Contested; TER gaining | Q1 2026 memory +61% QoQ[7] | Magnum 7H positioned for HBM4 cycle |
| SiPh/CPO | Tied | TER and Advantest "balanced"[7] | Architectural land grab; outcome 2027+ |
| Mobile / non-AI compute | TER (UltraFLEX) | Apple anchor | Mature, low-growth |

## Bull case — technical

For the stock to outperform from a ~$56B market cap and ~11× EV/NTM rev, the following technical conditions must hold:

1. **AI accelerator test-time scaling continues to outpace tester throughput improvements.** As Blackwell → Rubin → next-gen dies grow (>2 reticles, 12-Hi HBM4E, in-package CPO), per-unit test time stays north of 20 minutes and likely climbs.[12] This is a near-certainty by physics; reticle stitching, chiplet KGD, and HBM stack co-test all add test patterns roughly multiplicatively.
2. **TER's merchant GPU qualification converts to mid-teens share by 2028.** Management's own framing — "low double-digit share" is needed to hit the $6B target — gives the magnitude.[7] Base rate: second-source qualifications in ATE at this scale historically convert (e.g., Advantest's win at Apple displaced TER over ~5 years 2010–2015) but rarely above 30–40%. Hitting 15% by 2028 is plausible.
3. **HBM4 ramp pulls Magnum 7H share to ~40%+ at one of the three HBM vendors.** TER must hold or extend its HBM gains as HBM4 12-Hi and HBM4E 16-Hi qualify in 2026–2027.[3][17]
4. **CoWoS-L and HBM stay constrained.** Counter-intuitively this is bullish for TER: if CoWoS gates volume, every packaged unit gets full test attention; if CoWoS opens up, volume floods test capacity.
5. **Photon 100 captures meaningful CPO share before Advantest fields a true equivalent.** CPO is a 2027+ revenue story but a 2026 architectural lock-in.

If all five hold, the long-term target model ($6B revenue, ~$10 EPS midpoint) is achievable by 2028 and the stock can sustain a 30–35× multiple, supporting ~$300–$350/share at the consensus exit. Upside above current price requires either earlier achievement or a higher multiple than that — which gets harder.

**Base rate on technology displacement at this stage of the cycle:** The Advantest/TER duopoly has been remarkably stable for 20+ years. Share at the leader has oscillated between 50% and 66% but the floor for the #2 has held around 30%.[14][18] That base rate cuts both ways — it's hard for TER to break out, and hard for it to collapse.

## Bear case — technical

The version a short-seller who understands ATE would write:

1. **TER is currently a share-recapture story dressed as an AI growth story.** Advantest sits inside Nvidia, AMD, Broadcom, and Marvell production lines today.[18] TER's first merchant GPU production order shipped in Q2 2026 — a ramp from zero, against an incumbent who is also building capacity for the same demand. The 70% YTD move bakes in best-case execution of the qual.
2. **Apple is plateauing as a growth driver.** UltraFLEX revenue from mobile is mature; the AI-driven SoC growth is the new compute mix, and that's where TER is the **smaller** incumbent.[12][14]
3. **Customer concentration is brutal and discretionary.** Three customers >10% means a single Apple inventory correction, Nvidia roadmap slip, or hyperscaler ASIC delay can move quarterly revenue 15–25%. The Q1 2026 print + Q2 guide already produced a >19% single-day stock drop on what was a "beat" — pointing to a tape that is now positioned for perfection.[7][21]
4. **Multiple compression risk is real.** EV/NTM revenue of ~11–13× is in the 95th percentile of TER's history (long-run band 3–6×). If AI capex growth normalizes to "still strong but no longer accelerating" — a credible 2027 base case — the multiple is the first thing to give. A re-rate to 7–8× EV/NTM rev at the same revenue gives roughly 40% downside.
5. **Advantest can defend.** Pin Scale 5000 and EXA Scale already scale to 5 Gbit/s scan and exascale digital workloads; Advantest is not asleep at the wheel and has been investing aggressively in HBM4 test and CPO.[18][19] Parity scenarios at TER's growth segments deny TER the share it needs.
6. **Robotics is not the second leg the bull case implies.** Universal Robots + MiR at ~$91M/qtr is a $360M run-rate inside a $56B market cap. The Nvidia AI accelerator toolkit collaboration is genuine but the segment has been flat-to-down for several years and is well below its 2022 peak.[4]

**Bear summary:** TER is real, the technical content is real, but the price already reflects a flawless cross-qualification at Nvidia, sustained share gains in HBM through HBM4, and a 30%+ test TAM expansion. A miss on any one of those — especially the GPU qual — re-rates the name severely.

## Market view check

At $359.77 and ~11–13× EV/NTM revenue, TER trades at a ~3× premium to its long-run band and at a richer multiple than any pure-test-equipment peer except Advantest. The market is pricing in the bull case: that the Nvidia second-source qual is real and ramps, that HBM share gains stick into HBM4, and that the test-time scaling math protects against any AI capex pause. The consensus 12-month PT of $263 is almost certainly stale (it includes targets from before the Q4 2025 narrative shift), and the more current UBS $440 high target is closer to the actively-priced bull case. **My read:** the technical thesis is right but mostly in the price. The asymmetry has shifted from "underappreciated AI test exposure" (the 2024–2025 trade) to "priced for flawless execution against a stronger incumbent" (the current setup).

## 90-day falsifiers

Concrete, datable events through ~early August 2026:

- **Q2 2026 print (July 28, 2026):** SoC revenue must show sequential growth from $647M, with management confirming **first merchant GPU production revenue** in the $20–50M range. A flat or declining SoC line, or any pushout of the GPU ramp, breaks the thesis.[7]
- **Q2 EPS:** Must hit or beat the $1.86–$2.15 guide midpoint. A miss on a beat-and-raise tape would be telling.
- **Advantest fiscal-quarter results (late July 2026):** If Advantest's SoC segment grows faster than TER's, the share-recapture thesis is in trouble.
- **Hyperscaler capex commentary (MSFT/GOOG/META/AMZN earnings, late July):** Any sequential capex guide cut >10% materially compresses the test TAM math.
- **TSMC monthly revenue (June/July reports):** A sustained slowdown in advanced-node revenue is a leading indicator for ATE bookings ~2 quarters out.
- **HBM4 qualification milestones (SK Hynix volume announcement, expected Q3 2026):** Delays push Magnum 7H revenue out and benefit Advantest, who can sell qual-extension on incumbent platforms.
- **Disclosed customer wins/losses on second-source quals:** TER on Nvidia or AMD merchant-line additions; conversely, Advantest qualifying on TPU v8 / Trainium 3 / Maia 200 final test would be incremental Advantest wins.

## What I could not verify

- The identity of the "merchant GPU customer" for TER's first production win. Press coverage strongly implies Nvidia, and UBS frames it that way, but TER has not named the customer.[22]
- Per-system ASP for UltraFLEXplus and Magnum 7H, and therefore unit economics by platform. Publicly cited figures range $1–4M per system; I could not pin a current ASP.
- Exact Advantest vs. TER share at each individual hyperscaler ASIC (TPU v7/v8, Trainium 2/3, MTIA, Maia 200). Sources conflict — one credible analysis claims TER ~50% of "non-GPU AI ASIC designs"[23] while another places Advantest at "the merchant ASIC supply chain (Broadcom-Google, Marvell-Meta/Microsoft)."[18] The likely reconciliation is whether the ASIC is fabless-designed-internally (e.g., Apple, Tesla — TER favored) vs. routed via Broadcom/Marvell (Advantest favored), but I could not confirm the per-program split.
- Q1 2026 borrow rate and current dollar-weighted short interest (most recent confirmed reading is mid-Q1).[10]
- Whether TER's ~$50M robotics QoQ ramp is durable or front-loaded by the disclosed global-logistics "plan of record" deal.[4]
- Specific test-time figures for Blackwell B100/B200 vs. Hopper H100/H200 — the >20 min figure is widely cited but I have not seen a verified vendor disclosure.[12]

## Sources

[1] https://www.teradyne.com/products/ultraflexplus/ — retrieved 2026-05-10 — UltraFLEXplus product page; platform specs and AI compute positioning.
[2] https://www.teradyne.com/products/magnum-7h/ — retrieved 2026-05-10 — Magnum 7H product page; HBM tester capability claims.
[3] https://investors.teradyne.com/news-events/press-releases/detail/419/teradyne-unveils-magnum-7h---the-next-generation-memory-tester-for-high-bandwidth-memory-devices — retrieved 2026-05-10 — Magnum 7H launch PR with HBM4 4.5 Gbps / 9,216 pin specs.
[4] https://www.therobotreport.com/teradyne-robotics-revenue-rises-start-2026/ — retrieved 2026-05-10 — Q1 2026 robotics $91M, +32% YoY, four consecutive quarters of growth.
[5] https://meyka.com/blog/ter-stock-closes-up-16-on-may-8-2026-as-ai-demand-accelerates-0905/ — retrieved 2026-05-10 — TER 5/8/26 close $359.77, market cap $56.3B, P/E 66.6.
[6] https://www.tikr.com/blog/teradyne-stock-is-up-400-and-analysts-are-still-calling-for-more-upside-in-2026 — retrieved 2026-05-10 — 52-week range, YTD return, 2026 EPS context.
[7] https://www.fool.com/earnings/call-transcripts/2026/04/29/teradyne-ter-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1 2026 earnings transcript; AI=70% of revenue, merchant GPU win, customer concentration, $6B target model, Q2 guide.
[8] https://www.investing.com/news/company-news/teradyne-q4-2025-slides-ai-drives-44-revenue-growth-company-unveils-6b-target-model-93CH-4482270 — retrieved 2026-05-10 — Q4 2025 target model: $12–14B ATE TAM, $6B revenue, $9.50–$11 EPS.
[9] https://public.com/stocks/ter/forecast-price-target — retrieved 2026-05-10 — Consensus PT $263.33, UBS high $440, range bracket.
[10] https://www.marketbeat.com/stocks/NASDAQ/TER/short-interest/ — retrieved 2026-05-10 — Short interest 5.2M shares, ~3.3% of float.
[11] https://www.teradyne.com/2026/05/04/the-ai-server-challenge-testing-power-at-scale/ — retrieved 2026-05-10 — UltraFLEXplus high-current testing capability for AI server power.
[12] https://www.datagravity.dev/p/the-chip-testing-bottleneck — retrieved 2026-05-10 — Test time scaling, switching cost, duopoly mechanics, Blackwell test time figures.
[13] https://www.stocktitan.net/sec-filings/TER/10-k-teradyne-inc-files-annual-report-0f7699f4f250.html — retrieved 2026-05-10 — 10-K commentary on HBM/DRAM final test share gains.
[14] https://seekingalpha.com/article/4837312-advantest-teradyne-market-share-shifts-in-this-duopoly — retrieved 2026-05-10 — Duopoly history, Apple anchor at TER, Advantest at frontier AI accelerators.
[15] https://investors.teradyne.com/news-events/press-releases/detail/9/teradyne-announces-production-system-for-double-sided-wafer-probe-test-for-silicon-photonics — retrieved 2026-05-10 — Double-sided wafer probe production system for SiPh.
[16] https://investors.teradyne.com/news-events/press-releases/detail/436/teradyne-introduces-photon-100 — retrieved 2026-05-10 — Photon 100 platform launch for SiPh and CPO.
[17] https://info.fusionww.com/blog/inside-the-ai-bottleneck-cowos-hbm-and-2-3nm-capacity-constraints-through-2027 — retrieved 2026-05-10 — CoWoS-L, HBM3E/HBM4, N2/N3 allocation through 2026.
[18] https://tspasemiconductor.substack.com/p/advantest-leading-the-ai-testing — retrieved 2026-05-10 — Advantest SoC share 56%→66%, qualified at Nvidia/AMD/Broadcom/Marvell.
[19] https://www.advantest.com/products/soc/v93000/exa.html — retrieved 2026-05-10 — V93000 EXA Scale architecture, Pin Scale 5000, Xtreme Link.
[20] https://markets.financialcontent.com/stocks/article/finterra-2026-3-31-the-gatekeeper-of-silicon-and-steel-a-deep-dive-into-teradyne-ter-in-2026 — retrieved 2026-05-10 — TER VIP share commentary, AI ASIC positioning.
[21] https://www.tikr.com/blog/teradyne-falls-19-after-record-q1-2026-earnings-was-that-a-buying-opportunity — retrieved 2026-05-10 — Post-Q1 19% drawdown context.
[22] https://www.indexbox.io/blog/teradynes-potential-turnaround-nvidia-deal-could-boost-revenue/ — retrieved 2026-05-10 — UBS/Nvidia second-source thesis, revenue sensitivity.
[23] https://markets.financialcontent.com/stocks/article/finterra-2026-4-9-the-brains-and-the-limbs-a-deep-dive-into-teradynes-ter-ai-driven-ascent — retrieved 2026-05-10 — Claim of ~50% TER share in non-GPU AI ASIC designs.