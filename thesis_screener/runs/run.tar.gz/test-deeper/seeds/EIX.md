# EIX — Edison International

## Where this sits in the AI stack
EIX is the holding company for Southern California Edison (SCE), a regulated electric T&D utility serving ~5M customer accounts across coastal and inland Southern California [1]. In AI-stack terms it sits at the **power generation interconnect and distribution layer** — but it is not a frontline AI buildout name. SCE's territory contains essentially no operational transmission-connected hyperscale data centers; its disclosed data-center request queue is ~4.8 GW pre-operational, of which only ~100 MW has a firm 2025 in-service date and ~867 MW is unassigned [2]. The investable thesis is therefore **California regulated rate-base compounder with embedded wildfire option**, not "AI utility." Anyone framing EIX as a hyperscale power play is conflating it with Dominion (D), AEP, or Vistra (VST), all of which have ~5–10× the contracted hyperscale exposure [3].

## Snapshot
- **Price:** $68.95 (2026-05-08 close) [4]
- **Market cap:** $26.5B [4]
- **52-week range:** $47.73 – $76.22 [5]
- **Forward P/E:** 11.2× (on FY26 consensus EPS $6.18; company guide $5.90–$6.20) [4][6]
- **EV / NTM revenue:** ~3.4× (EV $68.2B; TTM revenue $19.3B; rev growth low single digits) [7] — multiple is dominated by long-duration regulated rate base, not revenue
- **Consensus 12-month price target:** $75.15 / Hold (21 analysts; range $54–$86) — implied +9% from spot [6]
- **YTD total return:** approx. +18% as of late March 2026; latest May read not separately disclosed in primary sources, so treat with caution [8]
- **Short interest (% of float):** 2.85%–3.50% (sources disagree; both figures imply low-conviction short) [4][6]
- **Dividend yield:** 5.1% (quarterly $0.88, 22 consecutive years of growth) [8]

## Moat — what it is physically made of
EIX's moat is **regulatory and topological**, not technological. There is no CUDA-equivalent. Decomposed:

1. **State-granted exclusive distribution franchise** in ~50,000 sq mi of central, coastal, and southern California (excluding LADWP, SDG&E, and CCAs' generation procurement) [1]. Durable until the legislature changes the franchise model — base rate for franchise revocation is functionally zero in living memory.
2. **Physical T&D topology**: ~16,500 circuit miles of transmission, ~108,000 miles of distribution, including the high-voltage corridors into the LA Basin and Inland Empire [1]. Replication cost is prohibitive; CEQA + permitting timelines for new transmission corridors run 7–12 years in California (inference based on CAISO transmission planning cycle and recent Imperial Valley projects).
3. **AB 1054 / SB 254 wildfire fund participation**, conditioned on annual safety certification from OEIS [9][10]. This is a *defensive* moat — without it, SCE would face uncapped inverse-condemnation liability and would be functionally uninsurable. SB 254 (signed September 19, 2025) caps SCE shareholder liability at **20% of SCE's T&D equity rate base** per ignition event, indexed to year of ignition rather than year of disallowance — a material reduction in tail risk [10].
4. **CPUC-approved 2025 GRC revenue requirement** of $9.756B for 2025 (up 13.7% over 2024 base) and $41.78B aggregate for 2025–2028, with annual CPI escalators capped at 5% [11]. CPUC awarded $4.39B less than SCE requested — informative on regulatory posture: constructive but not generous.
5. **Capital plan**: $38–41B SCE capex 2026–2030, supporting ~7% rate-base CAGR and 5–7% core EPS CAGR through 2030 [12][13]. ~30% of this is wildfire mitigation and grid hardening — i.e., the "moat" itself is a regulated capex program where shareholders earn authorized ROE (~10.5% on equity) on every dollar spent.

What this moat is **not**: it is not a knowledge moat, a software ecosystem, or a manufacturing scale advantage. The "switching cost" is geographic — customers can't switch utilities, but neither can hyperscalers easily *choose* EIX over a Loudoun County or Abilene site. The regulatory monopoly cuts both ways: load growth opportunity is bounded by CPUC affordability politics and CCA migration of load.

## AI buildout bottleneck map
The actual gating constraints for the next 24 months and where EIX sits:

| Bottleneck | Status | EIX exposure |
|---|---|---|
| Power generation (gas turbines, nuclear, geothermal) | GE Vernova / Siemens HD turbine backlogs reportedly 2028+ for new utility-scale orders [14] | **Minor beneficiary**: SCE has a 320 MW Fervo geothermal PPA but is generation-light vs. peers; most generation served by IPPs and CAISO market [15] |
| Transmission interconnect queue | CAISO queue >300 GW, multi-year clearance times [16] | **Constraint owner**: SCE owns transmission into Inland Empire; capacity is the gating factor for the 4.8 GW DC queue [2] |
| Advanced packaging (TSMC CoWoS-L) | Allocation-constrained through 2026 [17] | Indifferent |
| HBM3e/HBM4 supply | SK Hynix/Samsung/Micron supply tight | Indifferent |
| Optical interconnect / co-packaged optics | Volume ramp 2026–2027 | Indifferent |
| Liquid cooling at >100kW/rack | Vertiv/Schneider booked through 2026 | Indifferent |
| Electrical contractor / IBEW labor | Acute in Virginia, Texas, Ohio | **Modestly exposed** — California IBEW capacity is consumed by wildfire mitigation and EV charger build; ratepayer-funded |
| Kernel/compiler/CUDA talent | Acute | Indifferent |
| Frontier training data | Acute | Indifferent |

EIX is meaningfully exposed to **only one** AI bottleneck — transmission interconnect in the Inland Empire — and even there the queue economics route most upside to the developer/customer (via grid upgrades funded through CIAC and CAISO TPP), not to EIX shareholders, because CPUC has signaled it will socialize transmission costs only where they pass cost-causation tests [18]. The $1.4B CAISO-approved Silicon Valley transmission upgrade for South Bay data centers is in PG&E territory, not SCE [16]. **The "data centers will save EIX" narrative is weak relative to peers.**

## Competitive teardown
EIX competes on three relevant axes:

**1. Capital deployment alternatives within California IOUs.** PG&E (PCG) and Sempra (SRE/SDG&E) compete for CPUC-approved capex. PG&E has the South Bay data center build (2.5 GW, $2B+ transmission [18]) — i.e., PG&E captures more direct AI-load rate base than SCE in the 2026–2030 window. Sempra has the strongest gas-LDC and Texas (Oncor) growth profile. **On data-center-driven rate base, SCE ranks third of three California IOUs.**

**2. National "AI utility" comparable set.** On contracted hyperscale capacity:
- Dominion (D): ~51 GW contracted as of March 2026, 9.8 GW take-or-pay [3]
- AEP: ~20 GW customer commitments through 2030 [3]
- NextEra (NEE): targeting 15–30 GW DC hubs by 2035 [3]
- Vistra (VST): 3.8 GW 20-year PPAs [3]
- SCE: ~5 GW request queue, mostly speculative, ~100 MW with firm 2025 dates [2]

EIX has roughly **one-tenth** the contracted hyperscale exposure of Dominion, on a smaller market cap but with materially more wildfire risk. If the trade is "buy regulated power because of AI," D, AEP, NEE all dominate EIX on the technical merits.

**3. Wildfire risk-adjusted comparables.** PG&E (PCG) is the obvious analogue. Post-SB 254, both companies share the same liability cap mechanic (20% of T&D equity rate base) and the same fund. PCG trades at ~13× forward (vs. EIX 11.2×), and has materially more data-center load growth in the South Bay. The valuation gap is the market pricing residual Eaton Fire exposure into EIX [19]. Whether this gap is wide or tight depends on the prudency outcome.

## Bull case — technical
The bull case requires four conditions to hold simultaneously:

1. **SB 254 holds up under first stress test.** The Eaton Fire prudency proceeding (subrogation trial scheduled January 2027) results in either a fully prudent finding or a partial finding that keeps SCE's reimbursement obligation to the fund well below the 20%-of-equity-rate-base cap [20]. Base rate on California utility prudency findings under AB 1054 is limited (small sample), but PG&E's post-2019 wildfire findings have generally tracked toward partial-prudent outcomes. SCE's pre-Eaton wildfire mitigation record (PSPS, covered conductor, weather stations) is materially better than PG&E's pre-2019 record.
2. **Rate base compounds at 7%+ as guided.** This requires CPUC continuing to authorize wildfire mitigation capex (~$12B over two years [13]) and AMI 2.0 ($3.1B [21]) at returns near 10.3% authorized ROE. Affordability politics are the threat — California average residential rates are now $0.34–$0.40/kWh, ~3× the national average.
3. **Securitization of $2.9B SCE wildfire mitigation under SB 254 lowers ratepayer impact** without diluting equity returns [10]. This is a financial-engineering tailwind specific to the post-SB 254 regime.
4. **Inland Empire data-center queue converts at >50%.** Even partial conversion of the 5 GW queue [2] adds modest rate base via interconnect upgrades and demand-related distribution capex over 5+ years.

If all four hold, you get 5–7% EPS CAGR + 5% dividend + ~2 turns of multiple expansion (from ~11× to ~13×, closing the gap to PCG) → ~12–18% annualized total return for 2–3 years.

**Base rate on platform displacement for regulated utilities**: effectively zero in modern US history outside of bankruptcy reorganization (PG&E 2001, 2019). The risk to EIX is not displacement, it is *rate base impairment* via wildfire prudency disallowance or affordability-driven CPUC capex denial.

## Bear case — technical
Symmetric and credible:

1. **Eaton Fire prudency goes badly.** Pizarro has already conceded SCE equipment "likely could have been associated with" ignition [19]. Analyst tail estimates of total exposure run to $13.5B [19]. Under SB 254, SCE's per-event shareholder cap is 20% of T&D equity rate base — call this ~$4–5B based on current rate base composition (inference; SCE has not published the exact cap calculation publicly). A finding of imprudence at or near the cap is a 15–20% equity hit before any multiple compression.
2. **Wildfire fund replenishment dilutes shareholders.** SB 254 explicitly authorizes the fund administrator to require up to $3.9B in additional payments from participating IOUs, plus an $18B continuation account [10]. SCE's share of any top-up is approximately 33% (per AB 1054 historical allocation). A second major fire in 2026–2027 — base rate on California major utility-ignited fires is roughly one every 2–3 years over the past decade — could trigger this.
3. **Affordability political ceiling.** Average residential rates are already politically contentious. If CPUC begins disallowing capex on affordability grounds, the 7% rate base growth thesis breaks. This is the path most under-priced by sell-side. Watch the next GRC filing (SCE 2028 GRC, expected 2026 filing).
4. **Data center load doesn't materialize at SCE.** The CPUC public advocate is pushing minimum demand charges and termination fees similar to Ohio/Indiana [18]. If California adopts strict large-load rules, the 5 GW queue collapses and EIX gets none of the AI tailwind. **This is already the modal outcome — most "AI utility" upside in California accrues to PG&E (South Bay), not SCE.**
5. **Credit downgrade risk.** EIX has explicitly warned that without further wildfire reform, credit ratings are at risk [22]. A downgrade raises the cost of the $38–41B capex program directly.

A short-seller would write this trade as: *concentrated wildfire tail risk + smallest data-center exposure of California IOUs + affordability ceiling on rate base + first prudency trial in Q1 2027 = asymmetric downside in a defensive-looking name*.

## Market view check
At $68.95 / 11.2× FY26 EPS / 5.1% yield, the market is pricing EIX at roughly a 1.5–2 turn discount to PCG and ~3+ turns below the broader regulated utility median. The discount approximates the present value of a partial prudency finding on Eaton plus tail risk on a follow-on event. The **5% dividend + 5–7% EPS growth = ~10–12% expected total return** math is honest; this is a coupon-plus-modest-multiple-rerate trade contingent on SB 254 working as designed. The market view I disagree with: the framing of EIX as "AI-adjacent." It isn't, in any meaningful technical sense. The right comp set is PCG + post-2019 wildfire-cap utilities, not Dominion or NEE. If you want hyperscale exposure, buy D or VST; if you want California regulated yield with capped wildfire tail, EIX is reasonable but PCG is arguably better on growth.

## 90-day falsifiers
Specific events between now and ~August 8, 2026:

1. **Eaton Fire compensation program take-rate by July 2026 progress update.** If offers accepted exceed $1.5B (vs. ~$500M offered as of latest disclosure [23]) at expected severities materially below subrogation claim valuations, that's bullish on the prudency cap math. Track via newsroom.edison.com releases.
2. **Q2 2026 earnings (late July) and any update to FY26 guidance ($5.90–$6.20).** A reaffirmation = thesis intact; a downward revision driven by litigation costs = bear case validation.
3. **CFO transition close on July 3, 2026** (Aaron Moss replacing Maria Rigatti) [21]. Watch for any guidance reset or capex plan revision that conventionally accompanies a CFO change.
4. **Any new SCE-territory wildfire ignition during 2026 fire season** (peak July–November). A second utility-attributable fire materially worse than statistics predict triggers fund-replenishment math. Falsifier: any Red Flag Warning ignition with SCE equipment causation language in CPUC reportable incident filings.
5. **CAISO transmission planning process (TPP) 2026 draft, expected mid-year**, identifying SCE Inland Empire data-center upgrades. If $1B+ of new transmission is approved cost-allocated to data center customers, marginal upside; if blocked or socialized, marginal downside.
6. **CPUC decision on AMI 2.0 application** ($3.1B [21]). Approval at or near requested level is bullish on rate base; significant cuts (>20%) signal CPUC capex tightening.
7. **Any further California wildfire-fund legislation in the 2026 session** (current SB 254 implementation rulemaking is ongoing). Direction of travel matters more than headline.

## What I could not verify
- **Exact SB 254 liability cap calculation for SCE** — the 20%-of-T&D-equity-rate-base mechanic is documented [10], but I could not source SCE's own published cap figure as of FY25 close. The $4–5B estimate in the bear case is my inference from published rate base.
- **Composition of the 4.8 GW SCE data-center request queue** — names of requesting hyperscalers, contract status (LOA vs. PPA-equivalent), expected COD beyond 100 MW figure [2]. Hyperscale concentration would materially change conviction.
- **YTD return to May 8, 2026 close** — sources only quote through late March (~+18%) [8]. The May read may be materially different.
- **Authorized ROE in the 2025 GRC** — I cited the historical ~10.3% but did not verify the GRC-decision-level ROE.
- **Whether any SCE territory hyperscale announcements occurred in Q1 2026** that would change the queue picture — no specific large-customer name was disclosed in primary sources I located.
- **SCE pre-Eaton wildfire safety record vs. PG&E pre-2019** — qualitative claim based on industry reputation, not a quantified incident-rate comparison.
- **Exact dollar share of SCE share of any future wildfire fund top-up** — the ~33% figure is from AB 1054 cost allocation; SB 254 implementation may adjust.

## Sources
[1] https://www.sec.gov/Archives/edgar/data/827052/000082705226000023/eix-20251231xars.pdf — retrieved 2026-05-10 — EIX/SCE 2025 10-K, business description and operational footprint
[2] https://newprojectmedia.com/npm-analysis-southern-california-edison-discloses-5-gw-data-center-load-request-queue/ — retrieved 2026-05-10 — SCE 4.8 GW pre-operational data-center queue, 100 MW with 2025 connection, 867 MW unassigned
[3] https://www.utilitydive.com/news/nextera-basin-electric-data-center/807405/ + https://www.datacenterdynamics.com/en/news/dominion-energy-nearly-doubles-data-center-capacity-under-contract-to-40gw/ + https://qz.com/vistra-banks-on-the-data-center-ercot-growth-the-2027-2028-setup — retrieved 2026-05-10 — peer utility data-center contracted capacity figures (D 51 GW, AEP 20 GW, NEE 15–30 GW, VST 3.8 GW)
[4] https://stockanalysis.com/stocks/eix/statistics/ — retrieved 2026-05-10 — EIX price $68.95 (May 8, 2026), market cap $26.5B, forward P/E 11.21, dividend yield 5.09%, short interest 2.85%
[5] https://finance.yahoo.com/quote/EIX/ — retrieved 2026-05-10 — 52-week range $47.73–$76.22
[6] https://www.marketbeat.com/stocks/NYSE/EIX/forecast/ — retrieved 2026-05-10 — consensus PT $75.15, Hold rating across 21 analysts, range $54–$86, 2026 EPS consensus $6.18, short interest 3.50%
[7] https://www.gurufocus.com/term/ev/EIX/Enterprise-Value/Edison-International + https://companiesmarketcap.com/edison-international/revenue/ — retrieved 2026-05-10 — EV $68.23B, TTM revenue $19.31B
[8] https://www.gurufocus.com/news/8743561/edison-international-eix-leads-utilities-stocks-with-impressive-ytd-gains — retrieved 2026-05-10 — YTD ~+18.76% as of March 25, 2026; 22 consecutive years dividend growth, $0.88 quarterly
[9] https://leginfo.legislature.ca.gov/faces/billNavClient.xhtml?bill_id=201920200AB1054 — retrieved 2026-05-10 — AB 1054 statutory text on wildfire fund and prudency standard
[10] https://www.stocktitan.net/sec-filings/EIX/8-k-edison-international-reports-material-event-c887a6179e02.html — retrieved 2026-05-10 — SB 254 details: 20% T&D equity rate base cap, year-of-ignition basis, $21B claim-paying + $18B continuation, up to $3.9B IOU top-up, $6B wildfire mitigation securitization ($2.9B SCE)
[11] https://www.cpuc.ca.gov/-/media/cpuc-website/divisions/energy-division/documents/general-rate-cases/sce/fact-sheet-sce-grc-091825.pdf — retrieved 2026-05-10 — SCE 2025 GRC decision: $9.756B 2025 RR (+13.68%), $41.78B aggregate 2025–2028 (-$4.39B vs. request), 5% CPI cap on annual escalators
[12] https://www.businesswire.com/news/home/20260428414818/en/Edison-International-Reports-First-Quarter-2026-Results — retrieved 2026-05-10 — Q1 2026 results, $38–41B 2026–2030 capex, 5–7% core EPS CAGR
[13] https://www.stocktitan.net/sec-filings/EIX/8-k-edison-international-reports-material-event-4afb0a9b4f3c.html — retrieved 2026-05-10 — EIX 2026–2030 growth plan, $12B safety/reliability over two years, 7% rate-base CAGR
[14] https://www.powermag.com/hyperscalers-sign-white-house-pledge-to-fund-data-center-power-grid-upgrades/ — retrieved 2026-05-10 — turbine and grid upgrade bottleneck context
[15] https://fervoenergy.com/fervo-energy-announces-320-mw-power-purchase-agreements-with-southern-california-edison/ — retrieved 2026-05-10 — 320 MW Fervo geothermal PPA with SCE
[16] https://www.rtoinsider.com/129706-caiso-draft-tx-plan-silicon-valley-large-loads/ — retrieved 2026-05-10 — CAISO $1.4B Silicon Valley transmission for large data-center loads (PG&E territory)
[17] https://www.semianalysis.com — general industry context on CoWoS-L allocation (cited as background; specific URL not pulled in this dossier)
[18] https://www.publicadvocates.cpuc.ca.gov/press-room/commentary/251027-how-will-data-center-growth-impact-california-ratepayers — retrieved 2026-05-10 — CPUC public advocate analysis: PG&E South Bay 2.5 GW DC load 2026–2039, $2B+ transmission, push for minimum demand charges
[19] https://www.utilitydive.com/news/southern-california-edison-eix-wildfire-costs-earnings/812656/ — retrieved 2026-05-10 — Eaton Fire $1B booked, Pizarro statement on equipment association, $13.5B analyst tail estimate
[20] https://www.lawsuit-information-center.com/la-wildfires-lawsuit.html — retrieved 2026-05-10 — Eaton Fire litigation status, ~2,000 lawsuits, ~30,000 plaintiffs, first jury trial scheduled January 2027
[21] https://www.fool.com/earnings/call-transcripts/2026/04/28/edison-eix-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q1 2026 transcript: $1.42 core EPS, AMI 2.0 $3.1B application, CFO transition Rigatti → Aaron Moss July 3, 2026
[22] https://www.utilitydive.com/news/eix-california-utilities-credit-rating-wildfire-earnings/819026/ — retrieved 2026-05-10 — EIX warning on credit risk absent further wildfire reform
[23] https://newsroom.edison.com/releases/southern-california-edison-delivers-more-than-200-offers-to-eaton-fire-claimants — retrieved 2026-05-10 — Eaton Fire compensation program: $500M+ offered to ~3,800 claimants