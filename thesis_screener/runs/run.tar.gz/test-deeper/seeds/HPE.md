# HPE — Hewlett Packard Enterprise Company

## Where this sits in the AI stack
HPE sits at the **rack/cluster integration layer** between the silicon vendors (NVIDIA/AMD/Intel) and the data center: it does not design GPUs, HBM, or optics. Its differentiated IP is (a) the Cray EX/GX chassis and the **Slingshot** interconnect — proprietary Cassini NIC and Rosetta switch ASICs that compete with NVIDIA InfiniBand/Spectrum-X for scale-out fabric; (b) **direct liquid cooling (DLC)** engineering tuned to 130+ kW racks; (c) the **Aruba + Juniper** networking franchise (Mist AI, Marvis, Apstra) post the July 2025 $14B Juniper close [12]. The dominant AI workload exposure is **government/sovereign and enterprise training and inference** plus **HPC** — *not* hyperscaler frontier training, which is increasingly routed through Taiwanese ODMs (Foxconn, Wiwynn, Quanta) [15]. HPE plays in mid-scale fine-tune, sovereign sealed clouds, on-prem inference, and DOE/NNSA exascale.

## Snapshot
- **Price:** $31.35 (2026-05-08 close; May 10 is a Sunday) [21]
- **Market cap:** ~$41.6B [21]
- **52-week range:** $16.76 – $31.50 [21]
- **Forward P/E:** ~13.0× on FY26 non-GAAP EPS midpoint of $2.40 (guided $2.30–$2.50) [3]
- **EV / NTM revenue:** ~1.4× ($41.6B mcap + ~$16.8B net debt over ~$42B NTM revenue at 17–22% growth on FY25 base) [2][21] — inference, not a direct quote
- **Consensus 12-month price target:** ~$27.00 median (range $21–$38), implying **–14%** from spot — sell-side is below market [22]
- **YTD total return:** +31.4% [21]
- **Short interest (% of float):** n/a — not verified at retrieval time
- **TTM revenue:** $35.74B; **net cash:** –$16.8B (post-Juniper) [21]
- **Networking now ~30% of revenue / >50% of operating profit** [3]

## Moat — what it is physically made of
HPE's moat is **not the x86 server.** The DL380/DL580 ProLiant boxes are commodity integration around an NVIDIA reference design — Dell, Supermicro, Lenovo, and the Taiwanese ODMs ship equivalent SKUs within weeks of each other [19]. The real moat decomposes into four distinct components:

1. **Slingshot silicon + topology (durable, narrowing).** The Rosetta switch ASIC (originally TSMC 16nm, 64×200 Gb/s, 25.6 Tbps, ~250W) and the Cassini NIC together implement a Dragonfly+ topology with hardware-level adaptive routing, congestion control, and packet-by-packet load balancing that NVIDIA needed BlueField-3 + Spectrum-4 to approximate [10][11][27]. Slingshot 11 powers 6 of the top 10 supercomputers (El Capitan, Frontier, HPC6, Alps, LUMI, etc.) and **48.1% of TOP500 aggregate FLOPS** vs. 28.8% for InfiniBand NDR [5][29]. **Slingshot 400** (Rosetta-2, TSMC 7nm, 51.2 Tbps switch, fully liquid-cooled, ships 2H26-2H27 in GX5000) is a credible 1.6 Tb/s-class fabric [8][9]. The narrowing risk is real: NVIDIA's Spectrum-X has demonstrated 1.6× standard-Ethernet AI throughput and is winning cloud-AI deployments where Slingshot's HPC heritage doesn't translate to mixed-tenant LLM clusters [23]. Even HPE now ships Quantum-X800 InfiniBand as an option on GX5000 [9] — that is an admission that the in-house fabric is not the default choice for NVIDIA-stack AI training.

2. **Direct liquid cooling at exascale (durable, 24–36 months).** El Capitan is the world's fastest **fanless** DLC machine — 1.809 EF HPL, 58.89 GF/W, ~30 MW [4]. HPE claims (and is, by independent count, the largest installer of) >100 MW-class DLC deployments — five decades of liquid cooling history from Cray and Apollo [6]. With GB300 NVL72 dissipating 132–140 kW per rack and 90% of heat going to liquid, this is a binding constraint on every customer that didn't grow up with cold plates [6][7]. The base rate matters: thermal/MEP engineering at hyperscale takes years to acquire — see how long Meta/Microsoft took to scale their first liquid-cooled halls. Erosion path: ODM partnerships with Vertiv/CoolIT productize reference designs that close the gap by 2027.

3. **Mist AI + Marvis + Apstra (durable, software flywheel).** This is the Juniper acquisition's actual prize. Mist has been ingesting wireless/wired telemetry at customer scale since 2014 — a **10+ year labeled-data lead** for networking AIOps [14]. The Marvis agentic-AI assistant and Apstra's contextual graph DB on data-center topology are deeper than anything Cisco or Arista has shipped. This is the rare case where the acquirer's own AI is competitively useful, not theater. The Aruba CX 10000 with embedded **AMD Pensando P4 DPU** (3.2–8 Tbps, distributed L4 stateful firewall on every port) is a real differentiator vs. plain Arista 7050X/Cisco Nexus [16].

4. **HPE Cray Programming Environment + customer install base (sticky, slow).** Cray's compilers (CCE), CrayPat, perftools, MPI toolkit, and PE Programming Environment are 30+ years of accumulated HPC software. DOE/NNSA/EuroHPC/RIKEN customers don't re-port millions of LoC to switch vendors casually. This is closer to a switching cost than a network effect — and like all switching costs, it can be paid down with budget if the alternative is good enough.

What is **not** moat: ProLiant integration, GreenLake billing (any vendor has a "cloud-style consumption" wrapper), Storage (Alletra is a follower), and Morpheus VM Essentials — useful catch-share against Broadcom/VMware refugees, but Nutanix, Red Hat OpenShift Virt, and Proxmox are doing the same thing [18].

## AI buildout bottleneck map
| Bottleneck | HPE position |
|---|---|
| **Power (grid, GT backlog)** | Indifferent — sells what fits inside whatever envelope customer secures. *Not* a power-as-a-service operator. |
| **CoWoS-L allocation** | Exposed customer — depends on TSMC packaging cadence delivering Blackwell/Rubin into HPE-integrated racks. Zero control. |
| **HBM3e / HBM4 supply** | Exposed customer — directly affects per-rack price (Q1 FY26 transcript flagged memory commodity inflation) [1]. |
| **Optical interconnect / pluggables** | Mixed — Slingshot uses standard QSFP-DD optics; co-packaged optics (CPO) on Rosetta-2/Cassini-2 is on roadmap. Buyer, not maker. |
| **>100 kW/rack liquid cooling** | **Beneficiary and supplier.** This is genuinely HPE's lane — they integrate CDUs, in-row and rear-door units, manifolds, and warranty the whole stack [6]. |
| **Electrical contractor / data-center build labor** | Indifferent — though they tag along on AI Factory greenfield builds. |
| **CUDA kernel / Triton / compiler talent** | Indifferent — relies on NVIDIA's stack. |
| **Networking ASIC / DPU silicon** | **Owner** (Rosetta, Cassini) and **partner** (Pensando via AMD on CX 10000). Unique among server OEMs. |
| **Sovereign data-locality demand** | **Beneficiary** — HUMAIN, G42, EU sovereign clouds explicitly cite HPE among preferred prime contractors [20]. Sovereign deals favor non-hyperscaler primes. |

## Competitive teardown
- **Dell (PowerEdge XE9680/XE9712).** On AI servers Dell already has the larger book (~20% share vs. HPE 15% in 2024 [19]) and grew faster YTD 2026. Dell has parity on NVIDIA reference SKUs — there is no GPU-server axis where HPE technically beats Dell at scale. Dell has *no* equivalent to Slingshot and a thinner DLC story. **HPE wins on HPC + sovereign; Dell wins on hyperscaler tier-2 and enterprise breadth.**
- **Supermicro.** Faster time-to-market on every NVIDIA generation, lower margin. Distracted by the March 2026 DOJ indictment for $510M of GPU export-control violations — credible share-loss event, but the recipient has historically been Dell as much as HPE [19]. **Watch the next two quarters.**
- **ODMs (Foxconn, Wiwynn, Quanta).** Foxconn's AI rack volume could **double in 2026**, taking >40% of GPU-rack share globally [15]. Hyperscalers (AWS, Azure, GCP, Meta, Oracle) buy through ODMs directly — HPE is **structurally excluded** from that pool, which is the largest AI capex pool by absolute dollars. This is the binding ceiling on HPE's AI server TAM.
- **Cisco / Arista (networking).** Both are credible. Arista has the data-center scale; Cisco has the enterprise install base. Neither has a Marvis-equivalent: 10 years of supervised wireless/wired telemetry is hard to recreate. Cisco's Splunk/AI Defense pivot is the credible counter; Arista's CloudVision is technically thinner. **HPE+Juniper is the only fully integrated wired+wireless+DC+AIOps stack** — a real, defensible position that justifies the networking margin.
- **NVIDIA (Spectrum-X).** This is the *most concerning* competitor. Spectrum-X Ethernet is being designed in next to every GB200/GB300/Rubin reference rack. To the extent the AI fabric becomes "whichever Ethernet NVIDIA ships with the system," Slingshot's value proposition compresses to HPC niches [23].

## Bull case — technical
For HPE to outperform, four things must broadly hold over 2026–2027:

1. **AI rack densities continue to rise past 130 kW**, locking in DLC as a binding qualifier rather than a nice-to-have. GB300 at 140 kW/rack and Rubin NVL72 in Dec 2026 push this further [6][9]. Customers without HPE-grade thermal engineering experience pay HPE to do it.
2. **The Juniper Mist platform compounds into a true AIOps category.** The agentic Marvis releases (Aug 2025, Mar 2026) suggest the team can ship; if data-center Mist adoption hits ~20% of attached Aruba/Juniper switches, networking gross margins re-rate further [14]. The empirical signal is the >50% profit contribution from 30% of revenue already visible in Q1 FY26 [3].
3. **Sovereign AI converts the $5B backlog.** Middle East (HUMAIN, G42), EuroHPC, India digital sovereignty buildouts prefer non-hyperscaler primes for regulatory reasons. HPE is on the short list [20]. Each ~$1B sovereign deal cleanly drops through at high incremental margin if it's HPC-shaped (DLC + Slingshot) rather than commodity HGX.
4. **Slingshot 400 / Rosetta-2 ships on time (1H27) and at least one major hyperscaler or sovereign deploys it on a Rubin-class system.** This validates that the in-house fabric is not a stranded asset against Spectrum-X.

**Base rate on technology displacement at this stage of the cycle:** in roughly comparable platform shifts (x86 → ARM in mobile; on-prem → cloud; mainframe → x86), incumbents that owned both software and physical engineering moats (cooling, fabric, OS) typically retained 40–60% of their pre-shift profit pool over 5–7 years, even when share migrated. HPE's analog is Sun Microsystems c. 2002 (lost) versus IBM Z (kept ~50% of mainframe profits through 2020). The Mist + Slingshot combination puts HPE closer to IBM-Z than to Sun, if and only if management resists pricing networking like a server.

**Financial connect:** networking compounding + AI server pull-through against a 13× forward P/E and consensus targets below spot leaves room for re-rating to 15–17× on FY27 EPS of ~$2.80 — a $42–48 fair value.

## Bear case — technical
The short-seller who actually knows the stack writes this:

1. **Slingshot's relevance is shrinking, not growing.** HPE itself is shipping Quantum-X800 IB on GX5000 [9]. NVIDIA's reference Rubin NVL72 ships with ConnectX-9 + Spectrum-X by default; the customer would have to choose to swap it out. As enterprise AI converges on NVIDIA reference racks, the fabric moat decays from "owns top500" to "an option you can ask for." TOP500 share is a vanity metric — DOE/NNSA budgets are not 2026's marginal compute dollar.
2. **The Juniper "growth" is almost entirely acquisition arithmetic.** Q1 FY26 networking +151.5% reported but only **+7% normalized** [3]. The "30% revenue / 50% profit" line is a snapshot, not a growth rate. If organic networking decelerates to flat as Cisco/Arista respond and enterprise IT budgets tighten, the segment re-rates as a low-single-digit grower with elevated R&D, not a 20% compounder.
3. **AI server gross margins are compressing — Cloud & AI op margin was 10.2%** in Q1 FY26 vs. company average 12.7% [1][24]. Pass-through silicon cost on GB200/GB300 leaves HPE earning $0.04–$0.07 of operating margin per dollar of NVIDIA-content rack. As sovereign and tier-2 deals (the ones HPE is winning) push higher AI mix, blended margin **drops**, not rises. Management has flagged this on the call [1].
4. **ODMs structurally bound the TAM.** Hyperscalers' AI capex is the bulk of the market, and they don't buy from HPE [15]. Sovereign + enterprise + HPC is real but TAM-bounded. The growth story is fundamentally a mid-teens-grower at best, not a hyper-grower.
5. **The balance sheet is now levered.** Net debt of ~$16.8B against ~$3.5B FY25 FCF [21] — not dangerous, but limits the "buyback bridge to multiple expansion" common in the bull narrative.
6. **Spot is above consensus PT** (sell-side median $27 vs. $31 close) [22]. The marginal buyer is paying through analyst fair value on momentum.

**Falsifier of bear case:** any quarter where Cloud & AI op margin expands sequentially while AI revenue grows >15% YoY, with networking organic >10%.

## Market view check
At ~13× forward EPS and ~1.4× EV/revenue, HPE is priced as a low-teens grower with margin upside, *not* as an AI hyper-grower. The market apparently believes (a) Juniper synergies are real and structural, (b) DLC + sovereign give HPE durable second-tier AI-server share, and (c) the $5B backlog converts mostly on schedule in 2H FY26. What the market is **not** paying for is a re-rate to NVIDIA-correlated multiples — sensible, because HPE captures a single-digit percentage of the GPU dollar that flows through its racks. The +31% YTD move and the spot-above-consensus PT mean the easy money has already been made on Juniper close; from here the thesis depends on backlog conversion. Mispricing case: if Slingshot 400 wins a major hyperscaler-adjacent deployment and AI op margin expands rather than contracts in 2H FY26, fair value is closer to $42 than $27. Mispricing case the other way: if Q2/Q3 print shows AI margin compression and sovereign deal slippage, $22–$24 is plausible.

## 90-day falsifiers
- **HPE Q2 FY26 print (early June 2026):** Cloud & AI segment operating margin direction — sequential expansion validates pricing discipline; further contraction confirms the bear margin thesis. Watch networking *normalized* growth — needs >7% to confirm Juniper compounding.
- **TOP500 June 2026 list (ISC 2026, Hamburg, mid-June):** number of new Slingshot-11 vs. Slingshot-400 vs. Quantum-X800 systems entering. A Slingshot-400 debut on a publicly-named system would update the moat-durability thesis up.
- **GTC fall / ISC announcements:** named Vera Rubin NVL72 by HPE customer wins (Dec 2026 availability [9]). Silence here is bearish.
- **Sovereign deal cadence:** any announced cancellation or delay of HUMAIN, G42, or EuroHPC awards would compress backlog; a new sovereign prime award (e.g., India, KSA expansion, EU AI Factories) is incremental.
- **Hyperscaler Q2 capex guides (AMZN, MSFT, GOOG, META, late July 2026):** sequential >10% cuts would compress the entire AI server cohort and HPE with it, even though HPE has limited direct exposure to that wallet.
- **Supermicro DOJ trial/settlement progression:** material settlement or remediation order accelerates HPE/Dell share-gain narrative — Dell is the more likely beneficiary.
- **Spectrum-X large-cluster MLPerf submissions:** if NVIDIA discloses Spectrum-X-only GPT-class training within 10% of NVL72+IB at scale, Slingshot's "Ethernet+ for AI" pitch weakens. If Slingshot 400 submissions appear and lead on energy-per-token, opposite.

## What I could not verify
- Short interest on HPE as of May 8, 2026 close — generic forecast sites did not surface it.
- Whether the Rosetta-2 / Cassini-2 ASICs are actually fabbed at TSMC 7nm or moved to a more advanced node — the "7nm" datapoint comes from one secondary source [8][11].
- The exact mix of $5B AI backlog between hyperscaler-adjacent, sovereign, and enterprise customers — disclosed only in aggregate.
- Whether HPE-shipped GB200 NVL72 racks command a premium vs. Dell/Supermicro on like-for-like silicon (anecdotal claims, no audited margin breakdown).
- Specific FY27 consensus EPS — the dossier uses the FY26 midpoint of $2.40 and extrapolated.
- The status of HPE's Instant On divestiture (DOJ-mandated) — closing terms and buyer not confirmed in retrieved sources [12].
- Whether HPE has co-packaged optics (CPO) on the Slingshot 400 roadmap or a pure pluggable design — public materials are ambiguous.
- Whether sovereign Middle East deals are signed at corporate-average gross margin or below — HPE has not separately disclosed.

## Sources
[1] https://investors.hpe.com/~/media/Files/H/HP-Enterprise-IR/documents/q1-2026/hpe-q1-26-earnings-transcript.pdf — retrieved 2026-05-10 — Q1 FY26 transcript: $9.3B rev, 36.6% NG GM, $5B AI backlog, margin pressure flag.
[2] https://futurumgroup.com/insights/hpe-q1-fy-2026-results-show-networking-strength-ai-backlog-and-higher-outlook/ — retrieved 2026-05-10 — Q1 FY26 analysis, FY26 17-22% growth and EPS guide.
[3] https://247wallst.com/investing/2026/03/10/networking-now-30-of-hpe-revenue-but-over-half-of-profits/ — retrieved 2026-05-10 — Established networking is 30% of revenue / >50% of profit; +7% normalized vs. +151% reported.
[4] https://www.hpcwire.com/off-the-wire/hpe-delivers-worlds-fastest-direct-liquid-cooled-exascale-supercomputer-el-capitan-for-llnl/ — retrieved 2026-05-10 — El Capitan 1.742-1.809 EF, fully fanless DLC.
[5] https://top500.org/lists/top500/2025/11/ — retrieved 2026-05-10 — Nov 2025 list; HPE 22.4% systems, 48.1% Slingshot performance share.
[6] https://www.hpe.com/us/en/compute/hpe-nvidia-gb300-nvl72.html — retrieved 2026-05-10 — GB300 NVL72 by HPE: 132-140 kW/rack, DLC market leadership claim.
[7] https://hardforum.com/threads/liquid-cooling-for-nvidia-gb300-blackwell-ultra-nvl72-costs-nearly-50-000.2044553/ — retrieved 2026-05-10 — ~$50k/rack thermal hardware cost.
[8] https://www.servethehome.com/hpe-slingshot-400-brings-a-liquid-cooled-51-2t-switch-and-400gbps-networking/ — retrieved 2026-05-10 — Slingshot 400: 51.2Tbps, Rosetta-2 7nm, Cassini-2, GX5000 early 2027.
[9] https://www.storagereview.com/news/hpe-cray-gx5000-and-ai-factory-get-nvidia-vera-rubin-nvl72-quantum-x800-infiniband-and-new-blackwell-options — retrieved 2026-05-10 — GX5000 with Vera Rubin NVL72 (Dec 2026), Quantum-X800 option.
[10] https://en.wikichip.org/wiki/cray/interconnects/slingshot — retrieved 2026-05-10 — Rosetta switch architectural details.
[11] https://fuse.wikichip.org/news/3293/inside-rosetta-the-engine-behind-crays-slingshot-exascale-era-interconnect/ — retrieved 2026-05-10 — Rosetta TSMC 16nm, 250W, 64×200 Gb/s.
[12] https://www.hpe.com/us/en/newsroom/press-release/2025/07/hewlett-packard-enterprise-closes-acquisition-of-juniper-networks-to-offer-industry-leading-comprehensive-cloud-native-ai-driven-portfolio.html — retrieved 2026-05-10 — Juniper close July 2, 2025, $14B; Instant On divestiture.
[13] https://www.channelfutures.com/mergers-acquisitions/hpe-juniper-networks-acquisition-complete-timeline — retrieved 2026-05-10 — Juniper deal timeline and DOJ settlement.
[14] https://www.juniper.net/us/en/mist-ai-native-networking-platform.html — retrieved 2026-05-10 — Mist 10+ years of data science, Marvis agentic AI, Apstra integration.
[15] https://www.digitimes.com/news/a20260109PD249/revenue-ai-server-foxconn-wistron-quanta.html — retrieved 2026-05-10 — Foxconn/Wistron/Quanta NT$1T each; Foxconn ~40% AI server share, doubling in 2026.
[16] https://www.amd.com/content/dam/amd/en/documents/pensando-technical-docs/data-sheets/aruba-cx-10000-series-datasheet.pdf — retrieved 2026-05-10 — Aruba CX 10000 with Pensando P4 DPU, 3.2-8 Tbps, distributed firewall.
[17] https://www.hpe.com/us/en/private-cloud-ai.html — retrieved 2026-05-10 — HPE Private Cloud AI co-engineered with NVIDIA, DL380a Gen12 + RTX PRO 6000 Blackwell, 128-GPU scale.
[18] https://www.nextplatform.com/2025/05/14/taking-on-vmware-hpe-mashes-up-vm-essentials-with-morpheus-cloud-controller/ — retrieved 2026-05-10 — Morpheus VM Essentials per-socket pricing, KVM+VMware mgmt.
[19] https://www.ciodive.com/news/dell-hpe-ai-server-market-growth/759329/ — retrieved 2026-05-10 — Dell 20% / HPE 15% / Supermicro 9% AI server share 2024.
[20] https://newsletter.semianalysis.com/p/ai-arrives-in-the-middle-east-us-strikes-a-deal-with-uae-and-ksa — retrieved 2026-05-10 — HUMAIN/G42 deals, UAE-US 5GW campus, Nov 2025 GB300 export approvals.
[21] https://stockanalysis.com/stocks/hpe/statistics/ — retrieved 2026-05-10 — Price $31.35 (May 8 close), mcap $41.6B, 52w range $16.76-$31.50, TTM rev $35.74B, net debt $16.8B, YTD +31.4%.
[22] https://stockanalysis.com/stocks/hpe/forecast/ — retrieved 2026-05-10 — 36-analyst consensus PT median $27, range $21-$38.
[23] https://dev.to/firstpasslab/how-nvidia-spectrum-x-ports-infiniband-tricks-to-ethernet-for-ai-fabrics-3h24 — retrieved 2026-05-10 — Spectrum-X 1.6× perf over commodity Ethernet for AI training.
[24] https://www.nextplatform.com/2025/03/07/gpu-transitions-aggressive-server-pricing-squeeze-hpe-profits/ — retrieved 2026-05-10 — AI server pricing/margin pressure under GPU transitions.
[25] https://www.blocksandfiles.com/ai-ml/2026/03/11/hpe-networking-boom-offsets-server-dip-as-revenue-hits-93b/5208426 — retrieved 2026-05-10 — Q1 FY26 networking offsetting server softness; segment economics.
[26] https://futurumgroup.com/insights/hewlett-packard-enterprise-q4-fy-2025-arr-surges-as-ai-orders-build/ — retrieved 2026-05-10 — Q4 FY25 ARR / AI backlog trajectory.
[27] https://www.researchgate.net/publication/349528862_An_In-Depth_Analysis_of_the_Slingshot_Interconnect — retrieved 2026-05-10 — Slingshot adaptive routing and congestion-control technical analysis.
[28] https://cug.org/proceedings/cug2022_proceedings/includes/files/pap121s2-file1.pdf — retrieved 2026-05-10 — CUG Slingshot architecture, Dragonfly+ topology.
[29] https://www.sdxcentral.com/analysis/ethernets-exascale-victory-hpes-slingshot-continues-to-conquer-the-exascale-interconnect-battle/ — retrieved 2026-05-10 — Slingshot 48.1% TOP500 perf vs. 28.8% IB-NDR.
[30] https://www.computerweekly.com/news/366554278/HPE-hones-GreenLake-strategy-with-AI-moves-hybrid-cloud-management — retrieved 2026-05-10 — GreenLake ARR $3.2B +63% YoY.
[31] https://www.investing.com/news/transcripts/earnings-call-transcript-hpe-beats-q1-2026-eps-forecast-by-12-stock-dips-93CH-4550906 — retrieved 2026-05-10 — Q1 FY26 +12% EPS beat, stock reaction, margin commentary.