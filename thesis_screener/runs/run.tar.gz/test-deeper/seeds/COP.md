# COP — ConocoPhillips

## Where this sits in the AI stack

ConocoPhillips is not in the AI stack in any technical sense. It is an upstream oil & gas E&P — the largest pure-play US independent post the November 2024 Marathon Oil acquisition — producing ~2.31 MMBOE/d in Q1 2026, of which 1.45 MMBOE/d came from the Lower 48 (898 Mboed Permian/Delaware+Midland, 367 Mboed Eagle Ford, 183 Mboed Bakken) [4][5]. Reserves are ~46% oil / 34% gas / 14% NGL / 6% bitumen [6]. Its "AI exposure" sits three layers below the GPU: associated gas from oil-directed Permian wells and dry gas from Eagle Ford/Utica enters the wholesale molecule pool that feeds (a) behind-the-meter and grid-tied gas turbines now being installed at >5 GW scale at Permian and Texas data-center campuses, and (b) Gulf Coast LNG, where COP holds equity and offtake. COP itself sells commodity molecules at Waha / Henry Hub minus basis — no proprietary technology, no signed hyperscaler PPA, no captured price arbitrage versus a peer producer.

## Snapshot

- **Price:** $113.87 (2026-05-08 close) [9]
- **Market cap:** ~$140B (1.22B shares × $113.87) [9]
- **52-week range:** $84.28 – $135.87 [9]
- **Forward P/E:** ~23× on FY26 consensus EPS $4.93 (range $2.60–$7.56) [3]; one source cites 17.5× implying a 2027-weighted estimate near $6.50 [3]
- **EV / NTM revenue:** ~2.5× (EV ≈ $160B incl. ~$20B net debt post-Marathon, against Q1 2026 revenue $15.76B annualized at $63B) [4][7] — inference, not a directly reported metric
- **Consensus 12-month price target:** $115–$117 (range $98–$144); implied upside ~+1% to +3% from spot [3][8]
- **YTD total return:** +15% (2026 YTD through early May) [8]; +46% TTM
- **Short interest (% of float):** n/a — not surfaced in public summary feeds at retrieval time

## Moat — what it is physically made of

The honest decomposition: COP's moat is geology and execution, not technology. There is no software stack, no IP, no manufacturing relationship to allocate. Specifically:

1. **Cost-of-supply inventory.** The Midland/Delaware/Eagle Ford/Bakken positions average a stated ~$32 WTI breakeven, with portfolio-wide Lower 48 breakeven <$40 and a stated FCF breakeven in the mid-$40s pre-dividend, targeting low-$30s by 2030 [10]. The mechanism is mundane and durable: lateral length extension from 1-mile to 2-mile dropped per-foot cost ~25%, with another 10–15% available at 3–4 miles [10]. This is execution depth, not a moat in the Buffett sense — every Permian operator is on the same learning curve, but COP/EOG/FANG sit at the front of it.
2. **Inventory depth.** Post-Marathon, COP has stated decades of sub-$40 breakeven inventory across four basins. This is the only genuine durable advantage versus higher-cost majors — a real moat versus Shell/BP/TotalEnergies onshore but largely a wash versus XOM (post-Pioneer), CVX (post-Hess), EOG, and FANG.
3. **Qatar LNG seat.** COP holds 25% of a JV that owns 12.5% of QatarEnergy's North Field East — i.e., ~3.125% economic interest in NFE, expected start-up H2 2026 [2]. Qatar's wellhead lift cost is approximately $0.50–$1.00/MMBtu (one of the lowest globally). This is the only non-replicable structural moat in the portfolio — you cannot get a Qatar LNG seat at any price today.
4. **US LNG offtake.** Equity stake plus 5 Mtpa cumulative offtake at Sempra's Port Arthur LNG Phase 1 (2027 start-up) and Phase 2 (4 Mtpa SPA signed) [2]. This is a contractual position, not a moat — Sempra and Cheniere capture the tolling spread.
5. **Marathon integration.** $1B+ run-rate synergies achieved within ~12 months versus initial $500M target, plus $1B one-time benefits; ~30% fewer rigs to maintain production [1]. Synergy delivery beat the deal model — this is signaling on management quality rather than a durable competitive position.

What this is **not**: a technology moat, a developer ecosystem, a manufacturing allocation, or a regulatory monopoly. Treating COP as anything other than a low-cost commodity producer with high-quality LNG optionality is a category error.

## AI buildout bottleneck map

Real gating constraints over the next 24 months and where COP sits relative to each:

- **Gas turbines (the binding constraint).** GE Vernova's combined gas turbine backlog + slot reservations reached ~100 GW and the CEO stated equipment is "sold out through 2030" by year-end 2026; ~20% of new orders are explicitly data-center-tied [11]. Constraint owner: GEV / Siemens Energy / Mitsubishi. COP is **indifferent** — the molecule clears at Henry Hub regardless of who owns the turbine.
- **Permian gas takeaway.** Waha basis has averaged negative $0.37/MMBtu YTD 2026, with stretches near −$10/MMBtu, until Matterhorn ramp + Blackcomb (2.5 Bcf/d, full ramp by Dec 2026) + GCX expansion (~0.57 Bcf/d mid-2026) add ~4.5 Bcf/d of egress in H2 2026 [12]. COP is **exposed**, not a beneficiary: every Permian operator gives back basis until the pipe arrives. This is the single most important short-cycle variable for COP's Lower 48 gas realizations.
- **Data-center-adjacent power generation.** Crusoe Abilene secured 4.5 GW of natural gas through an Engine No. 1 JV for the Stargate site (1.2 GW IT load by mid-2026) [13]; Chevron is pursuing 2.5 GW (expandable to 5 GW) in West Texas via GEV/Engine No. 1 partnership with FID early 2026 and first power 2027 [14]; FO Permian Partners 5 GW; CloudBurst 1.2 GW via Energy Transfer; Diamondback exploring a JV on 65,000 acres for data-center power [14]. COP has announced **none of these**. Position: **supplier of fungible feedstock, not deal counterparty**.
- **FERC behind-the-meter rules.** FERC issued a December 2025 unanimous order directing PJM to create three new transmission-service options for co-located large loads — interim non-firm, firm contract demand, non-firm contract demand — with compliance starting January 2026 [15]. This is *enabling* for the broader gas-to-AI thesis (resolves the Talen/Amazon Susquehanna question that paralyzed deals in 2024–2025) and *neutral-to-positive* for upstream gas producers, but does not give COP any company-specific advantage.
- **HBM3e/CoWoS-L/optical/liquid cooling.** Completely irrelevant to COP. These constrain the GPU side of the buildout; gas demand follows GW provisioned, not chip shipments per se, but COP has no exposure.
- **Hyperscaler capex.** ~$600–630B expected in 2026 (+36–62% YoY) [16]. This is the demand pull. COP's leverage to it is a beta on aggregate gas demand, not a direct contractual relationship.

**Net read.** COP sits in the most generic position in the AI buildout map: it owns molecules that will eventually be burned for power, but the value capture is happening downstream (turbine vendors, midstream, on-site IPPs, LNG tollers) and laterally (EOG, FANG, EQT, CVX have all made more pointed strategic moves).

## Competitive teardown

- **EOG Resources.** Explicit 2026 strategic pivot to position as a "natural gas powerhouse" — aggressive Dorado dry-gas development in South Texas and the $5.6B Encino acquisition for Utica Shale exposure with stated AI/LNG dual-tailwind framing [17]. EOG has been notably louder about AI than COP. *Axis of advantage:* dry-gas optionality and Northeast/Gulf market access; explicit narrative.
- **Diamondback Energy (FANG).** Pure Permian. Actively pursuing a JV to build a gas-fired plant on 65,000 acres of owned surface for direct data-center electricity sales [14]. *Axis of advantage:* surface ownership lets FANG capture the molecule→electron spread that COP cannot.
- **Chevron (CVX).** February 2025 partnership with GE Vernova and Engine No. 1 for up to four gas-fired plants; first 2.5 GW project in West Texas with FID early 2026, power generation starting 2027, expandable to 5 GW [14]. *Axis of advantage:* integrated through midstream and now downstream into power; a real platform play that COP has chosen not to replicate.
- **EQT.** Pure Marcellus dry-gas operator, geographically closest to Northern Virginia / PJM data-center clusters. *Axis of advantage:* basis economics and proximity to the densest US data-center load.
- **ExxonMobil (XOM).** Largest Permian operator post-Pioneer, integrated through to LNG and chemicals. *Axis of advantage:* scale, balance sheet, and integrated downstream optionality.

Where COP wins on a defensible axis: lowest-cost integrated US unconventional operator with a unique Qatar LNG seat. Where COP is losing on the AI-specific narrative: it has not announced any direct data-center power deal, midstream JV, or surface-rights monetization, while every named competitor has. If the "AI gas premium" is real and persistent, it is currently accruing to CVX/FANG/EOG narratives faster than to COP.

## Bull case — technical

For the stock to materially outperform from $113.87, the following technical conditions need to hold:

1. **Henry Hub structurally re-rates to $4.00–$5.00/MMBtu by 2027.** EIA currently forecasts $3.67 in 2026 / $3.59 in 2027 [12]. The bull thesis requires US LNG export ramp (+1.3 Bcf/d in 2026 from Plaquemines, CC Stage 3, Golden Pass + 1.7 Bcf/d in 2027) plus AI-driven power burn (data centers at 9–17% of US electricity by 2030 per EPRI [18]) to overshoot supply response. COP's ~17% gas revenue mix re-rates without execution risk.
2. **Permian basis tightens to flat by H1 2027.** Matterhorn full ramp + Blackcomb + GCX expansion deliver the ~4.5 Bcf/d of egress, and incremental local demand (Permian gas-to-power: at least 12+ GW of announced projects across Crusoe, Chevron, FO Permian, PowerBridge) absorbs the new pipe. COP's stranded Permian gas re-prices.
3. **Qatar NFE starts on schedule H2 2026.** Adds an inference ~$1.0–1.5B annual FCF at Qatari cost structure — modest relative to total but high-quality, cycle-resilient cash flow.
4. **No competitor takes meaningful Permian/Eagle Ford share.** Unlike a chip moat, this is a near-mechanical truth: inventory depth at <$40 breakeven is set by acreage already owned. The "displacement" base rate for low-cost reserves owners is effectively zero on a 5-year horizon, in contrast to ~3–5 years for software moats and ~5–10 years for semiconductor moats.
5. **COP announces a direct data-center deal.** Currently zero such optionality is priced in. A PPA, midstream JV, or surface-rights deal analogous to FANG/CVX would unlock a narrative re-rating without changing underlying economics much.

Financial outcome: stock to $135–145 (consensus high), driven by 10–15% upward EPS revision on gas re-rating plus modest multiple expansion. Base rate caveat: integrated E&Ps have historically NOT sustained terminal multiple expansion through commodity cycles — the multiple compresses as cash returns rather than expanding.

## Bear case — technical

The short-seller-who-understands-the-stack version:

1. **AI gas demand is fungible across producers.** Whether the molecule comes from COP, EOG, FANG, EQT, or XOM is irrelevant to the turbine operator. COP captures no excess premium versus the basket. Sector beta only.
2. **Permian decline rates accelerate.** Public data shows US drilling discipline with flat rigs in 2026 [5]; COP's 2026 production guide of 2,300–2,330 MBOE/d versus 2,375 in 2025 implies essentially flat-to-down output. The growth story for the marginal investor has effectively ended.
3. **Waha basis structural.** Permian gas is overwhelmingly *associated* gas from oil-directed wells — supply is set by oil drilling, not gas economics. New takeaway helps but creates an oversupply ceiling at Henry Hub minus a stubborn $0.40–$0.80 basis. Behind-the-meter data center demand directly in the basin (Crusoe, Chevron, Stargate) helps locally but is double-edged: it bypasses the producer entirely if the data-center operator contracts directly with a smaller, more nimble counterparty.
4. **Oil at $60 destroys the FCF profile.** $40 portfolio breakeven is *not* the marginal-barrel breakeven. At WTI $60, $10B/yr shareholder returns become unsustainable without leverage — a scenario the market has not stress-tested into the current 6% FCF yield.
5. **Hyperscaler-direct disintermediation.** The actual money in the gas-to-AI stack is being captured by (a) turbine vendors (GEV's record backlog), (b) integrated IPPs (Crusoe, Talen, Vistra), and (c) midstream (Energy Transfer's CloudBurst deal). Upstream E&Ps see the demand but not the spread.
6. **No technical moat to expand.** Unlike a software / semis name where AI exposure can drive multiple expansion through demonstrated platform leverage, an E&P selling commodity into a structurally oversupplied basin has no mechanism for multiple expansion beyond cyclical re-rating.
7. **Qatar slippage risk.** NFE has already slipped from initial 2025 commissioning to H2 2026; another quarter or two is plausible and erodes the LNG bull narrative.
8. **The 46% TTM rally already priced the cycle.** Consensus PT $115 vs spot $113.87 says the sell side does not see meaningful 12-month upside. Limited margin of safety.

Base rate on technology / sector displacement: integrated upstream E&P moats erode slowly (decades) but multiples compress in oversupply cycles within 12–24 months. This is the relevant base rate, not "AI moat displacement."

## Market view check

At $113.87, 23× forward EPS, ~2.5× EV/sales, 6% FCF yield, and a consensus PT essentially flat to spot, the market is pricing COP as an in-line, low-cost integrated E&P with normalized commodity assumptions (~$65 WTI, ~$3.50 Henry Hub) and Marathon synergies already in numbers. The market is **not** pricing COP as an AI-gas-thesis winner — that premium is being attached to Chevron, EOG, FANG, EQT, and infra/turbine names. If the AI gas thesis is real *and* COP eventually monetizes it via direct deals, current valuation is undemanding because none of that optionality is in consensus. If the AI gas thesis is real but fully priced industry-wide and COP remains a fungible supplier, fair value is roughly here with cyclical risk asymmetric to the downside.

Where I disagree with apparent consensus: the sell side appears to be modeling COP as a commodity proxy with low-single-digit FCF growth and treating LNG optionality and any AI exposure as immaterial. The undermodeled item is Qatar NFE's H2 2026 startup combined with a 1.7 Bcf/d 2027 US LNG export ramp — those are quasi-certain unless project slippage occurs, and the cash flow is high-quality. The over-modeled item, in my read, is implicit confidence that Permian gas takeaway resolves cleanly in H2 2026 — Waha basis remains the single biggest near-term realization risk.

## 90-day falsifiers

Specific, observable events between now (2026-05-10) and 2026-08-10 that would update the thesis:

- **COP Q2 2026 earnings (early August)**: First reference to "AI" or "data center" demand in prepared remarks would signal a strategic narrative shift; absence reinforces commodity-proxy framing.
- **Announcement of direct hyperscaler PPA, midstream JV, or surface-rights deal** by COP. None exists today; one would unlock multiple expansion regardless of underlying economics. Bullish trigger.
- **Waha basis behavior post-Matterhorn full ramp / Blackcomb commissioning (early ramp July 2026 per East Daley)**: If basis remains net-negative >25% of trading days in Q3 2026, the Permian gas thesis is structurally damaged. Bearish.
- **EIA STEO Henry Hub revisions**: A >10% upward revision to 2027 averaging would validate the gas re-rating; a >10% downward revision invalidates the bull narrative.
- **QatarEnergy NFE commissioning updates**: Any further slip beyond H2 2026 hurts the LNG cash-flow ramp directly visible to COP.
- **FERC final colocation framework adoption** by PJM (compliance window starting January 2026 [15]): Restrictive final rules slow the gas-to-AI flow; permissive rules accelerate.
- **GE Vernova H1 2026 guidance update**: Acceleration of 2027–2028 turbine deliveries pulls forward gas-burn demand; deferrals delay it.
- **Comparable peer (EOG/FANG/CVX) data-center announcement scale-ups**: Each additional GW of announced Permian gas-fired data-center power directly increases regional gas demand and tightens basis.

## What I could not verify

- Specific volumetric breakdown of COP gas (Bcf/d) by basin — public materials report combined BOE rather than disaggregated gas.
- Whether COP has any non-public hyperscaler PPA, midstream joint venture, or letter of intent with a data-center developer. Absence in disclosures is suggestive but not dispositive.
- COP short interest as % of float — not surfaced in publicly available summary feeds at retrieval time.
- Whether any portion of COP's existing Permian production is contractually committed to molecules destined for data-center power (e.g., long-term sales agreements with Energy Transfer, Kinder Morgan, or named data-center IPPs).
- EV/NTM revenue calculation — derived from Q1 2026 annualized revenue and estimated net debt rather than a reported figure; treat as an order-of-magnitude estimate.
- Precise reconciliation of the 17.5× vs 23× forward P/E figures cited across sources; likely a 2026 vs 2027-weighted estimate discrepancy I could not resolve.
- Specific cash-flow contribution from the Qatar NFE economic interest (estimate $1.0–1.5B annual quoted as inference).
- Whether the FERC December 2025 colocation order survives any pending rehearing or appellate challenge through Q3 2026.

## Sources

[1] https://www.stocktitan.net/news/COP/conoco-phillips-completes-acquisition-of-marathon-oil-g56ikny1sqf7.html — retrieved 2026-05-10 — established Marathon Oil deal close, $22.5B enterprise value, $1B+ synergies achieved vs $500M initial target
[2] https://naturalgasintel.com/news/whats-next-for-conocophillips-lng-business-after-securing-port-arthur-equity-offtake/ — retrieved 2026-05-10 — established Qatar NFE 25%-of-JV-of-12.5% structure, Port Arthur Phase 1/Phase 2 equity and offtake, H2 2026 NFE start
[3] https://www.wallstreetzen.com/stocks/us/nyse/cop/stock-forecast — retrieved 2026-05-10 — established consensus 1Y PT $123 (and broader range $98–$144), forward P/E ~17.5× citation, EPS consensus $4.93 with $2.60–$7.56 range
[4] https://www.tradingview.com/news/tradingview:9914f10db7105:0-conocophillips-1q-2026-revenue-15-76b-eps-1-78-10-q-summary/ — retrieved 2026-05-10 — established Q1 2026 revenue $15.76B and EPS $1.78
[5] https://www.ogj.com/general-interest/companies/news/55374743/conocophillips-adds-to-permian-basin-capex-in-2026 — retrieved 2026-05-10 — established Q1 2026 production 2,309 Mboed total, Lower 48 1.45 MMboed, basin breakdown (Delaware 698 / Midland 200 / Eagle Ford 367 / Bakken 183 Mboed)
[6] https://en.wikipedia.org/wiki/ConocoPhillips — retrieved 2026-05-10 — established reserves mix 46% petroleum / 34% gas / 14% NGL / 6% bitumen as of 2023 year-end
[7] https://www.conocophillips.com/news-media/story/conocophillips-announces-first-quarter-2026-results-and-quarterly-dividend/ — retrieved 2026-05-10 — established 2026 capex guide $12–12.5B, production guide 2.30–2.33 MMBOE/d, Q1 disclosure
[8] https://247wallst.com/investing/2026/05/04/despite-soaring-46-conocophillips-is-a-hold-as-price-target-trails/ — retrieved 2026-05-10 — established TTM +46% return, "hold as PT trails," YTD 15% context
[9] https://stockanalysis.com/stocks/cop/market-cap/ — retrieved 2026-05-10 — established price $113.87 May 8 close, 52-week range $84.28–$135.87, shares outstanding 1.22B, market cap ~$140B
[10] https://www.hartenergy.com/exclusives/conocophillips-stratagem-permian-bakken-eagle-ford-dominance-205167 — retrieved 2026-05-10 — established $32 WTI average breakeven for Midland/Delaware/Eagle Ford/Bakken, lateral-length cost reductions of ~25% (1→2 mile) and additional 10–15% (3–4 mile)
[11] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — established GE Vernova 80 GW year-end 2025 backlog stretching into 2029, sold-out-through-2030 narrative, ~20% of orders data-center-tied
[12] https://www.eia.gov/todayinenergy/detail.php?id=67004 — retrieved 2026-05-10 — established Henry Hub 2026 $3.67/MMBtu, 2027 $3.59/MMBtu, LNG export ramp +1.3 Bcf/d 2026 / +1.7 Bcf/d 2027; Permian basis and pipeline context from East Daley/RBN sources
[13] https://www.datacenterfrontier.com/hyperscale/article/55276169/crusoe-adds-45-gw-natural-gas-to-fuel-ai-expands-abilene-data-center-to-12-gw — retrieved 2026-05-10 — established Crusoe Abilene 4.5 GW gas via Engine No. 1 JV, 1.2 GW IT campus by mid-2026
[14] https://eastdaley.com/the-burner-tip/chevron-plans-data-center-power-complex-in-permian-supporting-new-basin-demand — retrieved 2026-05-10 — established Chevron 2.5 GW (expandable to 5 GW) West Texas project, FID early 2026, first power 2027; Diamondback JV exploration for on-acreage gas-fired plant; CloudBurst/Energy Transfer 1.2 GW deal
[15] https://introl.com/blog/ferc-pjm-colocation-ruling-data-center-power-plant-guide-2025 — retrieved 2026-05-10 — established FERC December 18 2025 unanimous order to PJM, three new transmission service options, January 2026 compliance start; Talen-Amazon Susquehanna restructuring to grid-connected front-of-meter
[16] https://techblog.comsoc.org/2025/12/22/hyperscaler-capex-600-bn-in-2026-a-36-increase-over-2025-while-global-spending-on-cloud-infrastructure-services-skyrockets/ — retrieved 2026-05-10 — established 2026 hyperscaler capex >$600B (36% YoY increase)
[17] https://markets.financialcontent.com/stocks/article/marketminute-2026-1-9-the-gas-inflection-eog-resources-pivots-toward-ai-and-lng-as-2026-strategy-takes-shape — retrieved 2026-05-10 — established EOG 2026 gas pivot, Encino $5.6B Utica acquisition, Dorado dry-gas development, explicit AI/LNG narrative framing
[18] https://www.utilitydive.com/news/artificial-intelligence-doubles-data-center-demand-2030-EPRI/717467/ — retrieved 2026-05-10 — established EPRI projection of US data centers at 9–17% of national electricity by 2030, ~60% higher than 2-years-prior estimate