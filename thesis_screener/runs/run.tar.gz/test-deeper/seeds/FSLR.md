Both research streams complete. Writing the dossier now.

# FSLR — First Solar, Inc.

## Where this sits in the AI stack
FSLR sits at the **power-generation** layer of the AI infrastructure stack — three layers below the silicon. It physically manufactures CdTe (cadmium telluride) thin-film PV modules at integrated factories in Ohio, Alabama, Louisiana, India, Vietnam and Malaysia. It does not sell to hyperscalers at meaningful scale; modules flow to utility-scale IPPs (NextEra, AES, Lightsource bp, Intersect Power, Engie, Invenergy) which sign 15–20 year PPAs with the hyperscalers [1][27]. AI exposure is therefore second-derivative: data-center load drives PPA demand → IPP module orders → FSLR bookings and ASP. The relevant workload is **bulk grid-scale generation**, not behind-the-meter (where the relevant kit is gas turbines and Bloom fuel cells today).

## Snapshot
- **Price:** $220.81 (2026-05-08 close — markets closed Sun 05-10) [2]
- **Market cap:** $23.6B (~107M shares out) [2]
- **52-week range:** $133.75 – $285.99 [3]
- **Forward P/E:** 12.2× (FY26 consensus EPS $18.04) [4]
- **EV / NTM revenue:** ~4.5–4.8× — n/a from primary source; derived from $23.6B mkt cap, modest net cash, $4.9–5.2B FY26 revenue guide [1]
- **Consensus 12-month PT:** $237.92 (mean, 27 analysts) → ~+8% upside; analyst spread is unusually wide ($150 low / $310 high) reflecting §45X-durability debate [4][5]
- **YTD total return:** –21.8% [2]
- **Short interest (% float):** 11.51% (~2.9× ADV) — elevated [6]

## Moat — what it is physically made of

FSLR's moat is **eight stacked layers**, not one. Most analysts collapse this to "US manufacturing + IRA credits"; that is wrong by reduction.

1. **Vapor Transport Deposition (VTD) process.** Solid CdTe is sublimed and carried in inert gas onto TCO-coated glass moving past the source. Cells are scribed in-situ on the glass — monolithic, no tabbing/stringing. TCO glass enters → laminated/framed/JB'd module exits in **~4 hours on one continuous line** [7][8]. c-Si runs through 3–4 separate plants (poly → wafer → cell → module) over ≥3 days. This is a process-architecture moat, not just a cost moat.

2. **CdSeTe gradient absorber + Cu-doped ZnTe back contact.** Selenium grading at the front interface drops effective bandgap to ~1.45 eV and harvests red photons — the dominant post-Series 6 efficiency lever, patented [9]. The Cu-ZnTe back-contact stack with proprietary anneal/diffusion profile (suppresses shunting) is widely understood to be the trade-secret crown jewel [10]. **Replication estimate: 5–7 years, $1B+ — every credible third-party attempt (Toledo Solar, Calyxo, Reel) wound down**.

3. **Tellurium supply lock-in.** Global refined Te output ~640 t/yr in 2025; China ~80% [11]. FSLR has 5N Plus (Canada, since 2007), Apollo Solar (China, $110M/5yr), and **Rio Tinto Kennecott Utah** — the only US byproduct Te stream commissioned in decades (2022) [12]. At 25 GW/yr FSLR consumes ~1,400–1,650 t Te/yr, which is **2.5× current global supply** [13]. This is both a moat (incumbent has the contracts) and the only physical ceiling on FSLR scaling.

4. **30-year warranty / 0.3%/yr degradation.** Field data going back to 2007. **Perovskite tandems warrant only 10 years**; CdTe is the only thin-film proven at 25-year horizon. In a PPA NPV at 7% discount, the year-25 power generation differential is decisive [8].

5. **US manufacturing footprint.** ~14 GW US nameplate end-2026 (Perrysburg/Lake Township OH ~7 GW + Trinity AL 3.5 GW + Iberia Parish LA 3.5 GW); ~25 GW global with India 3.3 GW, Malaysia/Vietnam ~2.4 GW each; +3.5 GW South Carolina ramp 2027 [14][15]. Greenfield CapEx ~$300M/GW integrated [16]. The closest US-domiciled module competitor — **Hanwha Qcells (Korean parent, Georgia/Dalton)** — is module-assembly only, imports cells.

6. **§45X manufacturing PTC.** $0.07/W on integrated modules, preserved in OBBBA (signed July 4, 2025) [17]. FY26 guide includes **$2.10–2.19B of §45X — i.e., ~40% of revenue is tax credit** [1]. Integrated-component credit terminates Dec 31, 2026; module credit phases down through 2033. FSLR has executed >$2B of 45X transfer deals to date [18].

7. **FEOC alignment.** Treasury Notice 2026-15 (Feb 2026): 40% non-Prohibited-Foreign-Entity manufactured-product threshold effective Jan 1 2026, rising 5 pp/yr to 60% by 2030; applies to 45Y/48E/45X [19]. Stacks on top of April 2025 AD/CVD final tariffs on Cambodia (AD 125%/CVD 3,404%), Vietnam (271%/542%), Thailand (203%/800%), Malaysia (81%/169%) [20]. FSLR's CdTe supply chain has no PRC dependency by construction.

8. **Closed-loop recycling.** Recovers ~90% of semiconductor (Cd+Te) + ~95% of total module mass; only PV maker running this at scale [8]. Eases the Te ceiling and increasingly matters for state/EU procurement.

**Durability assessment.** Most durable: (1)(2)(3)(4)(8) — process IP, materials science, supply contracts, field data, recycling. Policy-dependent: (6)(7) — both could move with Congress, though OBBBA already locked 45X under Trump. Quasi-durable: (5) — replicable but takes 3–5 yrs and $300M/GW per integrated line.

## AI buildout bottleneck map

The 24-month gating constraints and FSLR's position relative to each:

| Bottleneck | Reality (May 2026) | FSLR position |
|---|---|---|
| Gas-turbine generation | GE Vernova backlog **100 GW** Q1 2026 (vs 83 GW year-end 2025); lead times 4–5 yrs; sold out through 2030; CCGT capex up from <$1,500/kW (2023) to $2,157/kW (2024); turbine equipment +195% [21] | **Direct beneficiary** — solar+storage is the only deployable bulk power in <24 months in ERCOT/PJM |
| Grid interconnect queue | ERCOT 432 GW pending (158 GW solar, 176 GW battery, 48 GW gas); PJM 220 GW (106 gas, 67 storage, 18 nuclear, 15 solar) [22][23] | **Exposed customer** — interconnect is a hard ceiling regardless of module supply |
| Tellurium supply | 640 t/yr global; FSLR needs ~1,400–1,650 t at 25 GW/yr [11][13] | **Constraint owner** — managed via Kennecott + 5N Plus + recycling |
| US wafer/cell capacity (for c-Si FEOC compliance) | Virtually none at scale [19] | **Structural beneficiary** — already integrated US silicon → module |
| CoWoS-L, HBM3e, optical, liquid cooling >100 kW/rack | Various binding constraints on the silicon side | **Indifferent** |
| EPC / electrical labor | Utility-scale solar EPC labor tightening | **Exposed customer** — delays project COD, degrades ASP |

The bottleneck story is unusually clean: **gas-turbine shortage is forcing hyperscaler PPA flow into solar**, the FEOC/AD-CVD policy stack is forcing that flow into US-domestic modules, and FSLR is the only at-scale fully-integrated US module supplier with a non-PRC supply chain. S&P Global (Mar 2026) ran a 627-MW West Texas data-center case: dedicated CCGT 20-yr cost $2.9B vs solar+battery $6.2B — gas still cheaper in absolute, but turbines are not available, so hybrid is the practical winner [24].

## Competitive teardown

**vs Chinese c-Si TOPCon/HJT (Jinko, LONGi, Trina, JA).** Nameplate efficiency advantage: mass-production TOPCon 23.5–23.8% (Jinko Tiger Neo 23.69%); LONGi BC 24.7%; Jinko TOPCon **cell** record 27.79% Nov 2025 [25][26]. Series 7 module ~19.7%. **Chinese c-Si is 4–5 pp ahead on nameplate.** Cost: China FOB $0.086–0.112/W vs FSLR $0.30/W list. Energy-yield gap closes to 0–2 pp in hot/humid climates due to CdTe's better temperature coefficient (~–0.32%/°C vs c-Si TOPCon –0.30 to –0.34%/°C; gap narrowed materially with TOPCon) and wider 1.45 eV bandgap [16]. **What changes the picture:** Treasury softens FEOC interpretation, or tariff carve-outs. Probability low–medium given current enforcement bias.

**vs Hanwha Qcells.** The most underappreciated direct US competitor and the only real threat on the "US-domestic module" axis. Qcells **won Microsoft's 12 GW direct module deal in Jan 2024** [27] — the kind of deal absent from FSLR's order book. However: Qcells is assembly-only on US soil, imports cells from Korea/Malaysia, more vulnerable to FEOC supply-chain depth tests. FSLR has the integrated-component §45X bonus, 30-yr warranty, and depth of energy-yield data. **Net: Qcells will take a share of hyperscaler-direct deals; FSLR keeps the IPP-mediated channel.**

**vs perovskite tandems (Oxford PV, Caelux).** Oxford PV shipped first commercial perovskite/Si tandems at 24.5% in Sep 2024; 25% commercial now; 26% target 2026; Fraunhofer ISE Jan 2024 validated 25% full-size tandem [28][29]. Warranty: 10 years vs FSLR 30. Stability: Nature Comms 2025 documented rapid thermal-cycling damage in wide-bandgap perovskite; ISOS-L2 1,400 h at 85°C maps to ~26 months in Phoenix-equivalent field [30]. **Timeline to displacement: 5–10 years iff perovskite tandems pass IEC 61215 with a 25-year warranty at scale.** Base rate: CFL→LED took ~7 years from commercial parity to dominance; NiMH→Li-ion ~5 years. Platform-level tech displacement is typically faster than incumbents expect. FSLR's defense is its own perovskite-on-CdTe roadmap (acquired Evolar 2023 for ~$80M+$42M earnout) — be the leader of the tandem path, not the displaced incumbent.

**vs CIGS.** Effectively moribund. Avancis at 20.3% on 30×30 cm aperture; no GW-scale; BIPV-only.

## Bull case — technical

**Base rate.** Established commercial PV with 25-year warranted field data, scale CapEx, and policy alignment typically resists displacement for 5–10 years past competitor commercial parity. Perovskite tandems are 1–2 years from nameplate parity but **>5 years from 25-year warranted parity.** This is the window FSLR controls.

Conditions that have to hold:
1. US data-center load grows ≥250 TWh by 2030 (mid LBNL 325–580 TWh range) [31].
2. Gas-turbine waitlists hold through 2030 (GE Vernova/Siemens current guidance) [21].
3. FEOC enforcement holds (Treasury Notice 2026-15 finalized without softening) [19].
4. FSLR maintains $0.30+/W blended ASP through 2026–2028 backlog conversion [1].
5. Te supply ceiling does not bind below 25 GW/yr (achievable via Kennecott + 5N Plus + recycling) [11][12][13].
6. No perovskite tandem ships 25-year warranted product before 2030 [28][29][30].

**Financial outcome.** If FY27 EPS reaches ~$24–28 (consensus midpoint), 13–15× P/E (still discount to S&P, reflects ongoing policy uncertainty) → $310–420. **+40–90% over 18–24 months from current $220.**

## Bear case — technical

Written from a short-seller who understands the stack:

1. **Bookings are lagging shipments.** Q1 2026: gross bookings 1.7 GW, debookings 0.1 GW, shipments 3.8 GW. **Backlog shrank from 50.1 GW (year-end 2025) to 47.9 GW in one quarter** [1]. FY25 had **8.3 GW of customer debookings** (vs 7.4 GW gross) — the backlog is being marked-to-market downward in real time as IPP projects fail to FID.
2. **48E ITC begin-construction cliff.** Projects must begin construction by July 4, 2026 OR be placed in service Dec 31, 2027 [17]. IPPs will pull forward 2026–2027 demand and leave 2028–2029 gapped. Backlog conversion rate accelerates short-term, then drops off a cliff.
3. **Perovskite tandems pass IEC 61215 with 20-yr warranty by 2028.** FSLR's efficiency gap (4–5 pp on nameplate) becomes hard to justify at a $0.35/W premium when the competitor has a 25-yr warranty.
4. **Treasury softens FEOC.** "Foreign-Influenced Entity" interpretation is currently interim; project-by-project waivers are possible. Chinese-cell modules re-enter the credit-bearing pipeline.
5. **§45X trimmed in late-stage tax negotiations.** Per-W margin compresses from $0.13/W gross to <$0.07/W. The ~40% of revenue that is tax credit is at policy risk.
6. **Te byproduct supply tightens** (Cu refinery curtailment in Chile/Peru). FSLR ASP-realized falls via input cost.

The strongest factual short point is (1) — the **Q1 2026 8.8 pp YoY gross-margin expansion is 100% policy-driven (§45X), not pricing-driven. Strip out 45X and the underlying ASP/COGS trajectory is flat to deteriorating.**

## Market view check

At ~$220, ~12× FY26 EPS, EV/NTM revenue ~4.5×, the market is implicitly pricing: FY26 hits guide (likely — 45X is rules-based); FY27 EPS modestly above FY26 (low growth); backlog walks down further; no material §45X change; and **no** material hyperscaler-direct deal. The wide analyst spread ($150–$310) means consensus is masking a bimodal distribution: §45X durable + bookings recover → fair value $280–310; §45X trimmed or bookings continue lagging → fair value $150–180. **Net read:** stock is slightly cheap if bookings stabilize in H2 2026 AND FEOC enforcement holds. The price is internally consistent with a market that has stopped believing the multi-year-backlog-equals-multi-year-visibility narrative — and that is the right thing to skeptical about. The substrate analysis above suggests the market is **underweighting the gas-turbine bottleneck** (which makes solar non-substitutable for 24+ months) and **overweighting the bookings-gap signal** (which partly reflects IPPs waiting for FEOC clarity, not fundamental demand softness).

## 90-day falsifiers

1. **Q2 2026 earnings (~late July).** Gross bookings <2 GW for the 2nd consecutive quarter = bear thesis confirmed. >3.5 GW = backlog refilling, bull case.
2. **Treasury final FEOC guidance (Notice 2026-15 finalization, expected mid-2026).** Any expansion of "Foreign-Influenced Entity" definition or material-assistance scope = positive; any softening or project-by-project waiver mechanism = negative.
3. **GE Vernova Q2 earnings (~late July).** Gas-turbine backlog stays >95 GW + lead times >4 yrs → solar bull intact. Softening or hyperscaler SMR scale-up announcement → marginal pressure.
4. **NextEra Q2 update.** NEE solar backlog growth >2 GW = direct positive read-through (NEE is FSLR's largest counterparty) [32].
5. **Oxford PV / Caelux 25-year warranted product announcement.** Direct catalyst on the perovskite displacement timeline.
6. **Named hyperscaler direct module deal.** Microsoft/Google/Meta/AWS taking direct FSLR supply of >2 GW = structural validation. Absence = continued IPP-mediated pattern.
7. **§45X reconciliation amendments / OBBBA technical corrections.** Any softening of integrated-component credit phase-down (currently Dec 31, 2026) = material negative.
8. **ERCOT 2026 summer load event.** Forced curtailment or grid stress that biases hyperscaler siting away from TX → hit to FSLR's largest end-market.

## What I could not verify
- Named hyperscaler counterparty for Q1 2026's 1.4 GW US bookings (none disclosed; itself a notable absence).
- Specific kWh/kWp delta vs c-Si TOPCon in named geographies (Phoenix, Riyadh, India) in 2025/2026 field-data publication — DOE/SETO documents only the mechanisms [16].
- Volume and $/t economics at Rio Tinto Kennecott's Te recovery stream.
- Series 7 first-year degradation rate specifically (only Series 6 historical data published).
- FSLR's perovskite-on-CdTe tandem internal efficiency / commercialization timeline post-Evolar acquisition.
- Q2 2026 forward indicators (Q1 reported; Q2 in-flight).
- Exact end-2026 global nameplate GW (FSLR press releases give ~25; specific country breakdown estimated from prior disclosures).
- EV/NTM revenue multiple — derived, not from primary source.

## Sources
[1] https://www.fool.com/earnings/call-transcripts/2026/04/30/first-solar-fslr-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1 2026 earnings transcript: backlog, ASP, §45X detail, bookings/debookings
[2] https://finance.yahoo.com/quote/FSLR/ — retrieved 2026-05-10 — price, market cap, shares outstanding
[3] https://stockanalysis.com/stocks/fslr/history/ — retrieved 2026-05-10 — 52-week range
[4] https://public.com/stocks/fslr/forecast-price-target — retrieved 2026-05-10 — FY26 consensus EPS
[5] https://www.marketbeat.com/stocks/NASDAQ/FSLR/forecast/ — retrieved 2026-05-10 — analyst PT range and recent revisions
[6] https://fintel.io/ss/us/fslr — retrieved 2026-05-10 — short interest as % of float
[7] https://docs.nrel.gov/docs/fy23osti/85320.pdf — retrieved 2026-05-10 — NREL CdTe / VTD process technical detail
[8] https://www.firstsolar.com/en/Products/Series-7 — retrieved 2026-05-10 — Series 7 efficiency, temp coefficient, degradation, warranty
[9] https://www.power-technology.com/data-insights/first-solar-files-patent-for-method-for-forming-photovoltaic-structure-with-cdsete-absorber-layer/ — retrieved 2026-05-10 — CdSeTe patent
[10] https://scijournals.onlinelibrary.wiley.com/doi/10.1002/ese3.843 — retrieved 2026-05-10 — Cu-ZnTe back contact stack review
[11] https://pubs.usgs.gov/periodicals/mcs2026/mcs2026-tellurium.pdf — retrieved 2026-05-10 — USGS MCS 2026: global Te production
[12] https://www.metaltechnews.com/story/2022/09/12/critical-minerals-alliances-2022/first-solar-powers-new-tellurium-demand/1082.html — retrieved 2026-05-10 — Rio Tinto Kennecott Te recovery
[13] https://www.sciencedirect.com/science/article/pii/S2542435125004167 — retrieved 2026-05-10 — Joule "Roadmap to 100 GW CdTe": Te per GW intensity
[14] https://www.businesswire.com/news/home/20260430224118/en/First-Solar-Inc.-Announces-First-Quarter-2026-Financial-Results-and-Reaffirms-Guidance — retrieved 2026-05-10 — Q1 2026 press release: 47.9 GW / $14.4B backlog
[15] https://pv-magazine-usa.com/2026/05/01/first-solar-reaffirms-2026-guidance-as-cure-launch-and-record-india-sales-drive-q1-margin-expansion/ — retrieved 2026-05-10 — capacity breakdown and India sales detail
[16] https://www.energy.gov/sites/default/files/2025-01/DOE%20SETO%20CdTe%20Photovoltaics%20Perspective%20Paper.pdf — retrieved 2026-05-10 — DOE/SETO CdTe perspective: efficiency, temp coefficient, CapEx
[17] https://www.millerchevalier.com/publication/obbba-brings-45x-changes-though-not-wholesale-repeal — retrieved 2026-05-10 — OBBBA §45X preservation and phase-down
[18] https://www.pv-tech.org/first-solar-45x-tax-credit-deals-reach-2billion/ — retrieved 2026-05-10 — FSLR 45X transfer deals to date
[19] https://www.projectfinance.law/publications/2026/february/new-feoc-guidance-notice-2026-15/ — retrieved 2026-05-10 — Treasury Notice 2026-15 FEOC guidance
[20] https://www.trade.gov/press-release/us-department-commerce-announces-final-determinations-antidumping-and-countervailing — retrieved 2026-05-10 — April 2025 AD/CVD final determinations
[21] https://www.utilitydive.com/news/ge-vernova-gas-turbine-backlog-hits-100-gw-as-prices-rise/818332/ — retrieved 2026-05-10 — GE Vernova gas-turbine backlog 100 GW Q1 2026
[22] https://www.ercot.com/files/docs/2025/11/17/ERCOT-Monthly-Operational-Overview-October-2025.pdf — retrieved 2026-05-10 — ERCOT generation queue composition
[23] https://www.utilitydive.com/news/pjm-interconnection-queue-gas-solar-nuclear/818824/ — retrieved 2026-05-10 — PJM 2025 reformed queue composition
[24] https://www.spglobal.com/market-intelligence/en/news-insights/research/2026/03/data-center-power-combined-cycle-plant-outperforms-solar-plus-battery — retrieved 2026-05-10 — 627 MW Texas data-center economic case CCGT vs solar+battery
[25] https://taiyangnews.info/topmodules/monthly-top-modules-update/top-solar-modules-listing-december-2025 — retrieved 2026-05-10 — Top mass-production module efficiencies Dec 2025
[26] https://www.pv-magazine.com/2025/11/27/jinkosolar-achieves-world-record-efficiency-of-27-79-for-topcon-solar-cell/ — retrieved 2026-05-10 — JinkoSolar 27.79% TOPCon cell record
[27] https://www.utilitydive.com/news/hanwha-qcells-microsoft-expand-solar-panel-supply-partnership-cartersville-georgia/703949/ — retrieved 2026-05-10 — Microsoft–Qcells 12 GW direct module deal Jan 2024
[28] https://www.pv-tech.org/oxford-pv-ships-first-commercial-perovskite-tandem-modules/ — retrieved 2026-05-10 — Oxford PV first commercial perovskite tandem shipment
[29] https://www.ise.fraunhofer.de/en/press-media/press-releases/2024/oxford-pv-and-fraunhofer-ise-develop-full-sized-tandem-pv-module-with-record-efficiency-of-25-percent.html — retrieved 2026-05-10 — Oxford PV / Fraunhofer ISE 25% tandem module
[30] https://www.nature.com/articles/s41467-025-68219-w — retrieved 2026-05-10 — Nature Comms 2025 perovskite thermal-cycling stability
[31] https://eta-publications.lbl.gov/sites/default/files/2024-12/lbnl-2024-united-states-data-center-energy-usage-report_1.pdf — retrieved 2026-05-10 — LBNL US data-center load 2023→2028 forecast
[32] https://pv-magazine-usa.com/2026/04/23/nextera-energy-adds-record-4-gw-of-renewables-and-storage-backlog-in-q1/ — retrieved 2026-05-10 — NextEra Q1 2026 4 GW backlog addition