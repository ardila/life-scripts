# PPL — PPL Corporation

## Where this sits in the AI stack
PPL is a regulated electric and gas utility holding company — it sits at the **power delivery** layer beneath the AI stack, not in silicon, software, or generation. Its three operating subs are PPL Electric Utilities (Pennsylvania, **wires-only transmission and distribution** to 1.5M customers across 29 counties including the Lehigh Valley, Harrisburg, Lancaster, and Scranton-Wilkes-Barre [1][7]), LG&E and KU (Kentucky, **vertically integrated** with ~7,500 MW of owned generation, historically ~84% coal [4][14]), and Rhode Island Energy (wires) [7]. PPL's "AI exposure" is therefore not generation merchant — it is the **build-rate on T&D infrastructure** that physically interconnects new hyperscaler load and new front-of-the-meter generation in central/eastern Pennsylvania, plus a recently-launched 51%-owned unregulated JV with Blackstone Infrastructure to build gas-fired generation specifically for data centers [5].

## Snapshot
- **Price:** $34.25 (May 8, 2026 close) — note: $36.77 on May 7, 2026; shares fell on earnings day despite a beat [1]
- **Market cap:** ~$27.1B [12]
- **52-week range:** $33.12 – $40.11 [1]
- **Forward P/E:** 17.7× (on FY26 ongoing EPS midpoint $1.94) [1][13]
- **EV / NTM revenue:** ~4.7× (EV $44.7B [12] / NTM revenue ~$9.5B implied from $9.04B FY25 [13])
- **Consensus 12-month price target:** $41.91 (implied +22% from $34.25); range $34 (Barclays/Campanella) to $45 (Wells Fargo/Pourreza); 11 analysts, Buy consensus [11]
- **YTD total return:** n/a — could not retrieve clean YTD figure; share price is within ~3% of 52-week low, suggesting a flat-to-down YTD against a defensive utility tape
- **Short interest (% of float):** n/a — not retrieved
- **Dividend yield:** 2.97% on $1.09 annualized [12]

## Moat — what it is physically made of
The "moat" in regulated utilities is usually a generic appeal to franchise monopoly. For PPL specifically, decompose it:

**(1) Geographic franchise / right-of-way inventory in central-eastern PA.** PPL Electric's 29-county footprint sits on top of the Marcellus/Utica shale, has existing 500 kV corridor capacity (e.g. the 2015 Susquehanna–Roseland 500 kV line into PSE&G [15]), and physically contains the Susquehanna nuclear plant (Salem Township, Luzerne County, ~2.5 GW, owned by Talen [9]). Franchise rights, easements, and substation siting are exclusive within the territory and effectively non-replicable — Dominion in NoVA is the only comparable franchise asset in PJM. This is durable on a 20-year horizon absent state-level municipalization, which is politically infeasible.

**(2) "Wires-only" structure in PA.** Because Pennsylvania is a deregulated retail-choice state, PPL **does not own generation** in PA (spun out as Talen Energy in 2015 [7]). For an AI investor, this is mechanically important: PPL earns regulated ROE on every transformer, every substation, every kV of transmission built to connect data center load and new generation — without bearing **commodity price, fuel, capacity-market, or stranded-asset risk** on the generation itself. PJM 2027/28 capacity cleared at the FERC cap of $333.44/MW-day [3] — that pain accrues to retail suppliers and ratepayers, not to PPL.

**(3) Kentucky vertical integration with constructive PSC.** LG&E/KU's 7.5 GW fleet is regulated cost-of-service; the PSC just approved retirement of 600 MW coal plus ~640 MW new gas combined-cycle and 1,000+ MW of solar/storage at 9.775% authorized ROE [4][14]. A second 1.3 GW gas block was approved specifically to serve data center load [4]. This is rate-base earning at moderate ROE — durable but not exciting; the more interesting question is whether Kentucky can attract the same hyperscaler interest PA does (smaller pipeline at ~8 GW signed [10]).

**(4) Blackstone JV (the only "non-utility" leg).** Front-of-the-meter combined-cycle plants sited on top of Marcellus pipeline. 51% PPL / 49% Blackstone. **No hyperscaler ESA signed as of mid-2025 disclosure; earliest COD 2030** [5]. This is real option value, not a current cash-flow moat — and it depends entirely on GE Vernova turbine slot availability, which is the limiting reagent (see below).

What the moat is **not**: it is not technology, software, or anything you would call switching costs in the usual sense. It is locational and regulatory. A competitor cannot rebuild PPL's PA T&D position; they also cannot replicate it elsewhere, but neither can PPL extend it beyond its franchise.

## AI buildout bottleneck map
Stating the actual gating constraints and where PPL sits on each:

- **Large power transformers (LPTs, 230 kV / 500 kV):** US lead times now 128 weeks, stretching to 5 years for HV data-center-grade units; Wood Mackenzie projects 30% power-transformer deficit, 10% distribution-transformer deficit in 2026 [6]. **PPL is an exposed customer.** This is the single most underappreciated risk to PPL's $23B capex plan executing on schedule. Capex plan slippage compresses near-term EPS even if rate base ultimately grows.
- **GE Vernova heavy-duty gas turbines:** Combined backlog + slot reservations 100 GW and rising to ~110 GW by YE26; **CEO expects fully sold out through 2030 by end of 2026** [8][16]. Production ramping 20 GW/yr by Q3 2026, 24 GW/yr by 2028. **PPL is an exposed customer via the Blackstone JV** and via the Kentucky 1.3 GW gas build [4][5]. The JV publicly says it is "engaged with turbine manufacturers" but the disclosure that no ESAs have been signed [5] combined with the turbine queue suggests realistic CODs slip to 2030–2031.
- **PJM interconnection queue and capacity prices:** ~30 GW left in the transition queue to be processed in 2026; new applications gated until Cycle #1 in April 2026 [2]. Capacity cleared at the FERC cap of $333.44/MW-day for 2027/28 [3]. **PPL is a beneficiary of the bottleneck** — high capacity prices accelerate hyperscaler willingness to fund interconnection upgrades on PPL's wires (CIAC and minimum-take contracts).
- **PA PUC large-load tariff framework (adopted Nov 2025, finalized 2026):** Applies to customers ≥50 MW individually or ≥100 MW aggregate; mandates contributions-in-aid-of-construction, tiered collateral, minimum contract terms [17]. **PPL is the direct beneficiary** — the framework shifts cost risk to hyperscalers and reduces stranded-cost exposure for PPL's existing ratepayer base. This is the single most important regulatory tailwind a sell-side note would underweight.
- **Power generation (PA specifically):** PPL forecasts 6 GW generation **shortfall** in its own service territory over 5–6 years if advanced-stage projects materialize [10]. **PPL is positioning as a constraint owner** (via the JV) but the supply will lag by years.
- **Skilled electrical contractor / lineman labor:** Generic capex execution risk. **Exposed customer.** PA's electrical apprenticeship pipeline is the practical pacing item once steel-on-site begins.

## Competitive teardown
Specifically, on which axis:

- **Talen Energy (TLN) — generation, in PPL's footprint.** Owns the 2.5 GW Susquehanna nuclear plant inside PPL Electric's territory. The FERC behind-the-meter rejection (Nov 2024, upheld April 2025) [9] is **structurally favorable to PPL** because it pushes the AWS load front-of-the-meter, which requires PPL's transmission. Talen is not a competitor to PPL on T&D; it is functionally a customer/supplier on PPL's wires whenever the behind-the-meter path is blocked.
- **Constellation (CEG) — nuclear merchant.** 20-year PPAs with Microsoft (Crane / TMI Unit 1 restart, 835 MW) and Meta (Clinton, 1.1 GW) [10]. Constellation does not compete with PPL — it competes for the hyperscaler PPA dollar, but its plants are in different ISOs and footprints. The risk to PPL is **substitution at the hyperscaler decision**: if AWS, Microsoft, Meta increasingly route to existing-nuclear PPAs rather than new gas-fired front-of-the-meter, PPL's Blackstone JV addressable market shrinks. PPL's T&D earnings are largely insensitive to this.
- **Vistra (VST) — gas + nuclear IPP.** Meta deal for 2.1 GW from Beaver Valley (PA) + Perry/Davis-Besse (OH) [10]. Beaver Valley is **inside** the PJM Western footprint but **outside** PPL Electric's territory (FirstEnergy's Penelec/West Penn). Vistra is a substitute for PPL's JV proposition, not for the regulated T&D.
- **AEP, FirstEnergy, Dominion, Exelon (ComEd/PECO):** Each has its own data center exposure in PJM. Dominion (Virginia / Loudoun) is the structurally largest, but PA is the structurally fastest-growing because Marcellus gas + nuclear are physically present. AEP-Ohio and FirstEnergy-Penelec have material pipelines too but smaller advanced-stage signed pools than PPL's 14 GW [10].
- **What would have to be true for a competitor to take share from PPL:** Effectively nothing, because PPL's "share" is its franchise territory — it is not a contestable market. The real risk is **demand shifting to other ISOs** (ERCOT 233 GW queue [2], MISO, Quebec, behind-the-meter campuses on private power). That is an addressable-market risk, not a market-share risk.

Honest read: **PPL's franchise is durable on a 5–10 year horizon; the question is the size of the demand cone landing on it, not who else captures it.**

## Bull case — technical
For PPL to outperform from $34, the following technical conditions need to hold over 12–24 months:

1. **PA data-center pipeline conversion rate stays high.** The 28 GW signed-agreement number must convert to ≥10 GW of energized ESAs by YE2026 [10][13]; CEO Sorgi's Q1 2026 claim that "all 25.2 GW have a high probability of completion" needs to be partially validated by hyperscaler announcements in PA over the next few quarters. Base rate: in past T&D buildouts (cloud era 2014–2020 NoVA, west-Texas wind 2010s) typical conversion of advanced-stage pipeline to in-service load runs 50–70% over 3–5 years. If PPL converts even 60% of 28 GW into rate-based interconnection capex, this drives the $500M+ of upside CapEx beyond the current $23B plan [13] and likely a second upward revision.
2. **Transformer and turbine bottlenecks remain binding for competitors but PPL has been queue-jumping.** PPL's $850M grid push [10] and earlier turbine slot commitments need to be honored on schedule. If they slip materially, the rate-base ramp slows.
3. **PA general rate case lands at or near 11.3% requested ROE effective July 1, 2026** [11][14]. This is structurally above the regulated-utility median (~9.5–10%) and would compound the 10.3% rate-base CAGR into upper-end 8% EPS CAGR.
4. **Blackstone JV signs ≥1 hyperscaler ESA in 2026.** Optional alpha. Would re-rate the stock as the market begins to price PPL as an integrated PA infrastructure platform rather than a pure regulated utility.

Base rate on technology displacement at this stage: utility T&D franchises have been displaced exactly **zero** times in the post-1935 PUHCA era except by acquisition. The downside scenario is not "PPL gets disrupted" — it is "the demand doesn't show up." Different falsifier.

## Bear case — technical
The version a short-seller who reads the stack would write:

1. **The 28 GW pipeline is a sell-side mirage of signed *intent*, not contracted MW.** Only "≥10 GW under ESAs by end of Q1 2026" and 5 GW under construction were disclosed [10][13]; the gap between announced pipeline and energized load in NoVA from 2021–2024 ran roughly 3:1 by some teardowns. If hyperscalers reroute to ERCOT (233 GW queue [2]), MISO, or private power islanded campuses (Stargate, Meta Hyperion in Louisiana, xAI Memphis) faster than PPL's rate-base ramps, the $23B plan partially de-rates and the multiple compresses.
2. **Forward P/E 17.7× is already pricing the upside.** The regulated-T&D-only fair multiple historically runs 14–16× forward EPS for high-quality names. PPL is trading at a ~2-turn premium to the regulated peer median on the strength of the data-center narrative. If the narrative doesn't accelerate, you get multiple compression even on flat EPS.
3. **The Blackstone JV is non-rate-base, non-utility, and exposed to gas turbine queue + PA permitting + falling AI training capex.** No ESA signed [5]. If AI training capex peaks in 2026–2027 (a real possibility — Stargate, Anthropic/AWS, Google TPU buildouts are largely placed; inference is increasingly more compute-efficient and shifts toward purpose-built ASICs at lower W/token), then 2030+ COD gas plants are exposed to overbuild risk. Blackstone takes 49% of that.
4. **PA PUC large-load framework could harden.** Today voluntary, with CIAC and minimum-term provisions [17]. If it becomes mandatory and the CIAC ratchet rises, hyperscalers may push back on capex contributions, slowing interconnection sign-ups and stretching PPL's recovery profile.
5. **Transformer / labor / contractor capacity:** PPL is exposed to the same 128-week LPT lead time as everyone else [6]. The $23B plan assumes execution. Slipping a year of capex compresses near-term EPS and pushes the 10.3% rate base CAGR toward the low 8s.
6. **The Talen-AWS FERC saga creates regulatory precedent risk in *either* direction.** If a future FERC reverses and allows expanded behind-the-meter at Susquehanna, hyperscaler load bypasses PPL's wires entirely. This is currently a tail risk because the November 2024 and April 2025 rulings both went against Talen [9], but the underlying litigation is unresolved.

## Market view check
At $34.25, PPL trades at 17.7× forward EPS — about a 2-turn premium to the regulated-utility median, with a 10.3% rate-base CAGR baked into management's plan and consensus targeting ~$42 (+22%) [11]. The market is **partially pricing the data-center narrative** but is also clearly **not** pricing the upper-end scenario: if you believed all 28 GW converts to rate-based interconnection capex with 11.3% ROE in PA and the Blackstone JV signs a hyperscaler ESA, the appropriate multiple is closer to 20–22× and the stock would be in the high $40s. The market is pricing roughly "this works, but slowly and with execution risk" — which is approximately the correct technical assessment. The mispricing question is asymmetric: the upside requires execution on a known plan; the downside requires demand to shift to other ISOs (a structural negative for all PJM-exposed names, not PPL-specific). I read the risk/reward as moderately favorable but **not** the kind of asymmetric pricing dislocation that defines a high-conviction long.

## 90-day falsifiers
Specific, observable, dated:

1. **PA general rate case ruling** (rates effective July 1, 2026): does PA PUC approve at or near the 11.3% requested ROE? An approval at <10.5% would be a clear bear signal [14].
2. **PA PUC final order on large-load tariff framework** (expected mid-2026): does the CIAC and minimum-term structure stay as proposed in the November 2025 tentative order, or get watered down at hyperscaler request [17]?
3. **Q2 2026 earnings (~early August):** confirmation that ≥10 GW of ESAs were actually signed by end of Q1 [10][13]; signed-pipeline number — if it stays flat or declines vs Q1's 28.3 GW, the narrative cracks.
4. **Blackstone JV ESA announcement:** any signed hyperscaler offtake announcement in the next 90 days would be a meaningful positive re-rating catalyst.
5. **GE Vernova Q2 2026 earnings**: any disclosure of accelerated turbine slot deliveries to PPL or the JV; conversely any slip [8][16].
6. **Talen-FERC litigation update**: any movement in the rehearing or D.C. Circuit court case [9] that signals FERC may eventually permit expanded behind-the-meter Susquehanna load — would be modestly negative for PPL's transmission rate base.
7. **Hyperscaler PA-to-other-ISO migration**: any high-profile cancellation of a previously announced PA data center in favor of ERCOT/MISO/private power. AWS, Microsoft, Google, Meta press releases should be monitored.

## What I could not verify
- Exact YTD 2026 total return for PPL (price data was inconsistent across sources between May 7 and May 8 closes).
- Short interest as % of float (not retrieved).
- The granular PA T&D vs Kentucky vs Rhode Island vs JV breakdown of the $23B capex plan — Utility Dive only gave the +$2B transmission, +$500M KY hardening, +$300M PA hardening deltas, not the absolute splits [13].
- Specific transformer and turbine slot commitments PPL has actually secured vs. competitors. PPL's investor materials reference engagement but do not disclose contracted MW of turbines or named LPT vendors.
- Whether the FERC Talen-AWS D.C. Circuit appeal has a hearing date or expected ruling timeline in 2026.
- Whether any of the "≥10 GW ESAs by end of Q1 2026" target was actually missed (the Q1 transcript references the goal but I did not find post-quarter confirmation).
- The actual contracted ROE PPL is earning in PA today (the 11.3% is the request for the new test year, not the current authorized).

## Sources
[1] https://finance.yahoo.com/quote/PPL/ — retrieved 2026-05-10 — current/recent close, 52-week range, market data
[2] https://www.pjm.com/-/media/DotCom/about-pjm/newsroom/fact-sheets/interconnection-reform-progress-fact-sheet.pdf — retrieved 2026-05-10 — PJM interconnection queue status, transition queue size, Cycle #1 timing
[3] https://insidelines.pjm.com/pjm-auction-procures-134479-mw-of-generation-resources/ — retrieved 2026-05-10 — PJM 2026/27 and 2027/28 capacity auction clearing prices, data-center-driven load increase
[4] https://www.utilitydive.com/news/ppl-kentucky-psc-lge-ku-gas-plant/756408/ — retrieved 2026-05-10 — Kentucky PSC approval of 1.3 GW gas-fired generation for data center load, coal retirement timing
[5] https://investors.pplweb.com/2025-07-15-PPL-Corporation-and-Blackstone-Infrastructure-create-joint-venture-to-build-natural-gas-generation-in-Pennsylvania-in-support-of-data-center-development — retrieved 2026-05-10 — PPL/Blackstone JV terms (51/49), Marcellus siting, no signed ESAs at announcement
[6] https://www.powermag.com/transformers-in-2026-shortage-scramble-or-self-inflicted-crisis/ — retrieved 2026-05-10 — Large power transformer 128-week lead times, WoodMac 30% deficit forecast, data center delay rates
[7] https://en.wikipedia.org/wiki/PPL_Corporation — retrieved 2026-05-10 — Corporate structure, 2015 Talen spinoff, three operating utilities, customer count
[8] https://www.utilitydive.com/news/ge-vernova-gas-turbine-backlog-hits-100-gw-as-prices-rise/818332/ — retrieved 2026-05-10 — GE Vernova 100 GW combined backlog + slot reservations, sold-out-through-2030 trajectory
[9] https://www.utilitydive.com/news/ferc-interconnection-isa-talen-amazon-data-center-susquehanna-exelon/731841/ — retrieved 2026-05-10 — FERC rejection of Talen-AWS expanded behind-the-meter ISA, AEP/Exelon opposition, rehearing denial
[10] https://www.utilitydive.com/news/ppl-electric-data-center-pennsylvania-pjm/756548/ — retrieved 2026-05-10 — 60 GW total PA interest, 14 GW advanced-stage, 6 GW generation shortfall projection
[11] https://www.marketbeat.com/stocks/NYSE/PPL/forecast/ — retrieved 2026-05-10 — Analyst price targets, $34–$45 range, Buy consensus, 11 analysts
[12] https://stockanalysis.com/stocks/ppl/statistics/ — retrieved 2026-05-10 — Market cap $27.1B, EV $44.7B, dividend $1.09, shares outstanding 739.5M
[13] https://www.utilitydive.com/news/ppl-capx-spending-plan-data-center-earnings/812813/ — retrieved 2026-05-10 — $23B capex plan, +$2B transmission, 10.3% rate-base CAGR, $500M upside beyond plan
[14] https://filecache.investorroom.com/mr5ir_pplweb2/1287/PPL_2025_Q4_Investor_Update_FINAL.pdf — retrieved 2026-05-10 — PA 11.3% ROE request, Kentucky 9.775% authorized ROE, rate-base detail
[15] https://news.pplweb.com/2015-05-11-PPL-Electric-Utilities-Completes-Susquehanna-Roseland-Transmission-Line — retrieved 2026-05-10 — 500 kV Susquehanna-Roseland line, 101-mile PA portion, PJM congestion relief
[16] https://www.power-eng.com/gas/turbines/data-centers-drive-record-surge-in-ge-vernova-power-equipment-orders-as-turbine-slots-tighten-through-2030/ — retrieved 2026-05-10 — GE Vernova turbine slots tightening through 2030, data center driver, electrification orders
[17] https://www.puc.pa.gov/press-release/2025/puc-advances-plan-to-balance-data-center-growth-and-consumer-protection-11062025 — retrieved 2026-05-10 — PA PUC large-load tariff framework, 50 MW threshold, CIAC, minimum contract terms