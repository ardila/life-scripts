# KEYS — Keysight Technologies

## Where this sits in the AI stack
Keysight sits at the **R&D validation and compliance layer** between silicon design and deployment — physical bench instruments (oscilloscopes, vector network analyzers, parametric/signal-integrity testers, BERTs) plus protocol/traffic emulators (Ixia + retained Spirent assets) plus design simulation software (PathWave). The workloads it touches are **frontier-speed electrical (224G SerDes)**, **optical (224 Gbd PAM4 / pluggables / NPO / CPO)**, and **scale-out network protocol (1.6T Ethernet, Ultra Ethernet, RDMA, NVLink/NVSwitch validation)** — i.e., the wires and SerDes that connect GPUs into clusters. It is **not** in high-volume manufacturing ATE (that is Teradyne/Advantest territory) and not in HBM probe cards (FormFactor) — its franchise is in characterization and pre-deployment validation, where customers are hyperscalers, network silicon vendors (Broadcom, Marvell, Astera Labs), accelerator vendors, optical transceiver/CPO suppliers, and switch OEMs (Arista, Cisco, Nokia) [1][2][3].

## Snapshot
- **Price:** $360.30 (May 8, 2026 close) [4]
- **Market cap:** ~$61.8B [4]
- **52-week range:** $152.52 – $367.12 [4]
- **Forward P/E:** ~42× on FY26 EPS guide of ≥$8.59 (FY ends Oct); ~30× on FY27 consensus per Yahoo Finance composite [5][6][7]
- **EV / NTM revenue:** ~9.5× (≈$62B EV / FY26 guide ≥$6.1B revenue, including ~$375M from Spirent) [5][8]
- **Consensus 12-month price target:** ~$310 post-Q1 print upgrades (BAC $340, UBS $340, GS $322, BARC $320, JPM $300, Citi $282, MS $268; implies ~−14% from spot) [9]
- **YTD total return:** ~+90% (estimate; stock cited "+65% since 1/31/2026," and rallied an additional 16–26% on the Feb 23 Q1 print) [10][11][12]
- **Short interest (% of float):** ~1.1% (1.2-day cover) [13]

## Moat — what it is physically made of

The moat is not a single technology — it's a stack of compounding advantages, each with a different durability profile:

**1. Highest-bandwidth real-time oscilloscopes (Infiniium UXR-series).** 110 GHz analog BW, 256 GSa/s, 10-bit ADC, 750 µVrms noise floor at 10 mV/div. The instrument is the only commercial scope that can measure 224 Gbps PAM4 signals (53 GBd / 56 GBd) with adequate ENOB margin for compliance. Two real competitors exist: Teledyne LeCroy LabMaster 10 Zi-A (claims comparable BW but trails on noise/ENOB in independent comparisons) and Tektronix DPO/MSO (typically caps lower with extenders). At <50 GHz the market is much more contested; at the highest bandwidths the physics — InP front-end ADCs, silicon-germanium TIAs, custom calibration know-how — locks the field [14][15]. **Durability: high (5–10 years).** Replicating an InP ADC + custom interleaving stack is ~10,000+ engineering person-years of accumulated R&D (inference from KEYS' ~$800M annual R&D over multiple cycles).

**2. Vector network analyzers (PNA-X / N5290).** Frequency coverage to 1.5 THz with extender heads. Critical for 6G research and on-wafer characterization of advanced packaging (signal integrity through interposers, RDLs, TSV stacks). Anritsu MS46/VectorStar and R&S ZNA compete in mid-band; KEYS dominates at sub-THz/highest frequencies. **Durability: high.**

**3. Network test / protocol emulation — post-Spirent.** Pre-divestiture, Keysight + Spirent combined held ~85% of high-speed Ethernet test market [16]. The DOJ forced divestiture of Spirent's high-speed Ethernet, network security, and RF channel emulation lines to Viavi for ~$425M [16][17]. Keysight **kept** Spirent's satellite emulation, positioning, network automation, and the lab-to-live software/digital-twin assurance assets — and combined them with its own AresONE 800GE/1600GE platforms and KAI architecture (launched April 2025) for AI workload emulation [2][18][19]. The retained portfolio is the AI-relevant piece: emulating real GPT/Llama-class collective-comm patterns (ring all-reduce, hierarchical all-reduce, expert-parallel) at line rate to validate fabric behavior pre-deployment. **Durability: medium-high; weakened post-divestiture.**

**4. 224G end-to-end portfolio.** Keysight states it has the industry's only 224 Gbps test solution covering both electrical and optical (DCA-M N1095/N1096 sampling scopes, BERTs, 224G arbitrary waveform generators) [20][21]. This matters because 224G SerDes is *the* gating physics for 1.6T networks (Nvidia Blackwell ships with 224G; Broadcom Sian-2 / Tomahawk 6 use 224G; LPO/CPO depend on it) [22]. Without this kit, you cannot ship a compliant 1.6T transceiver. **Durability: 3–5 years until 448G replaces it — at which point Keysight rotates the same revenue.**

**5. PathWave EDA software (ADS, EMPro, SystemVue, RFPro).** Not a Cadence/Synopsys substitute — instead embedded as the RF/microwave/EM signoff layer inside Cadence Virtuoso and Synopsys Custom Compiler flows [23]. Stickiness is workflow-level: signal-integrity engineers run PathWave EM solvers because measurement correlation in PathWave matches Keysight VNA hardware. **Durability: medium; tied to instrument moat.**

**6. Workflow lock-in via compliance test plans.** IEEE 802.3dj (200/400/800GE), OIF CEI-224G, UEC, PCIe 7.0, USB4 v2 — compliance test plans are written to specific Keysight instruments by industry working groups in which KEYS is a founding contributor [24]. Hyperscaler PRDs (product requirements docs) for accelerators and switches frequently cite Keysight model numbers for sign-off. **Durability: high but brittle to a single standards-body shift.**

**Where the moat is weak/absent:**
- HVM ATE for HBM (Teradyne Magnum 7H, Advantest V93000) — KEYS not a real player [25].
- HBM/AI probe cards (FormFactor) — KEYS not a real player [25].
- General-purpose oscilloscopes <8 GHz (commodified; R&S, Siglent, Rigol, Tektronix all credible).
- Digital ATE — Advantest dominates.

## AI buildout bottleneck map

24-month gating constraints and KEYS' position vs. each:

| Bottleneck | KEYS position |
|---|---|
| **CoWoS-L packaging** (TSMC scaling 35K → 130K wpm by end-2026; NVIDIA holds >60% allocation) [26][27] | **Indifferent.** Not a packaging tool maker; minor characterization only. |
| **HBM3e/HBM4 yield** (HBM4 doubles to 2048-bit interface, >2 TB/s/stack) [25] | **Peripheral beneficiary.** Does PHY/signal-integrity characterization but not stack-level KGD test. |
| **Optical interconnect supply (224G LPO/CPO/NPO)** | **Primary beneficiary and enabler.** Industry's only 224G optical+electrical test solution; sells to every transceiver vendor and CPO program [20][22]. |
| **224G SerDes scaling** | **Primary beneficiary.** Bench equipment is mandatory at this speed [20][22]. |
| **Power generation / grid interconnect** | **Indifferent.** |
| **Liquid cooling at >100 kW/rack** | **Indifferent** (some thermal validation, immaterial). |
| **Scale-out fabric standardization (UEC vs. Spectrum-X / NVLink)** | **Beneficiary either way.** Keysight is a UEC contributing member; Nokia + KEYS demonstrated end-to-end UET tests; AresONE emulates UEC LLR and CBFC at line rate [28][29]. |
| **Kernel/compiler talent** | **Indifferent.** |
| **Training data quality / frontier scaling** | **Indifferent.** |

Net: KEYS is a **levered beneficiary of the optical+electrical interconnect cycle**, not the silicon or packaging cycle directly. The right mental model is: every doubling of fabric speed (400G→800G→1.6T→3.2T) is a discrete order spike for Keysight, because every transceiver/DSP/switch/SerDes vendor needs new validation kit per cycle.

## Competitive teardown

**A. High-bandwidth signal integrity (>50 GHz oscilloscopes)** — KEYS leads on the highest-BW SKUs; Teledyne LeCroy LabMaster is the only credible peer at 100 GHz; Tektronix has lagged at the top end. Tektronix is being spun out of Fortive into Ralliant (announced Sept 2025), which could either focus the franchise or distract it. Independent ENOB/noise-floor benchmarks favor KEYS at 110 GHz [14][15].

**B. Vector network analyzers / mmWave** — KEYS dominant >67 GHz. Anritsu and R&S competitive in mid-band but not at sub-THz extender heads.

**C. AI fabric / protocol test** — **Viavi (post-Spirent integration) is now the closest direct competitor.** Viavi paid $410–425M for Spirent's high-speed Ethernet test, network security, and RF channel emulation; that gives them strong protocol coverage [16][17]. *But* — Keysight retained the AI workload emulation and lab-to-live software, and combined it with Ixia (a 2017 acquisition and the dominant traffic generator in hyperscaler labs). The competitive question is **whether Viavi can rebuild AI-specific workload emulation faster than KEYS can integrate retained Spirent software.** First evidence will be Q3 FY26 Viavi commentary on hyperscaler design wins.

**D. EDA simulation as substitute for physical test** — Synopsys (OptoCompiler, PrimeSim Continuum), Cadence (Spectre, Sigrity), Ansys HFSS. **At 224G the gap between simulation and silicon is wide enough that physical measurement is mandatory** — eye margins are <100 mV, BER targets are <1e-15, and PAM4 levels mean a 10% S-parameter modeling error fails a part. At 56G and below, simulation is starting to displace bench validation. The displacement frontier is maybe 2 process nodes behind the leading-edge SerDes — i.e., when 448G arrives, simulation will likely substitute meaningfully for 224G bench. KEYS has 3–5 years before this is a real concern at the cycle frontier.

**E. HVM ATE** — KEYS is not a player. Teradyne and Advantest dominate. Bull thesis here is irrelevant.

**F. Hyperscaler internal test labs** — Meta, Google, Microsoft do build internal validation, but they overwhelmingly buy Keysight (and Ixia) hardware and write their own scripts on top. The economics of building your own >100 GHz scope are prohibitive.

What would have to be true to displace KEYS:
- Viavi must integrate Spirent in <12 months and win named hyperscaler accounts on 1.6T (testable at OFC 2027).
- Or, ≥1 hyperscaler must publicly announce internal test infrastructure replacing Keysight at 1.6T (no signal of this).
- Or, simulation at 224G must show MLPerf-grade correlation with measured silicon (currently doesn't).

## Bull case — technical

The case is that KEYS is a **picks-and-shovels supplier to a multi-cycle, convergent speed transition** — not just AI but also 6G research, automotive radar, satellite (NTN), and PCIe 7. The key technical conditions for outperformance:

1. **800G → 1.6T transition compresses to <18 months**, overlapping with 224G electrical, CPO/LPO optical, and UEC scale-out. Each layer drives independent order cycles. Q1 FY26 already showed wireline > wireless for the first time, with ~half of wireline tied to AI [11][12].
2. **CPO ramps in 2026–2027.** Co-packaged optics is the only known path past pluggable thermal/power limits at 3.2T, and it requires entirely new validation methodology (electrical test of optical engines pre-substrate-attach) — tooling Keysight has uniquely productized [22][30].
3. **UEC adoption broadens beyond NVIDIA.** If hyperscalers continue to deploy Ultra Ethernet for scale-out (and even NVIDIA has joined UEC), Keysight's UEC LLR/CBFC test platform converts protocol-test demand for every switch ASIC vendor [28][29].
4. **Spirent integration delivers software ARR.** The retained lab-to-live and digital-twin pieces are software-margin assets (gross margins >80%), accretive to mix.
5. **Hyperscaler customer count doubled YoY** at Q1 FY26 with sovereign AI investments still ahead [12]. The TAM is widening, not just deepening at existing accounts.

**Base rate:** in prior test-equipment platform shifts (10G→25G→100G→400G), Keysight saw 2–3 year cycle uplifts of 15–25% revenue growth at the speed-leader, then mean-reversion to mid-single-digits. The current cycle is unusually convergent (multiple speeds + multiple physical layers + AI workload + 6G research all hitting at once), which has historically been worth ~2× the duration of a single transition. Last comparable convergence was ~2009–2011 (LTE rollout + early 100G). KEYS revenue grew at ~12–15% during that window. The current cycle is running hotter (+23% YoY in Q1 FY26).

**Financial outcome:** if FY27 grows 15% to ~$7.0B and OPM expands to 28%, EPS reaches ~$11–12. At 30× → $330–$360 (the current price). At 35× cycle-peak → $385–$420.

## Bear case — technical

This is the version a short-seller who actually understands the stack would write.

1. **The market is conflating order growth with revenue durability.** Order growth +30% YoY is from a small AI cohort — KEYS itself disclosed top 2 customers are NOT AI [12]. AI is ~10% of run-rate growing >>30%. Strip out AI, the rest of the business grew ~10%, which is good but not 23%. **If 2–3 hyperscaler customers pause or ration, the AI tailwind collapses concentration.**
2. **Test intensity per dollar of AI infra declines as designs mature.** Once Microsoft validates a switch SKU on KEYS gear, follow-on units don't need full bench validation. The bench-test surge is front-loaded in cycle. ~Half of wireline-AI revenue is one-time R&D bench equipment, which doesn't repeat.
3. **Simulation/digital-twin matures faster than expected at 112G.** Synopsys and Cadence are aggressively pushing "shift-left" simulation. At 112G the gap is already narrowing; if KEYS' 224G window is actually 18 months (not 36), the cycle peaks in 2027.
4. **Stock priced for perfection.** ~42× FY26 guided EPS, ~10× EV/sales, on a company whose stated long-term core growth target is **5–7%** [8]. The compression risk on any deceleration is severe — historical KEYS de-rates compress to ~18× forward in soft cycles (2019, 2023), implying ~−55% downside under that mean-reversion case.
5. **China decoupling tail risk.** KEYS does not break out China explicitly in recent prints, but historically it was 10–15% of revenue. Test equipment >70 GHz is plausibly listable under EAR if Commerce expands the entity list — this is not currently controlled but the policy direction is one-way [31].
6. **Spirent integration is fresh.** Closed October 15, 2025. The DOJ-forced carve-out (40% of Spirent revenue to Viavi) means KEYS paid $1.46B for ~60% of Spirent — net of Viavi's $410–425M, KEYS' net cost is ~$1.04B for ~$235M of retained Spirent revenue. That's ~4.4× sales, reasonable but only if integration delivers. Goodwill impairment is a 2027 risk if synergies disappoint [16][17].
7. **Viavi is now a focused, well-capitalized, antitrust-blessed pure-play network test competitor.** Viavi's existing optical test + Spirent's high-speed Ethernet test is a legitimately competitive stack. KEYS' protocol-test moat is weaker than the pre-divestiture monopoly position.
8. **Book-to-bill of 1.03 is healthy but not euphoric.** It's the level you get when bookings barely outpace shipments — not the 1.2–1.4 you would want if the cycle had multi-year visibility. KEYS itself called visibility "decent two quarters out," which is candid.

**Base rate on test-equipment platform shifts:** incumbents have historically held share well — KEYS vs. Tektronix has shifted only a few percentage points per decade at the high end. But share at high BW is not the same as **multiple at peak cycle**. Test-equipment names historically de-rate from ~30× to ~18× as cycles mature — a 40% multiple compression independent of EPS. Combine that with any earnings disappointment and downside is asymmetric.

## Market view check

At $360 the stock trades at ~42× FY26 guided EPS and ~10× EV/NTM revenue. Consensus PT post-print is ~$310 — meaning even after large upgrades (Citi $220→$282, JPM $255→$300, BAC neutral→buy with $340, Barclays $232→$320, GS $243→$322, UBS $230→$340, MS $227→$268), the stock has run **~14% above the upgraded consensus** [9]. The market has fully repriced KEYS from a "GDP-plus industrial test name" (its prior 10-year identity, ~20× forward P/E typical) to "AI infrastructure pure play." That re-rating is *partially* justified — wireline > wireless for the first time in company history is a regime change, and AI is materially levering test intensity. But the multiple now embeds 18–22% revenue growth for at least two more years. **If FY27 reverts to 8–10%** (the long-term trend with cycle moderation), the stock has 25–30% downside from current levels via multiple compression alone. **If FY27 holds at 18%+**, the stock is fairly valued, not cheap. The market is implicitly pricing the bull case; the entry has happened and the asymmetry on news is now to the downside.

## 90-day falsifiers

1. **Q2 FY26 print (mid/late August 2026).** Revenue ≥$1.71B, order growth ≥25% YoY, AI-cohort customer count growing — bull intact. Below guide on either revenue or orders, or a Q3 guide that flatlines order growth, breaks the thesis [12].
2. **Hyperscaler Q2 capex commentary (late July 2026).** AMZN/MSFT/GOOG/META Q2 prints. If aggregate Q3-implied capex is cut >10% sequentially, KEYS multiple compresses fast.
3. **Viavi (VIAV) earnings (early August 2026).** Watch for disclosed AI/hyperscaler design wins on the acquired Spirent assets. A specific named hyperscaler win on 1.6T would validate a real share-shift risk.
4. **OFC 2026 follow-through.** KEYS announced 224G + 1.6T at OFC March 2026 [20][30]. Order conversion (visible in Q2/Q3 prints) is the test; vendor-side announcements of CPO design wins are leading indicators.
5. **U.S. export-control update on test equipment.** Any explicit listing of >100 GHz oscilloscopes or protocol analyzers on the BIS Commerce Control List or Entity List update would be material. Watch Federal Register filings on EAR amendments.
6. **NVIDIA UEC vs. Spectrum-X positioning at GTC June 2026 / Hot Chips Aug 2026.** If NVIDIA continues converging toward UEC (joined Sept 2024), KEYS protocol-test exposure broadens; if NVIDIA reasserts proprietary stack (Spectrum-X exclusivity for hyperscalers), KEYS protocol moat narrows [28].
7. **Insider Form 4 filings.** Q1 FY26 RSU/PSU vesting clears around April–June; large insider sales above $350 is mild bear signal.
8. **First Spirent contribution disclosure** in the Q2 10-Q. Standalone vs. synergy capture, ARR breakout, and any goodwill commentary will move the integration thesis.

## What I could not verify

- **KEYS' precise China revenue %** for FY25/FY26. The 10-K is broken out by geography but not at the segment-by-AI level; recent commentary said China was "flattish, holding up well" but no fresh hard %.
- **Net Spirent purchase price after Viavi divestiture proceeds** — I infer ~$1.04B net but couldn't reconcile to KEYS' Q1 FY26 balance sheet without the 10-Q filing in hand.
- **Specific named hyperscaler contracts and dollar sizes.** KEYS does not disclose; no leaked supply-chain reporting at the level of, say, NVIDIA Blackwell allocation.
- **KEYS market share precisely at >100 GHz oscilloscopes.** Aggregate oscilloscope market reports (~$4B) don't isolate the highest-BW segment where the moat actually is.
- **Calendar 2026 YTD return precisely.** I estimate ~+90% based on cited "+65% since 1/31" plus subsequent Q1-print rally; don't have a clean primary source.
- **Person-years to replicate UXR.** The "10,000+" figure is inference from R&D spend over multiple cycles, not a sourced number.
- **Direct quantification of test intensity decline curve** as designs mature — there is no public study; my bear-case point on this is structurally argued, not empirically grounded.
- **Backlog composition (AI vs. non-AI).** $2.75B backlog disclosed but not split.

## Sources
[1] https://www.keysight.com/us/en/learn/hubs/ai-data-centers.html — retrieved 2026-05-10 — Keysight's AI data center hub describing scope of validation portfolio (electrical/optical/RF/protocol).
[2] https://www.keysight.com/us/en/about/newsroom/news-releases/2026/0310_pr26-044-keysight-debuts-purpose-built-1-6t-ethernet-ai-workload-emulation-platform-to-validate-next-generation-ai-fabrics.html — retrieved 2026-05-10 — AresONE 1600GE platform launch (March 10, 2026), purpose-built 1.6T Ethernet AI workload emulation.
[3] https://www.keysight.com/us/en/products/network-test/network-test-hardware/aresone-800ge.html — retrieved 2026-05-10 — AresONE 800GE-M product page.
[4] https://stockanalysis.com/stocks/keys/ — retrieved 2026-05-10 — KEYS price ($360.30), market cap (~$61.8B), 52-week range ($152.52–$367.12).
[5] https://finance.yahoo.com/quote/KEYS/key-statistics/ — retrieved 2026-05-10 — Forward P/E (~30× on FY27 consensus), valuation metrics.
[6] https://www.investing.com/news/transcripts/earnings-call-transcript-keysight-technologies-beats-q1-2026-forecasts-93CH-4520207 — retrieved 2026-05-10 — Q1 FY26 transcript: $1.6B revenue (+23% YoY, +14% core), EPS $2.17, GM 66.7%, raised FY26 guide >20% revenue and EPS growth (implies EPS ≥$8.59).
[7] https://www.investing.com/news/company-news/keysight-q1-fy2026-slides-record-revenue-23-growth-beat-forecasts-93CH-4520239 — retrieved 2026-05-10 — Q1 FY26 slides: CSG $1.124B (+27%, +16% core), CommCom $758M (+33%), ADG $366M (+18%), EISG $476M (+15%), CSG OPM 27.5%, EISG OPM 27.2%.
[8] https://seekingalpha.com/news/4525656-keysight-expects-fy-2026-revenue-growth-at-or-above-7-percent-target-while-expanding-ai-and — retrieved 2026-05-10 — FY26 guidance commentary, $375M Spirent revenue contribution, long-term 5–7% organic growth target.
[9] https://www.americanbankingnews.com/2026/02/26/keysight-technologies-nysekeys-reaches-new-1-year-high-after-analyst-upgrade.html — retrieved 2026-05-10 — Post-Q1 print analyst PT raises (BAC, UBS, GS, Barclays, JPM, Citi, MS).
[10] https://www.themarketsdaily.com/2026/04/18/keysight-technologies-inc-nysekeys-short-interest-down-18-4-in-march.html — retrieved 2026-05-10 — Short interest ~1.1%, 1.2-day cover; "+65% since 1/31/2026" reference.
[11] https://www.fool.com/earnings/call-transcripts/2025/11/24/keysight-keys-q4-2025-earnings-call-transcript/ — retrieved 2026-05-10 — Q4 FY25 transcript: wireline > wireless first time, ~half of wireline tied to AI ecosystem (Dhanasekaran).
[12] https://www.gurufocus.com/news/8644409/keysight-technologies-inc-keys-q1-2026-earnings-call-highlights-record-revenue-and-strong-growth-across-segments — retrieved 2026-05-10 — Q1 FY26 highlights: AI customer count doubled, top 2 customers not AI, AI ~10% of run rate growing >>30%, $2.75B backlog, book-to-bill 1.03.
[13] https://www.marketbeat.com/stocks/NYSE/KEYS/short-interest/ — retrieved 2026-05-10 — Short interest details.
[14] https://www.keysight.com/us/en/products/oscilloscopes/infiniium-real-time-oscilloscopes/infiniium-uxr-series-oscilloscopes.html — retrieved 2026-05-10 — UXR-series specs: 110 GHz BW, 256 GSa/s, 10-bit ADC.
[15] https://www.electronicsweekly.com/news/products/test-measurement-products/scope-hits-110ghz-analogue-bandwidth-low-noise-2018-09/ — retrieved 2026-05-10 — Independent coverage of UXR signal integrity claims: 750 µVrms noise at 10 mV/div at 110 GHz.
[16] https://www.justice.gov/opa/pr/justice-department-requires-keysight-divest-assets-proceed-spirent-acquisition — retrieved 2026-05-10 — DOJ proposed final judgment: KEYS+Spirent had 85% high-speed Ethernet test, 60% network security, 50% RF channel emulator share; required divestiture of these to Viavi.
[17] https://www.lightwaveonline.com/home/article/55272153/viavi-acquires-spirents-ethernet-and-network-security-testing-business-from-keysight-for-410m — retrieved 2026-05-10 — Viavi closed acquisition of divested Spirent assets for $410–425M.
[18] https://www.keysight.com/us/en/about/newsroom/news-releases/2025/1015_pr25-124-keysight-technologies-completes-acquisition-of-spirent-communications-plc.html — retrieved 2026-05-10 — Spirent acquisition closed October 15, 2025; retained satellite emulation, positioning, network automation, lab-to-live software.
[19] https://www.keysight.com/us/en/about/newsroom/news-releases/2025/0401-pr25-052-keysight-unveils-architecture-for-scaling-ai-data-centers.html — retrieved 2026-05-10 — KAI (Keysight AI) architecture launch, April 1, 2025.
[20] https://www.businesswire.com/news/home/20260313711497/en/Keysight-Introduces-New-224G-Test-Solutions-to-Enable-1.6T-Optical-Network-Validation — retrieved 2026-05-10 — 224G test portfolio launch March 2026; "industry's only 224 Gbps test solution for both electrical and optical."
[21] https://www.keysight.com/us/en/learn/hubs/emerging-technologies/800g/224-gbps.html — retrieved 2026-05-10 — Keysight 224 Gbps serial hub.
[22] https://newsletter.semianalysis.com/p/co-packaged-optics-cpo-book-scaling — retrieved 2026-05-10 — SemiAnalysis CPO scaling analysis: 224G in NVIDIA Blackwell, Broadcom 224G optical DSPs sampling late 2024.
[23] https://www.keysight.com/us/en/products/software/pathwave-design-software/eda-software-for-circuit-design.html — retrieved 2026-05-10 — PathWave ADS integration with Cadence Virtuoso, Synopsys Custom Compiler, Ansys HFSS.
[24] https://www.keysight.com/us/en/about/newsroom/news-releases/2026/0316_pr26-051-keysight-advances-ai-networking-with-ultra-ethernet-llr-and-cbfc-interoperability-demonstration-at-ofc-2026.html — retrieved 2026-05-10 — KEYS as UEC contributing member; LLR and CBFC interop demo at OFC 2026.
[25] https://chipscalereview.com/teradyne-unveils-magnum-7h-the-next-generation-memory-tester-for-high-bandwidth-memory-devices/ — retrieved 2026-05-10 — Teradyne Magnum 7H supports HBM2E/3/3E/4/4E; KEYS not present in HVM ATE for HBM.
[26] https://www.digitimes.com/news/a20260410VL204/packaging-capacity-tsmc-nvidia-demand.html — retrieved 2026-05-10 — TSMC CoWoS scaling at 80% CAGR; capacity-constrained 2026.
[27] https://markets.financialcontent.com/wral/article/tokenring-2026-1-1-the-great-packaging-pivot-how-tsmc-is-doubling-cowos-capacity-to-break-the-ai-supply-bottleneck-through-2026 — retrieved 2026-05-10 — TSMC scaling CoWoS 35K→130K wpm; NVIDIA holds >60% allocation.
[28] https://www.futuriom.com/articles/news/nvidia-has-joined-the-ultra-ethernet-consortium/2024/09 — retrieved 2026-05-10 — NVIDIA joined UEC September 2024.
[29] https://dcnnmagazine.com/infrastructure/networks/nokia-keysight-complete-uet-test-for-ai-data-centres/ — retrieved 2026-05-10 — Nokia–Keysight end-to-end UET test using AresONE 800GE-8P-QDD-M.
[30] https://www.keysight.com/us/en/about/newsroom/news-releases/2026/0309_pr26-045-keysight-showcases-solutions-accelerating-ai-infrastructure-at-ofc-2026.html — retrieved 2026-05-10 — OFC 2026 demonstrations including 224G LPO/RTLR validation.
[31] https://www.congress.gov/crs-product/R48642 — retrieved 2026-05-10 — CRS report on U.S. semiconductor export controls vs. China; policy direction one-way; test equipment not yet listed but plausibly listable.