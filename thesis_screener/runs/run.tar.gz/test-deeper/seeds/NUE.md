All four research agents are complete. Drafting the dossier now.

# NUE — Nucor Corporation

## Where this sits in the AI stack
Nucor sits at the **physical base of the AI buildout, not the silicon stack**. It is the largest US steelmaker (~28 Mt/yr shipments), supplying structural shapes (Nucor-Yamato), plate (Brandenburg KY), sheet (Apple Grove WV ramping), rebar (multiple micro-mills), open-web joists & metal deck (Vulcraft/Verco), galvanized transmission monopoles (Nucor Towers & Structures), CHI/Rytec overhead and high-speed doors, and rack/cage/airflow-containment hardware (Nucor Data Systems via the SWDP acquisition). The AI workload it serves is **the building shell, foundation, racking, and the transmission/substation steel feeding the grid expansion behind data centers** — not anything inside the machine. CEO Topalian claims Nucor can supply "over 95% of all steel products that go into a data center" [2]; on the Q1 2026 call he quantified the wedge: removing data centers cuts historical backlog by only ~10% [4]. So it is a real, growing, but not-yet-dominant slice of a fundamentally cyclical book.

## Snapshot
- **Price:** $227.50 (May 8, 2026 close; May 10 is Saturday) [1]
- **Market cap:** $51.8B [1]
- **52-week range:** $106.21 – $235.44 [1]
- **Forward P/E:** ~14.8× on FY26 EPS implied ~$15.40 (TIKR consensus $12.57 implies ~18× — wide dispersion driven by tariff-policy uncertainty) [1]
- **EV / NTM revenue:** ~1.35× (EV ~$56.5B / fwd revenue ~$41.8B) [1]
- **Consensus 12-month price target:** ~$209.60 (~7.9% **downside** vs spot) [1]
- **YTD total return (2026):** ~+24% [1]
- **Short interest:** ~2.0–2.9% of float [1]
- **Dividend yield:** ~1.0% (annualized $2.24/sh) [1]
- **Q1 2026:** Revenue $9.50B; EBITDA $1.51B; Net income $743M ($3.23 EPS); record 7.0 Mt mill shipments; 4.7 Mt backlog (highest since Q2 2021) [3][4]

## Moat — what it is physically made of
Nucor's moat decomposes into six components, each with different durability. None of them are software:

1. **EAF cost structure (durable).** Conversion cost ~$250–350/ton vs ~$400–500/ton for integrated BOF; greenfield capex ~$1,000–1,500/ton vs $2,500+/ton for new BOF [11]. Carbon intensity ~270 kg CO₂/ton vs ~1,990 kg/ton for BF-BOF [12] — an ~85–90% advantage that matters when MSFT/Meta/GOOG demand low-embodied-carbon steel for Scope 3 reporting. The integrated industry is asset-trapped: CLF is now retrofitting Middletown to DRI/EMF with DOE money — a forced migration toward the model Nucor built in the 1990s [13].
2. **Scrap & DRI vertical integration (highly durable).** David J. Joseph Co. (DJJ, acquired 2008) is the largest US scrap broker — ~70 yards, >20 Mt ferrous/yr, the largest private scrap railcar fleet in NA [14]. Nucor Steel Louisiana DRI plant (~2.5 Mt/yr) is the world's largest single-train DRI; Nu-Iron Trinidad adds ~2 Mt/yr [15]. Why this matters: prime scrap is structurally tight (rising EAF share = rising scrap demand), and DRI is the only low-residual virgin-iron unit that lets EAFs make exposed-auto and high-grade sheet. Replicating this is a 10-year, $3–5B project, not a capex line.
3. **Downstream product portfolio (operational moat, hard to replicate fast).** Vulcraft/Verco is the dominant US producer of open-web joists and metal deck — the structural skeleton of effectively every data-center building [16]. Add Nucor Buildings Group, CHI Overhead Doors ($3B, 2022) [17], Rytec ($565M, 2024) [18], Nucor Insulated Panel Group, and Nucor Data Systems (via $115M Southwest Data Products [2]). This is a vertical from coil to installed building — assembled over 15+ years through ~$5B of acquisitions.
4. **Capacity ramp into the AI window (cyclically timed).** Apple Grove WV sheet mill ($4B revised from $3.1B [19], ~3 Mt/yr, two 210-ton DC EAFs) — late 2026 startup. Brandenburg KY plate mill (1.2 Mt/yr) at full run-rate. Lexington NC rebar micro-mill (430k tons/yr) online. New Nucor Towers plants in Alabama and Indiana (2025) for transmission monopoles [4]. These hit the same window as the data center capex wave.
5. **Patent/process IP (narrow).** CASTRIP twin-roll thin-strip casting (JV with BlueScope/IHI) has >1,500 patents/applications; commercial at Crawfordsville and Blytheville; cuts energy ~90% and GHG ~80% vs conventional hot-strip [20]. Useful but not blocking.
6. **Tariff regime (powerful but reversible).** April 2026 Section 232 strengthening — **50% on full customs value** of pure steel articles, 25% on derivatives, 15% on metal-intensive industrial/grid equipment, 10% on goods made abroad with US steel [5][6]. Hard pricing floor on HRC/plate/rebar through the AI window. **Not a structural moat** — a future administration or trade-court ruling can flip it — but materially supports per-ton spreads now.

What is *not* a moat: brand at the spec level (steel is fungible), software/API lock-in (none), or any platform-style network effect. The moat is industrial: physical assets, scrap logistics, and a decentralized profit-share operating culture.

## AI buildout bottleneck map
Where Nucor sits relative to each gating constraint on the 24-month buildout:

| Bottleneck | Status (May 2026) | Nucor position |
|---|---|---|
| **Power generation** | EPRI: data centers reach 9–17% of US generation by 2030 [7]; Goldman: +220% DC power demand by 2030 [9]; JPM/Goldman: ~122 GW new US DC capacity by 2030 [9] | **Exposed customer.** Nucor is a ~30+ TWh/yr industrial electricity buyer; rising power prices in TX/SC/AR squeeze EAF spreads. **Negative.** |
| **Grid interconnection** | ERCOT large-load queue 233 GW (>70% data centers) [8]; PJM warns of 2026/27 shortfall; 5–8 yr interconnect waits | Indirect — slows demand pull-through but does not directly help/hurt Nucor. |
| **Gas turbines** | GE Vernova backlog 100 GW Q1'26, sold out through 2030 by YE'26 [21]; Mitsubishi sold into 2028 | **Indirect supplier** — turbine halls, exhaust stacks, balance-of-plant. Modest positive. |
| **Transmission steel** | DOE: 54,500 GW-miles needed by 2035 [22]; ~40–80 t/mile lattice + hundreds of tons per substation [23] | **Direct supplier.** Nucor Towers & Structures expanding (AL + IN plants 2025). Structural beneficiary. |
| **Data center construction steel** | ~35 GW under construction in NA [24]; rising to ~90+ GW by 2030 [9]; ~100 t structural steel/MW (working benchmark) [31] | **Direct supplier — Topalian's "95%" claim.** Structural beneficiary. |
| **Liquid cooling >100kW/rack** | GB200 NVL72 = 120 kW; Vera Rubin NVL576 targets 600 kW/rack by 2027 [27] | **Modest beneficiary** — heavier slabs, more CDU/manifold steel, mechanical-yard steel for chillers/dry coolers. |
| **CoWoS-L / HBM4** | NVIDIA reserved ~60% of 2026 CoWoS-L [25]; HBM4 sold out for 2026 [26] | Indifferent. Different supply chain. |
| **Electrical contractor capacity** | Severe shortage cited across DC construction press | Indifferent — but reduces velocity of demand pull-through. |

**Net:** beneficiary on three (transmission, building steel, mechanical), exposed on one (own electricity bill), indifferent on four. **The under-appreciated risk in the bull case is that AI demand is itself a Nucor input cost.**

**Sizing the wedge (working estimate):** 90 GW new US DC capacity × ~100 t/MW ≈ **~9 Mt structural steel for data centers alone** by 2030, plus tens of Mt for transmission/substations and balance-of-plant. Versus AISI 2025 US shipments of 90.95 Mt [28], AI buildout could plausibly add **~2–4% to annual US steel demand** for several years — material at the margin, concentrated in plate, structural shapes, rebar, and galvanized poles where Nucor leads. (No major bank has published a defensible isolated AI-steel-tonnage forecast that I could verify; the ~100 t/MW figure derives from a single 48 MW project [31].)

## Competitive teardown
- **Steel Dynamics (STLD)** — *peer cost competitor.* Same EAF model, similar scrap integration (OmniSource), Sinton TX mill ramping. Slightly thinner unit cost on flat-rolled per Q3'25 cost analysis [11]. **This is the one peer with parity on cost.** Nucor's edge is breadth — Vulcraft + Towers + Doors + DRI — not unit cost. STLD trades at ~12× forward, slightly cheaper. To take share, STLD would need to assemble a Vulcraft-class downstream; no current evidence.
- **Cleveland-Cliffs (CLF)** — *legacy integrated.* Cost-disadvantaged on conversion, auto-exposed sheet, limited DC exposure. Forced into a $1.3B Middletown DRI/EMF retrofit [13]. **Asymmetric — Nucor structurally ahead.**
- **Commercial Metals (CMC)** — *rebar peer.* Roughly even in rebar; Nucor's micro-mill rollout (Frostproof, Sedalia, Lexington) is closing the gap by placing capacity inside the demand region.
- **Nippon Steel / US Steel + Big River EAF** — *long-tail integrated + new EAF.* Nippon's $14.9B 2025 acquisition brings capital for Big River expansion. **Real long-term threat on advanced flat-rolled (auto, exposed)** if Big River 2 ramps 5+ Mt by 2028 — watch capex announcements.
- **Imports (Korea, Vietnam, Turkey rebar; EU/Japan HRC)** — neutralized for now by 50% Section 232 [5][6]. Falsifier: any narrowing of the rate.
- **Reliance Steel (RS)** — distributor, channel partner, not competitor.

## Bull case — technical
The technical conditions that would have to hold:

1. **Power and steel remain the binding bottlenecks** of the AI buildout for another 24+ months. Evidence: 5–8 yr gas turbine backlogs [21], 233 GW ERCOT queue [8], 5–8 yr interconnect waits — these are physical, not solvable by another fab.
2. **Hyperscaler capex stays at or above $725B/yr** [10], driving the data center pipeline from ~30 GW today to 90+ GW by 2030 [9].
3. **Section 232 holds** at the April 2026 strengthened levels [5][6], floor-pricing HRC/plate/rebar.
4. **Apple Grove WV ramps on schedule late 2026** (~3 Mt/yr [19]) and lands into a tight market — converting capex into operating leverage.
5. **STLD does not displace Nucor's downstream breadth** (Vulcraft/Towers/Doors/SWDP).

If these hold, FY27–28 EBITDA could rerate to $5.5–7B (vs ~$4.2B FY25 [29]), with EPS doubling vs FY25's $7.71 to ~$15+. At a 14× multiple, that's ~$210–250 — but the multiple is already there.

**Base rate on technology displacement at this stage:** Steel is a 200-year-old commodity. Mini-mill displacement of integrated took 40+ years; EAF share went from <30% (1990) to ~72% (2024) [30]. The intra-steel platform shift is essentially complete in flat-rolled. *Real* risks are peer competition (STLD), input shocks (electricity, scrap), and trade-policy reversal — not silicon-style platform shifts.

## Bear case — technical
A short-seller who understood the stack would write:

1. **Nucor's own electricity bill is rising in lockstep with the demand thesis.** EAFs consume ~400–500 kWh/ton of liquid steel. ERCOT/MISO/PJM capacity prices are surging on data center load [8]. A 30% rise in industrial power prices could compress EAF spreads by $30–50/ton — directly offsetting tariff-driven HRC strength. This is **the cleanest internally consistent short**: the same thesis that lifts revenue lifts COGS.
2. **The data center wedge is overstated in market expectations.** Topalian himself said removing data centers reduces backlog by ~10% [4]. The other 90% — non-residential construction, infrastructure, energy, automotive — is cyclical. If non-residential softens (high real rates, CRE distress), the AI tailwind is masked by the broader cyclical drag.
3. **Apple Grove is a $4B bet (revised up from $3.1B [19]) into a sheet market that may face structural oversupply** when Big River 2 (Nippon-funded), STLD Sinton, and the existing fleet are all running. Sheet HRC pricing is the most volatile end of Nucor's mix.
4. **Section 232 is policy, not physics.** The Court of International Trade has already ruled against parts of the IEEPA tariff edifice. A reversal removes a hard pricing floor instantly.
5. **The stock has already priced the bull case.** YTD +24%, near 52-week high, consensus PT below spot, EV/sales 1.35× vs cycle-mean 0.8–1.0×. **The technical thesis is correct; the entry point is not obviously cheap.**

## Market view check
At $227.50, NUE trades at ~14.8× forward EPS and ~1.35× EV/NTM revenue, both at the upper end of its 10-year cyclical range. **Consensus PT $209.60 implies ~8% downside** [1]. Sell-side has approximately the right view: AI tailwind real, tariff floor real, capacity ramp real, and largely priced. The market is pricing Nucor as a high-quality cyclical late in its cycle, not as a structural compounder. My disagreement with sell-side is mild in two directions: (a) the AI buildout is more multi-year and steel-intensive than a 12-month PT framework captures, but (b) the market is also under-weighting Nucor's electricity-input exposure to the same buildout. Net: fairly priced; positive optionality if buildout extends and tariff regime holds; downside if AI capex normalizes or input costs surge faster than ASPs.

## 90-day falsifiers
- **Hyperscaler Q2 2026 capex guidance** (late July/early August earnings): a >10% sequential cut to 2026/27 capex by MSFT/META/GOOG/AMZN invalidates the 24-month thesis.
- **GE Vernova / Siemens Energy / Mitsubishi Power Q2 2026 results** (mid-late July): if turbine backlog *stops growing*, the power constraint is loosening earlier than required for the bull case.
- **PJM 2027/28 capacity auction results** (Q2/Q3 2026): if cleared prices stay at or above 2026/27 levels, electricity-input drag on Nucor is real and rising.
- **Nucor Q2 2026 earnings** (late July): backlog change vs Q1's 4.7 Mt; Apple Grove ramp progress; Vulcraft tonnage; any further quantification of data-center share of book.
- **Nucor Q1 2026 10-Q filing** (mid-May 2026): segment external-sales mix not in the press release.
- **STLD Q2 2026 earnings:** comparison on per-ton spread, downstream growth, Sinton ramp.
- **Section 232 litigation (CIT) developments:** any narrowing of the April 2026 50% rate.
- **Big River 2 capacity announcements:** any pull-forward into 2027 is a flat-rolled supply risk.

## What I could not verify
- Exact data center share of Nucor backlog or revenue beyond the directional ~10% [4]. Nucor does not segment-disclose by end market.
- Steel intensity per MW for hyperscale data centers — used a ~100 t/MW working benchmark from a single 48 MW project [31] and a WEF range [2]; could be 2–3× off depending on multi-story design and density.
- Steel content per mile of HV transmission — 40–80 t/mile [23] is a utility-construction-standard range, not an authoritative industry average.
- Bank-published AI-buildout-specific steel-tonnage forecasts: none found from Goldman/MS/JPM/BofA in isolated form.
- Nucor's mill-level electricity contract structure (fixed-price PPAs vs spot exposure) — not broken out clearly in 10-K.
- The "95% of steel into a data center" management claim [2] — directionally credible, not externally audited.
- Whether Section 232 at 50% will survive Court of International Trade challenges — quantifying legal risk over 90 days is not feasible with public information.
- A common online claim that Sabre Industries is owned by Nucor is **incorrect** — Sabre is held by Blackstone, with TPG Rise Climate acquiring majority stake in 2026; Nucor's transmission franchise is Nucor Towers & Structures (Summit Utility Structures + Sovereign Steel).

## Sources
[1] https://stockanalysis.com/stocks/nue/ — retrieved 2026-05-10 — current price, market cap, 52-week range, forward P/E, dividend yield, short interest, consensus PT
[2] https://www.constructiondive.com/news/nucor-q3-2025-earnings-data-center-buildouts/804149/ — retrieved 2026-05-10 — Topalian "95% of steel into a data center" claim; Q3'25 rebar +28%, joist & deck +50%; SWDP context
[3] https://investors.nucor.com/news/news-details/2026/Nucor-Reports-Results-for-the-First-Quarter-of-2026/default.aspx — retrieved 2026-05-10 — Q1 2026 financials and 7 Mt shipment record
[4] https://www.fool.com/earnings/call-transcripts/2026/04/28/nucor-nue-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Topalian Q1'26 commentary; ~10% backlog from data centers; 4.7 Mt backlog; Towers AL/IN plant timing
[5] https://www.whitehouse.gov/fact-sheets/2026/04/fact-sheet-president-donald-j-trump-strengthens-tariffs-on-steel-aluminum-and-copper-imports/ — retrieved 2026-05-10 — April 2026 Section 232 strengthening to 50%
[6] https://www.whitecase.com/insight-alert/united-states-modifies-steel-aluminum-and-copper-section-232-tariffs — retrieved 2026-05-10 — legal analysis of April 2026 Section 232 changes
[7] https://www.epri.com/about/media-resources/press-release/trb5wwt7oemdbkaamxrccqkq2ktteae8 — retrieved 2026-05-10 — EPRI Powering Intelligence 2026: 9–17% of US generation by 2030
[8] https://www.latitudemedia.com/news/ercots-large-load-queue-has-nearly-quadrupled-in-a-single-year/ — retrieved 2026-05-10 — ERCOT large-load queue 233 GW
[9] https://www.goldmansachs.com/insights/articles/ai-to-drive-165-increase-in-data-center-power-demand-by-2030 — retrieved 2026-05-10 — Goldman: +220% DC power demand by 2030; ~122 GW global capacity
[10] https://www.tomshardware.com/tech-industry/big-tech/big-techs-ai-spending-plans-reach-725-billion — retrieved 2026-05-10 — Hyperscaler 2026 capex $725B
[11] https://artificall.com/analysis/companies/comparisons/nucor-vs-steel-dynamics/ — retrieved 2026-05-10 — STLD scrap-melted cost; EAF cost structure
[12] https://www.sustainable-ships.org/stories/2022/carbon-footprint-steel — retrieved 2026-05-10 — EAF 270 kg vs BOF 1,990 kg CO2/ton
[13] https://www.clevelandcliffs.com/news/news-releases/detail/629/cleveland-cliffs-selected-to-receive-575-million-in-us — retrieved 2026-05-10 — CLF Middletown DRI/EMF retrofit
[14] https://nucor.com/products/raw-materials — retrieved 2026-05-10 — DJJ scrap operations: ~70 yards, 20+ Mt brokered
[15] https://tenova.com/newsroom/latest-tenova/nucor-achieves-world-production-record-thanks-energiron — retrieved 2026-05-10 — Nucor Steel Louisiana DRI world record
[16] https://vulcraft.com/About — retrieved 2026-05-10 — Vulcraft as largest NA joist & deck producer
[17] https://nucor.com/news-release/nucor-completes-acquisition-of-chi-overhead-doors-122921 — retrieved 2026-05-10 — CHI Overhead Doors $3B acquisition
[18] https://nucor.com/news-release/nucor-to-acquire-manufacturer-of-high-performance-commercial-doors-122947 — retrieved 2026-05-10 — Rytec $565M acquisition
[19] https://www.herald-dispatch.com/business/after-rising-costs-nucor-is-now-a-4-billion-investment/article_30de7a4c-f54d-11ef-987c-97f6f3a3e679.html — retrieved 2026-05-10 — Apple Grove WV mill cost revised to $4B
[20] https://www.aist.org/nucor-breaks-strip-casting-record-with-castrip-process — retrieved 2026-05-10 — CASTRIP IP, energy/carbon savings
[21] https://www.utilitydive.com/news/ge-vernova-gas-turbine-backlog-hits-100-gw-as-prices-rise/818332/ — retrieved 2026-05-10 — GE Vernova 100 GW backlog
[22] https://www.energy.gov/gdo/national-transmission-needs-study — retrieved 2026-05-10 — DOE: 54,500 GW-miles new transmission by 2035
[23] https://www.distransteel.com/hubfs/2021%20Docs_NEW%20Template/2021%20Beginners%20Guide%20SubstationTransmission.pdf — retrieved 2026-05-10 — transmission steel content reference
[24] https://www.cbre.com/insights/books/north-america-data-center-trends-h2-2025 — retrieved 2026-05-10 — 35 GW under construction in NA
[25] https://newsletter.semianalysis.com/p/ai-capacity-constraints-cowos-and — retrieved 2026-05-10 — NVIDIA ~60% of 2026 CoWoS-L
[26] https://www.kynix.com/Blog/hbm3e-vs-hbm4-2026-specs-performance--supply-guide.html — retrieved 2026-05-10 — HBM4 sold out 2026
[27] https://introl.com/blog/nvidia-vera-rubin-gpu-600kw-racks-2027 — retrieved 2026-05-10 — Vera Rubin NVL576 600 kW/rack
[28] https://www.steel.org/2026/02/steel-imports-down-12-6-in-2025/ — retrieved 2026-05-10 — AISI 2025 US shipments 90.95 Mt
[29] https://www.investing.com/news/transcripts/earnings-call-transcript-nucor-q4-2025-results-miss-forecasts-stock-dips-93CH-4468117 — retrieved 2026-05-10 — Nucor FY2025 EBITDA ~$4.2B, EPS $7.71
[30] https://theworlddata.com/us-steel-production-statistics/ — retrieved 2026-05-10 — EAF 72% of US raw steel 2024
[31] https://www.thefabricator.com/thefabricator/news/metalsmaterials/fabarc-steel-supply-completes-steel-structure-for-48-mw-data-center-project — retrieved 2026-05-10 — 48 MW project ~100 t/MW benchmark