# APD — Air Products and Chemicals, Inc.

## Where this sits in the AI stack
APD is an industrial gas major. It does not sell anything that physically touches a training cluster. Its AI exposure is two layers upstream: it sells ultra-high-purity (UHP) bulk gases (N₂, O₂, Ar, H₂) and specialty electronics gases under 15–20 year on-site, take-or-pay contracts to the fabs that produce GPUs and HBM (Samsung Pyeongtaek, Intel Chandler/Ocotillo, etc.) and is one of three Western majors with bulk helium logistics — helium being structurally required for EUV purge, ion-implant magnet cooling, wafer backside thermal coupling, and chamber leak-test [1][2][3]. Treat APD as a fab-utility supplier whose growth is leveraged to wafer starts at advanced logic and HBM nodes, not to NVIDIA volumes directly.

## Snapshot
- **Price:** $294.99 (2026-05-08 close) [4]
- **Market cap:** $68.1B [4]
- **52-week range:** $229.11 – $301.11 [5]
- **Forward P/E:** 22.6× on FY26 EPS guide $13.00–$13.25 (raised on Q2 FY26 print) [5][6]
- **EV / NTM revenue:** ~6.6× ($82.1B EV / ~$12.5B FY26E sales) [7]
- **Consensus 12-month PT:** $312.50 (+5.3%) [4]
- **YTD total return:** +21.3% [4]
- **Short interest:** 2.26% of shares — not a battleground name [5]

## Moat — what it is physically made of

The moat is **embedded capital plus contract**, not technology. Decomposed:

**Physical assets (high durability).** APD operates 6 air separation units (ASUs) on a single site in Chandler, AZ — the largest produces >2M scfh gaseous N₂ and >20,000 scfh high-purity O₂ — physically piped via two dedicated nitrogen pipelines into Intel Ocotillo and other Chandler-area cleanrooms [8]. A fab cannot rip out and re-pipe its UHP nitrogen header mid-production; switching costs are not "high," they are infinite over the life of the fab. The Samsung Pyeongtaek announcement (April 2026) replicates this pattern at "Air Products' largest single operations site globally" with multi-phase ASUs and a bulk specialty gas supply system coming on between 2028–2030 [9][10].

**Helium logistics (oligopoly position).** Helium is non-manufacturable — it accumulates from radioactive decay and is captured only as an LNG byproduct [3]. Western supply is concentrated in Qatar (~30% of global), the US Hugoton/Cliffside system, and Algeria; Russia is sanctioned out [3][11]. APD has a US storage cavern, multi-source domestic production, and global container logistics, which it is currently leaning on as Qatar volumes ran into Strait of Hormuz interdiction risk in March 2026 [6][11][12]. Replicating this requires not capital but counterparty access — Sonatrach, RasGas — that takes a decade to build.

**Contract structure (the actual moat).** ~90% of revenue is from 15–20 year on-site take-or-pay contracts with energy pass-through and inflation escalators [13][14]. This is closer to a regulated utility return profile than a chemical company. The contract base is the moat — once written, a competitor cannot displace it short of fab decommissioning.

**Specialty/UHP qualification.** Sub-ppb impurity gas qualification at customer process tools takes 12–24 months per molecule; the qualified-supplier list at a leading-edge fab is small and sticky.

**What is NOT a moat.** No software stack worth pricing in (process control is in-house but undifferentiated vs. Linde). No patent fortress — the gas separation IP base is mature. Brand premium is roughly nil; this is B2B oligopoly. APD is **#3 in electronics gases globally** behind Linde (~27–30%) and Air Liquide (~22–24%), with APD at roughly 12–15% [15][16] — call this honestly: technical parity across the three majors, with share decided contract-by-contract.

**Person-years to replicate at parity:** the wrong question. The replication cost isn't engineering — it's the customer relationship and the embedded asset base. That's why the 5-major industrial gas oligopoly (Linde, Air Liquide, APD, Messer, Nippon Sanso Holdings) has been stable for >40 years.

## AI buildout bottleneck map

| Bottleneck | APD position |
|---|---|
| Power generation / grid interconnect (gas turbine OEM backlog at GE Vernova ~100 GW, sold out into 2030 [17]) | **Indifferent.** The cancelled US clean-H₂ projects targeted ammonia/transport, not data center power. No public datacenter PPA. |
| CoWoS-L / advanced packaging | **Indifferent.** APD does not sell into OSAT/packaging steps. |
| HBM yield (SK hynix M15X, P&T7; Samsung Pyeongtaek; Micron NY/Idaho) | **Beneficiary** — wafer starts at HBM-heavy fabs are the proximate driver of UHP nitrogen, helium, and specialty etch gas demand. APD has Samsung; Linde has TSMC AZ; Air Liquide has Micron Idaho [9][10][18][19]. APD is winning where it is incumbent (Korea), losing in the new US footprint. |
| Helium (EUV purge, implanter cryo, leak detect, ALD carrier — irreplaceable) [1][2] | **Supplier and partial constraint owner.** Helium volumes to Asian electronics expected to **>2× from 2026 to 2030** on contracts already signed [6][20]. But spot helium pricing was a **~4% EPS drag in FY26** even with Hormuz disruption — long-term contracts lag spot in both directions [6]. |
| Liquid cooling >100 kW/rack (dielectric immersion fluids — 3M Novec, Castrol, Shell) | **Indifferent.** Industrial gases are not the cooling fluid; cryogenic LN₂ failover is a marginal niche [21]. |
| Optical interconnect, NCCL/CUDA talent, training data | **Indifferent.** |

The honest read: APD is a **selective HBM/logic wafer-starts beneficiary plus a helium oligopolist**, not a power-bottleneck or networking-bottleneck play. Bulls who frame APD as "the picks-and-shovels of AI" are conflating two layers of the stack.

## Competitive teardown

The relevant axes are (a) capacity to win new on-site mega-contracts, (b) helium franchise depth, and (c) UHP specialty gas qualification at advanced nodes.

- **Linde (LIN).** Largest in industrial gases overall (~31% global share) and in electronics gases (~27–30%) [15]. Won TSMC Arizona Fab 21 (~$600M, on-stream H2 2022) [22]; expanded NF₃/WF₆ in Taiwan +40% in Sept 2024 [16]. Has consistently been the discipline benchmark — reference for what an activist would ask APD to look like. **Parity or edge** on UHP, **edge** on US CHIPS-Act fabs.
- **Air Liquide (AIQUY).** Won Micron Idaho ($250M+, on-stream end 2025) [18][19]. Strong NF₃/silane technology base. **Parity** on electronics gases; comparable backlog cadence.
- **Taiyo Nippon Sanso / Nippon Sanso Holdings.** Strong in Japan/Asia. Embedded with Japanese tool OEM customer base. Parity in specialty fluorides.
- **Messer.** Private, regional strength in Europe and US after Linde divestiture (FTC 2018). Smaller in electronics gases.
- **SK Specialty / SK Materials.** Korean fluorinated specialty position; sold 85% to Hahn & Co PE in 2024 [16]. Capital constraints likely to slow capacity adds.
- **Versum.** Acquired by Merck KGaA (2019, ~14.5× EV/EBITDA) and folded into Performance Materials [16].

What it would take for share to shift toward APD: winning the next Western mega-fab (a TSMC Arizona Fab 22, Intel 18A scale-up, Samsung Taylor expansion, or Micron NY phase 2) against Linde and Air Liquide. The Pyeongtaek win consolidates Korean incumbency but does not change the US share narrative. **APD has lost the two highest-profile US CHIPS Act gas contracts.** That is a real datapoint, not a sentiment one.

## Bull case — technical

Required technical conditions:

1. **Wafer starts at AI-relevant nodes (logic ≤3nm, HBM3e/HBM4) compound at >12% through 2028.** This is consistent with TSMC's CoWoS expansion, SK hynix P&T7 ($12.9B, 2027 onstream), Samsung Pyeongtaek phasing.
2. **Helium remains structurally tight.** Hormuz/Qatar disruption persists or normalizes slowly; Algeria flat; no new fields online. APD's storage cavern + signed Asia electronics contracts (volumes 2× by 2030) [6] convert this scarcity into pricing power as legacy contracts roll.
3. **Capital discipline holds.** Menezes cancels Louisiana at the mid-2026 go/no-go [6], capex stays near the $2.5B target vs. >$5B at peak [13][23], $250M cost-out lands. The clean-H₂ overhang stops being a discount factor.
4. **Linde and AL do not undercut on the next 2–3 large electronics on-site bids.** APD wins one of the next US mega-fab contracts.

If those hold: ~8–10% EPS CAGR (consistent with current FY26 guide [6]) on a stable 22–24× multiple = ~$340–$365 in 12–18 months. The technical reality supports a quality-compounder thesis, not a growth-stock one.

**Base rate on technology displacement.** Industrial gas oligopoly has been remarkably stable. The five-major structure has held since the 1980s. Compare: PC/server OEM share churned violently in the same period. The base rate for moat erosion at a #3 oligopolist with 90% take-or-pay revenue inside a 24-month window is **very low**. The base rate for a #3 oligopolist losing share is moderate — that is what's actually happening in US CHIPS-Act fabs.

## Bear case — technical

Required technical conditions:

1. **APD continues to lose Western share.** Linde and AL win the next two US/EU semi mega-projects. The narrative becomes "APD is the Korean incumbent" rather than "global AI gas play" — multiple compresses to chemicals industry median (~19×), implying ~$250 [5].
2. **Helium recovery scales at advanced fabs.** TSMC, Samsung, SK hynix, and Intel have all begun internal helium recovery/recycling programs in response to the 2026 shock [11][24]. If recovery rates approach 80% (technically plausible — DOE has demonstrated 90%+ on EUV purge), helium volumes per wafer fall structurally even as wafer counts rise. This kills the "helium scarcity = APD pricing power" leg.
3. **Louisiana proceeds.** If Menezes greenlights the Darrow blue-H₂ complex (mid-2026 decision [6]) under the same FID logic Ghasemi used, capital allocation discipline credibility evaporates. Forward FCF compresses.
4. **NEOM ammonia economics disappoint.** Green NH₃ pricing has been weak; Yara off-take negotiations are unresolved [6]. Plant comes online late 2026 into a soft market.
5. **Helium spot weakness persists** despite Hormuz — APD has already absorbed a 4% FY26 EPS hit from helium pricing [6]; another year of this drains the optionality argument.

The honest short thesis: APD is a #3 oligopolist trading at a #1 multiple on an "AI exposure" narrative, while losing share in the Western frontier of the AI fab build, with a $9B backlog [6] that is half hydrogen-adjacent and economically marginal at current rates.

## Market view check

At $295 / 22.6× FY26 / 6.6× EV/sales, APD trades at a **17% premium to chemicals industry median forward P/E** [5]. The +21% YTD return is mostly the Mantle Ridge governance reset (cleanup of the $3.1B Q2 FY25 hydrogen writedown, capex discipline, NEOM clarification [13][23][25]) plus the Samsung Pyeongtaek headline [9][10]. Consensus PT $312 implies the market sees the reset largely priced in. My read: **the market is correctly pricing the governance reset and roughly correctly pricing the wafer-starts tailwind, but is implicitly assigning some value to "AI exposure" that is upstream and partial**. Mispricing is small, not large. If the activist thesis is "industrial gas discipline at a Linde-like multiple," then $295 is reasonable; if the thesis is "AI infrastructure pure-play," it's stretched.

## 90-day falsifiers

- **Q3 FY26 print (~late July 2026):** management told investors to expect $1.5–2B incremental electronics backlog within six months [6]. **<$1B incremental electronics backlog** would weaken the AI-leverage thesis specifically.
- **Louisiana/Darrow go/no-go decision (mid-2026):** "GO" is a significant negative — capital indiscipline returning. "No-Go" is the base case priced in [6].
- **Helium spot pricing:** if Hormuz re-opens and helium spot collapses, the FY26 helium EPS drag widens beyond 4%.
- **Next US semiconductor on-site contract award** (e.g., TSMC AZ Fab 22, Samsung Taylor expansion, Intel 14A site selection): a Linde or AL win would extend the US-share-loss pattern; an APD win meaningfully reframes.
- **NEOM ammonia first production (target end-2026)** plus Yara distribution agreement closure [6].
- **Mantle Ridge 13D updates / Hilal stake change.**
- **Helium recovery technology demonstrations** at TSMC/Samsung/SK hynix above 70% recycle rate at production scale.

## What I could not verify

- APD's exact electronics gases market share (third-party sources put it at 12–15% [15][16] but APD does not segment-disclose).
- Helium as % of APD revenue and of EBIT (clearly material per Q2 FY26 commentary, but not disclosed).
- Whether SK hynix Cheongju M15X/P&T7 is supplied by APD or by a Korean local/JV.
- Whether APD has any direct data center cooling contracts (helium-cooled DC programs like Tidal NRG/Innov8 [21][26] do not name a gas supplier publicly).
- Whether APD has data-center hydrogen/ammonia offtake — Bloom Energy's hyperscaler deals appear to use natural gas + on-site reformers, not delivered H₂.
- Mantle Ridge's exact current stake size (reported ~$1.3B at filing [25]; current position not refreshed).
- Internal helium recovery rates at leading-edge fabs in 2026 (anecdotal "increasing"; no production data found).

## Sources

[1] https://reports.valuates.com/blogs/helium-demand-semiconductor-euv-chipmaking-supply-chain — retrieved 2026-05-10 — established helium uses in EUV purge, implanter cryo, ALD carrier, leak detection.
[2] https://www.tomshardware.com/tech-industry/semiconductors/the-global-helium-shortage-is-a-direct-threat-to-chipmaking — retrieved 2026-05-10 — established direct linkage of helium shortage to chipmaking processes.
[3] https://fortune.com/2026/04/22/helium-forecast-outlook-iran-war-moodys/ — retrieved 2026-05-10 — established helium concentration: Qatar ~30%, Russia sanctioned, helium non-manufacturable.
[4] https://finance.yahoo.com/quote/APD/ — retrieved 2026-05-10 — established price $294.99, market cap $68.1B, YTD +21.3%, consensus PT $312.50.
[5] https://www.gurufocus.com/term/forward-pe-ratio/APD — retrieved 2026-05-10 — established forward P/E 22.58, 52-week range, industry median 19.31.
[6] https://www.fool.com/earnings/call-transcripts/2026/04/30/air-products-apd-q2-2026-earnings-transcript/ — retrieved 2026-05-10 — Q2 FY26 transcript: EPS $3.20, FY26 guide $13.00–13.25, helium 4% EPS drag, Asia helium volumes 2× by 2030, $9B backlog, Louisiana decision mid-2026, Pyeongtaek largest electronics investment.
[7] https://stockanalysis.com/stocks/apd/statistics/ — retrieved 2026-05-10 — established $82.1B EV, $12.04B LTM revenue, net debt/EBITDA 2.2×.
[8] https://www.airproducts.com/company/news-center/2021/03/0315-air-products-places-newest-and-sixth-asu-onstream-in-chandler-arizona — retrieved 2026-05-10 — established 6 ASUs in Chandler AZ, >2M scfh N₂, two pipelines into local fabs.
[9] https://www.airproducts.com/company/news-center/2026/04/0429-air-products-gas-supply-samsung-semiconductor-fab-south-korea — retrieved 2026-05-10 — Samsung Pyeongtaek deal: largest electronics investment to date; multi-phase 2028–2030.
[10] https://www.stocktitan.net/news/APD/air-products-to-expand-industrial-gas-supply-for-samsung-electronics-hytty3hfzpds.html — retrieved 2026-05-10 — corroborates Pyeongtaek scope and timing.
[11] https://www.hpcwire.com/bigdatawire/2026/03/30/global-helium-shortage-begins-to-constrain-high-density-compute-and-cooling-systems/ — retrieved 2026-05-10 — established helium constraints on HPC and cooling systems in 2026.
[12] https://www.npr.org/2026/04/03/nx-s1-5762568/strait-of-hormuz-closure-deflates-global-helium-supply — retrieved 2026-05-10 — Hormuz closure removed ~27–30% of global helium since March 2026.
[13] https://www.beyondspx.com/quote/APD/air-products-strategic-reset-from-project-bloat-to-industrial-gas-discipline-nyse-apd — retrieved 2026-05-10 — Menezes capex target $2.5B vs. peak $5B+, $250M cost-out, $3.6B speculative project exits.
[14] https://www.headcountcoffee.com/blogs/corporate-legends-lost-empires/air-products-on-site-gas-contract-entrenchment-record — retrieved 2026-05-10 — established 15–20 year take-or-pay structure; ~90% of sales contracted; inflation escalators and energy pass-through.
[15] https://www.marketsandmarkets.com/ResearchInsight/industrial-gases-market.asp — retrieved 2026-05-10 — Linde ~31% global industrial gas share; oligopoly with Air Liquide, APD, Messer, TNSC.
[16] https://www.lincolninternational.com/perspectives/semiconductor-gas-market-heating-up/ — retrieved 2026-05-10 — electronics gas share estimates Linde 27–30%, AL 22–24%, APD 12–15%; Versum/Merck and SK Specialty/Hahn transactions.
[17] https://www.utilitydive.com/news/ge-vernova-gas-turbine-backlog-hits-100-gw-as-prices-rise/818332/ — retrieved 2026-05-10 — GE Vernova gas turbine backlog 100 GW, sold out into 2030.
[18] https://www.airliquide.com/group/press-releases-news/2024-06-05/air-liquide-signed-major-contract-support-semiconductor-industry-us-investment-more-250-million — retrieved 2026-05-10 — Air Liquide Idaho gas plant for Micron, $250M+, end-2025 onstream.
[19] https://www.chemengonline.com/air-liquide-to-construct-new-high-purity-gas-plant-in-idaho/ — retrieved 2026-05-10 — confirms Micron Idaho UHP nitrogen contract.
[20] https://investors.airproducts.com/news-releases/news-release-details/air-products-signs-long-term-supply-contract-national-helium — retrieved 2026-05-10 — APD long-term helium supply structure example.
[21] https://www.datacenterdynamics.com/en/news/tidal-nrg-and-innov8-gases-work-on-helium-cooling-for-data-centers/ — retrieved 2026-05-10 — Tidal NRG/Innov8 helium cooling for AI data centers (no APD link disclosed).
[22] https://www.linde.com/news-and-media/2021/linde-signs-long-term-agreement-to-supply-new-world-class-semiconductor-manufacturing-complex-in-the-u-s — retrieved 2026-05-10 — Linde TSMC Arizona ~$600M N₂/O₂/Ar contract; H2 2022 onstream.
[23] https://www.h2-view.com/story/air-products-shifts-neom-strategy-to-saudi-ammonia-sales-halts-louisiana-blue-hydrogen-spend/2125368.article/ — retrieved 2026-05-10 — NEOM strategy shift to ammonia sales; Louisiana blue-H₂ paused.
[24] https://www.trendforce.com/news/2026/04/08/news-decoding-impact-asia-chipmakers-move-to-tackle-helium-strain-as-intel-gains-relative-buffer/ — retrieved 2026-05-10 — TSMC, Samsung, SK hynix, Micron mitigation strategies including recovery and supplier diversification.
[25] https://cen.acs.org/business/Air-Products-loses-boardroom-fight/103/web/2025/01 — retrieved 2026-05-10 — Mantle Ridge wins 3 board seats Jan 2025; Ghasemi unseated as chair; Menezes installed.
[26] https://www.newswire.com/news/tidal-nrg-and-innov8-gases-partner-to-pioneer-helium-cooling-for-ai-22620940 — retrieved 2026-05-10 — proprietary helium-based cooling for AI/HPC data centers; eliminates water use.