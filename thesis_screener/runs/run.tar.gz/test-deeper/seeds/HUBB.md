# HUBB — Hubbell Incorporated

## Where this sits in the AI stack
HUBB sells the **balance-of-system electrical hardware** that surrounds — but does not include — the highest-value pieces of the AI power chain. On the grid side, that means transmission and substation **connectors, surge arresters, polymer insulators (2.5–800 kV), bushings, cutouts, switches, anchors, and grounding gear**, plus Aclara smart meters [1][2][3]. On the data-center side, it means **prefabricated power-distribution skids (PCX), rack PDUs, Burndy mechanical/compression connectors, grounding kits, and wire-management** delivered into hyperscale shells [4][5]. HUBB does **not** make the medium/high-voltage power transformers, gas turbines, or large switchgear lineups themselves — those are Hitachi Energy, GE Vernova, Siemens Energy, ABB, Schneider, Eaton. HUBB's exposure to AI is therefore as the picks-and-shovels supplier to the picks-and-shovels suppliers: every new 230 kV substation, every transformer, every utility-feed into a hyperscaler campus drags a multiple of HUBB SKUs with it.

## Snapshot
- **Price:** $492.58 (2026-05-08 close) [6]
- **Market cap:** $26.03B [6]
- **Enterprise value:** $28.25B [6]
- **52-week range:** $346.07 – $565.50 [7]
- **Forward P/E:** 24.3× (on FY consensus EPS implied by company guide of $19.30–$19.85) [6][8]
- **EV / NTM revenue:** 4.7× [6]
- **Consensus 12-month price target:** $544.84 (22-analyst average, ~+11% from spot); Stephens raised to $600 on 2026-05-04 [7]
- **YTD total return:** ~+14.5% (as of early May 2026) [9]
- **Short interest:** 4.77% of float (~2.54M shares short, 53.16M shares out) [10]

## Moat — what it is physically made of

HUBB's moat is **not software**. It is a stack of three concrete, separable assets, none of which is individually thrilling but which compose into pricing power that has yielded **22.6% operating margins** [11].

**1. Utility specification lock-in (the durable piece).** Investor-owned utilities maintain qualified parts lists; once a connector, arrester, or polymer insulator is qualified into a utility's standard, the switching cost is asymmetric — a $200 connector that fails on a 230 kV bus causes a multimillion-dollar outage, so utilities resist re-qualifying alternates absent meaningful cost gain. The brand stack (**Hubbell Power Systems, Anderson — 130+ years, Chance, Fargo, CMC**) is on standard parts lists at most North American IOUs and co-ops [12][13]. This is a procurement and reliability moat, not a technological one. It is real but slow-eroding: a new entrant needs years of in-service performance data plus utility engineering relationships, but the underlying products are mature steel/aluminum/polymer hardware, not deep IP.

**2. DMC Power swaged-connector IP (the actually-patented piece).** Acquired August 2025 for $825M ($130M revenue, $60M EBITDA — implying ~46% EBITDA margin and 14× EBITDA paid) [14]. DMC's patented 360° Radial Swage Tool collapses a HV connector installation from a bolted, torqued, multi-step lineman job to a single button-press; this matters acutely because the entire industry is constrained by lineman labor and field productivity, not raw connector cost [14]. This is the closest thing HUBB has to a hard technology moat in utility — a labor-saving tool inside a constraint-bound trade.

**3. PCX modular power skids (the time-to-power moat).** PCX integrates the medium-voltage step-down, switchgear, UPS, and BoS into factory-built, pre-commissioned skids that cut hyperscaler buildout by ~30% [15]. The competitive set is Schneider/Vertiv/Eaton/ABB — all bigger. HUBB's edge is the **PCX + Burndy + Hubbell premise wiring + Aclara metering** integration sold as a bundle, plus delivery date credibility into a market where Vertiv lead times have stretched.

**Weak parts of the moat to be honest about:**
- **Aclara AMI** is third in North American smart meters at **21% installed-base share** behind Itron (35%) and Landis+Gyr (32%) — and management acknowledged Q1 2026 Grid Automation organic sales fell ~7% YoY because utilities "deprioritized AMI investments" [16][17]. AMI 2.0 (Itron's Genesis platform, edge analytics) is where the next deployment wave goes, and Aclara is the share donor candidate, not gainer.
- The **NSI Industries deal** ($3.0B, May 2026, 15.5× 2026E EBITDA, $570M revenue) [18] is a roll-up of commoditized electrical fittings/wire management — Bridgeport fittings, Polaris connectors, Tork timers. It widens the SKU catalog from ~60,000 to ~75,000+ but adds limited proprietary technology. The strategic logic is cross-selling through 2,000 distributors; the economic logic depends on synergies, not differentiated tech.
- **Electrical Solutions** (wiring devices, harsh-and-hazardous) is closer to a branded-commodity oligopoly than a moat: HUBB, Leviton, Pass & Seymour (Legrand), Eaton all compete on catalog breadth and distributor stocking.

A competitor wanting to replicate HUBB's utility position would need ~10–15 years of qualifying parts at IOUs and probably a decade of legacy installs to prove polymer/silicone reliability — that is genuinely hard. Replicating the data-center skid business is a 3–5 year problem (Vertiv already does it at scale).

## AI buildout bottleneck map

Following the actual physical chain from generation → grid → data-center bus, here is where HUBB sits at each gate:

| Constraint | 2025–27 reality | HUBB position |
|---|---|---|
| **Gas turbines (frame 7/9)** | GE Vernova backlog **100 GW by Q1 2026**, sold through ~2030; Siemens Energy ramping from 48→70–80 units/yr [19] | **Indifferent** — HUBB sells nothing inside the turbine island |
| **Large power transformers / GSUs** | Lead times **128 wks** (power), **144 wks** (GSU); +70% price since 2019; 30% supply deficit forecast [20][21] | **Indirect beneficiary** — every transformer drags connectors, arresters, bushings, and surge protection. Not the prize, but every prize they sell comes with HUBB attachments |
| **Substation buildout** | PJM 2026 cycle, ERCOT large-load queue **233 GW (70% data center)** [22][23] | **Core beneficiary** — full Hubbell Power Systems / Anderson / Burndy / DMC stack ships with every new substation |
| **MV switchgear** | Lead times ~44 wks, eroding; ABB +120% capacity Brno/Rakovski [24] | **Adjacent** — HUBB sells some, but ABB/Schneider/Eaton/Siemens dominate. PCX integrates 3rd-party switchgear |
| **Liquid cooling (>100 kW/rack)** | nVent modular CDUs scaling; Vertiv, Schneider competing | **Largely absent** — HUBB does not have a meaningful direct-to-chip / rear-door heat-exchanger product |
| **High-amperage busway / 415V & 800V DC** | Migration from 480V AC to 415V AC and increasingly 800V DC for HVDC architectures [25] | **Mixed** — Burndy/Hubbell PDUs exist, but the 800V DC bus is contested by SST startups (Heron, Hyperscale Power, Amperesand) |
| **Interconnect lineman labor / utility EPC** | Hard cap — qualified line crews are scarcer than the hardware | **Indirect beneficiary** via DMC swage tool, which compresses crew-hours per connection |
| **Aclara / AMI deployments** | Utilities "deprioritized" AMI investments per HUBB Q1 [26] | **Headwind** — Grid Automation declined 7% YoY in Q1 |

The single most important read: HUBB's exposure is **wide and shallow** at each bottleneck rather than **deep at one**. That is durable to any single technology displacement but caps the upside if (say) FERC accelerates one specific category.

## Competitive teardown

The relevant axes are (a) utility T&D BoS hardware and (b) hyperscale data-center power distribution. They are different competitive sets.

**Utility T&D BoS (where HUBB is strongest):**
- **Eaton Cooper Power Systems** — closest direct overlap on distribution-class hardware; broader switchgear and reclosers. Eaton's $142B EV and integrated utility/data-center positioning is the structural threat over a 5-year horizon; Eaton can underwrite hyperscaler deals that bundle the full chain in a way HUBB cannot [11]. On a pure connector/arrester basis, HUBB is at parity or ahead.
- **MacLean Power Systems, TE Connectivity, Preformed Line Products (PLPC)** — fragmented competitors at the SKU level; none has HUBB's catalog breadth or distributor footprint.
- **Itron / Landis+Gyr** — winning the AMI 2.0 cycle against Aclara. Itron's Genesis platform combines edge compute with mesh networking in a way Aclara's I-210+c does not match credibly [16]. **This is a place where the competitor already has parity or advantage and HUBB is the share donor.**

**Hyperscale data-center power (where HUBB is mid-pack):**
- **Vertiv** — prefab UPS modules, Liebert switchgear; bigger scale, deeper hyperscaler relationships. Vertiv's modular power module is the direct PCX competitor.
- **Schneider Electric** — EcoStruxure software layer is the differentiator HUBB has no answer to; Schneider sells the building management + power monitoring + DCIM stack as an integrated platform. HUBB sells hardware.
- **Eaton** — full-stack including UPS, switchgear, busway, PDU. Operating at 19.8% margin vs HUBB's 22.6%, but Eaton's revenue base is 4× HUBB's and growing faster in absolute data-center dollars [11].
- **nVent** — different lane (containment, thermal, liquid cooling); reported 23% organic growth in Systems Protection. nVent is taking the cooling spend HUBB cannot reach [11].
- **ABB** — switchgear capacity adds 120% [24]; competes on the MV side of PCX skids but doesn't own the modular skid integration.

What would have to be true for HUBB to lose share at the rack: Vertiv or Eaton starts winning the multi-skid hyperscaler RFPs on integration + delivery date, not on individual SKUs. Watch hyperscaler-disclosed prefab-module supplier names.

What would have to be true for HUBB to lose share at the substation: Either (a) a new entrant with credible polymer arrester reliability data displaces HUBB on the qualified parts lists (very slow), or (b) hyperscalers self-build behind-the-meter with on-site gas/SMR that skips utility substations entirely (some path on a 5–10 year horizon).

## Bull case — technical

The grid super-cycle is the **least speculative** AI-adjacent thesis on the board. The base-rate from prior infrastructure cycles (US Interstate, ICE→EV charging buildout, fiber-to-the-home) is that gear and connector vendors with installed-base specification lock-in compound at mid-teens revenue growth for ~7–10 years before saturating. Specifics:

- **US utility capex projected at $259B (2026) and $276B (2027)** — distribution 33%, generation 24%, transmission 20% [27]. The transmission and distribution share alone is ~$140B/yr addressable, growing.
- HUBB Q1 2026: Utility Solutions +11%, Grid Infrastructure organic +12%, **Electrical Solutions data-center growth ~40%**, full-year DC market growth raised to **>25%** [26]. **Half of data-center exposure is long-cycle PCX skids** — i.e., backlog-protected.
- **Book-to-bill ~1.2** for both short- and long-cycle in Q1 [26].
- DMC Power closing tracks ahead of plan; NSI closes mid-2026 and is accretive to EPS in year 1.
- Management guides **8–11% sales growth, EPS $19.30–$19.85** for 2026 [3].
- Critical hardware lead times (transformers 128+ wks, switchgear 44 wks, turbines 5–7 yrs) act as a **price floor and backlog protector** for HUBB — short of demand cratering, the pipeline cannot empty.
- DMC swage technology aligns with the lineman-labor bottleneck — a real product moat in a real constraint.

If grid capex compounds at 8–10% through 2028 and HUBB outgrows the market at 10–12% (consistent with Q1 run-rate), $19.85 → roughly $25 EPS by 2028. At a 22× multiple that's a $550 stock; at 26× (current peak) it's $650. The bull case is mid-teens annualized total return with the buyback and dividend.

## Bear case — technical

The shorter who actually understands the stack would not argue "AI demand slows." They would argue three specific things:

**1. Hyperscalers route around utility T&D.** Meta, Amazon, and OpenAI/Stargate are increasingly negotiating **co-located generation** (gas peakers, PPAs with new turbines, eventually SMRs) that **bypasses substantial portions of the regulated utility infrastructure**. Amazon's private-grid signals and the FERC PJM co-located-load fight are early evidence [23][28]. Every gigawatt that lands behind-the-meter delivers fewer HUBB SKUs per gigawatt than a grid-served data center, because the high-voltage step-down can collapse into a single on-site MV bus.

**2. Aclara is structurally impaired and the market hasn't priced it.** Grid Automation declined 7% YoY in Q1 2026 [26], management is publicly conceding share, and AMI 2.0 awards convert to Itron/L+G on technology grounds (edge compute, mesh, ADMS integration) that Aclara cannot match without a multi-year platform rebuild. This is the IBM-PC-vs-Wintel pattern at small scale: HUBB owns the meter hardware, the value migrates to the analytics stack. Aclara is roughly 10–12% of Utility Solutions; if it goes to ~5% share, the segment growth rate compresses by ~150–200 bps.

**3. Multiple has done the work.** HUBB trades at **24× forward P/E vs a 10-year average of ~17×** [29]. The implied earnings CAGR baked in at current multiple is mid-teens; if the actual is high-single-digits, the multiple compresses 25–30%. The NSI deal at **15.5× EBITDA for commoditized fittings** is the highest signal yet that capital allocation may be drifting toward roll-up at full prices to maintain growth optics. A 50 bps margin disappointment plus a 4 multiple-turn compression is a $150 swing per share with no demand-side thesis change at all.

**4. SST is a slow, real risk on a 5–10 year horizon.** Heron Power ($140M raised, 40 GW of customer interest letters), Hyperscale Power, Amperesand, DG Matrix have raised >$330M collectively to replace the iron-and-copper MV-to-LV/DC step inside data centers [30][31]. If 800V DC architectures with SST front-ends become standard (Nvidia is steering this direction with GB300/Rubin power architectures), the **prefab skid composition changes** — fewer mechanical connectors, more semiconductor power-electronics modules, fewer Burndy lugs per kW delivered. HUBB does not have an SST product. The risk is not 2026 — it's 2029+.

Base rate caveat: infrastructure displacement is **slow**. Polymer insulators took 25+ years to displace porcelain at scale. Conventional switchgear is still standard 130 years after invention. Betting against the installed base on a 2-year horizon has been historically a losing trade.

## Market view check

At $492 / 24.3× forward / 4.7× EV-sales, the market is pricing HUBB roughly as a **higher-quality Eaton** — same end-markets, smaller scale, slightly higher margins. Consensus PT $545 implies +11%. The implicit assumption is: (a) data-center growth in Electrical Solutions runs at >25% for multiple years, (b) Grid Infrastructure +10–12% organic continues through 2027, (c) Aclara stabilizes rather than declines structurally, (d) the M&A roll-up creates synergy rather than dilutes ROIC. Each of those is plausible but not all four are likely to hit; (c) is the most contested.

The directional read: **technical reality supports the grid story but not the multiple.** The stock is priced for the bull case to mostly play out. Asymmetry favors a small short-term short or a wait-for-pullback long entry, not a fresh full-position add at $493. Falsifiers below would change this.

## 90-day falsifiers

- **Q2 2026 earnings (late July 2026)**: Does Grid Automation/Aclara return to flat-to-slight-positive organic as guided, or does it deteriorate further? A second consecutive negative print is a structural-impairment signal.
- **Q2 2026 earnings**: Data-center growth in Electrical Solutions — does it stay >25%, or compress as the 40% Q1 print pulls forward orders?
- **Hyperscaler Q2 capex prints (META, MSFT, GOOG, AMZN; late July–early August)**: Any one of the four cutting 2026 capex by >10% sequentially is a direct read-through; broad reaffirm is supportive.
- **NSI deal regulatory progress**: HSR clearance timeline. A second-request from DOJ/FTC delays closing past mid-2026 and complicates the EPS-accretion thesis.
- **GE Vernova / Siemens Energy Q2 turbine commentary**: New backlog adds and pricing inform whether the broader power-build cycle is still extending.
- **FERC PJM co-located load order final rules**: A ruling that broadly permits behind-the-meter co-location at scale is incrementally bearish for utility-side connector demand (over years, not quarters).
- **Itron Q2 earnings + AMI 2.0 contract awards**: Any major IOU award (e.g., Duke, Southern, Dominion second-wave) that goes to Itron rather than Aclara confirms the Grid Automation share-loss thesis.
- **Insider activity**: Material insider selling above ~$520 would be a quality-of-management read on price level.

## What I could not verify

- **Exact share of HUBB total revenue from AI/data-center end-markets** — management discloses segment growth contribution but not a clean revenue percentage; my inference is roughly 15–20% of total revenue, accelerating toward 25%+, but this is not directly disclosed.
- **HUBB's share of the substation connector / arrester market** specifically — multiple sources cite leadership but no number puts HUBB head-to-head with Eaton Cooper, MacLean Power, PLPC at a category level [13].
- **DMC Power's post-close margin profile** — the $60M EBITDA on $130M revenue implies ~46% but standalone vs synergy-loaded splits are not public.
- **PCX backlog visibility in months** — management referenced "long-cycle" but did not size the backlog in months of revenue.
- **Direct hyperscaler customer concentration in PCX** — implied to be heavy in Meta/Microsoft/Amazon/Google but not enumerated.
- **HUBB's actual position on SST / 800V DC architectures** — no public R&D commentary; absence may be an absence of signal or an absence of disclosure.
- **Aclara meter-shipment volumes vs Itron Q1 2026** — Itron reports gross shipments but Aclara's are buried in segment commentary, making the share-loss vector hard to size with precision.

## Sources

[1] https://www.hubbell.com/hubbellpowersystems/en/markets/substation — retrieved 2026-05-10 — Hubbell substation product taxonomy (arresters, connectors, bushings, etc.).
[2] https://www.hubbell.com/hubbellpowersystems/en/products/power-utilities/arresters/substation-ieee/polymer — retrieved 2026-05-10 — confirms polymer arrester range 2.5–800 kV.
[3] https://www.globenewswire.com/news-release/2026/04/30/3284729/0/en/Hubbell-Reports-First-Quarter-2026-Results.html — retrieved 2026-05-10 — Q1 2026 results, segment revenue, raised 2026 guide ($19.30–$19.85 EPS, 8–11% sales growth).
[4] https://www.hubbell.com/burndy/en/data-center — retrieved 2026-05-10 — Burndy's data-center catalog including PDU/UPS/grounding scope.
[5] https://www.pcxcorp.com/products/skids — retrieved 2026-05-10 — PCX modular skid configuration and integration scope.
[6] https://stockanalysis.com/stocks/hubb/statistics/ — retrieved 2026-05-10 — Price $492.58 (2026-05-08), $26.03B market cap, $28.25B EV, 4.71× EV/Revenue, 24.33× forward P/E, 4.82% short interest.
[7] https://public.com/stocks/hubb/forecast-price-target — retrieved 2026-05-10 — 52-week range $346.07–$565.50; consensus PT $544.84; Stephens $600 (2026-05-04).
[8] https://seekingalpha.com/news/4546461-hubbell-anticipates-7-percent-to-9-percent-total-sales-growth-in-2026-as-grid-and-data-center — retrieved 2026-05-10 — full-year EPS guide and growth framing.
[9] https://meyka.com/blog/hubb-hubbell-earnings-beat-q2-2026-results-exceed-expectations-0205/ — retrieved 2026-05-10 — YTD return ~14.5% as of early May 2026.
[10] https://fintel.io/ss/us/hubb — retrieved 2026-05-10 — short interest 2.54M shares / 4.77% of float; 53.16M shares out.
[11] https://beyondspx.com/quote/NVT/nvent-electric-s-ai-infrastructure-transformation-growth-acceleration-meets-margin-compression-nyse-nvt — retrieved 2026-05-10 — comparative margins: Eaton 19.8%, HUBB 22.6%, nVent 16.0%; segment growth rates.
[12] https://www.hubbell.com/hubbellpowersystems/en/hps-brands/anderson — retrieved 2026-05-10 — Anderson brand heritage (130+ years) as connector OEM.
[13] https://hubbellcdn.com/catalogfull/Substation%20Connectors%20(SA).pdf — retrieved 2026-05-10 — Anderson/Fargo substation connector catalog scope.
[14] https://www.globenewswire.com/news-release/2025/08/12/3131593/0/en/Hubbell-to-Acquire-DMC-Power.html — retrieved 2026-05-10 — DMC $825M deal, $130M revenue, $60M EBITDA, 360° swage tool IP.
[15] https://info.pcxcorp.com/the-complete-guide-to-modular-data-centers — retrieved 2026-05-10 — modular DC delivery time ~30% faster than stick-built.
[16] https://www.globenewswire.com/news-release/2024/06/10/2895857/28124/en/Smart-Metering-in-North-Amercia-Report — retrieved 2026-05-10 — AMI share: Itron 35%, L+G 32%, Aclara 21%.
[17] https://www.fool.com/earnings/call-transcripts/2026/04/30/hubbell-hubb-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1 transcript: Grid Automation -7%, "utilities deprioritized AMI"; data-center +40% in Electrical; book-to-bill 1.2; PCX is "long-cycle" and half of data-center exposure.
[18] https://www.globenewswire.com/news-release/2026/05/04/3286597/0/en/Hubbell-to-Acquire-NSI-Industries.html — retrieved 2026-05-10 — NSI $3.0B (15.5× 2026 EBITDA), $570M revenue, mid-2026 close.
[19] https://www.utilitydive.com/news/ge-vernova-gas-turbine-backlog-hits-100-gw-as-prices-rise/818332/ — retrieved 2026-05-10 — GE Vernova 100 GW backlog Q1 2026, sold through 2030.
[20] https://www.industrialsage.com/power-transformer-lead-times-us-grid-shortage/ — retrieved 2026-05-10 — power transformer lead times 128 wks, GSU 144 wks (Q2 2025 survey).
[21] https://www.woodmac.com/press-releases/power-transformers-and-distribution-transformers-will-face-supply-deficits-of-30-and-10-in-2025/ — retrieved 2026-05-10 — 30% power / 10% distribution transformer supply deficit forecast.
[22] https://enkiai.com/data-center/amazon-private-power-interconnection/ — retrieved 2026-05-10 — ERCOT large-load queue 233 GW, 70% data center.
[23] https://www.gibsondunn.com/ferc-orders-pjm-largest-u-s-grid-operator-to-revise-tariff-to-permit-new-transmission-services-for-co-located-loads-such-as-data-centers/ — retrieved 2026-05-10 — FERC order on PJM co-located load tariff revisions.
[24] https://new.abb.com/news/detail/131879/LVS-EU-scales — retrieved 2026-05-10 — ABB MNS switchgear +120% capacity Brno/Rakovski, online Q2/Q3 2026.
[25] https://www.viksnewsletter.com/p/understanding-hvdc-architectures-ai-megafactories — retrieved 2026-05-10 — 800V DC architecture migration for AI megafactories.
[26] https://www.fool.com/earnings/call-transcripts/2026/04/30/hubbell-hubb-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1 2026 transcript detail: data-center growth, book-to-bill, capital allocation hierarchy (capex > M&A > buybacks).
[27] https://powerlines.org/wp-content/uploads/2026/04/0413_PowerLines-CapEx-Report-1.pdf — retrieved 2026-05-10 — US utility capex $259B (2026), $276B (2027); transmission/distribution/generation share split.
[28] https://www.utilitydive.com/news/doe-large-load-interconnection-ferc-naruc/806278/ — retrieved 2026-05-10 — DOE large-load interconnection proposal and federal-state jurisdictional fight.
[29] https://www.macrotrends.net/stocks/charts/HUBB/hubbell-inc/pe-ratio — retrieved 2026-05-10 — HUBB historical P/E (~17× 10-year average vs ~24× current).
[30] https://techcrunch.com/2026/02/18/heron-power-raises-140m-to-ramp-production-of-grid-altering-tech/ — retrieved 2026-05-10 — Heron Power $140M raise, 40 GW of customer interest letters, 34.5kV AC to 800V DC SSTs.
[31] https://techcrunch.com/2026/03/10/hyperscale-power-is-the-latest-startup-to-challenge-140-year-old-transformer-tech/ — retrieved 2026-05-10 — SST competitive set, >$330M collective funding across Hyperscale Power / Heron / Amperesand / DG Matrix.