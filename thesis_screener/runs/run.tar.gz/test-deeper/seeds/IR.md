# IR — Ingersoll Rand Inc.

## Where this sits in the AI stack
IR is a general-industrial OEM of air/gas compressors, blowers, vacuum pumps, and positive-displacement / fluid-handling pumps, organized into Industrial Technologies & Services (ITS, ~80% of revenue) and Precision & Science Technologies (PST, ~20%) [1][2]. Relative to the AI buildout, IR sits **two layers removed** from the GPU: it supplies (a) general plant utilities — oil-free compressed air, on-site N₂ — into semiconductor fabs and (b) low-pressure fluid-handling pumps (ARO) into data-center mechanical rooms for coolant/condensate loops [3][4]. It is not a vacuum supplier to EUV/CVD/ALD process tools at any scale, not a coolant-distribution-unit (CDU) OEM, and not the data-center HVAC/chiller franchise — that business was spun off as Trane Technologies (TT) in the 2020 separation [5]. Treat IR as an "AI-adjacent compounder," not an "AI infrastructure" name.

## Snapshot
- **Price:** $77.45 (2026-05-08 close) [6]
- **Market cap:** ~$30.3B [6][7]
- **52-week range:** $72.45 – $100.96 [8]
- **Forward P/E:** 22.1× (on FY26 EPS guide midpoint $3.51) [9]
- **EV / NTM revenue:** ~5.7× (EV ≈ $44.5B vs. FY26 revenue ~$7.84B at guide midpoint) [10][9]
- **Consensus 12-month price target:** ~$100 average across sources (range $82–$118), implying ~+29% [11]
- **YTD total return:** approx. −10% (stock peaked $100.96 on Feb-13-26 post-Q4 print, then corrected; precise YE-2025 close not verified — flagged below) [8][12]
- **Short interest (% of float):** 4.54% (latest disclosed, Nov-25; peer-group average 3.26%) [13]

## Moat — what it is physically made of
The IR moat is **not technological frontier-ness**; it is **distribution density × installed-base annuity × M&A roll-up of fragmented niches**. Decomposed:

1. **Installed base annuity.** Aftermarket parts, consumables and service = ~37% of revenue in Q1-26 [14]. A rotary-screw compressor or oil-free centac sold today drags 10–12 years of filters, separators, oil, bearings, and remote-monitoring (X-Series IIoT) revenue at gross margins >50% per IR's own commentary [14][2]. This is high-quality cash flow, but it is **not specific to AI**: a fab bought a compressor in 2014 and is still paying for service whether GPUs are 8 nm or 2 nm.

2. **Channel density.** ~5,500 distributor / branch touchpoints globally for compressors, including direct service. This is the actual reason IR holds share against Atlas Copco in North-American general industry — service-truck response time. It is **not a technical moat** and not relevant at the leading-edge fab, where Edwards and Ebara have on-site staff embedded.

3. **Engineering breadth in niche pumps.** PST contains Milton Roy (metering pumps), Haskel (high-pressure hydrogen pumps), Welch / Gardner Denver Thomas (lab vacuum), Air Dimensions, and the 2024 acquisition of **ILC Dover** ($2.325B; biopharma single-use bag and powder/liquid handling) [15]. This is technically real — Haskel's gas boosters are non-trivial, ILC Dover has aerospace heritage including NASA EMU spacesuits — but it is leveraged to **biopharma, hydrogen, and lab automation**, not to the AI compute stack.

4. **Where the moat is NOT.** IR does **not** participate in the strategic AI-adjacent moats:
   - **EUV-grade dry vacuum** (Edwards iH/iXH series, Ebara A-series, Pfeiffer Adixen): the top six vendors (Edwards, Atlas Copco, Pfeiffer, ULVAC, Busch, Ebara) hold ~62% of semiconductor vacuum revenue; Edwards alone ~22% [16][17]. IR is not in this top tier.
   - **CDU / direct-to-chip cooling** for >100 kW/rack NVL72-class deployments: Vertiv, nVent, Boyd, CoolIT, Schneider, and (now) Trane via LiquidStack [18].
   - **Water-cooled centrifugal chillers** for the data-center mechanical plant: Trane Technologies (former parent), Carrier, Johnson Controls, Daikin.

   IR's "data center" page foregrounds ARO diaphragm pumps for cooling-water/condensate handling and centrifugal blowers for power-gen flue-gas duty [3][4][19] — useful, low-strategic-value subsystems sold downstream of the architecture decision.

5. **Roll-up math.** Capital allocation under CEO Vicente Reynal is the real engine: 25+ acquisitions since 2020, mostly bolt-ons at single-digit-to-low-teens EBITDA, levered into IR's distribution to deliver synergies [20][15]. This is a **process moat**, not a technology moat, and process moats are durable only while the M&A pipeline of fragmented targets remains deep and capital is cheap.

Inference (not directly sourced): a credible replicator with $10B+ capital and ~10 years could rebuild positions in industrial compression and PST end markets. The replication cost is high enough to prevent immediate competition, but it is **orders of magnitude lower** than what is required to replicate Edwards's process-vacuum service network or Trane's chiller franchise.

## AI buildout bottleneck map
Specific 24-month gating constraints and IR's relationship to each:

| Bottleneck | 2026–27 reality | IR's position |
|---|---|---|
| **Power generation / grid interconnect** | GE Vernova HA-class gas-turbine slots booked into 2028; behind-the-meter natural gas dominant [21] | **Indifferent** to OEM share but supplies *combustion air blowers and CCUS vacuum* into gas-turbine peakers; Q1-26 announced one carbon-capture blower+vacuum win for "power generation for data centers" — early-stage, immaterial [22] |
| **Advanced packaging (CoWoS-L)** | TSMC CoWoS capacity ~75kwpm exit-2025 ramping toward ~135kwpm exit-2026, still the binding constraint on Blackwell/Rubin volume | **Indifferent** — IR has no meaningful packaging exposure |
| **HBM yield / supply** | SK hynix dominant on HBM3e; Micron/Samsung closing | **Indifferent** |
| **EUV / process vacuum** | ASML High-NA ramp; each EUV needs 40–60 vacuum pumps per tool; each fab module 200–300 dry pumps [16] | **Marginal beneficiary indirectly** via clean-dry-air and N₂ to the fab; **not in the strategic process-vacuum bill of materials**, where Edwards / Ebara win |
| **Optical interconnect / co-packaged optics** | TSMC SoIC + photonics; Coherent/Lumentum lasers | **Indifferent** |
| **Liquid cooling at >100 kW/rack** | NVL72 ships standard with direct-to-chip cold plates; CDU and rack-manifold market doubling annually [18] | **Exposed as a component supplier** — ARO can sell pumps into a CDU BOM but does not architect the unit; pricing power is captured by the CDU integrator, not IR |
| **Electrical contractor / switchgear capacity** | Eaton, Vertiv, Schneider switchgear lead times 50+ weeks | **Indifferent** |
| **Cooling-tower / chiller capacity** | Lead times stretched; mechanical refrigerant constraints | **Indifferent at IR; this is the Trane Technologies story** |

Net: IR is at most a **second-derivative beneficiary** of AI capex. It is not a constraint owner anywhere on the critical path.

## Competitive teardown
- **vs. Atlas Copco (Compressor Technique + Vacuum Technique / Edwards).** This is the binding comparison. On general industrial air compression, IR and Atlas Copco are duopoly co-leaders in North America with IR holding edge in mid-tier rotary screw and Atlas Copco in oil-free centrifugal and VSD [23]. On semiconductor process vacuum — the AI-relevant axis — Atlas Copco (via Edwards) is in a **different league**: ~22% global share, exclusive-spec position at TSMC/Samsung/Intel leading-edge nodes, dedicated CHIPS-Act-funded New York plant for 4-week US lead times on semi-grade dry screws vs. 12–16 weeks Asian imports [16][17]. Electronics is ~⅔ of Atlas Copco's Vacuum Technique revenue and ~⅕ of group revenue [24]. **IR has no realistic 24-month path to take share in that bill of materials**; the qualification cycle on a new process tool is 18–36 months of co-engineering with the tool OEM (LAM, AMAT, TEL, ASML) and a fab.
- **vs. Trane Technologies (former parent).** TT now owns the high-margin data-center thermal layer end-to-end: chillers, heat-rejection, controls, liquid distribution, and as of March-2026 the LiquidStack direct-to-chip / immersion stack [18][5]. IR shareholders who think they own a data-center cooling option do not — that option is in TT.
- **vs. Vertiv, nVent, Schneider, Eaton.** These are the data-center-native equipment vendors with direct hyperscaler relationships. IR does not appear in published NVL72 / GB200 reference designs as a named subsystem supplier.
- **vs. Parker Hannifin, Roper, Dover.** Closer-to-peer industrial compounders. Parker is the dominant motion-control and filtration peer; Roper is the better software/recurring-revenue analog. IR's premium ~20× EV/EBITDA is roughly in line with this set, slightly above Parker, below Roper — not getting a discrete AI multiple.
- **vs. Busch, Pfeiffer, Ebara, ULVAC.** Tier-1 process-vacuum specialists that IR is not. Combined ~50% global share of semi vacuum [16][17].

What would have to be true for an IR re-rating *up* on the AI axis: PST's carbon-capture vacuum/blower wins scale beyond pilot, OR ITS lands a multi-year compressor + N₂ frame agreement with a US fab cluster (Arizona/Ohio/Texas) that is disclosed and quantified. Neither is in numbers today.

## Bull case — technical
1. **Aftermarket flywheel keeps compounding.** ~37% aftermarket revenue grows mid-single-digits independent of new-equipment cycle as the installed base ages [14]. IIoT remote monitoring (X-Series) pulls more service-contract attach. This is real and self-funding.
2. **PST mix-shift to life science.** Life-science orders +double-digit in Q1-26 [25]. ILC Dover scales single-use biopharma; Milton Roy / Haskel into hydrogen-economy capex. This is a credible 4–6% organic growth corridor even with industrial weak.
3. **Indirect semicap exposure inflects.** New US fabs in AZ/OH/TX collectively >$200B over 5 years all need clean-dry-air, house N₂, and general utilities [17] — a slow-burn ITS tailwind through 2028, sized in the high-single-digit-percent-of-revenue range (inference; not directly disclosed).
4. **Capital deployment.** ~$3–4B/yr M&A capacity into a fragmented $65B addressable market [15]; mid-teens IRR target on bolt-ons; ~95% FCF conversion guided for 2026 [22] gives optionality.
5. **Base-rate framing.** Industrial compounders with quality M&A and aftermarket mix (Roper, TransDigm, Heico) have historically rerated to 25–30× EPS once recurring revenue crosses ~40%. IR at 22× forward is reasonable if it converges to that archetype.

For the bull to monetize at materially above the consensus PT, organic growth has to inflect from the guided ~1% to ~4%+, which requires the semicap utilities and life-science doubles to actually show up in segment disclosure.

## Bear case — technical
1. **The AI premium is misattributed.** Investors who anchored on the 2020-era "Ingersoll Rand = cooling" narrative are paying a multiple that the **current** IR P&L does not earn. Q1-26 transcript contained **zero** mentions of NVIDIA, GPU, Blackwell, hyperscaler, or liquid cooling [12]. The "carbon capture for data centers" win is a single pilot-stage announcement, not a revenue line.
2. **Organic growth is decelerating.** ITS organic orders **−3%** in Q1-26 (or "approximately flat" excluding $40M of Middle East push-outs) [25]. FY26 organic guide ~1% at midpoint [9]. A 22× forward multiple on ~1% organic growth and 5% EPS growth is rich relative to historical industrial-compounder math.
3. **Tariffs and margin pressure.** Q2-26 management guided segment margins **50–100 bps down y/y** [12]; tariff pass-through is incomplete; PST mix is the only positive driver.
4. **Roll-up math is sensitive to rates.** ~$13–14B net debt post-ILC Dover; the M&A engine works on synergized 8× → 5–6× post-deal economics, which compresses if rates stay elevated or if quality targets get bid up. The deal pipeline of mid-teens-EBITDA bolt-ons at high-single-digit multiples is finite.
5. **No moat in the highest-growth AI-cooling sub-stack.** A short-seller's question: "Show me where IR competes for the >100 kW/rack thermal architecture, not where IR's pumps end up in someone else's CDU." The honest answer is "we don't, but we have aftermarket." That is a fine industrial-compounder pitch at a 16× multiple; at 22× with declining organic orders, it is exposed.
6. **Base rate.** Industrial roll-ups (Roper, Fortive, Dover) trading on serial-acquirer multiples have re-rated **down** during industrial recessions — Roper from 33× to 22× in 2022, Dover from 22× to 14× in 2018. IR has not been tested through a meaningful downcycle in its current form.

## Market view check
Price $77.45, forward P/E 22.1×, EV/EBITDA ~20.6× (FY26 guide midpoint) [9][6]. Consensus $100 PT implies ~+29% — that target embeds a re-acceleration of organic growth to mid-single-digits and continued M&A accretion at historical economics. The price is **consistent** with treating IR as a high-quality industrial compounder, but **inconsistent** with treating it as an AI-infrastructure beneficiary at the level implied by the 24× peak multiple it had in February 2026 [8]. The 23% correction off the Feb high suggests the market is **already partly re-pricing the AI-adjacency premium out**, but not yet back to industrial-cyclical multiples. The market appears to believe in the M&A flywheel and the PST life-science story; my disagreement is narrower — I would not pay an AI multiple at all, and at 22× the margin of safety against an organic-growth disappointment in 2H-26 is thin.

## 90-day falsifiers
Specific, observable events through August 2026 that would update materially:
1. **Q2-26 earnings (late July 2026)**: ITS organic orders +5%+ y/y, or commentary specifically quantifying AI-data-center exposure (e.g., "data center accounts for X% of revenue growing Y%"). Either confirms bull. Absence again confirms bear.
2. **Q2-26 margin print**: if segment EBITDA margins are flat-to-up vs. guided −50/−100 bps, tariff pass-through is working.
3. **Atlas Copco Q2-26 Vacuum Technique organic growth print (mid-July)**: if VT growth >20% y/y, leading-edge semi-cycle is back — IR will see derivative benefit on a 2-quarter lag in clean-dry-air orders.
4. **TSMC AZ Phase 2 / Intel Ohio One construction milestone announcements**: ground-breaking events trigger IR utilities orders 12–18 months later — track for pipeline visibility.
5. **Carbon-capture follow-on order announcement**: a second customer for the Aqualung / IR blower+vacuum CCUS skid would suggest the pilot is becoming a product line.
6. **M&A activity**: announcement of a >$1B deal in PST or a data-center-adjacent niche (e.g., a CDU specialist) would either validate or undermine the strategy depending on price paid.
7. **Insider activity**: open-market buying below $75 by CEO Reynal or CFO Maslin would be a confidence signal; further sales above $90 would be a tell.
8. **Sell-side downgrade of FY27 EPS below $3.69** (current Zacks figure) [9] — would indicate Street capitulation to lower-for-longer organic growth.

## What I could not verify
- **Specific data-center revenue $ or % of IR total.** Management does not disclose it; my "indirect / second-derivative" framing is inference from product portfolio and the absence of disclosure, not a sourced number.
- **Specific semiconductor-fab revenue.** IR markets to "electronics & semiconductor" as an end-market but does not break out the share; based on product positioning (general utilities, not process vacuum), I estimate it is high-single-digit percent of revenue at most — flagged as inference.
- **Precise YE-2025 close and therefore YTD return.** I estimated ~−10% from the Feb-26 peak trajectory; a confirmed 12/31/25 close is needed.
- **Edwards's exact 2025 revenue inside Atlas Copco Vacuum Technique.** Atlas Copco aggregates VT revenue at the BA level and does not separately disclose Edwards.
- **Whether IR's ARO pumps appear in any published NVL72 / GB200 reference CDU design.** I could not find IR named as a subsystem supplier in any hyperscaler-disclosed AI rack BOM.
- **The actual size of the Q1-26 carbon-capture data-center order.** Described as "selected to provide" but no dollar amount or shipment timeline disclosed [22].
- **Forward consensus revenue figure used in EV/NTM rev**; I used the FY26 guide midpoint rather than a true street consensus number, which could differ.

## Sources
[1] https://en.wikipedia.org/wiki/Ingersoll_Rand — retrieved 2026-05-10 — corporate structure, history of 2020 separation creating current IR and Trane Technologies.
[2] https://www.investing.com/news/company-news/ingersoll-rand-q4-2025-slides-revenue-up-10-eps-beats-expectations-93CH-4505839 — 2026-05-10 — segment mix (ITS ~80%, PST ~20%), aftermarket ~36.5% of revenue.
[3] https://www.irco.com/en/industries/ingersoll-rand-data-center-solutions/ — 2026-05-10 — IR's stated data-center solutions (ARO pumps for cooling, power, condensate).
[4] https://www.arozone.com/en/ — 2026-05-10 — ARO product positioning for AI/HPC site fluid handling.
[5] https://en.wikipedia.org/wiki/Trane_Technologies — 2026-05-10 — 2020 separation; Trane Technologies retains HVAC/data-center cooling.
[6] https://public.com/stocks/ir/market-cap — 2026-05-10 — price $78.65 on 2026-05-06, mkt cap $30.78B; later print $77.45 on 2026-05-08.
[7] https://tradingeconomics.com/ir:us:market-capitalization — 2026-05-10 — market cap ~$30.3B early May 2026.
[8] https://markets.financialcontent.com/stocks/article/barchart-2026-3-11-ingersoll-rand-stock-is-ir-underperforming-the-industrial-sector — 2026-05-10 — 52-wk range $72.45–$100.96; Feb-13-26 peak at $100.96; ~14% off high mid-March.
[9] https://www.americanbankingnews.com/2026/04/24/zacks-research-predicts-reduced-earnings-for-ingersoll-rand.html — 2026-05-10 — FY26 EPS guide $3.45–$3.57; FY27 Zacks $3.69; FY26 EBITDA guide $2.13–$2.19B.
[10] https://www.gurufocus.com/stock/IR/forecast — 2026-05-10 — EV ~$44.5B.
[11] https://stockanalysis.com/stocks/ir/forecast/ — 2026-05-10 — consensus PT range $82–$118, average ~$100.
[12] https://www.fool.com/earnings/call-transcripts/2026/04/29/ingersoll-rand-ir-q1-2026-earnings-transcript/ — 2026-05-10 — Q1-26 transcript: no mention of NVIDIA/GPU/hyperscaler/liquid cooling; Q2 margin guide −50/−100bps; FCF conversion ~95%.
[13] https://www.benzinga.com/insights/short-sellers/25/11/48935095/peering-into-ingersoll-rand-incs-recent-short-interest — 2026-05-10 — short interest 4.54% of float (Nov-25); peer average 3.26%.
[14] https://www.panabee.com/news/ingersoll-rand-earnings-2025-annual — 2026-05-10 — aftermarket 36.5% of revenue 2025, 37% Q1-26; installed-base annuity model; recurring revenue ~$450M in 2026.
[15] https://investors.irco.com/news/news-details/2024/Ingersoll-Rand-Closes-on-ILC-Dover-and-Announces-Acquisition-of-Three-Additional-Companies/default.aspx — 2026-05-10 — ILC Dover closing at $2.325B, expands TAM to ~$65B; PST positioning.
[16] https://www.marketgrowthreports.com/market-reports/semiconductor-dry-vacuum-pump-market-103670 — 2026-05-10 — semi vacuum market structure; top-six vendors hold ~62% (Edwards/Atlas Copco, Pfeiffer, ULVAC, Busch, Ebara); 40–60 pumps per EUV tool.
[17] https://www.atlascopcogroup.com/content/dam/atlas-copco/group/documents/investors/financial-publications/swedish/20251126-capital-markets-day-2025-vacuum-technique-se.pdf.coredownload.pdf — 2026-05-10 — Atlas Copco Vacuum Technique Capital Markets Day Nov-2025; electronics ~⅔ of VT revenue; CHIPS Act NY plant for 4-week semi-grade dry-screw delivery.
[18] https://investors.tranetechnologies.com/news-and-events/news-releases/news-release-details/2026/Trane-Technologies-Completes-Acquisition-of-LiquidStack/default.aspx — 2026-05-10 — Trane closed LiquidStack acquisition Mar-3-26; end-to-end DC thermal stack including direct-to-chip and immersion.
[19] https://www.gardnerdenver.com/en-us/about-us/news/ir-enable-material-transportation-06232022 — 2026-05-10 — IR (Gardner Denver legacy) vacuum positioning in industrial materials handling.
[20] https://tracxn.com/d/acquisitions/acquisitions-by-ingersoll-rand/__maxMK22F-7xv_SyyejZVC8zrBay_GHruO8PhE2Uq5zQ — 2026-05-10 — 25 acquisitions since 2020 under Reynal.
[21] https://www.gevernova.com/gas-power/resources/articles/2025/carbon-capture-and-modern-data-centers — 2026-05-10 — GE Vernova framing of CCUS economics for behind-the-meter data-center gas turbines.
[22] https://www.benzinga.com/insights/news/26/04/52127013/full-transcript-ingersoll-rand-q1-2026-earnings-call — 2026-05-10 — Q1-26 transcript: "Innovation in Action" carbon-capture vacuum+blower win mentioning data-center power-gen application; FY26 guide; 1.07x book-to-bill.
[23] https://www.ttl-holdings.com/en-us/media/blog-articles/airman-atlas-copco-ingersoll-rand-air-compressor — 2026-05-10 — comparative positioning of major industrial air-compressor OEMs.
[24] https://www.morningstar.com/company-reports/1040682-atlas-copcos-exposure-to-semiconductor-demand-boosting-short-term-revenue-growth — 2026-05-10 — Atlas Copco semiconductor exposure framing; electronics ~⅕ of group revenue via Vacuum Technique.
[25] https://www.investing.com/news/company-news/ingersoll-rand-q1-2026-slides-earnings-beat-masks-organic-weakness-93CH-4645577 — 2026-05-10 — Q1-26 organic orders breakdown (ITS −3%, PST +1%); Life Sciences double-digit orders; $40M Middle East delays.