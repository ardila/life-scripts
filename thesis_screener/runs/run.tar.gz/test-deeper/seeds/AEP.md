# AEP — American Electric Power Company, Inc.

## Where this sits in the AI stack
AEP is a regulated, multi-state vertically integrated electric utility whose 40,000-mile transmission system — including 2,200 miles of 765 kV extra-high-voltage (EHV) lines, the largest such network in North America [7] — physically delivers the bulk power that frontier-scale AI training campuses consume. Its relevance to AI is at the deepest layer of the stack: the bulk transmission system that moves GW-scale blocks of generation from coal/gas/wind sites to hyperscaler load centers, and the regulated retail interconnection that allows new data centers >25 MW to actually energize. AEP does not touch silicon, packaging, or software; it sells the kilowatt-hours, the firm capacity entitlements, and (most importantly) the right-of-way and EHV substation capacity without which Stargate-class campuses cannot run [3][7][12].

## Snapshot
- **Price:** $137.11 (2026-05-01 close) [1]
- **Market cap:** $72.84B [1]
- **52-week range:** $97.46 – $137.74 [9]
- **Forward P/E:** 20.9× (on FY26E EPS midpoint of $6.30; guide $6.15–$6.45) [9][2]
- **EV / NTM revenue:** ~5.7× — inferred from ~$72.8B equity + ~$48B net debt vs. ~$24B NTM revenue (Q1 2026 revenue $6.02B annualized) [2][16]
- **Consensus 12-month price target:** $138–$141 (implied ~+1–3%) [9][22]
- **YTD total return:** +14.5% (vs. XLU +2.3%) [11]
- **Short interest (% of float):** 3.5% [22]
- **Dividend yield:** 2.8% ($3.80 annualized) [9]

## Moat — what it is physically made of

AEP's moat is **not** "regulated monopoly" in the abstract. Decompose it:

**1. The 765 kV EHV backbone (durable, ~10–15 yr replacement cost).** AEP energized the first 765 kV line in North America in 1969 and today operates 2,200 miles across six states with 30 substations [7]. A single 765 kV circuit moves ~6× the power of a 345 kV circuit at roughly half the line losses [7]. For a 1+ GW data-center campus, this matters in a non-substitutable way: at 345 kV you need 2–3 parallel circuits and corresponding right-of-way; at 765 kV, one. The physical asset that is genuinely scarce is *the right-of-way and the 765 kV substation slots*, not the conductor itself. Replicating AEP's 765 kV footprint would require multi-decade siting and condemnation processes through Appalachia, central Ohio, and now west Texas. The new 765 kV STEP Eastern Backbone in ERCOT — 300 miles, Solstice (Fort Stockton) to San Antonio — is the first 765 kV in Texas history; AEP Texas is the lead developer alongside Oncor/CPS [12][14]. This is the relevant capability moat: AEP is the only US utility with operational 765 kV experience at scale.

**2. FERC formula-rate transmission ROE.** AEP Transmission HoldCo (AEPTH) earns a 9.85% base ROE + 50 bps RTO membership adder on a FERC formula rate that updates annually with capex; AEPTH's trailing realized ROE has been ~11.3%, the highest of any AEP rate base [10]. FERC formula rates allow recovery of construction work in progress (CWIP) — i.e., AEP earns on dollars *being spent today*, not just on completed assets [29]. With $33B of the $78B 5-year plan (42%) flowing into transmission [3], this is a near-mechanical translation from capex into earnings. State-jurisdictional generation does not work this way; lag and disallowance risk are higher.

**3. Multi-jurisdictional regulatory footprint as a hedge.** AEP's 11 states (notably AEP Ohio in PJM, AEP Texas in ERCOT, I&M in MISO, PSO/SWEPCO in SPP) [13] mean no single PUC can derail the data-center growth thesis. ERCOT and PJM exposure are independent regulatory regimes with independent rules.

**4. The new "anti-stranded-cost" tariff structure (durable but legally contested).** PUCO approved AEP Ohio's 2024 Data Center Tariff on 7/9/2025 (effective 7/23/2025): new data centers >25 MW must pay for 85% of contracted capacity monthly regardless of actual use, post collateral, demonstrate financial viability, and commit to a 4-year ramp + 8-year minimum (12-year total), with three-year-equivalent exit fees [4][5]. Indiana Michigan Power has a parallel agreement signed by Amazon, Google, Microsoft, and the Data Center Coalition [3]. This is the key risk-adjusted moat: it transfers the speculative-booking risk from ratepayers/AEP back to the hyperscaler.

What is **not** a moat: brand, generation fleet (much of which is retiring coal — 5.6 GW by 2030 [17]), or distribution. Anyone who tells you AEP's "moat" is the integrated utility model is wrong; the moat is specifically transmission + tariff structure + 765 kV know-how.

## AI buildout bottleneck map

The 24-month AI buildout is gated, in approximate order of severity:

1. **Gas turbine slots (severe).** GE Vernova's heavy-duty gas turbine backlog reached 80 GW exiting 2025, reservation slots 56 GW, with delivery sold out through 2029 and likely through 2030 by year-end 2026 [15]. Siemens Energy's backlog is €136B, also multi-year [15]. Installed CCGT cost has roughly doubled in 15 months from ~$1,000/kW to $2,000–$2,500/kW [15]. **AEP's position: exposed customer.** Its $24B generation capex — including a 918 MW gas plant at Sycamore Riverside (Indiana, 2029 commissioning) — sits in the same queue [3][27]. AEP can pass costs through, but project-timing risk is real.

2. **Transmission build (severe; AEP's edge).** PJM interconnection queues now average 8 years from application to commercial operation, up from <2 years in 2008 [6]. Wood Mackenzie has PJM utilities forecasting 55 GW of new large load by 2030 and 100 GW by 2037 [6]. **AEP's position: beneficiary and constraint owner.** AEP literally builds the EHV that relieves this constraint — and earns FERC ROE on it. Its $33B transmission capex (42% of plan) is the largest-dollar bet on this bottleneck by any US investor-owned utility.

3. **Capacity (acute, near-term).** PJM 2026/27 base residual auction cleared at the FERC-approved cap of $329.17/MW-day, up ~11× from $28.92 in 2024/25; 2027/28 cleared at the new cap of $333.44/MW-day, with ~5,100 MW of the YoY peak-load increase attributable to data centers [8][16]. Without the Shapiro collar, 2027/28 would have cleared near $530/MW-day [16]. **AEP's position: net beneficiary** as a vertically integrated utility in PJM (sells capacity from owned generation; retail customers see passthroughs).

4. **Interconnection queue talent and field labor (moderate).** Substation transformers (3-phase 765/345/138 kV), HV breakers, and field labor are all backlogged 2–4 years [6][15]. Inference, not cited: AEP's incumbent crews and existing service contracts are themselves an advantage versus greenfield merchant developers.

5. **Behind-the-meter / colocation as a bypass (the bottleneck AEP needs to *contain*).** This is the **competitive** bottleneck — see next section. FERC has so far ruled in AEP's favor (twice rejecting the Talen-AWS behind-the-meter ISA), and on 12/18/2025 ordered PJM to develop transparent colocation rules that explicitly contemplate a minimum transmission charge for colocated load [25][26]. This is the single most important regulatory decision affecting AEP over the next 24 months.

6. **HBM, CoWoS, optical, liquid cooling.** Indifferent. AEP's revenue is invariant to which silicon is in the rack as long as something is.

## Competitive teardown

The competitive question is *not* "which utility competes with AEP" (regulated geographies are exclusive) but **"who can supply power to AEP's prospective data-center customers without using AEP's wires?"** Three vectors:

**(a) Behind-the-meter colocation (Talen/Constellation/Vistra at nuclear sites).** Talen's original deal would have sold 480 MW from Susquehanna to AWS without using PJM transmission. FERC rejected the ISA twice (Nov 2024, April 2025) on a 2-1 vote, finding insufficient justification for deviating from pro forma ISA terms; the deal was restructured as a 17-year, 1.92 GW *in-front-of-the-meter* PPA [18][19]. **AEP and Exelon were the named challengers**, citing $140M/yr in transmission cost shifts [18]. The Dec 2025 FERC order extends this logic: PJM must build a tariff with new firm and non-firm transmission services for colocated load, with potential minimum charges [25][26]. **Verdict: as of May 2026, colocation is contained, not killed.** It remains the largest single threat to AEP's growth thesis. If FERC reverses or PJM's compliance filing (due Feb 2026, replies April 17 [25]) carves out generous BTM exceptions, AEP loses customer captivity at the margin.

**(b) Other utilities competing for hyperscaler campus siting.** Dominion (D) is in talks for 40–47 GW of data-center capacity in Northern Virginia (~70% of internet traffic transits) [4][20]. Dominion is more concentrated geographically (single-state regulatory risk) but has the densest existing fiber/colo ecosystem. AEP's edge: ERCOT exposure (Dominion has none) gives geographic diversification *and* access to the Permian/Stargate buildout, which is now physically sited in AEP Texas territory (Abilene Stargate, Solstice→San Antonio 765 kV) [12][14]. **On a per-GW-of-contracted-load basis, AEP (63 GW [2]) is now ahead of Dominion (40–47 GW [20]) and well ahead of any other regulated peer.**

**(c) SMRs as a 2030+ alternative path.** BWRX-300 first unit at Darlington targeting late 2029/2030; TVA Clinch River 2032 [21]. Kairos, X-energy, TerraPower all 2030–2035. **For the 2026–2030 capex cycle, SMRs are irrelevant to the demand thesis** — they cannot supply enough capacity in time. AEP itself is exploring an SMR site at Rockport (post-coal) with TVA/GEH [27], which is option value, not present-tense moat or threat.

What would have to be true for a competitor to take share: FERC reverses the colocation order; *or* hyperscalers successfully litigate the AEP Ohio tariff at PUCO and federal courts (Amazon, Google, Meta, Microsoft + Ohio Manufacturers Association are challenging it [4]); *or* PJM allows BTM nuclear deals as the default architecture. None of these has obviously happened as of May 2026.

## Bull case — technical

Base rate first: regulated utility moats erode slowly. The CPU→GPU shift took ~10 years from first credible threat to displacement; on-prem→cloud took ~8. Physical infrastructure with right-of-way easements, FERC-jurisdictional formula rates, and 50+ year asset lives is far stickier than software platforms — historical comp is closer to railroads (where Class I network footprints have been stable for ~80 years) than semiconductors. **The base rate for regulated-utility transmission moat erosion over a 5-year window is low.**

Specific technical conditions for outperformance:
1. **PJM colocation compliance filing (April 2026 → final order ~late 2026)** preserves transmission cost recovery from BTM/colocated loads. If PJM follows FERC's signaled preference for a meaningful minimum transmission charge [25][26], AEP retains transmission revenue even from BTM data centers.
2. **63 GW of contracted load by 2030 holds and continues to grow** [2]. The 7 GW Q-on-Q growth in Q1 2026 is the relevant trajectory; even at 50% materialization (vs. Georgia Power's 50%+ dropout rate [23]), the 85% take-or-pay floor [4] insulates AEP earnings.
3. **Gas turbine and EHV bottleneck persists**, keeping PJM/ERCOT capacity prices elevated and making AEP's owned generation valuable on the margin (PJM 2027/28 at $333/MW-day cap [16]).
4. **SMRs slip from 2030 to 2032+**, lengthening the period during which gas+transmission is the only feasible answer for >100 MW campuses.

Financial translation: 11% rate base CAGR × roughly stable allowed ROE in the ~10% band ≈ 9%+ EPS growth [3]. At a 20.9× forward P/E with a 2.8% yield, that's an ~11–12% expected total return — equity-like, with regulated cash flows.

## Bear case — technical

The honest version a short with stack knowledge would write:

1. **Speculative load is the bigger risk than the headline number suggests.** "Contracted load" is not the same as energized load. Georgia Power's pipeline collapsed by >50% even after they thought 93% would sign [23]. NERC issued a Level 3 alert on data-center load losses (60 Virginia data centers dropped off the grid simultaneously in one incident [23]). The 85% take-or-pay tariff is *contractual*, not bulletproof — Amazon/Google/Meta/Microsoft + Ohio Manufacturers Association are actively challenging it as discriminatory [4]. If a court strikes it down or grandfathers it, AEP is left with $33B of transmission and $24B of generation capex against load that may not show up.

2. **AI capex is itself the demand variable.** The 63 GW figure is a derivative of hyperscaler capex pace. Hyperscaler capex ran $112B in a single quarter in early 2026 [referenced in source 24], but that pace is not contractually committed past current PPAs. A 25% cut in 2027 capex guidance from any two of MSFT/META/GOOGL/AMZN/ORCL would cascade into deferred data-center groundbreakings, which cascades into deferred energization, which cascades into deferred AEP rate-base additions.

3. **Behind-the-meter is contained but not dead.** Talen lost twice, but FERC could reverse with a Republican commissioner shift; the Dec 2025 PJM order explicitly leaves the door open to colocation under new rules [25]. Constellation (CEG) has the largest US nuclear fleet and the strongest theoretical BTM optionality. If CEG signs a Susquehanna-style deal that *does* clear FERC, the precedent is set and AEP's transmission revenue from large loads becomes contestable.

4. **CCGT cost doubling ($1,000 → $2,000–2,500/kW [15]) compresses generation-segment ROE** even with passthrough, because regulatory lag exists between spend and inclusion in rate base, and prudency reviews can disallow overruns. The IURC ruling on Sycamore Riverside (expected by end of 2026 [27]) is a near-term test.

5. **Stock is at the top of the 52-week range, near consensus PT.** $137 vs. $138–$141 PT [9][22] means the fundamental thesis is largely priced in. Forward P/E of 20.9× is a meaningful premium to the regulated electric peer median (~19×) [28] and to DUK (~18.3×) and NEE (~18.2× forward) [28]. The premium is justifiable if 9% growth is real, but contracts at ~1× PEG.

## Market view check

The market is paying ~21× forward earnings for a regulated utility that historically traded 16–18×. The premium is narrowly justified by 9% earnings growth (vs. ~6% historic peer norm) driven by 11% rate base CAGR [3]. **The market is pricing AEP as a credible — but not certain — beneficiary of the AI buildout.** It is *not* pricing in either (a) the upside scenario where 63 GW becomes 80+ GW with intact tariff protections, or (b) the downside scenario where take-or-pay is litigated away. The asymmetry is mildly attractive on the upside but the consensus PT is essentially at spot, meaning there is no near-term catalyst-pull from sell-side revisions; the next leg requires another Q-on-Q step in contracted load, a favorable PJM compliance filing, or both. Versus Dominion (more concentrated, similar multiple) AEP is the diversified play; versus Constellation/Vistra (merchant/nuclear, much higher multiples) AEP is the lower-vol way to express the same demand thesis.

## 90-day falsifiers

1. **PJM compliance filing on colocation tariff (initial briefs filed Feb 16, 2026; replies April 17, 2026; final FERC action likely Q3 2026).** [25] If the proposed minimum transmission charge for colocated load is <$5/MW-day (de minimis) or has broad grandfathering, the AEP moat is materially weaker. If it is meaningful (>$50/MW-day) and applies retroactively, the Talen/AWS-style structure is dead and AEP's thesis tightens.
2. **AEP Q2 2026 earnings (early August 2026): contracted-load delta.** Q1 was +7 GW Q/Q to 63 GW [2]. <+3 GW is a deceleration signal; >+10 GW confirms acceleration.
3. **Hyperscaler Q2 2026 capex prints.** Any of MSFT/META/GOOGL/AMZN cutting FY26 capex guidance by >10% is a leading indicator for AEP load materialization.
4. **Ohio Supreme Court / federal court ruling on the data center tariff appeal** filed by Amazon/Google/Meta/Microsoft + OMA [4]. A remand to PUCO would re-open the take-or-pay question.
5. **IURC decision on the Sycamore Riverside 918 MW gas plant CPCN** (expected by end of 2026, but procedural orders likely in next 90 days) [27]. A disallowance or substantial cost-cap signals Indiana regulatory risk.
6. **GE Vernova Q2 2026 turbine slot pricing and 2030 reservation pace** [15]. If turbine reservations sell out 2030 ahead of schedule, AEP's gas pipeline gets more expensive (bear) but AEP's *transmission* alternative (bringing in remote generation via 765 kV) gets more valuable (bull).

## What I could not verify

- AEP's *energized* large-load number (vs. contracted) — i.e., the GW that is actually drawing power vs. the 63 GW signed. Disclosure quality on this is poor across the regulated utility complex; AEP gives total contracted but the Q1 transcript I could access did not break out energized vs. contracted vs. tariff-conditional.
- The specific share of the 63 GW contracted load that is tariff-protected at 85% take-or-pay vs. legacy contracts at lower minimums.
- Realized ROE on AEPTH for the 12 months ended 12/31/2025 (verified prior-year ROE of 11.3% [10]; 2025 number not located).
- Updated AEP credit ratings (S&P/Moody's senior unsecured) for 2026; only FFO/Debt range of 13.9–15.2% confirmed [24].
- Whether the new ERCOT 765 kV STEP project is in AEP's $78B capex plan in full or whether incremental upside exists. ERCOT board endorsed $9.4B for the broader 765 kV build [7]; AEP Texas's allocated share is not cleanly disclosed.
- Hyperscaler counter-litigation timing on the AEP Ohio tariff at the federal level (only state-level PUCO rejection of appeal verified [4]).

## Sources

[1] https://finance.yahoo.com/quote/AEP/ — retrieved 2026-05-10 — AEP price ($137.11), market cap ($72.84B), trading range.
[2] https://news.alphastreet.com/american-electric-power-aep-beats-q1-2026-estimates-as-data-center-demand-drives-78-billion-capital-plan/ — retrieved 2026-05-10 — Q1 2026 EPS $1.64 beat, 63 GW contracted load, $78B capex, 11% rate base CAGR.
[3] https://www.aep.com/news/stories/view/11917/ — retrieved 2026-05-10 — AEP Q1 2026 earnings release: $78B 5-year capex, $33B transmission, $24B generation, $6.15–$6.45 FY26 EPS guide.
[4] https://www.powermag.com/regulator-approves-aep-ohios-landmark-data-center-tariff/ — retrieved 2026-05-10 — PUCO 7/9/2025 approval of AEP Ohio data center tariff: 85% take-or-pay, 4+8 yr structure, hyperscaler+OMA opposition.
[5] https://kjk.com/2025/11/14/regulating-surge-legal-analysis-aep-ohios-data-center-tariff-and-pucos-approval/ — retrieved 2026-05-10 — Legal analysis of tariff effective 7/23/2025; >25 MW threshold; collateral and exit-fee mechanics.
[6] https://www.utilitydive.com/news/solving-pjms-data-center-problem/805600/ — retrieved 2026-05-10 — PJM 8-yr interconnection timeline (vs <2 yr in 2008); Wood Mackenzie 55 GW by 2030 / 100 GW by 2037.
[7] https://www.aep.com/about/businesses/transmission/765kv/ — retrieved 2026-05-10 — 2,200 mi 765 kV; 6× capacity vs 345 kV; first energized 1969; 30 substations across six states.
[8] https://www.utilitydive.com/news/pjm-interconnection-capacity-auction-data-center/808264/ — retrieved 2026-05-10 — PJM 2026/27 BRA cleared at $329.17/MW-day cap.
[9] https://stockanalysis.com/stocks/aep/statistics/ — retrieved 2026-05-10 — 52-wk range $97.46–$137.74; forward P/E 20.86×; $3.80 dividend / 2.8% yield; consensus PT $141.38.
[10] https://docs.aep.com/docs/investors/Rate_Base_and_ROE_12-31-25.pdf — retrieved 2026-05-10 — AEPTH base ROE 9.85% + 50 bps RTO adder; trailing realized 11.3% AEPTH ROE.
[11] https://stockanalysis.com/etf/xlu/ — retrieved 2026-05-10 — XLU YTD 2026 +2.3% baseline for AEP outperformance comp.
[12] https://www.aep.com/news/stories/view/10165/ — retrieved 2026-05-10 — AEP Texas first 765 kV in ERCOT, 300 mi Solstice→San Antonio.
[13] https://www.aep.com/about/businesses/opcos/ — retrieved 2026-05-10 — Operating subsidiaries: AEP Ohio, AEP Texas, AppPower, I&M, KY Power, PSO, SWEPCO across 11 states.
[14] https://www.zeroemissiongrid.com/insights-press-zeg-blog/ercot-765-kv-infrastructure/ — retrieved 2026-05-10 — ERCOT 43 GW demand growth by 2030; data centers + Stargate Abilene siting.
[15] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — GE Vernova 80 GW backlog; 56 GW reservations; sold out through 2030 by year-end 2026; CCGT installed cost doubling to $2,000–2,500/kW.
[16] https://insidelines.pjm.com/pjm-auction-procures-134479-mw-of-generation-resources/ — retrieved 2026-05-10 — PJM 2027/28 BRA $333.44/MW-day at FERC cap; 5,100 MW data center–driven peak load increase.
[17] https://www.powermag.com/aep-will-shutter-nearly-half-its-giant-coal-power-fleet-5-6-gw-by-2030/ — retrieved 2026-05-10 — AEP retiring 5.6 GW coal by 2030; Northeastern (2026), Rockport 1 (2028), Cardinal share (2030).
[18] https://www.utilitydive.com/news/ferc-interconnection-isa-talen-amazon-data-center-susquehanna-exelon/731841/ — retrieved 2026-05-10 — FERC rejected Talen-AWS BTM ISA Nov 2024; AEP and Exelon were named challengers ($140M/yr cost shift).
[19] https://www.datacenterfrontier.com/energy/article/55264293/talen-energy-continues-behind-the-meter-power-fight-for-aws-data-center-campus — retrieved 2026-05-10 — Restructured Talen-AWS as 17-yr, 1.92 GW front-of-meter PPA after FERC double rejection.
[20] https://www.canarymedia.com/articles/utilities/data-centers-are-driving-us-power-demand-to-hard-to-reach-heights — retrieved 2026-05-10 — Dominion 40–47 GW data center contract talks; Northern Virginia 70% of internet traffic.
[21] https://world-nuclear.org/information-library/nuclear-power-reactors/small-modular-reactors/small-modular-reactor-smr-global-tracker — retrieved 2026-05-10 — BWRX-300 timelines: Darlington 2029/30, TVA Clinch River 2032; broader SMR 2030–2035 cohort.
[22] https://www.marketbeat.com/stocks/NASDAQ/AEP/forecast/ — retrieved 2026-05-10 — Consensus PT $138.18 Moderate Buy; short interest 19.21M shares = 3.54% of outstanding (542.38M).
[23] https://www.utilitydive.com/news/utilities-data-center-risk-buildout-bubble-ai-infrastructure-grid/812781/ — retrieved 2026-05-10 — Speculative interconnects 5–10× actual builds; Georgia Power dropout >50%; NERC Level 3 alert on DC load losses; Virginia 60-DC simultaneous drop incident.
[24] https://docs.aep.com/docs/newsroom/resources/earnings/2026-02/4Q25EarningsReleasePresentation.pdf — retrieved 2026-05-10 — FFO/Debt 15.2% (S&P) / 13.9% (Moody's); 14–15% target.
[25] https://www.bdlaw.com/publications/ferc-orders-pjm-to-create-clear-rules-for-co-located-data-centers-and-large-loads/ — retrieved 2026-05-10 — FERC 12/18/2025 order: PJM colocation tariff reform; Feb 16 / Mar 18 / Apr 17 2026 briefing schedule; potential minimum transmission charge.
[26] https://www.ferc.gov/news-events/news/ferc-directs-nations-largest-grid-operator-create-new-rules-embrace-innovation-and — retrieved 2026-05-10 — FERC fact sheet: three new transmission service options for colocated load; BTM rule reforms.
[27] https://www.aep.com/news/stories/view/11850/ — retrieved 2026-05-10 — I&M filing for Sycamore Riverside 918 MW gas CT in Sullivan County IN; 2029 commissioning; IURC decision target end-2026.
[28] https://stockanalysis.com/stocks/industry/utilities-regulated-electric/ — retrieved 2026-05-10 — Regulated electric utilities weighted avg P/E 19.27×; NEE forward 18.2×, DUK forward 18.3×.
[29] https://foleyhoag.com/news-and-insights/blogs/energy-and-climate-counsel/2024/february/unpacking-recent-ferc-orders-on-transmission-rate-incentives-a-download-for-developers/ — retrieved 2026-05-10 — FERC transmission incentive structure: 50 bps RTO adder, CWIP recovery, ROE adders for risk.