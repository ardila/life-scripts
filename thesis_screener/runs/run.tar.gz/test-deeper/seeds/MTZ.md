# MTZ — MasTec, Inc.

## Where this sits in the AI stack
MTZ sits at the **physical-power-and-fiber layer beneath the data center** — it does not sell silicon, packaging, memory, or software. Specifically, MasTec is a North American specialty infrastructure construction (E&C) contractor whose four segments — Power Delivery (utility T&D), Pipeline Infrastructure (large-diameter natural-gas mainline + midstream), Clean Energy & Infrastructure (utility-scale solar/wind/storage EPC + General Buildings, including data center site/civil), and Communications (wireless + wireline fiber) — are the trades that translate hyperscaler announcements into working kilowatts and bits. The relevant workloads are the AI training-cluster *power and connectivity envelope*: high-voltage transmission to the substation gate, gas mainline to the behind-the-meter generation, and fiber to/between data center campuses [1][2].

## Snapshot
- **Price:** $412.27 (2026-05-07 close) [3]
- **Market cap:** ~$34.3B [4]
- **52-week range:** $145.27 – $441.43 [5]
- **Forward P/E:** 46.9× (FY26 consensus/midpoint EPS $8.79) [4][6]
- **EV / NTM revenue:** ~1.81× ($31.64B EV / $17.5B FY26 guide) [6][4]
- **EV / NTM EBITDA:** ~21× ($31.64B EV / $1.5B FY26 guide) [6][4]
- **Consensus 12-month price target:** $425.27 average (range $340 – $518); implied ~+3% [7]
- **YTD total return:** ~+74% (from $236.35 close on 2026-01-06) [8][3]
- **Short interest (% of float):** 3.65% [9]
- **Net leverage:** 1.8× EBITDA; net debt ~$2.54B [4][6]

## Moat — what it is physically made of
The honest answer: MTZ has **no software/silicon moat**. It is a labor + equipment + relationship business, and the moat must be assessed on those terms — which means it is real but shallower and more replicable than a CUDA stack, and it is bounded above by what the underlying skilled-trades labor pool can grow. Decomposed:

1. **Skilled-craft headcount.** MTZ added ~6,000 employees YoY in Q1'26 (~2,000 sequentially) to a base now in the mid-30,000s [10]. The binding constraint on T&D and pipeline buildout is journeyman lineworkers, splice technicians, and welders. The DOE reports 89% of T&D contractors have at least "some difficulty" hiring qualified workers; the industry needs to step from ~45k apprenticeships/yr to ~65k just to meet projected demand [11]. This is the moat: *the people are the bottleneck and MTZ owns one of the two largest pools in North America.* Replication time for a new entrant is roughly the apprenticeship-to-journeyman cycle, ~4-7 years at scale, and MTZ runs internal training programs that competitors must duplicate in parallel — not a 6-month software port.

2. **Master Service Agreements (MSAs) with utilities and pipeline operators.** MasTec runs multi-year, often sole-sourced or alliance-based contracts. Q1'26 commentary explicitly noted "customers continue to show high confidence in MasTec, seeking deeper integration and partnership through alliance agreements, sole-sourced contracts" [10]. These are awarded based on safety record (energized-line work has fatality consequences), schedule reliability, and bonding capacity — switching costs for a utility are real because mid-project re-tendering creates outage risk on assets earning regulated returns. Durability: high inside Power Delivery (utility-customer concentration is sticky over 5-10 year cycles), medium in Pipeline (project-by-project bidding still common on mainline), low in DC General Buildings where hyperscaler procurement is more transactional.

3. **Specialty equipment fleet.** Insulated bucket trucks, helicopter platforms for energized 500/765-kV work, large-diameter HDD (horizontal directional drilling) rigs for pipeline, mainline pipeline construction spreads. This is capex MTZ has accumulated; FY26 capex guide is only ~$220M [10] against a $34B market cap, so the fleet is largely in place. Replication cost for a peer is meaningful but not prohibitive (single-digit-billion order of magnitude).

4. **Family/founder control and the Mas family network.** Jorge and Jose Mas have run the company since the 1990s, with deep relationships in U.S. utility and midstream C-suites. This is brand/relationship moat — soft, but underrated when bidding on multi-year alliances.

5. **What is *not* a moat:** technology, IP, software, or any patent estate that matters. There is no "CUDA equivalent." The company's 10-K does not lean on patents. Anything MTZ does, Quanta (PWR), Primoris (PRIM), and to a lesser extent Centuri/MYR can do — the differentiator is scale and execution at scale, not capability.

**Bottom line on moat:** Real but shallow per unit, deep in aggregate because the *whole industry* is supply-constrained. The moat is more "owning a meaningful share of a structurally short input (skilled labor)" than "owning a unique technology." That is enough to print outsized returns *as long as the industry stays supply-constrained* — but it does not protect the stock from cyclical demand swings the way a true tech moat would.

## AI buildout bottleneck map
Mapping the actual gating constraints for the next 24 months and where MTZ sits:

| Constraint | Status | MTZ position |
|---|---|---|
| **Gas-turbine deliveries** | GE Vernova backlog ~80 GW into 2029, slot reservations 56 GW, expected sold out through 2030 by year-end '26; Siemens Energy and Mitsubishi backlogs to ~2030 [12][13] | **Indirect beneficiary.** When turbines land, MTZ does the gas lateral feeding them and the substation tying them to the grid. Pipeline segment Q1'26 revenue +92% YoY is the leading edge of this [10]. |
| **Large power transformers** | Standard LPT lead time ~128 weeks, GSUs ~144 weeks, some 210 weeks; ~80% imported; Hitachi/Siemens/Prolec adding domestic capacity but online '27-'28 [14] | **Beneficiary.** MTZ doesn't make transformers but is the installer/integrator at the substation. Constrains *project pace* — a tailwind for backlog optionality (work doesn't expire), not a headwind for revenue. |
| **PJM/MISO interconnect queues** | PJM approved $6.7B 765-kV backbone Feb'25; new single-window 2026 cycle imposes stricter cost-share; data-center load in Northern Virginia overwhelming existing capacity [15][16] | **Direct beneficiary.** $6.7B backbone build is exactly MTZ + Quanta-shaped work. MTZ's $6.2B Power Delivery backlog (record, 1.6× book-to-bill) is partly this [10]. |
| **Skilled-craft labor (linemen, welders)** | DOE: 89% of T&D contractors hiring with difficulty; need ~65k apprenticeships/yr (up from 45k); 6-8% wage hikes in 2026 [11] | **Constraint owner / beneficiary.** This is MTZ's moat *and* its growth ceiling. Wages flow through but cost-plus and indexed contracts limit margin damage; book-to-bill of 1.6× implies pricing power. |
| **Liquid cooling >100 kW/rack & in-rack power** | Distinct from MTZ's scope — happens *inside* the building | **Indifferent.** This is EMCOR's lane (mechanical/electrical contracting inside the white space), not MTZ's. |
| **CoWoS-L / HBM3e** | TSMC packaging and SK hynix/Micron HBM | **Indifferent.** Zero exposure. |
| **Fiber connectivity for AI campus interconnect** | Hyperscaler demand for low-latency, redundant interregional fiber spiking | **Direct beneficiary.** Communications backlog $5.5B; management called it "tens of billions, multi-year" [10][17]. |
| **Data-center site/civil + general buildings** | Hyperscaler EPC fragmented; MTZ ranked #22 in DC construction by ENR [18] | **Late-cycle entrant.** ~$1B in DC-related awards secured, $1B+ in active RFP [18]. Real but small relative to total mix. |

The clean read: **MTZ is leveraged to four of the actual bottlenecks (transmission, fiber, gas pipeline, electrical labor) and indifferent to the four most-discussed ones (silicon, packaging, HBM, in-rack)**. That's the technical case for owning it as an "AI infrastructure" name.

## Competitive teardown
The relevant axes are scale-of-craft-labor and segment overlap. Sell-side typically lumps these together — they shouldn't.

- **Quanta Services (PWR):** The clear scale leader. Total backlog $43.98B (vs. MTZ $20.3B) at end of 2025, with Electric Infrastructure Solutions alone >$36B [19]. PWR has parity-or-better capability on every MTZ axis except Pipeline (where MTZ is structurally stronger after the Henkels & McCoy footprint), and is roughly 2.7× MTZ's scale. **What would have to be true for PWR to take share from MTZ:** essentially nothing — they already have parity on most axes. The relevant question is whether the *combined* PWR + MTZ duopoly captures the bulk of incremental T&D capex, which seems likely given that no third player has the bonding capacity for $500M+ transmission projects. This is more rising-tide-lifts-both than head-to-head share war.

- **EMCOR (EME):** Different product. EMCOR is mechanical/electrical *inside the building* — chillers, busways, inside-the-white-space wiring. RPO of $4.3B in Network & Communications at Q3'25, doubled YoY [20]. **Overlap with MTZ on data centers is partial** — MTZ does site/civil/utility tie-in; EMCOR does the building MEP. They are complements far more than competitors.

- **Primoris (PRIM):** Roughly half MTZ's scale at $11.6B backlog Q1'26 [21]. Recently bought Paynecrest to add data center MEP/HVAC capability. PRIM is the most direct strategic threat in Pipeline + utility distribution, less so in transmission (it lacks the energized-line track record and bonding scale). **Falsifier:** if PRIM's data center backlog grows >50% sequentially over the next 2 quarters, that signals fragmentation of hyperscaler procurement away from MTZ/Quanta.

- **Dycom (DY):** Pure-play telecom/fiber. Direct competitor to MTZ Communications only. Not a power or pipeline threat.

- **Hyperscaler self-perform / direct-trade-hire:** Real but bounded risk. Meta and Microsoft have selectively direct-hired electrical contractors on individual campuses; this is a margin headwind on DC General Buildings if it accelerates. **It does *not* affect Power Delivery or Pipeline,** because hyperscalers don't run utility T&D — the utility does, and the utility hires MTZ.

The honest read: **MTZ does not have a unique competitive position vs. PWR.** What it has is a cheaper multiple, a faster recent growth rate, and meaningfully higher operating leverage (Pipeline cycling back from trough is the swing factor PWR doesn't have). The pair-trade is more interesting than the standalone long.

## Bull case — technical
**Technical conditions required:**
1. U.S. data center load growth continues at >15% CAGR through 2028, with the marginal megawatt sourced from gas (driving Pipeline) plus renewables (driving Clean Energy & Infrastructure) plus grid imports (driving Power Delivery). EIA-implied paths and hyperscaler capex commentary support this; GE Vernova's order pull-forward (2026 orders >2025 full year for electrification equipment) is corroborating evidence [12].
2. Gas turbine slots stay sold out through 2030 — this guarantees ~5 years of Pipeline tailwind because new generation requires new gas lateral connections. Management's $3B+ Pipeline revenue target for 2027 (vs. $2.4B base implied by Q1 run-rate) is consistent [10].
3. PJM's $6.7B 765-kV backbone executes on time, and MISO/SPP follow with similar plans. This is the multi-year bedrock of Power Delivery's $6.2B backlog growing further [15].
4. Skilled-craft constraint persists — ironically, this is bullish: it preserves pricing power and book-to-bill >1.4×.
5. Quanta and MTZ continue to operate as a rational duopoly on large transmission rather than a price war.

**Connect to financials:** if those hold, $17.5B FY26 → $22-25B FY28 is achievable, EBITDA margin walks from 8.6% to ~10% on Pipeline mix-shift, getting to ~$2.3B FY28 EBITDA. At 18× (the 5-year average for MTZ in good cycles), that's ~$40B EV / ~$36B equity, or ~5% upside from here over 2 years — i.e., **the bull case is mostly priced in at 21× NTM EBITDA**. The real bull case is multiple expansion to ~25× on the view that this is the new "AI utility" comp set, which is plausible but is a multiple call, not a fundamental call.

**Base rate:** Specialty E&C and pipeline-construction names re-rate violently both ways. PWR and MTZ doubled 2006-2007 then fell ~60% in 2008-09; doubled again 2020-2021, fell ~50% in 2022 when shale capex rolled. Average peak-to-trough drawdown from cycle-high entries: ~50%, recovery time ~2-3 years. Treat this as cyclical infrastructure, not as secular tech.

## Bear case — technical
**Technical conditions under which the thesis breaks:**
1. **Hyperscaler capex roll.** If Microsoft, Meta, Google, or Amazon cuts FY27 capex guidance materially (>10% sequential), data center power growth slows immediately. The lag from capex cut to MTZ revenue is ~6-9 months on the construction side. The signal to watch is hyperscaler Q3/Q4 '26 capex commentary; any "digestion phase" language is the leading indicator.
2. **Pipeline cycle déjà vu.** Pipeline revenue ran at $2.5-3B/yr in 2018, then collapsed to ~$1.5B in 2020 when shale capex was cut. The 92% YoY growth this quarter is *exactly* the 2017 setup [10]. If gas-fired buildout is delayed by NEPA, FERC, or state-level moratoria (Virginia, New Jersey, New York are already friction points), Pipeline's Q1'26 run-rate proves to be the cycle peak.
3. **AI training topology shift to inference-optimized clusters reduces frontier-cluster sizing.** If FP4/MoE plus distillation halves the kW/parameter for incremental AI capacity, the marginal data center is smaller, sited more flexibly, and demands less new transmission. This is the version that matters most because it would erase the secular tailwind that justifies the multiple.
4. **Hyperscaler vertical integration on DC EPC.** Direct-hire of mechanical and electrical contractors compresses MTZ's margin in General Buildings, the highest-multiple-justifying piece of the C&I segment. Watch hyperscaler 8-K disclosures of DC subsidiaries and direct-trade hires.
5. **Multiple compression to peer median.** MTZ trades at ~21× NTM EBITDA vs. a 10-year specialty E&C average of ~10-12×. Even with the secular AI premium, ~15× is more defensible. Compression to 15× holding $1.5B EBITDA is ~$22.5B EV vs. current $31.6B — about -28% on equity even if numbers come in.
6. **Family-control governance discount.** Jorge and Jose Mas exercise voting control via a dual-class structure (the "Class B" overhang), which is a permanent ~5-10% discount in long-only models that can widen in any related-party transaction.

The bear case I'd write as a short: MTZ is a very good cyclical at the wrong point in the cycle to underwrite at 46× forward earnings. The "AI" rerating layered onto a Pipeline cycle peak gives ~30-40% downside if either of those reverts.

## Market view check
At $412 / 46× FY26 EPS / 21× NTM EBITDA, the market is pricing MTZ as a high-growth secular AI infrastructure beneficiary, not as a cyclical specialty E&C. Consensus PT $425 implies the sell-side is roughly flat from here, which is unusual after the print and suggests analyst skepticism is also building. The price embeds: (a) >20% revenue CAGR through 2028, (b) 100-150 bps of EBITDA margin expansion, (c) Pipeline normalizing at $3B+ rather than mean-reverting to $1.5B, and (d) no multiple compression. **The market believes MTZ has stepped into a structurally different growth regime.** I think this is partially right (the bottleneck map is real) but overshoots on multiple — at 15× NTM EBITDA the technical thesis I described is fully reflected; today's 21× requires the AI rerating to be permanent, which historical base rates say it won't be.

## 90-day falsifiers
1. **MTZ Investor Day, May 12, 2026 [22]:** Long-term EBITDA margin target. Anything below 10% would undercut the multiple; >12% by 2028 would extend it. Watch ROIC target (mgmt has signaled >10% currently expanding).
2. **Hyperscaler Q2 capex commentary (late Jul / early Aug):** Any sequential capex guidance cut from MSFT/META/GOOG/AMZN of >5% prints as a direct read-through to forward Power Delivery and DC bookings.
3. **GE Vernova / Siemens Energy Q2 backlog disclosure:** If gas turbine slot reservations push past 60 GW (vs. 56 GW reported in Q1'26), confirms the Pipeline tailwind for 2027-28 [12].
4. **Q2 MTZ book-to-bill (early Aug):** Below 1.2× total or below 1.4× in Power Delivery would mark a backlog inflection. Above 1.5× extends the upcycle case.
5. **PJM 2026-cycle interconnection study results:** If PJM signals further cost-shifting onto load (data centers), expect a near-term hyperscaler pause that ripples to MTZ Power Delivery 6-9 months later.
6. **DOE/FERC large-load interconnection rule [16]:** Federal rule that would centralize co-located DC interconnection authority would accelerate transmission spend (bullish MTZ); state-level resistance and delays would slow it (bearish).
7. **Specific data center award announcements:** The "$1B+ in active DC RFPs" [18] should convert into named contracts within 90 days; absence would dent the General Buildings rerating.

## What I could not verify
- Exact percentage of MTZ FY26 revenue tied directly to data-center end-customers (vs. utility customers serving data centers indirectly). Management gives "tens of billions multi-year" qualitatively but not a clean disclosure.
- Specific named hyperscaler contracts. The "turnkey data center award" referenced in Q1'26 [10] is unnamed; the customer identity matters for assessing concentration risk.
- Margin profile of DC general-buildings work vs. core T&D. Management implied accretive; competitor disclosures (EMCOR) suggest mid-single-digit EBIT, not the 8-9% segment levels MTZ runs in T&D.
- True split of Pipeline backlog between "AI-driven gas-fired generation laterals" vs. legacy LNG export and shale-gathering work. The 92% YoY growth could be more LNG than AI.
- Lineworker headcount as a precise number — MTZ does not publicly disclose craft-vs-overhead split; "added 6,000 employees" is the only granularity [10].
- Whether Quanta and MTZ have explicit price-discipline behavior on overlapping bids, or merely capacity-constrained behavior that looks like discipline. This matters for the duopoly thesis under demand stress.
- Detail on the dual-class share structure's voting overhang — only inferred from prior 10-K patterns; would need to re-read the most recent proxy.

## Sources
[1] https://www.mastec.com/expertise/oil-gas/ — retrieved 2026-05-10 — MasTec corporate description of pipeline construction capabilities.
[2] https://en.wikipedia.org/wiki/MasTec — retrieved 2026-05-10 — Company background, segment structure, history.
[3] https://www.investing.com/news/transcripts/earnings-call-transcript-mastecs-q1-2026-earnings-beat-forecasts-stock-rises-93CH-4653674 — retrieved 2026-05-10 — Q1'26 earnings transcript and post-print stock prices.
[4] https://stockanalysis.com/stocks/mtz/statistics/ — retrieved 2026-05-10 — Market cap, EV, debt, valuation multiples (April 17, 2026 snapshot).
[5] https://www.wallstreetzen.com/stocks/us/nyse/mtz — retrieved 2026-05-10 — 52-week range and trading-day metrics.
[6] https://investors.mastec.com/static-files/12a728b2-93a1-4e8d-ac42-b2e564ac48ff — retrieved 2026-05-10 — MasTec FY26 guidance ($17.5B revenue / $1.5B EBITDA / $8.79 EPS / $220M capex).
[7] https://www.wallstreetzen.com/stocks/us/nyse/mtz/stock-forecast — retrieved 2026-05-10 — Consensus 12-month PT $425.27 (range $340-$518).
[8] (Implied via) Same Yahoo/Marketbeat history — retrieved 2026-05-10 — Jan 6, 2026 close $236.35 → May 7, 2026 close $412.27 (~+74% YTD).
[9] https://www.benzinga.com/insights/short-sellers/25/01/42859540/mtz-analyzing-mastecs-short-interest — retrieved 2026-05-10 — 3.65% short interest as % of float; days-to-cover 2.83.
[10] https://www.fool.com/earnings/call-transcripts/2026/05/01/mastec-mtz-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Q1'26 segment revenue/backlog detail, hyperscaler/DC commentary, FY26 guide raise, employee adds, alliance/sole-sourced contract language, Pipeline 2027 $3B+ target.
[11] https://www.powermag.com/bridging-the-gap-how-the-power-industry-is-tackling-its-workforce-crisis/ — retrieved 2026-05-10 — DOE 2025 data on T&D contractor hiring difficulty (89%) and apprenticeship gap (45k → 65k/yr needed).
[12] https://www.utilitydive.com/news/ge-vernova-gas-turbine-investor/807662/ — retrieved 2026-05-10 — GE Vernova ~80 GW gas turbine backlog into 2029, 56 GW slot reservations as of Q1'26, expected sold out through 2030.
[13] https://www.power-eng.com/gas/turbines/data-centers-drive-record-surge-in-ge-vernova-power-equipment-orders-as-turbine-slots-tighten-through-2030/ — retrieved 2026-05-10 — Data center demand and Siemens Energy / Mitsubishi capacity expansion plans through 2026.
[14] https://www.powermag.com/transformers-in-2026-shortage-scramble-or-self-inflicted-crisis/ — retrieved 2026-05-10 — LPT lead times 128-210 weeks, ~80% imported, Hitachi/Siemens/Prolec capacity adds online 2027-2028.
[15] https://www.zeroemissiongrid.com/insights-press-zeg-blog/pjm-2026-cycle/ — retrieved 2026-05-10 — PJM 2026 interconnection cycle changes; $6.7B 765-kV backbone approved Feb'25.
[16] https://www.utilitydive.com/news/doe-large-load-interconnection-ferc-naruc/806278/ — retrieved 2026-05-10 — DOE proposal on large-load interconnection and federal/state jurisdictional friction.
[17] https://finviz.com/news/182345/mastecs-record-backlog-a-springboard-for-double-digit-growth-ahead — retrieved 2026-05-10 — Communications $5.5B backlog (Q4'25), composition of MTZ backlog by segment.
[18] https://www.constructiondive.com/news/mastec-earnings-data-centers-finances-q1/715447/ — retrieved 2026-05-10 — MTZ data center positioning: $150M completed + $200M backlog + $1B RFPs in pursuit; ENR rank #22 in data centers.
[19] https://www.tradingview.com/news/zacks:bdd69d49b094b:0-quanta-vs-mastec-which-infrastructure-stock-is-the-better-buy/ — retrieved 2026-05-10 — Quanta total backlog $43.98B at end of 2025; Electric Infrastructure Solutions >$36B; relative scale comparison.
[20] https://finance.yahoo.com/news/data-center-expansion-continue-support-131400052.html — retrieved 2026-05-10 — EMCOR Q3'25 Network & Communications RPO of $4.3B (~doubled YoY); 2026 margin commentary.
[21] https://www.fool.com/earnings/call-transcripts/2026/05/06/primoris-prim-q1-2026-earnings-transcript/ — retrieved 2026-05-10 — Primoris Q1'26 backlog $11.6B; Paynecrest acquisition closed May 1.
[22] https://www.stocktitan.net/news/MTZ/mas-tec-to-host-2026-investor-tx7s7wu317ja.html — retrieved 2026-05-10 — MasTec Investor Day scheduled May 12, 2026, NYC; will release medium-term financial outlook and ROIC targets.