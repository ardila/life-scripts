# EOG — EOG Resources, Inc.

## Where this sits in the AI stack
EOG does not sit in the AI stack. It is an upstream oil & gas E&P (#1 standalone independent by market cap in its peer group) with operations in the Delaware Basin (Permian), the Eagle Ford and Dorado dry-gas play in South Texas, the Utica (post-Encino), the Powder River, and an offshore Trinidad gas business [3][8]. Its only credible AI nexus is as a **fuel-supply optionholder** for behind-the-meter gas turbines powering hyperscaler campuses: it controls ~1.1M net Utica acres and ~520k acres of standalone (non-associated) Dorado dry gas — the two assets executives explicitly market to data-center offtakers because, unlike Permian associated gas, they can be ramped, contracted, and stranded against a single load [13]. So treat EOG as a **commodity producer adjacent to** the AI buildout, not as a participant in it.

## Snapshot
- **Price:** $129.42 (2026-05-08 close; May 10 is a Sunday) [1]
- **Market cap:** $69.3B [1][9]
- **52-week range:** $101.59 – $151.87 [1]
- **Forward P/E:** ~12–13× on 2026 consensus EPS of $9.63; stockanalysis.com prints 8.0× on NTM EPS — the gap reflects whether you anchor to calendar-2026 consensus or annualized Q1 run-rate. Use 12× as central. [2][9]
- **EV / NTM revenue:** ~3.1× (EV $70.1B / TTM revenue $22.6B) [9]
- **Consensus 12-month price target:** $143.81 (Buy; +11% from spot) [15]
- **YTD total return:** ~+29% to +35% (sources diverge on measurement date in early May) [1]
- **Short interest (% of float):** 3.0% [9]
- **Dividend yield:** 3.0% on $4.08 annualized; 9 consecutive years of base-dividend hikes [4]

## Moat — what it is physically made of
The moat is **subsurface inventory selection × vertical integration × balance-sheet discipline**, not brand or scale. Decomposed:

1. **"Premium" / "double premium" inventory framework.** EOG's internal hurdle is wells delivering >30% direct after-tax IRR at flat $40 WTI (premium) or $40/$2.50 (double premium). The 2025 Delaware program is reported at >100% direct after-tax return at $55 WTI [a strong number, but on a per-well, ex-overhead basis] [11]. This screen has historically kept EOG out of speculative leasing booms.
2. **Lateral length × completion design.** 2–3 mile laterals in Delaware, 3–4 mile in Utica/Eagle Ford [2]. Drilled-feet/day up 22% YoY in Utica, 13% in PRB, 12% in Eagle Ford in 2026 [2]. Internal drilling-motor program is a self-built force multiplier on long laterals — competitors typically rent from Halliburton/SLB/Baker Hughes.
3. **Self-sourced inputs.** Owns three Wisconsin frac-sand mines + two processing plants (~$0.5M/well saved historically) [14]; pipes 95% of water (drilling, completion, produced) [14]; owns Verde Pipeline (1.0 Bcf/d, Dorado→Agua Dulce) [10]. This is uncommon at this depth in US E&P — most peers outsource sand & water to OFS specialists and basin midstream.
4. **Well costs.** ≤$725/foot Delaware with 30% longer laterals; 20% absolute reduction 2023→2025; ~45% of 2026 well costs locked in [11].
5. **Capital-plan breakeven.** ~$50 WTI for the entire 2026 plan including the regular dividend [11]. That is a structurally lower number than ExxonMobil's Permian-only program and most independent peers.
6. **LNG-linked marketing portfolio.** ~280 MMBtu/d JKM/HH-linked + 300 MMBtu/d HH-linked already, +140 MMBtu/d (JKM/HH) in 2026 and +180 MMBtu/d (Brent/USGC) in 2027 under the Vitol SPA [10][6]. Plus 250 mb/d crude-export capacity giving Brent-linked oil pricing [2].

**Durability per component:**
- Subsurface: **mortal.** Tier-1 Permian inventory at $50 WTI is "largely exhausted for public operators"; remaining inventory needs $65–75 WTI to break even per industry analysis [12]. EOG's 1H 2025 Permian wells already showed steep per-foot productivity declines vs. 2024 vintages [11]. The Encino deal ($5.6B for 675k Utica acres + ~2 BBoe undeveloped resource) is partly an inventory-extension move [3].
- Vertical integration: **durable.** Sand mines and water pipes don't get displaced; rebuilding takes 5+ years and $1B+.
- Cost discipline: **cultural, hard to copy.** Survived multiple cycles. ExxonMobil/Pioneer can match scale but not corporate-wide hurdle-rate culture.
- LNG-linked exposure: **growing but small.** Still a single-digit % of total volume; the moat here is contract optionality, not yet a structural margin advantage.

## AI buildout bottleneck map
The next-24-month AI-driven energy bottlenecks and EOG's position relative to each:

| Bottleneck | EOG's role |
|---|---|
| **Power generation (gas turbines for hyperscalers)** | Indirect supplier of feedstock. Real but mediated through midstream/marketers and turbine OEMs — EOG does not own turbines or sign retail PPAs. |
| **Permian gas takeaway** (Waha discounts, currently constraining) | Beneficiary of relief: Blackcomb (2.5 Bcf/d), Hugh Brinson (1.5 Bcf/d initial, 2.2 Bcf/d after Phase 2), Gulf Coast Express +570 MMcf/d all entering 2H26 [7]. EIA still expects constraints to recur in early 2026 [7]. |
| **LNG export demand** | Beneficiary. RBN: new LNG additions through 2030 will demand ~3× as much gas as new gas-fired data-center plants [5]. EOG's Verde Pipeline + Vitol SPA give it priced access. |
| **Behind-the-meter standalone gas** | **Constraint owner.** Utica and Dorado are dedicated dry-gas plays — EOG explicitly markets these as preferable to associated gas for hyperscaler offtakers because they're contractible and don't depend on oil-driven drilling cadence [13]. No signed hyperscaler PPA disclosed. |
| **Frac sand & completion water** | Self-sourced — neutralized [14]. |
| **Drilling rigs & frac crews** | Net beneficiary — locks in capacity at scale; smaller operators get squeezed when service costs spike. |
| **Tier 1 inventory (geological scarcity)** | Constraint owner via Encino acquisition [3]; relative beneficiary as competitors' Permian inventory degrades. |
| **Power grid interconnect / turbine backlog** | Indifferent — that's a problem for hyperscalers and IPPs, not E&Ps. |

## Competitive teardown
On the technical axes that matter for a US oil & gas E&P:

- **ExxonMobil (post-Pioneer).** Direct overlap in Delaware. Pioneer added depth that arguably beats EOG on raw Permian inventory life. XOM targets 2 mmboed Permian by 2030 (current ~1.3 mmboed) [12]. **EOG wins** on multi-basin (Utica, Eagle Ford, Dorado, PRB), capital efficiency per BOE, and standalone-gas optionality. **Loses** on scale, integrated downstream/chemicals.
- **ConocoPhillips (post-Marathon).** Permian + Bakken + Eagle Ford + Alaska + intl. Bigger and more diversified. Less standalone-gas optionality. Roughly comparable cost discipline.
- **Chevron (post-Hess).** Permian + offshore. Less direct overlap with EOG's gas thesis.
- **Diamondback Energy (post-Endeavor).** Permian pure-play. Very low LOE. Shares EOG's discipline but lacks gas optionality. The cleanest comp on Permian execution; EOG diversifies away the Permian-decline tail.
- **Devon Energy.** Permian + Bakken + Eagle Ford. Smaller. Devon's CEO publicly disputes that the Permian is at peak; EOG management has been more cautious [16]. The disagreement is itself a tell about where each portfolio is sited.
- **Expand Energy (CHK + SWN merger) and EQT.** Pure-play gas. Larger gas reserves, lower per-Mcf cost basis in Haynesville/Marcellus. **They beat EOG on gas-scale**; EOG beats them on oil optionality and balance-sheet diversification. If the AI-gas thesis dominates, EQT/Expand are more direct expressions; EOG is a hedged version.

## Bull case — technical
For the stock to materially outperform, you need **two of three** to be true over 18–24 months:

1. **Henry Hub re-rates structurally to $4.00–$5.00**, driven by ~10 Bcf/d of incremental LNG demand 2026–2028 [5] plus 5–10 Bcf/d of behind-the-meter and grid-connected gas demand for AI loads. EOG's standalone gas (Utica + Dorado) gets revalued from "marginal Mcf" to "anchor for a $1B+ PPA-style deal."
2. **EOG signs a named hyperscaler or IPP gas-supply contract** specifically against Utica or Dorado volumes, on a multi-year, JKM-or-Brent-style indexed basis. This converts EOG from a price-taker to an infrastructure partner [6]. As of Q1 2026, no such announcement is public — only directional commentary [6][13].
3. **Permian peer inventory degrades faster than EOG's**, validating the "premium/double-premium" screening framework and extending EOG's relative cost-of-supply lead. The 1H25 productivity declines are industry-wide, not EOG-specific [11][12].

**Base rate context:** Commodity producers riding new structural-demand cycles (US shale 2010–2014; iron ore 2003–2010; uranium 2005–2007) typically deliver 2–4× returns at the cycle peak but compress hard on multiple before consensus EPS rolls over. Cycles last 3–7 years and end abruptly. EOG today is best read as Year 1–2 of a potential gas-demand cycle, not Year 5.

Connection to financials: at ~$130 with 12× forward earnings, a $4 Henry Hub print + an announced PPA would justify a ~16× multiple on a $12+ EPS, getting to a $180–$200 stock without heroics.

## Bear case — technical
A short-seller who knows the stack writes:

1. **Permian per-foot productivity is in a real, not cyclical, decline** [11]. GOR rising basin-wide; oil cuts dropping below 65% in Wolfcamp A&B; some sub-plays seeing >10% declines. EOG's 2025 Delaware vintages are not exempt. The "premium inventory" frame is increasingly a function of where you choose to drill, not how good your wells are.
2. **Pipeline overbuild risk.** 4.5+ Bcf/d of Permian takeaway commissions in 2H26 [7] against a basin where oil — and therefore associated gas — is plateauing. This could compress in-basin gas pricing again as projected supply doesn't materialize, or compress Henry Hub spreads as it does.
3. **The hyperscaler-PPA story is a narrative, not a contract.** No named deal. Hyperscalers may prefer to (a) build SMRs (Constellation/Vistra-style), (b) contract through midstream marketers and IPPs rather than upstream producers, or (c) rely on grid-connected wholesale gas. Upstream E&P is structurally far from the offtake decision.
4. **LNG-linked exposure is small.** 280–460 MMBtu/d of JKM/Brent indexing on a base of ~7+ Bcf/d of total gas production. Even doubling it doesn't change the fundamental price-taker reality.
5. **Encino at $5.6B (~$8,300/acre) is rich.** Integration risk is moderate; price was full. If Utica well productivity doesn't compound, the synergy case ($150M Y1) is thin against $3.5B incremental debt [3].
6. **EIA forecasts US oil production to slightly decline in 2026.** The marginal-barrel narrative cuts both ways: it supports oil price but suggests EOG's oil volume growth ceiling is closer than guidance implies.
7. **Energy multiple compression.** If hyperscaler capex guidance is cut sequentially, gas-power demand thesis derates broadly; EOG carries the multiple expansion built into the H2 2024–H1 2026 rally.

## Market view check
At $129/share, EOG trades ~12× forward EPS, ~5.9× EV/EBITDA, ~3.1× EV/sales — a **discount to the E&P peer median (~7.5× EV/EBITDA)** [9] but a premium to pure-play Permians like FANG. Consensus PT $144 (+11%). The market is pricing **competent shale operator with normal cyclicality** — it is not pricing a structural Henry Hub re-rate and it is not pricing a signed hyperscaler PPA. That's consistent with the technical reality: the AI-gas thesis is real but unproven at the contract level. **Mispricing direction:** asymmetric to the upside if (a) any major US E&P signs a behind-the-meter hyperscaler PPA at premium pricing, OR (b) Henry Hub strip 2027 moves >$0.50/MMBtu. Asymmetric to the downside if Permian production peaks materially earlier than 2027 and Encino integration disappoints.

## 90-day falsifiers
- **Q2 2026 earnings (early August).** Watch (i) per-foot productivity in Delaware — any further degradation from 1H25 vintages confirms bear case [11]; (ii) Encino synergies tracking vs. $150M Y1; (iii) any formal disclosure of hyperscaler/IPP gas offtake.
- **Hyperscaler gas-supply announcement, any E&P.** If a peer (XOM, FANG, EQT, Expand) signs first, EOG's narrative loses optionality. If EOG signs, bull confirmed.
- **Henry Hub 2027 strip.** Move >$0.50/MMBtu either direction in 90 days resets the gas thesis.
- **Blackcomb / Hugh Brinson commercial in-service.** On-time = Permian gas relief and tighter Waha basis. Slip = continued Waha discount and short-term EOG margin pressure on associated gas.
- **EIA STEO monthly releases.** Each 2027 oil-production revision is a tell on Permian peak timing.
- **Crude price.** WTI sustained <$55 stresses growth capex; sustained >$75 makes the gas-thesis irrelevant to the stock for a quarter.

## What I could not verify
- Whether EOG has signed (vs. publicly negotiated) any hyperscaler or IPP PPA-style gas supply contract. All references are management-stated intent and analyst commentary [6][13], not announced deals.
- The exact 2026 production split between (a) Henry Hub-exposed, (b) Waha-exposed, (c) JKM/Brent-linked, (d) Brent crude-linked. Disclosed components are partial.
- True forward P/E. Sources span 8.0× (NTM, stockanalysis.com) to 12.2× (calendar-2026 consensus, public.com). Used 12× as central.
- Encino well-level economics on the EOG operating model vs. the prior Encino model — the $150M synergy figure is not decomposed.
- Hyperscaler share of gas-fired demand vs. LNG and grid replacement — RBN's "3× LNG > data center" figure [5] is one estimate; others (Wood Mackenzie, EIA STEO) frame the split differently.
- Whether Permian 1H 2025 per-foot productivity declines are mean-reverting (transient, vintage-mix-driven) or structural (Tier 1 exhaustion). The literature splits.
- Independent confirmation of frac-sand and water-pipeline cost savings at 2025/2026 input prices — the $0.5M/well figure is from older periods.
- Short interest detail (only top-line 3.0% confirmed [9], no days-to-cover or trend).

## Sources
[1] https://finance.yahoo.com/quote/EOG/ — retrieved 2026-05-10 — May 8 close $129.42, 52-week range $101.59–$151.87, market cap $69.25B
[2] https://www.fool.com/earnings/call-transcripts/2026/05/06/eog-eog-q1-2026-earnings-call-transcript/ — retrieved 2026-05-10 — Q1 2026 earnings call: lateral lengths, drilled-feet/day, LNG portfolio sizing, crude export capacity
[3] https://investors.eogresources.com/2025-05-30-EOG-Resources-to-Acquire-Encino-Acquisition-Partners-from-CPP-Investments-and-Encino-Energy — retrieved 2026-05-10 — Encino deal terms ($5.6B, 675k acres, $3.5B debt, $150M synergies)
[4] https://www.investing.com/news/company-news/eog-q1-2026-slides-15b-free-cash-flow-supports-25b-return-plan-93CH-4664656 — retrieved 2026-05-10 — Q1 FCF $1.5B, $950M returned, $4.08 dividend
[5] https://naturalgasintel.com/news/data-centers-playing-second-fiddle-to-lng-as-haynesville-permian-ramp-up-natural-gas-supply/ — retrieved 2026-05-10 — RBN: LNG demand ~3× data-center gas demand through 2030
[6] https://markets.financialcontent.com/stocks/article/marketminute-2026-1-9-the-gas-inflection-eog-resources-pivots-toward-ai-and-lng-as-2026-strategy-takes-shape — retrieved 2026-05-10 — EOG narrative on AI/LNG pivot
[7] https://www.eia.gov/todayinenergy/detail.php?id=63044 — retrieved 2026-05-10 — Permian gas takeaway: Blackcomb 2.5 Bcf/d, Hugh Brinson 1.5 Bcf/d, GCX +570 MMcf/d, return of constraints early 2026
[8] https://www.fool.com/earnings/call-transcripts/2026/02/25/eog-resources-eog-q4-2025-earnings-transcript/ — retrieved 2026-05-10 — FY 2025 results, 2026 capital plan ($6.5B capex), basin commentary
[9] https://stockanalysis.com/stocks/eog/statistics/ — retrieved 2026-05-10 — EV $70.1B, EV/EBITDA 5.86×, forward P/E 8.04×, short interest 3.0% of float, dividend yield 3.14%
[10] https://www.vitol.com/vitol-and-eog-resources-enter-into-long-term-gas-supply-agreement-indexed-to-brent-pricing-2/ — retrieved 2026-05-10 — Vitol SPA: 180 MMBtu/d, Brent-indexed, 10 years from 2027
[11] https://www.hartenergy.com/technology-and-innovation/drilling/he-tph-eog-resources-permian-wells-showing-steep-declines/ — retrieved 2026-05-10 — Permian per-foot productivity declines in 1H 2025 EOG vintages; Delaware program return profile
[12] https://kingdomexploration.com/?article=permians-dirty-secret-tier-1-acreage-exhaustion-signals-coming-supply-crunch-dec-09 — retrieved 2026-05-10 — Tier 1 inventory exhaustion at $50 WTI, $65–75 needed for remaining
[13] https://naturalgasintel.com/news/eog-touts-coming-out-party-for-dorado-utica-as-natural-gas-powers-into-2026-demand-surge/ — retrieved 2026-05-10 — Dorado/Utica behind-the-meter positioning vs. associated gas
[14] https://www.fool.com/investing/general/2014/04/10/1-problem-eog-resources-will-never-have.aspx — retrieved 2026-05-10 — frac sand vertical integration, $0.5M/well savings (older source; magnitude likely larger today)
[15] https://www.marketbeat.com/stocks/NYSE/EOG/forecast/ — retrieved 2026-05-10 — consensus PT $143.81, Buy, 21 analysts
[16] https://www.ogj.com/general-interest/companies/article/55299176/peak-shale-devon-and-eog-execs-differ-on-the-timeline — retrieved 2026-05-10 — Devon vs. EOG management on Permian peak timing
[17] https://rbnenergy.com/daily-posts/blog/new-entrant-tackle-permians-dire-need-gas-takeaway-capacity — retrieved 2026-05-10 — Hugh Brinson pipeline route, capacity, Phase 2 expansion to 2.2 Bcf/d