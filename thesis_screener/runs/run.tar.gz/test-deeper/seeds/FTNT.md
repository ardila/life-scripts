I have what I need. Writing the dossier now.

```markdown
# FTNT — Fortinet, Inc.

## Where this sits in the AI stack
FTNT operates at the **network security plane** — not the AI compute, memory, packaging, interconnect, or power layers — selling vertically integrated NGFW appliances (FortiGate) built around custom 7nm ASICs (FortiSP5, NP7) running FortiOS, plus a SASE/SD-WAN/cloud security overlay [4][5]. Direct AI-infrastructure exposure is narrow: a December 2025 integration that runs FortiGate-VM on NVIDIA BlueField-3 DPUs (ARM64 image, OVS bridges, FortiOS ≥7.6.3) for east-west isolation in "AI factory" deployments [6], plus FortiOS 8.0 inspection of MCP and agent-to-agent traffic [5]. The dominant business is still north-south enterprise/branch firewall — a downstream beneficiary of capex-driven enterprise hardening, not a primary AI-buildout name.

## Snapshot
- **Price:** $114.07 (2026-05-08 close) [1]
- **Market cap:** ~$83.5B (732.1M shares × $114.07) [1][2]
- **52-week range:** $70.12 – $114.66 [22] (essentially trading at the high)
- **Forward P/E:** ~36× on FY26 non-GAAP EPS midpoint $3.13 [3] (Yahoo's cached 29.3× pre-dates the post-Q1 rally [2])
- **EV / NTM revenue:** ~10.3× (EV ≈ $80.7B after ~$2.8B net cash, on $7.79B FY26 revenue midpoint [3][24])
- **Consensus 12-month price target:** ~$90 median (range $64–$120; UBS recently to $115, Wedbush $120) — implies **~21% downside** to median from current price [20]
- **YTD total return:** +13% [22] (TTM still −8%, reflecting a 2025 drawdown on slowing growth fears)
- **Short interest (% of float):** ~3.8% (most recent disclosed; ~23.6M shares short) [25]

## Moat — what it is physically made of
The moat is **vertical hardware-software integration in the NGFW box** — narrower and more durable than bulls claim, less defensible than the company's marketing implies. Decomposed:

**1. Custom security silicon (durable, 5–7 year lead).** Fortinet is the only NGFW vendor designing its own dataplane ASICs at scale. The current generation:
- **FortiSP5** — 7nm SoC consolidating L7 firewall, IPsec/SSL crypto, and CP10 content-processing accelerators alongside Arm cores. Vendor specs: 40 Gbps firewall, 37 Gbps IPsec VPN, 2.5 Gbps SSL deep inspection, 88% lower power vs. equivalent x86 [4][26].
- **NP7** — discrete network processor in high-end chassis, accelerates IPv4/v6 forwarding, IPsec, VXLAN termination, NAT, hardware logging [27].
- **CP9 / CP10** — content-processor blocks for pattern matching and crypto, integrated into SP5 or discrete in larger SKUs [4].
The competitive significance is *price-performance per rack U at line-rate L7*: no merchant-silicon competitor (PANW on Intel x86, Check Point on x86, Cisco mostly on Intel + recently DPUs) matches Gbps-per-watt at the entry/mid range. This is what permits 80%+ gross margins on appliances [21]. Foundry partner is not publicly disclosed; 7nm strongly implies TSMC N7/N7+ but I could not source confirmation. Lead time advantage is roughly the 24–36 months a competitor would need to tape out and yield comparable silicon — and PANW/Check Point have shown no intent to do so, having explicitly chosen merchant silicon for software flexibility.

**2. FortiOS as the integration glue (durable, but increasingly contested).** Single-image OS spans FortiGate appliances, VMs, BlueField-3 DPU, container, and cloud SKUs — a real engineering asset. Quantum-safe IPsec key exchange (ML-KEM, BIKE, HQC, Frodo hybrid mode) shipped natively in FortiOS 7.6, expanded in 8.0; this matters because most competitors will need to retrofit and Fortinet ships it at no incremental cost [16]. FortiOS 8.0's AIAP signature database and MCP/agent-to-agent inspection [5] are early but ahead of Cisco/PAN in *firewall-layer* AI-traffic visibility (Cisco's competing answer is in-fabric via Hypershield, which is architecturally different — see Competitive section).

**3. Distribution and installed base (very durable).** ~40,000 SD-WAN enterprise customers [19], 800k+ total customers, channel-led with deep MSSP penetration. The single most underappreciated piece of the moat: hardware NGFWs have a 5–7 year refresh cadence and operational dependencies (security policies, VPN topologies, SD-WAN overlays) that make rip-and-replace genuinely painful. The current 2025–2026 refresh cycle from F-series to G-series is ~50% complete and has driven Q4'25 product +20% and Q1'26 product +41% [21][1].

**4. Patents (1,800+, after Lacework added 225).** [7] Probably more useful as defensive ballast than as leverage, given that NGFW is a mature category where most architectural patents have been worked around.

**What is *not* a real moat:** brand recognition outside infosec, AI capability (Lacework was a $300–500M asset purchase, not a frontier-AI build), and SASE — Fortinet is #5 in SASE share behind Zscaler (21%), Cisco, PAN, Broadcom [11].

## AI buildout bottleneck map
FTNT sits **largely indifferent** to the primary 24-month bottlenecks. Specifically:
- **Power generation / grid interconnect** (multi-year turbine backlogs, gas-peaker bottleneck): indifferent. FTNT does not consume grid capacity at scale.
- **CoWoS-L advanced packaging / HBM3e/HBM4 yield**: indifferent. SP5/NP7 are 7nm logic with no HBM stacking — they share TSMC wafer capacity with thousands of other 7nm parts and would not be displaced by AI accelerator allocation.
- **Optical interconnect / CPO supply**: indifferent. FortiGate boxes top out at 400G QSFP today; pluggables, not silicon photonics.
- **Liquid cooling >100kW/rack**: indifferent — air-cooled appliances.
- **Kernel/compiler/distributed-training talent**: indifferent.
- **AI-driven enterprise security spend**: **modest beneficiary**. Each AI deployment generates new east-west traffic, shadow-AI usage, and prompt-exfiltration risk that drives incremental NGFW/SASE/CASB spend. This is real but secondary; it is not the kind of bottleneck where FTNT *gates* the buildout.
- **One direct touchpoint**: the BlueField-3 integration [6] makes FTNT a participant in AI-factory east-west security, but it is one of several vendors that can run on BF3 (Cisco, Check Point, Palo Alto can all containerize on Arm DPUs) — FTNT's ASIC moat does not extend to the DPU layer.

Net: Fortinet is **not on the critical path** of the AI buildout. It is exposed to a second-derivative tailwind (AI → more data centers → more enterprise security), not a first-derivative one.

## Competitive teardown
Three credible architectural threats and one price-flank attack:

**Cisco — Hypershield + N9300 Smart Switches (most credible long-term threat).** Cisco's bet is that security belongs *in the data path*, enforced by DPUs embedded in the switch, not in a perimeter box. The N9300 uses programmable DPUs (AMD Pensando lineage) to do stateful segmentation per port, with Hypershield handling distributed exploit protection and autonomous segmentation; an extended NVIDIA partnership delivers AI-workflow visibility [9]. This bypasses the FortiGate refresh cycle entirely for greenfield AI data centers. Timeline: meaningful share takeover would require 2–3 refresh cycles (5–10 years); architectural superiority for east-west enforcement is real *today*. FTNT's BlueField-3 answer [6] is structurally similar (move security into the infrastructure) but Cisco owns the switch port, not Fortinet.

**Palo Alto Networks — platformization + Chronosphere.** Q2 FY26: $2.6B revenue +15%, ~1,550 platformization deals (+35% YoY), 119% NRR [8]. The $3.35B Chronosphere acquisition adds "agentic remediation" and observability — competitively differentiated from Fortinet in the SOC/XDR layer, neutral-to-behind on appliance economics. PAN trades at ~10× EV/NTM rev, similar to FTNT — multiple parity is striking given PAN grows faster in software but FTNT generates better FCF margin. **Honest read: PAN already has parity-or-better in software/SOC; FTNT keeps its appliance-economics edge.**

**CrowdStrike + F5 — pincer from endpoint and ADC.** F5 BIG-IP customers get Falcon free through Oct 2026 [10], extending Crowdstrike from endpoint to web-app/API perimeter. Doesn't touch FortiGate's NGFW workload directly but bleeds budget. CRWD's Spring '26 release adds "Securing AI Everywhere" — agentic SOC and AI-native threat detection [10]. CRWD trades at ~16× EV/NTM rev — a market vote that subscription/agent economics > appliance economics over a 5-year horizon.

**Check Point / Juniper / Huawei — flank.** Limited share momentum; Check Point's Quantum Force has decent specs but anemic SASE; Juniper is now part of HPE and the integration is ongoing.

**Where FTNT has parity or better today**: hybrid mesh firewall execution (Gartner: gold for execution, bronze for vision; PAN reverses this) [11]; perimeter security/firewall installed-base share — FortiGate ~16% vs PAN ~7.6% per 6sense [12]; SD-WAN top-3 with 40k enterprise customers [19]; ASIC price-per-Gbps at the SMB/midmarket entry tier (uncontested).

**Where FTNT is behind**: SASE share rank (#5) [11], cloud-native CNAPP (Lacework integration still maturing), AI-SOC agentic capabilities (PAN/CRWD ahead), data-center-fabric security (Cisco Hypershield architecturally ahead).

## Bull case — technical
The technical conditions for outperformance — and what would need to remain true for each — read like this:

1. **Refresh cycle has another 12–18 months of legs.** F-series boxes shipped 2019–2021 are end-of-life and the G-series (powered by SP5/NP7) is the natural upgrade. ~50% complete per management commentary [21]; Q1'26 product +41% YoY confirms reacceleration [1]. If product growth holds 25%+ for 3–4 more quarters, FY26 hits the high end of guide and FY27 has positive comparisons.
2. **ASIC price-performance edge persists at the entry/mid range.** This is fundamentally a wafer-cost and design-team question. SP5 is 7nm; if Fortinet keeps a 1-generation lead on competitors stuck on x86 for 3+ years, gross margin on hardware stays 80%+ and the company can fund the price-flank against PAN's appliance line.
3. **AI traffic adds incremental load in front of existing FortiGate fleet.** Encrypted traffic, MCP/agent traffic, shadow AI all generate new inspection demand that the installed base needs more capacity to handle [5][3] — the FG 3500G's 595 Gbps firewall and 400Gb connectivity is positioned for this [3].
4. **BlueField-3 partnership scales.** If FortiGate-VM-on-BF3 captures a meaningful share of enterprise AI-factory east-west isolation [6], that's a new SAM where FTNT's software runs without needing the appliance.
5. **The Cisco/PAN/CRWD architectural alternatives take 3–5 years to displace the perimeter NGFW model**, which is the **base rate**: comparable security category transitions (anti-virus → EDR took ~7–10 years; on-prem SIEM → cloud SIEM is still incomplete after 10+ years; CASB/SSE consolidation has eaten less than expected) suggest moats in security categories with operational lock-in erode slowly.

Financial outcome: holding ~10× EV/NTM rev with 14–15% revenue growth and 32%+ FCF margin, and the multiple expanding 1–2 turns as AI-traffic narrative gets more credit, gets you to ~$135 (+18%). Bull-bull case (multiple to PAN+ at 11–12×) gets you to $145.

## Bear case — technical
1. **AI data centers are built around DPUs in the fabric, not perimeter boxes.** Cisco N9300 + Hypershield + NVIDIA partnership [9], or anyone running their own VPC-native security at hyperscale, means new buildout doesn't include a FortiGate. The FortiGate-VM-on-BF3 SKU [6] is an attempt to be present on this fabric, but it is one of *N* possible workloads on BF3, not the only one — FTNT's ASIC moat is not portable to merchant DPU silicon.
2. **The refresh cycle is a one-time sugar high.** When the F→G transition completes in mid-2027, product growth normalizes to single digits and the multiple compresses. Management already implemented 5–20% list price increases (March 2026) [21] — pulling forward demand and exhausting the easy pricing lever.
3. **CVE recidivism is structural, not anomalous.** CVE-2024-55591 (CVSS 9.6, exploited from Nov 2024, fixed Jan 2025), CVE-2025-24472 (CVSS 8.1), the 15k FortiGate config dump [13] — and these come on top of multiple critical FortiOS/FortiManager issues over the past three years. Each one accelerates customer evaluation of alternatives and gives PAN/Cisco/CRWD sales teams free ammunition. CrowdStrike's free-Falcon-on-BIG-IP play [10] is exactly this style of land-grab.
4. **The "AI security" pitch is 90% repackaged DPI.** Native shadow-AI detection [3] and AIAP signatures [5] are useful, but adversarial AI defense (prompt injection, model evasion) requires runtime techniques that don't naturally fit a network-layer appliance. PAN/CRWD have stronger runtime stories. Fortinet's marketing positions FTNT for the AI security wave; the technical reality is more incremental.
5. **Multiple is rich for a 14–15% grower.** ~10× EV/NTM rev and ~36× forward P/E on a hardware-heavy business with single-digit-percent gross-margin upside. PAN trades at the same EV/Rev with faster growth and cleaner platform narrative; CRWD trades at 16× and is growing 20%+. The FTNT multiple has to defend, not expand. **Base rate caveat: in past hardware-security cycles (Check Point post-2010, Juniper SRX), peak-multiple-on-peak-refresh has marked the top.**

A bear scenario gets you to $80–85 (consensus PT) on multiple compression to 8× EV/Rev and growth deceleration to ~12% in FY27.

## Market view check
At $114, FTNT trades meaningfully above the $90 consensus PT [20]. The market is paying ~10× EV/NTM rev and ~36× forward P/E for a 14–15% grower with best-in-class FCF (32%+ FCF/rev [15]) and a real-but-narrow ASIC moat. The bull narrative the price embeds is: refresh cycle extends, FortiOS 8.0 + BlueField-3 makes FTNT a credible AI-data-center security vendor, multiple holds. **My read**: the appliance/refresh story is real and earnings momentum will persist into Q2-Q3, but the AI-security/multiple-expansion piece is doing more work in the price than the technical reality supports. The competitive teardown above suggests architectural alternatives are real (Hypershield-in-switch, DPU-in-fabric) even if displacement is slow. Price is roughly fair-to-slightly-rich; not a clear short, not a clear long — closer to "trim into strength" than "add."

## 90-day falsifiers
Specific events to watch by ~Aug 2026:
- **Q2 2026 earnings (early Aug 2026)**: product revenue YoY <25% would say refresh is rolling over; billings <$2.09B (low end of guide [3]) would say price increases are being absorbed by attach-rate decline.
- **Cisco Live (June 2026)**: any disclosed N9300 + Hypershield deployment numbers, especially with named hyperscaler/AI-cloud customers — would directly evidence the in-fabric-security threat.
- **NVIDIA GTC commentary or BF3 design-win disclosure** mentioning Cisco/PAN/Check Point as DPU security partners on equal footing — would dilute the FTNT BlueField narrative.
- **Any new critical FortiOS/FortiManager CVE (CVSS ≥9.0)**: based on the 2024–2025 cadence, baseline probability of one in 90 days is non-trivial. A bad enough one could trigger a 10–15% stock move.
- **Hyperscaler Q2 capex commentary**: enterprise IT budget proxy. >10% sequential cuts to capex guidance would reduce the "AI tailwind" portion of the FTNT bull case.
- **PANW Q3 FY26 (Aug 2026)**: platformization deal count and net-new logo growth — if PAN accelerates while FTNT is tied to refresh cadence, the relative-value argument flips.

## What I could not verify
- **Foundry partner / wafer allocation** for SP5 and NP7. 7nm strongly implies TSMC N7/N7+ but I could not find a public confirmation; it could be Samsung. Material to gross margin durability if Samsung-fabricated.
- **ASIC team headcount** at Fortinet — I could find R&D total spend ($717M in 2024 [14]) but no breakout for silicon design vs. software vs. threat research.
- **Hyperscaler revenue concentration** — Fortinet does not disclose a top-10 customer concentration; if hyperscalers are <5% of revenue (likely, given enterprise/MSSP focus), the AI-buildout exposure is even thinner than implied.
- **BlueField-3 FortiGate-VM deployment count** — announced Dec 2025 [6], no deployment numbers disclosed; cannot size the SAM.
- **Lacework purchase price** — undisclosed; reported $300–500M range based on Wiz's prior offer [7], but could be materially different.
- **Hardware ASP trend post-March 2026 price hikes** — unit economics behind the +41% Q1 product growth (mix vs. price vs. units) not yet broken out.
- **MLPerf-style or independent inspection-throughput benchmarks** comparing SP5 vs. PAN's latest x86+accelerator or Cisco DPU at line-rate with realistic policy depth — I could find vendor specs on both sides but no neutral head-to-head.

## Sources
[1] https://www.fortinet.com/corporate/about-us/newsroom/press-releases/2026/fortinet-reports-first-quarter-2026-financial-results — retrieved 2026-05-10 — Q1 2026 results: revenue $1.85B (+20%), product $645M (+41%), billings $2.09B (+31%), GAAP EPS $0.72.
[2] https://stockanalysis.com/stocks/ftnt/statistics/ — retrieved 2026-05-10 — Shares outstanding 732.1M, forward P/E 29.27 (cached pre-rally), valuation comparables.
[3] https://www.stocktitan.net/news/FTNT/fortinet-reports-strong-first-quarter-2026-financial-aiqf1lc64cd7.html — retrieved 2026-05-10 — FY26 guidance: revenue $7.71–7.87B, non-GAAP EPS $3.10–3.16, Q2 guide.
[4] https://www.servethehome.com/fortinet-fortisp5-asic-launched/ — retrieved 2026-05-10 — FortiSP5 7nm SoC architecture, accelerator block composition (NP7 Lite + CP10 + Arm cores), throughput specs.
[5] https://www.fortinet.com/corporate/about-us/newsroom/press-releases/2026/fortinet-introduces-fortios-8-expand-secure-networking-with-secure-ai-controls-fabric-based-ai-agents-flexible-sase-and-simplified-sdwan — retrieved 2026-05-10 — FortiOS 8.0 features: AIAP database, MCP traffic inspection, agent-to-agent visibility, sovereign SASE, PQC.
[6] https://siliconangle.com/2025/12/16/fortinet-brings-fortigate-vm-security-nvidia-bluefield-3-ai-factories/ — retrieved 2026-05-10 — FortiGate-VM on NVIDIA BlueField-3 DPU, ARM64 image, FortiOS 7.6.3+ requirement, AI factory east-west use case.
[7] https://siliconangle.com/2024/06/10/fortinet-acquires-cloud-security-startup-lacework/ — retrieved 2026-05-10 — Lacework acquisition (CNAPP, ~225 patents, completed Aug 2024).
[8] https://futurumgroup.com/insights/palo-alto-networks-q2-fy-2026-arr-accelerates-as-platform-strategy-scales/ — retrieved 2026-05-10 — PANW Q2 FY26: $2.6B revenue +15%, 1,550 platformization deals +35%, 119% NRR.
[9] https://www.cisco.com/site/us/en/products/security/hypershield/index.html and https://newsroom.cisco.com/c/r/newsroom/en/us/a/y2025/m06/cisco-transforms-security-for-the-agentic-ai-era-further-fusing-security-into-the-network.html — retrieved 2026-05-10 — Hypershield architecture, N9300 Smart Switch DPU enforcement, NVIDIA AI Defense partnership.
[10] https://cloudnews.tech/f5-and-crowdstrike-bring-threat-hunting-to-the-heart-of-web-traffic-falcon-arrives-on-big-ip-and-will-be-free-through-2026/ and https://www.crowdstrike.com/en-us/resources/crowdcasts/introducing-the-falcon-platform-spring-2026-release/ — retrieved 2026-05-10 — Falcon free on BIG-IP through Oct 2026; Spring '26 release "Securing AI Everywhere" + agentic SOC.
[11] https://www.bankinfosecurity.com/palo-alto-fortinet-check-point-control-firewall-gartner-mq-a-29336 and https://www.sdxcentral.com/news/fortinet-joins-palo-alto-cato-netskope-as-gartner-sase-leaders/ — retrieved 2026-05-10 — Hybrid mesh firewall MQ rankings (PAN gold vision, FTNT gold execution); SASE leaders cohort.
[12] https://6sense.com/tech/perimeter-security-and-firewalls/palo-alto-nextgeneration-firewall-market-share — retrieved 2026-05-10 — Installed-base share data: FortiGate ~16%, PAN NGFW ~7.65% in perimeter security/firewalls.
[13] https://www.tenable.com/blog/cve-2024-55591-fortinet-authentication-bypass-zero-day-vulnerability-exploited-in-the-wild and https://www.helpnetsecurity.com/2025/01/14/fortinet-fortigate-zero-day-vulnerability-exploited-cve-2024-55591/ — retrieved 2026-05-10 — Critical zero-day disclosure, exploitation timeline, 15k config-dump leak.
[14] https://www.macrotrends.net/stocks/charts/FTNT/fortinet/research-development-expenses — retrieved 2026-05-10 — R&D spend: $717M (2024), $614M (2023), trajectory.
[15] https://investor.fortinet.com/news-releases/news-release-details/fortinet-reports-strong-fourth-quarter-and-full-year-2025/ — retrieved 2026-05-10 — FY2025 totals: revenue $6.8B (+14.2%), FCF $2.2B (+18.4%), capex $364.8M.
[16] https://docs.fortinet.com/document/fortigate/7.6.0/new-features/229631/enhancing-security-with-post-quantum-cryptography-for-ipsec-key-exchange-7-6-1 and https://www.thefastmode.com/technology-solutions/47550-fortinet-launches-fortios-8-0-with-ai-driven-security-and-quantum-safe-protection — retrieved 2026-05-10 — PQC algorithm support (ML-KEM, BIKE, HQC, Frodo) in FortiOS 7.6/8.0.
[17] https://blogs.arista.com/blog/arista-and-palo-alto-networks-strengthen-partnership-in-the-new-age-of-ai-security — retrieved 2026-05-10 — Arista + PANW east-west enforcement partnership (microperimeter on switches, NGFW for inspection).
[18] https://finance.yahoo.com/news/hardware-firewall-market-outlook-2026-123000677.html — retrieved 2026-05-10 — Hardware firewall TAM: $22.87B (2025) → $41.62B (2031).
[19] https://www.sdxcentral.com/analysis/fortinet-sd-wan-tops-cisco-broadcom-in-evolving-market/ — retrieved 2026-05-10 — Fortinet SD-WAN ~40k enterprise customers; Gartner SD-WAN MQ leaders cohort.
[20] https://www.marketbeat.com/stocks/NASDAQ/FTNT/forecast/ and https://www.dailypolitical.com/2026/05/09/ubs-group-forecasts-strong-price-appreciation-for-fortinet-nasdaqftnt-stock.html — retrieved 2026-05-10 — Analyst PT consensus and recent UBS/Wedbush upgrades.
[21] https://www.ainvest.com/news/fortinet-firewall-refresh-growth-catalyst-waning-2508/ — retrieved 2026-05-10 — Refresh cycle 40–50% complete, $400–450M revenue contribution 2025–26, March 2026 5–20% price hike, BlueField-3 integration commentary.
[22] https://www.tikr.com/blog/up-21-last-year-can-fortinet-stock-still-deliver-20-annual-returns-in-2026 and https://www.tradingview.com/symbols/NASDAQ-FTNT/ — retrieved 2026-05-10 — 52-week range $70.12–$114.66, YTD +13%, TTM −8%.
[23] https://www.fortinet.com/blog/business-and-technology/john-maddison-on-fortisp5-asic and https://www.fortinet.com/content/dam/fortinet/assets/brochures/brochure-ftnt-spu-book.pdf — retrieved 2026-05-10 — SP5 design rationale, full SPU lineup brochure (NP7, CP9, SP5).
[24] https://stockanalysis.com/stocks/ftnt/statistics/ — retrieved 2026-05-10 — Net cash position (~$2.8B), used to compute EV.
[25] https://www.nasdaq.com/market-activity/stocks/ftnt/short-interest — retrieved 2026-05-10 — Short interest ~23.6M shares (~3.8% of float).
[26] https://www.theregister.com/2023/02/07/fortinet_sp5_asic/ — retrieved 2026-05-10 — Independent technical writeup of SP5 SoC characteristics.
[27] https://docs.fortinet.com/document/fortigate/7.6.5/hardware-acceleration/46115/fortigate-np7-architectures — retrieved 2026-05-10 — NP7 acceleration scope (forwarding, IPsec, VXLAN, NAT, hardware logging).
```